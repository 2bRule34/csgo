Render.AddFont = function(name, size, _) {
  if (name.indexOf('.ttf') === -1) name = name + '.ttf';

  return Render.GetFont(name, size, true);
}

//////////////////////////////////////////////////////////////////
// 
// nyaahook - nicole's optimized semirage script for Onetap v3.5
// Version: 1.4
// 
// Onetap: https://www.onetap.com/members/nicole.202258/
// YouTube: https://www.youtube.com/channel/UCu7XH6v6B5mG7nc7DOKvzHA
// 
// Changelog:
//  v1.4 (2020/10/09):
//    - [Desync] Removed low delta desync.
//    - [Desync] Changed desync to have max desync.
//    - [Desync] Added jitter slowwalk (similar effect to rainbowwalk).
//    - [General] Variables are now reset upon loading the script.
//    - [Rage] Added safepoint on limb hitboxes.
// 
//  v1.3 (2020/10/07):
//    - [Clan tag spammer] Added padding spaces.
//    - [Clan tag spammer] Cleaned up code, 0 hardcoding, same effect.
//    - [Clan tag spammer] Now compensates for latency.
//    - [Dynamic FOV] Adjusted distance scaling to be more aggressive.
//    - [Dynamic FOV] FOV limits are increased from 15 to 30. Use with care.
//    - [Fake duck] Values are now dynamically calculated based on the spot you're fake ducking at.
//                  The script will do its best to make the least amount of visible units of your head hitbox visible if you're fake ducking in front of a wall.
// 
//  v1.2 (2020/10/05):
//    - [Desync indicator] Fixed real peek direction arrows.
//    - [Fake duck] Adjusted values.
// 
//  v1.1 (2020/10/05):
//    - [Clan tag spammer] Fixed overloading the socket packet buffer with clan tag changes.
//    - [Desync] Adjusted desync auto direction to use low-delta desync (like slowwalk) when no corner is detected.
//    - [Desync] Wall detection distance was adjusted from 90 units to 120 units.
//    - [System] Fixed timers breaking after starting a new match.
// 
//  v1.0 (2020/10/04):
//    - Initial release.
// 
//////////////////////////////////////////////////////////////////

// JavaScript polyfills
if(String.prototype.padEnd === undefined)
{
    String.prototype.padEnd = function padEnd(targetLength, padString)
    {
        targetLength = targetLength >> 0;
        padString = String(typeof padString !== "undefined" ? padString : ' ');

        if(this.length > targetLength)
        {
            return String(this);
        }
        
        else
        {
            targetLength = targetLength - this.length;
            
            if(targetLength > padString.length)
            {
                padString += padString.repeat(targetLength / padString.length);
            }
            
            return String(this) + padString.slice(0, targetLength);
        }
    };
}

// script constants
const FONT_WEIGHT = 600;
const FONT_SIZE = 14;
const FONT_FAMILY = "Verdanab";
var RENDER_FONT = undefined;

const DYNAMIC_FOV_DISTANCE_SCALE = 4000.0;
const DYNAMIC_FOV_UPDATE_INTERVAL = 0.2; // interval per dynamic fov updates
const DYNAMIC_FOV_MIN_DISTANCE = 1500.0;
const DYNAMIC_FOV_MAX_DISTANCE = 100.0;

const PEEK_DIRECTION_UPDATE_INTERVAL = 0.2; // interval per antiaim updates
const PEEK_DISTANCE_TO_WORLD_BRUSH = 120.0;
const PEEK_NEITHER = 0;
const PEEK_LEFT = 1;
const PEEK_RIGHT = 2;

const HITBOX_HEAD = 0;
const HITBOX_CHEST = 5;

const CLANTAG_TEXT = "nyaahook!";
const CLANTAG_LOOP_SIZE = 32;
const CLANTAG_UPDATE_SPEED = 3.3;
const CLANTAG_UPDATE_INTERVAL = 0.1;

const LBY_MAX_DESYNC = 58; // https://www.onetap.com/scripting/setlbyoffset.130/
const DESYNC_REAL_OFFSET = LBY_MAX_DESYNC; // https://www.onetap.com/scripting/setrealoffset.129/

const DUCK_WALL_DISTANCE = 125.0; // distance to wall for duckamount detection
const DUCK_AMOUNT_OFFSET = 0.3; // for fast fakeduck, we need to cycle duck amount between the ideal traced amount and this offset
const DUCK_AMOUNT_OFFSET_FOUND = 0.03; // offset on top of the ideal duckamount
const DUCK_AMOUNT_MINIMUM = 0.4; // if no wall is detected by the time we reach duck amount of this value, just force it

// game definitions, yoinked from game src
const MAX_CLAN_TAG_LENGTH = 15; // 15 + null terminator

const IN_DUCK = (1 << 2);
const IN_RAWDUCK = (1 << 22);

const HITBOX_LEFT_THIGH = 7;
const HITBOX_RIGHT_THIGH = 8;
const HITBOX_LEFT_CALF = 9;
const HITBOX_RIGHT_CALF = 10;
const HITBOX_LEFT_FOOT = 11;
const HITBOX_RIGHT_FOOT = 12;
const HITBOX_LIMBS = [ HITBOX_LEFT_THIGH, HITBOX_RIGHT_THIGH, HITBOX_LEFT_CALF, HITBOX_RIGHT_CALF, HITBOX_LEFT_FOOT, HITBOX_RIGHT_FOOT ];

// get_center()[CENTER_X] and get_center()[CENTER_Y]
const SCREEN_X = 0;
const SCREEN_Y = 1;

const FLAG =
{
    Rage: (1 << 0),
    Autowall: (1 << 1),
    BodyAim: (1 << 2),
    SafePoint: (1 << 3),
    FakeDuck: (1 << 4),
    ClanTag: (1 << 5),
    SlowWalk: (1 << 6),
    SafeOnLimbs: (1 << 7)
};

var g_bDuck = false;
var g_flIdealDuckAmount = 0.0;
var g_nFlags = 0;
var g_flLastDynamicFOVUpdate = 0.0;
var g_nLastPeekDirection = PEEK_NEITHER;
var g_flLastDesyncUpdate = 0.0;
var g_sClantag = null;
var g_flLastClanTagUpdate = 0.0;
var g_bDisplayEntireTag = false;

function update_flag(flag, enabled)
{
    if(enabled)
    {
        g_nFlags |= flag;
    }
    
    else
    {
        g_nFlags &= ~flag;
    }
}

function is_flag_active(flag)
{
    return (g_nFlags & flag) > 0;
}

function set_autowall(state)
{
    if((g_nFlags & FLAG.Autowall) > 0 === state)
    {
        return;
    }
    
    update_flag(FLAG.Autowall, state);
    
    const aWeaponCategories = UI.GetChildren(["Rage", "Target", "SHEET_MGR"]);
    
    for(var i = 0; i < aWeaponCategories.length; i++)
    {
        UI.SetValue(["Rage", "Target", aWeaponCategories[i], "Disable autowall"], state ? 0 : 1)
    }
}

function set_ragebot_fov(fov)
{
    const aWeaponCategories = UI.GetChildren(["Rage", "Target", "SHEET_MGR"]);
    
    for(var i = 0; i < aWeaponCategories.length; i++)
    {
        UI.SetValue(["Rage", "Target", aWeaponCategories[i], "Field of view"], fov)
    }
}

function get_ragebot_fov()
{
    return UI.GetValue(["Rage", "Target", "General", "Field of view"]);
}

function update_flags()
{
    const bOldFlags = g_nFlags;
    
    set_autowall(UI.GetValue(["Rage", "General", "General", "Key assignment", "Autowall"]));
    update_flag(FLAG.Rage, UI.GetValue(["Rage", "General", "General", "Key assignment", "Ragebot activation"]));
    update_flag(FLAG.BodyAim, UI.GetValue(["Rage", "General", "General", "Key assignment", "Force body aim"]));
    update_flag(FLAG.SafePoint, UI.GetValue(["Rage", "General", "General", "Key assignment", "Force safe point"]));
    update_flag(FLAG.FakeDuck, UI.GetValue(["Rage", "Anti Aim", "General", "Key assignment", "Fake duck"]));
    update_flag(FLAG.ClanTag, UI.GetValue(["Rage", "Semirage", "Semirage", "Clan tag spammer"]));
    update_flag(FLAG.SlowWalk, UI.GetValue(["Rage", "Anti Aim", "General", "Key assignment", "Slow walk"]));
    update_flag(FLAG.SafeOnLimbs, UI.GetValue(["Rage", "Semirage", "Semirage", "Safe point on limb hitboxes"]));
    
    // this means the flag was just turned off!
    if((bOldFlags & FLAG.ClanTag) > 0 && !is_flag_active(FLAG.ClanTag))
    {
        Local.SetClanTag("");
    }
}

function am_i_alive()
{
    return Entity.IsAlive(Entity.GetLocalPlayer());
}

function am_i_airborne()
{
    const nLocalPlayer = Entity.GetLocalPlayer();

    return Entity.GetProp(nLocalPlayer, "CCSPlayer", "m_nWaterLevel") < WL_Waist && Entity.GetProp(nLocalPlayer, "CCSPlayer", "m_hGroundEntity") != 0;
}

function is_dynamic_fov_enabled()
{
    return UI.GetValue(["Rage", "Semirage", "Semirage", "Dynamic FOV"]);
}

function is_fov_indicator_enabled()
{
    return UI.GetValue(["Rage", "Semirage", "Semirage", "FOV indicator"]);
}

function is_valve_fakeduck_enabled()
{
    return UI.GetValue(["Rage", "Semirage", "Semirage", "Fake duck on official servers"]);
}

function is_jitter_on_slow_walk_enabled()
{
    return UI.GetValue(["Rage", "Semirage", "Semirage", "Jitter on slow walk"]);
}

function is_desync_autodirection_enabled()
{
    return UI.GetValue(["Rage", "Semirage", "Semirage", "Desync auto direction"]);
}

function is_desync_safety_enabled()
{
    return UI.GetValue(["Rage", "Semirage", "Semirage", "Desync safety checks"]);
}

function is_desync_direction_indicator_enabled()
{
    return UI.GetValue(["Rage", "Semirage", "Semirage", "Desync direction indicator"]);
}

function get_indicator_color()
{
    return UI.GetColor(["Rage", "Semirage", "Semirage", "Indicator color"]);
}

function add_semirage_tab()
{
    UI.AddSubTab(["Rage", "SUBTAB_MGR"], "Semirage");
    UI.AddCheckbox(["Rage", "Semirage", "Semirage"], "Safe point on limb hitboxes");
    UI.AddHotkey(["Rage", "General", "General", "Key assignment"], "Autowall", "Autowall");
    UI.AddCheckbox(["Rage", "Semirage", "Semirage"], "Fake duck on official servers");
    UI.AddCheckbox(["Rage", "Semirage", "Semirage"], "Jitter on slow walk");
    UI.AddCheckbox(["Rage", "Semirage", "Semirage"], "Desync auto direction");
    UI.AddCheckbox(["Rage", "Semirage", "Semirage"], "Desync safety checks");
    UI.AddCheckbox(["Rage", "Semirage", "Semirage"], "Desync direction indicator");
    UI.AddCheckbox(["Rage", "Semirage", "Semirage"], "Dynamic FOV");
    UI.AddSliderInt(["Rage", "Semirage", "Semirage"], "Minimum FOV", 0, 30);
    UI.AddSliderInt(["Rage", "Semirage", "Semirage"], "Maximum FOV", 0, 30);
    UI.AddCheckbox(["Rage", "Semirage", "Semirage"], "FOV indicator");
    UI.AddColorPicker(["Rage", "Semirage", "Semirage"], "Indicator color");
    UI.AddCheckbox(["Rage", "Semirage", "Semirage"], "Clan tag spammer");
}

function get_screen_center()
{
    const aScreenSize = Render.GetScreenSize();
    
    return [ aScreenSize[SCREEN_X] / 37, aScreenSize[SCREEN_Y] / 2];
}

function add_indicator(text, to_append)
{
    return text + to_append + "\n";
}

function draw_indicators()
{
    const aCenter = get_screen_center();
    var sIndicators = "";

    sIndicators = add_indicator(sIndicators, "FOV: " + get_ragebot_fov());
    if(is_flag_active(FLAG.Rage)) sIndicators = add_indicator(sIndicators, "MT");
    if(is_flag_active(FLAG.Autowall)) sIndicators = add_indicator(sIndicators, "AW");
    if(is_flag_active(FLAG.BodyAim)) sIndicators = add_indicator(sIndicators, "BODY");
    if(is_flag_active(FLAG.SafePoint)) sIndicators = add_indicator(sIndicators, "SAFE");
    if(is_flag_active(FLAG.FakeDuck)) sIndicators = add_indicator(sIndicators, "DUCK");

    Render.String(aCenter[SCREEN_X], aCenter[SCREEN_Y] + 40, 2, sIndicators, get_indicator_color(), RENDER_FONT);

    if(is_desync_autodirection_enabled() && is_desync_direction_indicator_enabled())
    {
        if(g_nLastPeekDirection == PEEK_LEFT)
        {
            Render.String(aCenter[SCREEN_X] - 40, aCenter[SCREEN_Y] - 7, 1, "<-  ", get_indicator_color(), RENDER_FONT);
        }

        else if(g_nLastPeekDirection == PEEK_RIGHT)
        {
            Render.String(aCenter[SCREEN_X] + 40, aCenter[SCREEN_Y] - 7, 1, "  ->", get_indicator_color(), RENDER_FONT);
        }
    }
}

function get_distance(pos1, pos2)
{
    return Math.sqrt(Math.pow((pos1[0] - pos2[0]), 2) + Math.pow((pos1[1] - pos2[1]), 2) + Math.pow((pos1[2] - pos2[2]), 2));
}

function get_closest_enemy_distance()
{
    const flLocalHead = Entity.GetHitboxPosition(Entity.GetLocalPlayer(), HITBOX_HEAD);
    const aEnemies = Entity.GetEnemies();
    var flMinimumDistance = Infinity;
    
    for(var i = 0; i < aEnemies.length; i++)
    {
        if(!Entity.IsAlive(aEnemies[i]) || Entity.IsDormant(aEnemies[i]))
        {
            continue;
        }
        
        const flEnemyPos = Entity.GetHitboxPosition(aEnemies[i], HITBOX_CHEST);
        const flDist = get_distance(flLocalHead, flEnemyPos);
        
        if(flDist < flMinimumDistance)
        {
            flMinimumDistance = flDist;
        }
    }
    
    return flDist;
}

function clamp(val, min, max)
{
    if(val < min)
    {
        return min;
    }
    
    if(val > max)
    {
        return max;
    }
    
    return val;
}

function distance_to_dynamic_fov(dist)
{
    const nMinFOV = UI.GetValue(["Rage", "Semirage", "Semirage", "Minimum FOV"]);
    const nMaxFOV = UI.GetValue(["Rage", "Semirage", "Semirage", "Maximum FOV"]);
    
    // can't divide by 0
    if(nMinFOV === 0 || nMaxFOV === 0 || dist === undefined)
    {
        return nMinFOV;
    }
    
    if(dist >= DYNAMIC_FOV_MIN_DISTANCE)
    {
        return nMinFOV;
    }
    
    if(dist <= DYNAMIC_FOV_MAX_DISTANCE)
    {
        return nMaxFOV;
    }
    
    return clamp(DYNAMIC_FOV_DISTANCE_SCALE / dist, nMinFOV, nMaxFOV);
}

function is_valve_server()
{
    return Entity.GetProp(Entity.GetGameRulesProxy(), "CCSGameRulesProxy", "m_bIsValveDS");
}

function do_valve_fakeduck()
{
    var nButtons = UserCMD.GetButtons();
    const flDuckAmount = Entity.GetProp(Entity.GetLocalPlayer(), "CCSPlayer", "m_flDuckAmount");

    // no duck, just reset our ideal amount
    if(flDuckAmount == 0.0)
    {
        g_flIdealDuckAmount = 0.0;
    }

    if(g_flIdealDuckAmount === 0.0 && flDuckAmount > 0.0)
    {
        const nLocalPlayer = Entity.GetLocalPlayer();
        const aflEyePos = Entity.GetEyePosition(nLocalPlayer);
        const aflViewAngles = Local.GetViewAngles();
        const aflEndPos = vector_add(aflEyePos, vector_mul_fl(angle_vectors([ 0.0, aflViewAngles[1], 0.0 ]), DUCK_WALL_DISTANCE));
        const nTrace = Trace.Line(nLocalPlayer, aflEyePos, aflEndPos);
        
        // can view from above
        if(nTrace[1] != 1 && flDuckAmount > g_flIdealDuckAmount)
        {
            g_flIdealDuckAmount = flDuckAmount - DUCK_AMOUNT_OFFSET_FOUND;
        }
    }

    if(g_flIdealDuckAmount == 0.0 && flDuckAmount >= DUCK_AMOUNT_MINIMUM)
    {
        g_flIdealDuckAmount = DUCK_AMOUNT_MINIMUM;
    }

    const flMinimumDuck = g_flIdealDuckAmount === 0.0 ? DUCK_AMOUNT_MINIMUM : g_flIdealDuckAmount;
    const flMaximumDuck = (g_flIdealDuckAmount === 0.0 ? DUCK_AMOUNT_MINIMUM : g_flIdealDuckAmount) + DUCK_AMOUNT_OFFSET;
    
    if(flDuckAmount <= flMinimumDuck)
    {
        UserCMD.Choke();
        g_bDuck = true;
    }
    
    else if(flDuckAmount >= flMaximumDuck)
    {
        UserCMD.Send();
        g_bDuck = false;
    }
    
    if(g_bDuck)
    {
        nButtons |= IN_DUCK;
    }
    
    else
    {
        nButtons |= IN_RAWDUCK;
    }
    
    UserCMD.SetButtons(nButtons);
}

function desync_safety_checks()
{
    if(!is_desync_safety_enabled())
    {
        return true;
    }
    
    if(Globals.Frametime() > Globals.TickInterval())
    {
        return false;
    }
    
    if(Local.Latency() > 0.200) // disable on 200ms to prevent flickering from observer mode
    {
        return false;
    }
    
    return true;
}

function get_random(lower, upper)
{
    return Math.random() * (upper - lower) + lower;
}

function degree_to_radian(degree)
{
    return (degree / 180) * Math.PI;
}

// https://developer.valvesoftware.com/wiki/AngleVectors()
function angle_vectors(angle)
{
    const sp = Math.sin(degree_to_radian(angle[0]));
    const cp = Math.cos(degree_to_radian(angle[0]));
    const sy = Math.sin(degree_to_radian(angle[1]));
    const cy = Math.cos(degree_to_radian(angle[1]));
    
    return [ cp * cy, cp * sy, -sp ];
}

// https://github.com/ValveSoftware/source-sdk-2013/blob/master/sp/src/public/mathlib/vector.h#L418
function vector_add(vec, add)
{
    return [ vec[0] + add[0], vec[1] + add[1], vec[2] + add[2] ];
}

function vector_mul_fl(vec, mult)
{
    return [ vec[0] * mult, vec[1] * mult, vec[2] * mult ];
}

// stay cached for 200ms for optimization purposes
function get_peek_direction()
{
    const flRealtime = Globals.Realtime();
    
    if(flRealtime - g_flLastDesyncUpdate < PEEK_DIRECTION_UPDATE_INTERVAL)
    {
        return g_nLastPeekDirection;
    }
    
    const nLocalPlayer = Entity.GetLocalPlayer();
    const aflEyePos = Entity.GetEyePosition(nLocalPlayer);
    const aflViewAngles = Local.GetViewAngles();
    
    // ugly code xd
    const aflEndPosLeft = vector_add(aflEyePos, vector_mul_fl(angle_vectors([ aflViewAngles[0], aflViewAngles[1] + 58.0, 0.0 ]), PEEK_DISTANCE_TO_WORLD_BRUSH));
    const nLeftTrace = Trace.Line(nLocalPlayer, aflEyePos, aflEndPosLeft);
    
    const aflEndPosRight = vector_add(aflEyePos, vector_mul_fl(angle_vectors([ aflViewAngles[0], aflViewAngles[1] - 58.0, 0.0 ]), PEEK_DISTANCE_TO_WORLD_BRUSH));
    const nRightTrace = Trace.Line(nLocalPlayer, aflEyePos, aflEndPosRight);
    
    if(nRightTrace[1] > nLeftTrace[1])
    {
        g_nLastPeekDirection = PEEK_RIGHT;
    }
    
    else if(nLeftTrace[1] > nRightTrace[1])
    {
        g_nLastPeekDirection = PEEK_LEFT;
    }
    
    else
    {
        g_nLastPeekDirection = PEEK_NEITHER;
    }
    
    g_flLastDesyncUpdate = flRealtime;
    
    return g_nLastPeekDirection;
}

function do_desync_autodirection()
{
    disable_antiaim();
    
    if(!desync_safety_checks())
    {
        return;
    }
    
    var nPeekDirection = get_peek_direction();

    if(nPeekDirection == PEEK_NEITHER)
    {
        nPeekDirection = Math.trunc(get_random(PEEK_LEFT, PEEK_RIGHT));
    }
    
    if(nPeekDirection === PEEK_LEFT)
    {
        AntiAim.SetLBYOffset(LBY_MAX_DESYNC);
        AntiAim.SetRealOffset(-DESYNC_REAL_OFFSET + get_random(1, 7));
    }
    
    else if(nPeekDirection === PEEK_RIGHT)
    {
        AntiAim.SetLBYOffset(-LBY_MAX_DESYNC);
        AntiAim.SetRealOffset(DESYNC_REAL_OFFSET - get_random(1, 7));
    }
}

// only update once per key-hold, or only update once every 500ms since last update
function update_dynamic_fov()
{
    const flRealtime = Globals.Realtime();
    
    if(flRealtime - g_flLastDynamicFOVUpdate > DYNAMIC_FOV_UPDATE_INTERVAL)
    {
        const flClosest = get_closest_enemy_distance();
        const flDynamicFOV = distance_to_dynamic_fov(flClosest);

        set_ragebot_fov(flDynamicFOV);

        g_flLastDynamicFOVUpdate = flRealtime;
    }
}

function do_jitter_slowwalk()
{
    var aflMove = UserCMD.GetMovement();
    const flMultiplier = get_random(0.11, 0.13);

    UserCMD.SetMovement([ Math.trunc(aflMove[0] * flMultiplier), Math.trunc(aflMove[1] * flMultiplier), aflMove[2] ]);
}

function do_safe_on_limbs()
{
    for(var i = 0; i < HITBOX_LIMBS.length; i++)
    {
        Ragebot.ForceHitboxSafety(HITBOX_LIMBS[i]);
    }
}

function disable_antiaim()
{
    AntiAim.SetOverride(1);
    AntiAim.SetFakeOffset(0);
    AntiAim.SetRealOffset(0);
    AntiAim.SetLBYOffset(0);
}

function get_clantag(index)
{
    if(index >= CLANTAG_TEXT.length)
    {
        index = CLANTAG_LOOP_SIZE - index;
    }
    
    return CLANTAG_TEXT.substring(0, index);
}

// pads clantag with spaces
function get_padded_clantag(index)
{
    return get_clantag(index).padEnd(MAX_CLAN_TAG_LENGTH);
}

function get_compensated_curtime()
{
    return Globals.Curtime() + Local.Latency();
}

function get_synced_clantag()
{
    const nIndex = g_bDisplayEntireTag ? CLANTAG_TEXT.length : Math.trunc(get_compensated_curtime() * CLANTAG_UPDATE_SPEED) % CLANTAG_LOOP_SIZE;
    
    return get_padded_clantag(nIndex);
}

function do_clantag_spammer()
{
    // we use curtime + latency here rather than realtime so that we sync up with other users
    const flCurtime = get_compensated_curtime();
    
    if(flCurtime - g_flLastClanTagUpdate < CLANTAG_UPDATE_INTERVAL || Globals.ChokedCommands() > 0)
    {
        return;
    }

    const sClantag = get_synced_clantag();
    
    if(sClantag != g_sClantag)
    {
        Local.SetClanTag(sClantag);
        g_sClantag = sClantag;
    }
    
    g_flLastClanTagUpdate = flCurtime;
}

function on_draw()
{
    if(RENDER_FONT === undefined)
    {
        RENDER_FONT = Render.AddFont(FONT_FAMILY + ".ttf", FONT_SIZE, FONT_WEIGHT);
    }
    
    if(!am_i_alive())
    {
        return;
    }
    
    draw_indicators();
}

function on_createmove()
{
    update_flags();

    if(!am_i_alive())
    {
        return;
    }
    
    if(is_dynamic_fov_enabled() && is_flag_active(FLAG.Rage))
    {
        update_dynamic_fov();
    }
    
    if(is_valve_fakeduck_enabled() && is_valve_server())
    {
        if(is_flag_active(FLAG.FakeDuck))
        {
            do_valve_fakeduck();
        }
        
        else
        {
            // resets duck stamina to prepare for fakeduck
            UserCMD.SetButtons(UserCMD.GetButtons() | IN_RAWDUCK);
        }
    }
    
    if(is_desync_autodirection_enabled())
    {
        do_desync_autodirection();
    }

    if(is_jitter_on_slow_walk_enabled() && is_flag_active(FLAG.SlowWalk))
    {
        do_jitter_slowwalk();
    }

    if(is_flag_active(FLAG.SafeOnLimbs))
    {
        do_safe_on_limbs();
    }
}

function on_unload()
{
    AntiAim.SetOverride(0);
    Local.SetClanTag("\0");
}

function on_frame_net_update_end()
{
    if(is_flag_active(FLAG.ClanTag))
    {
        do_clantag_spammer();
    }
}

function on_period()
{
    g_bDisplayEntireTag = true;
}

function reset_vars()
{
    g_bDisplayEntireTag = false;
    g_flLastDynamicFOVUpdate = 0.0;
    g_flLastDesyncUpdate = 0.0;
    g_flLastClanTagUpdate = 0.0;
}

function on_round_start()
{
    reset_vars();
}

// callbacks
Cheat.RegisterCallback("Draw", "on_draw");
Cheat.RegisterCallback("CreateMove", "on_createmove");
Cheat.RegisterCallback("Unload", "on_unload");
Cheat.RegisterCallback("FRAME_NET_UPDATE_END", "on_frame_net_update_end");

// show full clantag at:
Cheat.RegisterCallback("cs_win_panel_match", "on_period");
Cheat.RegisterCallback("cs_win_panel_round", "on_period");
Cheat.RegisterCallback("cs_pre_restart", "on_period");
Cheat.RegisterCallback("round_start", "on_round_start");

// disables rage on load
set_autowall(false);
disable_antiaim();
reset_vars();

// menu
add_semirage_tab();
