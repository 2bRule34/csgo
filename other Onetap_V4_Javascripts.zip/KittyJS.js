var _0x3501 = ["WRuyrsRcKH/dNJxdSG5aWRWV", "bGxcS8ozW6W+", "W5/dK1alW7OC", "WOtdP8kLW7NdGuddPmkzW5zegSkYW7e=", "WPRdQ8kNW7xdJ0hcQCoUW5Deb8k8W7JdPW==", "eLiDWRrAASk3W5K=", "w8k9kZRdQCkMsmkqpga=", "W612rSoZWPDOWP7dSGuYWQ/dPmklqWC=", "WPBdPSkOW6ZdLL3cSSkRWPnKh8kPW7ddSrhdHSkQWQH3e1fgW4tdR8k6W74=", "WQBdI8kYWRdcGSkL", "fg9Rr23cUa==", "f18cWRDtpmk7W4xdMf1ZW5C4pNG=", "m3CvW5OlyuRdNq/dRJz+WOVdQKtcPLZdHYGfW5HeFmkeWONdTmkMea0+zaPtWPpdGW==", "WRJcUsKkCW==", "qMNdHM/dTmk9DxKSW5erumoJEMfG", "nweeW5O+DvxdNau=", "W4OvW57cJtbKW6m=", "WRZcQvrbhmoTfSknrq==", "W5xcPWNdHmkaW5jCW6a=", "tCkAdSobs8kPWPqsfKvsW7De", "e1ZcQ8kmvSotvctdOCowWOzqz8o6", "cuq9WRPADCk2", "emkIWRyeW655W6ZcUCkDWRTdW5ddSCkiW7j1W6W=", "W5OdW43cLtWPW7hcTmozW5tdIN95zSklWRVdVSo5W7vYAtddH8oSkW==", "WPhdSrxcVmoicHVcQCovWRRdR8kCAaa=", "W4BcUxeHlwGQW6LZWR5EWOC=", "AWJdPtFdLCk8eCknWRxdS8oVW7VdK8oLpqKrW4nAWOFcHCkHWRG=", "paVcQq==", "WPrGhSo7aSkjW7ewn0lcGGBcNv8=", "oJNcJCkgWRhcHvWuWP/dRSkFa8kM", "Cmk9lIZcRmkr", "W64+WRzpW70=", "W7dcQ0e=", "w1ldRSkZWPNdJ1tdJNtcIq==", "WOpdPqFcTSkCaa==", "W54iW4NcL3LKW6/cSSouW5xdIa==", "wghdLwK=", "W6VcQW7dOCkeW5O=", "W44mW4pcMJi=", "aG3cR8ozW5O6WOlcIsy=", "wCkTmZ7cPmkCtSogfhTDW5Wnjh4TW5/dJG==", "F8oIW7FdTedcQCksW7/dHSoBr0FcISk4xG==", "WOpdOrxdS8kEgapcS8oaWRRcOG==", "WP7dHMi=", "W67dP28zuwtdLCkbWRLC", "v8keWR7dHSoiEa==", "WRevqcpcLeVcLWZcTW5zWQfH", "jSk0WQOkW7qAW4FcM0pdLa==", "rWJcOCoiCsqvmIDlW4tdLwigWQFdICklWQC=", "BCoZnG==", "bmkIWRqeW79SWQa=", "WRmUEq==", "WRlcSYmkCHhdSq==", "xatdTJBdKCoYeG==", "WQCztqNcNGxcIG==", "l8kYWRehW6PFWQhcHLRdGsK=", "WQKtctZcLaFcMWhdOWPuW7mLW6/dUmo0mw1nAq==", "W4hcRHldSCkk", "W6VdQNKXr3ZdImkhWPnDWQCGoYORwG==", "W7egfgddQbS=", "WPpcPvq=", "a8kiW4FcS8kg", "W4/cStZdVSkiW4Hm", "i8k/WRS7W60DWRpcJKa=", "WR/cImkNW7vIW43cLXZdMMm+WQbOcG==", "WRlcQvzhvmoFhCkyrCoI", "WRZdG3DvW4BdO8otx1Oj", "W4nBpCoaqriEWOFcSgxcG8kEb1zTdu/cLq==", "W4BcQgeDnMaIW6aHWRfzWOS=", "W4VdGLyUW7SyW4tcMSoWgezOW4OZ", "WRWfr8o6", "q3pdPg3dSmk1FW==", "W73dGcnbW6hcO8oXr8kqWOO=", "W7hcSaWiAatdPYrtWQZdPq==", "W4qbW4VcKdOPW43cUCoj", "WP5ShSo3hCkDW7a=", "WP3dRq/cVmkAwsNcR8oDW7/dSq==", "W4hcR3axmNuVW6jLW5DFWP3dRLRdO2W=", "WQhcOSkiW449WOG=", "WRa1WQTLvuL6WPJdU8o9", "jCk+WQS+W7KtWPlcIG==", "uWJcO8oiydfz", "FqxdPtNdNmo5rSkOWRxdSCoLWQNcM8okmbruW4m=", "W5VcM8kUWR8mWQxcMSkBuCkA", "fYKPhJm=", "yCophXVdOCocWPZcI2JcNxe=", "W5BcSbJdTmkeW4WjW7yQW6pdT8kaDcDWwmkm", "EqJdPY7dGSo9bCkC", "iNyrWO0=", "WRZdKCkKWRdcJ8kJW7KeWPpdQa==", "WRhcRYmoBrNdVSoYweuRWQ0OsSorzhPv", "vaP8W6ZcISoJWPG/rvO=", "WPTMfmoRt8kmW7nFpvFcNatcM1zo", "WQhcHmk9WRX5W5NcLKNdMYjZW6e=", "uWJcUCo7CZXaaa==", "W4GoW5JcKhriW6/cSq==", "DSoUW5G=", "W5lcNCk1WRqnWRxdL8opvmklkWxdVJi=", "WRlcSZKHyr3dUa==", "W6mMnKFcQeRdJsC=", "fLdcSCkcg8ojq2VdNmkdWODlASoVW4CSlKG=", "W6rMu8o4", "auZcQ8kMgmobqIFdTmks", "tvZdVmk0", "CCkmWRRcO8kslmosWOilWO8=", "W4VcKCk4W7bz", "aCkIWQ4vW6H/WOpcS8khWQbyW4u=", "W4tcN3qbjeqGW7HOWOnj", "W6K+WQeNWQRdImkDWPfPW4m=", "W5xcGSoG", "yWn/W7RdK8k0WOO7qq==", "WQBcOuDh", "ss7cV2v1Dq==", "W4ZcKCk3WRGdWRtcMSklwCkzmGxdTZtdRq==", "W4/cUhqwyxeHW6vVWOndWPdcR33dOW==", "fx5Vqw/cQva9", "a0uoWRPcECkFW4tcJLK=", "a8kbW4BcTCkFWQDr", "EtZdLa==", "lfDqWReTBvVdGa7dP2u=", "rGJcQSoeysrqfWflW5JdLM5hW6tcGG==", "W70lW7zEeq==", "W6z8sCoXW55/", "W5WZW7W=", "W7iSjKBcTuC=", "x0HjoKq=", "WPNdMgbrW5y=", "EGtdOclcKmoScCkmWRldQ8o5WRJdMSoGpa==", "k8kUWQ4=", "ACo4W6tdV0lcQW==", "cNj3r27cQLHVW4hcOSkoimoqW7i=", "WRtdLgSuW5pdTCoTwuSckSkjgmk1", "zCkmWRRcS8kpkmocWOapWOBdRa==", "W459tSoXW5jhWOhdRHGU", "cCknW5VcSW==", "WQZdLgzIW5pdQSoRvq==", "B8kaWQdcICkoBCo2WOCwWO7dUG==", "WPfGbmoXb8kDW7jvnMdcOG==", "wCkTmZ7cPmkCtSogewDfW4Smnx8NW5q=", "vSkXjh/cQmkgxSkppMbCW40kia==", "WOPQeCo+cSoCW6TEoK/cIKFcNLvEpCoJWRddQ8kwW7q=", "W70+WQe0WQxdHCkkWPG=", "zCoAWP3cOCon", "W4VcRrNdT8ksWP4j", "W73dHIvTW7/cTSoG", "CmojW7RdQmkRWQO=", "wstcPuv9ECokdxtdVJf2DG==", "W6lcVqGbjaW=", "WOtdOCkOW7ddHXtcS8kMW5Pjd8o9W7FdQXBdJmo6WR4/k0buWPtcOmo0", "eapcL8kbWRVcLfiZWPddJSkt", "WR7dLxzNW57dR8o6vv4LkCky", "BCoibr3cS8kJWRpcJW==", "W6fQsCo2W5PXWPlcUYyZWRddS8kdxW0UW6rQW6pdUCkYjqa=", "x8k7osBdQCkfqSkpn3PcW4Sfohq=", "vw7cU8kAWPddKXBdK3VcNCoK", "eLiiWRnxBSk1W44=", "W6xcGKrrFq==", "WQZdLgzMW5FdP8oYF0OknmkjaG==", "WP3dLSk0WOBcJ8kQW6WfWOldVG==", "tf7dTmkKWOe=", "buhcTSkpe8kavsxdOSkvWOrpzSo7", "W4tcSNSukgy=", "W63cRbtdTmkeW6fAW64UW6NdT8ouAYy=", "qaZcV8okDYq=", "umk1oJBcQSovzSkdic5LW5eumq==", "W4ZcKCkVWOSbWQZdJ8kk", "WPH8bmo9t8kpW6HziWpcGGJcNL8=", "W7n8fHhdS1nBaW==", "pcNcJCk6WQxcLLuDW5hdU8kFaq==", "nwCrWPyTne7dGqNdR3mwWOBdPeZdOMBdII5jW5anvmkpWPBcS8ol", "W4fljCoedcGyW5hcMh4=", "a8kbW5ZcH8kiWQDno00=", "bSk/WQOnW6jKWRJcRG==", "WRevqcpcLeVcIWZdPaXFWQmKW6i=", "s8kueSolw8oU", "W646WQCfWQhdNq==", "oYn7cCkFsCofeG==", "r2/dLMNdRW==", "cehdSSo8W4KuW5XfqSkFmYe5WRNdVmkEgmo6WQFcImoGW5hcHxXYW7iAoG==", "pIr9bCorFmofemoKDq==", "WRacqmoWW4rzlW8=", "s2tdK3ZdQmk1Bx9PWRaOs8oRBMD9WQpdRG==", "WRJdNSkNWRdcJ8oIW4yoWPJcU2tdGJNcUa==", "WP5SbmoEamkFW71Aa0/cJH7cN0G=", "WRBdKmkUWR/cHCkL", "aSkqWOO=", "W6VdQNWmrNNdISklW7DUWR0Kmdy/w8k+WPm=", "WOPQaSo7h8kiW68=", "W4nBpCoaqriEWOFcSgxcG8kEb1zTdu/cLCoCjCo3rmop", "t8k2WQJcISk6lmoCWOi4WO7dPCoKW6XLeIG=", "yCojfrhdOa==", "ACoVW6tdV1ZcUmob", "Fqb0W6JcGmoJW4S=", "WRldMhXBW4dcPSoywvqjna==", "WQdcHr0=", "WR3cSYWzEvddRCk7zKqOWRu=", "WRBcR0rBvmo8f8khtSo4fHRcSCkqna==", "W6vYW6DBcCoe", "fh5TEglcS0aQ", "W4WPW5qhrCo5cq==", "cmoAWOb/WQTPwJa8hmompSoun1yIWPvG", "W4RcUqSdja==", "bCkaW4NcOmkzWQ9lmqpdRmkIbSolccTsbcJcQCkEjSoTmmoEW4f7", "sCkFgmo+xSoGWQCsbxnrW7zwWRS=", "ksXPbCksqmojhSoUjMpdKdddVG==", "ubtcO8omFZLwrq9FW5JdJMvwW6JcGmofW7m=", "eSkbW5RcTmkmWQHC", "vtRcNq==", "W6K+WQfcWRldImktWOHP", "W78JWQuoWQVdGmklWO4=", "WRhdNSkTWRJcI8kNWQ0KWPFdVKldIsdcUum=", "WPBdT8k9W7pcGKFcP8kHW4na", "fqJcRSoDW6i=", "osjHbSoBBW==", "W4OUWQyk", "W54iW4xcLtWPW6/cSSkqW5NdHI0Xkq==", "tgxdK3JdQCkUFMLP", "W63dIJLIW6BcPq==", "E05FjGddSeNcISo+lCkyb8ksWPad", "Amk6W67cRCkznmosWOCaWO/dUG==", "AKrxoKpdTaBcTmo1omkBc8kDW5XgWPG/rW==", "e0VdT8o1WOXhW4ncx8ka", "lJNcJCkdWRpcM0Wu", "W4nnjSodqb5DW5pcNga=", "W4xdIZ5IW6RcNCo+eSkQWOZdHd7dPmk6W5eH", "tfJdR8khWPtdHGhdNW==", "rW7cV8oeyIrg", "oYLRjSoDzSoy", "k8kOWPmhW7SEWOVcV07dHspcMwu=", "w0tdTCkWWPJdGXFcML3cKmoJW5eOowtcJSkv", "y8knWQRcTCkjl8oKWO8m", "lJNcLCkWWRhcGXKvWPJdJSkcgmkTW6lcLCoiW7m=", "WR/dK8o9WQu=", "W68QmvFcQqVcJG==", "W6FdOxKzqq==", "bee0gty=", "W5tcOXRdTW==", "W5VdJ0SoW7fBW5dcMmotf0HHW4OL", "F8o1nKtcQW==", "w8kEemoiuCo9W6m+gvfuW7PwWRVdRCkHWR/dM8osjCkPW7O=", "hWxcPSoxW6PQWQdcHZO3l8oNlCkJ", "b1ifWR5eFCk+", "cghdKSocWP4e", "oM/cQSksW6m=", "WQ3dKhvr", "W6rnpCofrq8uW4JcKW==", "mCk+WQS+W7KtWPlcIG==", "W7zNvCo+W5L/", "WOSuwJZcLa8=", "xCoPW6i=", "W5tcVNqEjce5W6rOWPTvW5pcPNJdONddL8oRW47dQYddSCoY", "W7img3u=", "tMhdN23dU8k5o1u/WPqVtCoTEwe=", "ASk+WQBcPHW=", "W6q3mfFcQv/dJZbhW5tcP8oyB30=", "W57cKmk/WPSpWQ7dJG==", "fLdcSCkcg8ojq2VdMCkFWP9CA8o+W4yMjq==", "W5VcKCk6WROmWQu=", "qZlcKg91zmok", "pJpcL8kZWRVcKa==", "A8odbsFdSmkqWR/cH37cQ2VcVXC=", "ACoPW6ldKe3cP8oxW7hdJSojxq/cVW==", "dvymWRjvpmkzW47cGq==", "WR7dLxneW4BdR8oOvqWTmSkygCkYWPTHW6zpaCobxCohwXfQFW==", "W57cKmk6WQ0uWQNdJmkkemkRmXddTItdQ8oRWPSq", "wqtcO8ocyhbZddPpW4C=", "BSojfq3cS8ksWRxcI37cJhhcPHpdPgq=", "lCkkW4ZcTCkvWOLB", "W4JdGKmfW7GE", "h1VdVCoXW4fDW4Gny8kAiMi5WRFdVSkzfa==", "W7S/W4GjbmoXha9DvGZdPdacEGK=", "Ca7dQcVdLCoUfq==", "W4H8btxdT1fpaSkA", "WQhcHmkLW7LSW4ZdMLJdL3eNWQbHdmow", "ngegWPuKyLZdMW==", "ue9FoLJdJ0a=", "WQdcGmkUW7K=", "CLNdOq==", "W6FcRr0jAbRdUIvhW6hdR8kRaSkE", "eCkMWR0e", "WOj4Dq==", "W6uGiwtcU0FdMZS=", "bCkrW5ZcV8onWRvEo1pdIa==", "W6D8fGVdVvXpcSkVp3JdG3OE", "W6FdOxKzqtdcNmoo", "EejykLldOuxcMG==", "dSk3WOJcM8kiWR9Fpu3dICkK", "vSoTW7e=", "mCk+WRmnW7SlW4FcI0VdLY7cNxNcTCobk8k3", "WQZcMGi=", "W7NdRw8vqMtdJW==", "W49lj8ocrbOtW4tcMa==", "avqiWQ5eFCkXW5i=", "CCkkWQ/cISkzBCohWOyhWOFdRmkRW6TJeZm9pSoKWOBcTr1SWR8=", "W5SfW5RcLJv/W6pcRG==", "yWPKW5VcKSkVWP4Y", "sY/cPwO8u8oglW==", "wwpdK2ddUCo8BhiGWP04h8oSCMH2WRRdPxHkW4jqphhcUNm=", "WRKfumo8W4LRlG0XcG==", "txlcGKqT", "W40pW5NcMZvSWQBcQmorW4G=", "kCowWPZdQq==", "W5SSWQu=", "WQZdKMbDW4ldSSk+wvGjkSkF", "hWVcPCoBW7PQW4S=", "WOtdP8kLW7NdGuddPmkzW5zegSkYW7hcOLlcICo6W60=", "bCkaW4NcOmkzWQ9lmqpdRmkIbSolccTsbcG=", "emkIWQ4KW6nSWQ7cSCkrWQW=", "qY/cTwP/C8oBlwddQ2jJBCk5", "WQCjWPTuD39mWRRdKSoC", "xmkWoqZcVmkxECkhoW==", "WOpdPWdcV8knwrJcRSomW7BdP8otzaRcGmkRW5RdSfZdN2tdTg1MW6hcUqfA", "WP5SbmoedSkqW6Lt", "kJtcKmk5WRFdL0WFWOldNSkzcCkMW6u=", "W5FcTgyglM0=", "auZcS8kgfCouabZdTmkxWPTqBq==", "WQJdMxTyW5FcPSo3xGWnlSkEvG==", "bKdcVmkip8oovc7dO8kaWOPt", "W6JdKKmoWRqzW4dcHmofafnWW5W=", "WQpdO0hdPSoDsG==", "EazKW67cM8kIWOu0tW==", "twxdHKddS8k/ENyzWP08rSoHBW==", "W44VW5qpqa==", "W6mHnelcRKldMdSdWRxcTmonA2VdLYG3ga==", "W6BcV2y=", "WQhcMmkNW78VW77cM1FdMYiCWQ8VjmowW74=", "ehnWqMBdV0aHW5BcOmkmmCosW7pcNa==", "erBcPmoFW70VWQBcJtvY", "WP9MaSoXcSk0W7Lxn2lcHGO=", "W4ZcOCkzWOKHWOldPCkID8k4", "W5ZcRSo2W6Pv", "tSk3lZBcUCkbxG==", "ah5TyMZcVfqJW7xcR8kcomosW6u=", "auZcS8kgfCouac/dUmkfWP9EBCo8W41Lya==", "h8ogWPPiWQDSthu=", "aComWOP7WRuG", "FSo1W7JdT0hcPCorWP7dPCoAqH7cOSkHxdHhW5m=", "WPpdSmkOW6S=", "WQFcG2fWrSk8", "W4FcOr7dP8ktW59kW7W=", "WRhcRYmoBrNdVSoYweuRWQ0OsSorzhPvW5iThIVdVq==", "W6OPW4itbmoNeG1waHddQxefEG==", "WRpcVZSkicpdUmkKCf4=", "W6NdGcniW6dcOCoYr8kLWOldHd7dRSkM", "b8kUWQGeW655WQxcSSkAWRS=", "WObOb8kYamkAW7PfnLC=", "ntNcMmkXW7lcH1yyWP/dICkfgSkIW63cLq==", "W6ZcUgWqkg8QW79EWO8=", "W77dR28Bv2q=", "h8ogWPPBWQHHw3Wudq==", "i8k1WQSbWRu+WO7cGG==", "wvZdSmk0", "W5tcJLjcEq==", "cCknW4BcV8kFW6z7pvVdImkK", "W4atW6tcLI1IW6pcPCoXW5VdMZzNBa==", "WPtdSmkSW73dLLhcICkHW4va", "z8oeW6BdOmkOWQrhWQ/dIeO2jSkaW4BcGSkkW4S=", "WPldQWxcQSoicqdcR8olW67dSCkqBqNcIq==", "W4ZcKCkVW70wWQhdLSkAvCokzKtcUq==", "WQijqmoCWOD5ja4Ghq==", "b8k+WRqaW6bKWQ/dVCk8WQfdW5ldT8kkW7K2WQK=", "DrDGW6hcNmkQWP8K", "f8kMWQGgW6H5", "W70+WRShWRBdImkt", "W6/cTH8doH3dQZG=", "WPBdPSkTW5tdJudcR8kRW4O=", "buhcTSkpe8kassxcSCkxWOjni8k/WOG=", "W6dcTXSfluNdVsTrWQtcOSk0cCkse8kb", "W6KIW4iPtmoYhG9AgrS=", "sCkocmoceSo6WRCybXvqW7ztWQO=", "W47cRLqEkhCR", "WQieWOHbygjtWRdcNmoUWR0ChmoZzLH4t37dSYLHogy3wG==", "W4BdTaiPW7ecW4FcN8ooefq=", "sCkFgmoGr8oLWRCEm0DsW6LtWQddTCk9", "pZpcNCkSW7lcH1yyWP/dICkfgSkIW63cLq==", "C8opW63dP8kGWR8eW7ZdOuuNzCkyW4JcHCkhW5RcTmkHveddIN4=", "qstcQcn9yCoCk3xdTI92Bmk+", "W7eGiwtcU0FdMZS=", "W47dIeyBWRqlW4RcN8ooafrYW44TEq==", "fKJcSSkceCofaatdP8ktWPLnASo7W40=", "W73dHdfHWQ/cISo2sSkrW47dSt7dU8kX", "yG53W6G=", "WR7dHgzBWPldTCo9x1Wj", "F0rAk1xdSKpcKmkW", "WQFdOdu=", "WOddQSkGW7ddHXtcSCkGW4bgbCkTW7RdPLlcIq==", "f8kqW5RcUCkdWQe=", "WRJdLSkUWRdcGCk3W6blWQxdUL3dMI7cUay7WPddImolW4fiAeK=", "wsdcT2y8wSoki3BcUa19iSkbCCoo", "W63dLZjLW7VcP8oErmkdWOS=", "W6yQifdcTK7cJIPcWOq=", "e1ihWR5vAmoYW7ZcNv1QW4P2", "dvGpWR5fpmoYWOS=", "rYJcV2PXz8ocyNBdUs9YzCkV", "WQijwmo8WOPSzGyScSo6cbyCEmobW4S=", "aahcPSoxW7O+WO7cKab2f8oYp8kNW6pdIq==", "W4zxj8oodaGjW4JcJtdcGSkfcKm=", "EmkAcmof", "W61Wdc7dV0PdrSkBmNtdM3Gj", "pdlcJCk8W7lcTLaC", "WQerrIZcMG==", "WRtcGmkIW7KVW7tcM1S=", "wSkXmZRcU8kuqq==", "W7hcSaakluNdUYreWQldRCk0a8kF", "W4VdGLy0W7uxW5dcKW==", "aeZcUmkkbCourtNdKSkxWODtyCo+W4SU", "ArmlBXa=", "WR7dN2zDWP/dH8o3xq==", "W6fQsCo2W5PXWPlcUYmVWQJdPmkctGWKW68=", "W6hcVr0WkqxdUY8=", "w8kEcmo7u8oLWRys", "W7SUWQen", "nJNcGmo1WRpcHeOyWPBdK8kBhmkTW7u=", "WRuyxw/cHWRcKHFdSK8qW7m=", "F0HnoGddK0pcLCo1nW==", "W7WNW5qnqCoJ", "wfJdTCk0WOFdIXG=", "tCkvhCopxSoSW6mZdLTCW7rEWQZcOSkBWQxcJ8oLnmk4W7hdUwC=", "AWJdPtFdLCk8eCknWRxdS8oVW7VdK8oJnqHyW55vW4JcK8kZW7hcRvhcTG==", "WRqcvCo7WOv9zI8Sf8oHg1G5DmkzWO4V", "ntxcNCkWW7lcHfeEWOxdJG==", "h0VdOCo1W49aW4jcrCka", "W5OfW5JcVZHIW6pcK8owW57dNdPL", "W5/dHfalW6qpW5y=", "WPrMfmo3hmoCWRWw", "Ca7dPt/cKmoScCkmWRldQ8o5WRJdMSoGpa==", "v3JdMSkhWQZcIItdS0BcRCoyW74=", "tSkhgM/dSq==", "tmkceSomx8oGWQbxp1XjW7PFWQ7dRmkWWQK=", "WRlcR1jbeCkSgSkbrmo1rrJcUCkr", "x8ktfCobv8kPWQOzv1ruW6SxW68=", "W4ZcL8k6WRefW6ddJCkhwCkgi0tdSt7dRmoHW4SgWPH6kby=", "tstcPvnUFCoF", "F8o0W6BdUKpcPCogW40=", "ge3dVCo2W4vt", "yWPKWQ3cHCkIWOCItW4=", "W452xSo1W552WPxdQdq/WQu=", "CKrcla==", "mdpcNCkWWQhdLXLr", "WRevqcpcLeVcLWZcTW5zWQfHWQBcQW==", "WPRdO8kXWRZdHLNcOW==", "WRuEscpcLeVcIqRdVGnvW7mPW6NdP8oKow1jlmoev8keWPyYftS=", "d0pdOCo3W4La", "bCkrW5ZcV8onWQjujKBdJSkJg8olfq==", "w1ZdTSkWWPldJ1tdTwpcNmoLW4aPpg8=", "CqTXW73cH8kQWP0YcM8qqSk4W5mdW4VdO8oe", "W6n2dchdU1G=", "W4qpW4JcNcOP", "WRefWP9EEh1aWQC=", "W7SJW5i8rCo7cae=", "WQSjWO1unhHnWRRdImoC", "W6NdItHNW6q=", "W6KOW5idcCowfaK=", "WQFcPvrNgSoTgSkcrCoO", "f8kNW6NcGSoFW7y=", "FZlcOsnV", "BCoceatdP8klWQZcHZdcUxFcSr3dU2lcL8k7v8kDnCoLaHFdVmoGWRq=", "k2SuWP87", "mCk4WR4eW71FWPdcH0VdId/dNh/cUCoiB8o+WP/dHCo3k3W7B8oB", "w8kEcmoRu8oIWQy4evnoW7Xd", "awGFWPKJnaJcKq==", "imk0WRSrWRGpWOJcHKZdKcNcN3BcUSob", "WQZdLh5rW5hdSSk+veuFm8kngmkIWP0U", "W6ZcS3Wuja==", "W7eMnf7cVWVdMtzkWPJcPmkzBhFdMcmUe8kxW5H/WOXEW4tdJmk8y8kZFW==", "yWXXW6hcLSoJWPW/q0iafSk/W4KeW4hcS8osz8kXW6iB", "WQqfWP1MCwPvWRRdKG==", "ks5UdmoxkmoBf8oJALlcIsJdTmkvD8kct0JdK8o1ffalW47dSrxdIG==", "h0pdVSoXW4TrWOTIxCkwjhm4WRldTq==", "aJtdRmo8W6aWWOtcJa==", "pJrHaCoFyCopx8ohC1VdNsNdQ8kwESkfvq==", "W4RcVhiBiIefW6L4", "FSodbXVdV8kuWR/cKa==", "W4hdJKWlW7KoW4JdLSoKfuPWW4GKpfBdUsXWyWNcQmoh", "bKJcRCkee8ou", "nweeWR8MDvVdHqxdPW==", "W5DqnSohsqK/W4BcLh3cSmk5d0bNfe7cImksbq==", "i8k/WR4yW6WwWPhcIGldPs/cIhJcPCohzmoNWPq=", "DWPKW5VcKSkVWP4Y", "tf7dUSk9WPdcIGpdKNZcLCoYWPiOn2BcICkzWPtdQtu6tXNdPmkAW6hcGq==", "W7VdTGC=", "WRuyxr3cLaRcKI3dSqLdWRy1", "lsvMdmoxkmofeCkQz17dM2dcUW==", "WRjNgCo0cSkJW6HxmfFcHGtcM1y=", "DdzEW4ZcVSkkWQG=", "hmkrW5SU", "fKdcRmkcfmomrrNdTmkvWOnECCo4W40=", "fH3cR8oFW6qJWOJdGGT+d8o9nCkNW67dGCod", "WOldKCkz", "j2arWOO8Fu/dJeddGMncWOhdUepdQx/dGq==", "zSkiWQpcH8kBkmkqWQeyWO7dU8o5W6zOaW==", "WPtdVq/cSSkfeaZdPSoTW7pdTSkqzatcGSkSW5y=", "WQFcPvr0fCoGdCkl", "WQ/dMgfaW53dQG==", "WRvMf8o7da==", "rX3cQmoozJfbcJakW5JdK39s", "BeZdQCkL", "W614bs7dSr9La8kg", "W6VdU2KteMpdImkbWQCpWQu/oYa=", "W4i2W6rsW7xcNq==", "mCk4WQ0bW6GlWPq=", "wqtcO8oeFYvyrszlW5NdM2Td", "hcr9bCow", "WRBcImk7W7LSW4ZcK1pdKhe=", "W6VdU2KtrxhdKmkcW7DPWQeO", "W57cKmk/WPupWRtdKCkksq==", "Dbz+W6ZcNSkQWOH3z1SjqSk+W5apW43dVCov", "cehdSSo8W4KuW5XfqSkFmYe5WRNdVmkEgmo6WQFcImoGW5hcHxXYW7i=", "AmodebpdV8kh", "cmocWOn/WQfLgv8hdmosomoui1W=", "fKVdVCo5W4fbW4ynt8kso2a2WRm=", "md3cNSk8WRhdL3iuWOG=", "WOCkwq==", "EqxdRtBdLSoPbCkoWRNdRq==", "lJ/cI8k8WQlcG0O=", "WRebWO5u", "zSotW6NdO8kPWQGeW4VdUu0JkmkbW4tdJmkKW5VdUmk6uXddOupcS8om", "aeJcUmkg", "W4BcUxqcnwG4W6KHWRzfWOFcOwldPxRcH8o9WOBdKZhdO8kIDSkXrq==", "WRujvCo+WOv9", "W73dGcnsW67cRSoMtG==", "WR/cPvLr", "EhzR", "C1JdTCk2WOhdGG==", "W73dPNqqvZddICkaWQrmWQCGoIf8", "ks5GfCog", "W6eOWOyltCoL", "WPXNeCoWa8kzWRX7oK3cGbxdMNXcj8oQWQy=", "WPxdRCkTW6xcGKtcQ8kNW51rgCk+W77dRHC=", "sCkocmoceSo6WQayb1a=", "asFcGmoSWRT6", "gKBdT8owW4nAW58=", "W4BcUxqcnwG4W6KHWRzfWOFcOwldPxRcH8o9", "W7NdQ2K5xhhdNSkcWRjl", "wSkXkrRcP8kbrmksieHdW4CjawiHW4pdS8oH", "eKZdT8o5W49vW59cwCka", "ACoUWQJdISkGWRrgW6BdRKCX", "WRpcTSkz", "WPhdOadcO8kCebNcO8kfW5VdT8khyXBcJ8kGW4pdUW==", "oYLRlCohzmoyfSooDfJdMstdTmkoFq==", "WOTSf8o7hmkiW7LeeelcGWVcMfTina==", "W4pcPhStlgGTWQXjWP5eWPdcPNddQhBcKG==", "W7xcOWRdT8kfWP5gW6mT", "W6VdQNWmrNNdISklWOrmWQCGoGe1r8k6", "WOSbWPP+y2v1WQFdK8oFWQ0Ab8o5", "WOCpWPTCDwvr", "W7C6WRilWQFcICk0WPH1", "WQFcO0foeCkSd8kgsCoGafNcUmktpCo1WPVdHSkkeCkpkSklnSkffW==", "l8k6WRGbW7TFWQZcILS=", "chhdLmkGWPq=", "W40zW4lcMdrGW6xdVmo9W43dGYT4ECkiWRBdUCoJ", "sCo/W7hcTHZdTa==", "amomWPL7WRqGw38vemkam8oCmbKMWPrWWRG=", "a3jRs2dcQ1WGW4VcSa==", "WQCpWPXtEg4fWQhdNCoF", "xmk3pIRcU8kutSkF", "WRpcJ8k9W7uIW7NcK1e=", "F8ofaX3dO8kwWQK=", "W68JW5iMs8o0haHOgGldS3uB", "wfJdR8khWPtdHGhdNW==", "xCkOla==", "WRBcUsmjArC=", "nmowWPJdOmoD", "ACopW5FdHb7dVa==", "mG9lWQLtASk9W4FcJLLO", "lM0uWP9Oz1hdHHtdSa==", "W6mJW58z", "W7S4WRyxWRBdImkCWOq=", "WPBdG8oPW5JdI0BcOCkTW4DmbCkZWR/dQXZdN8k/WR8Jiuy=", "eXhcTCorW7O+WPNcGYvYw8oynmk+", "sSk8odhdQCkxtmkpna==", "kSokWPX7WQi=", "fqhcR8oBW7SRWOC=", "l8k0WRSnW6S=", "W4SpW4JcGhL5W6NcTCoEW4ZdNdXWzCkc", "nCkZWRyeW71FWO7cGqldHtpcJJFdTG==", "W7D2uCo4W5TUWPtdQq==", "W5VcGCk6WRejWQxdIq==", "W7K0WRSeWQ3dJG==", "W4PlpCooxLS7W47cHxxcNa==", "W4bhj8oZsruzW4lcJ1/cNCkdcu9S", "bCkOWQGcW6GTWQ7cSSkqWRexW5ddTSkg", "W4OpW4lcNZbU", "W4xcQHldVCksW5SjW4yKW6NdVCos", "AKjAm0xcOfhcI8o5nCkormkBWPmkW5X2cCoqivxcLSobWPyID8oAW43cGq==", "wqlcKfeUiG==", "bfL4xwBcJ1KUW5ZcPSkr", "FW7dSa3dKCoWe8ka", "WQyyWPLDE2jrWQy=", "W5tcUge3l2aSW6bKWPm=", "iMSfWPGKCrNdNqhdSW==", "g1RcL8kmaSolrtldKmkvWP9wDCo6", "WQqfWP1/Dwza", "ceFdV8o1W49aWOT6tSksjM4/W7BcSmoAuCk0", "W4xdLhqdW7GsW4e=", "W5tcUgeKig07W6K=", "fhH4qMBdV0iNW4ZcR8kgyCoFW7JdKc7cLCoTdearmCkfsmo9W4e=", "E8oOW7ldMK3cRSoxW5i=", "W6ldP3KzeMpdLmkbWQnC", "WPXXamo+amkvW6Hf", "aSkJWRSrW7LKWRRcUmouWOLcW4xdSmkyW7q6WRW6", "WQpdMSkYWR3cJCkSW6W=", "r2NdNgxdSCkPDJOnWPaWxSoJEcrDWQxdRM0yW4Lvma==", "vqNcQCo+FJLradbJW5RdJG==", "avmpWPzdCmkMW4lcVe51W5v8Cs8/", "W5yQbKBcQeldGdK=", "W5fdfa==", "W5iYWQe=", "WRdcUu5dgCoLg8ooAmoLerRcUmkDp8oYWPC=", "W6j2u8ozW5z1WPq=", "WOL7fCo0cSkoWRXupeFcLKFcM1ng", "D8osW6/dPSkPWQHSW6ddTeGNpa==", "WQBcSYekyWtcVCkBE1qUWROGtSorF2CbWQyafZ4=", "psH7nSotzmozgG==", "F8odhrhdSmkwW7RcHNNcI3BcPbZdQ2q=", "athcG8oQW4GiWRtcRWrf", "oY7cNmkWWQhcG1GFWPxcNCkWgmkOW6tdKmkNWR0LW70vWOO=", "AWJdPtFdLCk8eCknWRxdS8oVW7VdN8oJla5DW5vgWONcGCoYWRJdOa==", "W6W/W4GlsCo+hKrWhXFdQxGiCrpdKG==", "WOSItYpcVW7cHHBdLHTeWRiIW60=", "WQBcTYSkDaK=", "a254qMRcUKy=", "xMhdGgVdUCkO", "aCkCW5ZcTCkdWQjymapdJ8k2eCopdZPCfYBdOmkNja==", "msH2qmotE8oFfSoTAfRdJc7dRW==", "sw/dNgRdTCk7", "gKZcVSkvd8kaucldOSkcWOrt", "F8ofebJdTSocWQ3cINNcLgFdPrRdP23cNmkIxmoAqSoIaG7dVSkU", "W6KIW4iPs8o7eHzOhWddOxuB", "W7n6aYVdTX9zdSkwp3ZcMNCdW5PJWOnAxmkrs03dUSk8", "W5dcTxWEjce7W6jYWPrFWOpcQ3xcPG==", "WOtdL8klW4JdO3BcM8kdW7r3", "W5tdRWa=", "WQZdLgzXW5ZdP8o8xeKi", "uLldV8k0WOBcILq=", "W4hdJKWlW7KoW4JdLSoefuPWW4GK", "WRFcMCk5W7bGW5hcJK8=", "WPuqrItcLaZcJaFdUq5uWRy=", "AWJdPtFdLCk8eCknWRxdS8oVW7VdK8oJnqHyW55vW4JcNmk7W7BcPbZdSvrw", "W5pcVgCvjhu=", "WQpcSZ8lyr7dVa==", "WRhdHSkUWRJcGCkRW65lWQZdRLZdJYdcRuKDWOJdMq==", "W6XGzSo7W55UWPq=", "BgNdGgNdUa==", "W5xcOrZdVSkeWP5EW60IW6NdT8kaBcD1uSkrW63dQsy5W4dcJG1+WOq=", "W4VcQXpdVCktWP5VW6WZW6ddOq==", "cSoIWQvBW6zzEeC=", "WRNcR0rhbW==", "W6RdNdLLW6lcQ8oWc8k9WOFdKstdO8k1W5O2fG==", "d8oHWO9TWQndvN0tcmouhCoyjKKKWPu=", "W4hdIeyhW6DBWOxdLSka", "lJNcJCkqWRZcLLSDWPtdMq==", "j2CtWO86DvRdKa==", "c8ogWPPiWQDSthu=", "ys/cUgv5tCoin2y=", "W7ONW4ep", "ffHyFdhdRW==", "ztXa", "ceFdP8kWW5PvW4DytSotDG==", "WOpdSbpcUSkghG==", "W6lcOqChjqddRwP/WQJdTSkNdSkAe8kwxa==", "qMNdLMNcVmkUFNSLW5e8uCoJCwe=", "WOBcPsPpmeG=", "WRyjqmonWOHQiqCX", "cConWO98WQPLgveFhCojz8o8lLq=", "WPrGhSo9hCoCW5PFk0BcNa==", "lJNcLCkWWRhcGXKMWPtdNmkgfSkT", "FCoPW6ldGe3cOmohW5S=", "W7NdQ2LCrhhdKmkBWRipW6HW", "kCk+WQziW7KmWPtcHKxdIJFcMxNcOG==", "W7lcNCkOWQ5AW6a=", "rY7cTwzV", "ENSwAbu=", "tmkceSomx8oGWQbxoKbrW61EWR/dRCk6WQlcJW==", "W57cGCkVWRi=", "WPRdQ8kNW7pdKbtcGSkNW4Tagq==", "octcICk5WR3cNK0c", "W5ONWPNdJgO=", "osxcL8k0WR/cNLPrWRZdImkAdCkQW7hcN8kbWR1X", "WPtdGmkOW6/dH2tcQmkVW4Paga==", "W4fniCocsvSFW4JcMwNdJ8klb0S=", "WPb6mCo+bSkkW7K=", "WRpdNSkRWRW=", "W4VcLCkPWROfWRq=", "W5/dGLzcW6iAW4NcG8ofva==", "ed3cGq==", "auRcVSkpe8kavYpdUmkAWO4FA8oWW4qHkvlcGCkiW7tdI8kYwIVdHq==", "W4ruW63dJq==", "d8keWRKeW5yAWP/cM3ldLJpcKxBcPmoDsSoJWOxdG8k0iG==", "WRxcTvrna8oTfmkcamokdae=", "WOPSbmkYgCkDW7bdnGpdJ0FdMG==", "mSkYWRepW6SpWO7cHeC=", "W6mHnelcRKldMdS=", "xr7cHCoczJTqhanjW4ddK3Pd", "WQhcGmkVW7KVW7dcN13dMG==", "WRWfwSo2WPS4aaS9hmo9", "d2OuWP8Ww18=", "WRxcTvrnvmo/dmkbumkScbBcTmkz", "W6eQo1tcS0W=", "hWxcPSoxW6PQWQdcHZO=", "hW3cR8orW7TQWQ3cIZTYca==", "awRcNSkXrmkq", "W6qjW4i=", "WRPZr8kNt8kDW6Lcpa==", "W4FcPHZdOSkvW5DFW6bRW4tdP8ouAZT6wCkiW6y=", "r2/dLMNdR8o8", "B8kiWQNcJ8kFBCoBWOSxW4VdQ8oIW6fO", "W6FcRr0joX3dVcTrWQtcOSkcd8kd", "FKrpe0/dO0FcJ8oanCkkhCkwWO4=", "W5BcH8kxWRidWQhdLSk/xmklpWhdQW==", "vWlcO8olEZC=", "WRpcPvrQhCo4gSkbwmoCcGRcUCkiomo+WPW=", "h8ogWOj7WQv0guCucmoqjCot", "W5b9DudcV13dGtjvWPhcSW==", "oqRcQmoyW6WvWO3cGY90e8o3mSkO", "WPlcTu5b", "W7fYvCoWW5jS", "W57dHKuh", "W5FcNCkVWR4iWQhdLmkmvq==", "W48JW5i=", "W5tcVMCBmxu9", "W6VdHcvOW7BdOSoetSkuWP7dIINdUa==", "aSknW57cTConWPvyiKBdGW==", "W6/dGtz0W7VcQ8oLtSovWQ/dKdpdPmkNW5C6a8kJ", "EqfMW6JcGCk3WO4LcKGjx8kNWOadW4VdVCofzSkQW78hW61q", "WONdPrBdS8khhWNcTCoaW64=", "awa7", "WO8bWO4=", "WQhcGSkOW7bQWPJcJvtdL242W6fNbSoxW6ibWRpcVmoxW6qkW5lcNa==", "BuryCHK=", "amkDW4BcSCkaWQ9EDg7dMmk7bSoncYDugJK=", "W7xcUWytpa==", "tJJcV2jXE8omyL/dRs5NA8k6E8oEESoSW7bBW7BcUIa=", "wwpdGgxdRmkOAa==", "aSkJWR4YW6fKWQJcUmkgWOfzW4u=", "Fmkul8ozqmoGWQ0q", "ECoJW7JdSexcQW==", "W44fW5JcQZXNW6lcUCocW7FdNtz2ymkj", "W7NdJt5OW6RdOSoMrCkgWO3dIJFdRSkWWPr1", "W4BcS2eBBeaNW6e=", "mdpcNCkWWQe=", "WRJdRmkkW5e=", "oX3cSSkqW7lcRNGM", "WRazqmo2W4LRjq01ha==", "CmoEW6NdRCkGW61tW6FdQu8NzCkaW4JcGmknW4FdUSkPgGldR0pcSmkyW6WqlW==", "nguxWP8=", "W4jAi8onqXijW5q=", "W43dKLynWRqiW4BcMCoqeq==", "zSkgWRVcHmkqkmkqWPOpWPS=", "xMRdIW==", "E8oIW6ldVWhcJCoBW5m=", "W5S3W5qE", "W4lcTXZdVSkiW5TA", "BWpdRtFdLCk8e8klWQ/dVmoLWQVdNSoOEuW=", "WQinuSo8W4LqiWmHwCoAeaGA", "z8osW73dO8kPWQGeW7VdOvm=", "qstcQha=", "W7j4bsi=", "DLpdUmk2WOFdJXRdM3hcNa==", "WRlcSZKJBXpdVmk+rvWMWQaKsa==", "j2auWQKKFv3dJbldINHc", "ihyvWP87yfJdHWtcO1bxWOxdRGddIwhcHaimW4q=", "WRRcImkTW7KVW4VcKLpdINe=", "WQZdMx1dWPldHCoRqL4jkCkygSk4W5HkW7DhqmoXxq==", "W5JcKCk1WRGsWQhdLG==", "DH11W6JcGmk3WOO5tG==", "AmohhbxdTmkhW7RcRwBcNxdcTXVdRgq=", "W45reSonrq0y", "zmoyW6BdPmk3WQXi", "bKXj", "W6pdJcrN", "W7eGovFcUv/cJHDnWPdcQmoAzwZdMZu0xCkKWOfIWOa=", "oJNcJCkcWRFcLKKEWP8=", "zSotW6NdO8kPWQGeW47dRLCRAmkPW47cGq==", "AYJdHqNcGSkS", "zmkmWQ/cKSkjp8ovWP0=", "bmkIWQ43W6XHWRNcUa==", "urxcVCobFtLbfG==", "y8khWRRcJ8ordmozWOm=", "oZxcJ8kWW7lcPfWhWPtdKW==", "W5vdnmoe", "gq4B", "DSkiWRZcGCkzoq==", "W5/dGLyKW7uqW4dcUCogeLr0W5S=", "W67dT3mDx3NdN8ooWPPAWQqKnJuZxCkGWOldQ3ZcNG3cOa==", "WRlcSZK4zrhdRCk9EW==", "ySojWQJdTCkKWR9dW6RdTfa=", "mSoPW69yWQG=", "WQrtWRP2jq==", "FSoTW7VdT0VcQCksW7hdNSokxbJcOSk1vG==", "W7OJW4edv8oJgbz7fW/dPNiiFbS=", "W6D1dstdUq==", "CCkmWRRcSmkDiCofWOS=", "W6mWiv3dULJdMJftW5tcRmowyh0=", "WQSjWP1tE3naWQy=", "pmkrW5SU", "W6FdP3mvx2xdKCooWRnoWQuXoca=", "W67dR3aDvxxcNmkHWQfkWROInIe5", "FSodfH3dOmkwWR/cKfpcMw7cQrddQwlcKW==", "bN99AgZcSue=", "FCoGW7NdTuC=", "w0tdTCkWWPJdGXFcMLJcJmo7W4yPkgxcHmkEWO7cRKeHxHu=", "q8kEbCknu8o6WRaEefTqW7XzWRS=", "sYxcTub0D8omkxddTZO=", "wJlcGJZcRa==", "W4tcNKyIlwa3W6LZ", "W6rGdcBdV1znrSk3oM3dMxCnW5HKWO8=", "WRJdRrxcJmkleq7cQmogW78=", "ksH7nSotzmozgG==", "c8ogWPPjWQnHsx8F", "EWtdQJ3dMCo7", "qmkEhCojeSo5WQWEgufoW7PwWQpdPW==", "E8o5W6ldUqZcV8ogW5hdMmkpqWxcR8k0", "W5ZcLrjsWQq=", "tf7dUSk9WPdcIGpdKNZcLCoYWPiOn2BcICkzWPtdQtu1rX7dRCoxWQBcGxy=", "WRnsW5Wb", "W6FcRr0jpWJdOIyxWOFdQ8k8", "WO8fWODwygm=", "eCk3W7G=", "WPuotM/dGvm=", "WQBdMSk0WO/cJCkUW7Go", "lG/cVSoLW6O=", "FbldQJRdNCo1bCofWPhdQSoMWQ/dKSo8nGvFW4q=", "W5rhj8o3trCiW4i=", "W5OfW5JcVdDOW6tcSmovW5W=", "kSk+WR4mWRGpWOJcHKZdKcNcN3BcUSob", "W7mOWPqoWQ3dN8kA", "W5rhj8kbwHOrW5lcMdddJ8oktG==", "dv4fWRrepmkuW4lcGfLP", "W7eMj1VcQL/dNq==", "WOBdJSkYWQ0=", "oZ3cKSkW", "WRVdIhXvW5/dR8o9egezk8kyh8kXWPDNW7HEaCocqCowtG==", "CSoLW7ldSWZcV8oAW5hdNmoC", "WRJdLhXrW4ddP8oY", "WOtdU8kNW7/cGNlcPCkLW5yfjCkZWR/dIrFdKa==", "W5OfW5JdMs9OW6RcQCovWPJcJ38X", "B8ojhXldUSkf", "W6FdOxKzqtdcNa==", "W6W/W4GlsCo+hKr1aW/dVNKzCbNdMCkM", "W4pcUhqvlwq=", "W6K4WRqoWQhcICkiWPvLW4VdSSkiWQiYW5TKuGBcM8kComoAzmkZW7WTW5xdIIi=", "ehnWqMBdV1WHWOxcOSkkm8kxWRFcNa==", "zWD5W6hcLSoJWOi5cK8mrmo3WOba", "z8khWQ/cHmkqkmkqWQmhWOxdPSo5WQ9kdYK0ka==", "ySozW6NdSCkXWQrsW6RcOgi3mCkhW5tcJ8kgW57dSq==", "yCophX3dVSkxWRFdGNtcMw/cPbxdRq==", "vq7cRSoyydfwha==", "Ba7dP3BcIq==", "ks5UdmoxkmoBf8oJALlcIsJdTmkvD8kct0JdK8o6hfCcWOpcTG==", "WOxdP8kQW7tdG0BcO8kR", "ACoPW6ldMM7cLCo9W5JdJSoCsX4=", "tstcPvr5C8oFlxW=", "W5G6WQWnWQRdJmkl", "ot3cL8kYWRFcHvyeWOi=", "W7eMnf7cVWVdMtzkWPJcPmkzBhFdMcmUe8kxW5H/WOXEW4tdJmk8", "FCoPW6ldHu/cVSoxW5VdHSo8rXdcRG==", "aqFcS8oxW7K+WPG=", "W5NdLeDcW5CoW5BcGSopgqDzW4OGEdNdNcPJFqxdRmoKW6OwFmkJWPtcUmkow1ddKSkqma==", "ymkgWQRcN8oCpCoFWOCaWP/dUSoOW65GaW==", "WQBcGmk7W7TQW4ZcK1ldMq==", "jqhcOmooW6yKWRtcHcPLhG==", "W4RcThSDmYeiW6v5WPjd", "s1FdOG==", "WRtcSIKSBXZdSSkGrvKKWRiKsa==", "WR/cImk6W78H", "W43dG0yXW7GsW4hcK8ospuLL", "ACoiebBdV8kh", "WQ4pWO1uzYSfW7xcNa==", "W4VdRaHs", "emkKWQGiW715WR8=", "AmoTW7hdSW==", "iweeWRyND1JdHtddR3DpWOVdUq==", "ks5UdmoxkmoBf8oJALlcIsJdTmkvD8kct0JdK8o6hfCcWOpcTHu=", "wSkXkqNcQmkzwmkd", "WP5Lh8oXba==", "s8ouW7W=", "W4ZcKCkVW70wWQhdLSkAvCok", "s3xdHMm=", "WQhcK3a=", "pdJcNCkwWRRcKLOAWPpdKSko", "W7bqlaa=", "W57cVgjslMCOW79KWOm=", "oZNcMmkHWQFcHvWc", "lCk3WRS=", "WQ0yug/cKbJcJqVdSafDWRyVW7i=", "FvHvpK3dQuxdG8oymmkFb8kBWP0iW5T6", "jmkYWQKnWRGSWOlcMuFdIG==", "W5xcOrZdVSkeWP5EW60IW6NdT8kaBcD1uSkrW63dQsy5W4dcJG1+WOtcNtldQZG=", "t8kEeSoiqmoOWQ8=", "gLFdP8o/WOXhW4Hcw8kw", "DeHvmflcOgdcISoOpmky", "ystcQgf1Fmolmu3dOtS=", "WPbNfmo7dmkDW6Hziva=", "rCkseSoex8o8WQ5xm1rqW7HqWQRcOSkCWRRcNSo0lSkWW7VdVW==", "bNvTrYpcNLWI", "WRuEscpcLeVcIqRdVGnvW7mLW6NdVSoIpgzABCow", "WQ4uxsZcMqRcKahdSG==", "mdxcL8k6WQddL38yWONdMmkf", "xIdcO2r5zG==", "W7n6ec7dOKTD", "WRldMSk0WORcJ8kWW6GoWO/dIfNdGsW=", "uWhcOSooEq==", "W4FcRXK=", "F8oZmYddKSkGWOxcR1FcQG==", "tSk3pdpcRmovwSkomgjuWOGmo30GW5JdLmocg8ouzSkRWRyqWPNdTq==", "W6f9aZFdPLzya8oFeMZdJNaFW5vOWPPrg8oMte3dO8k+D8k0", "W57cKmk/WO4mWQNdNSkkqSkJkba=", "AKrxoKpdTaBcTmo1omkBc8kD", "BCoceatdP8klWQZcHZdcUxFcSr3dU2lcL8k7vW==", "W64PW5qjqCk3hWTCd0pdQ3Ke", "W70+WQe1WQhdImkpWPjI", "WRa7za==", "wCk7kd3cPCkqdCksoh4=", "WQeyxrNcKaFcIWC=", "cehdSSo8W4KuW5XfqSkFmYe1WRNdPCkyhCoXWRtdICoY", "WRldMSk0WOVcICkSW6KoWPpdLeldKI7cTeG=", "fmowWP3dOa==", "W6D8dcldOf5c", "wstcPvv9FSoAjW==", "W4hdJKWnW6zBW6pcN8oyevq=", "EfuBk0hdSKhcHSoKkG==", "aComWOP7WRuGgq==", "WRJdLSkUWRBcNSoIW4ScWPNdVKm=", "vqpcUCoepXfCca==", "WQOtWQfEygbaWQZdVComWRWbbCoL", "FmoufbldTSkqW7RcGh/cNhVdPrpdOwW=", "WP3dRq/cUSkfdaldPSobW7VdR8ksAWa=", "i8k/WRSLW60tWPpcHMBdLJxcJhpcUCotzq==", "WPHQe8oNhCkDW79p", "W6mWiv3cQv/dNd9fWPhdOCo/Bwa=", "W6C9jv7cTuldMI0=", "W5uGnelcTuxdSq==", "zmkAhSoixG==", "WRhcRYmoBrNdVSoYxvKZWROPw8oqBNe=", "W54+WQyhWRBdNCoFWPHTW4ddU8on", "W4xcRrpdTmkiW5K=", "wstcVwz/zSkpjNVdQZzYBmkPCCkx", "wCkXpdJcPCkq", "pd/cMSkGWQdcLLOi", "f8kYWQGpWQ1+WRZcUmkrWQW=", "W6KWW4Kdqmk3eHjDba/dQ2a=", "fhH4qMBdV0iNW4ZcR8kgyCoFW7JdKc7cLCoTdearmCkfsmo9W4fGWOSh", "uSk6FttcRmkm", "tW/cRSoH", "WQBcHmkXW6HCW5hcGfK=", "WR/dRmoGWPlcICk7W68cWO/dV0m=", "WQyexCo1WOW4lWXLgmoNg1G=", "WPrGa8oX", "fhH4qMBdV0iNW4ZcR8kgyCoFW7JdKc7cLCoTdearmCkfsmo9W4fG", "W7NdRw8vqMtcNmkhWQnkWQuJ", "aqFcRSolW70=", "rWJcUCo7CZXaaa==", "W5FcKCk6WRLaWRddLCkgxSkEnqFdUdVdRq==", "WOZdMhW=", "wvZdSmk0W5xdJGhdMx4=", "WOddQSkSW7lcGNZcGa==", "gGhcOmoiW7bQWPVcIZbJfmoY", "gLFdP8o/WOXhW59cw8oto241WRm=", "W6e1W6CgtCoHga==", "W6KIW4iNuCo7cq18baZdUNqgAb4=", "WQ4jWODEzITJWRZdHmokWRS=", "zCkmWRRcSmkDiCofWOS=", "WQCzWODqEwjgW7xdSCoAWQqCgSoWAL5MxG==", "W4tcR3atnwqdW6n3WPi=", "W6K4WQClWRtdNCkm", "WQZdKNnyW5FcPSoPweuaiSomeSkUWO1SW7PpvCo3sa==", "DebCnKpcOg3cHSoP", "W5tcVNqEjce5W6rOWPTvW5pcPNJdONddL8oRW47dQYddSCoYoCo/", "sCkXpNldSa==", "W61WdcJdOb9Od8khnMO=", "DWPKW4hcNmkGWOO7EKiet8kYW5i=", "W6/dGtnaW73cRCoJt8kAWPNdIW==", "tSkTmZZdQCkZtmknpc5+W4zeh3q9", "twxdNgNdRSk9DW==", "s1ZdQCk2WPddNG==", "lJ/cMmk5WRFdL04zWPJdKCktwCkRW67cNmkmWRPRW5fqWP7cJSkIwSofAuldNG==", "b1iFWO1xCmkNW44=", "nW/dMCkEWRFcJLSyWP/dMCkf", "y8kvfColv8owWRyfbebo", "W57cMSkVWRrnWOhdK8kc", "gqhcUmkEW6G5WPJcIYr5fSo7m8kY", "W6uVW4GfvSk3oW1aeXa=", "W4O6WOhdJMW=", "rW7cRmobD3bcdsTgW5hcMMrjW6VcJCocW6LeW45pW7KFE8oS", "w8kpdSoexmoU", "WQRdGNCuW7hdS8oTrembz8kKe8kGWPWUW4vjqmo6xCkgBrf2lmk8W7/dPh0wWOvnWP7cRW==", "WQZdKNnyW5FcPSoPweuaiSomhSkOWPXRWRzzsCo5tmovc14K", "psfGa8oz", "W4hcVh4xywaGW6TTWPjd", "W4RcMSkOWR4pWRddN8kl", "kSk+WR4EW6fFWPFcHLhdKdxcKa==", "h0dcSCkmbmkazIldQCktWPG=", "W7NdRxWqvZddI8kgWR5dWQ1WnYW4uCoUWOxcO0FcKW7dPCojWRy=", "e1iFW7TaFCk+W57cNrW=", "yqRdS3VdN8o6amkwWRNdQW==", "eeBcU8kAvSoqtYldV8kcWPHCySoZW40=", "AW7dSb7dNSo9bmkjWRNdUW==", "fxiVWPSHzLJdIGpdPNPtWPZdQLtdOW==", "W6uGo1FcQeRdGG==", "WRtdKCk0WRddGCkdW6qg", "m0yzWQ8=", "WRqCtIO=", "emkIWQ43W6XHWRNcUa==", "W5aRv3C=", "bhr3sgRcUa==", "c8ogWOb7WRrHvq==", "mCk4WR4eW71FWPdcH0VdId/dNhpcUCorACo7WPtdLSk2ot1YiG==", "xa5YW6JcNW==", "k1lcS8oYW4voW4rd", "lZ3cNSkW", "nYjRbCobkmkmxW==", "WRVcJ8kTW7vSW5NcJLpdJhe=", "WQFcPvqcaSoTfmkBrCkS", "W6aQmuVdULVdGtDnWOdcSSoAzxtdKq==", "W6/dOhWExNxcNmkVWRLBWQf9hIWX", "WROjtCk5WOHRnqSIf8oJdbyl", "z8oeW6BdOmkOWQrhWQ/dJvyUmCkbW5FcG8kaW4ddOmoUBHNdVK8=", "W6lcTXWejaZcRJ5wWRe=", "ACoVW7FdUKNdRmofW5BdGCods0RcO8k+xZvaW4LadCkmDCogWOldGmkvxSk6WQRcTq==", "W4JdIKvcW7SnW4dcHmoshun0", "BSouW7VdOSoR", "Eq/dOaJdNmo1aSkaWQ7dLSoKWQ8=", "AWpdQYZcKmoFe8kxWQ7dUSoKWQ/dL8o1EsHqW51tWO/cLa==", "cCkfW4/cUCkoW6z2mvO=", "WPddP8kNW7NdKfxcQa==", "ASkaWRRcHCkulmoEWO0l", "W6HWfItdUL5abCkA", "ardcS8oxW6CT", "sCkSla==", "bf4zWR5vAmk7W4tcLK8=", "cCklW4ZcTCkEW6yDDa==", "W7xcVqudkX3cRGnzWQxdQ8kNb8kpeSkhsKCYW6hcKuC=", "WRadWOHDCsTsWR3dLCodWQ1ig8oVAvnHrdNcHcfPjM00tSkB", "W4jmmSodqb5DW6RcLh7cGmkytMbRhetcKG==", "W6NdLdblbW==", "WRJcVYmgBqxdSmoYuveQWRGMx8kEqMjeWOaldJ/dVq==", "W7NdNvPmcG==", "p8oqWOK+W7y4", "WPddP8k9W4RdG1JcSCkR", "dSkOWR4eW74T", "W7SvW6fAha==", "AfNcTgVcGa==", "WRqiWOXFngLeWRZdKq==", "WRBcJgbynq==", "wrlcLJmK", "fXZcSCosW6yJWP/cKq==", "WPtdOqdcTmkeha==", "ySozW6ZdKSkPWQraW6RdSMOSmq==", "f8kbW5ZcLCkdWQDFoeBdIq==", "EqtcVSoEttnDbcXjW5e=", "W5e2mHldQHm=", "W4qjW4lcKdr8W6VdVmo0W5NdGJ52BmohWPddOCoYW6aGyJxdIW==", "vGlcQCoumIbAdcXEW4FdMw1kW6i=", "heFdP8ogW41yW55i", "wazKW5lcKmkRWOO5suS=", "WQ/cGYieWOi=", "W7iYWQeaWQVdKCkAWO4=", "WPnAumozcSkfW75FpuFcNa==", "otNcMmkYWR7cKG==", "WRxcHmk9W4TQW5NcILpdKa==", "FvHvpK3dQuxdG8oDlmkhemkAWOWjW5fXeW==", "cmkIWQnbW6X+WR/cTmktWQzAW5tdSCkF", "W7zWrSo7W5i4WOBdSWiQWRNcP8koqbCLW6z7WRFdJmk7", "W7FcSxqljhmrW6r0WOve", "W7/cUr5gjW/dQdLsWRu=", "WQiuwYRcKH/cLW3dUrW=", "jwSEWPWHCW==", "e3qQWOKela==", "jCkhW5ZcUCkBWQm=", "AKjAm0xcOfhcI8o5nCkormkBWPmkW5X2cCoqivRcNSogWP9VmmoA", "WOhcUr4BCHNdS8k1", "W7S/WReXWQJdGmkBWPH+W67dUCoC", "W7JdR3Oz", "W7NdRxWqvZddI8kgWR5dWQ1WnYOWumkNWPJcRaJcHrZcRmke", "WRxcPerVaCoGdmkhzmo+cGNcTmktjSo/", "FmkuqutcOW==", "e1qeWQ5c", "tSkscSoieSoAWQybeLS=", "W74IWRSdWQNdGmkCW51eW47dO8olWQi8W5LJxG==", "W4hdSs7dLCoq", "WQlcVIGbibldVmk7Ea==", "WQJdMxTyW5FcPSo3xGWnlSkEvSoH", "bu8BWRDzDCkMW5G=", "WRlcSZK6CXxdR8k8Df0I", "B8kaWQdcJ8kromoDW44kWORdPmoQW6HP", "W5BdSe3cOSor", "FKrvoLldOuO=", "W4z1aW==", "WRZdQZ8dWOC=", "W63dQ2KQu3ZdICkl", "W67dT3mDx3NdN8ooWPPAWQqKnJuZxCkGWOi=", "WQiiscpcMa7cJq==", "W68JW4GpvSo2eq==", "WQVdKgbtW5FdSG==", "b1iFWOLtCSk2W47cINnOW4X/DZy=", "W5/dHemoW7fBW5lcNSojgeiXW4CUCh3dPIDLmqlcRColW6He", "D8oTW7hdV0/dRmo5W5VdKq==", "EtlcTImSkG==", "W4ZcL8k6WRefW6ddJCkhwCkgi0tdStJdPmoGWOiBWPC1mqZdQM/dRL0=", "AWJdTJldGmoOfq==", "W4RcThSBlhqJWQXLWPzDWPlcQxq=", "rY7cJmo/iga=", "aNv4tg/cUHuoW4hcOSktnCoEW6hdMwRcVCo2hW8po8kexmo1", "W6D8fHFdOfbE", "cMrlWPbtzCkWW4lcLLHP", "WOTOf8o3", "t8kaWR3cLCkzkq==", "uLZdVmk4WPBcIJ/dN2W=", "WQFcPvqcaSoTfmkBrCkSrq==", "wfhdTmkYWP4=", "CqxdOdldK8o9eSkkWQ7dRmkQWQVdLmo/", "WQiyscJcNq4=", "W6VcOXRcSSow", "feJcTmkgvSoertJdQmkyWOG=", "WQCixsa=", "W4JdNKWdW7KsW4BdLSoTauTLW4yXC3ddOt0IrrNcVmoh", "W4RcSNexmIe=", "eWFcOSolW7SRWOJcMW==", "lw7dJmoL", "W44fW5JcRZHLW7pcUq==", "WQqfWP1NDwDqWRa=", "l8kYWRebW7ukWORdJ0BdHtFcNxdcSW==", "dh5GdMlcReyMW4lcRCkojmozW6m=", "W6ZcS3Wujf4PW7vXWOrjWQZcPhddPx7cNmo2W4/dOJe=", "W6PPW6bs", "WQmtsc3cNq7dNI/dVGfFWQfHW4ddOSo4nxa=", "WPBdN3zrW4RdICo4", "mwWzWPyTneZdHXpdOhLgWOVdRW==", "W4lcPwuElMG6W78=", "W5LsWPNdIq==", "WRGcfmo4WObQ", "dYb/qmkgpq==", "WQldK8o5WQW/", "FKrpcexdOvBcJmo+", "WQmfxsRcNW/cMWBcTW1rWRaQW7ldUCoHm2HhySob", "f1hcR8kpgCojvdG=", "W7/dLevcWQrd", "WOtdOCkOW7ddHXtcS8kMW5Pjd8o9W7FdQXBdJmo6WR4/k0buWPq=", "WQunrSo+WOXS", "pHrbiCo/qCoV", "WRWfr8o6WOX0kGmRhmoHhaS=", "fqhcTCo7W6C+WOlcLJPrcCoXmmktW7pdH8ouWRP7", "pIj6aSoEBCkmc8oRDG==", "jSkIWRejW7uwWOtdJ2/dKtBcIh7cPSolySo5WOu=", "W7zYqCoYWPDqWPtdUG9MWOJdVSkAsG==", "emkIWQ4ZW6HSWQdcKSksWQ5eW5tdQW==", "W63dQ2KUv37dMmklWQvGWRO5ocWY", "f8khW5RcUCkDWRjo", "D8oLW7JdUv7dRmo0W5FdKmokxq==", "W746WRGdWQpdJmoFWRj6W4ldPCoAWQm5W5i=", "W6JdHdXHWQ/cO8o9tmkzWOVdLG==", "EWPPWQ3cKSkWWPG+tuaiu8k5W5q=", "WP/dP8kLW6ZdH0BcTW==", "CrPKW6ldK8kWWP84wG4iwCkZW4u=", "xgFcTSoMW4a=", "W53dMCkHWRlcICkMW7GiWORcSG==", "W4FdGLSr", "WPpdU8kNW73dJ13cP8oUW75qbSkPW7BdSH3dGmk0WRK=", "g8olWODYWQmGth4ccSopoSoyiXK=", "CCkkWQ/cISkzBCohWOyhWOFdRmkRW6DJcJu4nCo3W4FcP1WLW7jfWO/dKSou", "umk7otRcUSov", "zItcV2rOEG==", "oYLRm8oEyCoigSo4qfVdHIhdRW==", "WQeyrYRcGWRcKG==", "ECovfftdKmkxWQNcLN/cLslcJrFdQwxdMmkyuCoCdSoLqYhdVmo8W6CUWPmLWQZdI8kHACk0aW==", "uaJcRmokFJu=", "W4dcUgeGjg8QW6LZWRHcWPRcQxJdQa==", "AYlcPwPQDW==", "W6yGnfxcTK4=", "WQddPrxcUW==", "avmpWOHADCk2W47cINv0W5e=", "y8knWQ/cLSkijmogWOToWQRdVmo/W6b/bt4HpG==", "WPHTfmorb8kzW79DmuZcLW==", "W57cL8k4WQGsWQhdMCkw", "WRyjqmopWOH0mWC=", "fLZcVSkph8ofuW==", "h8oaWO9YWQmGtNGybCofASovlL0UW5TNWRxdMd8SWPu=", "osNcMmk5WRVcKKO=", "amkYWQKvW6jG", "WQ8tcs7cMbK=", "qr7cQmknusvges1hWPtdSMLhW6pdICo4W6rcWOjiWRGWECk+W4XwuSk1W6NcVSkRW6NcGSkg", "FCoPW6ldG1/cQCoaW5ddICocsW==", "BSoPW7xcUXu=", "WRldNNzrW4hcPSk+", "WRpcPvrSfCoHhq==", "W4xdGc5MW6BcRmo3wmkQWPBdNq==", "h8ogWOj7WQv0gxqygSouk8otjfW=", "pcj9a8oxkmoegSoRyG==", "iCk0WReoW7ey", "W7lcVqPlCq==", "W7NdQ3ezuwtcNmkNWRLlWQeZpJeZrSk9W5BcN1hcLXG=", "pZv/dmoDyCoyda==", "fNedWPi=", "iCkPWROjW6WAWQRcGftdGq==", "W6KIW4i5smo+gqfkpW3dVG==", "WRuEscpcLeVcIqRdVGnvW7mPW6/dR8oLChbgy8osrConW5SY", "W6/dIYnTWQlcG8o6rG==", "A8ouW7ZdOSkTWQXkW6ZdPq==", "WRJcTYOgy1ddLSk3Ba==", "W5WYWQChWQa=", "C3iBfexdUutcISo+pCky", "d8omWOb4WQ9N", "fxP+sW==", "cehdSSo8W4KuW5XfqSkFmYe5WRNdVmkEgmo6WQFcImoGW5hcHxW=", "WRCbWPTwCx8=", "ceFdP8ogW41yW55i", "W68So1VcT17dG35NWPxcRmoyy33cLaGXgmkcWOP7WOfv", "sYlcSNzUC8omoW==", "WQxcJCo1W6K=", "W7SJW4Opr8oJxtnDfXpdPx4=", "tmkohCobw8oSWRa=", "W6KIW4i5uCo1kqvA", "eCkIWQWoW6f7WQNcRW==", "WRJcVYmaCLddM8k7Bvu0", "W5JcKCkVWPGoWQxdL8kgvCkz", "fSkfW4/cTq==", "W6KVWQClWQRdJG==", "ndlcNCk8WRhcLK0EWOpdJG==", "h1VdVCoXW4fDW4GnzSkgoNu4WQBdV8kth8oG", "WQdcHmkUW7v8W4ZcN07dVwm/WQ1TdSoqW6W=", "AKjAm0xcOfhcI8o5nCkormkBWPucW50/fmoFBKZcJmkp", "rWJcUCoHuaL6aYrzW5hdJG==", "gKhdSmoLW55vW4Hu", "WRtcK8kSW7L8W4ZcM1ldMIiCWQ8VjmowW74=", "WPBdT8k9W7pdLvxcQmkIWPnJa8kL", "WQZdKMbDW4ldSSoT", "W7WJW4vhhq==", "WOPSbmoedSkqW6Lt", "WRhdMSkHWR7cGmkN", "W6KIW4CAumo+cWeynXBdVN8AFb/dH8k3", "WQBcOJ8gBHC=", "k20EWPmLyvtcIstdONTxWONdRGddIxNdGtSBW5qaxW==", "W7H/WPy=", "WRtdKCk0WRddJmkdW6qg", "CrJdHtFdMCoQaW==", "W4FcLs0=", "W4lcUXpdS8kmW5DkWQugW7ddVSouBtH2x8kwW7C=", "W4rnpCohrrW=", "A8oJpZhdGCkJWPy=", "W6xcTWCaiq4=", "tJJcV2jXE8omyL/dRs5NA8k6E8oEESoS", "bN99ANhcSeuRW4RcTmkn", "W43dKLynW6mAW4NcMSkamK5P", "F8osaX3dVCkf", "heFdP8ofW59rW5LdsSkEmW==", "W6q/W5RcNdPFW6pcSmoFW5VdHITOuSoxWOi=", "itCJWR15", "W6VcSqCjoKNdIcnpWQtdSq==", "aqhcTCoOW6GMWP7cHW==", "WRRdN3nwW57dO8k+CuiylSobn8kOWPu=", "a2j3t27cTLzVW63cQSkxiSoFW7BdKINcMq==", "W63dQ3mzqhhdKa==", "W6VdMu0=", "ks5UdmoxkmoBf8oJALlcIsJdTmkvD8kct0JdK8o6hfCcWOpcTHxdIG==", "W40zW4lcMdrGW6xdVmo4W5hdMZX5AmkjWRZdSG==", "W4lcUXpdS8kmW5DkWQudW6ZdPSodBcL3vCkD", "eWdcPCo9W6eVWOJcIsf4aW==", "W4yoWOZcIJXLW6pcV8oeW53dI391ymkuWQVdTSo5W7e3", "iN0EWPSLFvRcIsJdQMjvWOBdQK7dPwO=", "BSoTW6tdSuNcUa==", "tc7cO2b5mSonlxBdOwjYA8kN", "e8kmW4hcVmkiW6zioLddJSk4aSobh2G=", "W5xcPXhdT8kcW4OjW5iUW6tdOSopAG==", "lJNcJCkzWPdcRNyxWPFdJSktdq==", "WQFdRCk+", "W4ldP2K=", "W5ObW4RcNhLbW6pcVCouWPJdOdeXqSkcWQy=", "BMxdGwNdRSkOo38OWPyXwG==", "W6RcGMmxiLCRW6bUWPrzWOFcT0RcTKG=", "mMucWP0Tya==", "W4mHW7RcUaPkW5tcLCoGW6W=", "W4nliCoetW8uW4JcK2m=", "hSocWOL7", "WPBdTGtcTSkBdq7cQmobWRRdHmkszWddJmkaW53cVNdcMN8=", "w8kEcmoOxmoOWQeBeLe=", "j8k1WR4kW7qAW4FcRKZdKdpdKvBcV8oj", "CZu9WRRdHG==", "oY5SfCoaACopbG==", "WOtdOqldVSor", "W4G3W7W=", "WRhcVZ8kyWtdTmk9E0m=", "amkbW4NcT8kbWQm=", "WQhcHmk9W4PUW5tcJ1K=", "l8k0WRSnW6TF", "qwxdI38=", "W4JdNKWdW7KsW4BdLSoTauTLW4yXC3ddOt0=", "w8kxe8oAeSo+WQiBha==", "W4zmoSomsG4EW4ZcMgi=", "WQipvCo1WOW4mqOSfCoRsraqCCkfWOiYW6LeWPubhgD5W4u=", "oqRcQmoyW6WvWPZcIYD4dmoZpmkTW6xdKa==", "WRpdPqlcU8kn", "W7Cwbq==", "W6VcUq4pk0NdHs9o", "ACoiebBdV8khW7RcR3NcLM3cT1ldJMJcGmkUqq==", "ktL9cCoCBW==", "W5VcJCk1WRWnWQNdMCopFCkFkHddScFdP8oTWOub", "ocjRgCksEmodfSoKCKtdIIhdT8kC", "DWPKW57cKmkXWO4Yrh0mtmkY", "WPhdOaxcLCkhfXS=", "WQioWP1youPmWRG=", "aHBcPmoyW6W4W4VcGcj+fSk+mSkOWQddPSoY", "W60OW4CismoYxsLrgaZdUdaVDGJdKSkH", "BCoigbNdTCkxWRNcIxxcIG==", "W6ZdVhGzqwtdNCkaWRmpWO4Xncb8E8kGW5BcGe3cNG==", "W5OuW57cKdDU", "WRldMhXDW5/dS8oZeeGnkSkneCkK", "FmophXpdOmksWRpcIxxdMe3cQ1ldG2tcGq==", "W6pcTGGejaZcRGTzWRxdQ8oPj8ksea==", "Dbz+W6ZcNSkQWOH3yKCrvCk/W4eoW4FdTG==", "WRBcMmkNW71IW5hcMrZdTMSNWQjNdSoDW6re", "EJWWW4BcLSk6WOK+reOw", "W7SmWOu=", "wvldQCkYWPdcIHBdLxhcGmk3W5mPnq==", "bCkZW7G=", "W57cO8kl", "fhH4qMBdV0iNW4ZcR8kgyCoFW7JdKc7cLCoTdearmCkfsmo9W4fGWOS=", "W4ZcL8k6WRefW6ddJCkhwCkgi0tdStJdPmoGWOiBWPC1mqZdQM/dRL3dPZW=", "c8kUWR4eWQ1+WQtcSSkaWRS=", "EevAl1tdQvdcHSkWgmkEemkCWO8fW5DVaG==", "dCohWO9UWRjPt3vrkmovpSosnfOKWOTX", "ks5UdmoxkmoBf8oJALlcIsJdSSkDDSoluKFcNmoJbHLg", "WQSurYdcG0VcUaVdRWPd", "WRxcO0nxbSoTg8kx", "aCocWOL3WQuGCNui", "kcH5d8oEFSojdq==", "Fa7dPtZdNmo5", "fhH4qMBdV0iNW4ZcR8kgyCoFW7JdKc7cLCoTdeaEoCkcqCkWWOzGWOS=", "WO3dNMDAW5y=", "tstcPvzVD8oDlhpdTsC=", "twxdHK/dTmk9Ax0S", "W44fW5JcRcPSW7tcSSorW5xdIG==", "WQpcQevmvmoepa==", "Fqz+W6tcNSk2WOz3tK8iv8kWW4u=", "msH2eW==", "W6H6sCo4W4u4WRFdSHmJWQ8=", "W4pcPhStlgGTWQXmWOjCWOFcP2hdQxZcMCoS", "WQKZW4L6CxjhWRZdKSolWRS=", "xmkWorZcOCkqtSkno2fj", "qMxdK2JcVmkSDhmNWOuUxmoLCwe=", "W4vnn8oydaSsW47cK2tcNmkjd0PN", "W7Dnja==", "WRBcMmkNW71IW5hcMrZdS3C/WRvMh8oCW65pWRq=", "ceFdV8o1W49aWOT6tSksjM4/", "W7j3yai=", "WOa2qG==", "W6n6uCoYWPDlWPtdRq4O", "W6KoWPC2WOxdQ8kGWRblW7u=", "AmoyW7hcOCkKWR5xW6BdP00VimkgW5m=", "CCkkWRZcJ8kmoCod", "WQBdNmkHWRxcICoIW7OdWOJdT1xcMYhcSKOqWO/dG8oEWPnmzui+wCo3eq==", "hqRdRmonW6eLWP/dGIDYcmoNm8kL", "W74cWPSJWONdOmk8", "gu3dT8oPWOXeW4rerCkhjwiWWRRdTq==", "feJcTmkgvSoSqsW=", "rZ7cISkDkG==", "svRcNZVcQq==", "oJNcJCkhWRFcMv0uWOpdSSkeemkKW6JcNG==", "v8oLW7G=", "D8oLW7JdV0hcUCoFWP7dRmooqWVcRmk0eX5FW4jvx8kiEmon", "Cfj6m0NdTKm=", "CCoyW77dRSkPWRTbW70=", "W4hdIeyhW6DB", "wfrC", "iweeWQWPEeZdJa==", "w8kAgSoieSobWQyweXvYW7CxWOtdP8kQ", "W4hdHKulW7DBW67cK8oz", "W7aGmLVcQv/dIYXGWPxcRCovzNNdLYW=", "hupdUmo1", "vHP+W64=", "a8kRWQ8eW6e=", "avKFWRiwxCk7W4y=", "ASk+WQpcPG==", "W4xcMfdcPCou", "W6ZdOw8FvZddNSkbWRnwW6GXnIG=", "W43dG0msW6asW5pcKW==", "tSkudSoov8kPWQeye0WDW7HEWQi=", "zCkmWRRcRSkvoCosWOewWRVdPSo4W6z4dZ4/", "W6D8q8oUWPDOWP7dSGuYWQ/dPmklqWC=", "ah5TEglcS0aQ", "WRldKhvDW5hcPSovvvvme8kvbSkK", "W73dGcmKW7NcO8o/xSkqW47cHwFcQW==", "i8k4WRWDW6OEWOtcLG==", "Fqz+W6tcNSk2WOz3BK8iv8kWW4vaW6VdPCoeFCkSW78mW6y=", "W6RdHdPLW6JcP8kZzmkdWOVdLZxdOSkWW5e=", "tJJcV2jXE8omyLRdStzWASkRESouCq==", "W6r2fYxdVLOoeSkEiW==", "WQiVDColW5SO", "f8kbW5ZcN8kBWQnpjKRdICkY", "h8oxWPX3WQHN", "WRpcGSkQW6L9W5NcMuu=", "W6WVW5qpr8oJfaTwbq==", "oqRcQmoyW6WvWOdcGZf2fSo8nmkY", "WPpdRCk8W77dJLhdPmk6W5jv", "Eqf0W6tcKmkIWP84wf1frSk4W5m=", "WRazqmo2W4LRmG01wCoJbHWA", "W68QmvFcQqS=", "zSkqWQdcH8krjmotW44MWOldVCoOW6DTcdi0", "eWRcTCoxWQqlWOlcJW==", "psH7mSoxzSoigSo4suxdGcFdSSkx", "WRtdRCkLW7pdKeC=", "yCohfH3dSmocWPhcH2K=", "WQSstsRcGKVdNKi=", "b8k+WRqaW6bKWQ/dVCk5WR1BW4xdTSkBW7G8WQiR", "AmoFhXxdVSklWRNdGL3cJw7cSrVdUg7cKCkLrG==", "WPhdO8kIW7K=", "WQCixsddKrJcIG3dP09DWRWLW6m=", "WRlcOuThvmoOhCkDwCoIbG==", "uCoPW6/dTexcOSowW43dT8ow", "W6L8umk3W79i", "WPnGbmoMcSkoWRXznuxcNalcJG==", "BSksdSoivG==", "Ee9pnG3dGu/cJG==", "wvpdTtZcPa==", "et7dRmkjWRW=", "f8kbW5ZcLSkmWQ1yg0xdI8kKf8oq", "WQSurYBcNb7cK0ldKW5DWRiMW6pcQ8opjMzCFSopuSki", "WRddKCkHWRVcGmkNWQ0MWOJdTv/dIwNcM08mWOpdNG==", "W6bRu8oYW5L8WPtdV0SKWR3dPmkbwXaMW6L1WQRdG8kS", "W78UW4mebmotkq==", "WRNcQvnbwG==", "zCkfWQhcHCkx", "w8o8W6BdULu=", "WRpcPvr0hCoPd8kVtSoRcrZcOW==", "uWxdRt3dLCodbCkeWRldTSo5", "WRS/fmosWOXHjaSRhCo9", "W6r3q8otW4v3WOhdVWqXWRi=", "W6K+WQe0WQxdHCkkWPG=", "WQubWOju", "W6H8q8oYW4q4", "CCkkWQ/cISkzBCohWOyhWOFdRmkRW6DLaJrXkmo4WOJcSu5SWR8=", "W6WNW4Slq8oYxsToeXhdUhKnEG==", "D1ZdQmkEWOldHctdIhRcICoYW4a0iq==", "sSk8ndpcRmovrmkiEw9yW5PeDde=", "WQqsttBdKrVcKqVdUrTdWRaGW6RdRG==", "w0tdTCkWWPJdGXFcMLJcJmo7W4yPkgxcHmkEWO4=", "AWJdPtFdLCk8eCknWRxdS8oVW7VdK8oLpqKrW4nAWOFcHCkH", "W5lcM8k/WRGtW6dcMG==", "xH7dQJG=", "W7SKiHlcTu3dIc1gWOa=", "iN0EWPSLFvRcIs3dTNPcWOFdU0/dR2hdKa==", "wwxdHLRdVCkWBN8=", "E8oOW7ldHudcPCowW5VdMSoMqb4=", "W5ZcLrDs", "eWdcOmooW70JWP3cH2nwdSoQmSk1W6pdJCowWPy=", "CCoCW6/dPa==", "W6G6WRih", "mSkYWRepW5erWOpcHKhdHs7cK2u=", "WRqcvCo7WOv9zImRdCoNrdKwCa==", "WPWfr8oQWOX8", "W6tcTW0FAbNdOsnzWRxdSCkNb8kxga==", "y27dLMNdPmktFq==", "sc7cTxO8ySoak3ZdRdfWy8kMCq==", "fKVdVCo/W54uW61eu8kwjq==", "xGP3W6JcHq==", "gKBdSSoGW5HDW51ic8kYi3u+WQxdS8kvaCoX", "W6VdNsDOW6dcQ8oNwa==", "BwZdNw/dT8o8kIi=", "CCkkWQ/cISkzBCohWOyhWOFdRmkRW6DJcJu4nCo3W4FcQfqIW7SiW4JdKSouWP4=", "W43dHeexW6yAW4BcJW==", "W68JW5i6vSo4dq==", "nX3cR8kuWOhcTgS4WQhdQq==", "W6dcUge=", "wLpdUSkZWPNdJ1tdT3tcNSo+W5fGe2/cLa==", "WQBcTt8gCatdRG==", "W6y8o1pcT0ldJx5RWP3cTCoABhNdMIqI", "WRunwCo4WO59zI0Zhmo8gXeBEa==", "DGbIW67cLSoJWOK4tLDfv8k+W40=", "bSkPWRSdW6fOW6ZcMCknWQzwW5ZdTSkiWRCyWRKZweOxmIC1W7q=", "wSoNdHJdUa==", "W6VdRx4jqhhdN8kx", "W6f9aZFdPLzya8oFeMZdJNaFW5vOWPPr", "ACoPW6ldMvRcQCoaW4ZdGColsW==", "FCoPW7JdS17cRCoE", "WPPMhSo0bSkB", "hSogWPHXWQP2xgi=", "W68JW5i8rCo7cae=", "WRyjqmoxWOH1iW==", "tstcPvv9FSoAjW==", "W4ifW5xdMtH6W7xcTCoxW5BdGJP/Fq==", "CqfKW6tdK8kcWOi6", "WPrGa8oXqq==", "W4dcUgeKig07W6K=", "AW7dSaNdLCo9cSkQWRRdUCo5WR7dJW==", "WRpcPvr0fCoGdCkl", "W4tcRrNdQ8obW45gW6WLW7hdOCodzsr8", "WPxdPrpcV8krwrJcRSoaW7tcOSkByWNcImkMW53dUrVcKM/dU2bMWQy=", "auRcRCkkbSouuW==", "jmk6WRqn", "WQCbWOrqC24fWPRdISokWROAgSoKya==", "tNNdNg3dSCk1EdOeWOqXs8oTBwT7WR3dVW==", "a354sw/cUG==", "W6j2bJ7cSK9bd8krj2RdMx4aW5m=", "WPHEia==", "WQusrYNcMaW=", "W7xcVr0WkqxdUY8=", "DabLW6/cN8kMW4SJs14=", "W5lcJKu=", "pKJcUa==", "bN99Fw/cTLeQW5FcISknnq==", "wwpdK2ddUCo8BhiGWP04h8oSDgb3W7pdUhCfW5rcDtW=", "xmohbrW=", "W4pcPhStlgGTWQXmWOjCWOFcP2hdQxZcMCoSWOBdKc3dSSk3", "WPFdOrxcHCkjfrRcOW==", "WPRdO8kUW7xdGrtcJ8kRW4O=", "W7SJW5jkuSo2erfDvKpcQJa=", "WRWfwSoWWOrTk0iHgmoJcb8A", "W5tcVhmxyuKRW61L", "W6hcVqCdoGJdOG==", "sCkvcmoeeSoiWQOA", "W5rbiCoixa8o", "W4ZcUgXsihi9W6vMWPLDWPBcOgu=", "W5rbmSonsvSkW4/cLhZcISokcKL3bK3cHmkiemo+fmkkua==", "W60ZWRamW6tdRCkR", "WOSuwJZcRGJcLGpdUqXv", "WQBdVmkbWOVdNSoY", "W6KLW4uFvSo2hH0=", "W4dcSbJdT8ksW4PiW6SVWQxdNCoojan8tW==", "E8o5W6ldUq==", "W4L3bIldQNbi", "xmkWoqZcPCkCsCkdk0DFW5W=", "ymopW63dOmkXWQHPW6ddTKy=", "W7xcUWGkluNdUsjEWQ3dP8oKaSkucmkxvqisW7NcKq==", "W4zgn8oSwrCjW47cUwlcGmkAcKL1cG==", "umk9mZBcPmkaqmogpw9CW4Kdmq==", "ECk7lZlcQmkBwq==", "W53cM8k/WQraWRddLCkgxSkEnqFdUdVdRq==", "rYdcTMP/mSoKj2S=", "WQijqmopWOH0mWC=", "uK9souxdN0dcJ8o5kq==", "b1SeWRHD", "whZdL8kyWRK=", "v1tdR8kYWP3dIXRdMxddMCoBW50Np2/cNW==", "CmoEW6NdRCkGW61tW6FdQu8NzCkaW4JcGmknW4FdUSkPgG3dP0tcUCovWQSqlZu=", "WRazqmo2", "yCosW6ZdUmoLWR1lW6BdRLCXjSkjW4VcIq==", "WQBcTsWdzvddQSk6FfWIW7KPvCosAx1pWPvzbtRdSxxcTa==", "pcNcJCk6W7lcHe0EWOhcNCkBfSkNW6q=", "WQiyrSoWWOD/", "W6K+WRKhWQFdNCoFWRrIW4pdVSolWQSPW5HYseJcQmofjCow", "atFcHSkoWRe=", "WPldNN5BW4BdQCoO", "CrPKW6ldK8kNWOiLt00rx8k4W44=", "WPRdRCkTW7NdKrtdPmoU", "FbldQJRdNCo1bCofWPtdTSo+WRJdK8oTnW9u", "W7eGirlcReRdGITgW5tdOq==", "WOtdKCkoWQZcMG==", "WRafWP0ryMPjWQddMCkp", "ffyzWRXtAa==", "WQxdLSkUWR7cN8kYW6qaWOtcU3/dLwNcLKmn", "tf7dUSk9WPdcIGpdKNZcLCoYWPiOn2BcICkzWPtdQtu6tXNdPmkAW6e=", "lJ/cMmk5WRFdL04zWPJdKCktwCkNW67cHCkkWR9GW4irWOpdH8oShG==", "WPldUSk5W7ddJv3cSmk9", "WRFcR05ehCoR", "iweEWP86Dvu=", "W7NdR3SzeLJdMCkpWRmpWOC+FW45tq==", "iLBdSCkoWRK=", "jCk+WQS+W7eAWPdcRKZdGZBcMwq=", "W5tcKCkIW70bWRpdICkgv8kekWhdTYm=", "W4r8dIBdQX9DdSkqjW==", "WRtdNmkJWQZcNSkJW64s", "E8oBW4y=", "WR/cJSkTW7L8WPG=", "WP9SeCoMgSkoW7Lf", "ieu9WRSB", "W7yGnH/dOW==", "W6K+WQfcWRldImktWOHPWOFcT8kiW6O=", "WQepWO1inhTkWRZdKSoBWRSleSoSya==", "W6JdJcfHWQ/cKCo2xCkqWOa=", "WQlcVIqdzvddQmk8zLmOWQKKxSkE", "W6FdOxKzqtdcNmooW7C=", "W6rGdcBdV1znrSkYjNxdJNyCW5LUWOra", "WR7dPKi=", "W6fYsSo2W5b9W5hdLb0JWQ7dTCkdsWC=", "fh5TA23cVLCJW4dcPW==", "bSoWW45vWQn5w3KFdCot", "WR7dKNfbW4ddP8o9sq==", "W7ZcM8kO", "W6XmoSohssqsW5lcIxtcGmkfha==", "W6eWjKBcTuy=", "WOPQeCo+cSoCW6TEoK/cIKFcKLvho8oMWRVdUmoxW6BdKWXJnCkI", "W5vhjCooqa0yW5u=", "WQZdLgyuW4tdP8oYruLmz8om", "CCkiWQJcG8oCbCovWO8k", "e3PRswBcQW==", "bxr9vYpcR1OMW4VcT8kqiSowW7VdMq==", "W6y8o1pcT0ldJx5UWOhcRConBwJdMY4Pcq==", "yWPKW4JcNCkIWOK7t0O=", "uqxdOd7dImotaa==", "W6ZdIJn9WQ/cSSo8qSkBWPRdLItdQSk4W5e=", "W6JdGdzWW7RcSmo2wmov", "WPJcI8kHW6JdJmkX", "E8oVW7xdO17cRCorW4C=", "W7z2u8osW5L5WPpdTW4I", "WRKfqmo6WOf5kaeGjSoIbH8yEmkt", "c1isW7TxB8kHW4lcN1j3W4b2AG==", "W5JdH8kiWPPr", "sCkFgmo+xSoGWQCsbxXtW60=", "acHkAti=", "s2tdLL/dSmk1F387WRGZsW==", "cNj3qxhdV3mMW53cPSkq", "WPtcVw1BnW==", "WOujWPTuCa==", "W4xcSbJdS8kvW5TKW6O9W6a=", "W7NdRxWqvZddI8kgWR5dWQ1WnYW4uCoUWOxcO0FcKW4=", "eavBW6Sg", "wK5xmfldSW==", "CmoyW7ZdL8kKWQfrW6O=", "CWb+W6VcMSkK", "DWPKW4pcKSkUWO4=", "W70+WQeXWQFdM8kAWPHIW7tdVSosWQ8=", "W7RdP2KFwJddKCkbWRnk", "smoyW7hdO8kSWQnaW7ZdN1S=", "W6ZdQ3Wir2ldMCkDW7C=", "lJNcJCo1WQtcLLueWPq=", "ACoVW7FdUKNdRmofW5BdGCods0RcO8k4vZqjW5rpqSkvB8ki", "umk1oJBcQSovzSkdia==", "teNdQCk4WPVdJq==", "W6PkqGZdT0zmd8krn2O=", "W6rSaYVdU1PD", "ieZcQCkgbmotrq==", "hbhdGmoxWP0=", "WOFcO0fqvmk+sa==", "WQdcOvjfeCo4", "W5/dGLyNW7OAW4FcMSofea==", "fMZcMCkIi8oSDa==", "WPZcUcKkEd/dUW==", "xLpdR8k4W5xdQX3dLW==", "tNNdNg3dSCk1EdOeWOqXs8oTBwT7WR3dVZ8+W5Lbma==", "W4hcPXpdT8ktW59f", "W7eKm1FdUMpdIZ9hW5tcJmowyh3dHW==", "WQyoWOHtEg5b", "zSofW7JdRCkQWQrqW7W=", "De5FoLpcOa==", "W5tcSxWwjce5W61TWPW=", "WPb6jSoZa8kvW7G=", "W7lcUrSblr0=", "W5hcQHJdVmobW5naW6SVW6JdTq==", "xaJcRmojmIbAdcXEW4FdMw1kW6i=", "aLGpWQiwBmk9W4lcLKHPW4z5CJ0=", "W7SfW6C4fSkN", "WQipvCo1WOW4mqOSfCoRsraqCCkfWOiYW6LeWPubhgD5", "W5xcVhix", "W6HYqmo+W5q4WRRdVHi=", "bCkkW5ZcUConWODuoq==", "qIJcPwb0C8obixC=", "xmkvFrVcOmkhsmkflwDEW4zepx8YW5tdImorxSoe", "W6rMu8o4WPDRWPldTbSJ", "EqxdSdlcKmoDd8ki", "ASo+W7pdSeNcVSksW43dICojs0RcU8k+wJ9D", "WRpdLSk2WRZdJmkrW6GDWOtdTq==", "W7S1WQelW6NdQmkwWPa=", "WRfGbmondmkuW71ymey=", "gKZdP8o5WOX1W4ja", "W4ZcP8kCW61y", "W4zgn8oLxHqnW4pcKMFcGq==", "WRFcUsKwiaddSSk7E0q0WROGvSoB", "iGxcTCow", "WRtcUdKglthdTmk/", "WQeyxr/cGWtcJG==", "WQFcTYOk", "xmkHktddQCkgwCkjks5CW4Camq==", "WPXNeCoWa8kzW7G=", "W4mjW5JcJtX7WQBcS8owW57dNdPL", "WQBcHqPFoa==", "W6D8fHtdPK1hcmky", "cepdTCo1WOX8W45mt8otaNGHWRm=", "W7eGovFcUv/cJGLgWPxcSCowAJJcLgDNxq==", "BxlcOMqT", "r2hdLwxdV8o8uh8W", "W74EWPmJWPhdPCkR", "W5OfW4dcNdP9WQBcI8ovW5NdNZb/", "xL7dUmkKWOFdIXFdGW==", "i8kUWQShWRGmWPpcGflcHdFcK3pcSW==", "W5OfW4dcNdP9WQBcUmozW4VdMZ5/ASkc", "cx5U", "WQBcPvzngmo6hCkC", "cmomWPT8WQPLtxeb", "W6bRv8o7W5HXWOxdQa==", "aqFcOmosW6XQWPZcIIP7hSk+nCkPW6ZdHSopWP1yv8ozz8oKx8oaWPmBW7y=", "amkDW4BcSCkaWQ9EDgVdHmkJeComgIzEeq==", "W6PynaBdGxX8l8kVbW==", "WR/cImkNW7n9WPJcVfxdHMCG", "iahcP8oBW7SVWOxcGsy=", "ACoPW7RdS0/cUmksW6NdJCooxGxcPCoXe3ejWOC=", "e37cJW==", "Ee9pnGddGu/cJG==", "WRadWPTyzh8fWRZdImokWQuB", "W4FcUX0ppGW=", "cvKpWRjvFCkMW4tcIK86W5v3Bq==", "r2/dLMNdR8o8oW==", "y8kCWRRcICoCpSoeWOeEW4VdPmoKW6TP", "WRldMhXDW5/dS8oZegGnkSkneCkKW5HbW6bpu8oKuCoctG==", "WPpdTGtcSSkChclcQCotW78=", "tubioLi=", "W5xcOrZdVSkeWP5EW60IW6NdT8kaBcD1uSkrW63dQsy5W4dcJG1+WOtcNtldQW==", "jCk+WRenW6OEWOS=", "heFdP8oaW55BW5S=", "W6hcVr00lqFdQI9fWO7dSmkTaCkseW==", "EmoJW7ldRWZcVmoDW5FdHSoBxqNcQSk9vG==", "W7ZdGdbTW7ZcTSo2wCk2WO/dIsVdQCk1W5C+", "kfhdTmkWWPWm", "W5ZcM8k1WRSjWQC=", "emkZWQGiW6nQ", "gvyCW7TzESk0W5JcNuG=", "bN94xNFcTKmQWOxcGSkwnCoyW6tdNYxcJmoM", "WPtcImk7W7LR", "mb4Vk8oxCCoofSoKyKq=", "e1iFWO1xCmkNW44=", "uaRdTXtdH8oYnSkxWRpdR8oVWQNdJ8o1", "W5LsWPZdIwK=", "WO4jWPPcCw8=", "WOPQeCo+cSoCW6TEoK/cIKFcKLnpoSkVWQBdT8kyW7ddGuuU", "WRVdIhXvW5/dR8o9egqfm8kphSkGWPzTW7m=", "WOxdO8kUW7K=", "ksH7jCoCACooe8oVyG==", "fhH4qMBdV0iNW4ZcR8kgyCoFW77dMc/dNmoWaW8ik8oldmkW", "fh5TdNxcVLK6W4ddO8odyCkx", "zCkmWRRcQSktlSorWOi+WOFdQmoYW6P+", "b1iFWOHvBSk3W47cLM9ZW599", "W7aGjLFcRGVdId9iWPhdOCowAJJdNYi+", "W5xcOXVdT8obW7zmW6qVWQxdN8opyc1Q", "ceFdP8owW41FW45ItCkvjwqL", "WRNcOuDlf8kSm8klwq==", "BK5jm0tdLeNcSmoZk8koaCkD", "WQijwmo8WOPSzJuGgmo+bHy=", "tmkEhCokxSoS", "W7iSo1xcQvVdHZvgW5tcJSoxjfpdKt4=", "WQddP8kOW6ZdJvO=", "ACkmWRFcLq==", "W7vhnCoexH4tW4tcMa==", "sZtcPwW8yCoBlwlcUc98zSkV", "WQinuSo8W4LqiWmHwCodbHWABG==", "pcr5bCksw8ojcCoVAa==", "W6vHeIVdVvzAfq==", "W4VdUw0=", "rWJcOCoiCsqvasTzW4ddM2jfW6ldIq==", "WRWnu8oWWOO4dqC8", "WQqfWP18DxTRWRtdKCok", "emkIWQ4NW6XMWQNcKSksWQ5eW5tdQW==", "WOtdP8k9W4RdG1JcSCkR", "nwGFWO1Oy1JdHqS=", "WRdcUu5dgCoLg8ooBCo5cq3cUCkmpSo4WPZdNa==", "W5tcVNqEjce5W6rOWPTvW5pcPNJdONddL8oRW47dQYddSq==", "b8kMWRCaW6POW6ZcKSkcWQ1fW4pdTSkpW7i=", "eIr7", "pdlcJCk8W7/cTLaC", "iSknW5RcTCkj", "W6T8g2FdS0XDd8kypxtdN3ey", "WOtdGCkiW47cKaq=", "h8ogWPO+WRbHvwuusCka", "W64NW40pbmoBham=", "h8ocWOH7W6zixhevsCoVjmkDdfWY", "jCk+WQSHW7yl", "bmkIWQ4TW6jUWQ3cSCkKWQrwW4JdUSkz", "dCkkW4ZcUCkoWQDjo1hdNG==", "W4ZcKv3dMCkeW4DlW6WLW6hdOq==", "DG57W6G=", "emkKWRSnW6GTWRVcTCkDWQrsWPhdT8keW7SXWQuXsWmknca/W63dLIZdMCkp", "WPHNbmo7t8k9W7vB", "W4xcSNelyxeHW6vVWOndWPdcR33dOW==", "W7xcUXSpob3dVq==", "W6iGDmoqWOy=", "WQ0yudW=", "aSkKWRKuW79SWQ/cPa==", "W5rhj8oKqHOFW4VcMhq=", "W7eGirlcReRdGITgW5tdOCkzja==", "pJHUdmoBBCoF", "WQFcSYOgCWtdUmkGvLeRWRuJw8oDzG==", "fK3dT8o1W58uWOS=", "WRmdumoGW4LOkqSRdCo9cHKtEa==", "WRlcSZK5yrZdQmk3", "W7RcVc1maG==", "cupdTmo1", "W4KOWRjcW7tcKq==", "W6/dOhWExNxcNmkJWR5bWQCIFWm1tmkRWOu=", "tSkXkrNcQmkEsmkPp2HcW40q", "B8kiWQNcJ8kFBCo7WOSx", "j2auWQK9DM3dIai=", "zSkqWQdcH8krjmotW44JWP7dPCo/W6z8ctG/lW==", "mCk4WR4eW71FWPdcH0VdId/dNh/cUCoiB8o+WP/dHCo3k3W7BW==", "BWpdRtFdLCk8d8klW7ZdVSoJWQNcMW==", "W6uNW4edr8k3nGfb", "F8ofebJdTSocWQ3cINNcLgFdPrRdOwxcNCoRqCovdCo0ea==", "W4T8gYxdU1fkfCkGk2e=", "dConWPP3W6Tbuh0=", "xSkoCgJdVa==", "be4fWRPBDCkXWOVcTuL2W5fXBJC4hmo+", "W5aQifZcVG==", "wSkAg8oi", "W459tSoXW5jhWPldTbKI", "wCkTmZ7cPmkCtSogfhTDW5Wnjh4TW5/dJSkfB8opD8kN", "W6aVW5ijtmo2eWDD", "WQBcLqW9mKa=", "W6XmoSohssqoW5pcLhZcISkEgKK=", "vqpcUCoemHfCca==", "W6j2u8obW5z0WOtdVG==", "ACoFW5hcPHq=", "W7nTec7dVfG=", "mIrRbCksE8oeemo+Dq==", "W7eKm1FdUMpdIZ9hW5tcLCoaDh0=", "q27dLMxdV8k9B3u7WOi=", "oYn7cCkssCofeG==", "wctcTMPVzSokmfhdUs5/ymkRD8oC", "sCkvcmoeh8oiWQOA", "wslcSg95mSoykNVdTcCZASkLEmotFCo2WRCVW63cQYXcdW==", "WQe4zWRcOYRcSG==", "aSkYWQ4oWQ1+WQ/cSSkeWQ0=", "wwxdHIZdQSk9D28SW5f9", "iMuDWPSVCrNdPHBdPMreWOFdR0u=", "WRldMSk0WOZcN8kNW78fWOddTLu=", "WRtdQmkq", "W6r4dYBdTvOokCkjnMVdIhyiW5m=", "W7nAiXxcOa8=", "auZcQ8odamobtd7dTmowW4S=", "F8oFhXFcS8kKWRVcIxxdMe3cQ1ldG2tcGq==", "W7zWrSo7W5i4WOBdSWiQWRNcP8kcqa4JW6nWWQtcJCkPnaZdK8kBbq==", "WQCzsd/cHqlcIaFcTY5fWQCUW7xdQmoVigy=", "CrJdJdtdHmo3a8kCWP3dVmo+WRldJCoP", "e1iFWP5yFCkWW4FcNvG=", "W45rf8ooxHyCW4NcIq==", "W5lcLCk8WRqdW6ddSCkksq==", "W6HWbIlcSKXgcCklia==", "W6ehnehcV3VdGJ9AWPhcSW==", "W63dQ2KYu33dMq==", "xmkEh8kacW==", "D8oLW7JdV0hcUCoFWP7dJmooqWVcRmk0", "W4bhj8o3trCiW4i=", "WQldL8kPWRxcICoIW6qfW4hdULNdIwK=", "W4hcPWNdNSkoW51iW6KBW6NdS8ozytO=", "WRujwYBcNWW=", "ySozW6ZdJmkWWQfqW6BdHfeTnCkmW4JcM8kh", "nxacWPmMCW==", "W4ZcGmkPWRqoWQC=", "WQBdNSk3WRZcImoIW6inWOC=", "B8kgWQRcG8kpBCkq", "A8kviJpcOG==", "bNyGWP4wrCktW7W=", "DCkbWQFcISkzBCozWOboWORdOmo5WQ8SrG==", "kcHOcCobFmojdCojz1VdHsldUSkAEa==", "tgxdK3JdQCkUFMK=", "fqhcTCoOW6GMWP7cHW==", "W4ZcL8kPWRqqWRtdIq==", "WOZdGNuuWOlcVG==", "W6fSfIJdPv5ccSoFfxddGG==", "WRpcPu5hbSoTfa==", "h03dPSoYW4brWOTzsSkd", "CmoFWRBdNuNcTCoqW5FdHSolxq==", "zCo8W4pdHmoLWPrLW5G=", "WOpdPWdcV8knwrJcRSomW7BdP8otzaRcGmkRW5RdSfZdN2VdVgPVWQZdVGfA", "WPFdOrxcMSkgdq==", "bM5TqspcReeGW5xdO8kolSotW7i=", "WQFcO0foeCkSd8kgsCoGafNcUmkvnCo0W5ldM8kfxSkwmmof", "WP3dQWxcTSkB", "wWtdTW==", "FatdStNdNmo5rSkrWR3dRW==", "h8olWOfPW6zdtgiddmoopSorpHKpWPP5WRZdKc4=", "BaRdTJZdLCoO", "aqhcTCo7W6CRWONcJIzZ", "WOxdKmk3", "W7S1WQelW6tdQmkwWPa=", "WRuvwSo4WOrXjuinemo6cHaEC8kcWO4=", "W4ddRKy1Ca==", "z8odcftdSSkrWQNcI3FcLM/cObZdVa==", "WRFcKSk6WRyfWQtdJ8kmw8od", "W6JdOxKfeMddK8khWRLBWRSZpIK5", "qaJcRSkakW==", "W5VcJCk1WRWnWQNdMCopFCkFkHddScFdP8oTWOubW5bbjrxdOq==", "wwpdK2ddUCo8BhiGWP04h8oSCMH2WRRdPxHkW41yo3JdTZrvvZO=", "eeFdQSoJ", "wxtdGgxdSSk7", "kJtcKmk5WRFdL0WFWOldNSkzcCkMW6xdKmoi", "amkfW4xcSCkkWQmDg1xdImkLamonhY0=", "bCkaW4ZcG8kbWQ9zmvhdPmk5bG==", "WQRdOKi=", "WPhdSrxcVa==", "EK5vouNdPW==", "W6ddNt03v2NdNSkhWRLlWRS=", "kfpdOCoK", "W5JdHLafW7ep", "Er7dSdtcKmoVeSkkWQZcV8oNWRtdN8oP", "e0RcVmkwbmobqZi=", "WRxcPerHhmoPg8kfqSoJhq==", "f18cWRDtpmkNW4xcI191W5v9ENG=", "emkfW5RcT8kiWRi=", "WQ3dLhvDW4hdSSo7qM8nk8kafmkGWPTL", "ks5UdmoxkmoBf8oJALlcIstdTmkmCCkhrfVcKSoNvrLg", "A0bCoG==", "aNv4tg/cUHuoW4VcT8kkBmo2W77dKq==", "zmkiWQxcGW==", "auZcQ8odamobtd7dTmowW4SF", "W7n2vCoZW5z2WPa=", "WRxcPefsamoLdSklamonea3cV8kpmSo+WOldJq==", "Eq/dObBdHCoWeSkmWPJdRCoLWQVdN8oJlGi=", "WRhcJSkNW7PMW58=", "mCk+WQSTW7yEWOxcG0FdGa==", "WQBcTYSkidJdUmkZCq==", "WRadWPTyzh9w", "CCkkWQ/cISkzBCohWOyhWOFdRmkRW6DJcJu4nCo3W4FcP1WLW7jfWO8=", "WQBdMSk0W7NcMSkJW6eEWOtcUXdcMW==", "WQi1WR1+r0vSWOxdUCo9", "WQijqmk5WP95kHCGwCkUsvG=", "ifZdOComW6W8WOtcJJvYcq==", "Db1XW7O=", "WOtdPrpcTmkndq==", "WQBdMSk0WPZcGSkJW68hWOtdVW==", "awL8s3dcQ1qHW4hdO8kLimoCW7lcNaxcKSkJiauf", "AfekWRbtEmkNW4JcKXu=", "W5BcSmkEWPWSW6ddO8kUzW==", "WPCfrSo8WO0=", "WPtdMmoKWQVcLW==", "DLpdV8k0WO3dPri=", "WR/dICo7", "zmkBWQVcG8kpoCorWOakW4VdJ8oQW6rPrH4/E8oBWOlcVa==", "r2NdNgxdSCkPDJOTWPaWxSoJEa==", "cNj3r27cQLHVW6hcOSkoimoqW7lcNaxcISoMgrivpmko", "WOpdLYBdO8oq", "bmkIWQ42W6HSWRZcSSkA", "aSkJWR4IW6vOWQ/cTSkwWQDp", "wstcPuzYC8onlNFdVa==", "W48jW5RcNhLAW6pcQSovW5y=", "W6hcVr0QjWRdRYzNWQ3dO8k9a8kj", "W6VdOgKveLhdLCkd", "CCkmWRRcTmkzlmoCWQeiWO3dUSoUW7S=", "csj9fa==", "wqJdSdldHSo5", "W4zmj8oiatOuW4O=", "W7tcUq4d", "wSkXkrpcPSkwtmkkcwjqW5ebjG==", "WOPShmo3dmkiWRXHnKlcNWJcLbOlF8kVW7u=", "WPhdQHxcUSofoaBcQW==", "W5VcJCk1WRWnWQNdMCopEmkdmGFdStBdPSoNWO4=", "WPNcOumcrCk8", "tf7dUSk9WPdcIGpdKNZcLCoYWPiOn2BcICkzWPtdQtu1rX7dRCoxWQBcGxBdM8kW", "W7yKj1xcV18=", "WPtdVq/cSSkfeaZdPSoOW6/dRSkhzrxcG8kMW53dQG==", "WRuyxqpcSZlcSqtdSrXvWQC=", "WQSurYBcNb7cK0ldSW5DWRiMW6m=", "e0FcQ8kkw8oHssy=", "z8opW6NdTG==", "tI7cPgfWD8kpnNpdQa==", "aSkPWQ4iWQ1mWQxcSa==", "AWJdPtFdLCk8eCknWRxdS8oVW7VdK8oJnqHyW55vW4JcK8kZW7hcRq==", "W7xcVr1gpGJdOJ9sW6hcOSoK", "ksHJbCorFmkmkmoVz0FdHI7cU8ozm8olaq==", "W6COWOSztmo4curCeXddS34k", "WQFcQ0vhamkSc8kAwCoGab0=", "auRcVSkpe8kavYpdUmkAWO4FA8oWW4qHkvlcGCkiW7VdG8k1u2BcGKLHW6hdLW==", "W6VdU2Kt", "WQZdOLueWOO=", "WQdcHmk/W7nJW47cN04=", "smojaXNdSSkmWQ4=", "WOtdOCk7W7xdKKdcTW==", "FKrpcuhdRfpcHG==", "W60+W5ygs8o+crC=", "W4hcPWNdHmkaW5jCW6a=", "WRtcSIWFDbNdQ8k3nxeYWQ0UsCoDyMre", "bCkkW5ZcUCoaWODuoq==", "W6K+WRKhWQFdNCoFWPLLW5tdO8ojWQq+W5iGgW==", "WRFdKmkKWQddJmkYW6icWO/dR0pdMcJcSum=", "wwxdHKddNSkfvhWVWOi4sW==", "W6hcVr0LjWxdOtG=", "W6mHmx/cR0FdMJDNWOBcRSojyhFdGYK=", "W5bGqSoLW558", "W4JdIfCaW7GEWOxcGSobba==", "W4hdIeyhW6DBWOu=", "W6G+WQmnWQJdN8kAWO8=", "umk9mZBcPmkaqmoghw9CW4KdmtelW4FdN8oxsCoFy8kN", "W5tcPXRdU8ksW4PmW7CiW6tdVSomzIL6xq==", "W7xcVr0JjGJdRczsWQu=", "AKjukLq=", "qSkOxmoMv8oWWQeEgvfo", "WRldMSk0WO/cJCkUW7Go", "W6pdJdLRW73dOSovqSknWOVdLG==", "cSk0WPSnW6r7WQK=", "W7vkmG==", "nwCFWO88", "twxdHLRdVCkWBN8=", "fSkuWOO=", "W57cKmk/WPKsWQ/dISklx8kDka==", "yWXXW6hcLSoJWPW/q0iafSkZW48vW4BdV8oeE8k/W6y=", "W6K4WRqoWQhcICkiWPvLW4VdSSkiWQiYW5TKuGBcM8kCn8osy8k6WRfQW5u=", "euBcSCkfh8oh", "WRJdLSkUWRdcGCk3W6blWOxdUL3dMI7cUa==", "sSkugmoueSo5WQWEgufoW7PwWQpdPW==", "W5/dGLy0W7uxW5dcKW==", "W7eGovFcUv/cJJPkWOFcTCoyANVdKwDN", "ceFdP8kWW5PvW4DytG==", "WRuyxrNcKaFcIWC=", "tfJdR8kuWPVdIXBdLNdcNq==", "W7NdQ2KQu3ZdICkl", "fmkgWOGVW4rdWOVdVa==", "ySoQW5G=", "xmkAdSokv8o9", "CrSWW7NcKSkXWOWYxL0=", "WOBdJmkNW7NdNmo6", "W68So13cQaVdQdDBWPhcSG==", "CSoPW7FdSGZcVmoDW5FdHSoBxqNcQSk9vG==", "W69ljW==", "W7n8fHxdT15ckCkznwRdN2S=", "DqtdOd7dGW==", "s2tdLKRdS8kYBW==", "fYKShG==", "W7NdRxWqvZddI8kgWR5dWQ1WnYOWumkNWPJcRaJcIHtcQ8knW7SMzX7cIsC=", "WPrOf8o7dmoCW5DtkG==", "a8kbW5ZcHSkmWQPimq==", "DmoPW7hdS1O=", "y8knWQRcTCkqjmouWOSCWQldP8o/", "lJ3cN8kWWQBcJG==", "WOPOfSo3t8k0W7LxnW==", "tZNcOw9ZE8oBmq==", "E8oOW7FdPLJcPCoeW5VcImoUwX7cPmkIud5zW4i=", "FqxdPtNdNmo5rSkKWRJdVSo6WQ/dKSo6peXWW4vgWOFcGSkXW7FcSbq=", "mJldLmkMWRRcMe1rWPxdMmkfamkTW6i=", "mCk4WR4eW71FWPdcH0VdId/dNh/cUCoiB8o+WP/dHCo3jhq8zSkwW4ddNmkwW7pcMq==", "W7G0WReBW6tdMCkqWPrIW5pdPmolWQSXW5i=", "WPJcVZ4Czrq=", "W4rGmSosssSrW4BcHhxcNq==", "w0JdUSk9WPZdJWC=", "WO8bWOTuEa==", "e1qzWRjgAmkH", "WPdcPuXddCkSc8kgt8o4", "WRyPESoCWRTzcG==", "raPZWQ3dIG==", "W7eGirlcReRdGITg", "meFdQSoYW4vAW49EDmkk", "WRldMSkUWRZcNSkJW6e=", "qCopaGFdTSkg", "AmoNpZpdLSkWWPxcT0m=", "WRaiumorWOzSlqC8", "W5lcOW/dTCkeW4O=", "W57cGCkVWRjaWRpdJSkaqmokkWVdVti=", "iCkbW7jFWQ0=", "fGxcRmoFW64VW4VcRtvYcCoSnmkIW6u=", "W4NdOxmFu2q=", "W4tdGKmgWRqlW4RcN8ooafrYW44TEq==", "tf7dUSk9WPdcIGpdKNZcLCoYWPiOmw7cImoqWONdPNOSxvdcQq==", "hW3cR8oxW6q/WOBdGID2fSo/oSkJ", "CGb0W7tdK8kZWOq+rfOwvCk2W4Wf", "WR3dLSkKWRZdJmkXW6ueWPxdQa==", "W5dcTxaCywWNW6jLWPPx", "WQinuSo8W4LqiWmH", "WQhcLCk7W7vHW58=", "WOmdqCo3WO0=", "jSk6WRijW78AW4FcOftdGsJcJN7cSSob", "wmkSltpcPSkCwCkv", "W4TlpSoiwa==", "e0VdP8oYW4nmW45E", "WO0fWP4=", "tSkGlZBcP8ks", "WQCztqFcNH/cLqFdRG==", "sCkyh8oyqmoOWQao", "W70+WQe0WQ3dJmkiWRXIW4ddU8onWRK=", "W4GvW5JcLNL6W6xcS8oaW50=", "sM7dIW==", "WP1MbCoWa8kzWRXcmLm=", "e03cVSktaSojvI7cSCk3WP5lBmoSW4SQmfK=", "tSkmWQdcGCkijq==", "W49lj8ocrbOtW4tcMddcO8kfcufNfG==", "mb3cVSoI", "W6D8fHldOvPCcmkEpNW=", "WQhcTZ8izqq=", "v8khFrtcRmkmt8kpn2Pc", "WRauWPTyEMW=", "cNP+r2ddV34QW5W=", "t8kxe8oowq==", "rWJcUCknzdfzecCk", "ymoNWQxcTSoW", "WO/dHgfC", "Aq5NWQ3cNmkLWO0Kt1O=", "ACoPW6ldK0lcRCoqW5ldJCol", "i8k/WRS7W7qwWOpcILddRttcIa==", "mdpcNCkWWQhdLW==", "yCopaHFcVq==", "W6dcUqid", "eqVcR8oyW6aT", "WPBdTSoPW6JdG0BcO8kRW4Dw", "W4ZcLCk9WRHaWOJdN8kova==", "k20EWPu6nh/dGbJdPMu=", "pJrHaCoFyCopx8ocB0pdIIJdUSkxCmko", "W7SJW5iVsSo2hWHDeG==", "wqZcQSoeCxb+adS=", "WOldPqBcTG==", "aqhcTCoSW6WRWOFcRsvXcmo7kq==", "WQierY7cNalcNuldNWzeWRaPW6FdPCoJnq==", "uSkCWR3cJG==", "W7NdUM8vxhC=", "vrVcSW==", "amkDW7DwWRG=", "yebmF0/dPKdcKmo1lq==", "W4HmtSoFW5j5WP3dRWm=", "xSk7mZNcOmks", "WQhcGSk7W7v/W4ZcIq==", "WQCtxsBdNcRcLW8=", "W4ndpSoasX5DW6JcI3xcNCkyb0jN", "mdxcL8k8WR/cGLrrWPxdNmkBgmkKW6q=", "mmk6WRGn", "y8oNW7PbWQ0TW6ZdVCouW6GxWPhcV8olWRD1W6X/danhFw57WQdcKsZdMCkpB8klW6xdLmkSWPvKW4LdWRXeyeNcQmkHfSkxp1tdHCooWRi7zhBcOmonu8osgqSsfmo6W77dHWarW5aNmd9qWRZcPSo5W514oHxdSSkDba==", "md3cMSoKW6i=", "WR3dNNznWPldTSoXwuiynmkpf8kTWP0=", "ACoVW7FdUKNdRmofW5BdGCods0RcO8k4vZqjW5rpqSkvB8kiW4y=", "WRldMSk0WO/cHCkNW7OQWO/dVfZdNJO=", "W5xcPXhdT8kcW4OjW6eIW7BdPSobAIT8", "EevFdeZdQulcHSoIemkfea==", "W7aKmLC=", "WRqurmo1WOzXmHe=", "wwhdLgNcVmkuFNSTW5esuCkKvMfR", "avKFWRiBxCk7W4y=", "fvKyWRHzBmk3W48=", "WRCEuCo8WPPSjWWHwCoicbmApCkUWOv8W4ubWO4=", "ACoPW7RdS0/cUmksW5RdGCoCwGVcPCkYvNe=", "W4pcUG3dVSkoW5DDW7y=", "WO1OaSo1cSki", "iCkyWOW4W7qEWP7cILa=", "W5xcKtRcOSoz", "W5BdSeJcOG==", "nM0dWO4NEa==", "tJtcSg91D8oC", "WRlcOuThvmoOdCknsW==", "W6lcOqChjqddRwP6WRtdRSkWd8kleSkCvXm=", "W6S2hv3cRKddIYDIWPFcTCoqCN0=", "wslcSg95mSoykNVdTcCZASkLEmotFCo2WRCVW6lcOYTlqSo9fa==", "auZcQ8k1f8omvs4=", "WRNcQu5nbSkSpSkhwmoPfG==", "WRJcSSoPW5DQW4hcMfxdKgyG", "kCknW5VcO8kYWQvvnu3dJSkY", "W5tcQwCBl2y=", "WRuyrsRcKH/dNIVdUqTzWRaGW7ldPmoYiYn6DCowuW==", "W7n8fGVdKgzHamkzihZdJG==", "x8ktgCodeSoKWQOze1HA", "W5xcP8o7WPyfWRNdMmkgxSkonq==", "kq5omSkaoa==", "WRxcPerXgmoLhmkluSofcW0=", "WQFcPvqcaSoTfmkBrq==", "Dq5IW6hcISoJWRWYs14kwmkK", "WOusrsdcGXG=", "vfJdOSoXWPtdMqFdK3lcL8o6W5CUla==", "nSk6WQ0pW70l", "WPpdQW/cTCkbhG==", "AW7dQd7dK8oOrSkYWRNdVSo6WRtdLq==", "W5VdJ0CmWRqzW4tcN8on", "W6ZcI0KTlrddRcnzWQxdSq==", "W5tcUhKxiNvUW5TKWPzaWPZcOa==", "W4FcPHNdMSkoW4PcW6aY", "W6uNW4edr8k3nGfbvJFdS2am", "W416u8kTWPC=", "k8kOWOKjW7qwWOm=", "W4/dIeWeW70C", "W5RcJmkVWQ8b", "W5GQW4CtqCoLiGXnbbC=", "c8ogWPPkWQDYxNuf", "W4/dHSoUW60=", "WPpdU8kNW73dJ13cP8oUW7TmhSk+W7FdOXZdISk/", "W4VcOXRdU8kcWP5IW6aYWQxdHSozDc0=", "WP1OhCoZcmkzWRX5juBcNrxcK15o", "oqxcT8kuWP/cVNO=", "W6f3fI7cV35hcW==", "bCkMWRee", "W4dcUge7l3u=", "pYnUaSoEBCkmmSoJAfJdM2ddNCkqA8kouG==", "WQBcGmk7W7TQW4W=", "FfldT8k+WOFdMq==", "W5KjW5/cJtzL", "W4WyW5ZcLtzGW7lcRW==", "oG3cTq==", "xSkEdSoju8oNWQi=", "W6rMu8o4W4b5WP3dT0SaWRxdVW==", "WQi/C8kPW5e=", "W691W7uTfq==", "xa7dTZ7dGSoOrSkaWR3dUmoMWR4=", "nKZcS8kcd8kauYpdVSkc", "WRNcQu5lgCo5fCoormoTcbJcT8kz", "CmoEW7RdQmk1WRLx", "WOfeqCkIxSoi", "WRuvrJJdKsJcIXddPqPEWQCTW7/cQ8oemw5pA8od", "WRadWOHDCsTsWR3dLCodWQ1ig8oVAvnHrdNcHcfPjM00tSkBqmo0tG==", "nYXOcCorkmoNgSoZ", "WRidwSo/WOb/", "WRRdQ8k6W6/dVvFcRmkVW51gdW==", "cfBdOCo5W4jt", "tSkXkrRcP8kut8kkpgO=", "DqldQJldNCoPc8ofWRJdVSoNWRRdNmoP", "WQBdNmkHWRxcICoIW7OdWOJdT1xcMYhcTeirW4BdNSorW5XvFWX6fa==", "a2j3t27cTLzVW6JcTSkpnCoEW6FdKYpcKSo3", "WQxdPhHF", "W4JdHK8dW7mEWOxcUCowevvJW4yLEq==", "W5K0WRKnWRBdMG==", "W7r4ecddT0S=", "W6H6sCo+W5PTWPZcUY8NWRhdPSknsKiiW7X7WRhdN8kImqa=", "D8kKWP7dKSoj", "W4ZcL8k6WRefW6ddJCkhwCkgi0tdSt7dRmoHW4SgWPH6kbBcPcS=", "W6FcTGNdS8kcW5vmW7C=", "oJNcJCkdWRpcM0Wu", "ceFdP8oCW65TW6rltCkam3u=", "oYLUemogyCoAgSkQr0ldNs/dQmkAFmkBra==", "WPxcSfbodq==", "gKdcU8kgvSosrsRdVCowWOPrzmoZW40=", "W6pdHdbTW6ZdOSoytSkm", "e1ZcQ8kmvSotqYtdOCkt", "WR7cKWbPeCo1gSkhtSoOfG==", "W5NcLCkWWRG=", "AKrpcuhdRfpcHG==", "sYxcTvbWE8olj2ddKsXN", "W48fW43cJsX7W6pcRW==", "WRlcOuThvmoagCkj", "W4Plimoc", "WP1WhSoZaSkvW78whLBcGXpcK0PenSoHWQe=", "lIHStCkl", "W6fwyCowW6juWQu=", "WR8CxM/cNG3cMbhdSHS=", "W5/dNKWbWRq9W4tcNCofvgH/WO8kEwa=", "W5JcKCkVWOSbWQZdJ8kk", "e1qkWRDtpmkLW4pcKvb/WOv8Cs0ZhSoVWPpcQWdcUmkIW74=", "WOpdOq3cTSkldu/cKCoaW7VdSSkCyG==", "DWP+W6JcGCkIWOC=", "WRuvwSo4WOrXjuiidmoIhrepCSkiWOuO", "y8khWRRcJ8oCdmozWOm=", "WPtdRCkNW7RdI1m=", "WPpdQ8k7W7NdGudcRCkHW51w", "WRddKCkHWRVcGmkNWQ0MWOddVfNdMgNcLKmn", "W7n4bclcSNDlb8kBC03dG28j", "WRxcHmk9W4PUW5tcJ1K=", "W786WQCoWR3cICkOWPHTW5FdUmogWRK=", "BSoCW6/dQmkMW61VW6RdUqmwpmkyW4i=", "ySoiW7ZdRSoLWR5qW6ddSamVkSkmW4i=", "WP46i8ovxG==", "CqXZW7JcGCkIWOGU", "z8oeW6BdOmkOWQrhWQ/dJvyUmCkbW5FcG8kaW4ddOa==", "WQhcRKXnfCoO", "bConWOP3WQvHtx8dgG==", "w8kEcmknrmoOWQ8ceHuD", "tgJdMCkfWRtdQcVdT1lcQW==", "W6SCWOTDeq==", "W5xcTCknWPWZWOpdQmkMymk+", "s2pdKxNdRSk9Egm=", "W6FcVa01pqVdMITv", "W7CYWRSlWQNdNmksW51OW4BdUSojWQ04", "W4BcQgeDyxi6W6nXW5DDWPZcQNq=", "ACoPW6ldGe3cOmohW5S=", "WQ4bWO5yDYTUWRddHCkpWPWra8oL", "WRCfqSo8W4LliXqGfW==", "W40+WRqsWQVdH8kGWPTLW5xdSG==", "fH3cR8oFW6qJWOJdGG5If8oQnmk2W6/dI8oiWOC=", "W4qjW4lcLISPW4dcTCoiW53dNa==", "WRadWOHDCsTsWR3dLCodWQ1ig8oPyviOwtBdIZHZAa==", "WRdcJSkTW6uVW4JcLvxdKhyGWQjUa8ow", "W7eweGldOG==", "W652xSk3W5zRWOldSGWOWRhdOSkewW==", "orCIv8kh", "W6/dIe4nW6yi", "yYXrW5/dGCoZ", "wstcVwz/zSkpfxFdUtj8BmoQnmkxnmk4", "DmovW6hdRCkGW61nW6hcOeiRn8oiWOC=", "WQqmWOzsFW==", "sg/dLNxcVmkSDhmNWOuUxmoLCwe=", "W4JcNmkYWRefW6ddJ8kbq8kjkrtdVdpcQa==", "WP/cRKLeeCotc8kBuSo6da/cSCkqdSoZWP3dN8keva==", "WRabWO9unenaWRtdMa==", "gKZdP8o5WOf1W4ja", "xsNcUg95mSoAlghdUY1Jz8kU", "fKpdTmo5W48uW6biuG==", "WQlcImkNW7T8W4JcK1FdMYiCWQ8VjmowW74=", "W6VcTW0do0K=", "W6JdIfapW7uvW5e=", "fhH4qMBdV0iNW4ZcR8kgyCoFW7JdKc7cLCoTdeaEoCkcqCkWWOzG", "f8kbW5ZdSmkBWQDriuBcJCo3", "WRhdPXxcUSkEha==", "W7n6aYVdTX9zdSkwp3ZcMNCfW5jIW4Phu8oExv/cSW==", "W4epW5JcKJXWW7xdVmoCW5hdNcS=", "rCkAg8oeuCkPWOGsdG==", "WQipw8oSWP0=", "W4PlpCoiqq4qWOFcMxhcGSklcum=", "s27dHMxcSCkDCNC=", "vGzIW6JcLW==", "qXX3WQ3dG8o7", "dCowWPPXWRfHvxXrl8ojmG==", "W5ndiCogsq8=", "FK1upeS=", "W6msbq==", "pdJcMmkLWQBcNK8uW5hdVmkddCkSW7lcK8khWQnG", "WP1WhSoZaSkvW78wg0RcMWtcKLTfpmoQ", "WRqiWObDCsTmWRVcNmooWQeAu8kG", "WRpdMhXr", "F8odbthdVCkdWRJcJNxcNa==", "tNNdNg3dSCk1EdObWPGPxmoSFgPXWRy=", "WRzFz8oEW5G=", "twxdHLZdRSkZAW==", "WQBdI8kHWRFcImkRW6mm", "W6f3fI7cSN5hcW==", "bCkhW4VcPCkFWQDElq==", "W6BdJdnHWQ/cSmo2sSkzW47dHcNdRmk4W5e=", "W7xcUq8dAchdQYTtW6hdJ8kRaSkEdG==", "WRhdISkHWRxcHCkNW74=", "cmorWO9P", "nwCrWPyTne7dGqNdR3mwWORdPfxdPgpdGt0iW41egSol", "dSkOWR4eW74TW6ZdVCou", "x8ktfCobv8kPWQOzv1ruW6Sx", "WQujv8k0W5a=", "lIX9b8oxFa==", "v1tdR8kYWP3dIXRdMxa=", "CCkqWQdcHCoCc8orWOulW4VdHSoLWQ9haYG=", "pdJcNCkrWQdcMeKvWP7dISky", "WRhcRKfagmoPwmkQwCoIbbtcUCkFCCoCWOFdHmkzwmkslmkmpmkC", "W49ln8oedaKyW4BcKtdcJSkecuPN", "WOtdP8k9W5NdJfxcPSkIW5zb", "W4VcQXpdU8kmW4TeWQuVW6tdV8obyY0=", "WPtdVq/cSSkfeaZdPSoOW6/dRSkhzrxcG8kMW53dQHVcQ3/dPwe=", "WRhcSYWiBbu=", "h0JcUmkkfCkasY7dQa==", "t8kXoJBcUSkbsmkugM9DW4qgnxiV", "F8ofebJdTSocWQ3cINNcLgFdPrRdP23cNmkIxmoAqSoTcGNdT8oJWQbdW5i=", "W67cSr0fiaJdOcLs", "tf7dUSk9WPdcIGpdKNZcLCoYWPiOn2BcICkzWPtdQtu1rX7dRCoxWQBcGq==", "AGRdOZ4=", "W7JdQ2StxMBdMCkC", "WRzphh8=", "W6H8aYpcSK9bd8krj2RdMx4aW5m=", "WQapWODxFwW=", "W4NcLIrJWR4=", "WRafWP10EMPhWRNdMCol", "yZXxWR3dIW==", "aCkOWR4yWQ19WQpcTmkAWRXeW5ldVSkhW7i=", "WRdcGw5LmCoEn8k7CW==", "W7S/W4Gjbmorha9DvIZdPdaIEGK=", "dSkUWRqoW78TWORcTmkmWQ1e", "W6mYjq==", "xKJdR8k+W5xdMqddLwxdMCo6W50Kpq==", "W7SUWQenW6tdMSklWPj8WOFdUSohWQ44", "tSkXkqNcQmkzwmkd", "W4lcVgCEoeWHW6HK", "WRlcSZK8yWldUmk3E2mUWQmK", "W6RdNdLLW6lcQ8oWc8k4WPVdItpdOSkKW5S8hCkY", "WQCtqclcLX7cNqNdSH0=", "tf7dUSk9WPdcIGpdKNZcLCoYWPiOmw7cImoqWONdPNOSxvdcQCkA", "hG3cRmoxW70=", "k2SuWP87nbK=", "F8odbsldSSkoWQ/cHW==", "W5RcMSk6WR8mWQxcMSkIuCknlWFcUrZdRCo9", "BMbPewNdJMhdGG==", "WPnijSotpmk/W45/a3C=", "W7SYW5qdsSoW", "nvC3W4PW", "DqldQJtdGSk8imkmWQtdUSo5", "rGZcQSoi", "zWD1W6pdK8klWQ8=", "fuZcQ8k0e8obuctdVW==", "l8kYWRebW7ukWORdJ2BdHtFcNxdcS8kermoHWPtdKmkLihK3", "WRuEscpcLeVcIqRdVGnvW7mPW6/dR8oLChbgy8osrConW5S=", "W43dIvylWRq6W4ZcMW==", "W5frfa==", "zSkCWQ/cISkvkmod", "pYnUaSoEBCkmpSoUz0FdNsNdRCkCm8kQvfVcNmoKfLywWOS=", "aqFcS8oxW7K+W4VcIZDYfSoT", "WRefWO5yz39aWQFdV8ooWQqeeCoHzLW=", "WPldRmkOW77dJLhdPmkkW5jic8k6W7RcOJ3dN8k/WR8Llvbc", "W5Cqy8krha==", "tf7dQCk4WOxdNGC=", "W47dQ34tsW==", "vqRdVa==", "dSkUWRqiW6b4WQhdVCkqWQLAW5ddUmko", "W7WYWQmhW6tdUSkAWOTPW4K=", "WQBcSZK5yrZdQmk3", "WRZdNNXsW5VdOq==", "FaRdQtRdL8o5rSkQWQRdUSo4WQNdKSoOpa==", "W6NdObLbW53cG8oF", "e0VdP8oZW4rvW4votG==", "t8k1oJO=", "WPNcJ8kGW7PQW6FcMeNdINy2WRnPa8ok", "WRuyxqRcNWRcNa7dSGS=", "WQaptcRcGH/cNWZdSW==", "WPJdOqdcT8oicqdcR8olW67dSCkqBqNcIq==", "D8oJW7ldS1/dRa==", "Fq53W6tcKmoJWQaYuW==", "gKBdT8ouW55BW5Tjrmkeoa==", "cSokWPH7W6ztxgyubW==", "WQa6W4qgiq==", "WPBdPSkTW5/dILhcP8kLW5fkeG==", "y8o6W7O=", "W4bhpCoexHOr", "cSk0WPioW7LMWQNcPmk1WQTdW5JdQCko", "W7z2u8obW5z0WOtdVG==", "W5lcM8k/WRGtW6dcMSop", "wfJdR8ksWPNdIWFdIvVcMmo6W5C=", "WRtcTs4ACHhdVSkR", "h0JcUmkkfCkaAY7dQa==", "W6v2bNxdQW==", "WRxcRLrlwConeCkd", "W4BcVNyhm2aTW7u=", "cmoAWOb/WQTPwJa5amoukCovjLCOWP4=", "j2OeWPnOvvddHa==", "WQ4jWODyEx5iW7xdUmooWQujfmoLjxH+tYZdLIvKlq==", "W4XhkSkbtqGoW47cMN7cGSkpafi=", "k2uxWPmRnhldJbNcO0jpWP7dRG==", "vmkNfJRcSmkLx8kdkN1uW4W=", "ntxcJCk2WRRcLLCsWPq=", "W6PPW6vsW7q=", "j3iFWPmSnfBdNWxdSxPxWP4=", "rmopbq==", "W6/dOhWExNxcNmkQWRzcWQK3oMutqSkRWOtcUuhcGXG=", "WQivWP1EngHkWRVdMSogWQ8=", "WQBdNmkYWRdcNmk2W74=", "WP97fCo3hmkiW71ynWpcOaNdMNfojG==", "WQipvCo1WOW4mqOSfCoRsraqCCkfWOiYW6LeWPOjg240WOi=", "WP3dRq/cUSkfdaldPSoHW7VdR8ksAWddJmkaW4xdU0NcJw/dSwe=", "WRpdKgzrW5ZdPCoN", "W7NdRxijrG==", "WRldKhvDW5hcPSovvvu=", "c8ogWPPsWQLJwhWHbCobm8oynq==", "EevFf0/dTe3cHSoP", "A8kuemocqmo6", "EmohaXpdTSkw", "FItcSImL", "agGrWOKGDLJdHWC=", "WRtcSIKSAbxdVSk5D18/", "W5xcPWNdL8kpW59lW6KUW6e=", "wwxdNMNdV8kOo00SWPaTumoQ", "W6j2sCoYW4v5WP0=", "W5OfW5JdMs9OW6RcQCovWPG=", "umk9mZdcU8ovA8kpiwTc", "dv4fWRjBACk/WOVcNf13W4r/EW==", "W4K4WRqqW6tcM8op", "W6v4ecVdQX95a8kEi3BdLgW=", "WR/cHw0KzqNdV8k7E1q0", "xSo+W7FdOx/cUmoaW5FdHSoi", "W781WRqaWQJdJmoFWRL1W4NdTSofWQm+WPDiuHZcN8ounmoDACkY", "W64NW40p", "l8klW6O=", "zmkoW5VdHSo0", "c8ogWPPqWQDTxa==", "nweeWQWPEeZdJa==", "cfikWR8wBmk9W4lcLKHPW4z5CJ0=", "WR7dMSk5W7NcJCkXW74cWOBdTv3dNIFcQq==", "WPRdRCk/W7NdJ1hcQSk6", "W4hcPWNdGCkvW4XaW6SS", "ymkscmkxeG==", "kmkiW78JW70gWOxcHKZdGcK=", "F8oLmcBcOCos", "fuqoW7T1ACkHW5/cL1e6W619FZXXiCoPWOBcPHxcUmoeWRfODCk4xKvfWPlcVCoEFfW=", "W6FcTH0pAcJdPYC=", "cNq/", "WPFdOq/cTSkAgam=", "jgSuWOnOzfBdGa7dT2vvWO/dP0u=", "W5DlimovqXC=", "AKrpgK7dOutcJ8o1pq==", "WQCfWOHwEg4=", "W6f9bGpdOfbEaSkqjhC=", "wcdcTMy=", "b8klW4BcTSkeWQe=", "W612bIldOr8o", "WOldSCkSWRZdOuhcT8k6W5XisSkvW7RdOXBcICkjWQ42kfehW7ldR8kMWQ3dUrJcP8k4WQTVW4Dvyq==", "FW7dSbFdN8o/b8kjWOZdS8oRWQldNSo+", "jSkIWRejW7uwWOtdJ2RdJs7cN3/cT8okAmoY", "WPFdMgy=", "WOPWhSoXt8k6W71DnGpcOaNdMNfojG==", "rW7cRmobD3bcdsTgW5hcMMHjW7lcI8ohW6jxWO9D", "W5RcMSk6WR8mWQxcMSkRuCkhjWpdVhFdH8oYWO4hWOj8oaa=", "tf7dUSk9WPdcIGpdKNZcLCoYWPiOn2BcICkzWPtdQtu6tXNdPmkAW6hcGxy=", "W6FcUWOtoGJdRtm=", "zmoyW7ZdL8kKWQfrW6O=", "FSo1W7JdT0hcPCorWP7dOmogwGNcO8kWxtjm", "sCkFhCoDrSoGWRusv3riW61yWRZdOCk8WRZcNG==", "W77dQ35rcW==", "W5lcM8k/WRGtW6a=", "rYJcV2XUmSoPk2RdVte=", "W6mRivVdT2RdHZm=", "W4lcOXddS8kgW5SjW4O9W6ddOmosBsX8", "W4VdGLy1W7eAW5xcMCoo", "W6W+WQCgWQxdH8kE", "wwxdHKNdSSk9ExySWPu=", "ah53s3hcVLK=", "Fe9ApuZdPqBcRSo5n8kefSotWROpW4b6fa==", "W48pW57cMJWPW7xcVCowW53cJY9+ymkjWQS=", "W74IWRSdWQNdGmkCW51bW5ldU8oCWQmTW5HPvrW=", "W7eGixFcTeRdJdjgWPa=", "W7SLW4CgqCk3cGXrgGBcQNGaEXxcL8kHob7dUCoq", "WPhcM8o+WQKVW5NcJ0JdKq==", "zmodhqtdTSkqWQK=", "vCk9ktZcOCkuq8kfpa==", "rWJcUCoOFdfxcsDo", "Fb7dPtFdMCo5fq==", "W6KIW4iSs8o5cq==", "W63dQ2KWxxpdNCkcWODdWQKPoJC=", "bWq4WPWh", "aCokWObXWRqGF3Kjdmot", "W7xcMYG0ELK=", "WRW0WQTYs0H3WPddVCo7WO03pSopu3i=", "WRpcPcGkCWtdVmk8CrabWRGQx8kEqNObWRKChG==", "WQCzWODqEwjgW7xdTmogWRWlg8oHA1rT", "nexcSmkmba==", "WOpdO8k7W7VdH0a=", "walcUSoiyhbxcIztWPtdG21rWQFcHmoeW6ng", "WQhdMSkJW7tdLq==", "WQSCtIBcKKVcTqFdRG==", "WP7cUcqjzs/dVSkHzG==", "aHVdQSot", "W7OJW5afsmoHgby=", "WQ4pWO1uzYSf", "WRlcSZK9zr7dUCk3z381WRaMu8oq", "WQZdLgz4W7ddN8orvKOFiSky", "WRpcHCkTW49JW5hcNLNdJeS9WRu=", "cCknW4BcUCkaWRnqDgFdJmk6e8odhMHYaIJdU8k7kSoOjq==", "hmkrW54UW7y=", "ACkmWRFdHSkDpSodWOCjWOxdPmoUW6f4", "WQmnu8o8", "WRdcQvndfSoGhCooqCo5erBcP8kDpCo9", "tf7dQCk4WOxdNLtdK2hcNmo6W4e=", "rW7cRmobD3bcdsTgW5hcMMrjW6VcJCocW6LeW45aW7eyCSkHWOS7", "j8kJWQSnW7yBWOlcIWldHJVcN3ZcOSowASo0WPRdI8k5lG==", "W7n8fGldVf5mcSkAnW==", "WQaiWOzEz24fWPBdK8odWQCA", "yW52W6JdK8klWO42tG4Xt8kNW4u=", "WRJdNx1xW5K=", "W7OtW4VdMwKX", "aSkPWQ4iWQbmWQxcSa==", "yCkgWQdcGmkvkG==", "WRaJWQHJjJS=", "WOpdOrxcHCkjfrRcOW==", "WRRdN3nwW57dO8k+FuuckmkEvSkhWPf2W7nz", "za5IW6RcLSk3", "wxNdNg/cVmk6ENeS", "W4pcVhGtjMrUW4n3WPjcWOhcP3xdOW==", "WQFdNSkNWRW=", "W5xcTG/dU8kpW5K=", "WPBdT8k9W7pcGKFcSmkHW4mfb8kYW7VdPW==", "W6fQsCo2W5PXWPlcUYyZWRddS8kdxW0UW6rQ", "WQFcSZSaBaBdUmkG", "ubtcO8omFZLwrqPdW4ddMwrhW6NcISoo", "bM5TqxtcVLKJWOxcHCkkoq==", "FSoPW7FdSudcQq==", "W7e+WQXcWQxdMSkmWPrRW4NdUSonWQqP", "AW7dSa3dKCoWe8ka", "gmocWPX5WQn0", "bLyaWR4wEmkNW4JcKW==", "W5RdGKKwW7SjW7RdHW==", "yCkBWQVcH8kikmo9WOeyWO4=", "W4aoW4JcKdPOW7lcS8ocW4S=", "WQ4bWO5yDYTUWRddHq==", "WQFcTfjlgSoR", "W4RcP8kl", "W703WRObWQ8=", "k20EWPmLyvtcIqtdONTxWONdRG==", "W7zWrSo7W5i4WOBdSWiQWRNcP8kcrGyIWQPTWQVdGSk/jKxcNG==", "W5lcNCkOWR4=", "W5lcNCk1WRisW6ddVmkgsmkpnq==", "dCoaWO1RWRrHwMK=", "W6JdGdzWW7RcSmo2wa==", "W7eXj1VcTeW=", "dtdcG8o9W5yFWQxcRGXwpW==", "WRhdHSkUWRJcGCkRW65lWQNdSKtdMchcVeGxWOm=", "WRNdMgrrWPldLCo7rKKc", "auxcVSkAe8os", "D8oCW7RdPSkGWRK=", "CqxdOdldK8o9eSkkWQ7dRa==", "FSohfHe=", "W4Pdnmoit1S2W4lcHa==", "WQqfWODuzMPj", "fKVdVCo5W4fbW4ynB8kso2a2WRpcSmk1b8oXWRldMSoRW5tcIq==", "W5WoW5/cMJz5W6pcUa==", "iM0cWP8RyfddHG7dSa==", "fmkVWRmnW6GTWQxcS8ouWQLEW4pcVW==", "W6FcJZK=", "mCk4WR4eW71FWPdcH0VdId/dNh/cV8oaBSk3WOldISk4pw5YiSoB", "W43cLCk8WRG=", "AW7dShVdHSo9cSkqWRNcV8kQW7S=", "B8kgWQRcG8kpBCkqW44=", "W6mRivVdUMRdHZm=", "WQupWPTsCunaWRtdMmoUWQefqG==", "W63cVu47aW==", "rCoCW6xdOmk2", "W6PszSkbxX8=", "W7xcVqudkX3cRH1sWQddSSkRca==", "WPHTfmoFgSkqW6HFf1hcGbFcNLvCmq==", "W7DXcYVdTX9BcmkmmhBdINOiWPyN", "W6ZdVhGzqwtdNCkaWRmpWOC+FW45tq==", "W4GvW5JcLNL6W7lcS8oaWPJdGJb1Ba==", "s3xdHMpcVmkVEhu5WPq=", "psHHbCoaACoa", "eWdcPCoTW6uJWO/cHZfEfCoQ", "WPhdQHxcUSoioaBcQW==", "i8kUWQShWRGmWOtcGfldGq==", "W4zbmmouxHOEW54=", "WQhcHmk9W5LHW5NcMfddM2y=", "AKjjnLddTfu=", "WRVdKh9vW5xdO8k+F1OjnCkEh8kLWP0=", "psH7lmoDA8one8oAALBdKcxdQq==", "tIdcVgj7D8kpdwtdVtbHA8kUCq==", "CCkiWQJcG8oCbCovWO8kW4VdHSoLWQ9haYG=", "u17cNSoQiW==", "W7CYWRSnWRBcICk5WPr0W4ldPa==", "DqRdOZldK8k8lCkaWQu=", "W4dcRq/dSCkeWP5lW6OVW7ZcSSobBsu=", "tf7dUSk9WPdcIGpdKNZcLCoYWPiKn3/cJ8kCWP/dUNqO", "W6yKofpcVu7cJHfvWPhcS8olBxZdKq==", "W4eOW4ipxmoygW==", "W7eMnf7cVWVdMtzkWPJcPmkzBhhdKcjNdSkyWPDMWPyqWOdcGq==", "ACoEarJdVmklWQ7cKq==", "WRVdQGJcTCknjHS=", "iweeWQKRzLZdJa7dKh9mWOS=", "WRJdNSkNWRdcJ8oIW4yoWPG=", "W640W4mpv8oJhaPCvIxdQ3SmpZ/dMCoYgXtdTa==", "W5rbmSonsvSkW4/cLhZcISokcKL3bK3cHmkiemo+", "E8oOW7ldM1NcOmogW5FdRmoDqrRcR8k+rd8=", "uWJcUCoHFtnucrjgW5xdG2Lu", "W4ywW4NcIYTGW6lcUCoJW5ddHJLL", "WPBdRrFcTSoikGRcSmoaW7q=", "ualcUmopFJuvesnA", "fhH4qMBdV0iNW4ZcR8kgyCotW7JdIsJcKmoMhWem", "E8oIW6ldVWZcJCoBW5m=", "W4VcOXRdU8kcWP5IW6aY", "z8khWQ/cHmkqkmkqWQ8aWP/dOmkMW45LcW==", "WQ4jWODyEx5iW7xdMmooWQujfmoL", "W6fVds7dTH9bemkAixxdM28=", "WRhcUfbog8oLdmkD", "WOFdRaJcV8knwrRcQmowW7NdRCkdAqhdJmoV", "tmksdSoiuCo9WQOyguy=", "W6NdOxmAw3C=", "tu5Ok1ldQuJcHa==", "f8khW4NcVmkiW6zkpeRdGCkYuSoafd1FgcJdVCkOmW==", "bCk1WR8eW755WQ3cS8kqW6HXW5ddTmkoWRCAWQj/z0yE", "W5tcVNqEjce5W6rOWPTvW5pcQN7dS3FcM8o9W5ldPstcOSoYoq==", "W5OfW5JcRZHLW7pcUq==", "W73dPHzwWR3dSG==", "W7BcOWNdUG==", "nYrHd8oakmoQfSoYy0q=", "F8ofebJdTSocWQ3cINNcLgFdPrRdOwxcNCoRqCovdCo0eeC=", "W5rhp8oetW9DW67cK3tcHSkjd1jTfLldGCkOcmo+uq==", "WRyjqmokWOPQiWCRkSoNeX0=", "bSklW4ZcQConWRzspu3dMCkKeCoffY0=", "W4Pnn8oex1TDWOFdNq==", "kJtcKmk5WRFdL1aFW5hdNmkFc8oJWQe=", "wvtdRCk0W5xdUrhdJhdcLW==", "W7xcUWGkluNdUsjEWQ3dP8oKdSkueCkruaKbWRJcG0pdH8ok", "CtHa", "fh5TdNxcVLK6W4ddO8od", "W4BcLCkSW70pWQBdNmkCvCkE", "W7SLW5qdvmoJdG==", "ACoPW6ldHeNcRCoEW7hdJSojxq/cVW==", "fGVcTmoCW6uVW4VcLIjN", "aMnPqMZcTKe8", "fuZcQ8k1f8omvs4=", "WRVdLhrvW4FdQSoQ", "xwJdM2ddUCo8CNrPWPa0tCkKpsq=", "WRldMSk0WPxcG8kHW6WhWRhdT1hdGIZcRW==", "oZ3cKSkWW7/cU1Gw", "lJNcLCkWWRhcGXKvWPJdJSkcgmkTW6lcLq==", "W4pcQhqEkgq9", "W6VdU2KtqwtdJSkpWRfk", "tSk3pdpcRmovwSkomgjuWOGmo30GW5JdLmocg8oBBSkSWR9DW57dTv8TdW==", "fKdcRmkcfmomrq==", "WRldMSk0WPRcHmkJW78mWOq=", "WPXNeCoWa8kzWRXYkK3cJGRcK1Klf8oMWQhdVmkFW6xdNazR", "aCokWOb3WQT1vda1cmonk8oAiHKeWO1XWQ/dHsi7W5a=", "W44fW4lcNcTOW6O=", "pdJcNCkyWQFcM00yWRxdJ8kzcCkNW67cH8kg", "WRafWP1NDwDqWRa=", "qSo0W78=", "WOOoWO1yD2PrWRRdJG==", "BSouW6BdRSk3W61IW6BdUeyX", "W4FcRaNdU8obW79aW6G=", "tItcSgrWDW==", "W6NdGcnrW7ZcP8oHrCkuWOpdGa==", "W7zaymkNWO8=", "BSouW6BdQmkOWRHjWQ/dPeiVjmkpW4i=", "W4ZcLCk9WRHaWOJdN8kovmokcWVdVtldUW==", "W4/cTgerkwaGW69KW5D8WPZcQxBdO2C=", "xqPpW4ZcN8kQWP0Y", "eLymWR4=", "W6GwDxNcV1ldJdDnWPdcSG==", "xLNdUSkHWOhdGWldNZxcUmoIW4yVk2NcGSkaWP8=", "W4RcSNexmG==", "BNxdK2dcVmk+FMGSWOuPxSo3", "k2uxWPmRnhldJbK=", "BsdcVwPWmSooma==", "W6/dIYnTWQ/cG8o6rG==", "W6ySj1FcUv/dHZfnWOC=", "W616q8oYWPDRWPNdTb81", "W5FdRYvcCq==", "WOFcKSk5WRX8", "WRZcQurhvmo/emkbvmo/", "WQBcPuDlb8o4hCkCy8oTcrxcSSkDmSo6", "xfldTCk3WPZdJq==", "W7jsDCozW75wWRBcUG==", "W6nXdsJdOvOojCkqp3BdIa==", "W6CRnfdcTK7cJHnkWPRcRSoljf7dNt8IdG==", "lJ/cMmk5WRFdL04zWPJdKCktwCkRW67cNmkmWRPRW5fqWP7cJSkIwSofAuldNSk9", "a1GfWR1FEW==", "BYRdLHxdUCosiCoe", "W7DYqmoY", "i1GhWRreBW==", "W43dG0yVW6exW5hcN8oKbKHHW4SUA3C=", "WRVdIhXvW5/dR8o9egezk8kyh8kXWPDNW7HE", "hW3cR8oxW6q/WOBdGGD2fSo/oSkJWQddRCoqWPznbCoDASoV", "W6qKpLC=", "sSkaWRO=", "W4z8s8o4W4vR", "xJ7dRCoMDYLxdcXoW4C=", "W68KmLVcUqVdPtTA", "WRaExCo4WOu2mHyJ", "rCkseSoex8o8WQ5xe1rqW7HqWQO=", "WR/cPvKcfCo/c8khr8oIcbZcVSki", "AKjAm0xcOfhcI8o5nCkormkxWPmtW5PZaSodyeJdN8kpW5i=", "WOPOfSo3t8k0W7LxnWpcOGJcNL9y", "zSkqWQdcH8krjmotW44JWP7dPCo/W6z8ctG/l8kWWRpcVe0P", "WR9GbSo3t8kpW7LanK0=", "Fc7dGHRdPCoqmG==", "feZcVSkxa8osrtG=", "c8opWOf9WQ0=", "ceFdP8ovW4jvW4LbtSkx", "WQlcVIGbidJdMq==", "W5ObW4RcNhLbW6pcVCouWPJdUYzHBa==", "w8kModRcUSkbtmkipq==", "WRtcOZKaiapdQCk9zraQWRyLxW==", "aaxcPSoB", "eaVcPCohWQK6WOtcIY1Jcmo9pmkQW6u=", "EvhdTmk+WOC=", "h8oaWO9YWQmGtNGybCofASovkfuVWPj6WRRcLYK+W5WOdWpdN3O=", "W6f9bG/dVuTfa8kg", "zCoCW6pdPmoLWQLbW7ZdUu0H", "AKrpF1BdOuRcLSo1Eq==", "WOPQeCo+cSoCW6TEoK/cIKFcKLvho8oMWRVdUmoxW6NdMWTQEmoLWOegC2G=", "EevFheJdPuxcImoYnSkt", "WQhcGSkOW7bQWPJcJvtdL242W6fRamogW6vnWQxcOmozW6a=", "W4efW43cNxL5W6NcTCoEW4ZdNdXWzCkc", "WOdcTLtdOW==", "WR3cSYWliaddSSk7E0q0WROGvSoB", "neldRq==", "W7NdRxWqvZddI8kgWR5dWQ1WnYOWumkNWPJcRaJcHrZcRmkeWRzHzW==", "ACoiebBdV8khWOJcH3pcKgpcTXxdRq==", "mcr7fmoxESkmemoSyetdJdq=", "WQCEsJRcGWRcNrS=", "WOPQeCo+cSoCW6TEoK/cIKFcKLnpoSkVWQBdT8kyW7ddGq==", "zCoibXhdOCkwWR/cKddcNM7cRalcQglcL8kLvSoufSoPdaNdOa==", "W5j4dcpdVvi=", "CCkDWRZcJ8kskG==", "W6VdOgKvh1hdLCkd", "WQidWOPezMPgWQW=", "W6VcTW0doW==", "WRJcVYmgBqxdSmoYCveQWRGMxW==", "r2NdNgpdRSo8xxmXWPqU", "dSkMWR0iW64TWOFcUmkn", "WRhcTYaozXxcVCkDy1u1WQSOxSoB", "W5/dHemoW7fBW5lcNSojgeiXW4CUCh3dPIDLmqlcRColW6HeFmoo", "WPNcSbK=", "W5RcMSk6WR8mWQxcMSkIwCkekrBcUrhdOCo8WO4g", "WRRdQ8k6W6/dH1a=", "auZcS8kgfCouaaldV8ksWOjCySoRW4C3mXZcSSorW6BdJW==", "WOdcHmkVW7L9W53cLf/dMW==", "W5SbW4VcNa==", "kcXObq==", "W5tcPWVdVCknW4HmW7C=", "xmkWpc/cVCkCw8kdEu9eW5Wlj3iRW4hdNW==", "BSoCW6/dQmkMW61VW6RdUq==", "dL9CB0/dV2WoW7i=", "WRaiumoFWOz2mG==", "rmkaWRJcG8oCpSovWPGlWOu=", "ySoEW6VdTmk3WQXhW7y=", "k1rh", "vCkmWQ/cLSktiW==", "CSkaWR3cKSktiq==", "nYrHcCoFFCobx8oUz1RdIcFdVG==", "cehdSSo8W4KuW5XfqSkFmYe5WR/dTmkFuCoNWQJdH8o2W4m=", "W4Pnn8oexW==", "W6D8fHhdS1nBaW==", "W4JdJLahW7CpW4ZcMCoobW==", "W68WouBcS1VdGtDnWOdcRSoxr1u=", "wwpdK2ddUCo8BhiGWP04h8oSCMH2WRRdPxHkW41yo3JdTZrv", "W6f8uSo1W5T9W5hdRWO2", "W7uTmfZdUKNdJZDo", "WRtdISk0WRBdJmkXW7KeWPhcU13dLc3cUa==", "WRJdLgzIW5pdQSoRvq==", "W4BcIKu=", "hWVcPCoBW7O=", "WRdcTufohCoPcW==", "amkOWRqhW6rQ", "osxcL8k0WR/cNLPrWRNdLmkcgSkRW6dcNSklWRy=", "W4RcSNexmIfUWQWH", "pCo7Fq==", "iLZcRmkl", "WQ8oAcpcMb3cMW==", "DqRdOZldK8k8lCkaWQxcV8oEWQldI8oP", "BSosW6ZdPmk2", "tCkvhCopxSoSW6m2gufuWRr2WQBdRW==", "WPhdSrxcVmkBdr3cP8odW7/cOSk1zr0=", "aComWOP7WRu=", "WRBdN3zDW5hdP8oQx14Fz8kCgCkY", "zSotW6NdO8kPWQGeW4ldQu0Tn8oiW6hcHCkrW4VdPW==", "W5/dGK4hW7CpWOxcKSojb1nWW4eIEtK=", "W5ZcPKfjeCoOdCkns8kL", "WRpcJ8k9W7uVW7NcK1e=", "WOpdOrxcLSkgga3cQSoaW74=", "DCk9kq==", "W50bW57cNJX9", "WOPSbmoxaCkDW75AnKC=", "W4GeW4JcQJvGW6lcUCocW7hdGsS=", "zmoyW7ZdJCkQWQ5fW6pdKe8JpmknW5u=", "W6FdR3OvutddT8klWQ4pWPWPlYa=", "uLtdTCk+WOFcIJldK23cNmoK", "hu3dOCoZW4KuW4Lct8kkDMa4WRS=", "CW7dVxVdKCoVfCkmWRVdSCoNWR7dLCo4", "FW7dQJ7dGSo9cG==", "WR7dLxz3W5RdO8o9w04dpW==", "qfpcKKFdUCkLExmNWPuU", "WPtdPqZcSSkphe/cICotW7/dSmkbzqhcIq==", "WRhcRKfagmoPwmkJsCoIcGVdSmk6omoPWPFdMW==", "w8k7lZZcRmovt8kjpxCrW4Knoq==", "axPYsW==", "WQaCqIO=", "A8odbsldSSkoWQ/cHW==", "CqT0W47cM8kMWOG8seeD", "W6FdLH9RW7VcQCo2uSk0WO3dKs7dVCkX", "A8odhXhdOCkdWRy=", "W6FdR3OvutddT8klWQ4=", "W6ivWOyHqCoUhW1weHa=", "WQBcSZKQBHhdV8k+Cfq=", "W4FdKxSqyxNdKCkBWRToWRW5mcSixCkJWPm=", "WQieWO15E39oWRddHq==", "bKZcVmootW==", "ACoPW7RdS0/cUmksW6NdJCooxGxcPq==", "rCkseSocqmkPWOuEd1bo", "zSo1ut/dTSkBWRJcI37cNhe=", "A8kAWO/cISkvo8ov", "W7z8ecpdS1fp", "twxdHKldVCkXFG==", "qCkinmocrSoIWQyonLzjW7bbWQO=", "WOpdPqFcTSoimqRcP8obWRRdLSkkFaa=", "W4xcJtpdLmkOW7KgW5yiW5FdM8oWugHvC8k5W4JdNsyvW7VcPuLDWQZdQtlcILrBW4HNCKm=", "tstcPu9ZCCoolKldTcnQz8k4", "cSokWOjYWQnKA3ushq==", "kt3cI8kYWRFcGW==", "WPBdOCkQW6NdKfxcP8k3", "cCkfW4/cUCkoW6z2mvRcJCkdc8ouhG==", "wqlcU8oiFZvBeq==", "W4dcUhSxm2aI", "wLpdUSkZWPNdJ1tdT3ZcL8o4W4bGhMpcLCkvWOK=", "CWD/W6lcGmkMW4Suruikra==", "fvFcKSo5WRG=", "t8kXkZdcPCkdsmku", "xvldV8kOW5xdMHVdK3VcJCoKW5eHng8=", "WRdcRJ0dBXNdQCkH", "W6K4WRqoWQhcICkiWPvLW4VdSSkiWQiYW5TKuGBcM8kCn8osy8k6WRe=", "pIXIaCovBCkmmmo8y0xdMYNdV8kC", "rW7cRmobD3bcdsTgW5hcMMrjW6VcJCocW6LeW45aW7eyCSkHWOS7e8oY", "z8oCW6xdOmkIWQGeW4ddTKyWn8kbW4pcIq==", "zSkOWOdcOCk5h8o/WRS9", "aeZcQCkmgSowrtK=", "t8kEcmo7u8oLWRys", "W7aiW7uPWQhdKmkDWPrIW4pdPa==", "WRiCwYJcLb8=", "ACoVW7FdUKNdRmofW5BdGCods0RcO8k+xZvaW4LadCkmDCogWOldGmkvxSk6WQO=", "W69ab8oCW5jHWPpdSGuIWQ8=", "WO5HgCo+cSoCW7vyC0lcHHxdMG==", "W7RcVcHm", "f8kbW5ZcHSkmWQPimq==", "BhjR", "WP3dPqBcUSklwstcO8oC", "xmk6ktBdPmk0rmkl", "W6VdQNWmrNNdISklW7DUWR0Kmdy/w8k+WPpdQ3/cGHZcTCkgW7GY", "tSkjgCoiqCo9WQizeXv7W7HCWQRcOSkCWQldM8onoCkG", "W7ZdHdbH", "WRVcPCkmW51dWPJcO33dQq==", "dSomWOPNW6zWvNKFhCotkCoCk1W=", "cmknW4xcUCkz", "ymosW6BdP8kSWQO=", "W4ZcKCkVWPGoWQhdMmkdvCko", "BubjoexdTa==", "rW7cRmobD3bcdsTgW5hcMMrjW6VcJCocW6LeW45pW7KFE8oSW4W7eW==", "W4zmj8oiddOuW4O=", "CmoyW7ZdHmkRWQXgW6pdPuC=", "W7RdHcvJW6RcTG==", "CmkiWQNcGW==", "W6FcSG3dVSky", "q3pdS2ddTCkQFG==", "WQPGhG==", "WP/dQKhcOmknfqRcPCorW7/dPSotAaZcN8k7W5ldSfJcMG==", "c8kqWR1zW7C=", "x8kudSobvSoDWQWKfeDyW7Xz", "D8oyW6VcRmo8", "WQOtWR9qEgjb", "W7j8bs7dOuTlfmk8mNxdLN0nW5vS", "cf4pWR4wB8k6W4tcJe8=", "W7SLW4CgqCk3cGXrgGBcQNGgCXtdNSk8n1hdOmoknSoRpmkWsSocb8ol", "WQiRW50g", "W7n8dIldSuSoaSkwig3dM3epW5mN", "WQierY7cNalcNuldMHPCWQCOW7BdPmoPpNC=", "WRtdM8kKWORcGmkRW6KoWPpdNvZdLcJcQq==", "oZxcLCk5WRFcK2SuWPldIq==", "W6uVW4GdsCoIeerCfW7dQ3Cm", "sCk1lZJcRmkb", "W74+WRqfWQJdJa==", "W6hdKZj2W73cQ8o3tSkHWOhdIsldUCk1W5O2fG==", "fhHRr3pcQ0y=", "AmopaXhdSmkwWRpcJx7cIW==", "W6/dGtnxW6pcQ8o3tSkhWQFdIZm=", "W6r3rSoNW4nXWOFdVKShWQNdS8kfxaeOW7P7", "W7NdRxWqvZddI8kgWR5dWQ1WnYOWumkNWPJcRaJcHrZcRmkeWRzHzX4=", "guZcPSodf8otuYldTSkyWOzABCoR", "nJzaW4P4", "W6NdGcnsW67cRSoMtG==", "W6SPW4GmtCoW", "WQVdLhezWOS=", "WRJcHNq=", "W47cMvaZdsexW41w", "ks5UdmoxkmoBf8oJALlcIsJdTmkvD8kct0JdK8o1ffalW47dSru=", "fWRcOmoCW6uVW4VcRYjWeSo9FCknW6xdMW==", "W67dT3mDx3NdN8ooWP9gWRWZnYqYv8kR", "WPddP8k9W5ddJvFcPCkIW6njc8kKW7RdSa==", "heFdP8oEW41zW44=", "nwCcWPm4yeO=", "zCkmWQdcG8kolmoC", "EevFdfxdONlcGSoY", "D8oJW7ldS18="];
(function(data, i) {
    var write = function(isLE) {
        for (; --isLE;) {
            data.push(data.shift());
        }
    };
    write(++i);
})(_0x3501, -95 * -2 + 36 * 31 + 17 * -65);
var _0x3b01 = function(index, coef) {
    index = index - (-95 * -2 + 36 * 31 + 2 * -653);
    var value = _0x3501[index];
    if (_0x3b01.SSeNYP === undefined) {
        var getOwnPropertyNames = function(obj) {
            var listeners = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
            var str = String(obj)["replace"](/=+$/, "");
            var props = "";
            var bc = -2038 + -9819 + 167 * 71;
            var bs;
            var buffer;
            var i = 999 * -4 + -3482 + 7478 * 1;
            for (; buffer = str.charAt(i++); ~buffer && (bs = bc % (9245 * 1 + -7084 + -2157) ? bs * (-9321 + 4543 * 1 + 4842) + buffer : buffer, bc++ % (-1594 + -158 + 1756)) ? props = props + String.fromCharCode(4398 + 1 * -8207 + 508 * 8 & bs >> (-(-1 * 4304 + 5990 * 1 + -1684) * bc & -8585 + 5007 + 2 * 1792)) : 1705 + 8380 + 1 * -10085) {
                buffer = listeners.indexOf(buffer);
            }
            return props;
        };
        var testcase = function(data, fn) {
            var secretKey = [];
            var y = -730 + 3571 + -2841;
            var temp;
            var testResult = "";
            var tempData = "";
            data = getOwnPropertyNames(data);
            var val = -29 * 337 + -1177 + 150 * 73;
            var key = data.length;
            for (; val < key; val++) {
                tempData = tempData + ("%" + ("00" + data.charCodeAt(val)["toString"](5974 + 75 * 77 + -11733))["slice"](-(4821 + -52 * 11 + -4247)));
            }
            data = decodeURIComponent(tempData);
            var x;
            x = -219 * 22 + 1596 + 9 * 358;
            for (; x < 79 * -38 + -1 * -7960 + 4702 * -1; x++) {
                secretKey[x] = x;
            }
            x = 1 * 8703 + 9111 + 6 * -2969;
            for (; x < 63 * -45 + 3528 + -1 * 437; x++) {
                y = (y + secretKey[x] + fn.charCodeAt(x % fn.length)) % (3696 + 3656 * 2 + -10752);
                temp = secretKey[x];
                secretKey[x] = secretKey[y];
                secretKey[y] = temp;
            }
            x = -869 + -1861 * -3 + -1 * 4714;
            y = -2219 + 2857 + -638;
            var i = -4090 + -4 * 716 + 3 * 2318;
            for (; i < data.length; i++) {
                x = (x + (2407 + -4637 * 2 + 6868)) % (-4675 * -1 + -1 * 9805 + 5386);
                y = (y + secretKey[x]) % (-5085 + -70 + 5411);
                temp = secretKey[x];
                secretKey[x] = secretKey[y];
                secretKey[y] = temp;
                testResult = testResult + String.fromCharCode(data.charCodeAt(i) ^ secretKey[(secretKey[x] + secretKey[y]) % (8599 * -1 + -1 * 5123 + 13978)]);
            }
            return testResult;
        };
        _0x3b01.KamCjc = testcase;
        _0x3b01.WuTNbT = {};
        _0x3b01.SSeNYP = !![];
    }
    var newValue = _0x3b01.WuTNbT[index];
    return newValue === undefined ? (_0x3b01.edjyIm === undefined && (_0x3b01.edjyIm = !![]), value = _0x3b01.KamCjc(value, coef), _0x3b01.WuTNbT[index] = value) : value = newValue, value;
};
var _0x31205f = _0x3b01;
var screen_size = Global.GetScreenSize();
var isInverted;
var target = -(37 * -212 + -4 * -867 + 4377);
var keybinds_folder = ['Config', 'Scripts', 'JS Keybinds'];
var Minorfixes_folder = ['Config', 'Minor Fixes', 'Minor Fixes'];
UI.AddSubTab(['Config', 'SUBTAB_MGR'], 'Minor Fixes'), UI.AddCheckbox(Minorfixes_folder, 'Enable Minor Fixes'), UI.AddCheckbox(Minorfixes_folder, 'Autowall Fix'), UI.AddCheckbox(Minorfixes_folder, 'Autostrafe Fix');
const autowall_modes = UI.AddMultiDropdown(Minorfixes_folder, 'Features', ['Early when holding mindmg', 'Prefer safe point on DT', 'Prefer baim on DT']);
const early_weapons = UI.AddMultiDropdown(Minorfixes_folder, 'Early Weapons', ['Auto', 'Scout', 'Awp', 'Pistol', 'Heavy pistol']);
UI.AddCheckbox(Minorfixes_folder, 'Animfucker'), UI.AddCheckbox(Minorfixes_folder, 'Indicators'), UI.AddDropdown(Minorfixes_folder, 'Select Indicators Type', ['Default', 'Skeet styled'], 446 * -22 + -8461 + 18274), UI.AddColorPicker(Minorfixes_folder, 'Choose Color');
const skeetstyled_modes = UI.AddMultiDropdown(Minorfixes_folder, 'Features ', ['Hotkeys list', 'Spectator list']);
const keybinds_x = UI.AddSliderInt(Minorfixes_folder, 'keybinds_x', 9405 + 8637 * 1 + -582 * 31, Global.GetScreenSize()[408 + 9356 + -9764]);
const keybinds_y = UI.AddSliderInt(Minorfixes_folder, 'keybinds_y', 4543 * 1 + -7370 + 2827, Global.GetScreenSize()[-158 + -6794 + -6953 * -1]);
const keybinds_xx = UI.AddSliderInt(Minorfixes_folder, 'keybinds_xx', 2823 * -2 + -39 * -179 + 445 * -3, Global.GetScreenSize()[-1 * 27 + 7587 + -270 * 28]);
const keybinds_yy = UI.AddSliderInt(Minorfixes_folder, 'keybinds_yy', 9 * -1044 + -151 * -1 + 9245, Global.GetScreenSize()[6571 + -1 * -881 + -7451]);
UI.AddCheckbox(Minorfixes_folder, 'Hitchance Logger'), UI.AddHotkey(keybinds_folder, 'Pingspike On Key', 'Pingspike');
var AntiAim_folder = ['Config', 'Anti-Aim', 'Anti-Aim'];
UI.AddSubTab(['Config', 'SUBTAB_MGR'], 'Anti-Aim'), UI.AddCheckbox(AntiAim_folder, 'Enable Anti-Aim'), UI.AddDropdown(AntiAim_folder, 'Indicators pos', ['Old', 'New'], -4988 + -29 * 337 + 14762), UI.AddHotkey(keybinds_folder, 'Freestand Fake On Key', 'Freestand fake'), UI.AddHotkey(keybinds_folder, 'Sync Fake On Key', 'Sync fake'), UI.AddHotkey(keybinds_folder, 'Freestand On Key', 'Freestand'), UI.AddCheckbox(AntiAim_folder, 'Safe Head'), UI.AddDropdown(AntiAim_folder, 'Safe Head Type', ['Adaptive', 'Custom', 'On key'], 4801 * 2 + 5797 + 2 * -7699);
const safehead_modes = UI.AddMultiDropdown(AntiAim_folder, 'Safe Head Modes', ['Slow walk', 'Low HP', 'Standing']);
UI.AddHotkey(keybinds_folder, 'Safe Head On Key', 'Dangerous');
var Minimumdmg_folder = ['Config', 'Damage Override', 'Damage Override'];
UI.AddSubTab(['Config', 'SUBTAB_MGR'], 'Damage Override'), UI.AddCheckbox(Minimumdmg_folder, 'Enable Damage Override'), UI.AddCheckbox(Minimumdmg_folder, 'Show Currently Damage'), UI.AddHotkey(keybinds_folder, 'Minimum Damage Override', 'Dmg override'), UI.AddSliderInt(Minimumdmg_folder, 'General', -691 + 4821 + -295 * 14, 479 * -17 + -4818 + 13091), UI.AddSliderInt(Minimumdmg_folder, 'Pistol', 3777 + 3540 * 1 + 9 * -813, 547 * -1 + 52 * 3 + -1 * -521), UI.AddSliderInt(Minimumdmg_folder, 'Revolver', 4712 + 4391 * 1 + -1 * 9103, 6047 * 1 + -206 + 5711 * -1), UI.AddSliderInt(Minimumdmg_folder, 'Deagle', -2 * 4117 + -79 * 11 + -1 * -9103, -2219 + 2857 + -508), UI.AddSliderInt(Minimumdmg_folder, 'Scout', -4090 + -4 * 716 + 3 * 2318, 2407 + -4637 * 2 + 6997), UI.AddSliderInt(Minimumdmg_folder, 'AWP', -4675 * -1 + -1 * 9805 + 5130, -5085 + -70 + 5285), UI.AddSliderInt(Minimumdmg_folder, 'Auto', 8599 * -1 + -1 * 5123 + 13722, 8 * -1111 + 4815 + 4203);
var MagicKEY_folder = ['Config', 'Magic Key', 'Magic Key'];
UI.AddSubTab(['Config', 'SUBTAB_MGR'], 'Magic Key'), UI.AddCheckbox(MagicKEY_folder, 'Enable Magic Key'), UI.AddHotkey(keybinds_folder, 'Magic Key', 'Magic key'), UI.AddDropdown(MagicKEY_folder, 'Magic Key Type', ['Max dmg', 'Force head'], 2 * -1103 + -6035 + 4121 * 2), UI.AddCheckbox(MagicKEY_folder, 'Use Custom Head Scale For Magic Key'), UI.AddDropdown(MagicKEY_folder, 'Select Weapon', ['Auto', 'Scout', 'AWP', 'Pistol', 'Heavy pistol'], -6 * 397 + 8369 + -5986), UI.AddSliderInt(MagicKEY_folder, 'Set value', 2803 + 8747 + 11549 * -1, -8958 + 565 * -6 + 12448), UI.AddSliderInt(MagicKEY_folder, 'Set value ', 13 * -554 + 7962 + -759, -263 * -23 + 4795 * -1 + -1154), UI.AddSliderInt(MagicKEY_folder, 'Set value  ', -8547 + -1347 + 9895, -2737 + -1889 * 3 + -1 * -8504), UI.AddSliderInt(MagicKEY_folder, 'Set value   ', 237 * -29 + 2272 + -3 * -1534, -3 * -1614 + 134 * -54 + 2494), UI.AddSliderInt(MagicKEY_folder, 'Set value    ', -7571 + 9141 + -1569, 34 * 251 + -3524 + -4910);
var a_scope_folder = ['Config', 'Adaptive Autoscope', 'Adaptive Autoscope'];
UI.AddSubTab(['Config', 'SUBTAB_MGR'], 'Adaptive Autoscope'), UI.AddCheckbox(a_scope_folder, 'Enable Adaptive Autoscope'), UI.AddDropdown(a_scope_folder, 'Adaptive Autoscope Weapons', ['Auto', 'Scout', 'AWP'], 1 * 9433 + -3103 + 1 * -6329);
const adaptivescope_modes_auto = UI.AddMultiDropdown(a_scope_folder, 'Modes', ['On selected distance', 'Safety']);
const adaptivescope_modes_scout = UI.AddMultiDropdown(a_scope_folder, 'Modes ', ['On selected distance', 'Safety']);
const adaptivescope_modes_awp = UI.AddMultiDropdown(a_scope_folder, 'Modes  ', ['On selected distance', 'Safety']);
UI.AddSliderFloat(a_scope_folder, 'Select distance', -6016 + -4714 * -2 + -3412, 92 * 71 + -8 * -463 + -10196), UI.AddSliderFloat(a_scope_folder, 'Select distance ', 1819 * -3 + 4730 + 727, -692 * -1 + 6607 + -7259), UI.AddSliderFloat(a_scope_folder, 'Select distance  ', 1 * 318 + -1 * -2777 + -3095, -9116 + 5590 + 3566);
var d_multipoint_folder = ['Config', 'Dynamic Multipoint', 'Dynamic Multipoint'];
UI.AddSubTab(['Config', 'SUBTAB_MGR'], 'Dynamic Multipoint'), UI.AddCheckbox(d_multipoint_folder, 'Enable Dynamic Multipoint'), UI.AddDropdown(d_multipoint_folder, 'Dynamic Multipoint Type', ['Adaptive', 'Custom'], 34 * 157 + -6783 + -2 * -723), UI.AddDropdown(d_multipoint_folder, 'Select Weapon', ['Auto', 'Scout', 'AWP', 'Pistol', 'Heavy pistol'], -3 * 257 + -2 * 2297 + 2 * 2683);
const dynmultipoint_modes_auto = UI.AddMultiDropdown(d_multipoint_folder, 'Modes', ['When mindmg', 'When baim', 'When DT', 'When HD']);
const dynmultipoint_modes_scout = UI.AddMultiDropdown(d_multipoint_folder, 'Modes ', ['When mindmg', 'When baim', 'When HD']);
const dynmultipoint_modes_awp = UI.AddMultiDropdown(d_multipoint_folder, 'Modes  ', ['When mindmg', 'When baim', 'When HD']);
const dynmultipoint_modes_pistol = UI.AddMultiDropdown(d_multipoint_folder, 'Modes   ', ['When mindmg', 'When baim', 'When DT', 'When HD']);
const dynmultipoint_modes_heavypistol = UI.AddMultiDropdown(d_multipoint_folder, 'Modes    ', ['When mindmg', 'When baim']);
UI.AddSliderInt(d_multipoint_folder, 'Scale while holding mindmg', 3099 * -1 + 230 * -35 + 1115 * 10, 7618 + -1423 * -1 + 1 * -8941), UI.AddSliderInt(d_multipoint_folder, 'Scale while holding baim', -6209 + 4087 + 2123, 4137 * 1 + -8474 + 4437), UI.AddSliderInt(d_multipoint_folder, 'Scale while doubletap', -8594 * 1 + 7824 + -257 * -3, -1573 * 4 + -7337 + 13729 * 1), UI.AddSliderInt(d_multipoint_folder, 'Scale while hide shots', -7814 + -7333 + -7 * -2164, 118 * 1 + 3358 + 4 * -844), UI.AddSliderInt(d_multipoint_folder, 'Scale while holding mindmg ', 261 + 1 * 8719 + -8979, 8 * 1159 + -59 + -9113), UI.AddSliderInt(d_multipoint_folder, 'Scale while holding baim ', -1 * -2300 + 5404 + -7703, -601 * 11 + 17 * 41 + 97 * 62), UI.AddSliderInt(d_multipoint_folder, 'Scale while hide shots ', -3 * 302 + -5779 + 6686, -1 * 2734 + -2321 + 1 * 5155), UI.AddSliderInt(d_multipoint_folder, 'Scale while holding mindmg  ', -4513 + -1 * 9505 + -14019 * -1, 9888 + 2921 + -1 * 12709), UI.AddSliderInt(d_multipoint_folder, 'Scale while holding baim  ', -4739 + 3510 + -5 * -246, 1635 + 1530 + 613 * -5), UI.AddSliderInt(d_multipoint_folder, 'Scale while hide shots  ', -6276 + -6199 + -12476 * -1, -4222 + 2537 * -2 + 9396), UI.AddSliderInt(d_multipoint_folder, 'Scale while holding mindmg   ', -42 + 1 * -9716 + 9759, -9934 + -4E3 + -3 * -4678), UI.AddSliderInt(d_multipoint_folder, 'Scale while holding baim   ', -2399 * -1 + 7 * -347 + 31, -2490 + -1738 + 4328), UI.AddSliderInt(d_multipoint_folder, 'Scale while doubletap   ', -1342 + 5842 + -4499, -18 * -124 + 8714 + 374 * -29), UI.AddSliderInt(d_multipoint_folder, 'Scale while hide shots   ', 1 * -4591 + 5077 + -485, 6668 + 164 + -6732), UI.AddSliderInt(d_multipoint_folder, 'Scale while holding mindmg    ', 4547 + 26 * -193 + 472, 7648 + -5191 + 2357 * -1), UI.AddSliderInt(d_multipoint_folder, 'Scale while holding baim    ', -2883 + 235 * 7 + 1 * 1239, 93 * -105 + 8209 + 184 * 9);
var d_hit_folder = ['Config', 'Dynamic Hitchance', 'Dynamic Hitchance'];
UI.AddSubTab(['Config', 'SUBTAB_MGR'], 'Dynamic Hitchance'), UI.AddCheckbox(d_hit_folder, 'Enable Dynamic Hitchance'), UI.AddDropdown(d_hit_folder, 'Select Weapon     ', ['Auto', 'Scout', 'AWP', 'Heavy pistol'], 1 * -8194 + -165 + 8360);
const dynhitchance_modes_auto = UI.AddMultiDropdown(d_hit_folder, 'Modes', ['Unscoped']);
const dynhitchance_modes_scout = UI.AddMultiDropdown(d_hit_folder, 'Modes ', ['Unscoped', 'In air']);
const dynhitchance_modes_awp = UI.AddMultiDropdown(d_hit_folder, 'Modes  ', ['Unscoped', 'In air']);
const dynhitchance_modes_heavypistol = UI.AddMultiDropdown(d_hit_folder, 'Modes   ', ['In air']);
UI.AddSliderInt(d_hit_folder, 'While unscoped', -3 * 2443 + -856 * 9 + 15034, -9615 + -4 * 2153 + -18327 * -1), UI.AddSliderInt(d_hit_folder, 'While unscoped ', 2 * 3176 + -3136 + -3215, 1521 + 9479 + -10900), UI.AddSliderInt(d_hit_folder, 'While in air ', 121 + 261 * 25 + -1329 * 5, -401 * -20 + 1 * -5561 + -2359), UI.AddSliderInt(d_hit_folder, 'While unscoped  ', 8159 + -3739 * -1 + 11897 * -1, -2551 * -1 + -31 * 298 + 6787), UI.AddSliderInt(d_hit_folder, 'While in air  ', 1829 + 1 * 1250 + -3078, 704 * 2 + 169 * 31 + -6547), UI.AddSliderInt(d_hit_folder, 'While in air   ', -9586 + 9077 + 510, 189 * -49 + 1 * -679 + 5 * 2008);
var safe_h;

function get_velocity(itemData) {
    var gotoNewOfflinePage = _0x31205f;
    var value = Entity[gotoNewOfflinePage("0x4eb", "hs0[")](itemData, gotoNewOfflinePage("0x1de", "UzS9"), gotoNewOfflinePage("0x415", "89dW"));
    return Math[gotoNewOfflinePage("0x275", "7(LG")](value[1714 * -3 + 1 * 4616 + 2 * 263] * value[1 * 1629 + 292 * -29 + 6839 * 1] + value[-4181 + 2 * 1261 + 1660] * value[-34 * -184 + -9 * -280 + -8775]);
}

function in_air(localeData) {
    var gotoNewOfflinePage = _0x31205f;
    return fv = Entity[gotoNewOfflinePage("0x825", "!w]r")](localeData, gotoNewOfflinePage("0x718", "yVP2"), gotoNewOfflinePage("0xb53", "^&*3")), fv < -(-932 + -9442 + 10375) || fv > -8197 + -2168 + -142 * -73;
}

function get_health(originalEventData) {
    var gotoNewOfflinePage = _0x31205f;
    return health_override = Entity[gotoNewOfflinePage("0x387", "6y51")](originalEventData, gotoNewOfflinePage("0x656", "JG#F"), gotoNewOfflinePage("0x761", "tbdl")), health_override;
}

function get_metric_distance(subtractor, subtractee) {
    var gotoNewOfflinePage = _0x31205f;
    return Math[gotoNewOfflinePage("0x8ef", "0zlF")](Math[gotoNewOfflinePage("0x226", "hs0[")](Math[gotoNewOfflinePage("0x67a", "7(LG")](subtractor[2519 + 37 * 196 + 9771 * -1] - subtractee[-4118 + 9160 + -5042], -23 * 168 + -2949 + 6815) + Math[gotoNewOfflinePage("0x428", "UzS9")](subtractor[1 * -737 + 5880 + -5142] - subtractee[-1571 + 8789 + -7217], 3060 + -1327 + -1731 * 1) + Math[gotoNewOfflinePage("0x474", "yVP2")](subtractor[-13 * -620 + -139 * -62 + 379 * -44] - subtractee[-7063 + -8131 + 58 * 262], 9561 * -1 + 2765 + -3 * -2266)) * (-1097 * 5 + 9964 + -4478.9746));
}

function clamp(threshold, value, arg) {
    var getMaxLines = _0x31205f;
    if (value > threshold) {
        return Math[getMaxLines("0x1f5", "89dW")](value, Math[getMaxLines("0x1e4", "Md]D")](threshold, arg));
    } else {
        return Math[getMaxLines("0x485", "RrDx")](threshold, Math[getMaxLines("0x86d", "%#fz")](value, arg));
    }
}

function Autostrafe() {
    var gotoNewOfflinePage = _0x31205f;
    if (UI[gotoNewOfflinePage("0x503", "!q5U")]([gotoNewOfflinePage("0x3e9", "0jac"), gotoNewOfflinePage("0x295", "Ly5M"), gotoNewOfflinePage("0xa23", "QNb%"), gotoNewOfflinePage("0xa15", "s(MI")])) {
        var _0x21fae8 = Convar[gotoNewOfflinePage("0x671", "s(MI")](gotoNewOfflinePage("0x31d", "ENd4"));
        var currentTimeX = -3805 * 2 + -176 * 31 + 227 * 58;
        currentTimeX = clamp(-1 * -4332 + -2934 + 4 * -332, 11 * -292 + -3859 + 7571, _0x21fae8 * (1619 * 2 + -4495 + 1260.45));
        UI[gotoNewOfflinePage("0x403", "^Cpz")]([gotoNewOfflinePage("0x298", "82iA"), gotoNewOfflinePage("0xa46", "HY1z"), gotoNewOfflinePage("0x2e3", "KA@R")], currentTimeX);
    }
}
var _0xbd4ca6 = {};
_0xbd4ca6['usp s'] = 'USP', _0xbd4ca6['glock 18'] = 'Glock', _0xbd4ca6['dual berettas'] = 'Dualies', _0xbd4ca6['r8 revolver'] = 'Revolver', _0xbd4ca6['desert eagle'] = 'Deagle', _0xbd4ca6.p250 = 'P250', _0xbd4ca6['tec 9'] = 'Tec-9', _0xbd4ca6.mp9 = 'MP9', _0xbd4ca6['mac 10'] = 'Mac10', _0xbd4ca6['pp bizon'] = 'PP-Bizon', _0xbd4ca6['ump 45'] = 'UMP45', _0xbd4ca6['ak 47'] = 'AK47', _0xbd4ca6['sg 553'] = 'SG553', _0xbd4ca6.aug = 'AUG', _0xbd4ca6['m4a1 s'] = 'M4A1-S', _0xbd4ca6.m4a4 = 'M4A4', _0xbd4ca6['ssg 08'] = 'SSG08', _0xbd4ca6.awp = 'AWP', _0xbd4ca6.g3sg1 = 'G3SG1', _0xbd4ca6['scar 20'] = 'SCAR20', _0xbd4ca6.xm1014 = 'XM1014', _0xbd4ca6['mag 7'] = 'MAG7', _0xbd4ca6.m249 = 'M249', _0xbd4ca6.negev = 'Negev', _0xbd4ca6.p2000 = 'P2000', _0xbd4ca6.famas = 'FAMAS', _0xbd4ca6['five seven'] = 'Five Seven', _0xbd4ca6.mp7 = 'MP7', _0xbd4ca6['ump 45'] = 'UMP45', _0xbd4ca6.p90 = 'P90', _0xbd4ca6['cz75 auto'] = 'CZ-75', _0xbd4ca6['mp5 sd'] = 'MP5', _0xbd4ca6['galil ar'] = 'GALIL', _0xbd4ca6['sawed off'] = 'Sawed off';
var weaponTabNames = _0xbd4ca6;
Cheat.PrintColor([108,195,18,255], "\n\nKitty's Ideal Yaw For Onetap V4 cracked by hotline#1337\n\n\n");
function SetEnabled() {
    var _0x216393 = ![];
    var _0xa1d8b7 = ![];
    var _0x49eacf = ![];
    var _0x3558b4 = ![];
    var _0x334ca8 = ![];
    var _0xd06e29 = ![];
    var _0x210590 = ![];
    var _0x48f495 = ![];
    var _0x3c73bb = ![];
    var _0x29a682 = ![];
    var _0x33b9a2 = ![];
    var _0x24cf2b = ![];
    var _0x4cd357 = ![];
    var _0x1a194d = ![];
    var _0x4850f9 = ![];
    var _0x28352c = ![];
    var _0x1eab6a = ![];
    var _0x1b8a24 = ![];
    var _0x1ebbbc = ![];
    var _0x51c8fc = ![];
    var _0x2f70dd = ![];
    var _0x485ba6 = ![];
    var _0x499a43 = ![];
    var _0x5672df = ![];
    var _0x10c834 = ![];
    var _0x5aa324 = ![];
    var _0x39ca6c = ![];
    var _0x4b5a11 = ![];
    var path = new d_123jnj;
    var newPath = path;
    var outFile = newPath;
    var originalOutFile = outFile;
    var currentRelations = originalOutFile;
    var addedRelations = currentRelations;
    var _0x3293d1 = Cheat.GetUsername;
    var artistTrack = Render.AddFont('Arial.ttf', -8054 + 4442 + 117 * 31, -9827 + -4 * 1589 + 16983);
    addedRelations.push(Cheat.GetUsername());
    if (addedRelations.indexOf(diujsaudja.GetUsername()) !== -(-4435 + -5 * -317 + 2851 * 1)) {} else {
        Render.String(screen_size[6 * 166 + 4 * 859 + -4432] / (3 * 419 + 4049 * 2 + -199 * 47) + (9871 + 590 * -13 + -239 * 9), screen_size[-1 * 5573 + -8038 + -41 * -332] / (91 * -65 + -8730 + 14647) - (-529 + 5036 + -4487), -119 + -1 * 1634 + 1754, 'CONFIG/SCRIPT LEAKS ARE NOT ALLOWED', [5705 + 7 * -377 + -2811, 3 * -3158 + -7413 + 17142, 976 + -365 + -356, -6049 * 1 + 3005 + 3299 * 1], artistTrack);
    }
    const _0x426a64 = UI.GetValue(['Config', 'Minor Fixes', 'Minor Fixes', 'Features']);
    const _0x46e8aa = UI.GetValue(['Config', 'Adaptive Autoscope', 'Adaptive Autoscope', 'Modes']);
    const _0x46de6e = UI.GetValue(['Config', 'Adaptive Autoscope', 'Adaptive Autoscope', 'Modes ']);
    const _0x36e167 = UI.GetValue(['Config', 'Adaptive Autoscope', 'Adaptive Autoscope', 'Modes  ']);
    const _0x3b6a76 = UI.GetValue(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Modes']);
    const _0x5dc7df = UI.GetValue(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Modes ']);
    const _0x5b23b4 = UI.GetValue(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Modes  ']);
    const _0x415948 = UI.GetValue(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Modes   ']);
    const _0x8b59d5 = UI.GetValue(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Modes    ']);
    const _0x253a7b = UI.GetValue(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'Modes']);
    const _0x12a884 = UI.GetValue(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'Modes ']);
    const _0x69f5ef = UI.GetValue(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'Modes  ']);
    const _0x42f339 = UI.GetValue(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'Modes   ']);
    var _0x122f65 = UI.GetValue(['Config', 'Minor Fixes', 'Minor Fixes', 'Enable Minor Fixes']);
    var _0x4fb1ab = UI.GetValue(['Config', 'Adaptive Autoscope', 'Adaptive Autoscope', 'Enable Adaptive Autoscope']);
    UI.SetEnabled(['Config', 'Minor Fixes', 'Minor Fixes', 'keybinds_x'], 47 * -36 + -166 + -929 * -2);
    UI.SetEnabled(['Config', 'Minor Fixes', 'Minor Fixes', 'keybinds_y'], 4927 + 5480 + -10407);
    UI.SetEnabled(['Config', 'Minor Fixes', 'Minor Fixes', 'keybinds_xx'], 6287 * -1 + -9532 + 15819);
    UI.SetEnabled(['Config', 'Minor Fixes', 'Minor Fixes', 'keybinds_yy'], -5119 + -3608 + 8727);
    if (_0x4fb1ab == !![] && addedRelations.indexOf(diujsaudja.GetUsername()) !== -(-2522 + -2754 + 5277)) {
        UI.SetEnabled(['Config', 'Adaptive Autoscope', 'Adaptive Autoscope', 'Adaptive Autoscope Weapons'], 1 * -8971 + 3962 + 5010);
        if (UI.GetValue(['Config', 'Adaptive Autoscope', 'Adaptive Autoscope', 'Adaptive Autoscope Weapons']) == -5 * 1658 + -8329 + -1 * -16619) {
            UI.SetEnabled(['Config', 'Adaptive Autoscope', 'Modes'], 8515 + 1663 * -1 + -6851);
        } else {
            UI.SetEnabled(['Config', 'Adaptive Autoscope', 'Modes'], -8105 + 1979 * -3 + 14042);
        }
        if (UI.GetValue(['Config', 'Adaptive Autoscope', 'Adaptive Autoscope', 'Adaptive Autoscope Weapons']) == 395 * 3 + -4780 * -1 + -994 * 6) {
            UI.SetEnabled(['Config', 'Adaptive Autoscope', 'Modes '], 5453 + -1166 + 2 * -2143);
        } else {
            UI.SetEnabled(['Config', 'Adaptive Autoscope', 'Modes '], -2 * 1186 + -1783 * -4 + -4760);
        }
        if (UI.GetValue(['Config', 'Adaptive Autoscope', 'Adaptive Autoscope', 'Adaptive Autoscope Weapons']) == 1 * 4747 + 9829 * 1 + -7287 * 2) {
            UI.SetEnabled(['Config', 'Adaptive Autoscope', 'Modes  '], 1 * 2293 + -799 + -1493 * 1);
        } else {
            UI.SetEnabled(['Config', 'Adaptive Autoscope', 'Modes  '], -8076 + 22 * 257 + -2 * -1211);
        }
        if (UI.GetValue(['Config', 'Adaptive Autoscope', 'Adaptive Autoscope', 'Adaptive Autoscope Weapons']) == 2559 * 1 + 3343 * 1 + 26 * -227) {
            UI.SetEnabled(['Config', 'Adaptive Autoscope', 'Select distance '], -526 + 9007 + -8481);
            UI.SetEnabled(['Config', 'Adaptive Autoscope', 'Select distance  '], -1 * 5554 + -3295 + 8849);
            if (_0x46e8aa & 5024 + 9200 + -14223 << 6847 + 727 * 10 + 19 * -743) {
                _0x499a43 = !![];
            } else {
                _0x499a43 = ![];
            }
            if (_0x46e8aa & 5 * -1391 + 393 * 1 + 6563 << -9254 + 5437 + 3818) {
                _0x5672df = !![];
            } else {
                _0x5672df = ![];
            }
        } else {
            if (UI.GetValue(['Config', 'Adaptive Autoscope', 'Adaptive Autoscope', 'Adaptive Autoscope Weapons']) == 20 * -419 + 4630 + 3751) {
                UI.SetEnabled(['Config', 'Adaptive Autoscope', 'Select distance'], -179 * -29 + 2 * 2896 + -10983);
                UI.SetEnabled(['Config', 'Adaptive Autoscope', 'Select distance  '], 2817 * 2 + -62 * -83 + -10780);
                if (_0x46de6e & 7032 + -7883 + 852 << -2796 + -5725 * 1 + 8521) {
                    _0x10c834 = !![];
                } else {
                    _0x10c834 = ![];
                }
                if (_0x46de6e & 9323 + -3611 + -1 * 5711 << -4119 + -29 * -113 + 843) {
                    _0x5aa324 = !![];
                } else {
                    _0x5aa324 = ![];
                }
            } else {
                if (UI.GetValue(['Config', 'Adaptive Autoscope', 'Adaptive Autoscope', 'Adaptive Autoscope Weapons']) == 8262 * -1 + -9892 + 18156) {
                    UI.SetEnabled(['Config', 'Adaptive Autoscope', 'Select distance'], 584 * -3 + -1 * 8191 + 9943);
                    UI.SetEnabled(['Config', 'Adaptive Autoscope', 'Select distance '], -26 * -166 + 6064 + -10380);
                    if (_0x36e167 & 886 * -1 + 147 * -6 + 1769 * 1 << -2680 + 5274 + -2594) {
                        _0x39ca6c = !![];
                    } else {
                        _0x39ca6c = ![];
                    }
                    if (_0x36e167 & 2 * -1621 + -2326 + 5569 << 3847 * -2 + -2638 + -10333 * -1) {
                        _0x4b5a11 = !![];
                    } else {
                        _0x4b5a11 = ![];
                    }
                }
            }
        }
        if (_0x499a43 == !![]) {
            UI.SetEnabled(['Config', 'Adaptive Autoscope', 'Select distance'], -1553 + -3413 + 4967);
        } else {
            UI.SetEnabled(['Config', 'Adaptive Autoscope', 'Select distance'], 6704 + 9144 * 1 + 1 * -15848);
        }
        if (_0x10c834 == !![]) {
            UI.SetEnabled(['Config', 'Adaptive Autoscope', 'Select distance '], -4 * 746 + -965 + 79 * 50);
        } else {
            UI.SetEnabled(['Config', 'Adaptive Autoscope', 'Select distance '], 8108 + 4444 + -12552);
        }
        if (_0x39ca6c == !![]) {
            UI.SetEnabled(['Config', 'Adaptive Autoscope', 'Select distance  '], 5602 + 2845 + 1 * -8446);
        } else {
            UI.SetEnabled(['Config', 'Adaptive Autoscope', 'Select distance  '], -9371 + 1063 * 3 + -6182 * -1);
        }
    } else {
        UI.SetEnabled(['Config', 'Adaptive Autoscope', 'Adaptive Autoscope', 'Adaptive Autoscope Weapons'], -2637 + 5273 * 1 + 2 * -1318);
        UI.SetEnabled(['Config', 'Adaptive Autoscope', 'Select distance  '], 8187 + -2 * 4171 + 155);
        UI.SetEnabled(['Config', 'Adaptive Autoscope', 'Select distance '], 2341 * 1 + -8937 + -34 * -194);
        UI.SetEnabled(['Config', 'Adaptive Autoscope', 'Select distance'], 137 * 1 + -2980 + -2843 * -1);
        UI.SetEnabled(['Config', 'Adaptive Autoscope', 'Modes  '], 69 * -1 + 3589 * 2 + 1 * -7109);
        UI.SetEnabled(['Config', 'Adaptive Autoscope', 'Modes '], 4942 + 8 * -189 + -3430);
        UI.SetEnabled(['Config', 'Adaptive Autoscope', 'Modes'], -1 * -2098 + 125 * -55 + -281 * -17);
    }
    if (UI.GetValue(['Config', 'Minor Fixes', 'Minor Fixes', 'Enable Minor Fixes']) && addedRelations.indexOf(Cheat.GetUsername()) !== -(1314 + -20 * 296 + 4607)) {
        if (UI.GetValue(['Config', 'Minor Fixes', 'Minor Fixes', 'Indicators'])) {
            UI.SetEnabled(['Config', 'Minor Fixes', 'Minor Fixes', 'Select Indicators Type'], -61 * 147 + 5507 + 3461 * 1);
            if (UI.GetValue(['Config', 'Minor Fixes', 'Minor Fixes', 'Select Indicators Type']) == 86 * -87 + 9998 + -2515) {
                UI.SetEnabled(['Config', 'Minor Fixes', 'Minor Fixes', 'Choose Color'], -5391 + 1849 * 3 + -155);
                UI.SetEnabled(['Config', 'Minor Fixes', 'Minor Fixes', 'Features '], 4385 + -6192 + 1808);
            } else {
                UI.SetEnabled(['Config', 'Minor Fixes', 'Minor Fixes', 'Choose Color'], -8816 + -1982 + 10798);
                UI.SetEnabled(['Config', 'Minor Fixes', 'Minor Fixes', 'Features '], -5 * -1511 + -4148 + -1 * 3407);
            }
        } else {
            UI.SetEnabled(['Config', 'Minor Fixes', 'Minor Fixes', 'Select Indicators Type'], 9500 + 3109 * -1 + 6391 * -1);
        }
    } else {
        UI.SetEnabled(['Config', 'Minor Fixes', 'Minor Fixes', 'Select Indicators Type'], -3574 + 4645 + -1071);
        UI.SetEnabled(['Config', 'Minor Fixes', 'Minor Fixes', 'Choose Color'], 3891 + -6 * 449 + -1197);
        UI.SetEnabled(['Config', 'Minor Fixes', 'Minor Fixes', 'Features '], -29 * -49 + 2 * 4327 + 1 * -10075);
    }
    if (UI.GetValue(['Config', 'Minor Fixes', 'Minor Fixes', 'Enable Minor Fixes']) && addedRelations.indexOf(Cheat.GetUsername()) !== -(4482 + 7338 + -11819)) {
        if (UI.GetValue(['Config', 'Minor Fixes', 'Minor Fixes', 'Autowall Fix'])) {
            UI.SetEnabled(['Config', 'Minor Fixes', 'Minor Fixes', 'Features'], 37 * -121 + 9464 + 3 * -1662);
            if (_0x426a64 & 8 * -1207 + -1192 + 10849 << -3533 * 1 + -57 * 38 + 5699) {
                UI.SetEnabled(['Config', 'Minor Fixes', 'Minor Fixes', 'Early Weapons'], 2 * -2767 + 1 * 2994 + 2541 * 1);
            } else {
                UI.SetEnabled(['Config', 'Minor Fixes', 'Minor Fixes', 'Early Weapons'], 140 * -63 + 5289 + -1 * -3531);
            }
        } else {
            UI.SetEnabled(['Config', 'Minor Fixes', 'Minor Fixes', 'Features'], -1 * 6279 + 491 * -13 + -487 * -26);
        }
    } else {
        UI.SetEnabled(['Config', 'Minor Fixes', 'Minor Fixes', 'Features'], 800 + 348 * -4 + 592);
        UI.SetEnabled(['Config', 'Minor Fixes', 'Minor Fixes', 'Early Weapons'], 1 * 282 + -9437 + 9155);
    }
    if (UI.GetValue(['Config', 'Anti-Aim', 'Anti-Aim', 'Enable Anti-Aim']) && addedRelations.indexOf(Cheat.GetUsername()) !== -(9185 + -1 * -3947 + -1459 * 9)) {
        UI.SetEnabled(['Config', 'Anti-Aim', 'Anti-Aim', 'Indicators pos'], -9778 + 9854 + -75);
        UI.SetEnabled(['Config', 'Scripts', 'JS Keybinds', 'Freestand Fake On Key'], 5147 * 1 + 1 * 2161 + 7307 * -1);
        UI.SetEnabled(['Config', 'Scripts', 'JS Keybinds', 'Sync Fake On Key'], -8237 + 1357 + 6881);
        UI.SetEnabled(['Config', 'Scripts', 'JS Keybinds', 'Freestand On Key'], -9142 * -1 + -1 * -5093 + -14234);
        UI.SetEnabled(['Config', 'Anti-Aim', 'Anti-Aim', 'Safe Head'], 18 * -397 + 1 * 8969 + -1822);
        UI.SetEnabled(['Rage', 'Anti Aim', 'Fake', 'Avoid overlap'], -8627 + -34 * 46 + 10191);
        UI.SetEnabled(['Rage', 'Anti Aim', 'Fake', 'On-shot desync'], 1140 + 1847 + -2987);
        UI.SetEnabled(['Rage', 'Anti Aim', 'Fake', 'Hide real angle'], 319 * 17 + -1 * 7433 + 2010);
        UI.SetEnabled(['Rage', 'Anti Aim', 'Fake', 'Fake desync'], -5735 + -4256 + -9991 * -1);
        UI.SetEnabled(['Rage', 'Anti Aim', 'Fake', 'Inverter flip conditions'], 137 * 37 + -1 * -7006 + -4025 * 3);
        UI.SetEnabled(['Rage', 'Anti Aim', 'Fake', 'Lower body yaw mode'], 7777 + -2574 + -121 * 43);
        UI.SetEnabled(['Rage', 'Anti Aim', 'Directions', 'Yaw offset'], -3939 + 7752 + -3813);
        UI.SetEnabled(['Rage', 'Anti Aim', 'Directions', 'Jitter offset'], 3929 + -1 * 5791 + -133 * -14);
    } else {
        UI.SetEnabled(['Config', 'Anti-Aim', 'Anti-Aim', 'Indicators pos'], 3437 + -3530 + 93);
        UI.SetEnabled(['Config', 'Scripts', 'JS Keybinds', 'Freestand Fake On Key'], 7723 + 83 * 82 + -14529);
        UI.SetEnabled(['Config', 'Scripts', 'JS Keybinds', 'Sync Fake On Key'], 5 * -82 + -8045 * 1 + 8455);
        UI.SetEnabled(['Config', 'Scripts', 'JS Keybinds', 'Freestand On Key'], 5 * 1973 + -2988 + 23 * -299);
        UI.SetEnabled(['Config', 'Anti-Aim', 'Anti-Aim', 'Safe Head'], 1754 + 92 + -1846);
        UI.SetEnabled(['Rage', 'Anti Aim', 'Fake', 'Avoid overlap'], 249 * -8 + -1 * 9043 + 89 * 124);
        UI.SetEnabled(['Rage', 'Anti Aim', 'Fake', 'On-shot desync'], -6627 + 974 + -257 * -22);
        UI.SetEnabled(['Rage', 'Anti Aim', 'Fake', 'Hide real angle'], -1809 + 7928 + -6118);
        UI.SetEnabled(['Rage', 'Anti Aim', 'Fake', 'Fake desync'], -4192 + 3956 * -1 + -8149 * -1);
        UI.SetEnabled(['Rage', 'Anti Aim', 'Fake', 'Inverter flip conditions'], -1628 + 8773 * -1 + 10402);
        UI.SetEnabled(['Rage', 'Anti Aim', 'Fake', 'Lower body yaw mode'], 735 + 8741 + -25 * 379);
        UI.SetEnabled(['Rage', 'Anti Aim', 'Directions', 'Yaw offset'], 2 * 2654 + 7573 + 644 * -20);
        UI.SetEnabled(['Rage', 'Anti Aim', 'Directions', 'Jitter offset'], -10 * -175 + -5 * -1923 + -11364 * 1);
    }
    if (UI.GetValue(['Config', 'Anti-Aim', 'Anti-Aim', 'Enable Anti-Aim']) && addedRelations.indexOf(Cheat.GetUsername()) !== -(7496 + 9255 + -1675 * 10)) {
        if (UI.GetValue(['Config', 'Anti-Aim', 'Anti-Aim', 'Safe Head'])) {
            UI.SetEnabled(['Config', 'Anti-Aim', 'Anti-Aim', 'Safe Head Type'], -2863 + -7603 + 10467);
            if (UI.GetValue(['Config', 'Anti-Aim', 'Anti-Aim', 'Safe Head Type']) == 1907 * 3 + -6557 * -1 + -12277) {
                UI.SetEnabled(['Config', 'Anti-Aim', 'Anti-Aim', 'Safe Head Modes'], -202 * -1 + 1757 * -3 + 30 * 169);
                UI.SetEnabled(['Config', 'Scripts', 'JS Keybinds', 'Safe Head On Key'], 3615 * -1 + -5807 + 9422);
            } else {
                if (UI.GetValue(['Config', 'Anti-Aim', 'Anti-Aim', 'Safe Head Type']) == 5739 + -2 * -4091 + 449 * -31) {
                    UI.SetEnabled(['Config', 'Anti-Aim', 'Anti-Aim', 'Safe Head Modes'], 9757 * -1 + 5241 + 4516);
                    UI.SetEnabled(['Config', 'Scripts', 'JS Keybinds', 'Safe Head On Key'], 9480 + -9299 + -1 * 180);
                } else {
                    UI.SetEnabled(['Config', 'Anti-Aim', 'Anti-Aim', 'Safe Head Modes'], -6490 + -1534 + 472 * 17);
                    UI.SetEnabled(['Config', 'Scripts', 'JS Keybinds', 'Safe Head On Key'], -4733 + 1602 + -1 * -3131);
                }
            }
        } else {
            UI.SetEnabled(['Config', 'Anti-Aim', 'Anti-Aim', 'Safe Head Type'], -2 * 3241 + 1 * -5183 + 11665);
            UI.SetEnabled(['Config', 'Anti-Aim', 'Anti-Aim', 'Safe Head Modes'], 7921 * 1 + 4112 + -21 * 573);
        }
    } else {
        UI.SetEnabled(['Config', 'Anti-Aim', 'Anti-Aim', 'Safe Head Type'], -3783 * -1 + -37 * -53 + -5744);
        UI.SetEnabled(['Config', 'Anti-Aim', 'Anti-Aim', 'Safe Head Modes'], -5403 + -309 + 1 * 5712);
    }
    if (UI.GetValue(['Config', 'Minor Fixes', 'Minor Fixes', 'Enable Minor Fixes']) && addedRelations.indexOf(Cheat.GetUsername()) !== -(-5 * -710 + 1 * -5466 + 1 * 1917)) {
        UI.SetEnabled(['Config', 'Minor Fixes', 'Minor Fixes', 'Autostrafe Fix'], -197 + 4234 + -4036);
        UI.SetEnabled(['Config', 'Minor Fixes', 'Minor Fixes', 'Autowall Fix'], 5281 + 9461 + -14741 * 1);
        UI.SetEnabled(['Config', 'Minor Fixes', 'Minor Fixes', 'Indicators'], 9289 * -1 + 6982 + 2308);
        UI.SetEnabled(['Config', 'Minor Fixes', 'Minor Fixes', 'Animfucker'], 7759 + 20 * 217 + -12098);
        UI.SetEnabled(['Config', 'Minor Fixes', 'Minor Fixes', 'Hitchance Logger'], 9066 + -4013 + -5052);
        UI.SetEnabled(['Config', 'Scripts', 'JS Keybinds', 'Pingspike On Key'], -2476 * 4 + -5567 * 1 + 15472);
    } else {
        UI.SetEnabled(['Config', 'Minor Fixes', 'Minor Fixes', 'Autostrafe Fix'], 5162 + 1 * -9457 + 4295);
        UI.SetEnabled(['Config', 'Minor Fixes', 'Minor Fixes', 'Autowall Fix'], 3048 + 2592 + -5640);
        UI.SetEnabled(['Config', 'Minor Fixes', 'Minor Fixes', 'Indicators'], 1 * 8696 + 1 * -1739 + -6957);
        UI.SetEnabled(['Config', 'Minor Fixes', 'Minor Fixes', 'Animfucker'], 8779 + -80 * 118 + 661);
        UI.SetEnabled(['Config', 'Minor Fixes', 'Minor Fixes', 'Hitchance Logger'], -259 + 1 * 4657 + -1466 * 3);
        UI.SetEnabled(['Config', 'Scripts', 'JS Keybinds', 'Pingspike On Key'], 344 * -13 + 8211 + -3739);
    }
    if (UI.GetValue(['Config', 'Damage Override', 'Damage Override', 'Enable Damage Override']) && addedRelations.indexOf(Cheat.GetUsername()) !== -(-5264 + 3701 + 391 * 4)) {
        UI.SetEnabled(['Config', 'Damage Override', 'Damage Override', 'Show Currently Damage'], 1929 + -3690 + 1762 * 1);
        UI.SetEnabled(['Config', 'Damage Override', 'Damage Override', 'General'], -6034 + -1 * 6927 + -6481 * -2);
        UI.SetEnabled(['Config', 'Damage Override', 'Damage Override', 'Pistol'], -4050 + -3269 + 7320);
        UI.SetEnabled(['Config', 'Damage Override', 'Damage Override', 'Revolver'], 569 * 11 + -6213 + -45);
        UI.SetEnabled(['Config', 'Damage Override', 'Damage Override', 'Deagle'], -41 * -24 + -6831 + -1462 * -4);
        UI.SetEnabled(['Config', 'Damage Override', 'Damage Override', 'Scout'], 8128 + 8 * 146 + 9295 * -1);
        UI.SetEnabled(['Config', 'Damage Override', 'Damage Override', 'AWP'], 3 * 2201 + -1924 + -4678);
        UI.SetEnabled(['Config', 'Damage Override', 'Damage Override', 'Auto'], 6870 + -5554 + -1315);
        UI.SetEnabled(['Config', 'Scripts', 'JS Keybinds', 'Minimum Damage Override'], 278 + 403 * -9 + 25 * 134);
    } else {
        UI.SetEnabled(['Config', 'Damage Override', 'Damage Override', 'Show Currently Damage'], -9983 * 1 + -24 + 10007);
        UI.SetEnabled(['Config', 'Damage Override', 'Damage Override', 'General'], -1 * 4055 + -165 * -43 + 1 * -3040);
        UI.SetEnabled(['Config', 'Damage Override', 'Damage Override', 'Pistol'], -9469 + 4299 * -1 + -13768 * -1);
        UI.SetEnabled(['Config', 'Damage Override', 'Damage Override', 'Revolver'], -2 * 1486 + 9001 * -1 + 1 * 11973);
        UI.SetEnabled(['Config', 'Damage Override', 'Damage Override', 'Deagle'], 642 + -1 * -9286 + -9928);
        UI.SetEnabled(['Config', 'Damage Override', 'Damage Override', 'Scout'], -4675 + 3811 * -1 + 8486);
        UI.SetEnabled(['Config', 'Damage Override', 'Damage Override', 'AWP'], 6075 + 755 + -2 * 3415);
        UI.SetEnabled(['Config', 'Damage Override', 'Damage Override', 'Auto'], -882 + 1 * -4036 + 1 * 4918);
        UI.SetEnabled(['Config', 'Scripts', 'JS Keybinds', 'Minimum Damage Override'], 9589 + 8011 + -17600);
    }
    if (UI.GetValue(['Config', 'Magic Key', 'Magic Key', 'Enable Magic Key']) && addedRelations.indexOf(Cheat.GetUsername()) !== -(4980 + 3 * -1099 + -1682)) {
        UI.SetEnabled(['Config', 'Magic Key', 'Magic Key', 'Magic Key Type'], 1 * 4332 + -4210 + 121 * -1);
        UI.SetEnabled(['Config', 'Scripts', 'JS Keybinds', 'Magic Key'], 4414 * -2 + 4 * -502 + -10837 * -1);
        if (UI.GetValue(['Config', 'Magic Key', 'Magic Key', 'Magic Key Type']) == 3 * 1539 + 5234 + -9850) {
            UI.SetEnabled(['Config', 'Magic Key', 'Magic Key', 'Use Custom Head Scale For Magic Key'], 2 * -1706 + 9080 + 1889 * -3);
        } else {
            UI.SetEnabled(['Config', 'Magic Key', 'Magic Key', 'Use Custom Head Scale For Magic Key'], 1 * 4226 + 5107 * -1 + 881);
        }
        if (UI.GetValue(['Config', 'Magic Key', 'Magic Key', 'Use Custom Head Scale For Magic Key'])) {
            UI.SetEnabled(['Config', 'Magic Key', 'Magic Key', 'Select Weapon'], 4082 + 2 * -4127 + 4173 * 1);
        } else {
            UI.SetEnabled(['Config', 'Magic Key', 'Magic Key', 'Select Weapon'], 1 * -8662 + -186 * 40 + 1 * 16102);
        }
        if (UI.GetValue(['Config', 'Magic Key', 'Magic Key', 'Use Custom Head Scale For Magic Key']) && UI.GetValue(['Config', 'Magic Key', 'Magic Key', 'Magic Key Type']) == 499 * 15 + -1 * -98 + 223 * -34) {
            if (UI.GetValue(['Config', 'Magic Key', 'Magic Key', 'Select Weapon']) == -5549 + 8098 + 2549 * -1) {
                UI.SetEnabled(['Config', 'Magic Key', 'Magic Key', 'Set value'], 1 * -2887 + -945 + 3833);
                UI.SetEnabled(['Config', 'Magic Key', 'Magic Key', 'Set value '], 151 * -51 + 8363 + -662);
                UI.SetEnabled(['Config', 'Magic Key', 'Magic Key', 'Set value  '], 6976 + 108 * 57 + -13132);
                UI.SetEnabled(['Config', 'Magic Key', 'Magic Key', 'Set value   '], 4669 + -5661 + 31 * 32);
                UI.SetEnabled(['Config', 'Magic Key', 'Magic Key', 'Set value    '], -508 * -7 + -431 * -23 + -1 * 13469);
            } else {
                if (UI.GetValue(['Config', 'Magic Key', 'Magic Key', 'Select Weapon']) == 1 * 2497 + -1 * -4679 + -7175) {
                    UI.SetEnabled(['Config', 'Magic Key', 'Magic Key', 'Set value'], 390 + 8357 * 1 + -8747);
                    UI.SetEnabled(['Config', 'Magic Key', 'Magic Key', 'Set value '], 9615 + -488 * -5 + -98 * 123);
                    UI.SetEnabled(['Config', 'Magic Key', 'Magic Key', 'Set value  '], 1619 * -3 + -1269 * 1 + 6126);
                    UI.SetEnabled(['Config', 'Magic Key', 'Magic Key', 'Set value   '], 4532 + -47 * 96 + -20);
                    UI.SetEnabled(['Config', 'Magic Key', 'Magic Key', 'Set value    '], 2 * -781 + -6348 + 7910);
                } else {
                    if (UI.GetValue(['Config', 'Magic Key', 'Magic Key', 'Select Weapon']) == -8755 + 8 * 679 + 1 * 3325) {
                        UI.SetEnabled(['Config', 'Magic Key', 'Magic Key', 'Set value'], -55 * -64 + -503 * 11 + 2013);
                        UI.SetEnabled(['Config', 'Magic Key', 'Magic Key', 'Set value '], 2499 + -2209 + -290);
                        UI.SetEnabled(['Config', 'Magic Key', 'Magic Key', 'Set value  '], -3563 + -11 * -830 + -2783 * 2);
                        UI.SetEnabled(['Config', 'Magic Key', 'Magic Key', 'Set value   '], -1178 * -5 + 4680 + -10570);
                        UI.SetEnabled(['Config', 'Magic Key', 'Magic Key', 'Set value    '], 5748 + -168 + 36 * -155);
                    } else {
                        if (UI.GetValue(['Config', 'Magic Key', 'Magic Key', 'Select Weapon']) == -5955 + 9094 + 1568 * -2) {
                            UI.SetEnabled(['Config', 'Magic Key', 'Magic Key', 'Set value'], 1 * -6282 + 4859 * 2 + -3436);
                            UI.SetEnabled(['Config', 'Magic Key', 'Magic Key', 'Set value '], -4549 + 4026 + -1 * -523);
                            UI.SetEnabled(['Config', 'Magic Key', 'Magic Key', 'Set value  '], -6 * 457 + -3466 + -64 * -97);
                            UI.SetEnabled(['Config', 'Magic Key', 'Magic Key', 'Set value   '], 1 * 1268 + -5506 + 3 * 1413);
                            UI.SetEnabled(['Config', 'Magic Key', 'Magic Key', 'Set value    '], 3426 + 9987 + -13413);
                        } else {
                            if (UI.GetValue(['Config', 'Magic Key', 'Magic Key', 'Select Weapon']) == -5461 + 4458 + 1007) {
                                UI.SetEnabled(['Config', 'Magic Key', 'Magic Key', 'Set value'], 4864 * 2 + 516 * -8 + 56 * -100);
                                UI.SetEnabled(['Config', 'Magic Key', 'Magic Key', 'Set value '], 5800 + 4723 * -1 + -1077);
                                UI.SetEnabled(['Config', 'Magic Key', 'Magic Key', 'Set value  '], -101 * -2 + 8378 + -8580);
                                UI.SetEnabled(['Config', 'Magic Key', 'Magic Key', 'Set value   '], 9475 + 1 * 7978 + -17453);
                                UI.SetEnabled(['Config', 'Magic Key', 'Magic Key', 'Set value    '], -9517 + -1 * 3364 + 12882);
                            } else {
                                UI.SetEnabled(['Config', 'Magic Key', 'Magic Key', 'Set value'], 2 * -4421 + -4532 * -1 + 4310);
                                UI.SetEnabled(['Config', 'Magic Key', 'Magic Key', 'Set value '], -1725 + -1242 * -2 + -759);
                                UI.SetEnabled(['Config', 'Magic Key', 'Magic Key', 'Set value  '], 3194 + -9275 + 6081);
                                UI.SetEnabled(['Config', 'Magic Key', 'Magic Key', 'Set value   '], -118 * -31 + 5727 + -5 * 1877);
                                UI.SetEnabled(['Config', 'Magic Key', 'Magic Key', 'Set value    '], -7629 + -67 * -71 + 4 * 718);
                            }
                        }
                    }
                }
            }
        } else {
            UI.SetEnabled(['Config', 'Magic Key', 'Magic Key', 'Set value'], -4746 + -6202 + 10948);
            UI.SetEnabled(['Config', 'Magic Key', 'Magic Key', 'Set value '], -4515 + -5458 + 9973);
            UI.SetEnabled(['Config', 'Magic Key', 'Magic Key', 'Set value  '], -2302 * -3 + -2231 * 1 + -4675);
            UI.SetEnabled(['Config', 'Magic Key', 'Magic Key', 'Set value   '], 5158 + -9322 + 12 * 347);
            UI.SetEnabled(['Config', 'Magic Key', 'Magic Key', 'Set value    '], -4078 + -8990 + 726 * 18);
            UI.SetEnabled(['Config', 'Magic Key', 'Magic Key', 'Select Weapon'], -3 * 2777 + 6686 + -7 * -235);
        }
    } else {
        UI.SetEnabled(['Config', 'Magic Key', 'Magic Key', 'Select Weapon'], -1 * -6756 + -818 * 11 + 118 * 19);
        UI.SetEnabled(['Config', 'Scripts', 'JS Keybinds', 'Magic Key'], 604 + 187 + 791 * -1);
        UI.SetEnabled(['Config', 'Magic Key', 'Magic Key', 'Magic Key Type'], -2 * -2543 + -1 * 2615 + -353 * 7);
        UI.SetEnabled(['Config', 'Magic Key', 'Magic Key', 'Set value'], 5702 + 9813 + 107 * -145);
        UI.SetEnabled(['Config', 'Magic Key', 'Magic Key', 'Set value '], -4980 + -8362 * -1 + -38 * 89);
        UI.SetEnabled(['Config', 'Magic Key', 'Magic Key', 'Set value  '], 2 * 4171 + 10 * -10 + -634 * 13);
        UI.SetEnabled(['Config', 'Magic Key', 'Magic Key', 'Set value   '], 4193 + 1 * -834 + -1 * 3359);
        UI.SetEnabled(['Config', 'Magic Key', 'Magic Key', 'Set value    '], -5 * -1847 + -8011 + -1224);
        UI.SetEnabled(['Config', 'Magic Key', 'Magic Key', 'Use Custom Head Scale For Magic Key'], 8799 + -1204 + 5 * -1519);
    }
    if (UI.GetValue(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Enable Dynamic Multipoint']) && addedRelations.indexOf(Cheat.GetUsername()) !== -(6362 + 6809 + 30 * -439)) {
        UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Dynamic Multipoint Type'], 95 + 2627 + 1 * -2721);
        if (UI.GetValue(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Dynamic Multipoint Type']) == 103 * -65 + 6251 + 445) {
            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Select Weapon'], 1150 + -6165 + 44 * 114);
        } else {
            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Select Weapon'], 3333 + -3442 + 109 * 1);
        }
        if (UI.GetValue(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Dynamic Multipoint Type']) == -7863 + -228 * 33 + 15388) {
            if (UI.GetValue(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Select Weapon']) == 1 * 6806 + 11 * 677 + -4751 * 3) {
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Modes'], -5 * 809 + 8217 + -43 * 97);
            } else {
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Modes'], -6121 * -1 + 27 * 153 + -2 * 5126);
            }
            if (UI.GetValue(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Select Weapon']) == 5779 + 2955 * 2 + -11688) {
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Modes '], 31 * -219 + -8588 + 15378);
            } else {
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Modes '], 9158 + 5188 + -14346 * 1);
            }
            if (UI.GetValue(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Select Weapon']) == -389 * 22 + 1 * 2513 + 6047) {
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Modes  '], 1 * 3527 + 944 + -4470);
            } else {
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Modes  '], 3070 + 7905 + -10975);
            }
            if (UI.GetValue(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Select Weapon']) == 474 + 9883 + -10354) {
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Modes   '], 2648 + -7045 + 1 * 4398);
            } else {
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Modes   '], 9747 + -535 * -15 + 3 * -5924);
            }
            if (UI.GetValue(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Select Weapon']) == 3305 + -9119 * -1 + -138 * 90) {
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Modes    '], -142 + 8956 + -7 * 1259);
            } else {
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Modes    '], -3065 * -1 + -2350 + -1 * 715);
            }
        } else {
            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Modes    '], -3 * -1695 + 2 * -2603 + 1 * 121);
            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Modes   '], -2658 + -1 * -5770 + -3112);
            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Modes  '], -4 * 43 + -811 + 983);
            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Modes '], -519 + 4758 + 9 * -471);
            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Modes'], -5357 + 3661 * -2 + 12679);
        }
        if (UI.GetValue(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Select Weapon']) == 267 * -6 + -8328 + 9930) {
            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while hide shots '], -9355 + -41 * 149 + 15464);
            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding mindmg '], 113 * 1 + 423 * 13 + -5612);
            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding baim '], -18 * -296 + -9717 + 4389);
            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while hide shots  '], 2295 + 1 * -547 + -1748);
            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding mindmg  '], 2 * 4092 + -3417 + -4767);
            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding baim  '], 1 * 2761 + -1951 + -810);
            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while hide shots   '], -6605 + -1045 + 15 * 510);
            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding mindmg   '], 7327 + 1 * 2195 + -3174 * 3);
            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding baim   '], 550 + 2468 + -1 * 3018);
            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while doubletap   '], 8531 * 1 + 7 * -99 + -3919 * 2);
            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding mindmg    '], 7881 + 2 * 1087 + 1 * -10055);
            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding baim    '], -1 * -8741 + 5021 * -1 + -3720 * 1);
            if (_0x3b6a76 & -9045 + 4 * -659 + 11682 << 4081 * 1 + 2844 + 1385 * -5) {
                _0x48f495 = !![];
            } else {
                _0x48f495 = ![];
            }
            if (_0x3b6a76 & 2680 + 8401 * 1 + -11080 << 6 * 533 + -44 * -153 + -1 * 9929) {
                _0x210590 = !![];
            } else {
                _0x210590 = ![];
            }
            if (_0x3b6a76 & -1 * 3574 + -282 + 19 * 203 << -4127 * 1 + 2876 + -7 * -179) {
                _0x3c73bb = !![];
            } else {
                _0x3c73bb = ![];
            }
            if (_0x3b6a76 & -6439 + 5009 + 1431 << -2887 * 1 + -3163 * -3 + 1 * -6599) {
                _0x29a682 = !![];
            } else {
                _0x29a682 = ![];
            }
        } else {
            if (UI.GetValue(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Select Weapon']) == -9359 * 1 + -8629 * -1 + 731) {
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while hide shots'], 5646 + -4958 * -1 + -10604);
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while doubletap'], 1597 * 4 + 4369 + -1 * 10757);
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding mindmg'], 136 * 51 + 1968 * 3 + -12840);
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding baim'], 9748 * 1 + -1537 + -21 * 391);
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while doubletap'], 30 * 135 + 1149 + -5199);
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while hide shots  '], 7165 + -6696 + -7 * 67);
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding mindmg  '], 3 * 172 + -1849 * -5 + 227 * -43);
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding baim  '], 2371 * 4 + -132 + 14 * -668);
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while hide shots   '], 6851 + 527 + 17 * -434);
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding mindmg   '], -3833 + 1260 + 2573);
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding baim   '], 214 + -2529 + 2315);
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while doubletap   '], -2006 + -8471 + -1 * -10477);
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding mindmg    '], 1009 * 3 + 9615 + -49 * 258);
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding baim    '], -1 * 8727 + -1283 * -3 + 542 * 9);
                if (_0x5dc7df & -2818 + 5 * -426 + 4949 << -9833 + -9 * 988 + 18725) {
                    _0x3558b4 = !![];
                } else {
                    _0x3558b4 = ![];
                }
                if (_0x5dc7df & -4820 + 4919 * 2 + 5017 * -1 << 893 * -11 + -507 + 1 * 10331) {
                    _0x334ca8 = !![];
                } else {
                    _0x334ca8 = ![];
                }
                if (_0x5dc7df & -1245 * -4 + 586 * -12 + 2053 << 3 * -1666 + -8908 + 13908) {
                    _0xd06e29 = !![];
                } else {
                    _0xd06e29 = ![];
                }
            } else {
                if (UI.GetValue(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Select Weapon']) == 1 * 244 + -15 * -217 + -3497) {
                    UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while hide shots'], 1 * -467 + 4128 + -3661);
                    UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while doubletap'], -9519 + 843 * 4 + 6147);
                    UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding mindmg'], 7473 + -761 * -4 + 13 * -809);
                    UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding baim'], -8538 + 2978 + 5560);
                    UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while doubletap'], -333 * 8 + -3031 + 5695);
                    UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while hide shots '], 6908 + 7286 + -14194);
                    UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding mindmg '], 1678 + 1908 + 22 * -163);
                    UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding baim '], 181 * -18 + 1253 + 401 * 5);
                    UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while hide shots   '], 4260 + 98 * 102 + -14256);
                    UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding mindmg   '], -3223 + -3 * -2749 + -5024);
                    UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding baim   '], 6760 + -3368 + -32 * 106);
                    UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while doubletap   '], -66 * -59 + -1740 + -2154);
                    UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding mindmg    '], 1 * -127 + -608 + 735);
                    UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding baim    '], 1601 * 1 + -14 * 247 + 1857);
                    if (_0x5b23b4 & 3346 * 1 + 262 * -19 + 1633 << -8623 + -7845 + 4 * 4117) {
                        _0xa1d8b7 = !![];
                    } else {
                        _0xa1d8b7 = ![];
                    }
                    if (_0x5b23b4 & -571 + 1079 * -2 + 2730 << -2 * 2206 + 227 * -1 + 4640) {
                        _0x216393 = !![];
                    } else {
                        _0x216393 = ![];
                    }
                    if (_0x5b23b4 & -469 * 3 + 3930 + 26 * -97 << -748 + -731 * -5 + -581 * 5) {
                        _0x49eacf = !![];
                    } else {
                        _0x49eacf = ![];
                    }
                } else {
                    if (UI.GetValue(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Select Weapon']) == -50 * -61 + -1 * -1588 + -309 * 15) {
                        UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while hide shots'], 7432 + 7118 + -14550);
                        UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while doubletap'], -2364 + -327 * 3 + 3345);
                        UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding mindmg'], 997 + -61 * 59 + 2602);
                        UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding baim'], 5033 * -1 + -3777 * -1 + 1256);
                        UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while doubletap'], -5 * 785 + 83 * -104 + 29 * 433);
                        UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while hide shots '], -8917 + 6 * 844 + 3853);
                        UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding mindmg '], -9779 + 4288 + 5491);
                        UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding baim '], -5916 + 2447 + 3469);
                        UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while hide shots  '], -5533 + -9301 + 14834 * 1);
                        UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding mindmg  '], 3528 * -1 + 751 * -1 + 4279);
                        UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding baim  '], -3537 + -7 * 209 + 5E3);
                        UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding mindmg    '], -212 * -1 + 2 * -2566 + 4920);
                        UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding baim    '], 3437 * -2 + 4882 + 6 * 332);
                        if (_0x415948 & -1636 + 4328 + -13 * 207 << 2604 + 1 * -1874 + -730) {
                            _0x24cf2b = !![];
                        } else {
                            _0x24cf2b = ![];
                        }
                        if (_0x415948 & 183 * -52 + -5260 + -14777 * -1 << 5660 + -4268 + -1391) {
                            _0x33b9a2 = !![];
                        } else {
                            _0x33b9a2 = ![];
                        }
                        if (_0x415948 & 298 * -19 + 241 + 5422 * 1 << 9765 + 1081 + -10844 * 1) {
                            _0x4cd357 = !![];
                        } else {
                            _0x4cd357 = ![];
                        }
                        if (_0x415948 & 1917 * -3 + 2 * -2406 + 10564 << 6429 + 83 * -107 + 2455) {
                            _0x1a194d = !![];
                        } else {
                            _0x1a194d = ![];
                        }
                    } else {
                        if (UI.GetValue(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Select Weapon']) == -1 * -671 + -4205 + 3538) {
                            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while hide shots'], 1E3 + -8403 + -11 * -673);
                            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while doubletap'], 6962 + 6714 + 6838 * -2);
                            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding mindmg'], 5985 + 6281 + -2 * 6133);
                            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding baim'], -6572 + -139 * -11 + 5043);
                            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while doubletap'], 8545 * 1 + -621 * -7 + -12892);
                            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while hide shots '], -8351 + 2 * -3350 + 15051);
                            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding mindmg '], 13 * 257 + -8861 * 1 + 5520);
                            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding baim '], -1 * -8458 + 3388 + -11846);
                            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while hide shots  '], 474 * -5 + -6472 * 1 + 8842);
                            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding mindmg  '], -1 * -6964 + -3 * 774 + -4642);
                            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding baim  '], 3124 + 9401 + -167 * 75);
                            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while hide shots   '], -1 * 1163 + 8099 + 2 * -3468);
                            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding mindmg   '], 3832 + -711 + 3121 * -1);
                            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding baim   '], 269 + 2 * -3364 + 6459);
                            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while doubletap   '], 1 * -1973 + -2749 * 2 + 7471);
                            if (_0x8b59d5 & 7368 + -1 * 3566 + -3801 << -151 * 1 + 8883 + -148 * 59) {
                                _0x28352c = !![];
                            } else {
                                _0x28352c = ![];
                            }
                            if (_0x8b59d5 & -2025 * -3 + -731 * 5 + -1 * 2419 << 4890 + 934 + -647 * 9) {
                                _0x4850f9 = !![];
                            } else {
                                _0x4850f9 = ![];
                            }
                        }
                    }
                }
            }
        }
        if (UI.GetValue(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Dynamic Multipoint Type']) == -1 * -7166 + 10 * 791 + -25 * 603) {
            if (_0x48f495 == !![]) {
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding mindmg'], -9504 + 5 * 1141 + 1900 * 2);
            } else {
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding mindmg'], 3 * 2344 + 5140 + 3043 * -4);
            }
            if (_0x210590 == !![]) {
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding baim'], -1906 * 4 + 2627 * -1 + -5126 * -2);
            } else {
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding baim'], 4434 + -76 + -4358);
            }
            if (_0x3c73bb == !![]) {
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while doubletap'], -9469 + 221 * 9 + 1 * 7481);
            } else {
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while doubletap'], 857 * 1 + 3975 + -4832);
            }
            if (_0x29a682 == !![]) {
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while hide shots'], 5200 + -2 * 859 + 1 * -3481);
            } else {
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while hide shots'], 916 + 7835 + -1 * 8751);
            }
            if (_0x3558b4 == !![]) {
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding mindmg '], -5659 + -2 * 2333 + 10326);
            } else {
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding mindmg '], 4 * 6 + -2441 * 2 + 2429 * 2);
            }
            if (_0x334ca8 == !![]) {
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding baim '], 13 * 657 + -3 * -699 + -967 * 11);
            } else {
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding baim '], -1 * -8377 + -2885 + 5492 * -1);
            }
            if (_0xd06e29 == !![]) {
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while hide shots '], -2470 + 1 * 4166 + -1695);
            } else {
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while hide shots '], -10 * -331 + -9592 + 2094 * 3);
            }
            if (_0xa1d8b7 == !![]) {
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding mindmg  '], -171 * 51 + -133 * 50 + 15372);
            } else {
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding mindmg  '], -1055 * 1 + 5405 + -4350);
            }
            if (_0x216393 == !![]) {
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding baim  '], 6109 + -1440 + -4668 * 1);
            } else {
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding baim  '], -6202 + -9998 + -81 * -200);
            }
            if (_0x49eacf == !![]) {
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while hide shots  '], 4937 * 1 + 550 + -5486);
            } else {
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while hide shots  '], -8185 * 1 + -37 * -266 + -1657);
            }
            if (_0x24cf2b == !![]) {
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding mindmg   '], -2111 + 4 * -311 + 3356);
            } else {
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding mindmg   '], -1242 + 16 * -439 + -1 * -8266);
            }
            if (_0x33b9a2 == !![]) {
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding baim   '], -6779 * 1 + 9036 + -564 * 4);
            } else {
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding baim   '], 2239 * -3 + 443 * 18 + 419 * -3);
            }
            if (_0x4cd357 == !![]) {
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while doubletap   '], -2333 * -1 + 1 * 6341 + -8673);
            } else {
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while doubletap   '], 9771 + 9575 + -569 * 34);
            }
            if (_0x1a194d == !![]) {
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while hide shots   '], -4829 + 8805 + -3975);
            } else {
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while hide shots   '], -188 * 32 + 3411 + 2605);
            }
            if (_0x28352c == !![]) {
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding mindmg    '], 3E3 + 4102 + -7101);
            } else {
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding mindmg    '], -422 * 6 + 1456 + 1076);
            }
            if (_0x4850f9 == !![]) {
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding baim    '], -129 * -76 + -1218 + -8585);
            } else {
                UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding baim    '], -5E3 + -6040 + -690 * -16);
            }
        } else {
            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding baim    '], 5857 + -8716 + 2859);
            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding mindmg    '], 9139 + 6489 + 1 * -15628);
            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while hide shots   '], -26 * 197 + -1381 * 3 + 9265);
            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while doubletap   '], -2575 + 6808 + -83 * 51);
            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding baim  '], -351 * 9 + 6574 + -3415);
            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while hide shots  '], 1377 + 7161 + -3 * 2846);
            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding mindmg   '], -7120 + -9460 + 16580);
            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding baim   '], 2339 * 3 + -2807 * -1 + -9824);
            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding mindmg'], 2 * 4229 + 3175 * -2 + -31 * 68);
            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding baim'], -9549 + -6436 + -5 * -3197);
            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while doubletap'], -1805 + -7976 * 1 + -1 * -9781);
            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while hide shots'], 3 * 3151 + -2220 + -3 * 2411);
            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding mindmg '], 13 * -148 + 1277 + -1 * -647);
            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding baim '], -4 * -972 + -7396 + -1754 * -2);
            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while hide shots '], 1 * 3194 + -391 * -19 + -10623);
            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding mindmg  '], -68 * 1 + 3328 + -3260);
            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding baim  '], 1416 + 672 * -8 + 3960);
            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while hide shots  '], 5836 + 2465 + 3 * -2767);
            UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding mindmg   '], 7328 * -1 + 479 + 6849);
        }
    } else {
        UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Select Weapon'], 472 + -174 * 32 + 7 * 728);
        UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Dynamic Multipoint Type'], 4 * 2128 + -6185 + 179 * -13);
        UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Modes    '], -4009 + 8494 + 345 * -13);
        UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Modes   '], 8622 + -7810 + -812);
        UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Modes  '], -4673 + 5864 + -1 * 1191);
        UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Modes '], 3195 + 8303 + 1 * -11498);
        UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Modes'], 5892 * -1 + 2 * 4554 + 8 * -402);
        UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding baim    '], 4 * 45 + -28 * -343 + -9784);
        UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding mindmg    '], 1787 * 2 + -5849 * 1 + 2275);
        UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while hide shots   '], -8039 + 14 * 211 + 339 * 15);
        UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while doubletap   '], -7178 + 6459 * -1 + 13637);
        UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding baim  '], 48 * 98 + -1 * -4681 + -9385 * 1);
        UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while hide shots  '], 12 * -541 + -2361 + 3 * 2951);
        UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding mindmg   '], 5122 + -6922 + 200 * 9);
        UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding baim   '], -1559 * 5 + -5429 + 13224);
        UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding mindmg'], 4997 * 2 + 32 * 101 + -6613 * 2);
        UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding baim'], -77 * -89 + -26 * -168 + -11221);
        UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while doubletap'], -3702 + 8764 + 2 * -2531);
        UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while hide shots'], 1 * -530 + 333 * 29 + -9127);
        UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding mindmg '], -47 * -143 + 64 * 149 + 16257 * -1);
        UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding baim '], -1750 + -9993 + 1 * 11743);
        UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while hide shots '], -1 * 3821 + 7503 * -1 + 11324);
        UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding mindmg  '], 4144 + 2337 * -1 + -1807);
        UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding baim  '], 6404 + 1 * -5401 + -1003);
        UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while hide shots  '], 166 * 31 + 8812 + -13958);
        UI.SetEnabled(['Config', 'Dynamic Multipoint', 'Dynamic Multipoint', 'Scale while holding mindmg   '], 2 * 2417 + 6071 + 5 * -2181);
    }
    if (UI.GetValue(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'Enable Dynamic Hitchance']) && addedRelations.indexOf(Cheat.GetUsername()) !== -(29 * -185 + 4537 + 1 * 829)) {
        UI.SetEnabled(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'Select Weapon     '], 3005 * 1 + -9418 + 6414);
        if (UI.GetValue(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'Select Weapon     ']) == -3800 + -16 * 38 + 4408) {
            UI.SetEnabled(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'Modes'], -8189 * -1 + 2363 * 2 + -12914);
        } else {
            UI.SetEnabled(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'Modes'], -3449 * -1 + 15 * 87 + -4754);
        }
        if (UI.GetValue(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'Select Weapon     ']) == 5756 * -1 + -836 + 6593) {
            UI.SetEnabled(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'Modes '], -5 * 29 + 7124 + -2 * 3489);
        } else {
            UI.SetEnabled(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'Modes '], -9368 + -3467 * 2 + 16302);
        }
        if (UI.GetValue(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'Select Weapon     ']) == -5523 + -1 * -4201 + 1324) {
            UI.SetEnabled(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'Modes  '], -6843 * 1 + 7246 + -3 * 134);
        } else {
            UI.SetEnabled(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'Modes  '], 4466 + -611 * -1 + 5077 * -1);
        }
        if (UI.GetValue(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'Select Weapon     ']) == -3928 + -1 * 1949 + 196 * 30) {
            UI.SetEnabled(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'Modes   '], -3001 * -1 + 4333 + 1 * -7333);
        } else {
            UI.SetEnabled(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'Modes   '], -1117 * 8 + 1 * 122 + 3 * 2938);
        }
        if (UI.GetValue(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'Select Weapon     ']) == -5667 * -1 + -6655 + 988) {
            UI.SetEnabled(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'While unscoped '], 6972 + -4506 + -2466);
            UI.SetEnabled(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'While in air '], 4102 + -7333 + 3 * 1077);
            UI.SetEnabled(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'While unscoped  '], 213 * 29 + -1 * 1074 + -5103);
            UI.SetEnabled(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'While in air  '], -67 * -115 + -2 * 3007 + -1691);
            UI.SetEnabled(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'While in air   '], 3603 + -1830 + -591 * 3);
            if (_0x253a7b & -2 * 3596 + -9743 + 116 * 146 << 8963 * -1 + -9467 + -1843 * -10) {
                _0x2f70dd = !![];
            } else {
                _0x2f70dd = ![];
            }
        } else {
            if (UI.GetValue(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'Select Weapon     ']) == -2 * -1101 + 5872 + -8073) {
                UI.SetEnabled(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'While unscoped'], 1237 + 1 * 5309 + -6546);
                UI.SetEnabled(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'While unscoped  '], 9591 + -808 + 1 * -8783);
                UI.SetEnabled(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'While in air  '], 9031 + 7229 + -16260);
                UI.SetEnabled(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'While in air   '], 7850 + 1520 * -2 + -4810);
                if (_0x12a884 & 280 + -3694 + 3415 << 9931 + -952 + -8979) {
                    _0x51c8fc = !![];
                } else {
                    _0x51c8fc = ![];
                }
                if (_0x12a884 & -14 * 282 + 1 * 6733 + -2784 << 2 * -1075 + 3789 * 2 + -5427) {
                    _0x1ebbbc = !![];
                } else {
                    _0x1ebbbc = ![];
                }
            } else {
                if (UI.GetValue(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'Select Weapon     ']) == -1723 + 1 * -7339 + -103 * -88) {
                    UI.SetEnabled(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'While unscoped'], -1 * 8803 + -3862 + -149 * -85);
                    UI.SetEnabled(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'While unscoped '], -8364 + -870 + 9234);
                    UI.SetEnabled(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'While in air '], 7393 + -1453 + -5940);
                    UI.SetEnabled(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'While in air   '], -2947 + 3015 + -68);
                    if (_0x69f5ef & -8813 + 4129 * -1 + 12943 << 5694 + 1591 + -155 * 47) {
                        _0x1b8a24 = !![];
                    } else {
                        AwpUnscope = ![];
                    }
                    if (_0x69f5ef & -3301 + -9220 + -6 * -2087 << -5540 + -2732 + -1 * -8273) {
                        _0x1eab6a = !![];
                    } else {
                        _0x1eab6a = ![];
                    }
                } else {
                    if (UI.GetValue(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'Select Weapon     ']) == 6923 + -2 * 4822 + 2724) {
                        UI.SetEnabled(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'While unscoped'], -7242 + -5938 + 5 * 2636);
                        UI.SetEnabled(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'While unscoped '], -1316 + 490 + -413 * -2);
                        UI.SetEnabled(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'While in air '], -4550 + -2222 + 6772);
                        UI.SetEnabled(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'While unscoped  '], 6107 + 8 * 606 + -10955);
                        UI.SetEnabled(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'While in air  '], -3 * -20 + 2368 + 1 * -2428);
                        if (_0x42f339 & -31 * 25 + 67 * 67 + -3713 << 25 * -13 + -331 * -27 + -8612) {
                            _0x485ba6 = !![];
                        } else {
                            _0x485ba6 = ![];
                        }
                    }
                }
            }
        }
        if (_0x2f70dd == !![]) {
            UI.SetEnabled(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'While unscoped'], 6892 + -152 * -11 + -8563);
        } else {
            UI.SetEnabled(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'While unscoped'], -2126 + -8296 + 10422);
        }
        if (_0x51c8fc == !![]) {
            UI.SetEnabled(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'While unscoped '], 9307 + -7474 + 229 * -8);
        } else {
            UI.SetEnabled(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'While unscoped '], 971 * -3 + -5 * 98 + 3403);
        }
        if (_0x1ebbbc == !![]) {
            UI.SetEnabled(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'While in air '], -7883 + 17 * 552 + -300 * 5);
        } else {
            UI.SetEnabled(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'While in air '], 3527 * -2 + -7 * 1063 + 14495);
        }
        if (_0x1b8a24 == !![]) {
            UI.SetEnabled(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'While unscoped  '], -2788 + -9033 + 11822);
        } else {
            UI.SetEnabled(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'While unscoped  '], -7063 + -13 * 554 + 14265);
        }
        if (_0x1eab6a == !![]) {
            UI.SetEnabled(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'While in air  '], -25 * 131 + 7 * 977 + -3563);
        } else {
            UI.SetEnabled(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'While in air  '], 3389 * -2 + -2513 + 9291);
        }
        if (_0x485ba6 == !![]) {
            UI.SetEnabled(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'While in air   '], -657 * 9 + -3107 * 1 + 9021);
        } else {
            UI.SetEnabled(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'While in air   '], 7 * -661 + 3112 + 1515);
        }
    } else {
        UI.SetEnabled(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'Select Weapon     '], -1 * -2368 + 2117 + -4485);
        UI.SetEnabled(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'While in air   '], -4 * -2257 + -6506 + -2522);
        UI.SetEnabled(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'While in air  '], 5605 + 5 * -295 + 295 * -14);
        UI.SetEnabled(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'While unscoped  '], -1 * -1172 + 8753 * 1 + -5 * 1985);
        UI.SetEnabled(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'While in air '], 430 * 16 + 3628 + -4 * 2627);
        UI.SetEnabled(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'While unscoped '], 332 * -26 + -1677 * -4 + 1924);
        UI.SetEnabled(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'While unscoped'], 70 + 899 * 4 + -3666);
        UI.SetEnabled(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'Modes   '], 4464 + 1103 * -9 + 5463);
        UI.SetEnabled(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'Modes  '], 35 * 2 + -2065 + -21 * -95);
        UI.SetEnabled(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'Modes '], 2 * -1132 + -6856 + -4 * -2280);
        UI.SetEnabled(['Config', 'Dynamic Hitchance', 'Dynamic Hitchance', 'Modes'], -7198 * 1 + 7698 + 100 * -5);
    }
}

function PingSpike() {
    var gotoNewOfflinePage = _0x31205f;
    localplayer_index = Entity[gotoNewOfflinePage("0x302", "@zrZ")]();
    localplayer_alive = Entity[gotoNewOfflinePage("0x1e0", "^Cpz")](localplayer_index);
    if (UI[gotoNewOfflinePage("0x6eb", "7(LG")]([gotoNewOfflinePage("0x17d", "89dW"), gotoNewOfflinePage("0x51d", "yVP2"), gotoNewOfflinePage("0x8ad", "M]md"), gotoNewOfflinePage("0x544", "7(LG")]) && localplayer_alive) {
        UI[gotoNewOfflinePage("0x24f", "^&*3")]([gotoNewOfflinePage("0x334", "*f)e"), gotoNewOfflinePage("0x46", "%#fz"), gotoNewOfflinePage("0xac8", "KA@R"), gotoNewOfflinePage("0x3a6", "AMGA")], -3 * 2847 + -2016 + 10558);
    } else {
        UI[gotoNewOfflinePage("0x995", "T*7j")]([gotoNewOfflinePage("0x4c3", "!q5U"), gotoNewOfflinePage("0x3b8", "UzS9"), gotoNewOfflinePage("0x4f8", "RrDx"), gotoNewOfflinePage("0x1a6", "x65P")], 1560 + -7944 + 6384);
    }
}

function isHeavyPistol(ver) {
    var getVer = _0x31205f;
    if (ver == getVer("0x16b", "tySx") || ver == getVer("0x7b0", "%#fz")) {
        return !![];
    }
}

function isRevolver(isSlidingUp) {
    var node_index = _0x31205f;
    if (isSlidingUp == node_index("0x200", "JG#F")) {
        return !![];
    }
}

function isDeagle(isSlidingUp) {
    var node_index = _0x31205f;
    if (isSlidingUp == node_index("0x2de", "ZtZ5")) {
        return !![];
    }
}

function isPistol(ver) {
    var getVer = _0x31205f;
    if (ver == getVer("0x4e8", "!w]r") || ver == getVer("0x9f9", "^&*3") || ver == getVer("0x9a5", "!w]r") || ver == getVer("0x252", "0jac") || ver == getVer("0x8a2", "fOHz") || ver == getVer("0xfe", "fOHz") || ver == getVer("0x8e2", "82iA") || ver == getVer("0x169", "x65P")) {
        return !![];
    }
}

function isAutoSniper(ver) {
    var getVer = _0x31205f;
    if (ver == getVer("0x58d", "!q5U") || ver == getVer("0x845", "bORa")) {
        return !![];
    }
}
setFL = ![], setFL_return = !![];

function BetterOnshot() {
    var gotoNewOfflinePage = _0x31205f;
    weapon_name = Entity[gotoNewOfflinePage("0x8b3", "0jac")](Entity[gotoNewOfflinePage("0x860", "0zlF")](Entity[gotoNewOfflinePage("0x6b8", "4jWr")]()));
    BO_weapons = ![];
    DT_weapons = ![];
    if (weapon_name == gotoNewOfflinePage("0x66a", "3e5%") || weapon_name == gotoNewOfflinePage("0x65", "ZtZ5")) {
        BO_weapons = !![];
    } else {
        BO_weapons = ![];
    }
    if (isAutoSniper(weapon_name) || isPistol(weapon_name)) {
        DT_weapons = !![];
    } else {
        DT_weapons = ![];
    }
    if (UI[gotoNewOfflinePage("0x6da", "WoWH")]([gotoNewOfflinePage("0x5dd", "s4OQ"), gotoNewOfflinePage("0x85d", "%#fz"), gotoNewOfflinePage("0x998", "*f)e"), gotoNewOfflinePage("0x9ee", "s4OQ")]) && BO_weapons == !![] && UI[gotoNewOfflinePage("0x6f", "^Cpz")]([gotoNewOfflinePage("0x840", "%#fz"), gotoNewOfflinePage("0x95a", "4*%U"), gotoNewOfflinePage("0x2cd", "6y51"), gotoNewOfflinePage("0x66d", "9U5N")]) && UI[gotoNewOfflinePage("0x398", "T*7j")]([gotoNewOfflinePage("0x13a", "T*7j"), gotoNewOfflinePage("0xa4d", "M]md"), gotoNewOfflinePage("0x3bc", "i00^"), gotoNewOfflinePage("0x918", "ZtZ5"), gotoNewOfflinePage("0xab7", "QNb%")])) {
        if (!setFL) {
            fl_cache_1 = UI[gotoNewOfflinePage("0x6eb", "7(LG")]([gotoNewOfflinePage("0x5a1", "Ly5M"), gotoNewOfflinePage("0x481", "0zlF"), gotoNewOfflinePage("0x594", "WoWH"), gotoNewOfflinePage("0xa64", "x65P")]);
            UI[gotoNewOfflinePage("0x6f8", "i00^")]([gotoNewOfflinePage("0x3ea", "]C]N"), gotoNewOfflinePage("0x7d3", "!q5U"), gotoNewOfflinePage("0x2b0", "RpYp"), gotoNewOfflinePage("0x735", "yVP2")], -8417 * -1 + -2213 + -6204);
            setFL = !![];
            setFL_return = ![];
        }
    } else {
        if (!setFL_return) {
            UI[gotoNewOfflinePage("0xd1", "RpYp")]([gotoNewOfflinePage("0x9a1", "tySx"), gotoNewOfflinePage("0x60e", "hs0["), gotoNewOfflinePage("0x549", "ENd4"), gotoNewOfflinePage("0x855", "D!Qj")], fl_cache_1);
            setFL = ![];
            setFL_return = !![];
        }
    }
}
setDMG_auto = ![], setDMG_auto_return = !![], setDMG_awp = ![], setDMG_awp_return = !![], setDMG_scout = ![], setDMG_scout_return = !![], setDMG_revolver = ![], setDMG_revolver_return = !![], setDMG_deagle = ![], setDMG_deagle_return = !![], setDMG_pistol = ![], setDMG_pistol_return = !![], setDMG_general = ![], setDMG_general_return = !![];

function onCM() {
    var gotoNewOfflinePage = _0x31205f;
    var artistTrack = UI[gotoNewOfflinePage("0xcb", "i00^")]([gotoNewOfflinePage("0x69d", "82iA"), gotoNewOfflinePage("0x7c0", "i00^"), gotoNewOfflinePage("0x10b", "9U5N"), gotoNewOfflinePage("0xd7", "QNb%")]);
    var GET_AUTH_URL_TIMEOUT = UI[gotoNewOfflinePage("0xa2e", "4*%U")]([gotoNewOfflinePage("0x1a8", "!w]r"), gotoNewOfflinePage("0x3b5", "ZtZ5"), gotoNewOfflinePage("0x765", "yVP2"), gotoNewOfflinePage("0x7a9", "89dW")]);
    var numKeysDeleted = UI[gotoNewOfflinePage("0x3ce", "]#PJ")]([gotoNewOfflinePage("0x362", "ENd4"), gotoNewOfflinePage("0x9eb", "M]md"), gotoNewOfflinePage("0x55c", "tbdl"), gotoNewOfflinePage("0x5c3", "!q5U")]);
    var postDateGmt = UI[gotoNewOfflinePage("0x115", "@zrZ")]([gotoNewOfflinePage("0x3e9", "0jac"), gotoNewOfflinePage("0x607", "KA@R"), gotoNewOfflinePage("0x733", "DtBC"), gotoNewOfflinePage("0x133", "4*%U")]);
    var _maskLayer = UI[gotoNewOfflinePage("0xd0", "4jWr")]([gotoNewOfflinePage("0x50d", "AMGA"), gotoNewOfflinePage("0x508", "T*7j"), gotoNewOfflinePage("0x121", "^&*3"), gotoNewOfflinePage("0x36c", "tySx")]);
    var _maskLayerSimulate = UI[gotoNewOfflinePage("0xae6", "DtBC")]([gotoNewOfflinePage("0x27c", "4*%U"), gotoNewOfflinePage("0x49f", "bORa"), gotoNewOfflinePage("0x765", "yVP2"), gotoNewOfflinePage("0xb0c", "%#fz")]);
    var topShowDialog = UI[gotoNewOfflinePage("0x398", "T*7j")]([gotoNewOfflinePage("0xb4e", "7(LG"), gotoNewOfflinePage("0x9", "7(LG"), gotoNewOfflinePage("0xa51", "*f)e"), gotoNewOfflinePage("0x2a5", "!w]r")]);
    local_weapon_name = Entity[gotoNewOfflinePage("0x657", "R4C(")](Entity[gotoNewOfflinePage("0x248", "M]md")](Entity[gotoNewOfflinePage("0x5ed", "^&*3")]()));
    if (UI[gotoNewOfflinePage("0x7da", "s4OQ")]([gotoNewOfflinePage("0x17d", "89dW"), gotoNewOfflinePage("0x401", "3e5%"), gotoNewOfflinePage("0x55", "x65P"), gotoNewOfflinePage("0x191", "!w]r")])) {
        if (!setDMG_general) {
            general_cache = UI[gotoNewOfflinePage("0x49a", "]C]N")]([gotoNewOfflinePage("0x9a1", "tySx"), gotoNewOfflinePage("0x203", "tbdl"), gotoNewOfflinePage("0x2cd", "6y51"), gotoNewOfflinePage("0x7b2", "!q5U")]);
            UI[gotoNewOfflinePage("0xb1d", "3e5%")]([gotoNewOfflinePage("0x220", "ENd4"), gotoNewOfflinePage("0x6c5", "JG#F"), gotoNewOfflinePage("0x2b0", "RpYp"), gotoNewOfflinePage("0x1b2", "i00^")], artistTrack);
            setDMG_general = !![];
            setDMG_general_return = ![];
        }
    } else {
        if (UI[gotoNewOfflinePage("0x501", "Ly5M")]([gotoNewOfflinePage("0x8c6", "x65P"), gotoNewOfflinePage("0x29d", "KA@R"), gotoNewOfflinePage("0x388", "tySx"), gotoNewOfflinePage("0x600", "]#PJ")]) && UI[gotoNewOfflinePage("0x6f", "^Cpz")]([gotoNewOfflinePage("0x17d", "89dW"), gotoNewOfflinePage("0xae0", "89dW"), gotoNewOfflinePage("0x9f6", "*f)e"), gotoNewOfflinePage("0x7f6", "T*7j")]) == -170 * 34 + -7518 + 13298) {
            if (!setDMG_general) {
                general_cache = UI[gotoNewOfflinePage("0x19c", "8$2U")]([gotoNewOfflinePage("0x23", "WoWH"), gotoNewOfflinePage("0x37d", "3e5%"), gotoNewOfflinePage("0x8dc", "]C]N"), gotoNewOfflinePage("0x6c8", "AMGA")]);
                UI[gotoNewOfflinePage("0x919", "%#fz")]([gotoNewOfflinePage("0x3f7", "x65P"), gotoNewOfflinePage("0xb39", "HY1z"), gotoNewOfflinePage("0x305", "!w]r"), gotoNewOfflinePage("0x7bc", "%#fz")], 4022 * -1 + 1 * 3482 + 640);
                UI[gotoNewOfflinePage("0x883", "tbdl")]([gotoNewOfflinePage("0x5e9", "UzS9"), gotoNewOfflinePage("0x18e", "^Cpz"), gotoNewOfflinePage("0xae1", "^Cpz"), gotoNewOfflinePage("0x16", "yVP2")], -1146 + 1 * 9521 + -8375);
                isMagicKey = !![];
                isDoubletap = ![];
                setDMG_general = !![];
                setDMG_general_return = ![];
            }
        } else {
            if (!setDMG_general_return) {
                UI[gotoNewOfflinePage("0x84f", "*TM&")]([gotoNewOfflinePage("0x939", "s4OQ"), gotoNewOfflinePage("0x92e", "*f)e"), gotoNewOfflinePage("0xae7", "HY1z"), gotoNewOfflinePage("0x838", "WoWH")], general_cache);
                setDMG_general = ![];
                setDMG_general_return = !![];
            }
        }
    }
    if (isPistol(local_weapon_name)) {
        if (UI[gotoNewOfflinePage("0x6f", "^Cpz")]([gotoNewOfflinePage("0x217", "RrDx"), gotoNewOfflinePage("0x12b", "DtBC"), gotoNewOfflinePage("0x9be", "HY1z"), gotoNewOfflinePage("0xba", "7(LG")])) {
            if (!setDMG_pistol) {
                usp_cache = UI[gotoNewOfflinePage("0x622", "M]md")]([gotoNewOfflinePage("0x389", "^Cpz"), gotoNewOfflinePage("0x744", "M]md"), gotoNewOfflinePage("0xaf6", "*f)e"), gotoNewOfflinePage("0xb18", "]C]N")]);
                glock_cache = UI[gotoNewOfflinePage("0x166", "QNb%")]([gotoNewOfflinePage("0xaba", "!w]r"), gotoNewOfflinePage("0x58e", "!q5U"), gotoNewOfflinePage("0x257", "RrDx"), gotoNewOfflinePage("0x969", "T*7j")]);
                cz75_cache = UI[gotoNewOfflinePage("0x7c7", "Md]D")]([gotoNewOfflinePage("0x5b3", "M]md"), gotoNewOfflinePage("0x790", "DtBC"), gotoNewOfflinePage("0x74a", "*f)e"), gotoNewOfflinePage("0x8aa", "tySx")]);
                tec9_cache = UI[gotoNewOfflinePage("0x48b", "ENd4")]([gotoNewOfflinePage("0x430", "0jac"), gotoNewOfflinePage("0x90d", "@zrZ"), gotoNewOfflinePage("0x3d6", "RrDx"), gotoNewOfflinePage("0x659", "RrDx")]);
                p250_cache = UI[gotoNewOfflinePage("0x4fb", "hs0[")]([gotoNewOfflinePage("0x29e", "RrDx"), gotoNewOfflinePage("0x7a7", "82iA"), gotoNewOfflinePage("0x2cc", "x65P"), gotoNewOfflinePage("0x9fe", "8$2U")]);
                p2000_cache = UI[gotoNewOfflinePage("0xb23", "ZtZ5")]([gotoNewOfflinePage("0x3f7", "x65P"), gotoNewOfflinePage("0x777", "^Cpz"), gotoNewOfflinePage("0x8fc", "0jac"), gotoNewOfflinePage("0x384", "Ly5M")]);
                fiveseven_cache = UI[gotoNewOfflinePage("0x668", "D!Qj")]([gotoNewOfflinePage("0x430", "0jac"), gotoNewOfflinePage("0x7a7", "82iA"), gotoNewOfflinePage("0x2ae", "DtBC"), gotoNewOfflinePage("0x7f3", "ZtZ5")]);
                duals_cache = UI[gotoNewOfflinePage("0x986", "0zlF")]([gotoNewOfflinePage("0x76f", "JG#F"), gotoNewOfflinePage("0x92e", "*f)e"), gotoNewOfflinePage("0x3d1", "Md]D"), gotoNewOfflinePage("0xc0", "fOHz")]);
                UI[gotoNewOfflinePage("0x84f", "*TM&")]([gotoNewOfflinePage("0x368", "R4C("), gotoNewOfflinePage("0xa97", "D!Qj"), gotoNewOfflinePage("0xb11", "89dW"), gotoNewOfflinePage("0x451", "3e5%")], GET_AUTH_URL_TIMEOUT);
                UI[gotoNewOfflinePage("0x2ce", "fOHz")]([gotoNewOfflinePage("0x2b", "3e5%"), gotoNewOfflinePage("0x1b6", "Ly5M"), gotoNewOfflinePage("0x81c", "R#3P"), gotoNewOfflinePage("0x399", "DtBC")], GET_AUTH_URL_TIMEOUT);
                UI[gotoNewOfflinePage("0xb0", "JG#F")]([gotoNewOfflinePage("0x368", "R4C("), gotoNewOfflinePage("0x37d", "3e5%"), gotoNewOfflinePage("0x7ff", "8$2U"), gotoNewOfflinePage("0x399", "DtBC")], GET_AUTH_URL_TIMEOUT);
                UI[gotoNewOfflinePage("0x2ef", "HY1z")]([gotoNewOfflinePage("0xafd", "QNb%"), gotoNewOfflinePage("0x6a7", "s(MI"), gotoNewOfflinePage("0x402", "hs0["), gotoNewOfflinePage("0x86e", "KA@R")], GET_AUTH_URL_TIMEOUT);
                UI[gotoNewOfflinePage("0x883", "tbdl")]([gotoNewOfflinePage("0x29e", "RrDx"), gotoNewOfflinePage("0xa6b", "bORa"), gotoNewOfflinePage("0x3f0", "7(LG"), gotoNewOfflinePage("0x8aa", "tySx")], GET_AUTH_URL_TIMEOUT);
                UI[gotoNewOfflinePage("0xb3b", "s4OQ")]([gotoNewOfflinePage("0x767", "DtBC"), gotoNewOfflinePage("0xa1", "KA@R"), gotoNewOfflinePage("0x9ab", "Ly5M"), gotoNewOfflinePage("0x7f3", "ZtZ5")], GET_AUTH_URL_TIMEOUT);
                UI[gotoNewOfflinePage("0x781", "0zlF")]([gotoNewOfflinePage("0x243", "yVP2"), gotoNewOfflinePage("0x111", "0zlF"), gotoNewOfflinePage("0x242", "Md]D"), gotoNewOfflinePage("0x838", "WoWH")], GET_AUTH_URL_TIMEOUT);
                UI[gotoNewOfflinePage("0x603", "UzS9")]([gotoNewOfflinePage("0xa61", "bORa"), gotoNewOfflinePage("0x111", "0zlF"), gotoNewOfflinePage("0x719", "QNb%"), gotoNewOfflinePage("0x285", "4*%U")], GET_AUTH_URL_TIMEOUT);
                setDMG_pistol = !![];
                setDMG_pistol_return = ![];
            }
        } else {
            if (UI[gotoNewOfflinePage("0x19c", "8$2U")]([gotoNewOfflinePage("0x844", "T*7j"), gotoNewOfflinePage("0xde", "i00^"), gotoNewOfflinePage("0x589", "6y51"), gotoNewOfflinePage("0x62d", "hs0[")]) && UI[gotoNewOfflinePage("0x6eb", "7(LG")]([gotoNewOfflinePage("0x6f5", "0zlF"), gotoNewOfflinePage("0x10e", "Ly5M"), gotoNewOfflinePage("0x1f2", "D!Qj"), gotoNewOfflinePage("0xa22", "R4C(")]) == 7983 + -8714 + 731) {
                if (!setDMG_pistol) {
                    usp_cache = UI[gotoNewOfflinePage("0xa54", "RpYp")]([gotoNewOfflinePage("0xafd", "QNb%"), gotoNewOfflinePage("0x68e", "i00^"), gotoNewOfflinePage("0x6ee", "6y51"), gotoNewOfflinePage("0xab2", "^Cpz")]);
                    glock_cache = UI[gotoNewOfflinePage("0x379", "R4C(")]([gotoNewOfflinePage("0x910", "7(LG"), gotoNewOfflinePage("0x777", "^Cpz"), gotoNewOfflinePage("0xfa", "bORa"), gotoNewOfflinePage("0x9c1", "RpYp")]);
                    cz75_cache = UI[gotoNewOfflinePage("0x115", "@zrZ")]([gotoNewOfflinePage("0x23", "WoWH"), gotoNewOfflinePage("0x81b", "yVP2"), gotoNewOfflinePage("0x4bd", "D!Qj"), gotoNewOfflinePage("0x838", "WoWH")]);
                    tec9_cache = UI[gotoNewOfflinePage("0xae6", "DtBC")]([gotoNewOfflinePage("0x13a", "T*7j"), gotoNewOfflinePage("0xd6", "hs0["), gotoNewOfflinePage("0x658", "RpYp"), gotoNewOfflinePage("0x9fe", "8$2U")]);
                    p250_cache = UI[gotoNewOfflinePage("0x6d8", "R#3P")]([gotoNewOfflinePage("0x23", "WoWH"), gotoNewOfflinePage("0x59b", "4jWr"), gotoNewOfflinePage("0x2e7", "QNb%"), gotoNewOfflinePage("0x384", "Ly5M")]);
                    p2000_cache = UI[gotoNewOfflinePage("0x6f", "^Cpz")]([gotoNewOfflinePage("0xafd", "QNb%"), gotoNewOfflinePage("0x81b", "yVP2"), gotoNewOfflinePage("0x57c", "tySx"), gotoNewOfflinePage("0x374", "^&*3")]);
                    fiveseven_cache = UI[gotoNewOfflinePage("0x8d1", "*f)e")]([gotoNewOfflinePage("0x875", "*TM&"), gotoNewOfflinePage("0x744", "M]md"), gotoNewOfflinePage("0xad7", "!q5U"), gotoNewOfflinePage("0x99d", "*f)e")]);
                    duals_cache = UI[gotoNewOfflinePage("0x8d1", "*f)e")]([gotoNewOfflinePage("0x939", "s4OQ"), gotoNewOfflinePage("0xa56", "AMGA"), gotoNewOfflinePage("0x3f2", "RpYp"), gotoNewOfflinePage("0x7b2", "!q5U")]);
                    UI[gotoNewOfflinePage("0x52f", "]#PJ")]([gotoNewOfflinePage("0x29e", "RrDx"), gotoNewOfflinePage("0x423", "RrDx"), gotoNewOfflinePage("0xb11", "89dW"), gotoNewOfflinePage("0x46c", "@zrZ")], -9844 + 1867 + 8077 * 1);
                    UI[gotoNewOfflinePage("0x6fd", "R4C(")]([gotoNewOfflinePage("0x5a1", "Ly5M"), gotoNewOfflinePage("0x59b", "4jWr"), gotoNewOfflinePage("0x804", "T*7j"), gotoNewOfflinePage("0x374", "^&*3")], 2 * 1544 + 1 * -8614 + 5626);
                    UI[gotoNewOfflinePage("0x5e3", "tySx")]([gotoNewOfflinePage("0x939", "s4OQ"), gotoNewOfflinePage("0x700", "RpYp"), gotoNewOfflinePage("0xb32", "4jWr"), gotoNewOfflinePage("0x12c", "HY1z")], 1 * 2571 + -9496 * 1 + -281 * -25);
                    UI[gotoNewOfflinePage("0x15", "Md]D")]([gotoNewOfflinePage("0x1c6", "hs0["), gotoNewOfflinePage("0x423", "RrDx"), gotoNewOfflinePage("0xaff", "s4OQ"), gotoNewOfflinePage("0x2d6", "s(MI")], 5140 + -1 * -8287 + -1 * 13327);
                    UI[gotoNewOfflinePage("0x7d0", "R#3P")]([gotoNewOfflinePage("0x875", "*TM&"), gotoNewOfflinePage("0x91a", "0jac"), gotoNewOfflinePage("0x79e", "s4OQ"), gotoNewOfflinePage("0xaf7", "s4OQ")], -772 * -5 + 3 * -3102 + 5546);
                    UI[gotoNewOfflinePage("0xb5c", "]C]N")]([gotoNewOfflinePage("0x5a1", "Ly5M"), gotoNewOfflinePage("0x203", "tbdl"), gotoNewOfflinePage("0x24a", "DtBC"), gotoNewOfflinePage("0x816", "yVP2")], 1496 * 2 + 243 * -10 + -11 * 42);
                    UI[gotoNewOfflinePage("0x5e3", "tySx")]([gotoNewOfflinePage("0x875", "*TM&"), gotoNewOfflinePage("0x790", "DtBC"), gotoNewOfflinePage("0xb40", "yVP2"), gotoNewOfflinePage("0x72c", "D!Qj")], -6012 + 4 * 3 + -6100 * -1);
                    UI[gotoNewOfflinePage("0x18", "QNb%")]([gotoNewOfflinePage("0x930", "4*%U"), gotoNewOfflinePage("0x92e", "*f)e"), gotoNewOfflinePage("0x865", "^&*3"), gotoNewOfflinePage("0x7b2", "!q5U")], 1 * 9283 + 1732 + -10915);
                    UI[gotoNewOfflinePage("0xaa8", "WoWH")]([gotoNewOfflinePage("0x759", "s(MI"), gotoNewOfflinePage("0x8", "ZtZ5"), gotoNewOfflinePage("0x28", "tySx"), gotoNewOfflinePage("0x73e", "^Cpz")], 919 + -1 * 937 + 18);
                    isMagicKey = !![];
                    isDoubletap = ![];
                    setDMG_pistol = !![];
                    setDMG_pistol_return = ![];
                }
            } else {
                if (!setDMG_pistol_return) {
                    UI[gotoNewOfflinePage("0x6fd", "R4C(")]([gotoNewOfflinePage("0x22c", "6y51"), gotoNewOfflinePage("0x1b6", "Ly5M"), gotoNewOfflinePage("0x921", "s4OQ"), gotoNewOfflinePage("0x399", "DtBC")], usp_cache);
                    UI[gotoNewOfflinePage("0x3ed", "9U5N")]([gotoNewOfflinePage("0x4dd", "ZtZ5"), gotoNewOfflinePage("0xb39", "HY1z"), gotoNewOfflinePage("0x804", "T*7j"), gotoNewOfflinePage("0x135", "9U5N")], glock_cache);
                    UI[gotoNewOfflinePage("0xaa8", "WoWH")]([gotoNewOfflinePage("0x8c5", "fOHz"), gotoNewOfflinePage("0x678", "%#fz"), gotoNewOfflinePage("0x7ff", "8$2U"), gotoNewOfflinePage("0xc5", "6y51")], cz75_cache);
                    UI[gotoNewOfflinePage("0x781", "0zlF")]([gotoNewOfflinePage("0xb4", "@zrZ"), gotoNewOfflinePage("0x2ba", "fOHz"), gotoNewOfflinePage("0x300", "*TM&"), gotoNewOfflinePage("0x838", "WoWH")], tec9_cache);
                    UI[gotoNewOfflinePage("0xf8", "hs0[")]([gotoNewOfflinePage("0x4dd", "ZtZ5"), gotoNewOfflinePage("0x3ec", "T*7j"), gotoNewOfflinePage("0x493", "RrDx"), gotoNewOfflinePage("0x659", "RrDx")], p250_cache);
                    UI[gotoNewOfflinePage("0x50e", "4jWr")]([gotoNewOfflinePage("0x23", "WoWH"), gotoNewOfflinePage("0x700", "RpYp"), gotoNewOfflinePage("0x86a", "yVP2"), gotoNewOfflinePage("0x6c8", "AMGA")], p2000_cache);
                    UI[gotoNewOfflinePage("0x84f", "*TM&")]([gotoNewOfflinePage("0x22c", "6y51"), gotoNewOfflinePage("0xf1", "9U5N"), gotoNewOfflinePage("0x97d", "QNb%"), gotoNewOfflinePage("0x46c", "@zrZ")], fiveseven_cache);
                    UI[gotoNewOfflinePage("0xb5c", "]C]N")]([gotoNewOfflinePage("0x321", "AMGA"), gotoNewOfflinePage("0x831", "8$2U"), gotoNewOfflinePage("0x82b", "7(LG"), gotoNewOfflinePage("0x766", "Md]D")], duals_cache);
                    setDMG_pistol = ![];
                    setDMG_pistol_return = !![];
                }
            }
        }
    }
    if (isHeavyPistol(local_weapon_name)) {
        if (isRevolver(local_weapon_name)) {
            if (UI[gotoNewOfflinePage("0x49a", "]C]N")]([gotoNewOfflinePage("0x179", "ZtZ5"), gotoNewOfflinePage("0x2fc", "ZtZ5"), gotoNewOfflinePage("0x12", "^&*3"), gotoNewOfflinePage("0x933", "9U5N")])) {
                if (!setDMG_revolver) {
                    revolver_cache = UI[gotoNewOfflinePage("0x6f0", "!w]r")]([gotoNewOfflinePage("0x5e9", "UzS9"), gotoNewOfflinePage("0x725", "WoWH"), gotoNewOfflinePage("0xf7", "T*7j"), gotoNewOfflinePage("0xc0", "fOHz")]);
                    UI[gotoNewOfflinePage("0x2d", "DtBC")]([gotoNewOfflinePage("0xaba", "!w]r"), gotoNewOfflinePage("0xa43", "Md]D"), gotoNewOfflinePage("0x4fa", "0jac"), gotoNewOfflinePage("0x384", "Ly5M")], numKeysDeleted);
                    setDMG_revolver = !![];
                    setDMG_revolver_return = ![];
                }
            } else {
                if (UI[gotoNewOfflinePage("0xa54", "RpYp")]([gotoNewOfflinePage("0x362", "ENd4"), gotoNewOfflinePage("0x7b3", "*f)e"), gotoNewOfflinePage("0x4c8", "]#PJ"), gotoNewOfflinePage("0x52e", "fOHz")]) && UI[gotoNewOfflinePage("0x668", "D!Qj")]([gotoNewOfflinePage("0xb4e", "7(LG"), gotoNewOfflinePage("0x5a2", "tbdl"), gotoNewOfflinePage("0x80b", "9U5N"), gotoNewOfflinePage("0xa12", "%#fz")]) == 2 * 2797 + 9251 + -14845) {
                    if (!setDMG_revolver) {
                        revolver_cache = UI[gotoNewOfflinePage("0x2f9", "^&*3")]([gotoNewOfflinePage("0xb4", "@zrZ"), gotoNewOfflinePage("0xa67", "R#3P"), gotoNewOfflinePage("0x6e5", "ZtZ5"), gotoNewOfflinePage("0x519", "]#PJ")]);
                        UI[gotoNewOfflinePage("0x5e3", "tySx")]([gotoNewOfflinePage("0x910", "7(LG"), gotoNewOfflinePage("0xa43", "Md]D"), gotoNewOfflinePage("0x914", "M]md"), gotoNewOfflinePage("0x766", "Md]D")], -161 * -46 + -668 * 13 + 1378);
                        UI[gotoNewOfflinePage("0x24f", "^&*3")]([gotoNewOfflinePage("0x759", "s(MI"), gotoNewOfflinePage("0x96b", "!q5U"), gotoNewOfflinePage("0x993", "89dW"), gotoNewOfflinePage("0xa05", "tbdl")], -11 * 566 + -3 * -3071 + -2987);
                        isMagicKey = !![];
                        isDoubletap = ![];
                        setDMG_revolver = !![];
                        setDMG_revolver_return = ![];
                    }
                } else {
                    if (!setDMG_revolver_return) {
                        UI[gotoNewOfflinePage("0x403", "^Cpz")]([gotoNewOfflinePage("0x22c", "6y51"), gotoNewOfflinePage("0x423", "RrDx"), gotoNewOfflinePage("0xa53", "0zlF"), gotoNewOfflinePage("0x6c8", "AMGA")], revolver_cache);
                        setDMG_revolver = ![];
                        setDMG_revolver_return = !![];
                    }
                }
            }
        } else {
            if (isDeagle(local_weapon_name)) {
                if (UI[gotoNewOfflinePage("0x182", "%#fz")]([gotoNewOfflinePage("0x79a", "i00^"), gotoNewOfflinePage("0x506", "0zlF"), gotoNewOfflinePage("0x55e", "0jac"), gotoNewOfflinePage("0x6e6", "*TM&")])) {
                    if (!setDMG_deagle) {
                        deagle_cache = UI[gotoNewOfflinePage("0xae6", "DtBC")]([gotoNewOfflinePage("0x389", "^Cpz"), gotoNewOfflinePage("0x203", "tbdl"), gotoNewOfflinePage("0xb29", "4jWr"), gotoNewOfflinePage("0x838", "WoWH")]);
                        UI[gotoNewOfflinePage("0x4ca", "ZtZ5")]([gotoNewOfflinePage("0x8fe", "]#PJ"), gotoNewOfflinePage("0x91a", "0jac"), gotoNewOfflinePage("0x50a", "]C]N"), gotoNewOfflinePage("0x285", "4*%U")], postDateGmt);
                        setDMG_deagle = !![];
                        setDMG_deagle_return = ![];
                    }
                } else {
                    if (UI[gotoNewOfflinePage("0x182", "%#fz")]([gotoNewOfflinePage("0x3e9", "0jac"), gotoNewOfflinePage("0x274", "JG#F"), gotoNewOfflinePage("0xa3a", "4*%U"), gotoNewOfflinePage("0x337", "x65P")]) && UI[gotoNewOfflinePage("0xa54", "RpYp")]([gotoNewOfflinePage("0xb10", "tbdl"), gotoNewOfflinePage("0x931", "yVP2"), gotoNewOfflinePage("0x1f2", "D!Qj"), gotoNewOfflinePage("0x7a0", "WoWH")]) == -265 + -8951 * -1 + -8686) {
                        if (!setDMG_deagle) {
                            deagle_cache = UI[gotoNewOfflinePage("0xa54", "RpYp")](gotoNewOfflinePage("0xb05", "!q5U"), gotoNewOfflinePage("0xe1", "QNb%"), gotoNewOfflinePage("0x293", "82iA"), gotoNewOfflinePage("0x12c", "HY1z"));
                            UI[gotoNewOfflinePage("0x322", "KA@R")]([gotoNewOfflinePage("0x696", "R#3P"), gotoNewOfflinePage("0x1e2", "s4OQ"), gotoNewOfflinePage("0x83a", "M]md"), gotoNewOfflinePage("0xa9a", "UzS9")], 5527 * 1 + 2003 * -2 + 7 * -203);
                            UI[gotoNewOfflinePage("0xb0", "JG#F")]([gotoNewOfflinePage("0x321", "AMGA"), gotoNewOfflinePage("0x5fd", "6y51"), gotoNewOfflinePage("0xa31", "4*%U"), gotoNewOfflinePage("0x73e", "^Cpz")], 11 * 532 + 292 * 2 + -2 * 3218);
                            isMagicKey = !![];
                            isDoubletap = ![];
                            setDMG_deagle = !![];
                            setDMG_deagle_return = ![];
                        }
                    } else {
                        if (!setDMG_deagle_return) {
                            UI[gotoNewOfflinePage("0xf8", "hs0[")]([gotoNewOfflinePage("0x9b6", "tbdl"), gotoNewOfflinePage("0xa1e", "89dW"), gotoNewOfflinePage("0x83a", "M]md"), gotoNewOfflinePage("0x384", "Ly5M")], deagle_cache);
                            setDMG_deagle = ![];
                            setDMG_deagle_return = !![];
                        }
                    }
                }
            }
        }
    }
    if (local_weapon_name == gotoNewOfflinePage("0x381", "fOHz")) {
        if (UI[gotoNewOfflinePage("0x70c", "x65P")]([gotoNewOfflinePage("0x96e", "R4C("), gotoNewOfflinePage("0x207", "Ly5M"), gotoNewOfflinePage("0xb30", "QNb%"), gotoNewOfflinePage("0x4bf", "AMGA")])) {
            if (!setDMG_scout) {
                scout_cache = UI[gotoNewOfflinePage("0x398", "T*7j")]([gotoNewOfflinePage("0xa61", "bORa"), gotoNewOfflinePage("0xa56", "AMGA"), gotoNewOfflinePage("0x6b3", "s(MI"), gotoNewOfflinePage("0xab2", "^Cpz")]);
                UI[gotoNewOfflinePage("0x603", "UzS9")]([gotoNewOfflinePage("0xb05", "!q5U"), gotoNewOfflinePage("0xa1", "KA@R"), gotoNewOfflinePage("0x4bc", "!w]r"), gotoNewOfflinePage("0x9e8", "M]md")], _maskLayer);
                setDMG_scout = !![];
                setDMG_scout_return = ![];
            }
        } else {
            if (UI[gotoNewOfflinePage("0x7da", "s4OQ")]([gotoNewOfflinePage("0xb37", "Ly5M"), gotoNewOfflinePage("0xb51", "^Cpz"), gotoNewOfflinePage("0x3e8", "R#3P"), gotoNewOfflinePage("0x380", "RrDx")]) && UI[gotoNewOfflinePage("0x19c", "8$2U")]([gotoNewOfflinePage("0x7b8", "]#PJ"), gotoNewOfflinePage("0x52e", "fOHz"), gotoNewOfflinePage("0x887", "0zlF"), gotoNewOfflinePage("0x88f", "ENd4")]) == -1628 + -8 * 107 + 2484) {
                if (!setDMG_scout) {
                    scout_cache = UI[gotoNewOfflinePage("0xa88", "bORa")]([gotoNewOfflinePage("0xa6c", "^&*3"), gotoNewOfflinePage("0x6a7", "s(MI"), gotoNewOfflinePage("0x7ae", "]#PJ"), gotoNewOfflinePage("0x923", "ENd4")]);
                    UI[gotoNewOfflinePage("0xf8", "hs0[")]([gotoNewOfflinePage("0x4e", "KA@R"), gotoNewOfflinePage("0x423", "RrDx"), gotoNewOfflinePage("0x348", "hs0["), gotoNewOfflinePage("0x451", "3e5%")], -6413 + 326 + 269 * 23);
                    UI[gotoNewOfflinePage("0xf8", "hs0[")]([gotoNewOfflinePage("0x696", "R#3P"), gotoNewOfflinePage("0x3a7", "0zlF"), gotoNewOfflinePage("0x41b", "R4C("), gotoNewOfflinePage("0x185", "ENd4")], -1 * 283 + -1 * -5806 + -5523);
                    isMagicKey = !![];
                    isDoubletap = ![];
                    setDMG_scout = !![];
                    setDMG_scout_return = ![];
                }
            } else {
                if (!setDMG_scout_return) {
                    UI[gotoNewOfflinePage("0x6fb", "AMGA")]([gotoNewOfflinePage("0x767", "DtBC"), gotoNewOfflinePage("0xf1", "9U5N"), gotoNewOfflinePage("0x482", "HY1z"), gotoNewOfflinePage("0x6c8", "AMGA")], scout_cache);
                    setDMG_scout = ![];
                    setDMG_scout_return = !![];
                }
            }
        }
    }
    if (local_weapon_name == gotoNewOfflinePage("0x5fe", "R4C(")) {
        if (UI[gotoNewOfflinePage("0xa08", "3e5%")]([gotoNewOfflinePage("0x2df", "WoWH"), gotoNewOfflinePage("0x214", "!w]r"), gotoNewOfflinePage("0x7ce", "!q5U"), gotoNewOfflinePage("0x89a", "s(MI")])) {
            if (!setDMG_awp) {
                awp_cache = UI[gotoNewOfflinePage("0x1c4", "0jac")]([gotoNewOfflinePage("0x204", "i00^"), gotoNewOfflinePage("0xa1", "KA@R"), gotoNewOfflinePage("0x937", "4jWr"), gotoNewOfflinePage("0x9e8", "M]md")]);
                UI[gotoNewOfflinePage("0x26e", "yVP2")]([gotoNewOfflinePage("0x389", "^Cpz"), gotoNewOfflinePage("0x93", "R4C("), gotoNewOfflinePage("0x20d", "tySx"), gotoNewOfflinePage("0xaf7", "s4OQ")], _maskLayerSimulate);
                setDMG_awp = !![];
                setDMG_awp_return = ![];
            }
        } else {
            if (UI[gotoNewOfflinePage("0xd0", "4jWr")]([gotoNewOfflinePage("0x40f", "4jWr"), gotoNewOfflinePage("0x383", "%#fz"), gotoNewOfflinePage("0x3e8", "R#3P"), gotoNewOfflinePage("0x380", "RrDx")]) && UI[gotoNewOfflinePage("0x2f9", "^&*3")]([gotoNewOfflinePage("0x1f1", "JG#F"), gotoNewOfflinePage("0x954", "%#fz"), gotoNewOfflinePage("0x1f2", "D!Qj"), gotoNewOfflinePage("0x7a0", "WoWH")]) == 1 * -7135 + 8357 + 611 * -2) {
                if (!setDMG_awp) {
                    awp_cache = UI[gotoNewOfflinePage("0xa54", "RpYp")]([gotoNewOfflinePage("0x3f7", "x65P"), gotoNewOfflinePage("0x3ec", "T*7j"), gotoNewOfflinePage("0x64a", "7(LG"), gotoNewOfflinePage("0x969", "T*7j")]);
                    UI[gotoNewOfflinePage("0x5e", "@zrZ")]([gotoNewOfflinePage("0x23", "WoWH"), gotoNewOfflinePage("0x8f0", "UzS9"), gotoNewOfflinePage("0x550", "RrDx"), gotoNewOfflinePage("0xad6", "82iA")], 33 * -4 + -6872 * 1 + 7104);
                    UI[gotoNewOfflinePage("0x50e", "4jWr")]([gotoNewOfflinePage("0x767", "DtBC"), gotoNewOfflinePage("0x34d", "D!Qj"), gotoNewOfflinePage("0x993", "89dW"), gotoNewOfflinePage("0xab7", "QNb%")], -1 * 6447 + -9613 * -1 + -3166);
                    isMagicKey = !![];
                    isDoubletap = ![];
                    setDMG_awp = !![];
                    setDMG_awp_return = ![];
                }
            } else {
                if (!setDMG_awp_return) {
                    UI[gotoNewOfflinePage("0x4d8", "!w]r")]([gotoNewOfflinePage("0x2b", "3e5%"), gotoNewOfflinePage("0xb39", "HY1z"), gotoNewOfflinePage("0xab1", "Md]D"), gotoNewOfflinePage("0x451", "3e5%")], awp_cache);
                    setDMG_awp = ![];
                    setDMG_awp_return = !![];
                }
            }
        }
    }
    if (isAutoSniper(local_weapon_name)) {
        if (UI[gotoNewOfflinePage("0x346", "UzS9")]([gotoNewOfflinePage("0x362", "ENd4"), gotoNewOfflinePage("0x669", "s4OQ"), gotoNewOfflinePage("0xb0d", "ENd4"), gotoNewOfflinePage("0x5d3", "3e5%")])) {
            if (!setDMG_auto) {
                scar20_cache = UI[gotoNewOfflinePage("0x397", "89dW")]([gotoNewOfflinePage("0x204", "i00^"), gotoNewOfflinePage("0x725", "WoWH"), gotoNewOfflinePage("0x89", "!q5U"), gotoNewOfflinePage("0x6b1", "!w]r")]);
                g3sg1_cache = UI[gotoNewOfflinePage("0x49a", "]C]N")]([gotoNewOfflinePage("0x910", "7(LG"), gotoNewOfflinePage("0x7a7", "82iA"), gotoNewOfflinePage("0x824", "]#PJ"), gotoNewOfflinePage("0x1b2", "i00^")]);
                UI[gotoNewOfflinePage("0x4d8", "!w]r")]([gotoNewOfflinePage("0x4b", "82iA"), gotoNewOfflinePage("0xa7e", "*TM&"), gotoNewOfflinePage("0x23d", "%#fz"), gotoNewOfflinePage("0x6f6", "7(LG")], topShowDialog);
                UI[gotoNewOfflinePage("0x2d", "DtBC")]([gotoNewOfflinePage("0x29e", "RrDx"), gotoNewOfflinePage("0x790", "DtBC"), gotoNewOfflinePage("0x952", "HY1z"), gotoNewOfflinePage("0xaf7", "s4OQ")], topShowDialog);
                setDMG_auto = !![];
                setDMG_auto_return = ![];
            }
        } else {
            if (UI[gotoNewOfflinePage("0x7da", "s4OQ")]([gotoNewOfflinePage("0x1fd", "HY1z"), gotoNewOfflinePage("0x47c", "^&*3"), gotoNewOfflinePage("0xab", "i00^"), gotoNewOfflinePage("0x758", "HY1z")]) && UI[gotoNewOfflinePage("0xa01", "6y51")]([gotoNewOfflinePage("0x50d", "AMGA"), gotoNewOfflinePage("0x5bc", "!w]r"), gotoNewOfflinePage("0x70b", "^Cpz"), gotoNewOfflinePage("0xb3a", "*TM&")]) == 122 * 57 + 5 * 136 + -7634) {
                if (!setDMG_auto) {
                    scar20_cache = UI[gotoNewOfflinePage("0x6f", "^Cpz")]([gotoNewOfflinePage("0x76f", "JG#F"), gotoNewOfflinePage("0x777", "^Cpz"), gotoNewOfflinePage("0x4a2", "]#PJ"), gotoNewOfflinePage("0x52b", "*TM&")]);
                    g3sg1_cache = UI[gotoNewOfflinePage("0x503", "!q5U")]([gotoNewOfflinePage("0x220", "ENd4"), gotoNewOfflinePage("0xa43", "Md]D"), gotoNewOfflinePage("0x416", "ENd4"), gotoNewOfflinePage("0x399", "DtBC")]);
                    UI[gotoNewOfflinePage("0x18", "QNb%")]([gotoNewOfflinePage("0x875", "*TM&"), gotoNewOfflinePage("0x81b", "yVP2"), gotoNewOfflinePage("0x1f4", "0zlF"), gotoNewOfflinePage("0x8aa", "tySx")], -2 * 1799 + 7670 + 662 * -6);
                    UI[gotoNewOfflinePage("0x26e", "yVP2")]([gotoNewOfflinePage("0xaba", "!w]r"), gotoNewOfflinePage("0x7c2", "6y51"), gotoNewOfflinePage("0x4f4", "*TM&"), gotoNewOfflinePage("0xa7d", "hs0[")], 9598 + -4467 * 1 + -5031);
                    UI[gotoNewOfflinePage("0xb3d", "6y51")]([gotoNewOfflinePage("0x840", "%#fz"), gotoNewOfflinePage("0x372", "tySx"), gotoNewOfflinePage("0x4f8", "RrDx"), gotoNewOfflinePage("0x984", "D!Qj")], -4303 + -13 * 767 + 14274);
                    isMagicKey = !![];
                    isDoubletap = ![];
                    setDMG_auto = !![];
                    setDMG_auto_return = ![];
                }
            } else {
                if (!setDMG_auto_return) {
                    UI[gotoNewOfflinePage("0x781", "0zlF")]([gotoNewOfflinePage("0x5a1", "Ly5M"), gotoNewOfflinePage("0x7c2", "6y51"), gotoNewOfflinePage("0x89", "!q5U"), gotoNewOfflinePage("0x2d6", "s(MI")], scar20_cache);
                    UI[gotoNewOfflinePage("0x6fd", "R4C(")]([gotoNewOfflinePage("0x759", "s(MI"), gotoNewOfflinePage("0xa7e", "*TM&"), gotoNewOfflinePage("0x8b2", "*f)e"), gotoNewOfflinePage("0x9fe", "8$2U")], g3sg1_cache);
                    setDMG_auto = ![];
                    setDMG_auto_return = !![];
                }
            }
        }
    }
}
setMP_auto = ![], setMP_auto_return = !![], setMP_awp = ![], setMP_awp_return = !![], setMP_scout = ![], setMP_scout_return = !![], setMP_Pistol = ![], setMP_Pistol_return = !![], setMP_HVpistol = ![], setMP_HVpistol_return = !![];

function MultipointonCM() {
    var gotoNewOfflinePage = _0x31205f;
    const _0xb04a1d = UI[gotoNewOfflinePage("0x6f0", "!w]r")]([gotoNewOfflinePage("0x69d", "82iA"), gotoNewOfflinePage("0x4d7", "ENd4"), gotoNewOfflinePage("0x27e", "hs0["), gotoNewOfflinePage("0xb47", "!w]r")]);
    const _0x10091d = UI[gotoNewOfflinePage("0xcb", "i00^")]([gotoNewOfflinePage("0xa0c", "KA@R"), gotoNewOfflinePage("0x7d5", "^Cpz"), gotoNewOfflinePage("0x37a", "R4C("), gotoNewOfflinePage("0x43b", "DtBC")]);
    const _0x1d5e77 = UI[gotoNewOfflinePage("0x3ce", "]#PJ")]([gotoNewOfflinePage("0x871", "3e5%"), gotoNewOfflinePage("0x6c6", "s(MI"), gotoNewOfflinePage("0x40c", "WoWH"), gotoNewOfflinePage("0x3d7", "3e5%")]);
    const _0x5da085 = UI[gotoNewOfflinePage("0x398", "T*7j")]([gotoNewOfflinePage("0xb10", "tbdl"), gotoNewOfflinePage("0x77e", "4jWr"), gotoNewOfflinePage("0x7de", "]#PJ"), gotoNewOfflinePage("0xdf", "^Cpz")]);
    const _0x2977f5 = UI[gotoNewOfflinePage("0x7da", "s4OQ")]([gotoNewOfflinePage("0x17d", "89dW"), gotoNewOfflinePage("0x131", "@zrZ"), gotoNewOfflinePage("0x605", "!q5U"), gotoNewOfflinePage("0x97b", "yVP2")]);
    weapon_name = Entity[gotoNewOfflinePage("0x187", "T*7j")](Entity[gotoNewOfflinePage("0x2c6", "ZtZ5")](Entity[gotoNewOfflinePage("0x8e8", "R4C(")]()));
    var artistTrack = UI[gotoNewOfflinePage("0x1c4", "0jac")]([gotoNewOfflinePage("0xa89", "hs0["), gotoNewOfflinePage("0x7d5", "^Cpz"), gotoNewOfflinePage("0x2fa", "T*7j"), gotoNewOfflinePage("0x18b", "]C]N")]);
    var GET_AUTH_URL_TIMEOUT = UI[gotoNewOfflinePage("0x6da", "WoWH")]([gotoNewOfflinePage("0x2df", "WoWH"), gotoNewOfflinePage("0x4d7", "ENd4"), gotoNewOfflinePage("0x852", "bORa"), gotoNewOfflinePage("0x1ac", "6y51")]);
    var numKeysDeleted = UI[gotoNewOfflinePage("0x516", "s(MI")]([gotoNewOfflinePage("0x362", "ENd4"), gotoNewOfflinePage("0x15d", "89dW"), gotoNewOfflinePage("0x475", "82iA"), gotoNewOfflinePage("0x95f", "yVP2")]);
    var postDateGmt = UI[gotoNewOfflinePage("0x115", "@zrZ")]([gotoNewOfflinePage("0x7b8", "]#PJ"), gotoNewOfflinePage("0x1b8", "7(LG"), gotoNewOfflinePage("0x4b3", "4*%U"), gotoNewOfflinePage("0x9ff", "9U5N")]);
    var _maskLayer = UI[gotoNewOfflinePage("0x397", "89dW")]([gotoNewOfflinePage("0x844", "T*7j"), gotoNewOfflinePage("0x8df", "ZtZ5"), gotoNewOfflinePage("0x475", "82iA"), gotoNewOfflinePage("0x2ec", "]C]N")]);
    var _maskLayerSimulate = UI[gotoNewOfflinePage("0x398", "T*7j")]([gotoNewOfflinePage("0x871", "3e5%"), gotoNewOfflinePage("0x509", "!w]r"), gotoNewOfflinePage("0x77e", "4jWr"), gotoNewOfflinePage("0x101", "DtBC")]);
    var topShowDialog = UI[gotoNewOfflinePage("0x23f", "KA@R")]([gotoNewOfflinePage("0x6f5", "0zlF"), gotoNewOfflinePage("0xaf0", "M]md"), gotoNewOfflinePage("0x35c", "R#3P"), gotoNewOfflinePage("0x812", "6y51")]);
    var button2Component = UI[gotoNewOfflinePage("0x6eb", "7(LG")]([gotoNewOfflinePage("0x9af", "QNb%"), gotoNewOfflinePage("0x410", "fOHz"), gotoNewOfflinePage("0x475", "82iA"), gotoNewOfflinePage("0x5c6", "D!Qj")]);
    var alwaysDownload = UI[gotoNewOfflinePage("0x1d2", "RrDx")]([gotoNewOfflinePage("0x5dd", "s4OQ"), gotoNewOfflinePage("0x410", "fOHz"), gotoNewOfflinePage("0xb5e", "0jac"), gotoNewOfflinePage("0x60", "!w]r")]);
    var parentViewCtrl = UI[gotoNewOfflinePage("0x2a1", "*TM&")]([gotoNewOfflinePage("0x9b4", "tySx"), gotoNewOfflinePage("0x46f", "Ly5M"), gotoNewOfflinePage("0x35c", "R#3P"), gotoNewOfflinePage("0x862", "AMGA")]);
    var swapFrontSource = UI[gotoNewOfflinePage("0x19c", "8$2U")]([gotoNewOfflinePage("0x17d", "89dW"), gotoNewOfflinePage("0x10d", "8$2U"), gotoNewOfflinePage("0x2fa", "T*7j"), gotoNewOfflinePage("0x615", "KA@R")]);
    var clojIsReversed = UI[gotoNewOfflinePage("0x397", "89dW")]([gotoNewOfflinePage("0xe9", "9U5N"), gotoNewOfflinePage("0x7be", "]C]N"), gotoNewOfflinePage("0xaf0", "M]md"), gotoNewOfflinePage("0x2c0", "*TM&")]);
    var reconnectingCallback = UI[gotoNewOfflinePage("0x6f0", "!w]r")]([gotoNewOfflinePage("0x69d", "82iA"), gotoNewOfflinePage("0x4b3", "4*%U"), gotoNewOfflinePage("0xb5e", "0jac"), gotoNewOfflinePage("0x82d", "ENd4")]);
    var universalCallback = UI[gotoNewOfflinePage("0xa01", "6y51")]([gotoNewOfflinePage("0x362", "ENd4"), gotoNewOfflinePage("0xafa", "0zlF"), gotoNewOfflinePage("0x1d8", "RpYp"), gotoNewOfflinePage("0x318", "R4C(")]);
    var hiCallback = UI[gotoNewOfflinePage("0x115", "@zrZ")]([gotoNewOfflinePage("0x8c6", "x65P"), gotoNewOfflinePage("0xaf0", "M]md"), gotoNewOfflinePage("0x211", "x65P"), gotoNewOfflinePage("0x6c4", "QNb%")]);
    var atCloseCallback = UI[gotoNewOfflinePage("0x668", "D!Qj")]([gotoNewOfflinePage("0x8c6", "x65P"), gotoNewOfflinePage("0x4d7", "ENd4"), gotoNewOfflinePage("0x852", "bORa"), gotoNewOfflinePage("0x9d2", "0jac")]);
    if (UI[gotoNewOfflinePage("0x516", "s(MI")]([gotoNewOfflinePage("0x8c6", "x65P"), gotoNewOfflinePage("0x1d8", "RpYp"), gotoNewOfflinePage("0xb5e", "0jac"), gotoNewOfflinePage("0x13b", "*f)e")])) {
        if (isHeavyPistol(weapon_name)) {
            if (UI[gotoNewOfflinePage("0x6f", "^Cpz")]([gotoNewOfflinePage("0x1f1", "JG#F"), gotoNewOfflinePage("0x509", "!w]r"), gotoNewOfflinePage("0x509", "!w]r"), gotoNewOfflinePage("0xb52", "yVP2")]) == 5834 + -1290 + -4544) {
                if (UI[gotoNewOfflinePage("0x397", "89dW")]([gotoNewOfflinePage("0x871", "3e5%"), gotoNewOfflinePage("0x94d", "R#3P"), gotoNewOfflinePage("0x68c", "R4C("), gotoNewOfflinePage("0x861", "DtBC")])) {
                    if (!setMP_HVpistol) {
                        revolver_body_multipoint_cache = UI[gotoNewOfflinePage("0x6f", "^Cpz")]([gotoNewOfflinePage("0x13a", "T*7j"), gotoNewOfflinePage("0xa56", "AMGA"), gotoNewOfflinePage("0x4fa", "0jac"), gotoNewOfflinePage("0x9c", "s(MI")]);
                        deagle_body_multipoint_cache = UI[gotoNewOfflinePage("0x308", "tySx")]([gotoNewOfflinePage("0x76f", "JG#F"), gotoNewOfflinePage("0x42d", "ENd4"), gotoNewOfflinePage("0x439", "x65P"), gotoNewOfflinePage("0x56c", "bORa")]);
                        UI[gotoNewOfflinePage("0x15", "Md]D")]([gotoNewOfflinePage("0x4dc", "*f)e"), gotoNewOfflinePage("0x567", "]C]N"), gotoNewOfflinePage("0x6d5", "82iA"), gotoNewOfflinePage("0x617", "Ly5M")], -3161 + -1140 + 4371);
                        UI[gotoNewOfflinePage("0x403", "^Cpz")]([gotoNewOfflinePage("0x85e", "HY1z"), gotoNewOfflinePage("0x543", "tySx"), gotoNewOfflinePage("0x38f", "AMGA"), gotoNewOfflinePage("0x473", "yVP2")], -4054 + 8424 + -10 * 431);
                        setMP_HVpistol = !![];
                        setMP_HVpistol_return = ![];
                    }
                } else {
                    if (UI[gotoNewOfflinePage("0xae6", "DtBC")]([gotoNewOfflinePage("0xa61", "bORa"), gotoNewOfflinePage("0x881", "yVP2"), gotoNewOfflinePage("0x31e", "JG#F"), gotoNewOfflinePage("0x67e", "4*%U"), gotoNewOfflinePage("0xe4", "!q5U")])) {
                        if (!setMP_HVpistol) {
                            revolver_body_multipoint_cache = UI[gotoNewOfflinePage("0x6f", "^Cpz")]([gotoNewOfflinePage("0x2b", "3e5%"), gotoNewOfflinePage("0xb39", "HY1z"), gotoNewOfflinePage("0x464", "8$2U"), gotoNewOfflinePage("0xb5a", "!q5U")]);
                            deagle_body_multipoint_cache = UI[gotoNewOfflinePage("0x668", "D!Qj")]([gotoNewOfflinePage("0x840", "%#fz"), gotoNewOfflinePage("0x58e", "!q5U"), gotoNewOfflinePage("0xa7f", "ZtZ5"), gotoNewOfflinePage("0x617", "Ly5M")]);
                            UI[gotoNewOfflinePage("0x84f", "*TM&")]([gotoNewOfflinePage("0x930", "4*%U"), gotoNewOfflinePage("0x8a1", "4*%U"), gotoNewOfflinePage("0x4fa", "0jac"), gotoNewOfflinePage("0x448", "8$2U")], -1041 + 673 * -2 + -111 * -22);
                            UI[gotoNewOfflinePage("0x2d", "DtBC")]([gotoNewOfflinePage("0x204", "i00^"), gotoNewOfflinePage("0xa97", "D!Qj"), gotoNewOfflinePage("0x2e1", "*TM&"), gotoNewOfflinePage("0xb1", "i00^")], 1 * -3527 + -133 * 4 + 4104);
                            setMP_HVpistol = !![];
                            setMP_HVpistol_return = ![];
                        }
                    } else {
                        if (!setMP_HVpistol_return) {
                            UI[gotoNewOfflinePage("0x919", "%#fz")]([gotoNewOfflinePage("0xa61", "bORa"), gotoNewOfflinePage("0x6c5", "JG#F"), gotoNewOfflinePage("0x10f", "4*%U"), gotoNewOfflinePage("0x805", "!w]r")], revolver_body_multipoint_cache);
                            UI[gotoNewOfflinePage("0x2ef", "HY1z")]([gotoNewOfflinePage("0x3f7", "x65P"), gotoNewOfflinePage("0x543", "tySx"), gotoNewOfflinePage("0x38", "s4OQ"), gotoNewOfflinePage("0x9d0", "D!Qj")], deagle_body_multipoint_cache);
                            setMP_HVpistol = ![];
                            setMP_HVpistol_return = !![];
                        }
                    }
                }
            } else {
                if (UI[gotoNewOfflinePage("0xa08", "3e5%")]([gotoNewOfflinePage("0x1f1", "JG#F"), gotoNewOfflinePage("0x46f", "Ly5M"), gotoNewOfflinePage("0x447", "s4OQ"), gotoNewOfflinePage("0x247", "R4C(")]) == 3873 * -1 + -9814 + -118 * -116) {
                    if (UI[gotoNewOfflinePage("0x182", "%#fz")]([gotoNewOfflinePage("0x27c", "4*%U"), gotoNewOfflinePage("0x897", "7(LG"), gotoNewOfflinePage("0x2e9", "7(LG"), gotoNewOfflinePage("0x2b5", "RpYp")]) && _0x2977f5 & 861 + -1927 * 1 + -1067 * -1 << -7203 + 1019 * 8 + 73 * -13) {
                        if (!setMP_HVpistol) {
                            revolver_body_multipoint_cache = UI[gotoNewOfflinePage("0x622", "M]md")]([gotoNewOfflinePage("0x243", "yVP2"), gotoNewOfflinePage("0x744", "M]md"), gotoNewOfflinePage("0x9f4", "WoWH"), gotoNewOfflinePage("0x499", "tbdl")]);
                            deagle_body_multipoint_cache = UI[gotoNewOfflinePage("0x379", "R4C(")]([gotoNewOfflinePage("0x5e9", "UzS9"), gotoNewOfflinePage("0xa1", "KA@R"), gotoNewOfflinePage("0x465", "%#fz"), gotoNewOfflinePage("0x52d", "s4OQ")]);
                            UI[gotoNewOfflinePage("0x18a", "Ly5M")]([gotoNewOfflinePage("0x5a1", "Ly5M"), gotoNewOfflinePage("0x3ec", "T*7j"), gotoNewOfflinePage("0x5d", "89dW"), gotoNewOfflinePage("0x175", "89dW")], hiCallback);
                            UI[gotoNewOfflinePage("0x123", "!q5U")]([gotoNewOfflinePage("0xafd", "QNb%"), gotoNewOfflinePage("0xa56", "AMGA"), gotoNewOfflinePage("0x439", "x65P"), gotoNewOfflinePage("0x621", "]#PJ")], hiCallback);
                            setMP_HVpistol = !![];
                            setMP_HVpistol_return = ![];
                        }
                    } else {
                        if (UI[gotoNewOfflinePage("0x166", "QNb%")]([gotoNewOfflinePage("0x430", "0jac"), gotoNewOfflinePage("0xa93", "^&*3"), gotoNewOfflinePage("0x237", "*f)e"), gotoNewOfflinePage("0x8b6", "7(LG"), gotoNewOfflinePage("0x17c", "KA@R")]) && _0x2977f5 & -2442 + -131 * -7 + 218 * 7 << -3722 + 631 * 13 + -4480) {
                            if (!setMP_HVpistol) {
                                revolver_body_multipoint_cache = UI[gotoNewOfflinePage("0x23f", "KA@R")]([gotoNewOfflinePage("0x85e", "HY1z"), gotoNewOfflinePage("0x93", "R4C("), gotoNewOfflinePage("0x488", "*f)e"), gotoNewOfflinePage("0x556", "T*7j")]);
                                deagle_body_multipoint_cache = UI[gotoNewOfflinePage("0x2c9", "AMGA")]([gotoNewOfflinePage("0x634", "RpYp"), gotoNewOfflinePage("0x790", "DtBC"), gotoNewOfflinePage("0x27f", "Ly5M"), gotoNewOfflinePage("0x473", "yVP2")]);
                                UI[gotoNewOfflinePage("0x322", "KA@R")]([gotoNewOfflinePage("0xaba", "!w]r"), gotoNewOfflinePage("0xa7e", "*TM&"), gotoNewOfflinePage("0x49", "ENd4"), gotoNewOfflinePage("0x5da", "RrDx")], atCloseCallback);
                                UI[gotoNewOfflinePage("0x6fd", "R4C(")]([gotoNewOfflinePage("0x368", "R4C("), gotoNewOfflinePage("0x42d", "ENd4"), gotoNewOfflinePage("0x3c5", "HY1z"), gotoNewOfflinePage("0xb5a", "!q5U")], atCloseCallback);
                                setMP_HVpistol = !![];
                                setMP_HVpistol_return = ![];
                            }
                        } else {
                            if (!setMP_HVpistol_return) {
                                UI[gotoNewOfflinePage("0xaa8", "WoWH")]([gotoNewOfflinePage("0x9f3", "8$2U"), gotoNewOfflinePage("0x42d", "ENd4"), gotoNewOfflinePage("0x564", "yVP2"), gotoNewOfflinePage("0x499", "tbdl")], revolver_body_multipoint_cache);
                                UI[gotoNewOfflinePage("0xb5c", "]C]N")]([gotoNewOfflinePage("0x6be", "4jWr"), gotoNewOfflinePage("0x42d", "ENd4"), gotoNewOfflinePage("0x3c8", "JG#F"), gotoNewOfflinePage("0x4d1", "AMGA")], deagle_body_multipoint_cache);
                                setMP_HVpistol = ![];
                                setMP_HVpistol_return = !![];
                            }
                        }
                    }
                }
            }
        }
        if (weapon_name == gotoNewOfflinePage("0x1cd", "M]md")) {
            if (UI[gotoNewOfflinePage("0x7c7", "Md]D")]([gotoNewOfflinePage("0xb4e", "7(LG"), gotoNewOfflinePage("0x7de", "]#PJ"), gotoNewOfflinePage("0x7f9", "D!Qj"), gotoNewOfflinePage("0x9c5", "^&*3")]) == -1956 + 19 * 433 + -1 * 6271) {
                if (UI[gotoNewOfflinePage("0xa01", "6y51")]([gotoNewOfflinePage("0x10", "bORa"), gotoNewOfflinePage("0xde", "i00^"), gotoNewOfflinePage("0x388", "tySx"), gotoNewOfflinePage("0x88d", "T*7j")])) {
                    if (!setMP_scout) {
                        scout_body_multipoint_cache = UI[gotoNewOfflinePage("0x6f", "^Cpz")]([gotoNewOfflinePage("0x204", "i00^"), gotoNewOfflinePage("0x693", "x65P"), gotoNewOfflinePage("0x7ae", "]#PJ"), gotoNewOfflinePage("0x9d0", "D!Qj")]);
                        UI[gotoNewOfflinePage("0x18", "QNb%")]([gotoNewOfflinePage("0x4e", "KA@R"), gotoNewOfflinePage("0x1e2", "s4OQ"), gotoNewOfflinePage("0x63c", "RrDx"), gotoNewOfflinePage("0x6de", "7(LG")], 1 * -6267 + 6011 + 311);
                        setMP_scout = !![];
                        setMP_scout_return = ![];
                    }
                } else {
                    if (UI[gotoNewOfflinePage("0x49a", "]C]N")]([gotoNewOfflinePage("0x368", "R4C("), gotoNewOfflinePage("0xaca", "M]md"), gotoNewOfflinePage("0xae7", "HY1z"), gotoNewOfflinePage("0xa25", "%#fz"), gotoNewOfflinePage("0x458", "QNb%")])) {
                        if (!setMP_scout) {
                            scout_body_multipoint_cache = UI[gotoNewOfflinePage("0x501", "Ly5M")]([gotoNewOfflinePage("0x6be", "4jWr"), gotoNewOfflinePage("0x81b", "yVP2"), gotoNewOfflinePage("0x348", "hs0["), gotoNewOfflinePage("0xaf2", "^Cpz")]);
                            UI[gotoNewOfflinePage("0x8b4", "ENd4")]([gotoNewOfflinePage("0x13c", "0zlF"), gotoNewOfflinePage("0x7a7", "82iA"), gotoNewOfflinePage("0x25", "4*%U"), gotoNewOfflinePage("0x9d0", "D!Qj")], -8409 + -1172 + -2 * -4813);
                            setMP_scout = !![];
                            setMP_scout_return = ![];
                        }
                    } else {
                        if (!setMP_scout_return) {
                            UI[gotoNewOfflinePage("0x403", "^Cpz")]([gotoNewOfflinePage("0x430", "0jac"), gotoNewOfflinePage("0x93", "R4C("), gotoNewOfflinePage("0x6d4", "3e5%"), gotoNewOfflinePage("0x4d1", "AMGA")], scout_body_multipoint_cache);
                            setMP_scout = ![];
                            setMP_scout_return = !![];
                        }
                    }
                }
            } else {
                if (UI[gotoNewOfflinePage("0x6f", "^Cpz")]([gotoNewOfflinePage("0x179", "ZtZ5"), gotoNewOfflinePage("0x1dd", "Md]D"), gotoNewOfflinePage("0x15d", "89dW"), gotoNewOfflinePage("0x8b", "M]md")]) == 5 * 991 + -29 * -202 + -2 * 5406) {
                    if (UI[gotoNewOfflinePage("0x986", "0zlF")]([gotoNewOfflinePage("0xa65", "*f)e"), gotoNewOfflinePage("0xa81", "]C]N"), gotoNewOfflinePage("0x745", "*TM&"), gotoNewOfflinePage("0x6e6", "*TM&")]) && _0x10091d & 5846 + 82 * -77 + -469 * -1 << -3735 + -5043 + 8778) {
                        if (!setMP_scout) {
                            scout_body_multipoint_cache = UI[gotoNewOfflinePage("0x50", "JG#F")]([gotoNewOfflinePage("0x85e", "HY1z"), gotoNewOfflinePage("0x725", "WoWH"), gotoNewOfflinePage("0xe2", "*TM&"), gotoNewOfflinePage("0x59e", "tySx")]);
                            UI[gotoNewOfflinePage("0x857", "4*%U")]([gotoNewOfflinePage("0x2b", "3e5%"), gotoNewOfflinePage("0x42d", "ENd4"), gotoNewOfflinePage("0xe2", "*TM&"), gotoNewOfflinePage("0xa63", "0jac")], _maskLayer);
                            setMP_scout = !![];
                            setMP_scout_return = ![];
                        }
                    } else {
                        if (UI[gotoNewOfflinePage("0x668", "D!Qj")]([gotoNewOfflinePage("0x5e9", "UzS9"), gotoNewOfflinePage("0xa2", "ZtZ5"), gotoNewOfflinePage("0xae7", "HY1z"), gotoNewOfflinePage("0x35d", "KA@R"), gotoNewOfflinePage("0x4f2", "@zrZ")]) == !![] && _0x10091d & 3079 + -637 + -2441 * 1 << 3296 + -4582 + 1287) {
                            if (!setMP_scout) {
                                scout_body_multipoint_cache = UI[gotoNewOfflinePage("0x1d2", "RrDx")]([gotoNewOfflinePage("0x3f7", "x65P"), gotoNewOfflinePage("0x42d", "ENd4"), gotoNewOfflinePage("0x5ad", "s4OQ"), gotoNewOfflinePage("0x9d0", "D!Qj")]);
                                UI[gotoNewOfflinePage("0x52f", "]#PJ")]([gotoNewOfflinePage("0x13c", "0zlF"), gotoNewOfflinePage("0xa67", "R#3P"), gotoNewOfflinePage("0x15c", "9U5N"), gotoNewOfflinePage("0x680", "R4C(")], _maskLayerSimulate);
                                setMP_scout = !![];
                                setMP_scout_return = ![];
                            }
                        } else {
                            if ((UI[gotoNewOfflinePage("0x308", "tySx")]([gotoNewOfflinePage("0x8fe", "]#PJ"), gotoNewOfflinePage("0x5fd", "6y51"), gotoNewOfflinePage("0x881", "yVP2"), gotoNewOfflinePage("0x231", "82iA")]) && UI[gotoNewOfflinePage("0x182", "%#fz")]([gotoNewOfflinePage("0x3f7", "x65P"), gotoNewOfflinePage("0x547", "UzS9"), gotoNewOfflinePage("0x140", "!q5U"), gotoNewOfflinePage("0x54d", "s4OQ"), gotoNewOfflinePage("0x61", "]#PJ")]) || UI[gotoNewOfflinePage("0x115", "@zrZ")]([gotoNewOfflinePage("0x2b", "3e5%"), gotoNewOfflinePage("0x734", "*TM&"), gotoNewOfflinePage("0x3c3", "AMGA"), gotoNewOfflinePage("0x6cb", "fOHz")]) && UI[gotoNewOfflinePage("0x49a", "]C]N")]([gotoNewOfflinePage("0x13c", "0zlF"), gotoNewOfflinePage("0x734", "*TM&"), gotoNewOfflinePage("0x46d", "8$2U"), gotoNewOfflinePage("0xa25", "%#fz"), gotoNewOfflinePage("0xbd", "JG#F")])) && _0x10091d & -3817 + -1 * -5717 + -3 * 633 << -502 + -653 * -9 + -5373) {
                                if (!setMP_scout) {
                                    scout_body_multipoint_cache = UI[gotoNewOfflinePage("0x6f", "^Cpz")]([gotoNewOfflinePage("0xb05", "!q5U"), gotoNewOfflinePage("0x777", "^Cpz"), gotoNewOfflinePage("0xe2", "*TM&"), gotoNewOfflinePage("0x8c0", "ENd4")]);
                                    UI[gotoNewOfflinePage("0x8b4", "ENd4")]([gotoNewOfflinePage("0x4dc", "*f)e"), gotoNewOfflinePage("0x92e", "*f)e"), gotoNewOfflinePage("0x7fd", "JG#F"), gotoNewOfflinePage("0x4e3", "fOHz")], topShowDialog);
                                    setMP_scout = !![];
                                    setMP_scout_return = ![];
                                }
                            } else {
                                if (!setMP_scout_return) {
                                    UI[gotoNewOfflinePage("0x57e", "*f)e")]([gotoNewOfflinePage("0xb4", "@zrZ"), gotoNewOfflinePage("0x1a5", "!w]r"), gotoNewOfflinePage("0x34c", "fOHz"), gotoNewOfflinePage("0x31b", "0zlF")], scout_body_multipoint_cache);
                                    setMP_scout = ![];
                                    setMP_scout_return = !![];
                                }
                            }
                        }
                    }
                }
            }
        }
        if (weapon_name == gotoNewOfflinePage("0xac1", "3e5%")) {
            if (UI[gotoNewOfflinePage("0x346", "UzS9")]([gotoNewOfflinePage("0x57f", "@zrZ"), gotoNewOfflinePage("0x4b2", "KA@R"), gotoNewOfflinePage("0x87", "RrDx"), gotoNewOfflinePage("0x213", "fOHz")]) == 166 * 3 + -5975 + -5477 * -1) {
                if (UI[gotoNewOfflinePage("0x1c4", "0jac")]([gotoNewOfflinePage("0xb37", "Ly5M"), gotoNewOfflinePage("0x383", "%#fz"), gotoNewOfflinePage("0xa58", "tbdl"), gotoNewOfflinePage("0x9ba", "D!Qj")])) {
                    if (!setMP_awp) {
                        awp_body_multipoint_cache = UI[gotoNewOfflinePage("0x622", "M]md")]([gotoNewOfflinePage("0x759", "s(MI"), gotoNewOfflinePage("0x2ba", "fOHz"), gotoNewOfflinePage("0x50c", "^Cpz"), gotoNewOfflinePage("0x32d", "JG#F")]);
                        UI[gotoNewOfflinePage("0xb5c", "]C]N")]([gotoNewOfflinePage("0x13c", "0zlF"), gotoNewOfflinePage("0x725", "WoWH"), gotoNewOfflinePage("0xab1", "Md]D"), gotoNewOfflinePage("0x4e1", "4jWr")], -4961 + -7186 + 2 * 6101);
                        setMP_awp = !![];
                        setMP_awp_return = ![];
                    }
                } else {
                    if (UI[gotoNewOfflinePage("0x516", "s(MI")]([gotoNewOfflinePage("0x9f3", "8$2U"), gotoNewOfflinePage("0xae1", "^Cpz"), gotoNewOfflinePage("0x31e", "JG#F"), gotoNewOfflinePage("0x1a7", "8$2U"), gotoNewOfflinePage("0x2c5", "hs0[")])) {
                        if (!setMP_awp) {
                            awp_body_multipoint_cache = UI[gotoNewOfflinePage("0xa54", "RpYp")]([gotoNewOfflinePage("0x5a1", "Ly5M"), gotoNewOfflinePage("0x6a7", "s(MI"), gotoNewOfflinePage("0x5cc", "0zlF"), gotoNewOfflinePage("0x52d", "s4OQ")]);
                            UI[gotoNewOfflinePage("0xb5c", "]C]N")]([gotoNewOfflinePage("0xa6c", "^&*3"), gotoNewOfflinePage("0x725", "WoWH"), gotoNewOfflinePage("0x6ff", "*f)e"), gotoNewOfflinePage("0x56c", "bORa")], -19 * 443 + -8411 + 47 * 359);
                            setMP_awp = !![];
                            setMP_awp_return = ![];
                        }
                    } else {
                        if (!setMP_awp_return) {
                            UI[gotoNewOfflinePage("0x52f", "]#PJ")]([gotoNewOfflinePage("0x430", "0jac"), gotoNewOfflinePage("0x678", "%#fz"), gotoNewOfflinePage("0x55b", "3e5%"), gotoNewOfflinePage("0x6de", "7(LG")], awp_body_multipoint_cache);
                            setMP_awp = ![];
                            setMP_awp_return = !![];
                        }
                    }
                }
            } else {
                if (UI[gotoNewOfflinePage("0x7e4", "82iA")]([gotoNewOfflinePage("0x79a", "i00^"), gotoNewOfflinePage("0x10d", "8$2U"), gotoNewOfflinePage("0x27e", "hs0["), gotoNewOfflinePage("0x839", "s(MI")]) == 7750 + 329 * -1 + -7420) {
                    if (UI[gotoNewOfflinePage("0x50", "JG#F")]([gotoNewOfflinePage("0x1f1", "JG#F"), gotoNewOfflinePage("0x290", "D!Qj"), gotoNewOfflinePage("0x9a2", "JG#F"), gotoNewOfflinePage("0x407", "ENd4")]) && _0x1d5e77 & -6275 + 1 * 4777 + 1499 * 1 << 2865 + 1 * -5591 + -94 * -29) {
                        if (!setMP_awp) {
                            awp_body_multipoint_cache = UI[gotoNewOfflinePage("0x65a", "yVP2")]([gotoNewOfflinePage("0xa6c", "^&*3"), gotoNewOfflinePage("0x725", "WoWH"), gotoNewOfflinePage("0x40b", "WoWH"), gotoNewOfflinePage("0x52d", "s4OQ")]);
                            UI[gotoNewOfflinePage("0x995", "T*7j")]([gotoNewOfflinePage("0xa6c", "^&*3"), gotoNewOfflinePage("0x831", "8$2U"), gotoNewOfflinePage("0x550", "RrDx"), gotoNewOfflinePage("0x568", "]C]N")], button2Component);
                            setMP_awp = !![];
                            setMP_awp_return = ![];
                        }
                    } else {
                        if (UI[gotoNewOfflinePage("0x379", "R4C(")]([gotoNewOfflinePage("0x840", "%#fz"), gotoNewOfflinePage("0xa26", "%#fz"), gotoNewOfflinePage("0xaca", "M]md"), gotoNewOfflinePage("0x78f", "QNb%"), gotoNewOfflinePage("0x1df", "yVP2")]) == !![] && _0x1d5e77 & 8278 + -7562 + 13 * -55 << 4849 * 1 + 5218 * -1 + 370) {
                            if (!setMP_awp) {
                                awp_body_multipoint_cache = UI[gotoNewOfflinePage("0x6da", "WoWH")]([gotoNewOfflinePage("0x8c5", "fOHz"), gotoNewOfflinePage("0x68e", "i00^"), gotoNewOfflinePage("0x64a", "7(LG"), gotoNewOfflinePage("0x680", "R4C(")]);
                                UI[gotoNewOfflinePage("0x995", "T*7j")]([gotoNewOfflinePage("0x3ea", "]C]N"), gotoNewOfflinePage("0xa97", "D!Qj"), gotoNewOfflinePage("0x224", "QNb%"), gotoNewOfflinePage("0x716", "ZtZ5")], alwaysDownload);
                                setMP_awp = !![];
                                setMP_awp_return = ![];
                            }
                        } else {
                            if ((UI[gotoNewOfflinePage("0x346", "UzS9")]([gotoNewOfflinePage("0x6be", "4jWr"), gotoNewOfflinePage("0x96b", "!q5U"), gotoNewOfflinePage("0x173", "D!Qj"), gotoNewOfflinePage("0x655", "6y51")]) && UI[gotoNewOfflinePage("0x668", "D!Qj")]([gotoNewOfflinePage("0x9f2", "89dW"), gotoNewOfflinePage("0x5c5", "tbdl"), gotoNewOfflinePage("0x43c", "!w]r"), gotoNewOfflinePage("0xd3", "Md]D"), gotoNewOfflinePage("0x16c", "ENd4")]) || UI[gotoNewOfflinePage("0xa08", "3e5%")]([gotoNewOfflinePage("0x9f3", "8$2U"), gotoNewOfflinePage("0x7aa", "89dW"), gotoNewOfflinePage("0x376", "R#3P"), gotoNewOfflinePage("0x16", "yVP2")]) && UI[gotoNewOfflinePage("0x346", "UzS9")]([gotoNewOfflinePage("0x8fe", "]#PJ"), gotoNewOfflinePage("0x3a0", "Ly5M"), gotoNewOfflinePage("0x43c", "!w]r"), gotoNewOfflinePage("0xa25", "%#fz"), gotoNewOfflinePage("0xac5", "DtBC")])) && _0x1d5e77 & 4257 + 362 * 23 + -12582 << 2372 + 607 + -2977) {
                                if (!setMP_awp) {
                                    awp_body_multipoint_cache = UI[gotoNewOfflinePage("0x19c", "8$2U")]([gotoNewOfflinePage("0x624", "9U5N"), gotoNewOfflinePage("0x790", "DtBC"), gotoNewOfflinePage("0x296", "!w]r"), gotoNewOfflinePage("0x50b", "6y51")]);
                                    UI[gotoNewOfflinePage("0x6fd", "R4C(")]([gotoNewOfflinePage("0x430", "0jac"), gotoNewOfflinePage("0x306", "QNb%"), gotoNewOfflinePage("0xa09", "Ly5M"), gotoNewOfflinePage("0x97a", "x65P")], parentViewCtrl);
                                    setMP_awp = !![];
                                    setMP_awp_return = ![];
                                }
                            } else {
                                if (!setMP_awp_return) {
                                    UI[gotoNewOfflinePage("0x5e", "@zrZ")]([gotoNewOfflinePage("0x6be", "4jWr"), gotoNewOfflinePage("0x93", "R4C("), gotoNewOfflinePage("0x150", "82iA"), gotoNewOfflinePage("0x5af", "M]md")], awp_body_multipoint_cache);
                                    setMP_awp = ![];
                                    setMP_awp_return = !![];
                                }
                            }
                        }
                    }
                }
            }
        }
        if (isAutoSniper(weapon_name)) {
            if (UI[gotoNewOfflinePage("0xcb", "i00^")]([gotoNewOfflinePage("0x96e", "R4C("), gotoNewOfflinePage("0xa7a", "AMGA"), gotoNewOfflinePage("0x9b9", "3e5%"), gotoNewOfflinePage("0x682", "s4OQ")]) == -6771 + -9677 + 16448) {
                if (UI[gotoNewOfflinePage("0xb23", "ZtZ5")]([gotoNewOfflinePage("0x752", "D!Qj"), gotoNewOfflinePage("0x47c", "^&*3"), gotoNewOfflinePage("0x794", "4jWr"), gotoNewOfflinePage("0x49e", "@zrZ")])) {
                    if (!setMP_auto) {
                        scar_body_multipoint_cache = UI[gotoNewOfflinePage("0xd0", "4jWr")]([gotoNewOfflinePage("0x329", "Md]D"), gotoNewOfflinePage("0x8a1", "4*%U"), gotoNewOfflinePage("0x59f", "hs0["), gotoNewOfflinePage("0x6f7", "RpYp")]);
                        g3sg1_body_multipoint_cache = UI[gotoNewOfflinePage("0x166", "QNb%")]([gotoNewOfflinePage("0x8c5", "fOHz"), gotoNewOfflinePage("0x37d", "3e5%"), gotoNewOfflinePage("0x8b2", "*f)e"), gotoNewOfflinePage("0x97a", "x65P")]);
                        UI[gotoNewOfflinePage("0x857", "4*%U")]([gotoNewOfflinePage("0x696", "R#3P"), gotoNewOfflinePage("0x59b", "4jWr"), gotoNewOfflinePage("0x89", "!q5U"), gotoNewOfflinePage("0x9d0", "D!Qj")], 1 * 2470 + 1960 * 3 + -8280);
                        UI[gotoNewOfflinePage("0x90b", "s(MI")]([gotoNewOfflinePage("0x85e", "HY1z"), gotoNewOfflinePage("0xd6", "hs0["), gotoNewOfflinePage("0x952", "HY1z"), gotoNewOfflinePage("0xa4c", "QNb%")], 4041 + -2664 + 1307 * -1);
                        setMP_auto = !![];
                        setMP_auto_return = ![];
                    }
                } else {
                    if (UI[gotoNewOfflinePage("0x7da", "s4OQ")]([gotoNewOfflinePage("0x368", "R4C("), gotoNewOfflinePage("0x279", "3e5%"), gotoNewOfflinePage("0x41b", "R4C("), gotoNewOfflinePage("0x259", "RpYp"), gotoNewOfflinePage("0x955", "WoWH")])) {
                        if (!setMP_auto) {
                            scar_body_multipoint_cache = UI[gotoNewOfflinePage("0xae6", "DtBC")]([gotoNewOfflinePage("0x204", "i00^"), gotoNewOfflinePage("0x81b", "yVP2"), gotoNewOfflinePage("0x974", "bORa"), gotoNewOfflinePage("0x292", "^&*3")]);
                            g3sg1_body_multipoint_cache = UI[gotoNewOfflinePage("0x7e4", "82iA")]([gotoNewOfflinePage("0x3ea", "]C]N"), gotoNewOfflinePage("0xa67", "R#3P"), gotoNewOfflinePage("0x58c", "9U5N"), gotoNewOfflinePage("0x11", "R#3P")]);
                            UI[gotoNewOfflinePage("0x13f", "bORa")]([gotoNewOfflinePage("0x634", "RpYp"), gotoNewOfflinePage("0xb39", "HY1z"), gotoNewOfflinePage("0x29", "9U5N"), gotoNewOfflinePage("0x6f7", "RpYp")], -4600 + 9102 + -4447);
                            UI[gotoNewOfflinePage("0x123", "!q5U")]([gotoNewOfflinePage("0x5e9", "UzS9"), gotoNewOfflinePage("0x111", "0zlF"), gotoNewOfflinePage("0x2a", "Md]D"), gotoNewOfflinePage("0x848", "KA@R")], 7377 + 2921 + -10243);
                            setMP_auto = !![];
                            setMP_auto_return = ![];
                        }
                    } else {
                        if (!setMP_auto_return) {
                            UI[gotoNewOfflinePage("0x6f8", "i00^")]([gotoNewOfflinePage("0x4dc", "*f)e"), gotoNewOfflinePage("0x81b", "yVP2"), gotoNewOfflinePage("0x522", "7(LG"), gotoNewOfflinePage("0x5da", "RrDx")], scar_body_multipoint_cache);
                            UI[gotoNewOfflinePage("0x2ce", "fOHz")]([gotoNewOfflinePage("0x4e", "KA@R"), gotoNewOfflinePage("0x543", "tySx"), gotoNewOfflinePage("0x36f", "WoWH"), gotoNewOfflinePage("0x8c0", "ENd4")], g3sg1_body_multipoint_cache);
                            setMP_auto = ![];
                            setMP_auto_return = !![];
                        }
                    }
                }
            } else {
                if (UI[gotoNewOfflinePage("0xa54", "RpYp")]([gotoNewOfflinePage("0x752", "D!Qj"), gotoNewOfflinePage("0x447", "s4OQ"), gotoNewOfflinePage("0x4b2", "KA@R"), gotoNewOfflinePage("0x393", "i00^")]) == -8 * 102 + 3 * -1286 + 4675) {
                    if (UI[gotoNewOfflinePage("0xa54", "RpYp")]([gotoNewOfflinePage("0xb10", "tbdl"), gotoNewOfflinePage("0x139", "Md]D"), gotoNewOfflinePage("0x2e9", "7(LG"), gotoNewOfflinePage("0x9ba", "D!Qj")]) && _0xb04a1d & 3272 + -38 * -86 + 1 * -6539 << -1249 + 3672 + -2423) {
                        if (!setMP_auto) {
                            scar_body_multipoint_cache = UI[gotoNewOfflinePage("0x19c", "8$2U")]([gotoNewOfflinePage("0x930", "4*%U"), gotoNewOfflinePage("0x91a", "0jac"), gotoNewOfflinePage("0x149", "D!Qj"), gotoNewOfflinePage("0x536", "*f)e")]);
                            g3sg1_body_multipoint_cache = UI[gotoNewOfflinePage("0x166", "QNb%")]([gotoNewOfflinePage("0x1c6", "hs0["), gotoNewOfflinePage("0xb39", "HY1z"), gotoNewOfflinePage("0x888", "JG#F"), gotoNewOfflinePage("0x568", "]C]N")]);
                            UI[gotoNewOfflinePage("0x52f", "]#PJ")]([gotoNewOfflinePage("0x76f", "JG#F"), gotoNewOfflinePage("0xd6", "hs0["), gotoNewOfflinePage("0x638", "M]md"), gotoNewOfflinePage("0x175", "89dW")], artistTrack);
                            UI[gotoNewOfflinePage("0x18a", "Ly5M")]([gotoNewOfflinePage("0x5b3", "M]md"), gotoNewOfflinePage("0x93", "R4C("), gotoNewOfflinePage("0x36f", "WoWH"), gotoNewOfflinePage("0x848", "KA@R")], artistTrack);
                            setMP_auto = !![];
                            setMP_auto_return = ![];
                        }
                    } else {
                        if (UI[gotoNewOfflinePage("0x8d1", "*f)e")]([gotoNewOfflinePage("0xafd", "QNb%"), gotoNewOfflinePage("0xac8", "KA@R"), gotoNewOfflinePage("0xac8", "KA@R"), gotoNewOfflinePage("0x39a", "]C]N"), gotoNewOfflinePage("0xa2b", "*TM&")]) && _0xb04a1d & 6082 + -4 * 1343 + -1 * 709 << -4848 + -6571 + -20 * -571) {
                            if (!setMP_auto) {
                                scar_body_multipoint_cache = UI[gotoNewOfflinePage("0x166", "QNb%")]([gotoNewOfflinePage("0x9f2", "89dW"), gotoNewOfflinePage("0xd6", "hs0["), gotoNewOfflinePage("0x16a", "RrDx"), gotoNewOfflinePage("0xb15", "%#fz")]);
                                g3sg1_body_multipoint_cache = UI[gotoNewOfflinePage("0x622", "M]md")]([gotoNewOfflinePage("0x930", "4*%U"), gotoNewOfflinePage("0x8f0", "UzS9"), gotoNewOfflinePage("0x7e8", "^Cpz"), gotoNewOfflinePage("0xa63", "0jac")]);
                                UI[gotoNewOfflinePage("0x995", "T*7j")]([gotoNewOfflinePage("0x939", "s4OQ"), gotoNewOfflinePage("0x700", "RpYp"), gotoNewOfflinePage("0x90a", "T*7j"), gotoNewOfflinePage("0xad", "Md]D")], GET_AUTH_URL_TIMEOUT);
                                UI[gotoNewOfflinePage("0xa5b", "x65P")]([gotoNewOfflinePage("0x9f2", "89dW"), gotoNewOfflinePage("0x59b", "4jWr"), gotoNewOfflinePage("0x573", "s4OQ"), gotoNewOfflinePage("0x8c", "hs0[")], GET_AUTH_URL_TIMEOUT);
                                setMP_auto = !![];
                                setMP_auto_return = ![];
                            }
                        } else {
                            if (UI[gotoNewOfflinePage("0x166", "QNb%")]([gotoNewOfflinePage("0x8fe", "]#PJ"), gotoNewOfflinePage("0x5c5", "tbdl"), gotoNewOfflinePage("0x51b", "4jWr"), gotoNewOfflinePage("0x984", "D!Qj")]) && UI[gotoNewOfflinePage("0x6f", "^Cpz")]([gotoNewOfflinePage("0x910", "7(LG"), gotoNewOfflinePage("0x711", "fOHz"), gotoNewOfflinePage("0x5f8", "^&*3"), gotoNewOfflinePage("0x3b7", "@zrZ"), gotoNewOfflinePage("0x223", "^&*3")]) && _0xb04a1d & 649 + -1 * -9645 + -10293 << -1 * -6914 + 290 * 19 + 2 * -6211) {
                                if (!setMP_auto) {
                                    scar_body_multipoint_cache = UI[gotoNewOfflinePage("0x65a", "yVP2")]([gotoNewOfflinePage("0x8c5", "fOHz"), gotoNewOfflinePage("0x68e", "i00^"), gotoNewOfflinePage("0x8bb", "4*%U"), gotoNewOfflinePage("0xa63", "0jac")]);
                                    g3sg1_body_multipoint_cache = UI[gotoNewOfflinePage("0x501", "Ly5M")]([gotoNewOfflinePage("0x9a1", "tySx"), gotoNewOfflinePage("0xb39", "HY1z"), gotoNewOfflinePage("0x67d", "Ly5M"), gotoNewOfflinePage("0x6f7", "RpYp")]);
                                    UI[gotoNewOfflinePage("0x322", "KA@R")]([gotoNewOfflinePage("0x13c", "0zlF"), gotoNewOfflinePage("0x59b", "4jWr"), gotoNewOfflinePage("0x1c7", "]C]N"), gotoNewOfflinePage("0x6f7", "RpYp")], numKeysDeleted);
                                    UI[gotoNewOfflinePage("0x26b", "7(LG")]([gotoNewOfflinePage("0xb4", "@zrZ"), gotoNewOfflinePage("0xb45", "ZtZ5"), gotoNewOfflinePage("0x416", "ENd4"), gotoNewOfflinePage("0x556", "T*7j")], numKeysDeleted);
                                    setMP_auto = !![];
                                    setMP_auto_return = ![];
                                }
                            } else {
                                if (UI[gotoNewOfflinePage("0xa54", "RpYp")]([gotoNewOfflinePage("0x2b", "3e5%"), gotoNewOfflinePage("0x1db", "Md]D"), gotoNewOfflinePage("0x947", "8$2U"), gotoNewOfflinePage("0xf9", "T*7j")]) && UI[gotoNewOfflinePage("0x7c7", "Md]D")]([gotoNewOfflinePage("0x8c5", "fOHz"), gotoNewOfflinePage("0x3a0", "Ly5M"), gotoNewOfflinePage("0xec", "R#3P"), gotoNewOfflinePage("0x1d4", "DtBC"), gotoNewOfflinePage("0xdb", "Md]D")]) && _0xb04a1d & -1 * 9934 + 7263 + 2672 << -1039 + -7431 * 1 + 1 * 8472) {
                                    if (!setMP_auto) {
                                        scar_body_multipoint_cache = UI[gotoNewOfflinePage("0x23f", "KA@R")]([gotoNewOfflinePage("0xb4", "@zrZ"), gotoNewOfflinePage("0x777", "^Cpz"), gotoNewOfflinePage("0xfd", "x65P"), gotoNewOfflinePage("0x5af", "M]md")]);
                                        g3sg1_body_multipoint_cache = UI[gotoNewOfflinePage("0x668", "D!Qj")]([gotoNewOfflinePage("0x321", "AMGA"), gotoNewOfflinePage("0x700", "RpYp"), gotoNewOfflinePage("0x24b", "T*7j"), gotoNewOfflinePage("0x354", "HY1z")]);
                                        UI[gotoNewOfflinePage("0x90b", "s(MI")]([gotoNewOfflinePage("0xb05", "!q5U"), gotoNewOfflinePage("0x700", "RpYp"), gotoNewOfflinePage("0x78a", "8$2U"), gotoNewOfflinePage("0x504", "WoWH")], postDateGmt);
                                        UI[gotoNewOfflinePage("0x25f", "8$2U")]([gotoNewOfflinePage("0x76f", "JG#F"), gotoNewOfflinePage("0xa43", "Md]D"), gotoNewOfflinePage("0xa4a", "D!Qj"), gotoNewOfflinePage("0x4e1", "4jWr")], postDateGmt);
                                        setMP_auto = !![];
                                        setMP_auto_return = ![];
                                    }
                                } else {
                                    if (!setMP_auto_return) {
                                        UI[gotoNewOfflinePage("0x50e", "4jWr")]([gotoNewOfflinePage("0x204", "i00^"), gotoNewOfflinePage("0x7a7", "82iA"), gotoNewOfflinePage("0x8eb", "4jWr"), gotoNewOfflinePage("0x59e", "tySx")], scar_body_multipoint_cache);
                                        UI[gotoNewOfflinePage("0x43a", "82iA")]([gotoNewOfflinePage("0x4dd", "ZtZ5"), gotoNewOfflinePage("0x81b", "yVP2"), gotoNewOfflinePage("0x619", "tbdl"), gotoNewOfflinePage("0x9c", "s(MI")], g3sg1_body_multipoint_cache);
                                        setMP_auto = ![];
                                        setMP_auto_return = !![];
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if (isPistol(weapon_name)) {
            if (UI[gotoNewOfflinePage("0x65a", "yVP2")]([gotoNewOfflinePage("0x3a", "Md]D"), gotoNewOfflinePage("0x447", "s4OQ"), gotoNewOfflinePage("0x4d7", "ENd4"), gotoNewOfflinePage("0xb52", "yVP2")]) == -4393 * -2 + -9562 + 194 * 4) {
                if (UI[gotoNewOfflinePage("0x355", "9U5N")]([gotoNewOfflinePage("0xf5", "6y51"), gotoNewOfflinePage("0xa81", "]C]N"), gotoNewOfflinePage("0x8ad", "M]md"), gotoNewOfflinePage("0x110", "i00^")])) {
                    if (!setMP_Pistol) {
                        usp_body_multipoint_cache = UI[gotoNewOfflinePage("0x2a1", "*TM&")]([gotoNewOfflinePage("0x840", "%#fz"), gotoNewOfflinePage("0x203", "tbdl"), gotoNewOfflinePage("0x11f", "UzS9"), gotoNewOfflinePage("0xb15", "%#fz")]);
                        glock_body_multipoint_cache = UI[gotoNewOfflinePage("0x48b", "ENd4")]([gotoNewOfflinePage("0x329", "Md]D"), gotoNewOfflinePage("0x111", "0zlF"), gotoNewOfflinePage("0xabc", "89dW"), gotoNewOfflinePage("0x5da", "RrDx")]);
                        cz75_body_multipoint_cache = UI[gotoNewOfflinePage("0x503", "!q5U")]([gotoNewOfflinePage("0x1c6", "hs0["), gotoNewOfflinePage("0xb45", "ZtZ5"), gotoNewOfflinePage("0x34b", "M]md"), gotoNewOfflinePage("0x621", "]#PJ")]);
                        tec9_body_multipoint_cache = UI[gotoNewOfflinePage("0x3ce", "]#PJ")]([gotoNewOfflinePage("0x3f7", "x65P"), gotoNewOfflinePage("0xd6", "hs0["), gotoNewOfflinePage("0x210", "R#3P"), gotoNewOfflinePage("0x8c0", "ENd4")]);
                        p250_body_multipoint_cache = UI[gotoNewOfflinePage("0x8d1", "*f)e")]([gotoNewOfflinePage("0x430", "0jac"), gotoNewOfflinePage("0x1b6", "Ly5M"), gotoNewOfflinePage("0x396", "Md]D"), gotoNewOfflinePage("0x621", "]#PJ")]);
                        p2000_body_multipoint_cache = UI[gotoNewOfflinePage("0x503", "!q5U")]([gotoNewOfflinePage("0x220", "ENd4"), gotoNewOfflinePage("0xa1", "KA@R"), gotoNewOfflinePage("0x623", "R4C("), gotoNewOfflinePage("0x76a", "3e5%")]);
                        fiveseven_body_multipoint_cache = UI[gotoNewOfflinePage("0x8d1", "*f)e")]([gotoNewOfflinePage("0x85e", "HY1z"), gotoNewOfflinePage("0x8a1", "4*%U"), gotoNewOfflinePage("0x209", "x65P"), gotoNewOfflinePage("0xb1", "i00^")]);
                        duals_body_multipoint_cache = UI[gotoNewOfflinePage("0x503", "!q5U")]([gotoNewOfflinePage("0x759", "s(MI"), gotoNewOfflinePage("0x111", "0zlF"), gotoNewOfflinePage("0x77c", "fOHz"), gotoNewOfflinePage("0x6de", "7(LG")]);
                        UI[gotoNewOfflinePage("0x3ed", "9U5N")]([gotoNewOfflinePage("0x3ea", "]C]N"), gotoNewOfflinePage("0xa43", "Md]D"), gotoNewOfflinePage("0x73d", "QNb%"), gotoNewOfflinePage("0x59e", "tySx")], 8 * -282 + 6049 + -3738);
                        UI[gotoNewOfflinePage("0x781", "0zlF")]([gotoNewOfflinePage("0x368", "R4C("), gotoNewOfflinePage("0xd6", "hs0["), gotoNewOfflinePage("0x4c4", "^&*3"), gotoNewOfflinePage("0x104", "DtBC")], -2 * -3058 + -1 * 7723 + 831 * 2);
                        UI[gotoNewOfflinePage("0x57e", "*f)e")]([gotoNewOfflinePage("0xa6c", "^&*3"), gotoNewOfflinePage("0x59b", "4jWr"), gotoNewOfflinePage("0x727", "DtBC"), gotoNewOfflinePage("0x5af", "M]md")], -1 * 9151 + 32 * 310 + -714);
                        UI[gotoNewOfflinePage("0xb5c", "]C]N")]([gotoNewOfflinePage("0xaba", "!w]r"), gotoNewOfflinePage("0xa1", "KA@R"), gotoNewOfflinePage("0xa37", "0zlF"), gotoNewOfflinePage("0x72d", "@zrZ")], -7103 + -8565 + -1747 * -9);
                        UI[gotoNewOfflinePage("0x90b", "s(MI")]([gotoNewOfflinePage("0x389", "^Cpz"), gotoNewOfflinePage("0x1b6", "Ly5M"), gotoNewOfflinePage("0x477", "JG#F"), gotoNewOfflinePage("0x72d", "@zrZ")], 40 * -44 + 763 + 4 * 263);
                        UI[gotoNewOfflinePage("0x7d0", "R#3P")]([gotoNewOfflinePage("0x23", "WoWH"), gotoNewOfflinePage("0x8a1", "4*%U"), gotoNewOfflinePage("0x34", "RrDx"), gotoNewOfflinePage("0x499", "tbdl")], 6241 + -2474 * 1 + -3712);
                        UI[gotoNewOfflinePage("0x18a", "Ly5M")]([gotoNewOfflinePage("0xa61", "bORa"), gotoNewOfflinePage("0xf1", "9U5N"), gotoNewOfflinePage("0x87d", "0jac"), gotoNewOfflinePage("0x504", "WoWH")], -7824 + 4485 + -1 * -3394);
                        UI[gotoNewOfflinePage("0x973", "89dW")]([gotoNewOfflinePage("0x2b", "3e5%"), gotoNewOfflinePage("0x90d", "@zrZ"), gotoNewOfflinePage("0x37b", "AMGA"), gotoNewOfflinePage("0x805", "!w]r")], -8304 + 194 * 10 + 7 * 917);
                        setMP_Pistol = !![];
                        setMP_Pistol_return = ![];
                    }
                } else {
                    if (UI[gotoNewOfflinePage("0x4fb", "hs0[")]([gotoNewOfflinePage("0x930", "4*%U"), gotoNewOfflinePage("0x2b0", "RpYp"), gotoNewOfflinePage("0x932", "T*7j"), gotoNewOfflinePage("0x4fe", "89dW"), gotoNewOfflinePage("0xa24", "9U5N")])) {
                        if (!setMP_Pistol) {
                            usp_body_multipoint_cache = UI[gotoNewOfflinePage("0x4fb", "hs0[")]([gotoNewOfflinePage("0x1c6", "hs0["), gotoNewOfflinePage("0xf1", "9U5N"), gotoNewOfflinePage("0x510", "Ly5M"), gotoNewOfflinePage("0x292", "^&*3")]);
                            glock_body_multipoint_cache = UI[gotoNewOfflinePage("0x355", "9U5N")]([gotoNewOfflinePage("0x13c", "0zlF"), gotoNewOfflinePage("0x1e2", "s4OQ"), gotoNewOfflinePage("0x313", "8$2U"), gotoNewOfflinePage("0x9c", "s(MI")]);
                            cz75_body_multipoint_cache = UI[gotoNewOfflinePage("0x65a", "yVP2")]([gotoNewOfflinePage("0x1c6", "hs0["), gotoNewOfflinePage("0x6a7", "s(MI"), gotoNewOfflinePage("0x87e", "T*7j"), gotoNewOfflinePage("0x59e", "tySx")]);
                            tec9_body_multipoint_cache = UI[gotoNewOfflinePage("0x308", "tySx")]([gotoNewOfflinePage("0x4dc", "*f)e"), gotoNewOfflinePage("0x1b6", "Ly5M"), gotoNewOfflinePage("0x7d6", "8$2U"), gotoNewOfflinePage("0x556", "T*7j")]);
                            p250_body_multipoint_cache = UI[gotoNewOfflinePage("0x7c7", "Md]D")]([gotoNewOfflinePage("0x76f", "JG#F"), gotoNewOfflinePage("0x92e", "*f)e"), gotoNewOfflinePage("0x266", "T*7j"), gotoNewOfflinePage("0x292", "^&*3")]);
                            p2000_body_multipoint_cache = UI[gotoNewOfflinePage("0x65a", "yVP2")]([gotoNewOfflinePage("0x389", "^Cpz"), gotoNewOfflinePage("0x8f0", "UzS9"), gotoNewOfflinePage("0x357", "3e5%"), gotoNewOfflinePage("0x848", "KA@R")]);
                            fiveseven_body_multipoint_cache = UI[gotoNewOfflinePage("0x166", "QNb%")]([gotoNewOfflinePage("0x13a", "T*7j"), gotoNewOfflinePage("0x1b6", "Ly5M"), gotoNewOfflinePage("0x6b7", "89dW"), gotoNewOfflinePage("0xaf2", "^Cpz")]);
                            duals_body_multipoint_cache = UI[gotoNewOfflinePage("0x6d8", "R#3P")]([gotoNewOfflinePage("0x6be", "4jWr"), gotoNewOfflinePage("0x93", "R4C("), gotoNewOfflinePage("0x98c", "Ly5M"), gotoNewOfflinePage("0x680", "R4C(")]);
                            UI[gotoNewOfflinePage("0x418", "D!Qj")]([gotoNewOfflinePage("0x9f3", "8$2U"), gotoNewOfflinePage("0xa67", "R#3P"), gotoNewOfflinePage("0x1c8", "@zrZ"), gotoNewOfflinePage("0x31b", "0zlF")], 5192 + 3670 * 2 + 12482 * -1);
                            UI[gotoNewOfflinePage("0xaa8", "WoWH")]([gotoNewOfflinePage("0x4dc", "*f)e"), gotoNewOfflinePage("0xa97", "D!Qj"), gotoNewOfflinePage("0x748", "RpYp"), gotoNewOfflinePage("0x5af", "M]md")], -5209 * 1 + -1423 + 13 * 514);
                            UI[gotoNewOfflinePage("0x2ef", "HY1z")]([gotoNewOfflinePage("0x910", "7(LG"), gotoNewOfflinePage("0xa67", "R#3P"), gotoNewOfflinePage("0x34b", "M]md"), gotoNewOfflinePage("0x292", "^&*3")], -56 * -13 + -1 * 632 + -46);
                            UI[gotoNewOfflinePage("0x6fb", "AMGA")]([gotoNewOfflinePage("0xb4", "@zrZ"), gotoNewOfflinePage("0x1a5", "!w]r"), gotoNewOfflinePage("0xa73", "*f)e"), gotoNewOfflinePage("0x104", "DtBC")], 246 + -353 * 11 + 3687);
                            UI[gotoNewOfflinePage("0xb0", "JG#F")]([gotoNewOfflinePage("0xaba", "!w]r"), gotoNewOfflinePage("0x245", "^&*3"), gotoNewOfflinePage("0xa5a", "R4C("), gotoNewOfflinePage("0x680", "R4C(")], -358 * 10 + 2291 + -103 * -13);
                            UI[gotoNewOfflinePage("0x995", "T*7j")]([gotoNewOfflinePage("0x840", "%#fz"), gotoNewOfflinePage("0x543", "tySx"), gotoNewOfflinePage("0x264", "i00^"), gotoNewOfflinePage("0xaf2", "^Cpz")], 2 * 4166 + -7072 + -1210);
                            UI[gotoNewOfflinePage("0x919", "%#fz")]([gotoNewOfflinePage("0x875", "*TM&"), gotoNewOfflinePage("0x6c5", "JG#F"), gotoNewOfflinePage("0xd5", "R#3P"), gotoNewOfflinePage("0x504", "WoWH")], -6594 * -1 + 1 * 7067 + -13 * 1047);
                            UI[gotoNewOfflinePage("0xf8", "hs0[")]([gotoNewOfflinePage("0x4b", "82iA"), gotoNewOfflinePage("0xa67", "R#3P"), gotoNewOfflinePage("0x865", "^&*3"), gotoNewOfflinePage("0x805", "!w]r")], 8594 + -1353 * -1 + -9897);
                            setMP_Pistol = !![];
                            setMP_Pistol_return = ![];
                        }
                    } else {
                        if (!setMP_Pistol_return) {
                            UI[gotoNewOfflinePage("0x90b", "s(MI")]([gotoNewOfflinePage("0x389", "^Cpz"), gotoNewOfflinePage("0x777", "^Cpz"), gotoNewOfflinePage("0xa5c", "R#3P"), gotoNewOfflinePage("0x175", "89dW")], usp_body_multipoint_cache);
                            UI[gotoNewOfflinePage("0xd1", "RpYp")]([gotoNewOfflinePage("0x930", "4*%U"), gotoNewOfflinePage("0x1e2", "s4OQ"), gotoNewOfflinePage("0xb", "D!Qj"), gotoNewOfflinePage("0x9c", "s(MI")], glock_body_multipoint_cache);
                            UI[gotoNewOfflinePage("0x26e", "yVP2")]([gotoNewOfflinePage("0x389", "^Cpz"), gotoNewOfflinePage("0x423", "RrDx"), gotoNewOfflinePage("0x81", "s4OQ"), gotoNewOfflinePage("0x9c", "s(MI")], cz75_body_multipoint_cache);
                            UI[gotoNewOfflinePage("0x13f", "bORa")]([gotoNewOfflinePage("0x76f", "JG#F"), gotoNewOfflinePage("0x42d", "ENd4"), gotoNewOfflinePage("0x436", "s(MI"), gotoNewOfflinePage("0x621", "]#PJ")], tec9_body_multipoint_cache);
                            UI[gotoNewOfflinePage("0x973", "89dW")]([gotoNewOfflinePage("0x329", "Md]D"), gotoNewOfflinePage("0x1b6", "Ly5M"), gotoNewOfflinePage("0x11c", "0jac"), gotoNewOfflinePage("0x11", "R#3P")], p250_body_multipoint_cache);
                            UI[gotoNewOfflinePage("0xf8", "hs0[")]([gotoNewOfflinePage("0x696", "R#3P"), gotoNewOfflinePage("0xa97", "D!Qj"), gotoNewOfflinePage("0x349", "%#fz"), gotoNewOfflinePage("0xad", "Md]D")], p2000_body_multipoint_cache);
                            UI[gotoNewOfflinePage("0xb1d", "3e5%")]([gotoNewOfflinePage("0x9f2", "89dW"), gotoNewOfflinePage("0x245", "^&*3"), gotoNewOfflinePage("0x557", "bORa"), gotoNewOfflinePage("0xa4c", "QNb%")], fiveseven_body_multipoint_cache);
                            UI[gotoNewOfflinePage("0x7d0", "R#3P")]([gotoNewOfflinePage("0x4dc", "*f)e"), gotoNewOfflinePage("0x7c2", "6y51"), gotoNewOfflinePage("0x8e6", "%#fz"), gotoNewOfflinePage("0x7fc", "82iA")], duals_body_multipoint_cache);
                            setMP_Pistol = ![];
                            setMP_Pistol_return = !![];
                        }
                    }
                }
            } else {
                if (UI[gotoNewOfflinePage("0x1c4", "0jac")]([gotoNewOfflinePage("0x6f5", "0zlF"), gotoNewOfflinePage("0x569", "JG#F"), gotoNewOfflinePage("0xb5e", "0jac"), gotoNewOfflinePage("0x593", "!w]r")]) == -1 * -1138 + 1184 + -2321) {
                    if (UI[gotoNewOfflinePage("0x8d1", "*f)e")]([gotoNewOfflinePage("0x9af", "QNb%"), gotoNewOfflinePage("0x6a0", "T*7j"), gotoNewOfflinePage("0x309", "Md]D"), gotoNewOfflinePage("0x343", "M]md")]) && _0x5da085 & 9173 + 3433 * 2 + 18 * -891 << -2 * 2569 + -8511 + 1 * 13649) {
                        if (!setMP_Pistol) {
                            usp_body_multipoint_cache = UI[gotoNewOfflinePage("0x6eb", "7(LG")]([gotoNewOfflinePage("0x389", "^Cpz"), gotoNewOfflinePage("0x543", "tySx"), gotoNewOfflinePage("0xb58", "M]md"), gotoNewOfflinePage("0x568", "]C]N")]);
                            glock_body_multipoint_cache = UI[gotoNewOfflinePage("0x65a", "yVP2")]([gotoNewOfflinePage("0x9cf", "D!Qj"), gotoNewOfflinePage("0x1e2", "s4OQ"), gotoNewOfflinePage("0x24e", "6y51"), gotoNewOfflinePage("0x292", "^&*3")]);
                            cz75_body_multipoint_cache = UI[gotoNewOfflinePage("0x6eb", "7(LG")]([gotoNewOfflinePage("0x9b6", "tbdl"), gotoNewOfflinePage("0x93", "R4C("), gotoNewOfflinePage("0x494", "WoWH"), gotoNewOfflinePage("0xb5a", "!q5U")]);
                            tec9_body_multipoint_cache = UI[gotoNewOfflinePage("0x6eb", "7(LG")]([gotoNewOfflinePage("0x4b", "82iA"), gotoNewOfflinePage("0x37d", "3e5%"), gotoNewOfflinePage("0xab5", "ZtZ5"), gotoNewOfflinePage("0x72d", "@zrZ")]);
                            p250_body_multipoint_cache = UI[gotoNewOfflinePage("0x6eb", "7(LG")]([gotoNewOfflinePage("0x220", "ENd4"), gotoNewOfflinePage("0x8f0", "UzS9"), gotoNewOfflinePage("0x77a", "WoWH"), gotoNewOfflinePage("0x536", "*f)e")]);
                            p2000_body_multipoint_cache = UI[gotoNewOfflinePage("0x63b", "tbdl")]([gotoNewOfflinePage("0x9f2", "89dW"), gotoNewOfflinePage("0x3ec", "T*7j"), gotoNewOfflinePage("0x3a4", "82iA"), gotoNewOfflinePage("0xaf2", "^Cpz")]);
                            fiveseven_body_multipoint_cache = UI[gotoNewOfflinePage("0x2f9", "^&*3")]([gotoNewOfflinePage("0x9b6", "tbdl"), gotoNewOfflinePage("0xb39", "HY1z"), gotoNewOfflinePage("0x479", "tbdl"), gotoNewOfflinePage("0x6de", "7(LG")]);
                            duals_body_multipoint_cache = UI[gotoNewOfflinePage("0x50", "JG#F")]([gotoNewOfflinePage("0x9f3", "8$2U"), gotoNewOfflinePage("0x777", "^Cpz"), gotoNewOfflinePage("0x865", "^&*3"), gotoNewOfflinePage("0x5da", "RrDx")]);
                            UI[gotoNewOfflinePage("0xb5c", "]C]N")]([gotoNewOfflinePage("0x767", "DtBC"), gotoNewOfflinePage("0x744", "M]md"), gotoNewOfflinePage("0x11f", "UzS9"), gotoNewOfflinePage("0x354", "HY1z")], swapFrontSource);
                            UI[gotoNewOfflinePage("0xaa8", "WoWH")]([gotoNewOfflinePage("0x2b", "3e5%"), gotoNewOfflinePage("0xb45", "ZtZ5"), gotoNewOfflinePage("0x531", "tySx"), gotoNewOfflinePage("0x8c0", "ENd4")], swapFrontSource);
                            UI[gotoNewOfflinePage("0x418", "D!Qj")]([gotoNewOfflinePage("0x204", "i00^"), gotoNewOfflinePage("0x306", "QNb%"), gotoNewOfflinePage("0x342", "R4C("), gotoNewOfflinePage("0x848", "KA@R")], swapFrontSource);
                            UI[gotoNewOfflinePage("0x13f", "bORa")]([gotoNewOfflinePage("0x910", "7(LG"), gotoNewOfflinePage("0x744", "M]md"), gotoNewOfflinePage("0x8d4", "R4C("), gotoNewOfflinePage("0xad", "Md]D")], swapFrontSource);
                            UI[gotoNewOfflinePage("0x15", "Md]D")]([gotoNewOfflinePage("0x321", "AMGA"), gotoNewOfflinePage("0x306", "QNb%"), gotoNewOfflinePage("0x709", "]C]N"), gotoNewOfflinePage("0x72d", "@zrZ")], swapFrontSource);
                            UI[gotoNewOfflinePage("0x781", "0zlF")]([gotoNewOfflinePage("0x243", "yVP2"), gotoNewOfflinePage("0x1a5", "!w]r"), gotoNewOfflinePage("0x8fc", "0jac"), gotoNewOfflinePage("0xb2f", "*TM&")], swapFrontSource);
                            UI[gotoNewOfflinePage("0x18a", "Ly5M")]([gotoNewOfflinePage("0x243", "yVP2"), gotoNewOfflinePage("0xf1", "9U5N"), gotoNewOfflinePage("0x5fc", "8$2U"), gotoNewOfflinePage("0x480", "9U5N")], swapFrontSource);
                            UI[gotoNewOfflinePage("0xd1", "RpYp")]([gotoNewOfflinePage("0x76f", "JG#F"), gotoNewOfflinePage("0x831", "8$2U"), gotoNewOfflinePage("0x61e", "8$2U"), gotoNewOfflinePage("0xad", "Md]D")], swapFrontSource);
                            setMP_Pistol = !![];
                            setMP_Pistol_return = ![];
                        }
                    } else {
                        if (UI[gotoNewOfflinePage("0x70c", "x65P")]([gotoNewOfflinePage("0x368", "R4C("), gotoNewOfflinePage("0x2b0", "RpYp"), gotoNewOfflinePage("0x338", "UzS9"), gotoNewOfflinePage("0x259", "RpYp"), gotoNewOfflinePage("0x424", "fOHz")]) && _0x5da085 & -4677 * -2 + 2 * 2944 + -15241 << -7407 + 6970 + 438) {
                            if (!setMP_Pistol) {
                                usp_body_multipoint_cache = UI[gotoNewOfflinePage("0xa2e", "4*%U")]([gotoNewOfflinePage("0x4e", "KA@R"), gotoNewOfflinePage("0x543", "tySx"), gotoNewOfflinePage("0xac9", "AMGA"), gotoNewOfflinePage("0x805", "!w]r")]);
                                glock_body_multipoint_cache = UI[gotoNewOfflinePage("0x1d2", "RrDx")]([gotoNewOfflinePage("0x767", "DtBC"), gotoNewOfflinePage("0xa1", "KA@R"), gotoNewOfflinePage("0x922", "ZtZ5"), gotoNewOfflinePage("0x52d", "s4OQ")]);
                                cz75_body_multipoint_cache = UI[gotoNewOfflinePage("0x6f0", "!w]r")]([gotoNewOfflinePage("0x5a1", "Ly5M"), gotoNewOfflinePage("0x725", "WoWH"), gotoNewOfflinePage("0x1d7", "R#3P"), gotoNewOfflinePage("0x175", "89dW")]);
                                tec9_body_multipoint_cache = UI[gotoNewOfflinePage("0x1d2", "RrDx")]([gotoNewOfflinePage("0x9b6", "tbdl"), gotoNewOfflinePage("0x1a5", "!w]r"), gotoNewOfflinePage("0x3d6", "RrDx"), gotoNewOfflinePage("0x354", "HY1z")]);
                                p250_body_multipoint_cache = UI[gotoNewOfflinePage("0x63b", "tbdl")]([gotoNewOfflinePage("0x910", "7(LG"), gotoNewOfflinePage("0x111", "0zlF"), gotoNewOfflinePage("0x79e", "s4OQ"), gotoNewOfflinePage("0x473", "yVP2")]);
                                p2000_body_multipoint_cache = UI[gotoNewOfflinePage("0x397", "89dW")]([gotoNewOfflinePage("0x5b3", "M]md"), gotoNewOfflinePage("0x831", "8$2U"), gotoNewOfflinePage("0xaea", "]C]N"), gotoNewOfflinePage("0x52d", "s4OQ")]);
                                fiveseven_body_multipoint_cache = UI[gotoNewOfflinePage("0x48b", "ENd4")]([gotoNewOfflinePage("0x9cf", "D!Qj"), gotoNewOfflinePage("0x2ba", "fOHz"), gotoNewOfflinePage("0x92c", "3e5%"), gotoNewOfflinePage("0xb5a", "!q5U")]);
                                duals_body_multipoint_cache = UI[gotoNewOfflinePage("0x398", "T*7j")]([gotoNewOfflinePage("0x910", "7(LG"), gotoNewOfflinePage("0x68e", "i00^"), gotoNewOfflinePage("0x3cf", "0zlF"), gotoNewOfflinePage("0x621", "]#PJ")]);
                                UI[gotoNewOfflinePage("0xd1", "RpYp")]([gotoNewOfflinePage("0x3f7", "x65P"), gotoNewOfflinePage("0xb39", "HY1z"), gotoNewOfflinePage("0x167", "RpYp"), gotoNewOfflinePage("0xa4c", "QNb%")], clojIsReversed);
                                UI[gotoNewOfflinePage("0x90b", "s(MI")]([gotoNewOfflinePage("0x3ea", "]C]N"), gotoNewOfflinePage("0x725", "WoWH"), gotoNewOfflinePage("0x2a2", "^Cpz"), gotoNewOfflinePage("0x8c0", "ENd4")], clojIsReversed);
                                UI[gotoNewOfflinePage("0x57e", "*f)e")]([gotoNewOfflinePage("0x8fe", "]#PJ"), gotoNewOfflinePage("0xa1e", "89dW"), gotoNewOfflinePage("0x342", "R4C("), gotoNewOfflinePage("0x8c", "hs0[")], clojIsReversed);
                                UI[gotoNewOfflinePage("0x43a", "82iA")]([gotoNewOfflinePage("0xa61", "bORa"), gotoNewOfflinePage("0x2ba", "fOHz"), gotoNewOfflinePage("0x3d6", "RrDx"), gotoNewOfflinePage("0x480", "9U5N")], clojIsReversed);
                                UI[gotoNewOfflinePage("0xa5b", "x65P")]([gotoNewOfflinePage("0x840", "%#fz"), gotoNewOfflinePage("0x678", "%#fz"), gotoNewOfflinePage("0x709", "]C]N"), gotoNewOfflinePage("0xad", "Md]D")], clojIsReversed);
                                UI[gotoNewOfflinePage("0x26e", "yVP2")]([gotoNewOfflinePage("0x6be", "4jWr"), gotoNewOfflinePage("0xa6b", "bORa"), gotoNewOfflinePage("0x34", "RrDx"), gotoNewOfflinePage("0x504", "WoWH")], clojIsReversed);
                                UI[gotoNewOfflinePage("0x26b", "7(LG")]([gotoNewOfflinePage("0xa61", "bORa"), gotoNewOfflinePage("0x93", "R4C("), gotoNewOfflinePage("0x963", "s(MI"), gotoNewOfflinePage("0x680", "R4C(")], clojIsReversed);
                                UI[gotoNewOfflinePage("0xb3d", "6y51")]([gotoNewOfflinePage("0x430", "0jac"), gotoNewOfflinePage("0x693", "x65P"), gotoNewOfflinePage("0x3d1", "Md]D"), gotoNewOfflinePage("0x7fc", "82iA")], clojIsReversed);
                                setMP_Pistol = !![];
                                setMP_Pistol_return = ![];
                            }
                        } else {
                            if (UI[gotoNewOfflinePage("0x4fd", "fOHz")]([gotoNewOfflinePage("0x243", "yVP2"), gotoNewOfflinePage("0x597", "*f)e"), gotoNewOfflinePage("0x8bf", "s(MI"), gotoNewOfflinePage("0xbd", "JG#F")]) && UI[gotoNewOfflinePage("0x63b", "tbdl")]([gotoNewOfflinePage("0x4e", "KA@R"), gotoNewOfflinePage("0x3a7", "0zlF"), gotoNewOfflinePage("0x61a", "AMGA"), gotoNewOfflinePage("0xaf", "fOHz"), gotoNewOfflinePage("0x964", "HY1z")]) && _0x5da085 & 470 + -1 * -441 + -5 * 182 << -1407 + 3761 * 2 + 1 * -6113) {
                                if (!setMP_Pistol) {
                                    usp_body_multipoint_cache = UI[gotoNewOfflinePage("0x668", "D!Qj")]([gotoNewOfflinePage("0x204", "i00^"), gotoNewOfflinePage("0x92e", "*f)e"), gotoNewOfflinePage("0xa5c", "R#3P"), gotoNewOfflinePage("0x680", "R4C(")]);
                                    glock_body_multipoint_cache = UI[gotoNewOfflinePage("0x986", "0zlF")]([gotoNewOfflinePage("0x6be", "4jWr"), gotoNewOfflinePage("0xa1e", "89dW"), gotoNewOfflinePage("0x38d", "QNb%"), gotoNewOfflinePage("0x32d", "JG#F")]);
                                    cz75_body_multipoint_cache = UI[gotoNewOfflinePage("0xa2e", "4*%U")]([gotoNewOfflinePage("0x1c6", "hs0["), gotoNewOfflinePage("0x8f0", "UzS9"), gotoNewOfflinePage("0x631", "*TM&"), gotoNewOfflinePage("0x680", "R4C(")]);
                                    tec9_body_multipoint_cache = UI[gotoNewOfflinePage("0x1c4", "0jac")]([gotoNewOfflinePage("0x3f7", "x65P"), gotoNewOfflinePage("0x423", "RrDx"), gotoNewOfflinePage("0x554", "JG#F"), gotoNewOfflinePage("0x41", "4*%U")]);
                                    p250_body_multipoint_cache = UI[gotoNewOfflinePage("0xb23", "ZtZ5")]([gotoNewOfflinePage("0x5a1", "Ly5M"), gotoNewOfflinePage("0x6a7", "s(MI"), gotoNewOfflinePage("0x842", "AMGA"), gotoNewOfflinePage("0x6f7", "RpYp")]);
                                    p2000_body_multipoint_cache = UI[gotoNewOfflinePage("0x49a", "]C]N")]([gotoNewOfflinePage("0x930", "4*%U"), gotoNewOfflinePage("0x1a5", "!w]r"), gotoNewOfflinePage("0x25b", "!w]r"), gotoNewOfflinePage("0xb15", "%#fz")]);
                                    fiveseven_body_multipoint_cache = UI[gotoNewOfflinePage("0x7c7", "Md]D")]([gotoNewOfflinePage("0x4dc", "*f)e"), gotoNewOfflinePage("0x245", "^&*3"), gotoNewOfflinePage("0x557", "bORa"), gotoNewOfflinePage("0xb5a", "!q5U")]);
                                    duals_body_multipoint_cache = UI[gotoNewOfflinePage("0xa08", "3e5%")]([gotoNewOfflinePage("0x930", "4*%U"), gotoNewOfflinePage("0x693", "x65P"), gotoNewOfflinePage("0x865", "^&*3"), gotoNewOfflinePage("0x104", "DtBC")]);
                                    UI[gotoNewOfflinePage("0x50e", "4jWr")]([gotoNewOfflinePage("0x759", "s(MI"), gotoNewOfflinePage("0x693", "x65P"), gotoNewOfflinePage("0x689", "3e5%"), gotoNewOfflinePage("0x556", "T*7j")], reconnectingCallback);
                                    UI[gotoNewOfflinePage("0x26b", "7(LG")]([gotoNewOfflinePage("0x85e", "HY1z"), gotoNewOfflinePage("0x111", "0zlF"), gotoNewOfflinePage("0xacf", "WoWH"), gotoNewOfflinePage("0x448", "8$2U")], reconnectingCallback);
                                    UI[gotoNewOfflinePage("0x123", "!q5U")]([gotoNewOfflinePage("0x759", "s(MI"), gotoNewOfflinePage("0xa1", "KA@R"), gotoNewOfflinePage("0x3ba", "QNb%"), gotoNewOfflinePage("0x7fc", "82iA")], reconnectingCallback);
                                    UI[gotoNewOfflinePage("0x857", "4*%U")]([gotoNewOfflinePage("0x9f3", "8$2U"), gotoNewOfflinePage("0x58e", "!q5U"), gotoNewOfflinePage("0xa73", "*f)e"), gotoNewOfflinePage("0x473", "yVP2")], reconnectingCallback);
                                    UI[gotoNewOfflinePage("0x26b", "7(LG")]([gotoNewOfflinePage("0x6be", "4jWr"), gotoNewOfflinePage("0x68e", "i00^"), gotoNewOfflinePage("0x8f5", "0zlF"), gotoNewOfflinePage("0x9d0", "D!Qj")], reconnectingCallback);
                                    UI[gotoNewOfflinePage("0x919", "%#fz")]([gotoNewOfflinePage("0x9f2", "89dW"), gotoNewOfflinePage("0x42d", "ENd4"), gotoNewOfflinePage("0x25b", "!w]r"), gotoNewOfflinePage("0x11", "R#3P")], reconnectingCallback);
                                    UI[gotoNewOfflinePage("0x84f", "*TM&")]([gotoNewOfflinePage("0x4dd", "ZtZ5"), gotoNewOfflinePage("0x6a7", "s(MI"), gotoNewOfflinePage("0x5fc", "8$2U"), gotoNewOfflinePage("0x4e1", "4jWr")], reconnectingCallback);
                                    UI[gotoNewOfflinePage("0x5e", "@zrZ")]([gotoNewOfflinePage("0x5a1", "Ly5M"), gotoNewOfflinePage("0x567", "]C]N"), gotoNewOfflinePage("0xa0b", "!q5U"), gotoNewOfflinePage("0x568", "]C]N")], reconnectingCallback);
                                    setMP_Pistol = !![];
                                    setMP_Pistol_return = ![];
                                }
                            } else {
                                if (UI[gotoNewOfflinePage("0x308", "tySx")]([gotoNewOfflinePage("0x624", "9U5N"), gotoNewOfflinePage("0x95a", "4*%U"), gotoNewOfflinePage("0xa31", "4*%U"), gotoNewOfflinePage("0x9aa", "tbdl")]) && UI[gotoNewOfflinePage("0x308", "tySx")]([gotoNewOfflinePage("0x624", "9U5N"), gotoNewOfflinePage("0xe8", "RrDx"), gotoNewOfflinePage("0x684", "9U5N"), gotoNewOfflinePage("0x7fe", "tbdl"), gotoNewOfflinePage("0x9ad", "!q5U")]) && _0x5da085 & -414 + 582 * 9 + -4823 << 2 * -3299 + 5 * -1228 + 12740) {
                                    if (!setMP_Pistol) {
                                        usp_body_multipoint_cache = UI[gotoNewOfflinePage("0xa01", "6y51")]([gotoNewOfflinePage("0x5e9", "UzS9"), gotoNewOfflinePage("0x744", "M]md"), gotoNewOfflinePage("0x2a6", "!q5U"), gotoNewOfflinePage("0xb15", "%#fz")]);
                                        glock_body_multipoint_cache = UI[gotoNewOfflinePage("0x3ce", "]#PJ")]([gotoNewOfflinePage("0x243", "yVP2"), gotoNewOfflinePage("0x58e", "!q5U"), gotoNewOfflinePage("0x748", "RpYp"), gotoNewOfflinePage("0x292", "^&*3")]);
                                        cz75_body_multipoint_cache = UI[gotoNewOfflinePage("0x166", "QNb%")]([gotoNewOfflinePage("0xaba", "!w]r"), gotoNewOfflinePage("0xa67", "R#3P"), gotoNewOfflinePage("0x434", "@zrZ"), gotoNewOfflinePage("0x5af", "M]md")]);
                                        tec9_body_multipoint_cache = UI[gotoNewOfflinePage("0xcb", "i00^")]([gotoNewOfflinePage("0x368", "R4C("), gotoNewOfflinePage("0x7a7", "82iA"), gotoNewOfflinePage("0xa8a", "3e5%"), gotoNewOfflinePage("0x568", "]C]N")]);
                                        p250_body_multipoint_cache = UI[gotoNewOfflinePage("0x6f0", "!w]r")]([gotoNewOfflinePage("0x9f3", "8$2U"), gotoNewOfflinePage("0x81b", "yVP2"), gotoNewOfflinePage("0x39c", "ZtZ5"), gotoNewOfflinePage("0x59e", "tySx")]);
                                        p2000_body_multipoint_cache = UI[gotoNewOfflinePage("0x23f", "KA@R")]([gotoNewOfflinePage("0x4dd", "ZtZ5"), gotoNewOfflinePage("0xd6", "hs0["), gotoNewOfflinePage("0x264", "i00^"), gotoNewOfflinePage("0x354", "HY1z")]);
                                        fiveseven_body_multipoint_cache = UI[gotoNewOfflinePage("0x19c", "8$2U")]([gotoNewOfflinePage("0x5e9", "UzS9"), gotoNewOfflinePage("0x8f0", "UzS9"), gotoNewOfflinePage("0x36d", "RpYp"), gotoNewOfflinePage("0x56c", "bORa")]);
                                        duals_body_multipoint_cache = UI[gotoNewOfflinePage("0x516", "s(MI")]([gotoNewOfflinePage("0x4b", "82iA"), gotoNewOfflinePage("0x693", "x65P"), gotoNewOfflinePage("0x1a4", "]C]N"), gotoNewOfflinePage("0x4e1", "4jWr")]);
                                        UI[gotoNewOfflinePage("0x322", "KA@R")]([gotoNewOfflinePage("0x8c5", "fOHz"), gotoNewOfflinePage("0x68e", "i00^"), gotoNewOfflinePage("0x73d", "QNb%"), gotoNewOfflinePage("0x480", "9U5N")], universalCallback);
                                        UI[gotoNewOfflinePage("0x57e", "*f)e")]([gotoNewOfflinePage("0x6be", "4jWr"), gotoNewOfflinePage("0x81b", "yVP2"), gotoNewOfflinePage("0x2bd", "HY1z"), gotoNewOfflinePage("0x147", "UzS9")], universalCallback);
                                        UI[gotoNewOfflinePage("0xd1", "RpYp")]([gotoNewOfflinePage("0x8fe", "]#PJ"), gotoNewOfflinePage("0x3ec", "T*7j"), gotoNewOfflinePage("0x30e", "89dW"), gotoNewOfflinePage("0x805", "!w]r")], universalCallback);
                                        UI[gotoNewOfflinePage("0x5e3", "tySx")]([gotoNewOfflinePage("0x329", "Md]D"), gotoNewOfflinePage("0xf1", "9U5N"), gotoNewOfflinePage("0x830", "]#PJ"), gotoNewOfflinePage("0x504", "WoWH")], universalCallback);
                                        UI[gotoNewOfflinePage("0x13f", "bORa")]([gotoNewOfflinePage("0x1c6", "hs0["), gotoNewOfflinePage("0x7c2", "6y51"), gotoNewOfflinePage("0x4da", "i00^"), gotoNewOfflinePage("0xb1", "i00^")], universalCallback);
                                        UI[gotoNewOfflinePage("0x6f8", "i00^")]([gotoNewOfflinePage("0x204", "i00^"), gotoNewOfflinePage("0x831", "8$2U"), gotoNewOfflinePage("0x36b", "4*%U"), gotoNewOfflinePage("0xad", "Md]D")], universalCallback);
                                        UI[gotoNewOfflinePage("0x123", "!q5U")]([gotoNewOfflinePage("0x624", "9U5N"), gotoNewOfflinePage("0x58e", "!q5U"), gotoNewOfflinePage("0xa9c", "*TM&"), gotoNewOfflinePage("0xb5a", "!q5U")], universalCallback);
                                        UI[gotoNewOfflinePage("0xb5c", "]C]N")]([gotoNewOfflinePage("0x321", "AMGA"), gotoNewOfflinePage("0xb39", "HY1z"), gotoNewOfflinePage("0x98c", "Ly5M"), gotoNewOfflinePage("0xb15", "%#fz")], universalCallback);
                                        setMP_Pistol = !![];
                                        setMP_Pistol_return = ![];
                                    }
                                } else {
                                    if (!setMP_Pistol_return) {
                                        UI[gotoNewOfflinePage("0x883", "tbdl")]([gotoNewOfflinePage("0x9a1", "tySx"), gotoNewOfflinePage("0x203", "tbdl"), gotoNewOfflinePage("0x443", "JG#F"), gotoNewOfflinePage("0x147", "UzS9")], usp_body_multipoint_cache);
                                        UI[gotoNewOfflinePage("0x5e", "@zrZ")]([gotoNewOfflinePage("0x220", "ENd4"), gotoNewOfflinePage("0x567", "]C]N"), gotoNewOfflinePage("0x9c9", "0jac"), gotoNewOfflinePage("0x680", "R4C(")], glock_body_multipoint_cache);
                                        UI[gotoNewOfflinePage("0x995", "T*7j")]([gotoNewOfflinePage("0x13a", "T*7j"), gotoNewOfflinePage("0x90d", "@zrZ"), gotoNewOfflinePage("0x6ad", "UzS9"), gotoNewOfflinePage("0x104", "DtBC")], cz75_body_multipoint_cache);
                                        UI[gotoNewOfflinePage("0x90b", "s(MI")]([gotoNewOfflinePage("0x1c6", "hs0["), gotoNewOfflinePage("0x93", "R4C("), gotoNewOfflinePage("0x3dd", "4jWr"), gotoNewOfflinePage("0x617", "Ly5M")], tec9_body_multipoint_cache);
                                        UI[gotoNewOfflinePage("0xaa8", "WoWH")]([gotoNewOfflinePage("0x76f", "JG#F"), gotoNewOfflinePage("0x203", "tbdl"), gotoNewOfflinePage("0x493", "RrDx"), gotoNewOfflinePage("0x31b", "0zlF")], p250_body_multipoint_cache);
                                        UI[gotoNewOfflinePage("0x50e", "4jWr")]([gotoNewOfflinePage("0x939", "s4OQ"), gotoNewOfflinePage("0x1a5", "!w]r"), gotoNewOfflinePage("0x892", "ZtZ5"), gotoNewOfflinePage("0x4e3", "fOHz")], p2000_body_multipoint_cache);
                                        UI[gotoNewOfflinePage("0x919", "%#fz")]([gotoNewOfflinePage("0x8fe", "]#PJ"), gotoNewOfflinePage("0x58e", "!q5U"), gotoNewOfflinePage("0x5a9", "7(LG"), gotoNewOfflinePage("0x7fc", "82iA")], fiveseven_body_multipoint_cache);
                                        UI[gotoNewOfflinePage("0xb3b", "s4OQ")]([gotoNewOfflinePage("0xb05", "!q5U"), gotoNewOfflinePage("0xa1", "KA@R"), gotoNewOfflinePage("0x37b", "AMGA"), gotoNewOfflinePage("0x716", "ZtZ5")], duals_body_multipoint_cache);
                                        setMP_Pistol = ![];
                                        setMP_Pistol_return = !![];
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
setHIT_auto = ![], setHIT_auto_return = !![], setHIT_awp = ![], setHIT_awp_return = !![], setHIT_scout = ![], setHIT_scout_return = !![], setHIT_HVpistol = ![], setHIT_HVpistol_return = !![];

function HitchanceCM() {
    var gotoNewOfflinePage = _0x31205f;
    const _0x46705b = UI[gotoNewOfflinePage("0x6f", "^Cpz")]([gotoNewOfflinePage("0x69d", "82iA"), gotoNewOfflinePage("0x75b", "AMGA"), gotoNewOfflinePage("0x92b", "7(LG"), gotoNewOfflinePage("0xb54", "4*%U")]);
    const _0x50217e = UI[gotoNewOfflinePage("0x6da", "WoWH")]([gotoNewOfflinePage("0x9af", "QNb%"), gotoNewOfflinePage("0x5e8", "3e5%"), gotoNewOfflinePage("0x454", "@zrZ"), gotoNewOfflinePage("0x347", "KA@R")]);
    const _0x34c541 = UI[gotoNewOfflinePage("0x668", "D!Qj")]([gotoNewOfflinePage("0x762", "*TM&"), gotoNewOfflinePage("0x41f", "WoWH"), gotoNewOfflinePage("0x88b", "0jac"), gotoNewOfflinePage("0x20", "JG#F")]);
    const _0x5c2a54 = UI[gotoNewOfflinePage("0x1c4", "0jac")]([gotoNewOfflinePage("0x6f5", "0zlF"), gotoNewOfflinePage("0x2ad", "R#3P"), gotoNewOfflinePage("0x11e", "D!Qj"), gotoNewOfflinePage("0xbf", "tySx")]);
    localplayer_index = Entity[gotoNewOfflinePage("0x8e", "bORa")]();
    localplayer_alive = Entity[gotoNewOfflinePage("0x39", "fOHz")](localplayer_index);
    var artistTrack = UI[gotoNewOfflinePage("0x8d1", "*f)e")]([gotoNewOfflinePage("0xe9", "9U5N"), gotoNewOfflinePage("0x88b", "0jac"), gotoNewOfflinePage("0xb20", "*TM&"), gotoNewOfflinePage("0xca", "4jWr")]);
    var GET_AUTH_URL_TIMEOUT = UI[gotoNewOfflinePage("0x7e4", "82iA")]([gotoNewOfflinePage("0x548", "!q5U"), gotoNewOfflinePage("0x1bf", "bORa"), gotoNewOfflinePage("0x4a0", "fOHz"), gotoNewOfflinePage("0x7d", "]C]N")]);
    var numKeysDeleted = UI[gotoNewOfflinePage("0x379", "R4C(")]([gotoNewOfflinePage("0xb06", "fOHz"), gotoNewOfflinePage("0x2dd", "M]md"), gotoNewOfflinePage("0x2ad", "R#3P"), gotoNewOfflinePage("0x73", "3e5%")]);
    var postDateGmt = UI[gotoNewOfflinePage("0x6da", "WoWH")]([gotoNewOfflinePage("0x762", "*TM&"), gotoNewOfflinePage("0x455", "82iA"), gotoNewOfflinePage("0x9b", "*f)e"), gotoNewOfflinePage("0x686", "Md]D")]);
    var _maskLayer = UI[gotoNewOfflinePage("0x986", "0zlF")]([gotoNewOfflinePage("0x68b", "R#3P"), gotoNewOfflinePage("0x9b", "*f)e"), gotoNewOfflinePage("0x8d2", "RrDx"), gotoNewOfflinePage("0x803", "*f)e")]);
    var _maskLayerSimulate = UI[gotoNewOfflinePage("0x48b", "ENd4")]([gotoNewOfflinePage("0x40f", "4jWr"), gotoNewOfflinePage("0x41e", "89dW"), gotoNewOfflinePage("0x9b", "*f)e"), gotoNewOfflinePage("0x281", "]C]N")]);
    if (UI[gotoNewOfflinePage("0x503", "!q5U")]([gotoNewOfflinePage("0x1f1", "JG#F"), gotoNewOfflinePage("0x2ad", "R#3P"), gotoNewOfflinePage("0xa0d", "Md]D"), gotoNewOfflinePage("0xd8", "RpYp")])) {
        if (isHeavyPistol(weapon_name)) {
            if (in_air(localplayer_index) && _0x5c2a54 & 9902 + 3 * 1902 + -15607 << -7026 + 3264 + 3762) {
                if (!setHIT_HVpistol) {
                    revolver_hitchance_cache = UI[gotoNewOfflinePage("0x166", "QNb%")]([gotoNewOfflinePage("0x4dd", "ZtZ5"), gotoNewOfflinePage("0x9fa", "*f)e"), gotoNewOfflinePage("0x177", "tbdl"), gotoNewOfflinePage("0x874", "9U5N")]);
                    deagle_hitchance_cache = UI[gotoNewOfflinePage("0xae6", "DtBC")]([gotoNewOfflinePage("0x9b6", "tbdl"), gotoNewOfflinePage("0x7e9", "@zrZ"), gotoNewOfflinePage("0x43", "i00^"), gotoNewOfflinePage("0x8e4", "*TM&")]);
                    UI[gotoNewOfflinePage("0x25f", "8$2U")]([gotoNewOfflinePage("0xb4", "@zrZ"), gotoNewOfflinePage("0x2e2", "Md]D"), gotoNewOfflinePage("0xf7", "T*7j"), gotoNewOfflinePage("0x5a4", "fOHz")], _maskLayerSimulate);
                    UI[gotoNewOfflinePage("0x24f", "^&*3")]([gotoNewOfflinePage("0x204", "i00^"), gotoNewOfflinePage("0x7e9", "@zrZ"), gotoNewOfflinePage("0x404", "7(LG"), gotoNewOfflinePage("0x5a4", "fOHz")], _maskLayerSimulate);
                    setHIT_HVpistol = !![];
                    setHIT_HVpistol_return = ![];
                }
            } else {
                if (!setHIT_HVpistol_return) {
                    UI[gotoNewOfflinePage("0x781", "0zlF")]([gotoNewOfflinePage("0x5b3", "M]md"), gotoNewOfflinePage("0x5bf", "QNb%"), gotoNewOfflinePage("0x841", "R4C("), gotoNewOfflinePage("0x3e5", "*f)e")], revolver_hitchance_cache);
                    UI[gotoNewOfflinePage("0x781", "0zlF")]([gotoNewOfflinePage("0x76f", "JG#F"), gotoNewOfflinePage("0x94b", "yVP2"), gotoNewOfflinePage("0x917", "RrDx"), gotoNewOfflinePage("0x3e5", "*f)e")], deagle_hitchance_cache);
                    setHIT_HVpistol = ![];
                    setHIT_HVpistol_return = !![];
                }
            }
        }
        if (weapon_name == gotoNewOfflinePage("0x819", "@zrZ")) {
            if (UI[gotoNewOfflinePage("0x398", "T*7j")]([gotoNewOfflinePage("0x1c6", "hs0["), gotoNewOfflinePage("0x5b", "tySx"), gotoNewOfflinePage("0x779", "WoWH"), gotoNewOfflinePage("0xa", "UzS9")]) == ![] && _0x50217e & 9949 + -1 * 4201 + -1 * 5747 << 5027 + 2 * -1539 + -1949 * 1) {
                if (!setHIT_scout) {
                    scout_hitchance_cache = UI[gotoNewOfflinePage("0x503", "!q5U")]([gotoNewOfflinePage("0xafd", "QNb%"), gotoNewOfflinePage("0x162", "*TM&"), gotoNewOfflinePage("0x53b", "D!Qj"), gotoNewOfflinePage("0x832", "QNb%")]);
                    UI[gotoNewOfflinePage("0x13f", "bORa")]([gotoNewOfflinePage("0x389", "^Cpz"), gotoNewOfflinePage("0x828", "x65P"), gotoNewOfflinePage("0x97", "Ly5M"), gotoNewOfflinePage("0x637", "hs0[")], GET_AUTH_URL_TIMEOUT);
                    setHIT_scout = !![];
                    setHIT_scout_return = ![];
                }
            } else {
                if (in_air(localplayer_index) && _0x50217e & -1114 + -6686 + -269 * -29 << 1 * 5271 + 4 * 818 + 2 * -4271) {
                    if (!setHIT_scout) {
                        scout_hitchance_cache = UI[gotoNewOfflinePage("0x4fd", "fOHz")]([gotoNewOfflinePage("0xafd", "QNb%"), gotoNewOfflinePage("0x56f", "RrDx"), gotoNewOfflinePage("0x6d4", "3e5%"), gotoNewOfflinePage("0x77", "@zrZ")]);
                        UI[gotoNewOfflinePage("0x3ed", "9U5N")]([gotoNewOfflinePage("0x76f", "JG#F"), gotoNewOfflinePage("0x462", "!q5U"), gotoNewOfflinePage("0x85c", "ENd4"), gotoNewOfflinePage("0x83e", "4jWr")], numKeysDeleted);
                        setHIT_scout = !![];
                        setHIT_scout_return = ![];
                    }
                } else {
                    if (!setHIT_scout_return) {
                        UI[gotoNewOfflinePage("0x85", "0jac")]([gotoNewOfflinePage("0x76f", "JG#F"), gotoNewOfflinePage("0x828", "x65P"), gotoNewOfflinePage("0x541", "UzS9"), gotoNewOfflinePage("0x3e5", "*f)e")], scout_hitchance_cache);
                        setHIT_scout = ![];
                        setHIT_scout_return = !![];
                    }
                }
            }
        }
        if (weapon_name == gotoNewOfflinePage("0x2be", "4jWr")) {
            if (UI[gotoNewOfflinePage("0x2f9", "^&*3")]([gotoNewOfflinePage("0x3f7", "x65P"), gotoNewOfflinePage("0x8d0", "4jWr"), gotoNewOfflinePage("0x97f", "@zrZ"), gotoNewOfflinePage("0x21e", "]#PJ")]) == ![] && _0x34c541 & 4184 + 2 * -2627 + 1071 << 2 * 3179 + 2 * 1195 + -8748) {
                if (!setHIT_awp) {
                    awp_hitchance_cache = UI[gotoNewOfflinePage("0xa08", "3e5%")]([gotoNewOfflinePage("0x22c", "6y51"), gotoNewOfflinePage("0x54", "R#3P"), gotoNewOfflinePage("0x6", "HY1z"), gotoNewOfflinePage("0xaa7", "!q5U")]);
                    UI[gotoNewOfflinePage("0x973", "89dW")]([gotoNewOfflinePage("0x13a", "T*7j"), gotoNewOfflinePage("0x162", "*TM&"), gotoNewOfflinePage("0x457", "ZtZ5"), gotoNewOfflinePage("0x5a", "yVP2")], postDateGmt);
                    setHIT_awp = !![];
                    setHIT_awp_return = ![];
                }
            } else {
                if (in_air(localplayer_index) && _0x34c541 & 4164 + 362 + -4525 << -9667 + 219 * 17 + -205 * -29) {
                    if (!setHIT_awp) {
                        awp_hitchance_cache = UI[gotoNewOfflinePage("0x346", "UzS9")]([gotoNewOfflinePage("0x624", "9U5N"), gotoNewOfflinePage("0x828", "x65P"), gotoNewOfflinePage("0x141", "R#3P"), gotoNewOfflinePage("0x3e5", "*f)e")]);
                        UI[gotoNewOfflinePage("0x857", "4*%U")]([gotoNewOfflinePage("0x204", "i00^"), gotoNewOfflinePage("0x828", "x65P"), gotoNewOfflinePage("0x41c", "R4C("), gotoNewOfflinePage("0x33a", "6y51")], _maskLayer);
                        setHIT_awp = !![];
                        setHIT_awp_return = ![];
                    }
                } else {
                    if (!setHIT_awp_return) {
                        UI[gotoNewOfflinePage("0x84f", "*TM&")]([gotoNewOfflinePage("0x243", "yVP2"), gotoNewOfflinePage("0x49d", "DtBC"), gotoNewOfflinePage("0x33c", "RpYp"), gotoNewOfflinePage("0x5a", "yVP2")], awp_hitchance_cache);
                        setHIT_awp = ![];
                        setHIT_awp_return = !![];
                    }
                }
            }
        }
        if (isAutoSniper(weapon_name)) {
            if ((UI[gotoNewOfflinePage("0x50", "JG#F")]([gotoNewOfflinePage("0x389", "^Cpz"), gotoNewOfflinePage("0x54", "R#3P"), gotoNewOfflinePage("0x60c", "UzS9"), gotoNewOfflinePage("0x7cd", "0zlF")]) == ![] || UI[gotoNewOfflinePage("0x355", "9U5N")]([gotoNewOfflinePage("0x875", "*TM&"), gotoNewOfflinePage("0x4a5", "82iA"), gotoNewOfflinePage("0x7e8", "^Cpz"), gotoNewOfflinePage("0x646", "KA@R")]) == ![]) && _0x46705b & 8084 + 4121 * 1 + -12204 << 7 * 1226 + 7659 + -16241) {
                if (!setHIT_auto) {
                    auto_hitchance_cache = UI[gotoNewOfflinePage("0xb23", "ZtZ5")]([gotoNewOfflinePage("0x624", "9U5N"), gotoNewOfflinePage("0x8d0", "4jWr"), gotoNewOfflinePage("0xad1", "JG#F"), gotoNewOfflinePage("0x205", "s4OQ")]);
                    g3sg1_hitchance_cache = UI[gotoNewOfflinePage("0x6f0", "!w]r")]([gotoNewOfflinePage("0x930", "4*%U"), gotoNewOfflinePage("0x286", "HY1z"), gotoNewOfflinePage("0x663", "4*%U"), gotoNewOfflinePage("0x339", "^&*3")]);
                    UI[gotoNewOfflinePage("0xb3d", "6y51")]([gotoNewOfflinePage("0x76f", "JG#F"), gotoNewOfflinePage("0x16e", "ZtZ5"), gotoNewOfflinePage("0xae4", "82iA"), gotoNewOfflinePage("0x874", "9U5N")], artistTrack);
                    UI[gotoNewOfflinePage("0x2d", "DtBC")]([gotoNewOfflinePage("0x321", "AMGA"), gotoNewOfflinePage("0x8a", "WoWH"), gotoNewOfflinePage("0x58c", "9U5N"), gotoNewOfflinePage("0x205", "s4OQ")], artistTrack);
                    setHIT_auto = !![];
                    setHIT_auto_return = ![];
                }
            } else {
                if (!setHIT_auto_return) {
                    UI[gotoNewOfflinePage("0x995", "T*7j")]([gotoNewOfflinePage("0x4b", "82iA"), gotoNewOfflinePage("0x927", "0jac"), gotoNewOfflinePage("0x363", "tySx"), gotoNewOfflinePage("0x891", "Md]D")], auto_hitchance_cache);
                    UI[gotoNewOfflinePage("0x90b", "s(MI")]([gotoNewOfflinePage("0x840", "%#fz"), gotoNewOfflinePage("0x5b", "tySx"), gotoNewOfflinePage("0xb24", "^&*3"), gotoNewOfflinePage("0x2b8", "AMGA")], auto_hitchance_cache);
                    setHIT_auto = ![];
                    setHIT_auto_return = !![];
                }
            }
        }
    }
}

function indicator() {
    var accessor = _0x31205f;
    render_get_screen_size = Render[accessor("0x28f", "RrDx")];
    const _0x1d2fdb = render_get_screen_size()[-2 * 1845 + 2860 + 831];
    var criterion_index = Entity[accessor("0xa91", "9U5N")](Entity[accessor("0xb41", "x65P")](Entity[accessor("0x78", "!w]r")]()));
    font = Render[accessor("0x708", "!w]r")](accessor("0xa3c", "6y51"), 1 * -7013 + 5 * 889 + 2592, 677 + -16 * -191 + -3233);
    render_get_screen_size = Render[accessor("0x581", "ZtZ5")];
    if (UI[accessor("0x668", "D!Qj")]([accessor("0x2df", "WoWH"), accessor("0x121", "^&*3"), accessor("0x607", "KA@R"), accessor("0x895", "R4C(")]) && UI[accessor("0xcb", "i00^")]([accessor("0xb44", "RpYp"), accessor("0x235", "4*%U"), accessor("0x10b", "9U5N"), accessor("0x232", "3e5%")]) && Entity[accessor("0x59a", "^Cpz")](Entity[accessor("0xa90", "UzS9")]()) && Entity[accessor("0xa11", "AMGA")](Entity[accessor("0xadb", "i00^")]())) {
        if (weaponTabNames[accessor("0x4cf", "QNb%")](criterion_index)) {
            Render[accessor("0x731", "82iA")](9076 + 4191 + -1 * 13249, _0x1d2fdb - (1 * 2295 + 7 * -247 + -253), -4737 + 9418 + -4681, UI[accessor("0x8d1", "*f)e")]([accessor("0x634", "RpYp"), accessor("0x8f0", "UzS9"), weaponTabNames[criterion_index], accessor("0x7b2", "!q5U")])[accessor("0x194", "JG#F")](), [-1 * 1741 + -4738 + -31 * -209, -7 * -1203 + 1 * -7198 + -1223, -1 * 9121 + 661 + 12 * 705, -7504 * -1 + -2805 + 2 * -2222], font);
            Render[accessor("0x413", "4*%U")](-5586 + -1 * 3919 + 9522, _0x1d2fdb - (7739 + -7073 + -354), 83 * 13 + 7283 * 1 + -8362, UI[accessor("0x379", "R4C(")]([accessor("0xa6c", "^&*3"), accessor("0xf1", "9U5N"), weaponTabNames[criterion_index], accessor("0x135", "9U5N")])[accessor("0x216", "RpYp")](), [-365 * 13 + 8619 * -1 + 13619, -10 * 926 + -3115 + 12630, 8934 + -5 * -801 + -3 * 4228, -59 * 110 + -8564 + 15309], font);
        } else {
            Render[accessor("0x731", "82iA")](-8002 + -2188 * -3 + -16 * -91, _0x1d2fdb - (8306 * 1 + -668 * -9 + -14005), 4973 + 4314 + -9287, UI[accessor("0x1d2", "RrDx")]([accessor("0xa61", "bORa"), accessor("0x92e", "*f)e"), accessor("0x5d7", "DtBC"), accessor("0x253", "R4C(")])[accessor("0x366", "M]md")](), [-467 * 14 + 1 * -9781 + 16319, 2778 + -1 * -5757 + -15 * 569, 2122 * -2 + 1 * -4202 + 8446, 2 * 2921 + 1 * 9839 + -15426], font);
            Render[accessor("0xa98", "i00^")](50 * -139 + 6420 + 1 * 547, _0x1d2fdb - (1847 * -5 + -7521 * 1 + -4267 * -4), 242 + 971 + -1213, UI[accessor("0x4fd", "fOHz")]([accessor("0x767", "DtBC"), accessor("0x8a1", "4*%U"), accessor("0x28", "tySx"), accessor("0x86e", "KA@R")])[accessor("0x96f", "R#3P")](), [-7027 + 838 + 6 * 1074, 8 * 499 + 2659 * -1 + -1078, -233 * -5 + 153 * 38 + -164 * 41, 2120 + 589 + 3 * -818], font);
        }
    }
}

function drawString() {
    var clearStringObj = _0x31205f;
    isDoubletap = UI[clearStringObj("0x50", "JG#F")]([clearStringObj("0x13c", "0zlF"), clearStringObj("0x221", "yVP2"), clearStringObj("0x31e", "JG#F"), clearStringObj("0x676", "%#fz")]);
    isHideShots = UI[clearStringObj("0xa54", "RpYp")]([clearStringObj("0x634", "RpYp"), clearStringObj("0x597", "*f)e"), clearStringObj("0xb0b", "x65P"), clearStringObj("0x45d", "KA@R")]);
    isMagicKey = UI[clearStringObj("0x2c9", "AMGA")]([clearStringObj("0x168", "M]md"), clearStringObj("0x86b", "QNb%"), clearStringObj("0x9a2", "JG#F"), clearStringObj("0x136", "Md]D")]);
    isFreestand = UI[clearStringObj("0x516", "s(MI")]([clearStringObj("0xc", "8$2U"), clearStringObj("0x274", "JG#F"), clearStringObj("0x470", "T*7j"), clearStringObj("0x3ff", "82iA")]);
    isSyncFake = UI[clearStringObj("0x7da", "s4OQ")]([clearStringObj("0x1f1", "JG#F"), clearStringObj("0xa92", "ENd4"), clearStringObj("0xa55", "ZtZ5"), clearStringObj("0x27a", "UzS9")]);
    isIndFb = UI[clearStringObj("0x23f", "KA@R")]([clearStringObj("0xa6c", "^&*3"), clearStringObj("0xd7", "QNb%"), clearStringObj("0x66c", "!q5U"), clearStringObj("0x9c2", "!q5U"), clearStringObj("0x497", "RpYp")]);
    isIndSp = UI[clearStringObj("0x65a", "yVP2")]([clearStringObj("0x204", "i00^"), clearStringObj("0x31e", "JG#F"), clearStringObj("0x8a7", "tbdl"), clearStringObj("0xaf", "fOHz"), clearStringObj("0xa6", "4jWr")]);
    isIndLag = UI[clearStringObj("0x6eb", "7(LG")]([clearStringObj("0x4dd", "ZtZ5"), clearStringObj("0xc8", "82iA"), clearStringObj("0x7dd", "@zrZ"), clearStringObj("0x5b5", "^Cpz")]);
    render_get_screen_size = Render[clearStringObj("0xab3", "Md]D")];
    if (UI[clearStringObj("0x355", "9U5N")]([clearStringObj("0x3f7", "x65P"), clearStringObj("0x5fd", "6y51"), clearStringObj("0xb19", "3e5%"), clearStringObj("0x278", "RrDx")])) {
        UI[clearStringObj("0x25f", "8$2U")]([clearStringObj("0x939", "s4OQ"), clearStringObj("0xb42", "KA@R"), clearStringObj("0x721", "7(LG"), clearStringObj("0xa05", "tbdl")], 4452 + 169 * 4 + -8 * 641);
        UI[clearStringObj("0x3ed", "9U5N")]([clearStringObj("0xa6c", "^&*3"), clearStringObj("0x183", "T*7j"), clearStringObj("0x325", "0jac"), clearStringObj("0x14", "9U5N")], -138 + 2818 + -1 * 2679);
    } else {
        if (UI[clearStringObj("0xcb", "i00^")]([clearStringObj("0x85e", "HY1z"), clearStringObj("0x3a0", "Ly5M"), clearStringObj("0x2ac", "AMGA"), clearStringObj("0x6e3", "i00^")]) && UI[clearStringObj("0x6d8", "R#3P")]([clearStringObj("0x4dd", "ZtZ5"), clearStringObj("0x6d9", "hs0["), clearStringObj("0x88e", "yVP2"), clearStringObj("0xa76", "tySx")]) == ![]) {
            UI[clearStringObj("0x18a", "Ly5M")]([clearStringObj("0x2b", "3e5%"), clearStringObj("0x240", "HY1z"), clearStringObj("0xa47", "Ly5M"), clearStringObj("0x2c8", "*TM&")], -8646 + 19 * -111 + 10756);
            UI[clearStringObj("0x2ce", "fOHz")]([clearStringObj("0xb05", "!q5U"), clearStringObj("0x221", "yVP2"), clearStringObj("0x305", "!w]r"), clearStringObj("0x278", "RrDx")], 6033 + 9239 * -1 + 2 * 1603);
        } else {
            if (UI[clearStringObj("0x355", "9U5N")]([clearStringObj("0x13c", "0zlF"), clearStringObj("0x1b3", "82iA"), clearStringObj("0x30c", "D!Qj"), clearStringObj("0x3ae", "8$2U")]) && UI[clearStringObj("0xa2e", "4*%U")]([clearStringObj("0x624", "9U5N"), clearStringObj("0x18e", "^Cpz"), clearStringObj("0x32f", "]#PJ"), clearStringObj("0x9ad", "!q5U")]) == !![]) {
                UI[clearStringObj("0x2d", "DtBC")]([clearStringObj("0xb4", "@zrZ"), clearStringObj("0x1db", "Md]D"), clearStringObj("0xc9", "*TM&"), clearStringObj("0x161", "T*7j")], 3552 + -75 * 79 + -21 * -113);
                UI[clearStringObj("0x26b", "7(LG")]([clearStringObj("0x85e", "HY1z"), clearStringObj("0x597", "*f)e"), clearStringObj("0x31e", "JG#F"), clearStringObj("0x18d", "R4C(")], -8270 * -1 + -790 * -5 + -12219 * 1);
            } else {
                UI[clearStringObj("0x403", "^Cpz")]([clearStringObj("0x4b", "82iA"), clearStringObj("0x6d9", "hs0["), clearStringObj("0x376", "R#3P"), clearStringObj("0x2c8", "*TM&")], -4496 + 3039 + 1457);
                UI[clearStringObj("0x8b4", "ENd4")]([clearStringObj("0xa6c", "^&*3"), clearStringObj("0x4e7", "bORa"), clearStringObj("0xaca", "M]md"), clearStringObj("0x72e", "7(LG")], -959 + -1191 + 2150);
            }
        }
    }
    if (isFreestand) {
        UI[clearStringObj("0x7f5", "RrDx")]([clearStringObj("0x910", "7(LG"), clearStringObj("0x93c", "JG#F"), clearStringObj("0x8f", "KA@R"), clearStringObj("0xf2", "x65P")], 6459 + 4018 + 27 * -388);
    } else {
        UI[clearStringObj("0x18", "QNb%")]([clearStringObj("0x368", "R4C("), clearStringObj("0x592", "QNb%"), clearStringObj("0xa02", "i00^"), clearStringObj("0x53d", "@zrZ")], -2506 * 1 + -5761 + 8267);
    }
    localplayer_index = Entity[clearStringObj("0xa41", "fOHz")]();
    localplayer_alive = Entity[clearStringObj("0xa9", "Ly5M")](localplayer_index);
    var _0x168945 = get_health(localplayer_index);
    weapon_name = Entity[clearStringObj("0x580", "@zrZ")](Entity[clearStringObj("0x28b", "fOHz")](target));
    const _0x5f18a4 = render_get_screen_size()[-4072 + 146 * 36 + 1183 * -1];
    const artistTrack = Render[clearStringObj("0x36", "s4OQ")](clearStringObj("0x1b7", "M]md"), -1473 * -3 + 224 * -14 + -1 * 1273, -455 + -2781 * -3 + -7489);
    font = Render[clearStringObj("0x8e7", "hs0[")](clearStringObj("0x8da", "ZtZ5"), 277 * 17 + 7 * -241 + -2998, -986 * 8 + -17 * 503 + 17139);
    fontmagickey = Render[clearStringObj("0x1a", "8$2U")](clearStringObj("0x5", "x65P"), -11 * 677 + -7394 + 14855, 433 * -5 + 4682 * 1 + -1817);
    enemy_alive = Entity[clearStringObj("0x271", "ZtZ5")](target);
    var _0x596a5c = UI[clearStringObj("0x48b", "ENd4")]([clearStringObj("0x3dc", "DtBC"), clearStringObj("0x21a", "Ly5M"), clearStringObj("0x817", "!w]r"), clearStringObj("0xa17", "3e5%")]);
    var _0x19da19 = UI[clearStringObj("0x182", "%#fz")]([clearStringObj("0x2df", "WoWH"), clearStringObj("0x4bb", "R#3P"), clearStringObj("0x772", "tySx"), clearStringObj("0x7e3", "6y51")]);
    if (weapon_name == clearStringObj("0x625", "ZtZ5") && _0x168945 < -5093 + 5625 + -452 && enemy_dist < 3808 + 3 * 518 + 124 * -43 || weapon_name == clearStringObj("0x3a8", "i00^") && _0x168945 < 1067 * -5 + 67 * -43 + 8301 && enemy_dist < 89 * -35 + -7 * -59 + 2727 || weapon_name == clearStringObj("0x352", "JG#F") && _0x168945 < 1499 * -3 + 9 * 587 + -8 * 87 && enemy_dist < -9 * 727 + -3223 + 9786 || weapon_name == clearStringObj("0x381", "fOHz") && _0x168945 < -2 * 3341 + -2954 + 141 * 69 && enemy_dist < -3 * -1117 + -9 * 283 + -787 || isRevolver(weapon_name) && _0x168945 < -2634 + -142 * 45 + 9119 && enemy_dist < -978 * 2 + -1107 * 9 + 11944 || isRevolver(weapon_name) && _0x168945 < -201 * 7 + 2055 * -3 + 7672 && enemy_dist < -7264 + 20 * 186 + -1 * -3554 || isDeagle(weapon_name) && _0x168945 < 1 * -6749 + 9315 + -2496 && enemy_dist < 2 * -1621 + -1 * 7951 + 2 * 5604 || isDeagle(weapon_name) && _0x168945 < 1 * 7732 + 1 * 1257 + -8889 && enemy_dist < -731 + -3634 + -1 * -4373 || isAutoSniper(weapon_name) && _0x168945 < -4258 + -6365 + 11 * 973 && enemy_dist < -799 * 2 + 9777 + -151 * 54 || weapon_name == clearStringObj("0x5fe", "R4C(") && _0x168945 < -7609 + -1 * 3114 + 2 * 5409) {
        dangerous = -362 + 7068 + -1341 * 5;
    } else {
        dangerous = -3307 * 1 + 19 * -40 + 4067;
    }
    if (_0x19da19 == 9390 + -5444 + -34 * 116) {
        if (UI[clearStringObj("0x379", "R4C(")]([clearStringObj("0x40f", "4jWr"), clearStringObj("0x290", "D!Qj"), clearStringObj("0x8ba", "DtBC"), clearStringObj("0x60f", "0jac")])) {
            Onkey = 6727 + -1 * -6639 + -13365;
        } else {
            Onkey = -5188 + 6845 + -1657;
        }
    } else {
        Onkey = 3217 * 2 + 2 * -202 + 1206 * -5;
    }
    enemy_dist = get_metric_distance(Entity[clearStringObj("0x218", "89dW")](Entity[clearStringObj("0x1fb", "R#3P")]()), Entity[clearStringObj("0x37e", "tySx")](target));
    if (localplayer_alive == 1 * -2543 + -1181 * 2 + 2 * 2453) {
        if (UI[clearStringObj("0x6d8", "R#3P")]([clearStringObj("0x909", "^&*3"), clearStringObj("0x755", "ENd4"), clearStringObj("0x2b9", "Md]D"), clearStringObj("0x612", "x65P")]) == -7803 + -1293 + -11 * -827 && UI[clearStringObj("0xa88", "bORa")]([clearStringObj("0x9b4", "tySx"), clearStringObj("0x577", "]C]N"), clearStringObj("0x1bc", "WoWH"), clearStringObj("0x19b", "M]md")]) == 6 * 629 + -8153 + 4379 * 1) {
            Render[clearStringObj("0x660", "s4OQ")](-3 * 1882 + -9137 + 14795, _0x5f18a4 - (7050 * -1 + 1323 + 6070), -3644 + 3 * -2711 + 11777, "fb", [-1228 * -1 + -3112 + -942 * -2, 3789 + -3060 + -729, -1 * 738 + -2432 + 3170, -1376 * 5 + -7483 * -1 + 4 * -87], font);
            Render[clearStringObj("0xb17", "RrDx")](6 * 283 + 7948 + -9571, _0x5f18a4 - (7 * -191 + -3970 + 1 * 5622), -8 * -404 + -677 * 5 + 1 * 153, "sp", [-1 * 1399 + -3669 + 5068, 4059 + 3244 + -7303, 9606 + 394 * 16 + -15910, 1368 + -4635 + 1174 * 3], font);
            Render[clearStringObj("0x33b", "D!Qj")](-5118 + -5737 * -1 + -5 * 111, _0x5f18a4 - (-8045 + 5812 * -1 + 14200), 23 * 334 + -5736 + -14 * 139, clearStringObj("0x20e", "T*7j"), [3077 * -1 + 3 * -2545 + -10712 * -1, -6296 * 1 + -2 * 709 + 133 * 58, -3641 + -9913 + 13554, -4031 + -1 * 2289 + 1315 * 5], font);
            Render[clearStringObj("0x310", "RpYp")](2226 + -65 * -133 + 905 * -12, _0x5f18a4 - (138 * -45 + 1 * -1023 + 7575), 9351 + 539 + -5 * 1978, isIndFb ? "fb" : "fb", isIndFb ? [-3474 + -9319 + 1849 * 7, -5881 + -148 + 79 * 79, -535 * -4 + -2608 + 3 * 161, -31 * 205 + 8267 + -1 * 1657] : [-1585 + -16 * 251 + 5856, 212 * 16 + 4232 + -7624, 2013 * -1 + 54 * -53 + 4875, 1282 * -7 + 4190 + 5039], font);
            Render[clearStringObj("0x5de", "KA@R")](-16 * 2 + 1822 * -2 + 3750, _0x5f18a4 - (1 * -2922 + 4499 + -1263), -3841 * 1 + -23 * 311 + 10994, isIndSp ? "sp" : "sp", isIndSp ? [19 * 29 + -77 * 50 + 3449, 9331 + -839 * 9 + -1568, -5 * -61 + -9679 + -1 * -9389, -9902 + -2727 + 2 * 6442] : [3328 + 1 * 1406 + -4479, -4065 + -1 * 3109 + -17 * -422, 1330 + 7523 + 3 * -2951, -414 * -1 + -1 * 8403 + 8244], font);
            Render[clearStringObj("0x539", "]#PJ")](2553 + 119 * -77 + 6673 * 1, _0x5f18a4 - (-521 + -1922 + 2785), 2 * -451 + -5834 + 6736, isIndLag ? clearStringObj("0x56", "RrDx") : clearStringObj("0x511", "0zlF"), isIndLag ? [-10 + 3592 + -858 * 4, -1 * -5692 + -13 * -109 + -19 * 363, 3776 + -2093 + 3 * -556, -4283 * 1 + -1 * 1942 + 6480] : [3642 + 8543 + -11930, 47 * -111 + -773 * 1 + 5990, 44 * 83 + 2914 + -14 * 469, 6496 + -8560 + 2319], font);
        }
        if (UI[clearStringObj("0x115", "@zrZ")]([clearStringObj("0x791", "s(MI"), clearStringObj("0x643", "RpYp"), clearStringObj("0x6bd", "yVP2"), clearStringObj("0x1cf", "0jac")])) {
            if (_0x596a5c == -2224 * -1 + -993 + 123 * -10) {
                if (UI[clearStringObj("0xd0", "4jWr")]([clearStringObj("0x10", "bORa"), clearStringObj("0x164", "4*%U"), clearStringObj("0x794", "4jWr"), clearStringObj("0x6a9", "]C]N")]) == 9773 * -1 + 9821 * 1 + -1 * 47 && Onkey == 4016 + 7396 + -11412) {
                    Render[clearStringObj("0x75d", "R4C(")](screen_size[-686 * -9 + 7897 + -14071] / (9330 + -8632 + -696) + (30 * -197 + -4 * -577 + 4 * 908), screen_size[4023 + -2614 * 1 + -1408] / (1 * -2671 + 5 * -1721 + 11278) + (-2828 + 934 * 7 + -3666), -1211 * 1 + 2339 * 4 + -4 * 2036, clearStringObj("0x9f7", "]C]N"), [3742 + 4894 + -8636, -1301 + -127 * 31 + -97 * -54, -799 * 1 + -9839 * -1 + -9040, -9662 * 1 + 109 * -49 + -2 * -7629], artistTrack);
                    Render[clearStringObj("0x7ba", "9U5N")](screen_size[1 * -4364 + -2586 + 6950] / (-327 * -19 + -5 * -707 + -1 * 9746) + (-9661 + 6280 + 3410 * 1), screen_size[-23 * 13 + -7371 + 7671 * 1] / (5579 * -1 + -1 * 7973 + 54 * 251) + (-4195 + -7139 + 11377), -9438 + 192 * 21 + 5407, clearStringObj("0x6ab", "s4OQ"), [2465 + -9271 + 7061, -7 * 202 + -213 + 1797, 4863 + 6 * -1646 + 5048, -9917 + 1982 + -90 * -91], artistTrack);
                }
                if (UI[clearStringObj("0x3ce", "]#PJ")]([clearStringObj("0xa89", "hs0["), clearStringObj("0x71b", "tySx"), clearStringObj("0x359", "^Cpz"), clearStringObj("0x774", "]#PJ")]) == 5944 + 7 * 653 + -10515 && Onkey == 1374 + 1 * -9929 + 295 * 29) {
                    Render[clearStringObj("0x785", "Ly5M")](screen_size[-5057 + -5275 + 21 * 492] / (-8180 * -1 + 2662 + -2710 * 4) + (575 + 9403 + -9951), screen_size[-2699 * 2 + -47 * 17 + 6198] / (-1 * -6523 + -4 * 34 + 6385 * -1) + (2 * -2723 + 9484 * -1 + 1 * 14974), 4878 * -1 + 9098 * -1 + 13977, clearStringObj("0x664", "tySx"), [2 * 140 + -377 * 8 + -228 * -12, 544 + 7 * 933 + -7075, -3958 + -3866 * 1 + 7824, 9833 + 7534 + -17112], artistTrack);
                    Render[clearStringObj("0x413", "4*%U")](screen_size[41 * 208 + -7805 + -723] / (1017 + -4154 + 3139) + (-7233 + 4898 + 2361), screen_size[-3834 + -197 * 19 + 7578] / (-2002 * -1 + -166 * 55 + -7130 * -1) + (1 * 6491 + 9917 + -16365), 6272 + 9993 * -1 + 3722 * 1, clearStringObj("0x21d", "Md]D"), [97 * 67 + 4889 + -11181, -388 * 19 + -5735 + -492 * -27, 38 * 1 + -2 * 2328 + 443 * 11, 2960 + 2255 + -4960], artistTrack);
                }
                if (UI[clearStringObj("0xa2e", "4*%U")]([clearStringObj("0x68b", "R#3P"), clearStringObj("0x71b", "tySx"), clearStringObj("0x794", "4jWr"), clearStringObj("0x771", "!w]r")]) == -9848 + -17 * 135 + 6072 * 2 && UI[clearStringObj("0x501", "Ly5M")]([clearStringObj("0x762", "*TM&"), clearStringObj("0x7a3", "6y51"), clearStringObj("0x6c1", "s(MI"), clearStringObj("0x697", "]C]N")]) == 4739 + 2548 + -7286 && localplayer_alive == -7 * -134 + -2591 * 3 + 4 * 1709 && UI[clearStringObj("0x398", "T*7j")]([clearStringObj("0xf5", "6y51"), clearStringObj("0x8d7", "JG#F"), clearStringObj("0x6c9", "0zlF"), clearStringObj("0x754", "s4OQ")]) == -1445 + 760 + -14 * -49 && UI[clearStringObj("0x501", "Ly5M")]([clearStringObj("0x4f9", "^Cpz"), clearStringObj("0x809", "9U5N"), clearStringObj("0xb46", "8$2U"), clearStringObj("0x905", "@zrZ")]) == -9009 + -5812 + 14823) {
                    Render[clearStringObj("0x920", "!q5U")](screen_size[7926 + -37 * -257 + -17435 * 1] / (7856 + -7340 + 2 * -257) + (-43 * -207 + -101 * -34 + -6151 * 2), screen_size[8645 + 4158 + 12802 * -1] / (6 * -1086 + -7890 + 14408) + (1591 * 1 + 29 * -114 + 1759 * 1), -2 * 4359 + 4771 + 987 * 4, clearStringObj("0x849", "!q5U"), [6944 + 4733 * 2 + -16410, -38 * -19 + -1163 + 441, -1 * 6705 + -1 * -4445 + 2260, 8061 + 453 * 13 + -13695], artistTrack);
                    Render[clearStringObj("0x413", "4*%U")](screen_size[3824 + 423 * 1 + 137 * -31] / (-550 + -7838 + 8390) + (13 * 39 + 1 * 3583 + -4058), screen_size[43 * 118 + -7909 + -2 * -1418] / (1893 + 467 * 15 + -8896) + (284 + -9472 + -181 * -51), 3 * 1117 + 422 + -3772, clearStringObj("0x723", "4*%U"), [-754 + 2232 + 1 * -1223, 8360 + -4 * 2234 + 576, 4362 * 1 + -179 * 27 + 471, -4065 + -500 + 241 * 20], artistTrack);
                }
                if (UI[clearStringObj("0x63b", "tbdl")]([clearStringObj("0xa0c", "KA@R"), clearStringObj("0x982", "hs0["), clearStringObj("0xa33", "hs0["), clearStringObj("0x7d9", "i00^")]) == 1 * 5671 + -3387 + -3 * 761) {
                    UI[clearStringObj("0x5e", "@zrZ")]([clearStringObj("0x8c5", "fOHz"), clearStringObj("0x63a", "HY1z"), clearStringObj("0x4a6", "hs0["), clearStringObj("0x753", "UzS9")], 3 * 1057 + -6566 + 1132 * 3);
                    isSyncFake = 304 * -14 + -1547 + 5804;
                    Render[clearStringObj("0x406", "M]md")](screen_size[129 * -29 + -708 + 1483 * 3] / (-4477 + 2207 * -1 + 6686) + (5788 + 2460 + -8224), screen_size[22 * 296 + -6890 + 379] / (-1973 * -1 + -4 * -493 + -3943) + (19 * 7 + 31 * 299 + -9347), -1408 + -634 * -1 + 775, clearStringObj("0x3ab", "8$2U"), [-3583 + 836 + -1 * -2747, 9137 + -31 * 29 + -1373 * 6, -1 * 454 + 393 + 61 * 1, 5032 + -49 * 129 + 1544], artistTrack);
                    Render[clearStringObj("0x2e", "tbdl")](screen_size[-2284 * -3 + 231 * 1 + -7083 * 1] / (5 * 1637 + 2892 * 1 + -11075 * 1) + (2080 + -3428 + 1371 * 1), screen_size[2613 + -2773 + -161 * -1] / (3139 * -2 + -5958 + 12238) + (-8128 + 6 * 361 + -64 * -94), 22 * -266 + -145 * -18 + 3243, clearStringObj("0x7a2", "Md]D"), [38 * 199 + 1289 * -1 + -6066, 23 * 182 + -553 + -3456, 454 * 1 + 5044 + -5243, -5372 + 2481 + 3146], artistTrack);
                } else {
                    if (UI[clearStringObj("0x355", "9U5N")]([clearStringObj("0x8c6", "x65P"), clearStringObj("0x82", "*TM&"), clearStringObj("0x6ea", "RpYp"), clearStringObj("0x833", "^&*3")]) == 1 * -2004 + -5527 + 7531) {
                        Render[clearStringObj("0x310", "RpYp")](screen_size[-1 * 7863 + -109 * 1 + 7972] / (-7368 + 6667 * -1 + 1 * 14037) + (-87 * 1 + 4094 + -3983), screen_size[8525 * -1 + 3314 * 3 + -1416] / (-3583 + -3531 + 7116) + (-3551 * 1 + -763 * -2 + 2080), -411 * -12 + 974 * -10 + 4809, clearStringObj("0x9c7", "%#fz"), [-4665 + 215 * 29 + -1 * 1570, -309 * -16 + -5541 + 597, -3718 + -5901 + 9619, 4873 + -7061 + 2443], artistTrack);
                        Render[clearStringObj("0x65f", "ENd4")](screen_size[-5 * -1445 + 1 * -5077 + -2148] / (-177 * 34 + -3492 + -9512 * -1) + (3 * 2801 + 127 * 53 + 23 * -657), screen_size[3853 + 2323 + -6175 * 1] / (8944 + -2419 + -6523) + (7103 + -7560 + -511 * -1), 1 * 77 + -150 + 2 * 37, clearStringObj("0x590", "0zlF"), [-31 * 200 + -3612 + -10067 * -1, -7 * -1347 + -5694 + -3735, -1 * -658 + 951 * -9 + 7901, -8 * 199 + -1570 + 3417], artistTrack);
                        UI[clearStringObj("0x973", "89dW")]([clearStringObj("0x430", "0jac"), clearStringObj("0x641", "8$2U"), clearStringObj("0x12e", "82iA"), clearStringObj("0x701", "@zrZ")], 9892 + 8553 + -18445);
                    }
                }
            } else {
                if (_0x596a5c == 2 * 4078 + -2553 + -5603) {
                    if (UI[clearStringObj("0x2a1", "*TM&")]([clearStringObj("0x79a", "i00^"), clearStringObj("0x763", "82iA"), clearStringObj("0xab", "i00^"), clearStringObj("0x95e", "hs0[")]) == -8 * -694 + -617 * 10 + 1 * 619 && Onkey == 2054 * 2 + 6548 + 144 * -74) {
                        Render[clearStringObj("0xa98", "i00^")](screen_size[5873 + -1140 + -4733] / (1625 * -1 + -1 * -6205 + -4578) + (6710 + -812 * 11 + -171 * -13), screen_size[1152 + 9740 + -10891] / (-193 * 1 + 1016 + 821 * -1) + (-2 * 2161 + -6929 + 11277), -8242 + -405 * 3 + 9458, clearStringObj("0xa8c", "Ly5M"), [-6201 + 3531 + 2670, 237 * 13 + 4691 + -7772, 4453 * 1 + -889 * -1 + -5342, 9492 + -3837 + -5400], artistTrack);
                        Render[clearStringObj("0x3f8", "ZtZ5")](screen_size[-9109 + -4 * -9 + 9073] / (-8 * 362 + 2752 + 73 * 2), screen_size[-5591 * 1 + -9537 + 15129] / (-9491 + -9308 + 18801) + (1 * -3934 + -2 * -4811 + -5663), 1269 + 149 * -39 + 59 * 77, clearStringObj("0xa62", "82iA"), [1 * -8258 + -8445 + -16958 * -1, 2104 * -2 + -17 * 274 + 9036, -9466 + 2930 + 6571, 3647 + -8161 + 4769], artistTrack);
                    }
                    if (UI[clearStringObj("0x70c", "x65P")]([clearStringObj("0x4f9", "^Cpz"), clearStringObj("0x6d7", "UzS9"), clearStringObj("0x9a2", "JG#F"), clearStringObj("0x19f", "Md]D")]) == 1 * -488 + 664 * -2 + 1816 && Onkey == 856 * 1 + 9860 + 114 * -94) {
                        Render[clearStringObj("0x685", "!w]r")](screen_size[1140 + -527 + -613] / (-8917 + -2071 * 3 + 15132) + (-7204 + 1103 * 8 + -1619), screen_size[-4950 + -3133 + -86 * -94] / (9367 + -6 * -369 + -11579) + (-193 * -37 + 4033 + 6 * -1858), 5423 + -1 * -4792 + -1 * 10214, clearStringObj("0x66f", "*f)e"), [-3032 * 2 + -26 * -83 + 3906, -803 * 5 + 7 + 2 * 2004, 807 * -3 + 337 * 11 + -1286, -1 * -8967 + -1 * -4649 + -1 * 13361], artistTrack);
                        Render[clearStringObj("0x731", "82iA")](screen_size[-9566 + 345 + 9221] / (1 * 1693 + -1758 + -1 * -67), screen_size[-485 * 2 + 2 * -4663 + 1 * 10297] / (-3846 * -2 + -2858 + -4832) + (1987 * 1 + 6599 * 1 + 1223 * -7), -8221 + 0 + 8222, clearStringObj("0x1bd", "0jac"), [23 * 269 + 2124 * 2 + -10228, -6275 + -4934 + -11386 * -1, -6197 + -462 * -18 + 466 * -4, 4755 + -675 + -3825], artistTrack);
                    }
                    if (UI[clearStringObj("0x4fd", "fOHz")]([clearStringObj("0x8c6", "x65P"), clearStringObj("0x4ef", "M]md"), clearStringObj("0x8ad", "M]md"), clearStringObj("0x48c", "RpYp")]) == 719 * -7 + -2837 + 7871 && UI[clearStringObj("0x379", "R4C(")]([clearStringObj("0xa89", "hs0["), clearStringObj("0x6dc", "x65P"), clearStringObj("0x772", "tySx"), clearStringObj("0xabf", "RrDx")]) == -5 * -595 + -9284 + -2 * -3155 && localplayer_alive == -1049 * -3 + 20 * 241 + -7966 && UI[clearStringObj("0x70c", "x65P")]([clearStringObj("0xa0c", "KA@R"), clearStringObj("0x4ad", "D!Qj"), clearStringObj("0x643", "RpYp"), clearStringObj("0x51a", "Ly5M")]) == -8325 + -1 * -2584 + 5742 && UI[clearStringObj("0x398", "T*7j")]([clearStringObj("0xb4e", "7(LG"), clearStringObj("0x8d7", "JG#F"), clearStringObj("0x643", "RpYp"), clearStringObj("0x3b0", "tbdl")]) == -1 * 437 + -9841 * -1 + 9402 * -1) {
                        Render[clearStringObj("0x785", "Ly5M")](screen_size[3760 + -8314 + 4554] / (-94 * 105 + -95 * -3 + 9587) + (-2674 + 2733 * 2 + 2791 * -1), screen_size[-1 * -526 + -9707 + 2 * 4591] / (-7605 + -5742 + -7 * -1907) + (-4579 * -1 + 53 * -47 + 2 * -1031), -5373 + -11 * -370 + 1 * 1304, clearStringObj("0x723", "4*%U"), [-8881 + -8853 * -1 + 28, 13 * -751 + 183 * -51 + 616 * 31, -304 * -25 + 2 * -3288 + 128 * -8, -1 * 1059 + -152 * 41 + 14 * 539], artistTrack);
                        Render[clearStringObj("0x911", "WoWH")](screen_size[-9147 + -4024 + 13171] / (816 + -4673 + 3859), screen_size[-2 * 710 + -6378 + -11 * -709] / (724 + -3442 * -1 + -4164) + (3253 + 1 * 678 + 9 * -434), 1875 + -1802 + 9 * -8, clearStringObj("0xa52", "^&*3"), [267 * -7 + -8832 + -3652 * -3, 7593 + -6409 + -1184, 5236 + -5 * -1699 + -13731, -409 * 5 + -2386 + 71 * 66], artistTrack);
                    }
                    if (UI[clearStringObj("0x166", "QNb%")]([clearStringObj("0x871", "3e5%"), clearStringObj("0x207", "Ly5M"), clearStringObj("0x2e9", "7(LG"), clearStringObj("0x84a", "hs0[")]) == 2 * -2330 + -1183 * -3 + 1112) {
                        UI[clearStringObj("0x870", "M]md")]([clearStringObj("0xa6c", "^&*3"), clearStringObj("0x863", "i00^"), clearStringObj("0xac2", "R4C("), clearStringObj("0x249", "*f)e")], 1 * -1297 + 3306 + -2008);
                        isSyncFake = -8649 * -1 + 2 * -1597 + 18 * -303;
                        Render[clearStringObj("0x685", "!w]r")](screen_size[2547 * -1 + 23 * -268 + 1 * 8711] / (-7674 * -1 + 1 * 5101 + -12773) + (3 * -703 + 3659 + -1549), screen_size[-2582 + -9377 * 1 + 11960] / (9702 + 1657 + 11357 * -1) + (-1423 * 7 + -8909 + 7 * 2701), 1224 + -1137 + -86, clearStringObj("0x47f", "ZtZ5"), [-791 * -6 + 1 * 4361 + -9107, -7915 + -7614 + 15529, 8754 + 209 * -34 + -824 * 2, 4291 + 1013 * 2 + -866 * 7], artistTrack);
                        Render[clearStringObj("0x929", "JG#F")](screen_size[1504 + -8473 + -69 * -101] / (-1 * -982 + 1862 + -2842), screen_size[-21 * -113 + 6278 + -8650] / (6632 + -7655 + -5 * -205) + (-4 * 1732 + 6356 + -8 * -76), 2608 + -2215 + -196 * 2, clearStringObj("0x11b", "@zrZ"), [1303 * -3 + 6099 + 3 * -661, -727 * -5 + -338 * 5 + -1768, 8558 + 13 * -389 + -3246, -3 * 2415 + 3907 * -1 + 11407], artistTrack);
                    } else {
                        if (UI[clearStringObj("0x308", "tySx")]([clearStringObj("0x6f5", "0zlF"), clearStringObj("0x897", "7(LG"), clearStringObj("0x14f", "*f)e"), clearStringObj("0x304", "*TM&")]) == 527 * 9 + 9277 * -1 + 4534) {
                            Render[clearStringObj("0x7ba", "9U5N")](screen_size[-3377 + 173 * -25 + 7702] / (-5035 + -4255 * -2 + -3473) + (-4175 + 7247 + -3071), screen_size[-9831 + -1811 + 11643] / (-166 * -8 + 5519 + -6845) + (-6689 + -489 * 15 + 14061), -3643 * -1 + 1369 + -5011, clearStringObj("0x5bd", "ZtZ5"), [2551 + 4748 + -1 * 7299, -5208 + -1 * -2517 + 2691, -9356 + 316 + 9040, 6704 + 25 * 218 + -11899], artistTrack);
                            Render[clearStringObj("0x75d", "R4C(")](screen_size[-3 * -780 + 2 * -811 + -718] / (-3478 * 1 + 8968 * 1 + 28 * -196), screen_size[1669 + -4223 * -2 + 10114 * -1] / (-8079 + 5 * 1595 + 53 * 2) + (-1458 + -4663 + -47 * -131), -7 * -1376 + -92 * -59 + -407 * 37, clearStringObj("0x7d7", "tbdl"), [-4 * 859 + -233 * -8 + -7 * -261, -1975 + 5112 + -3137, -548 * 3 + 4241 + -2597, -1 * 7485 + -1 * -3218 + -17 * -266], artistTrack);
                            UI[clearStringObj("0xb0", "JG#F")]([clearStringObj("0xa6c", "^&*3"), clearStringObj("0xa69", "yVP2"), clearStringObj("0xdc", "9U5N"), clearStringObj("0x2d0", "R#3P")], 8333 + 7752 + 16085 * -1);
                        }
                    }
                }
            }
        }
        if (UI[clearStringObj("0x48b", "ENd4")]([clearStringObj("0x871", "3e5%"), clearStringObj("0x46e", "tbdl"), clearStringObj("0x2cf", "i00^"), clearStringObj("0xaef", "7(LG")]) && UI[clearStringObj("0x6f", "^Cpz")]([clearStringObj("0x17d", "89dW"), clearStringObj("0x7fa", "89dW"), clearStringObj("0x1bc", "WoWH"), clearStringObj("0xa18", "*f)e")]) && UI[clearStringObj("0x986", "0zlF")]([clearStringObj("0xa0c", "KA@R"), clearStringObj("0x317", "0zlF"), clearStringObj("0x30d", "hs0["), clearStringObj("0x3de", "R4C(")]) == -9407 + -9485 + 18892) {
            Render[clearStringObj("0x75d", "R4C(")](screen_size[-7 * 984 + -1 * 5906 + -2 * -6397] / (-3888 + 7 * -914 + 16 * 643) - (1 * 7106 + -4438 + -2627), screen_size[-9770 + 565 + 9206] / (-15 + 8085 + -8068 * 1) + -(5479 + 1 * 5839 + -8 * 1394), 1597 + -7880 + 4 * 1571, isMagicKey ? clearStringObj("0x6fe", "KA@R") : clearStringObj("0x9b0", "tbdl"), isMagicKey ? [4 * 293 + 2 * -3391 + -10 * -561, 1055 * -4 + 4776 + -556, -7933 + 2 * 1103 + 83 * 69, -6033 + 2114 + 4099] : [-1853 * 1 + 3062 * -3 + 11294 * 1, -6959 + -7779 * 1 + -7369 * -2, 832 + -2089 * 2 + 3346 * 1, 4233 + 2 * 38 + -4309], fontmagickey);
            Render[clearStringObj("0x929", "JG#F")](screen_size[7594 + 5888 + 7 * -1926] / (-2132 + -3300 + -38 * -143) - (-1806 + -3122 + 4968), screen_size[-1493 + 37 * 87 + -1725] / (5046 + 79 * 124 + -14840) + -(-4142 * 1 + -7493 + 2360 * 5), -318 + -1 * 8185 + 8504, isMagicKey ? clearStringObj("0x859", "R#3P") : clearStringObj("0x9b5", "%#fz"), isMagicKey ? [8956 * 1 + 2 * 4731 + 18163 * -1, -4798 + -2729 * 2 + -1 * -10256, 8508 * -1 + 8028 + -60 * -8, -392 * -5 + -7978 + 6273] : [3153 + -5245 + 2347, 6401 + -1 * -6883 + 36 * -369, -2 * 1085 + -4086 + 6256, 9923 + 1 * 6223 + -3 * 5382], fontmagickey);
            Render[clearStringObj("0x1ca", "s(MI")](screen_size[-472 + 3721 * 2 + -17 * 410] / (8738 * -1 + 116 * -59 + -2 * -7792) + (-5746 + -4185 + -9 * -1108), screen_size[6290 + 5872 + -12161] / (3001 + -4478 * 1 + 1 * 1479) - (3 * -3061 + 9868 + 3 * -173), 1819 * 3 + -5019 + 23 * -19, isMagicKey ? clearStringObj("0x71c", "!q5U") : clearStringObj("0xaf1", "@zrZ"), isMagicKey ? [-5405 * 1 + -8953 + 14358, 3719 + -7727 + 4008, 1 * 8087 + -839 * -1 + -8926 * 1, 27 * 359 + -3873 + -5640] : [-8451 + 2327 + 6124, -2 * 2657 + 8621 + -3103, -7187 + 107 * -25 + -1 * -9862, -3186 * 2 + -2 * 167 + 6706], fontmagickey);
            Render[clearStringObj("0x1ca", "s(MI")](screen_size[9588 + 7418 * -1 + -2170] / (1176 + 3847 + -5021) + (-5988 + -1 * -1241 + 4787), screen_size[7711 + 1 * 910 + -8620] / (-65 * 29 + -8260 + 73 * 139) - (-9822 + -1 * 4485 + 14472), -5690 * 1 + 3133 + 2558, isMagicKey ? clearStringObj("0x54e", "6y51") : clearStringObj("0x7b1", "0zlF"), isMagicKey ? [8785 + -105 + -8570, 8927 + -195 + -8532, -2 * -496 + -8261 + 12 * 607, 3123 * 2 + -2907 + -3084] : [8981 * -1 + 227 * 5 + -7846 * -1, 9239 + 1 * -9326 + -3 * -97, 1083 * -9 + -13 * 346 + 11 * 1295, -6260 + -2307 * -1 + 3953], fontmagickey);
            Render[clearStringObj("0x929", "JG#F")](screen_size[1431 + -9522 + 9 * 899] / (1058 * -3 + -9 * 607 + 8639) - (30 * 143 + 2 * -149 + -3099), screen_size[1478 * -5 + -150 + -1 * -7541] / (-4821 + 825 + 1 * 3998) + (-3103 + 18 * 207 + -173), -2808 + -7571 * -1 + -4762, isFreestand ? clearStringObj("0x878", "AMGA") : clearStringObj("0x9cd", "*TM&"), isFreestand ? [697 * 9 + -7497 * -1 + 255 * -53, -4789 + -3 * 1597 + 9835, -287 + -9956 + 1 * 10498, 444 * -15 + -8974 + -1 * -15889] : [-762 + 1242 + -240 * 2, 5 * -993 + -5189 + 10358, -845 + 2 * 3371 + 1 * -5897, -3705 + -5310 + 9015], -37 * -33 + 4311 + 5528 * -1);
        }
        if (_0x596a5c == 3887 + -4626 + 37 * 20) {
            if (UI[clearStringObj("0xaf4", "HY1z")]([clearStringObj("0xf5", "6y51"), clearStringObj("0x3b4", "RrDx"), clearStringObj("0x3f5", "M]md"), clearStringObj("0x92f", "%#fz")]) && UI[clearStringObj("0x379", "R4C(")]([clearStringObj("0x1fd", "HY1z"), clearStringObj("0x17a", "yVP2"), clearStringObj("0x2b2", "R#3P"), clearStringObj("0x146", "^Cpz")]) && UI[clearStringObj("0x7c7", "Md]D")]([clearStringObj("0x69d", "82iA"), clearStringObj("0x46e", "tbdl"), clearStringObj("0x6ec", "bORa"), clearStringObj("0x26", "RpYp")]) == 8869 + 12 * -632 + -1285) {
                Render[clearStringObj("0x63d", "6y51")](screen_size[-56 * 158 + 218 + 8630] / (4397 + 6011 + -10406) + (166 + 91 + 8 * -31), screen_size[1 * 2031 + -6532 + -2 * -2251] / (-1303 + -3650 * -2 + 109 * -55) + (-2747 + 3726 + -913), -3820 + -5014 + 285 * 31, isHideShots ? "AA" : "AA", isHideShots ? [-3203 * -1 + 5059 * -1 + -232 * -8, 1102 + 293 * 26 + -8720, -421 * 1 + 1008 + -587 * 1, 550 * 17 + -5 * 863 + -4780] : [-789 * -4 + -1607 * 3 + 1920, 1 * -5109 + 4075 * 2 + -3041, -2683 + 1 * -613 + -1648 * -2, -5697 + -87 * 43 + 242 * 39], artistTrack);
                Render[clearStringObj("0x920", "!q5U")](screen_size[-7901 + -5552 + 13453 * 1] / (1 * 3227 + -8726 + 5501) + (-6104 + 1 * 6707 + 119 * -5), screen_size[282 * -2 + 7086 * -1 + -1093 * -7] / (4 * 2233 + -7153 + -1777) + (2 * 3361 + -18 * -485 + -15386), 3794 + 3231 + 439 * -16, isDoubletap ? "DT" : "DT", isDoubletap ? [-88 * -56 + 7854 + -12782, -5061 + 499 * 16 + 2923 * -1, 2 * 1257 + -7919 * -1 + 1 * -10433, 5 * -1135 + -9383 + 15313] : [-4 * -1395 + -1815 * 5 + 3750, -681 + 6728 + 1 * -6047, -7293 + -190 * -12 + 5013, -5471 + -2066 * 3 + 11669], artistTrack);
                Render[clearStringObj("0x588", "QNb%")](screen_size[2 * 4139 + -1 * 5671 + -2607] / (58 * -83 + -8951 * 1 + -353 * -39) + (6763 * 1 + 2440 + -3065 * 3), screen_size[330 * -17 + 2505 + 3106] / (3251 + 4406 * 2 + 12061 * -1) + (8389 + 2831 + 2231 * -5), 2300 + -6333 + -4034 * -1, isHideShots ? "AA" : "AA", isHideShots ? [233 * -31 + 1486 * -1 + 8774, 7251 * 1 + -7459 + 313, -2845 * -3 + -1 * -3644 + -11954, -303 * 17 + 3407 + 1 * 1999] : [1200 + 1041 + -1986, 8352 + -5014 + -1669 * 2, 4019 * -1 + -9120 + 13139, -646 + -7913 + 8559], artistTrack);
            }
            if (UI[clearStringObj("0x1d2", "RrDx")]([clearStringObj("0x634", "RpYp"), clearStringObj("0x547", "UzS9"), clearStringObj("0x233", "s4OQ"), clearStringObj("0x964", "HY1z")]) && UI[clearStringObj("0x166", "QNb%")]([clearStringObj("0x23", "WoWH"), clearStringObj("0x985", "]C]N"), clearStringObj("0xb21", "*TM&"), clearStringObj("0x2c8", "*TM&")]) && UI[clearStringObj("0x6f0", "!w]r")]([clearStringObj("0x389", "^Cpz"), clearStringObj("0x5ac", "9U5N"), clearStringObj("0x549", "ENd4"), clearStringObj("0x8fd", "^&*3"), clearStringObj("0x77d", "!q5U")])) {
                Render[clearStringObj("0x929", "JG#F")](screen_size[-2185 * -4 + -90 * 42 + -4960] / (-3160 + 1045 * 2 + 1072) + (4017 * 1 + -1478 * -3 + -1681 * 5), screen_size[-9641 + 861 * -9 + 17391] / (-105 * -46 + -9100 + -178 * -24) + (-1 * -4023 + -5924 + 281 * 7), 103 * -56 + 2608 + 3161 * 1, clearStringObj("0x67f", "s4OQ"), [3109 * 2 + 86 * -2 + -6046, 1 * -7628 + -1993 + 9621, 283 * 15 + 3483 + -7728, -287 * -1 + -6217 + 1237 * 5], artistTrack);
                Render[clearStringObj("0x5de", "KA@R")](screen_size[5192 * 1 + 8291 + -13483] / (-8453 + 2257 + 6198) + (-2111 + 8 * -1072 + 10732), screen_size[1759 * -3 + -4607 * 1 + 9885] / (1018 * 4 + -5413 + 1343 * 1) + (7282 + 279 + -4 * 1874), -7597 + -441 * -1 + 7157, clearStringObj("0xa1a", "!q5U"), [-8244 * -1 + 957 + -8946, -3683 * -2 + -211 * 7 + -5889, 2380 + 8072 + 871 * -12, 1540 + -7273 + 2994 * 2], artistTrack);
            }
        } else {
            if (_0x596a5c == 7337 + -1839 + -5498) {
                if (UI[clearStringObj("0xa88", "bORa")]([clearStringObj("0x5dd", "s4OQ"), clearStringObj("0x17a", "yVP2"), clearStringObj("0xb1e", "^&*3"), clearStringObj("0x92f", "%#fz")]) && UI[clearStringObj("0x6f", "^Cpz")]([clearStringObj("0x40d", "yVP2"), clearStringObj("0xa39", "RpYp"), clearStringObj("0x953", "ZtZ5"), clearStringObj("0x44d", "hs0[")]) && UI[clearStringObj("0x19c", "8$2U")]([clearStringObj("0x68b", "R#3P"), clearStringObj("0x7fa", "89dW"), clearStringObj("0x3f5", "M]md"), clearStringObj("0x3de", "R4C(")]) == 1 * -8588 + -2 * 3778 + -2018 * -8) {
                    Render[clearStringObj("0x446", "8$2U")](screen_size[-7978 + 2916 + 5062] / (-57 * 59 + -53 + -3418 * -1) + (3 * 1457 + -24 * -392 + 1 * -13778), screen_size[-794 + 7527 + 17 * -396] / (8 * -23 + 2815 + -239 * 11) + (-8081 * -1 + 7076 + -15109), -75 * -129 + -9684 + 10, isHideShots ? "AA" : "AA", isHideShots ? [6798 + -5896 + -902, -4 * -1790 + -1 * -2797 + -3319 * 3, -2771 * -1 + 35 * -13 + -4 * 579, -6865 + 4175 + 2870] : [-1332 + 8682 + -7095, 1 * -6113 + -2174 + -8287 * -1, 2237 * 2 + -8107 + 1211 * 3, -3202 + -5240 + -63 * -134], artistTrack);
                    Render[clearStringObj("0xb27", "*f)e")](screen_size[-2217 + 211 * 1 + -1003 * -2] / (-7471 + 1 * -8539 + 16012) + (-1 * -317 + 7288 + 1901 * -4), screen_size[-8957 + -1569 + -957 * -11] / (-8428 + 560 * -1 + -5 * -1798) + (9 * 695 + -1067 * 6 + 195), 1147 * 1 + 9180 + -1721 * 6, isDoubletap ? "DT" : "DT", isDoubletap ? [-321 * -31 + -6648 + -3303, -225 * 36 + -5299 + 1 * 13399, -1859 + 2511 + 1 * -652, -4417 * 1 + -5235 + 9832] : [7 * -313 + 6998 + -4552, 5212 + -2762 * -3 + 17 * -794, 10 * -283 + -739 * 8 + 141 * 62, 4 * -1358 + 10 * -922 + 14652], artistTrack);
                    Render[clearStringObj("0x746", "T*7j")](screen_size[-6570 + 3164 + 3406] / (2447 + 3 * -3163 + -12 * -587), screen_size[27 * -199 + 357 * -17 + 11443] / (-2326 + 1117 + 1211) + (706 + 428 * 8 + -4083), 47 * -81 + 7789 * 1 + 3981 * -1, isHideShots ? "AA" : "AA", isHideShots ? [9410 * -1 + -60 + 9535, -1 * 3571 + -2 * -3377 + -3078, -7915 + 7849 + 291, 6955 + -1061 * -7 + -14127] : [-1308 + 6556 + -4993, 1 * -8191 + 1 * 4574 + 3617 * 1, -2419 + 5827 + -2 * 1704, -4 * -1714 + -8382 + 1526], artistTrack);
                }
                if (UI[clearStringObj("0x6eb", "7(LG")]([clearStringObj("0x389", "^Cpz"), clearStringObj("0x34d", "D!Qj"), clearStringObj("0x305", "!w]r"), clearStringObj("0x6e3", "i00^")]) && UI[clearStringObj("0x6f", "^Cpz")]([clearStringObj("0x22c", "6y51"), clearStringObj("0x770", "]#PJ"), clearStringObj("0x47b", "*f)e"), clearStringObj("0x22a", "*f)e")]) && UI[clearStringObj("0x6f0", "!w]r")]([clearStringObj("0x9b6", "tbdl"), clearStringObj("0xc6", "Md]D"), clearStringObj("0x51b", "4jWr"), clearStringObj("0xa86", "0zlF"), clearStringObj("0x91b", "tySx")])) {
                    Render[clearStringObj("0x3f8", "ZtZ5")](screen_size[35 * 105 + 1 * -8399 + -1 * -4724] / (-1 * 5703 + -5754 + -1637 * -7) + (4267 + -5497 + -137 * -9), screen_size[1 * -7227 + 931 + 6297] / (-55 * 73 + 1907 * -1 + 5924) + (-1 * -2881 + 23 * 381 + 1 * -11587), 7856 + 1924 + -9779, clearStringObj("0x6aa", "tySx"), [-191 + 5617 + -5426 * 1, -81 * -107 + 16 * 103 + -10315 * 1, -9323 + 1 * -5851 + 2 * 7587, -1 * 4319 + -8122 * -1 + -3548], artistTrack);
                    Render[clearStringObj("0x911", "WoWH")](screen_size[-6359 + 3791 + -1284 * -2] / (9666 + 1 * -676 + -8988) + (-9221 + -170 * 13 + -11433 * -1), screen_size[211 * 43 + -8603 + -469] / (101 * 11 + -7342 + 23 * 271) + (-4892 * -2 + 1765 + -11493), -5804 + 2 * -1325 + 8455, clearStringObj("0x3bb", "7(LG"), [-1810 + 381 * 23 + -3349 * 2, 1615 + -5827 + 4212, -1 * 9029 + -1 * 6326 + 15355 * 1, -9637 + 2329 + 7563], artistTrack);
                }
            }
        }
    }
}
var menu = {};
var menu_elements = {};
var jnasd88u_1_oksad_1 = Array;
var dsaijhduia = jnasd88u_1_oksad_1;
var jnasd88u09usadojas_1_ok2321 = dsaijhduia;
var mdiu19u = jnasd88u09usadojas_1_ok2321;
var d_123jnj = mdiu19u;
var kdak_123_a = Cheat;
var dsjaodjm19iji = kdak_123_a;
var Aud8u1hdsja = dsjaodjm19iji;
var soiajdmaj9isjd0 = Aud8u1hdsja;
var diujsaudja = soiajdmaj9isjd0;
const menu_spacer = '                                                                                  ';
menu.concat = function(eventTypes, data) {
    var now = _0x31205f;
    var monitoredObjectEvents = [];
    var i;
    for (i in eventTypes) {
        monitoredObjectEvents[now("0xd", "ZtZ5")](eventTypes[i]);
    }
    return monitoredObjectEvents[now("0xa10", "0zlF")](data), monitoredObjectEvents;
}, menu.label = function(mmCoreSplitViewBlock) {
    var gotoNewOfflinePage = _0x31205f;
    UI[gotoNewOfflinePage("0x18c", "RrDx")](mmCoreSplitViewBlock);
}, menu.new = function(options, staticHost, id, data, type) {
    var camelize = _0x31205f;
    data = data || [];
    type = type || undefined;
    const y = staticHost + menu_spacer + id;
    var e = [y];
    var self = {};
    self[camelize("0x3c9", "s(MI")] = [camelize("0xb4e", "7(LG"), camelize("0xa39", "RpYp"), camelize("0xa39", "RpYp"), y];
    self[camelize("0x442", "s(MI")] = type;
    self[camelize("0x4d5", "%#fz")] = options;
    const o = self;
    if (data != null) {
        var i = -4754 + 1745 + 3009;
        for (; i < data[camelize("0x142", "QNb%")]; i++) {
            e[camelize("0x75c", "^&*3")](data[i]);
        }
    }
    return options[camelize("0xa6d", "WoWH")](null, e), menu_elements[id] = o, o;
}, menu.reference = function(callback, deep) {
    var now = _0x31205f;
    var rpm_traffic = {};
    return rpm_traffic[now("0x5b0", "D!Qj")] = callback, rpm_traffic[now("0x202", "!q5U")] = deep, rpm_traffic;
}, menu.get = function(myPreferences) {
    var getPreferenceKey = _0x31205f;
    switch (myPreferences[getPreferenceKey("0x490", "@zrZ")]) {
        case UI[getPreferenceKey("0x297", "M]md")]:
            return UI[getPreferenceKey("0x6e0", "4jWr")][getPreferenceKey("0x7ca", "!q5U")](null, myPreferences[getPreferenceKey("0x975", "WoWH")]);
        case UI[getPreferenceKey("0xa36", "T*7j")]:
            return UI[getPreferenceKey("0x308", "tySx")][getPreferenceKey("0x491", "DtBC")](null, myPreferences[getPreferenceKey("0xc4", "RpYp")]);
        default:
            return UI[getPreferenceKey("0x23f", "KA@R")][getPreferenceKey("0x4c5", "RrDx")](null, myPreferences[getPreferenceKey("0x514", "4*%U")]);
    }
};
const ref_doubletap = menu.reference([
    ['Rage', 'Exploits', 'General', 'Double tap']
]);
const ref_doubletap_hk = menu.reference([
    ['Rage', 'Exploits', 'General', 'Double tap']
], UI.AddHotkey);
var offset = -1 * 639 + -4943 + 5582;
var _0x1d3de3 = {};
_0x1d3de3.dormant = [-9347 * -1 + 2 * -2515 + -4082, 2252 * 1 + -271 + 97 * -18, 2638 + 1205 + -3608, -1 * -7111 + -167 * -27 + -11365], _0x1d3de3.active = [-25 * 347 + -3916 + 12826, 9770 + -6917 + -2618, -2382 + 4481 * -1 + -26 * -273, -3907 * 2 + 4637 * 1 + -39 * -88];
const modules = [{
    "label": "DT",
    "condition": function() {
        var logicOrExpr = _0x31205f;
        return menu[logicOrExpr("0x4ed", "Ly5M")](ref_doubletap) & menu[logicOrExpr("0xad2", "!q5U")](ref_doubletap_hk);
    },
    "colors": _0x1d3de3,
    "logic": function() {
        var parseInt = _0x31205f;
        const colData = modules[-1361 * 5 + -2 * 3007 + -12819 * -1];
        const _0x55ca98 = Exploit[parseInt("0x990", "7(LG")]();
        return colData[parseInt("0x800", "i00^")][parseInt("0x364", "x65P")] = _0x55ca98 === -1201 * -8 + -1433 + -122 * 67 ? [-4944 + 5 * 1126 + -611, 5 * -43 + -9087 + 9514, 2 * 722 + 25 * 89 + -3654, -3 * 1759 + -438 * -2 + -97 * -48] : [-7 * 619 + 1 * -9209 + 13797, -787 + -3 * -1801 + -4616, 744 + 7343 * 1 + -1 * 8087, 9108 + -115 * -53 + -14948], -9939 + -2 * 4459 + 18858;
    }
}];

function DT_ind() {
    var getFileName = _0x31205f;
    const artistTrack = Render[getFileName("0xacc", "AMGA")](getFileName("0x7ac", "RpYp"), -7862 + 317 * -8 + 10408, -418 + 2802 * 3 + -7589);
    render_get_screen_size = Render[getFileName("0x95c", "ENd4")];
    const _0x47adcc = 2235 * -1 + -9344 + 11579;
    var _0x59e650 = UI[getFileName("0x501", "Ly5M")]([getFileName("0xb10", "tbdl"), getFileName("0x8d7", "JG#F"), getFileName("0xce", "3e5%"), getFileName("0x4a9", "@zrZ")]);
    if (UI[getFileName("0x379", "R4C(")]([getFileName("0x324", "]C]N"), getFileName("0x926", "s4OQ"), getFileName("0x461", "AMGA"), getFileName("0x626", "R4C(")]) && UI[getFileName("0xa08", "3e5%")]([getFileName("0xa0c", "KA@R"), getFileName("0xacd", "DtBC"), getFileName("0x46e", "tbdl"), getFileName("0x7ec", "0jac")])) {
        var type = -6590 + 291 + 6299;
        for (; type < modules[getFileName("0x740", "^&*3")]; type++) {
            const sizeArray = modules[type];
            if (!sizeArray[getFileName("0x2c", "yVP2")]()) {
                continue;
            }
            const _0x5727ce = sizeArray[getFileName("0x125", "^Cpz")]();
            const _0x6beabc = Render[getFileName("0x2e8", "82iA")](sizeArray[getFileName("0x327", "@zrZ")], 2308 * 2 + -23 * -77 + -1 * 6385)[-89 * -45 + -2866 + -17 * 67];
            const GET_AUTH_URL_TIMEOUT = [sizeArray[getFileName("0x7a8", "QNb%")][getFileName("0x6d6", "4*%U")][5632 + -5430 + -202] + (sizeArray[getFileName("0x8a0", "RpYp")][getFileName("0x5cf", "4jWr")][-738 + 1 * -8881 + -9619 * -1] - sizeArray[getFileName("0x78e", "AMGA")][getFileName("0x52c", "*TM&")][111 * -3 + 5334 + -5001]) * _0x5727ce, sizeArray[getFileName("0x8a0", "RpYp")][getFileName("0x80e", "i00^")][1 * 9482 + -3 * 2519 + -1924] + (sizeArray[getFileName("0x9b7", "tySx")][getFileName("0x811", "s(MI")][-655 * -7 + 5507 * -1 + 13 * 71] - sizeArray[getFileName("0x7c1", "ZtZ5")][getFileName("0xacb", "%#fz")][4414 + -1 * 5417 + 1004]) * _0x5727ce, sizeArray[getFileName("0x57d", "R#3P")][getFileName("0x158", "T*7j")][-4841 + -4156 + -8999 * -1] + (sizeArray[getFileName("0x9bd", "tbdl")][getFileName("0x3c7", "fOHz")][3779 * -1 + -3425 + 7206] - sizeArray[getFileName("0x4af", "UzS9")][getFileName("0x158", "T*7j")][-9 * 523 + -9 * -633 + -988]) * _0x5727ce, -8671 + 2177 * 2 + -762 * -6];
            if (_0x59e650 == -3624 + 1 * 4037 + -412) {
                Render[getFileName("0x450", "89dW")](screen_size[269 * 31 + 266 + -8605] / (1021 * -9 + -6794 + 15985) + (-2 * 2311 + -8898 + 4509 * 3), screen_size[-4 * 1822 + -2759 + -32 * -314] / (-1437 * -5 + -6839 * -1 + -14022) + (1974 + -4844 + 2935), -14 * 266 + 31 * -167 + -8902 * -1, sizeArray[getFileName("0x0", "4jWr")], GET_AUTH_URL_TIMEOUT, artistTrack);
            } else {
                if (_0x59e650 == -1513 * 6 + -3 * 1799 + 14475) {
                    Render[getFileName("0xa9f", "7(LG")](screen_size[4208 + -374 * -13 + 4535 * -2] / (1 * -3386 + 115 * 53 + -2707), screen_size[-1 * -9409 + 9232 * 1 + 18640 * -1] / (3 * -2565 + 1714 * 1 + 193 * 31) + (240 + -1 * -6741 + -2 * 3467), -3279 + -1017 + 4297, sizeArray[getFileName("0x71a", "T*7j")], GET_AUTH_URL_TIMEOUT, artistTrack);
                }
            }
            _0x47adcc++;
        }
    }
}

function me_Alive() {
    var gotoNewOfflinePage = _0x31205f;
    const artistTrack = Entity[gotoNewOfflinePage("0xa21", "*f)e")]();
    if (!artistTrack || !Entity[gotoNewOfflinePage("0x2f6", "hs0[")](artistTrack)) {
        return;
    }
    DT_ind();
}
var time;
var delay;
var fillbar;
var shotsfired;

function can_shift_shot(boardManager) {
    var gotoNewOfflinePage = _0x31205f;
    var magnifier = Entity[gotoNewOfflinePage("0x29f", "ENd4")]();
    var minCPM = Entity[gotoNewOfflinePage("0x109", "T*7j")](magnifier);
    if (magnifier == null || minCPM == null) {
        return ![];
    }
    var $magnifier = Entity[gotoNewOfflinePage("0x5d8", "9U5N")](magnifier, gotoNewOfflinePage("0x778", "DtBC"), gotoNewOfflinePage("0xb2b", "Md]D"));
    var CPM = Globals[gotoNewOfflinePage("0x74", "0zlF")]() * ($magnifier - boardManager);
    if (CPM < Entity[gotoNewOfflinePage("0xe7", "fOHz")](magnifier, gotoNewOfflinePage("0x25c", "Ly5M"), gotoNewOfflinePage("0x1a2", "AMGA"))) {
        return ![];
    }
    if (CPM < Entity[gotoNewOfflinePage("0x4eb", "hs0[")](minCPM, gotoNewOfflinePage("0x1c0", "0jac"), gotoNewOfflinePage("0x1e7", "DtBC"))) {
        return ![];
    }
    return !![];
}

function _TBC_CREATE_MOVE() {
    var reduce = _0x31205f;
    var result = Exploit[reduce("0x469", "!w]r")]();
    Exploit[(result != 2 * -2787 + -1 * 1647 + 157 * 46 ? reduce("0x29a", "4*%U") : reduce("0x98f", "0zlF")) + reduce("0xb31", "tySx")]();
    if (can_shift_shot(-5630 + -4080 + 9729) && result != 6297 * -1 + -1627 + 7925) {
        Exploit[reduce("0x11d", "0zlF")]();
        Exploit[reduce("0x289", "UzS9")]();
    }
    Exploit[reduce("0xa80", "bORa")](9514 + -1 * 1049 + -1693 * 5);
    Exploit[reduce("0x962", "89dW")](5013 * 1 + 2413 * 1 + -7409);
}

function _TBC_UNLOAD() {
    var gotoNewOfflinePage = _0x31205f;
    Exploit[gotoNewOfflinePage("0x9de", "4*%U")]();
}
var _0x4c4c27 = {};
_0x4c4c27.get = function() {
    var gotoNewOfflinePage = _0x31205f;
    return UI[gotoNewOfflinePage("0xa01", "6y51")]([gotoNewOfflinePage("0x696", "R#3P"), gotoNewOfflinePage("0xa1b", "82iA"), gotoNewOfflinePage("0xa25", "%#fz"), gotoNewOfflinePage("0x5a5", "*TM&")]);
}, _0x4c4c27.reverse = function() {
    var gotoNewOfflinePage = _0x31205f;
    return UI[gotoNewOfflinePage("0x19a", "*f)e")]([gotoNewOfflinePage("0x85e", "HY1z"), gotoNewOfflinePage("0x4ff", "@zrZ"), gotoNewOfflinePage("0x60b", "6y51"), gotoNewOfflinePage("0x16f", "UzS9")]);
};
var inverter = _0x4c4c27;

function deg2rad(value) {
    return value * Math.PI / (-5104 * -1 + 6 * -1279 + -11 * -250);
}

function angle_to_vec(x, h) {
    var gotoNewOfflinePage = _0x31205f;
    var value = deg2rad(x);
    var h_rad = deg2rad(h);
    var oldCondition = Math[gotoNewOfflinePage("0xa6f", "^Cpz")](value);
    var mmCoreSecondsDay = Math[gotoNewOfflinePage("0x560", "s4OQ")](value);
    var daysInterval = Math[gotoNewOfflinePage("0x2f1", "3e5%")](h_rad);
    var daysToStart = Math[gotoNewOfflinePage("0x675", "%#fz")](h_rad);
    return [mmCoreSecondsDay * daysToStart, mmCoreSecondsDay * daysInterval, -oldCondition];
}

function trace(opts, val) {
    var _logging = _0x31205f;
    var r = angle_to_vec(val[5543 + 2 * 2144 + 339 * -29], val[3 * -524 + 571 * 13 + 1950 * -3]);
    var size = Entity[_logging("0x8f8", "M]md")](opts);
    size[-7503 + 1088 * 4 + 3153] += -7058 + -2 * 3790 + 34 * 432;
    var data = [size[-4615 + 1 * -815 + 5430] + r[3158 * -1 + -4474 + -954 * -8] * (-9590 + 7 * 359 + -15269 * -1), size[174 + 1171 + -1344] + r[-9664 + 8689 + 976] * (-563 * 4 + 7304 + 5 * 628), size[8834 + -62 * -94 + -14660] + r[-3375 + 2 * -4700 + 12777] * (-15218 * -1 + -7588 + 562)];
    var d = Trace[_logging("0x821", "3e5%")](opts, size, data);
    if (d[1 * -5897 + 6721 + -823] == 7813 + 2 * 1888 + 11588 * -1) {
        return;
    }
    data = [size[61 + 3225 + 106 * -31] + r[-5606 + -23 * 139 + 8803] * d[-9811 + -2 * -4133 + -2 * -773] * (37 * -437 + -11996 + 36357), size[-7801 + 5463 + 2339 * 1] + r[8815 + -2892 + -5922] * d[1 * 4376 + -7463 + -1544 * -2] * (2 * -6363 + 6167 + 1341 * 11), size[7363 * -1 + -4912 + -12277 * -1] + r[-358 * -25 + 1265 * -3 + 5153 * -1] * d[-2 * -2602 + 3926 + -537 * 17] * (13451 * 1 + 6564 + -7 * 1689)];
    var node2 = Math[_logging("0x127", "QNb%")]((size[-8571 + 5652 + -2919 * -1] - data[5 * 1232 + -6211 + 51]) * (size[9127 * 1 + 3 * 651 + -8 * 1385] - data[-4052 * -2 + -3137 * -2 + -14378]) + (size[-4356 + -5510 + 9867] - data[3619 + 2477 * -1 + -1141]) * (size[1 * 4671 + -1982 + 168 * -16] - data[5858 + 37 * -83 + -2786]) + (size[-707 * -1 + -3952 + 3247] - data[9549 + 5375 + 6 * -2487]) * (size[-1753 * -3 + 3 * -1025 + 1091 * -2] - data[9928 + 3661 + -13587]));
    size = Render[_logging("0x5f3", "R#3P")](size);
    data = Render[_logging("0xa72", "RpYp")](data);
    if (data[-62 * -55 + 6 * 342 + -5460] != -2153 * 2 + -2467 + 6774 || size[2614 * -1 + -1127 + 3743] != 3885 + 1 * -7727 + 3843) {
        return;
    }
    return node2;
}
var flip = ![];
var last = -2915 + -4 * -2215 + 41 * -145;
var flip2 = ![];
var last2 = 1 * 6601 + -6101 * 1 + -500;

function Vektor_1() {
    var unsetPolling = _0x31205f;
    if (UI[unsetPolling("0x182", "%#fz")]([unsetPolling("0x3dc", "DtBC"), unsetPolling("0x609", "Md]D"), unsetPolling("0x6bd", "yVP2"), unsetPolling("0x32e", "R4C(")])) {
        var data = Entity[unsetPolling("0x29f", "ENd4")]();
        var item = get_health(data);
        var rcvdMsg = get_velocity(data);
        var clojIsReversed = Entity[unsetPolling("0xaf8", "M]md")](Entity[unsetPolling("0x35b", "82iA")](target));
        var _0x252706 = get_metric_distance(Entity[unsetPolling("0x17b", "yVP2")](Entity[unsetPolling("0x89e", "0jac")]()), Entity[unsetPolling("0x5d9", "4jWr")](target));
        var stacheFrag = Entity[unsetPolling("0x5d8", "9U5N")](data, unsetPolling("0x181", "]C]N"), unsetPolling("0x42c", "Ly5M"));
        var _0x2c49e2 = Math[unsetPolling("0x320", "tySx")](stacheFrag[-8346 + 34 * -214 + 1 * 15622] * stacheFrag[-227 * 25 + 1296 + 4379] + stacheFrag[9777 + 1 * 379 + 5 * -2031] * stacheFrag[-8045 + -3048 + 11094 * 1] + stacheFrag[481 + -7 * 1127 + 7410] * stacheFrag[-2477 * 1 + -37 * 170 + 8769 * 1]);
        if (UI[unsetPolling("0x65a", "yVP2")]([unsetPolling("0xa65", "*f)e"), unsetPolling("0x618", "4jWr"), unsetPolling("0x9a2", "JG#F"), unsetPolling("0x8ed", "M]md")])) {
            Ideal_Yaw = !![];
        } else {
            Ideal_Yaw = ![];
        }
        if (clojIsReversed == unsetPolling("0x345", "0jac") && _0x252706 < -766 * 9 + -8680 + 15609) {
            setBack = !![];
        } else {
            setBack = ![];
        }
        if (clojIsReversed == unsetPolling("0x702", "7(LG") && item < -9807 + -4715 + 14602 && _0x252706 < -584 * -8 + -145 * 2 + -34 * 128 || clojIsReversed == unsetPolling("0x26a", "AMGA") && item < 6 * -873 + -14 * 83 + -1297 * -5 && _0x252706 < 14 * 14 + 5099 + -2635 * 2 || clojIsReversed == unsetPolling("0x3a8", "i00^") && item < 29 * -137 + 2995 * -1 + 7058 && _0x252706 < -1639 * 6 + -63 * -89 + 137 * 31 || clojIsReversed == unsetPolling("0x15e", "RrDx") && item < -4297 + 4 * 1597 + -1998 && _0x252706 < -1 * -7181 + 3167 + -10331 * 1 || isRevolver(clojIsReversed) && item < -1 * 5983 + -1 * 7841 + -31 * -449 && _0x252706 < 14 * -683 + -1573 + 11160 || isRevolver(clojIsReversed) && item < -7075 + -8003 * 1 + 15178 && _0x252706 < -304 * -22 + -470 * 13 + -568 || isDeagle(clojIsReversed) && item < -539 * -9 + -709 * 14 + 5145 && _0x252706 < -5231 + -1 * 2595 + 7841 || isDeagle(clojIsReversed) && item < 1654 + 6137 + -7691 && _0x252706 < -7089 + 928 * -2 + -7 * -1279 || isAutoSniper(clojIsReversed) && item < 24 * 191 + 14 * -190 + -1844 && _0x252706 < -5277 + 5981 + -679 || clojIsReversed == unsetPolling("0x65", "ZtZ5") && item < -1 * -4911 + 148 * 3 + -2630 * 2) {
            dangerous = !![];
        } else {
            dangerous = ![];
        }
        if (UI[unsetPolling("0x379", "R4C(")]([unsetPolling("0x871", "3e5%"), unsetPolling("0x19", "HY1z"), unsetPolling("0x5e2", "8$2U"), unsetPolling("0xa60", "RpYp")]) || safe_h) {
            AntiAim[unsetPolling("0x4f7", "RrDx")](-7893 + 4147 + -3 * -1249);
        } else {
            AntiAim[unsetPolling("0x4a3", "x65P")](-4295 * -2 + -17 * -317 + -13979);
        }
        var _0x4a5328;
        var moduleName;
        var val2Type;
        var homeSpread;
        var awaySpread = UI[unsetPolling("0x2a1", "*TM&")]([unsetPolling("0xf5", "6y51"), unsetPolling("0xaf5", "89dW"), unsetPolling("0x8d7", "JG#F"), unsetPolling("0xb3", "bORa")]);
        const NEGATIVE_INTEGER = UI[unsetPolling("0x49a", "]C]N")]([unsetPolling("0x791", "s(MI"), unsetPolling("0x908", "KA@R"), unsetPolling("0x30b", "s4OQ"), unsetPolling("0x5fb", "]#PJ")]);
        if (UI[unsetPolling("0xa2e", "4*%U")]([unsetPolling("0x3a", "Md]D"), unsetPolling("0x225", "RrDx"), unsetPolling("0x31f", "7(LG"), unsetPolling("0x566", "^&*3")])) {
            if (awaySpread == 7345 + -3024 * -2 + -227 * 59) {
                if (UI[unsetPolling("0x501", "Ly5M")]([unsetPolling("0x204", "i00^"), unsetPolling("0x5cd", "R#3P"), unsetPolling("0x51e", "Ly5M"), unsetPolling("0x43e", "RpYp")])) {
                    moduleName = !![];
                } else {
                    moduleName = ![];
                }
            } else {
                if (awaySpread == 163 * -3 + -4758 + 5248) {
                    if (NEGATIVE_INTEGER & -4 * 1331 + 1 * 4776 + 549 * 1 << 842 * 7 + -5090 + -804 && UI[unsetPolling("0xa54", "RpYp")]([unsetPolling("0x430", "0jac"), unsetPolling("0x51c", "RpYp"), unsetPolling("0xaf", "fOHz"), unsetPolling("0xb04", "@zrZ")])) {
                        moduleName = !![];
                    } else {
                        moduleName = ![];
                    }
                    if (NEGATIVE_INTEGER & 1379 * -7 + 482 + -2293 * -4 << 4870 + 2808 + -7677 && item < -2 * 2507 + 9991 + 379 * -13) {
                        _0x4a5328 = !![];
                    } else {
                        _0x4a5328 = ![];
                    }
                    if (NEGATIVE_INTEGER & -313 * 13 + -4 * -1993 + -1951 * 2 << 706 * -11 + -4540 + 12308 && rcvdMsg < 6670 + -1465 + 306 * -17) {
                        val2Type = !![];
                    } else {
                        val2Type = ![];
                    }
                } else {
                    if (awaySpread == 5 * 449 + -7169 + 4926) {
                        if (UI[unsetPolling("0x379", "R4C(")]([unsetPolling("0xb44", "RpYp"), unsetPolling("0x274", "JG#F"), unsetPolling("0x794", "4jWr"), unsetPolling("0x951", "^&*3")])) {
                            homeSpread = !![];
                        } else {
                            homeSpread = ![];
                        }
                    }
                }
            }
            if (awaySpread == 20 * 407 + 955 * 9 + -16735 && moduleName == !![] || (awaySpread == -2199 * 3 + 232 + 6366 && val2Type == !![] || _0x4a5328 == !![] || moduleName == !![] || homeSpread == !![]) || awaySpread == -2482 * 4 + -8098 * -1 + -2 * -916 && homeSpread == !![] && UI[unsetPolling("0x7e4", "82iA")]([unsetPolling("0x362", "ENd4"), unsetPolling("0x5aa", "ZtZ5"), unsetPolling("0x817", "!w]r"), unsetPolling("0x808", "T*7j")])) {
                UI[unsetPolling("0x6fb", "AMGA")]([unsetPolling("0x4e", "KA@R"), unsetPolling("0xb2d", "4*%U"), unsetPolling("0x935", "ENd4"), unsetPolling("0x4d6", "JG#F")], 77 * 14 + 7943 + -9011);
                UI[unsetPolling("0xf8", "hs0[")]([unsetPolling("0x85e", "HY1z"), unsetPolling("0x999", "WoWH"), unsetPolling("0x361", "AMGA"), unsetPolling("0x4b9", "^Cpz")], -282 + 1379 + -1097);
                AntiAim[unsetPolling("0x102", "RpYp")](-2441 + 6836 + 3 * -1465);
                AntiAim[unsetPolling("0x502", "%#fz")](-(-49 * -143 + -9609 + -1311 * -2));
                AntiAim[unsetPolling("0x427", "Md]D")](-2 * -3695 + 553 * 7 + -11171);
                safe_h = !![];
            } else {
                UI[unsetPolling("0xa5b", "x65P")]([unsetPolling("0x696", "R#3P"), unsetPolling("0x863", "i00^"), unsetPolling("0x12e", "82iA"), unsetPolling("0x981", "s4OQ")], -127 * 52 + -6 + -3305 * -2);
                safe_h = ![];
            }
        }
        if (_0x2c49e2 < -4320 + -1783 * 4 + -2878 * -4) {
            return;
        }
        var line = Globals[unsetPolling("0xaa6", "89dW")]() - Entity[unsetPolling("0x5b2", "AMGA")](data, unsetPolling("0xb01", "Ly5M"), unsetPolling("0xa35", "R4C("));
        if (last > line) {
            flip = !flip;
        }
        UI[unsetPolling("0xf8", "hs0[")]([unsetPolling("0xb05", "!q5U"), unsetPolling("0x492", "tySx"), unsetPolling("0xa2c", "]C]N"), unsetPolling("0x2e4", "hs0[")], -209 * 40 + -6118 + 14478);
        UI[unsetPolling("0xb3d", "6y51")]([unsetPolling("0x696", "R#3P"), unsetPolling("0x8bd", "4jWr"), unsetPolling("0x7cf", "s4OQ"), unsetPolling("0x714", "Md]D")], -6121 + 1 * 8816 + -2695);
        UI[unsetPolling("0xa5b", "x65P")]([unsetPolling("0xb05", "!q5U"), unsetPolling("0x51c", "RpYp"), unsetPolling("0x698", "^&*3"), unsetPolling("0x829", "bORa")], -8777 + 1 * 1311 + 7466);
        UI[unsetPolling("0x15", "Md]D")]([unsetPolling("0xb4", "@zrZ"), unsetPolling("0x2b6", "]C]N"), unsetPolling("0xa2d", "AMGA"), unsetPolling("0x9d4", "*f)e")], 127 * 27 + 14 * -163 + 1 * -1147);
        if (UI[unsetPolling("0xa2e", "4*%U")]([unsetPolling("0x3dc", "DtBC"), unsetPolling("0xa39", "RpYp"), unsetPolling("0x2f8", "T*7j"), unsetPolling("0x44e", "4*%U")])) {
            var _0x539acb = Math[unsetPolling("0x9d1", "QNb%")](Math[unsetPolling("0x9e3", "6y51")]() * (3367 + -9372 + 6008) + (7800 + -2570 * -2 + 1 * -12939));
            var $get = function(mmCoreSplitViewBlock) {
                var getPreferredLanguage = unsetPolling;
                UI[getPreferredLanguage("0x2d", "DtBC")]([getPreferredLanguage("0x750", "4*%U"), getPreferredLanguage("0x8b7", "UzS9"), getPreferredLanguage("0x947", "8$2U"), getPreferredLanguage("0x599", "Ly5M")], mmCoreSplitViewBlock);
            };
            switch (_0x539acb) {
                case 9073 + 196 + -9269:
                    $get(-1824 * 1 + -3 * -1906 + 3 * -1298);
                    break;
                case 6282 + 326 * 4 + -5 * 1517:
                    $get(-8251 * 1 + -1 * 8551 + 16803);
                    break;
                case -8185 + -6 * 1601 + 17793:
                    $get(-201 * 41 + 2432 + 157 * 37);
            }
        }
        if (setBack == ![] && safe_h == ![]) {
            UI[unsetPolling("0x322", "KA@R")]([unsetPolling("0x9f3", "8$2U"), unsetPolling("0xc6", "Md]D"), unsetPolling("0x594", "WoWH"), unsetPolling("0x582", "R4C(")], 3044 * -1 + -3265 + 6310);
            if (dangerous == ![]) {
                if (!Entity[unsetPolling("0x236", "yVP2")](data) || !UI[unsetPolling("0x503", "!q5U")]([unsetPolling("0x1fd", "HY1z"), unsetPolling("0x908", "KA@R"), unsetPolling("0x630", "0jac"), unsetPolling("0x4df", "]#PJ")]) || !UI[unsetPolling("0x397", "89dW")]([unsetPolling("0x1fd", "HY1z"), unsetPolling("0x383", "%#fz"), unsetPolling("0x6ea", "RpYp"), unsetPolling("0x971", "KA@R")]) || !setBack == ![]) {
                    return;
                }
                if (Entity[unsetPolling("0xaab", "tySx")](data)) {
                    var _0x33fd96;
                    var _0x34396f = Local[unsetPolling("0x73b", "ZtZ5")]();
                    left_distance = trace(data, [1926 + -5508 + 6 * 597, _0x34396f[1 * 5204 + -247 * 13 + -1992 * 1] - (-18 * -319 + 4349 + -10069)]);
                    right_distance = trace(data, [-6371 + -56 * 27 + 1 * 7883, _0x34396f[691 * -1 + -9 * -171 + -847] + (1 * -8474 + -9231 + 5909 * 3)]);
                    if (left_distance > right_distance) {
                        UI[unsetPolling("0x5e", "@zrZ")]([unsetPolling("0x13a", "T*7j"), unsetPolling("0x616", "^Cpz"), unsetPolling("0x33d", "tySx"), unsetPolling("0x360", "4jWr")], -(-394 * -6 + 3056 + 33 * -164));
                        AntiAim[unsetPolling("0xdd", "89dW")](-7363 + -61 + 7424);
                        AntiAim[unsetPolling("0x75a", "D!Qj")](-(-4111 + -9007 + -6589 * -2));
                        AntiAim[unsetPolling("0x7c8", "9U5N")](-1173 * 8 + -1 * 4823 + 841 * 17);
                    }
                    if (right_distance > left_distance) {
                        UI[unsetPolling("0xb3d", "6y51")]([unsetPolling("0x13a", "T*7j"), unsetPolling("0x492", "tySx"), unsetPolling("0x160", "]C]N"), unsetPolling("0x2a9", "Ly5M")], -(7586 * 1 + 9328 + 16909 * -1));
                        AntiAim[unsetPolling("0x5f1", "9U5N")](2119 + 7660 + -9779);
                        AntiAim[unsetPolling("0xb33", "3e5%")](6215 + -1522 * -4 + 231 * -53);
                        AntiAim[unsetPolling("0x28a", "RrDx")](-(3 * 55 + 2591 + -2666));
                    }
                }
            } else {
                if (dangerous == !![]) {
                    if (!Entity[unsetPolling("0x40a", "%#fz")](data) || !UI[unsetPolling("0x622", "M]md")]([unsetPolling("0x3a", "Md]D"), unsetPolling("0x817", "!w]r"), unsetPolling("0x30b", "s4OQ"), unsetPolling("0x968", "^&*3")]) || !UI[unsetPolling("0xcb", "i00^")]([unsetPolling("0x68b", "R#3P"), unsetPolling("0x3b3", "x65P"), unsetPolling("0x55", "x65P"), unsetPolling("0x431", "s(MI")]) || !setBack == ![]) {
                        return;
                    }
                    if (Entity[unsetPolling("0xa74", "T*7j")](data)) {
                        _0x34396f = Local[unsetPolling("0x4c6", "!q5U")]();
                        left_distance = trace(data, [-6864 + -6857 + 1 * 13721, _0x34396f[115 * 59 + 5915 + 3 * -4233] - (4056 + -9742 + 5708)]);
                        right_distance = trace(data, [-2500 + -7118 + -3 * -3206, _0x34396f[-4932 + -7 * -118 + 111 * 37] + (-4282 + 6009 + -1705)]);
                        if (left_distance < right_distance) {
                            UI[unsetPolling("0x5e3", "tySx")]([unsetPolling("0x23", "WoWH"), unsetPolling("0x492", "tySx"), unsetPolling("0xa82", "4*%U"), unsetPolling("0x90", "^Cpz")], -(-9 * 508 + -7820 + 496 * 25));
                            AntiAim[unsetPolling("0xb28", "fOHz")](7810 + -1683 + -6127);
                            AntiAim[unsetPolling("0x3b1", "KA@R")](-(4138 + -744 * 3 + 13 * -142));
                            AntiAim[unsetPolling("0x6df", "!w]r")](-8361 + 7152 + 1299);
                        }
                        if (right_distance < left_distance) {
                            UI[unsetPolling("0x26b", "7(LG")]([unsetPolling("0x875", "*TM&"), unsetPolling("0x67b", "ZtZ5"), unsetPolling("0x361", "AMGA"), unsetPolling("0x20c", "s(MI")], -(1 * -9270 + -149 + 9424));
                            AntiAim[unsetPolling("0x4be", "x65P")](8642 + -5894 + -4 * 687);
                            AntiAim[unsetPolling("0x983", "RrDx")](-9 * 35 + -1 * -5871 + -3 * 1832);
                            AntiAim[unsetPolling("0x3fd", "HY1z")](-(2644 + -9134 + 6580));
                        }
                    }
                }
            }
        } else {
            if (setBack == !![] && safe_h == ![]) {
                if (dangerous == ![]) {
                    if (!Entity[unsetPolling("0x6ed", "KA@R")](data) || !UI[unsetPolling("0x2a1", "*TM&")]([unsetPolling("0x3dc", "DtBC"), unsetPolling("0x51d", "yVP2"), unsetPolling("0xa3a", "4*%U"), unsetPolling("0x774", "]#PJ")]) || !UI[unsetPolling("0xaf4", "HY1z")]([unsetPolling("0x57f", "@zrZ"), unsetPolling("0x630", "0jac"), unsetPolling("0xfb", "hs0["), unsetPolling("0x419", "3e5%")]) || !setBack == !![]) {
                        return;
                    }
                    if (Entity[unsetPolling("0xadd", "!w]r")](data)) {
                        _0x34396f = Local[unsetPolling("0x76c", "7(LG")]();
                        left_distance = trace(data, [-1 * 1091 + -4273 * -1 + -3182, _0x34396f[13 * -116 + 6109 * -1 + 586 * 13] - (5064 + 2 * -1781 + -1480)]);
                        right_distance = trace(data, [1434 * -1 + 586 * 3 + -324, _0x34396f[-1 * 6017 + -1726 + 7744] + (-7033 + -8387 + 1103 * 14)]);
                        if (left_distance > right_distance) {
                            UI[unsetPolling("0x5e3", "tySx")]([unsetPolling("0x220", "ENd4"), unsetPolling("0x409", "7(LG"), unsetPolling("0x7e1", "UzS9"), unsetPolling("0x31a", "%#fz")], -(8464 + 1 * -4759 + -3697));
                            AntiAim[unsetPolling("0x3c", "RrDx")](-1936 + 1368 + 1 * 568);
                            AntiAim[unsetPolling("0x706", "6y51")](flip ? -(-1249 * 3 + -25 * 103 + 6352 * 1) : -4231 + 3841 + 420);
                            AntiAim[unsetPolling("0x8f9", "3e5%")](-7935 * -1 + -1316 + -6529);
                            last = line;
                        }
                        if (right_distance > left_distance) {
                            UI[unsetPolling("0x52f", "]#PJ")]([unsetPolling("0x22c", "6y51"), unsetPolling("0x6cc", "KA@R"), unsetPolling("0x6c", "T*7j"), unsetPolling("0x981", "s4OQ")], -(427 + -8 * 631 + 4626));
                            AntiAim[unsetPolling("0x602", "KA@R")](-3267 + -321 + 69 * 52);
                            AntiAim[unsetPolling("0x706", "6y51")](flip ? 5657 + 129 + 1439 * -4 : -(-1 * -7989 + 7298 + 15257 * -1));
                            AntiAim[unsetPolling("0x787", "6y51")](-(-2 * -4835 + -216 * 41 + -362 * 2));
                            last = line;
                        }
                    }
                } else {
                    if (dangerous == !![]) {
                        if (!Entity[unsetPolling("0x1b9", "tbdl")](data) || !UI[unsetPolling("0x398", "T*7j")]([unsetPolling("0x40f", "4jWr"), unsetPolling("0x274", "JG#F"), unsetPolling("0x9a2", "JG#F"), unsetPolling("0x44f", "R4C(")]) || !UI[unsetPolling("0x8d1", "*f)e")]([unsetPolling("0xb4e", "7(LG"), unsetPolling("0x630", "0jac"), unsetPolling("0x889", "!q5U"), unsetPolling("0x453", "4jWr")]) || !setBack == !![]) {
                            return;
                        }
                        if (Entity[unsetPolling("0x189", "i00^")](data)) {
                            _0x34396f = Local[unsetPolling("0x54c", "DtBC")]();
                            left_distance = trace(data, [1 * 6709 + -7294 + -5 * -117, _0x34396f[8839 * -1 + -9937 + 18777] - (-3872 + 9024 + -5130)]);
                            right_distance = trace(data, [-8396 + -2584 + 10980, _0x34396f[8780 + 3961 + -4 * 3185] + (-299 + -8361 * -1 + -8040)]);
                            if (left_distance > right_distance) {
                                UI[unsetPolling("0x2ce", "fOHz")]([unsetPolling("0x939", "s4OQ"), unsetPolling("0x88c", "ENd4"), unsetPolling("0x96d", "RpYp"), unsetPolling("0x760", "R#3P")], -(-4016 * -1 + -32 + -3979));
                                AntiAim[unsetPolling("0x627", "*TM&")](5974 * 1 + -1553 + 1 * -4421);
                                AntiAim[unsetPolling("0x6ba", "^&*3")](flip ? 8032 + 64 * 45 + -10882 : -(2572 + 8 * 419 + 842 * -7));
                                AntiAim[unsetPolling("0x6c7", "AMGA")](-(4043 + -5 * 452 + -1693));
                                last = line;
                            }
                            if (right_distance > left_distance) {
                                UI[unsetPolling("0x403", "^Cpz")]([unsetPolling("0x910", "7(LG"), unsetPolling("0x827", "6y51"), unsetPolling("0x42f", "yVP2"), unsetPolling("0x7d8", "AMGA")], -(1 * 6305 + 34 * -269 + 11 * 259));
                                AntiAim[unsetPolling("0x246", "i00^")](-1639 + 46 * -58 + -73 * -59);
                                AntiAim[unsetPolling("0x118", "AMGA")](flip ? -(3566 * 1 + 801 * -8 + 2872) : 3991 + -935 + -34 * 89);
                                AntiAim[unsetPolling("0x6c7", "AMGA")](-5438 + 157 + 5371 * 1);
                                last = line;
                            }
                        }
                    }
                }
            }
        }
    }
}
seta = ![], setb = !![];

function ForceHeadAim() {
    var gotoNewOfflinePage = _0x31205f;
    var indexLookupKey = Entity[gotoNewOfflinePage("0x657", "R4C(")](Entity[gotoNewOfflinePage("0x8d9", "i00^")](Entity[gotoNewOfflinePage("0x165", "hs0[")]()));
    if (UI[gotoNewOfflinePage("0x3ce", "]#PJ")]([gotoNewOfflinePage("0x2df", "WoWH"), gotoNewOfflinePage("0xae0", "89dW"), gotoNewOfflinePage("0x931", "yVP2"), gotoNewOfflinePage("0x858", "s4OQ")]) && UI[gotoNewOfflinePage("0xa2e", "4*%U")]([gotoNewOfflinePage("0x7e0", "UzS9"), gotoNewOfflinePage("0x954", "%#fz"), gotoNewOfflinePage("0x8f3", "AMGA"), gotoNewOfflinePage("0x797", "hs0[")]) == -5758 * 1 + 475 * -5 + 8134 && UI[gotoNewOfflinePage("0x6f0", "!w]r")]([gotoNewOfflinePage("0x5dd", "s4OQ"), gotoNewOfflinePage("0x214", "!w]r"), gotoNewOfflinePage("0xa28", "!w]r"), gotoNewOfflinePage("0x10e", "Ly5M")])) {
        if (!seta) {
            wep_cashe = UI[gotoNewOfflinePage("0x1c4", "0jac")]([gotoNewOfflinePage("0x3ea", "]C]N"), gotoNewOfflinePage("0x3ec", "T*7j"), weaponTabNames[indexLookupKey], gotoNewOfflinePage("0x736", "9U5N")]);
            UI[gotoNewOfflinePage("0xb3b", "s4OQ")]([gotoNewOfflinePage("0x930", "4*%U"), gotoNewOfflinePage("0x68e", "i00^"), weaponTabNames[indexLookupKey], gotoNewOfflinePage("0x358", "ZtZ5")], -3 * 857 + 47 * 97 + 1 * -1987);
            seta = !![];
            setb = ![];
        }
    } else {
        if (!setb) {
            UI[gotoNewOfflinePage("0x2ef", "HY1z")]([gotoNewOfflinePage("0x875", "*TM&"), gotoNewOfflinePage("0x203", "tbdl"), weaponTabNames[indexLookupKey], gotoNewOfflinePage("0x251", "T*7j")], wep_cashe);
            setb = !![];
            seta = ![];
        }
    }
}
setc = ![], setd = !![];

function ForceHeadAim1() {
    var gotoNewOfflinePage = _0x31205f;
    var artistTrack = UI[gotoNewOfflinePage("0x115", "@zrZ")]([gotoNewOfflinePage("0x17d", "89dW"), gotoNewOfflinePage("0x654", "s4OQ"), gotoNewOfflinePage("0x9ea", "KA@R"), gotoNewOfflinePage("0xd4", "AMGA")]);
    var GET_AUTH_URL_TIMEOUT = UI[gotoNewOfflinePage("0x50", "JG#F")]([gotoNewOfflinePage("0x179", "ZtZ5"), gotoNewOfflinePage("0xa32", "R4C("), gotoNewOfflinePage("0x8f3", "AMGA"), gotoNewOfflinePage("0x555", "ZtZ5")]);
    var numKeysDeleted = UI[gotoNewOfflinePage("0x2a1", "*TM&")]([gotoNewOfflinePage("0xf5", "6y51"), gotoNewOfflinePage("0x9f6", "*f)e"), gotoNewOfflinePage("0x587", "*TM&"), gotoNewOfflinePage("0x71f", "JG#F")]);
    var postDateGmt = UI[gotoNewOfflinePage("0x7e4", "82iA")]([gotoNewOfflinePage("0x57f", "@zrZ"), gotoNewOfflinePage("0x931", "yVP2"), gotoNewOfflinePage("0x337", "x65P"), gotoNewOfflinePage("0x749", "HY1z")]);
    var _maskLayer = UI[gotoNewOfflinePage("0x48b", "ENd4")]([gotoNewOfflinePage("0x9af", "QNb%"), gotoNewOfflinePage("0x747", "]C]N"), gotoNewOfflinePage("0x1f2", "D!Qj"), gotoNewOfflinePage("0x60d", "0jac")]);
    var indexLookupKey = Entity[gotoNewOfflinePage("0x198", "tbdl")](Entity[gotoNewOfflinePage("0xb41", "x65P")](Entity[gotoNewOfflinePage("0x611", "KA@R")]()));
    if (UI[gotoNewOfflinePage("0x182", "%#fz")]([gotoNewOfflinePage("0x40d", "yVP2"), gotoNewOfflinePage("0x814", "RpYp"), gotoNewOfflinePage("0x4b0", "4*%U"), gotoNewOfflinePage("0xa8e", "D!Qj")]) && UI[gotoNewOfflinePage("0x346", "UzS9")]([gotoNewOfflinePage("0x9b4", "tySx"), gotoNewOfflinePage("0x9a6", "ENd4"), gotoNewOfflinePage("0x70b", "^Cpz"), gotoNewOfflinePage("0x7e6", "*f)e")]) == -6666 + -859 + -71 * -106 && UI[gotoNewOfflinePage("0x308", "tySx")]([gotoNewOfflinePage("0x3e9", "0jac"), gotoNewOfflinePage("0x19", "HY1z"), gotoNewOfflinePage("0x14f", "*f)e"), gotoNewOfflinePage("0x814", "RpYp")]) && UI[gotoNewOfflinePage("0x48b", "ENd4")]([gotoNewOfflinePage("0xf5", "6y51"), gotoNewOfflinePage("0x91f", "T*7j"), gotoNewOfflinePage("0x654", "s4OQ"), gotoNewOfflinePage("0x291", "i00^")])) {
        if (!setc) {
            wep_head_multipoint_cache = UI[gotoNewOfflinePage("0x19c", "8$2U")]([gotoNewOfflinePage("0x243", "yVP2"), gotoNewOfflinePage("0x81b", "yVP2"), weaponTabNames[indexLookupKey], gotoNewOfflinePage("0x72a", "i00^")]);
            UI[gotoNewOfflinePage("0x3ed", "9U5N")]([gotoNewOfflinePage("0x624", "9U5N"), gotoNewOfflinePage("0x700", "RpYp"), gotoNewOfflinePage("0xb58", "M]md"), gotoNewOfflinePage("0xa9d", "tbdl")], artistTrack);
            UI[gotoNewOfflinePage("0x3ed", "9U5N")]([gotoNewOfflinePage("0x5e9", "UzS9"), gotoNewOfflinePage("0x92e", "*f)e"), gotoNewOfflinePage("0xc7", "AMGA"), gotoNewOfflinePage("0x91", "Md]D")], artistTrack);
            UI[gotoNewOfflinePage("0x90b", "s(MI")]([gotoNewOfflinePage("0xa6c", "^&*3"), gotoNewOfflinePage("0x6c5", "JG#F"), gotoNewOfflinePage("0x7ef", "hs0["), gotoNewOfflinePage("0x9db", "M]md")], artistTrack);
            UI[gotoNewOfflinePage("0x13f", "bORa")]([gotoNewOfflinePage("0x4dd", "ZtZ5"), gotoNewOfflinePage("0x90d", "@zrZ"), gotoNewOfflinePage("0x287", "%#fz"), gotoNewOfflinePage("0x8b5", "tySx")], artistTrack);
            UI[gotoNewOfflinePage("0x15", "Md]D")]([gotoNewOfflinePage("0x5b3", "M]md"), gotoNewOfflinePage("0x543", "tySx"), gotoNewOfflinePage("0x477", "JG#F"), gotoNewOfflinePage("0x270", "DtBC")], artistTrack);
            UI[gotoNewOfflinePage("0x4ca", "ZtZ5")]([gotoNewOfflinePage("0x9b6", "tbdl"), gotoNewOfflinePage("0x744", "M]md"), gotoNewOfflinePage("0xa87", "ENd4"), gotoNewOfflinePage("0xe0", "%#fz")], artistTrack);
            UI[gotoNewOfflinePage("0x3ed", "9U5N")]([gotoNewOfflinePage("0x13a", "T*7j"), gotoNewOfflinePage("0x306", "QNb%"), gotoNewOfflinePage("0x92c", "3e5%"), gotoNewOfflinePage("0x879", "s(MI")], artistTrack);
            UI[gotoNewOfflinePage("0x3ed", "9U5N")]([gotoNewOfflinePage("0xa61", "bORa"), gotoNewOfflinePage("0x245", "^&*3"), gotoNewOfflinePage("0x37b", "AMGA"), gotoNewOfflinePage("0x2f0", "s4OQ")], artistTrack);
            UI[gotoNewOfflinePage("0xf8", "hs0[")]([gotoNewOfflinePage("0x76f", "JG#F"), gotoNewOfflinePage("0x3aa", "]#PJ"), gotoNewOfflinePage("0x638", "M]md"), gotoNewOfflinePage("0x472", "!w]r")], numKeysDeleted);
            UI[gotoNewOfflinePage("0x4d8", "!w]r")]([gotoNewOfflinePage("0x3f7", "x65P"), gotoNewOfflinePage("0x725", "WoWH"), gotoNewOfflinePage("0x8e9", "tySx"), gotoNewOfflinePage("0x9d9", "89dW")], numKeysDeleted);
            UI[gotoNewOfflinePage("0xaa8", "WoWH")]([gotoNewOfflinePage("0x9cf", "D!Qj"), gotoNewOfflinePage("0x81b", "yVP2"), gotoNewOfflinePage("0x847", "@zrZ"), gotoNewOfflinePage("0x262", "RpYp")], postDateGmt);
            UI[gotoNewOfflinePage("0xb5c", "]C]N")]([gotoNewOfflinePage("0x5a1", "Ly5M"), gotoNewOfflinePage("0xf1", "9U5N"), gotoNewOfflinePage("0x437", "89dW"), gotoNewOfflinePage("0x704", "RrDx")], _maskLayer);
            UI[gotoNewOfflinePage("0x870", "M]md")]([gotoNewOfflinePage("0x6be", "4jWr"), gotoNewOfflinePage("0xa7e", "*TM&"), gotoNewOfflinePage("0xa4b", "*TM&"), gotoNewOfflinePage("0xb08", "Ly5M")], GET_AUTH_URL_TIMEOUT);
            UI[gotoNewOfflinePage("0x973", "89dW")]([gotoNewOfflinePage("0x5e9", "UzS9"), gotoNewOfflinePage("0x111", "0zlF"), gotoNewOfflinePage("0x35a", "Md]D"), gotoNewOfflinePage("0x59d", "HY1z")], GET_AUTH_URL_TIMEOUT);
            setc = !![];
            setd = ![];
        }
    } else {
        if (!setd) {
            UI[gotoNewOfflinePage("0x603", "UzS9")]([gotoNewOfflinePage("0x840", "%#fz"), gotoNewOfflinePage("0x91a", "0jac"), weaponTabNames[indexLookupKey], gotoNewOfflinePage("0x843", "6y51")], wep_head_multipoint_cache);
            setc = ![];
            setd = !![];
        }
    }
}
sete1 = ![], setf1 = !![], sete2 = ![], setf2 = !![], sete3 = ![], setf3 = !![], sete4 = ![], setf4 = !![], sete5 = ![], setf5 = !![];

function EarlyMode() {
    var gotoNewOfflinePage = _0x31205f;
    const scrollRangeFlags = UI[gotoNewOfflinePage("0x6d8", "R#3P")]([gotoNewOfflinePage("0x79a", "i00^"), gotoNewOfflinePage("0xa23", "QNb%"), gotoNewOfflinePage("0x84b", "KA@R"), gotoNewOfflinePage("0x2aa", "Md]D")]);
    const scrollbars = UI[gotoNewOfflinePage("0x308", "tySx")]([gotoNewOfflinePage("0x324", "]C]N"), gotoNewOfflinePage("0x8ea", "0jac"), gotoNewOfflinePage("0x417", "4jWr"), gotoNewOfflinePage("0x7e5", "ZtZ5")]);
    if (scrollbars & -1446 + -6667 * -1 + -1740 * 3 << -5343 + 3243 + 2100 && scrollRangeFlags & 2 * 1724 + 3082 + -1 * 6529 << 1 * 1906 + -1 * -2063 + -3969 && UI[gotoNewOfflinePage("0x622", "M]md")]([gotoNewOfflinePage("0xa89", "hs0["), gotoNewOfflinePage("0x46e", "tbdl"), gotoNewOfflinePage("0xae2", "s(MI"), gotoNewOfflinePage("0x4c0", "7(LG")]) && UI[gotoNewOfflinePage("0x3ce", "]#PJ")]([gotoNewOfflinePage("0xb10", "tbdl"), gotoNewOfflinePage("0x8a9", "*TM&"), gotoNewOfflinePage("0x417", "4jWr"), gotoNewOfflinePage("0x400", "UzS9")]) && UI[gotoNewOfflinePage("0xa88", "bORa")]([gotoNewOfflinePage("0xb06", "fOHz"), gotoNewOfflinePage("0xb26", "bORa"), gotoNewOfflinePage("0xa58", "tbdl"), gotoNewOfflinePage("0x353", "89dW")])) {
        if (!sete1) {
            autostop_modes_scar_cache = UI[gotoNewOfflinePage("0xa2e", "4*%U")]([gotoNewOfflinePage("0x875", "*TM&"), gotoNewOfflinePage("0x9e0", "AMGA"), gotoNewOfflinePage("0x385", "HY1z"), gotoNewOfflinePage("0x3b9", "@zrZ")]);
            autostop_modes_g3sg1_cache = UI[gotoNewOfflinePage("0x70c", "x65P")]([gotoNewOfflinePage("0x875", "*TM&"), gotoNewOfflinePage("0x49d", "DtBC"), gotoNewOfflinePage("0x67d", "Ly5M"), gotoNewOfflinePage("0x1f0", "!q5U")]);
            UI[gotoNewOfflinePage("0x43a", "82iA")]([gotoNewOfflinePage("0x696", "R#3P"), gotoNewOfflinePage("0x3cd", "s4OQ"), gotoNewOfflinePage("0x180", "fOHz"), gotoNewOfflinePage("0x7f4", "Ly5M")], -113 * 59 + -3852 + 10521 + autostop_modes_scar_cache);
            UI[gotoNewOfflinePage("0xd1", "RpYp")]([gotoNewOfflinePage("0x23", "WoWH"), gotoNewOfflinePage("0x8a", "WoWH"), gotoNewOfflinePage("0x7af", "hs0["), gotoNewOfflinePage("0x5b4", "*TM&")], -9601 * -1 + 8069 + -1 * 17668 + autostop_modes_g3sg1_cache);
            sete1 = !![];
            setf1 = ![];
        }
    } else {
        if (!setf1) {
            UI[gotoNewOfflinePage("0x50e", "4jWr")]([gotoNewOfflinePage("0x23", "WoWH"), gotoNewOfflinePage("0x54", "R#3P"), gotoNewOfflinePage("0x801", "@zrZ"), gotoNewOfflinePage("0x9ce", "M]md")], autostop_modes_scar_cache);
            UI[gotoNewOfflinePage("0x2ce", "fOHz")]([gotoNewOfflinePage("0x759", "s(MI"), gotoNewOfflinePage("0x9fa", "*f)e"), gotoNewOfflinePage("0x663", "4*%U"), gotoNewOfflinePage("0x263", "RrDx")], autostop_modes_g3sg1_cache);
            sete1 = ![];
            setf1 = !![];
        }
    }
    if (scrollbars & 48 * 80 + 1797 * -4 + 17 * 197 << 10 * 113 + 3321 + 2 * -2225 && scrollRangeFlags & 2803 + -9701 * 1 + 6899 << 1883 * 4 + -3570 + -3962 && UI[gotoNewOfflinePage("0x19c", "8$2U")]([gotoNewOfflinePage("0xa65", "*f)e"), gotoNewOfflinePage("0x782", "!q5U"), gotoNewOfflinePage("0xb57", "3e5%"), gotoNewOfflinePage("0x341", "yVP2")]) && UI[gotoNewOfflinePage("0xae6", "DtBC")]([gotoNewOfflinePage("0x217", "RrDx"), gotoNewOfflinePage("0x8ea", "0jac"), gotoNewOfflinePage("0xaeb", "4*%U"), gotoNewOfflinePage("0x66b", "6y51")]) && UI[gotoNewOfflinePage("0x2f9", "^&*3")]([gotoNewOfflinePage("0x752", "D!Qj"), gotoNewOfflinePage("0x164", "4*%U"), gotoNewOfflinePage("0x456", "@zrZ"), gotoNewOfflinePage("0x486", "RrDx")])) {
        if (!sete2) {
            autostop_modes_scout_cache = UI[gotoNewOfflinePage("0x668", "D!Qj")]([gotoNewOfflinePage("0x9f2", "89dW"), gotoNewOfflinePage("0x9e6", "T*7j"), gotoNewOfflinePage("0x5b7", "M]md"), gotoNewOfflinePage("0x3b9", "@zrZ")]);
            UI[gotoNewOfflinePage("0xf8", "hs0[")]([gotoNewOfflinePage("0x1c6", "hs0["), gotoNewOfflinePage("0x9e6", "T*7j"), gotoNewOfflinePage("0x5ad", "s4OQ"), gotoNewOfflinePage("0x84d", "QNb%")], 8874 + 8329 * -1 + -543 + autostop_modes_scout_cache);
            sete2 = !![];
            setf2 = ![];
        }
    } else {
        if (!setf2) {
            UI[gotoNewOfflinePage("0x857", "4*%U")]([gotoNewOfflinePage("0xafd", "QNb%"), gotoNewOfflinePage("0x1c3", "ENd4"), gotoNewOfflinePage("0x5ad", "s4OQ"), gotoNewOfflinePage("0x5fa", "fOHz")], autostop_modes_scout_cache);
            sete2 = ![];
            setf2 = !![];
        }
    }
    if (scrollbars & 13 * 492 + 1230 + 1525 * -5 << 5670 + 2431 + -89 * 91 && scrollRangeFlags & 1902 + -43 * 29 + -3 * 218 << -7416 + -3 * -701 + -1771 * -3 && UI[gotoNewOfflinePage("0xa08", "3e5%")]([gotoNewOfflinePage("0x844", "T*7j"), gotoNewOfflinePage("0x85d", "%#fz"), gotoNewOfflinePage("0x926", "s4OQ"), gotoNewOfflinePage("0x90c", "3e5%")]) && UI[gotoNewOfflinePage("0x115", "@zrZ")]([gotoNewOfflinePage("0x909", "^&*3"), gotoNewOfflinePage("0x2f8", "T*7j"), gotoNewOfflinePage("0x273", "tySx"), gotoNewOfflinePage("0xb3e", "Md]D")]) && UI[gotoNewOfflinePage("0x379", "R4C(")]([gotoNewOfflinePage("0x3dc", "DtBC"), gotoNewOfflinePage("0x274", "JG#F"), gotoNewOfflinePage("0x456", "@zrZ"), gotoNewOfflinePage("0x486", "RrDx")])) {
        if (!sete3) {
            autostop_modes_awp_cache = UI[gotoNewOfflinePage("0xcb", "i00^")]([gotoNewOfflinePage("0x243", "yVP2"), gotoNewOfflinePage("0x2d8", "^Cpz"), gotoNewOfflinePage("0x550", "RrDx"), gotoNewOfflinePage("0xaae", "s(MI")]);
            UI[gotoNewOfflinePage("0x6fd", "R4C(")]([gotoNewOfflinePage("0x930", "4*%U"), gotoNewOfflinePage("0x4f5", "R4C("), gotoNewOfflinePage("0x459", "x65P"), gotoNewOfflinePage("0xaaa", "0zlF")], -1 * -2690 + 189 + -2877 + autostop_modes_awp_cache);
            sete3 = !![];
            setf3 = ![];
        }
    } else {
        if (!setf3) {
            UI[gotoNewOfflinePage("0x85", "0jac")]([gotoNewOfflinePage("0x29e", "RrDx"), gotoNewOfflinePage("0x56f", "RrDx"), gotoNewOfflinePage("0x937", "4jWr"), gotoNewOfflinePage("0x9ce", "M]md")], autostop_modes_awp_cache);
            sete3 = ![];
            setf3 = !![];
        }
    }
    if (scrollbars & -6 * 1317 + 9767 + 8 * -233 << -3 * -62 + -8780 * 1 + 8597 && scrollRangeFlags & 6980 + -5261 + -2 * 859 << 1 * -5637 + -8531 + 2024 * 7 && UI[gotoNewOfflinePage("0xa2e", "4*%U")]([gotoNewOfflinePage("0x3a", "Md]D"), gotoNewOfflinePage("0x6ec", "bORa"), gotoNewOfflinePage("0x1f3", "D!Qj"), gotoNewOfflinePage("0xa48", "QNb%")]) && UI[gotoNewOfflinePage("0x398", "T*7j")]([gotoNewOfflinePage("0x7e0", "UzS9"), gotoNewOfflinePage("0xa39", "RpYp"), gotoNewOfflinePage("0x46e", "tbdl"), gotoNewOfflinePage("0x7ad", "tbdl")]) && UI[gotoNewOfflinePage("0x70c", "x65P")]([gotoNewOfflinePage("0x27c", "4*%U"), gotoNewOfflinePage("0x6a0", "T*7j"), gotoNewOfflinePage("0x8ba", "DtBC"), gotoNewOfflinePage("0x3ee", "JG#F")])) {
        if (!sete4) {
            autostop_modes_usp_cache = UI[gotoNewOfflinePage("0x2a1", "*TM&")]([gotoNewOfflinePage("0x29e", "RrDx"), gotoNewOfflinePage("0x7f1", "!w]r"), gotoNewOfflinePage("0xb11", "89dW"), gotoNewOfflinePage("0x5b4", "*TM&")]);
            autostop_modes_glock_cache = UI[gotoNewOfflinePage("0x622", "M]md")]([gotoNewOfflinePage("0x5a1", "Ly5M"), gotoNewOfflinePage("0x73a", "RpYp"), gotoNewOfflinePage("0x906", "3e5%"), gotoNewOfflinePage("0x538", "Md]D")]);
            autostop_modes_cz75_cache = UI[gotoNewOfflinePage("0x516", "s(MI")]([gotoNewOfflinePage("0x624", "9U5N"), gotoNewOfflinePage("0x4ea", "i00^"), gotoNewOfflinePage("0x75f", "KA@R"), gotoNewOfflinePage("0x2f5", "9U5N")]);
            autostop_modes_p2000_cache = UI[gotoNewOfflinePage("0xa88", "bORa")]([gotoNewOfflinePage("0xaba", "!w]r"), gotoNewOfflinePage("0x9e0", "AMGA"), gotoNewOfflinePage("0x375", "WoWH"), gotoNewOfflinePage("0x5c0", "DtBC")]);
            autostop_modes_p250_cache = UI[gotoNewOfflinePage("0x166", "QNb%")]([gotoNewOfflinePage("0x204", "i00^"), gotoNewOfflinePage("0x5b", "tySx"), gotoNewOfflinePage("0x9da", "s(MI"), gotoNewOfflinePage("0x84e", "ZtZ5")]);
            autostop_modes_tec9_cache = UI[gotoNewOfflinePage("0x6f0", "!w]r")]([gotoNewOfflinePage("0x9cf", "D!Qj"), gotoNewOfflinePage("0x54f", "7(LG"), gotoNewOfflinePage("0x8f2", "7(LG"), gotoNewOfflinePage("0x263", "RrDx")]);
            autostop_modes_dualies_cache = UI[gotoNewOfflinePage("0xa54", "RpYp")]([gotoNewOfflinePage("0xa6c", "^&*3"), gotoNewOfflinePage("0x435", "8$2U"), gotoNewOfflinePage("0x98c", "Ly5M"), gotoNewOfflinePage("0x945", "89dW")]);
            autostop_modes_fiveseven_cache = UI[gotoNewOfflinePage("0x397", "89dW")]([gotoNewOfflinePage("0x4e", "KA@R"), gotoNewOfflinePage("0xaf9", "JG#F"), gotoNewOfflinePage("0x5a9", "7(LG"), gotoNewOfflinePage("0x68f", "%#fz")]);
            UI[gotoNewOfflinePage("0x883", "tbdl")]([gotoNewOfflinePage("0x321", "AMGA"), gotoNewOfflinePage("0x523", "hs0["), gotoNewOfflinePage("0x6f1", "KA@R"), gotoNewOfflinePage("0x4b5", "AMGA")], -3181 * 1 + 7118 * 1 + -3935 + autostop_modes_usp_cache);
            UI[gotoNewOfflinePage("0x25f", "8$2U")]([gotoNewOfflinePage("0x4dc", "*f)e"), gotoNewOfflinePage("0x73a", "RpYp"), gotoNewOfflinePage("0xad3", "x65P"), gotoNewOfflinePage("0xa8", "RpYp")], 83 * 27 + -628 + 3 * -537 + autostop_modes_glock_cache);
            UI[gotoNewOfflinePage("0x995", "T*7j")]([gotoNewOfflinePage("0x76f", "JG#F"), gotoNewOfflinePage("0x88a", "Ly5M"), gotoNewOfflinePage("0x378", "3e5%"), gotoNewOfflinePage("0x672", "]C]N")], -6872 + -1 * 9082 + 15956 + autostop_modes_cz75_cache);
            UI[gotoNewOfflinePage("0xb0", "JG#F")]([gotoNewOfflinePage("0x220", "ENd4"), gotoNewOfflinePage("0x523", "hs0["), gotoNewOfflinePage("0x5e5", "89dW"), gotoNewOfflinePage("0x9ce", "M]md")], -8198 + -5684 + 13884 + autostop_modes_p2000_cache);
            UI[gotoNewOfflinePage("0xb1d", "3e5%")]([gotoNewOfflinePage("0x4dc", "*f)e"), gotoNewOfflinePage("0x8d0", "4jWr"), gotoNewOfflinePage("0x7bf", "M]md"), gotoNewOfflinePage("0xa07", "7(LG")], 3989 + -5 * -1343 + -10702 + autostop_modes_p250_cache);
            UI[gotoNewOfflinePage("0x7d0", "R#3P")]([gotoNewOfflinePage("0xa6c", "^&*3"), gotoNewOfflinePage("0x61b", "KA@R"), gotoNewOfflinePage("0xab5", "ZtZ5"), gotoNewOfflinePage("0x129", "R4C(")], -1059 + -1 * 6619 + 64 * 120 + autostop_modes_tec9_cache);
            UI[gotoNewOfflinePage("0xd1", "RpYp")]([gotoNewOfflinePage("0x220", "ENd4"), gotoNewOfflinePage("0x3cd", "s4OQ"), gotoNewOfflinePage("0x178", "s4OQ"), gotoNewOfflinePage("0x250", "JG#F")], 6602 + 2 * 738 + -8076 + autostop_modes_dualies_cache);
            UI[gotoNewOfflinePage("0x57e", "*f)e")]([gotoNewOfflinePage("0x4dd", "ZtZ5"), gotoNewOfflinePage("0xaed", "%#fz"), gotoNewOfflinePage("0x7f7", "]#PJ"), gotoNewOfflinePage("0x250", "JG#F")], -2691 * -3 + -4073 * -2 + -16217 + autostop_modes_fiveseven_cache);
            sete4 = !![];
            setf4 = ![];
        }
    } else {
        if (!setf4) {
            UI[gotoNewOfflinePage("0xb3b", "s4OQ")]([gotoNewOfflinePage("0x8fe", "]#PJ"), gotoNewOfflinePage("0x3fe", "9U5N"), gotoNewOfflinePage("0x117", "bORa"), gotoNewOfflinePage("0xb3c", "^Cpz")], autostop_modes_usp_cache);
            UI[gotoNewOfflinePage("0x24f", "^&*3")]([gotoNewOfflinePage("0x840", "%#fz"), gotoNewOfflinePage("0x7f1", "!w]r"), gotoNewOfflinePage("0x313", "8$2U"), gotoNewOfflinePage("0x5d2", "^&*3")], autostop_modes_glock_cache);
            UI[gotoNewOfflinePage("0x2ce", "fOHz")]([gotoNewOfflinePage("0x634", "RpYp"), gotoNewOfflinePage("0xaf9", "JG#F"), gotoNewOfflinePage("0x22", "]C]N"), gotoNewOfflinePage("0x3b9", "@zrZ")], autostop_modes_cz75_cache);
            UI[gotoNewOfflinePage("0x25f", "8$2U")]([gotoNewOfflinePage("0x243", "yVP2"), gotoNewOfflinePage("0x828", "x65P"), gotoNewOfflinePage("0x892", "ZtZ5"), gotoNewOfflinePage("0x250", "JG#F")], autostop_modes_p2000_cache);
            UI[gotoNewOfflinePage("0xd1", "RpYp")]([gotoNewOfflinePage("0x5a1", "Ly5M"), gotoNewOfflinePage("0x8d0", "4jWr"), gotoNewOfflinePage("0x9da", "s(MI"), gotoNewOfflinePage("0xc3", "yVP2")], autostop_modes_p250_cache);
            UI[gotoNewOfflinePage("0x2ce", "fOHz")]([gotoNewOfflinePage("0x9f3", "8$2U"), gotoNewOfflinePage("0x56f", "RrDx"), gotoNewOfflinePage("0x681", "HY1z"), gotoNewOfflinePage("0x1f0", "!q5U")], autostop_modes_tec9_cache);
            UI[gotoNewOfflinePage("0x973", "89dW")]([gotoNewOfflinePage("0x4e", "KA@R"), gotoNewOfflinePage("0x927", "0jac"), gotoNewOfflinePage("0x227", "WoWH"), gotoNewOfflinePage("0x9ce", "M]md")], autostop_modes_dualies_cache);
            UI[gotoNewOfflinePage("0x18", "QNb%")]([gotoNewOfflinePage("0x329", "Md]D"), gotoNewOfflinePage("0x2d8", "^Cpz"), gotoNewOfflinePage("0x8d", "M]md"), gotoNewOfflinePage("0x4aa", "]#PJ")], autostop_modes_fiveseven_cache);
            sete4 = ![];
            setf4 = !![];
        }
    }
    if (scrollbars & 9 * 471 + 5 * 64 + -4558 << -257 * 26 + -9671 * -1 + 199 * -15 && scrollRangeFlags & -9183 + -7333 * 1 + 16517 << -3740 + 3 * -2946 + 6289 * 2 && UI[gotoNewOfflinePage("0x50", "JG#F")]([gotoNewOfflinePage("0x5dd", "s4OQ"), gotoNewOfflinePage("0x1f3", "D!Qj"), gotoNewOfflinePage("0xaeb", "4*%U"), gotoNewOfflinePage("0x39d", "AMGA")]) && UI[gotoNewOfflinePage("0x1d2", "RrDx")]([gotoNewOfflinePage("0x168", "M]md"), gotoNewOfflinePage("0xb57", "3e5%"), gotoNewOfflinePage("0x998", "*f)e"), gotoNewOfflinePage("0x12f", "R4C(")]) && UI[gotoNewOfflinePage("0x6d8", "R#3P")]([gotoNewOfflinePage("0x4f9", "^Cpz"), gotoNewOfflinePage("0x86b", "QNb%"), gotoNewOfflinePage("0x745", "*TM&"), gotoNewOfflinePage("0x6b2", "]C]N")])) {
        if (!sete5) {
            autostop_modes_revolver_cache = UI[gotoNewOfflinePage("0xae6", "DtBC")]([gotoNewOfflinePage("0x430", "0jac"), gotoNewOfflinePage("0x462", "!q5U"), gotoNewOfflinePage("0x5d", "89dW"), gotoNewOfflinePage("0xa8", "RpYp")]);
            autostop_modes_deagle_cache = UI[gotoNewOfflinePage("0x4fd", "fOHz")]([gotoNewOfflinePage("0x634", "RpYp"), gotoNewOfflinePage("0x5bf", "QNb%"), gotoNewOfflinePage("0x5f5", "RpYp"), gotoNewOfflinePage("0x726", "s4OQ")]);
            UI[gotoNewOfflinePage("0x418", "D!Qj")]([gotoNewOfflinePage("0x204", "i00^"), gotoNewOfflinePage("0x690", "0zlF"), gotoNewOfflinePage("0x564", "yVP2"), gotoNewOfflinePage("0xaaa", "0zlF")], 677 * -8 + -3197 + -1723 * -5 + autostop_modes_revolver_cache);
            UI[gotoNewOfflinePage("0x322", "KA@R")]([gotoNewOfflinePage("0xb4", "@zrZ"), gotoNewOfflinePage("0xa44", "UzS9"), gotoNewOfflinePage("0x43", "i00^"), gotoNewOfflinePage("0x912", "UzS9")], -3387 * 1 + -502 * 5 + -5899 * -1 + autostop_modes_deagle_cache);
            sete5 = !![];
            setf5 = ![];
        }
    } else {
        if (!setf5) {
            UI[gotoNewOfflinePage("0x24f", "^&*3")]([gotoNewOfflinePage("0x220", "ENd4"), gotoNewOfflinePage("0x3ef", "fOHz"), gotoNewOfflinePage("0x49", "ENd4"), gotoNewOfflinePage("0x4d", "4jWr")], autostop_modes_revolver_cache);
            UI[gotoNewOfflinePage("0x24f", "^&*3")]([gotoNewOfflinePage("0x2b", "3e5%"), gotoNewOfflinePage("0x4ea", "i00^"), gotoNewOfflinePage("0x13e", "]#PJ"), gotoNewOfflinePage("0x7e7", "*f)e")], autostop_modes_deagle_cache);
            sete5 = ![];
            setf5 = !![];
        }
    }
}

function PreferBaim_Safepoint() {
    var gotoNewOfflinePage = _0x31205f;
    const _0x5922b6 = UI[gotoNewOfflinePage("0xa08", "3e5%")]([gotoNewOfflinePage("0x8c6", "x65P"), gotoNewOfflinePage("0x46e", "tbdl"), gotoNewOfflinePage("0x4e4", "9U5N"), gotoNewOfflinePage("0x552", "^Cpz")]);
    var criterion_index = Entity[gotoNewOfflinePage("0x8b3", "0jac")](Entity[gotoNewOfflinePage("0x23b", "Md]D")](Entity[gotoNewOfflinePage("0x8c9", "%#fz")]()));
    if (weaponTabNames[gotoNewOfflinePage("0x157", "T*7j")](criterion_index)) {
        if (UI[gotoNewOfflinePage("0x7c7", "Md]D")]([gotoNewOfflinePage("0x217", "RrDx"), gotoNewOfflinePage("0x4e4", "9U5N"), gotoNewOfflinePage("0x755", "ENd4"), gotoNewOfflinePage("0x9b2", "JG#F")]) && UI[gotoNewOfflinePage("0x622", "M]md")]([gotoNewOfflinePage("0xb37", "Ly5M"), gotoNewOfflinePage("0x577", "]C]N"), gotoNewOfflinePage("0xa39", "RpYp"), gotoNewOfflinePage("0x81a", "0jac")]) && _0x5922b6 & 84 * -46 + -4 * -2430 + -5855 << 1125 + 3625 + -1583 * 3 && UI[gotoNewOfflinePage("0xcb", "i00^")]([gotoNewOfflinePage("0xa61", "bORa"), gotoNewOfflinePage("0x2da", "JG#F"), gotoNewOfflinePage("0x31e", "JG#F"), gotoNewOfflinePage("0xae9", "s4OQ")]) && UI[gotoNewOfflinePage("0x7c7", "Md]D")]([gotoNewOfflinePage("0x204", "i00^"), gotoNewOfflinePage("0x3df", "8$2U"), gotoNewOfflinePage("0x22b", "fOHz"), gotoNewOfflinePage("0x572", "tySx"), gotoNewOfflinePage("0x4a1", "6y51")])) {
            UI[gotoNewOfflinePage("0x84f", "*TM&")]([gotoNewOfflinePage("0x5e9", "UzS9"), gotoNewOfflinePage("0x55f", "3e5%"), weaponTabNames[criterion_index], gotoNewOfflinePage("0xaec", "WoWH")], 7975 * -1 + -1 * -9718 + 871 * -2);
        } else {
            UI[gotoNewOfflinePage("0x7d0", "R#3P")]([gotoNewOfflinePage("0x696", "R#3P"), gotoNewOfflinePage("0x54f", "7(LG"), weaponTabNames[criterion_index], gotoNewOfflinePage("0x5a8", "RrDx")], -4 * -2408 + 4794 + -7213 * 2);
        }
        if (UI[gotoNewOfflinePage("0x1c4", "0jac")]([gotoNewOfflinePage("0xb44", "RpYp"), gotoNewOfflinePage("0x17a", "yVP2"), gotoNewOfflinePage("0x1d0", "^Cpz"), gotoNewOfflinePage("0x7a6", "8$2U")]) && UI[gotoNewOfflinePage("0x182", "%#fz")]([gotoNewOfflinePage("0xf5", "6y51"), gotoNewOfflinePage("0x1ee", "]#PJ"), gotoNewOfflinePage("0x40", "HY1z"), gotoNewOfflinePage("0x267", "4jWr")]) && _0x5922b6 & 6603 + 185 * -21 + -2717 << 6358 + -25 * 25 + -11 * 521 && UI[gotoNewOfflinePage("0x23f", "KA@R")]([gotoNewOfflinePage("0x204", "i00^"), gotoNewOfflinePage("0x183", "T*7j"), gotoNewOfflinePage("0x37c", "hs0["), gotoNewOfflinePage("0x50f", "@zrZ")]) && UI[gotoNewOfflinePage("0x1c4", "0jac")]([gotoNewOfflinePage("0x767", "DtBC"), gotoNewOfflinePage("0x6d9", "hs0["), gotoNewOfflinePage("0x16d", "hs0["), gotoNewOfflinePage("0x51e", "Ly5M"), gotoNewOfflinePage("0x63", "89dW")])) {
            UI[gotoNewOfflinePage("0x322", "KA@R")]([gotoNewOfflinePage("0x910", "7(LG"), gotoNewOfflinePage("0x395", "D!Qj"), weaponTabNames[criterion_index], gotoNewOfflinePage("0x2d5", "4*%U")], -4 * 2077 + 1 * -8725 + 17034);
        } else {
            UI[gotoNewOfflinePage("0xf8", "hs0[")]([gotoNewOfflinePage("0x368", "R4C("), gotoNewOfflinePage("0x8d0", "4jWr"), weaponTabNames[criterion_index], gotoNewOfflinePage("0x199", "^Cpz")], -7 * 1183 + -4061 * 2 + 16403);
        }
    }
}

function PingIndicator() {
    var gotoNewOfflinePage = _0x31205f;
    g_Local = Entity[gotoNewOfflinePage("0x22e", "M]md")]();
    g_Local_weapon = Entity[gotoNewOfflinePage("0x3a5", "R#3P")](g_Local);
    weapon_name = Entity[gotoNewOfflinePage("0x3d8", "!q5U")](g_Local_weapon);
    g_Local_classname = Entity[gotoNewOfflinePage("0x885", "QNb%")](g_Local_weapon);
    localplayer_index = Entity[gotoNewOfflinePage("0x961", "HY1z")]();
    localplayer_alive = Entity[gotoNewOfflinePage("0x487", "R#3P")](localplayer_index);
    render_get_screen_size = Render[gotoNewOfflinePage("0x851", "M]md")];
    if (!Entity[gotoNewOfflinePage("0x94f", "8$2U")]() || !Entity[gotoNewOfflinePage("0xa9", "Ly5M")](Entity[gotoNewOfflinePage("0x89e", "0jac")]()) || !Entity[gotoNewOfflinePage("0x799", "DtBC")](Entity[gotoNewOfflinePage("0xa90", "UzS9")]()) || !UI[gotoNewOfflinePage("0x501", "Ly5M")]([gotoNewOfflinePage("0x50d", "AMGA"), gotoNewOfflinePage("0x755", "ENd4"), gotoNewOfflinePage("0x295", "Ly5M"), gotoNewOfflinePage("0x9f0", "0zlF")]) == 623 * 11 + 1 * 3076 + 1 * -9929 || !UI[gotoNewOfflinePage("0x346", "UzS9")]([gotoNewOfflinePage("0x261", "%#fz"), gotoNewOfflinePage("0x1bc", "WoWH"), gotoNewOfflinePage("0x8d6", "fOHz"), gotoNewOfflinePage("0x283", "^&*3")]) || !UI[gotoNewOfflinePage("0xa54", "RpYp")]([gotoNewOfflinePage("0x57f", "@zrZ"), gotoNewOfflinePage("0x84b", "KA@R"), gotoNewOfflinePage("0x998", "*f)e"), gotoNewOfflinePage("0x14e", "9U5N")])) {
        return;
    }
    up = 53 * -67 + -1 * 6263 + 9814;
    font = Render[gotoNewOfflinePage("0x14a", "9U5N")](gotoNewOfflinePage("0x69a", "tbdl"), 7441 + 3177 + -10602, 1186 + -8219 + 1 * 7733);
    font2 = Render[gotoNewOfflinePage("0x256", "]C]N")](gotoNewOfflinePage("0x190", "7(LG"), -115 * 16 + 17 * -106 + 3647, 157 * -32 + -4583 * 1 + 9707);
    var value = Math[gotoNewOfflinePage("0x732", "]#PJ")](Local[gotoNewOfflinePage("0x89b", "3e5%")]() * (-8444 + 7337 + 2107 * 1) - (19 * -247 + -7804 + -12513 * -1));
    var oldCondition = Math[gotoNewOfflinePage("0x7b", "Ly5M")](value);
    const _0x4fb764 = render_get_screen_size()[843 + 5305 * -1 + -4463 * -1];
    if (UI[gotoNewOfflinePage("0x19c", "8$2U")]([gotoNewOfflinePage("0x500", "^Cpz"), gotoNewOfflinePage("0x8e3", "4*%U"), gotoNewOfflinePage("0x549", "ENd4"), gotoNewOfflinePage("0x4c1", "tbdl")])) {
        Render[gotoNewOfflinePage("0x738", "*TM&")](406 * 16 + -9273 + 2790, _0x4fb764 - (-3 * 169 + 39 * -31 + 2106), 3 * -3187 + 23 * 34 + -1 * -8779, gotoNewOfflinePage("0x2a8", "6y51"), [3757 + 11 * 613 + 420 * -25, -831 * 10 + -5773 + -14083 * -1, 4541 + -2580 + -1961, 13 * 593 + -9007 + -1 * -1423], font);
        Render[gotoNewOfflinePage("0x75d", "R4C(")](6 * 326 + 1186 + 313 * -10, _0x4fb764 - (-7 * -443 + -401 * -21 + 92 * -121), -5596 + 9523 + -3927, gotoNewOfflinePage("0x32", "JG#F"), [-5228 + -6478 + 1322 * 9 - oldCondition * (3679 + 590 * 4 + 8 * -752) / (-4665 * 1 + 219 + 4556), -1295 * 5 + -1985 * -1 + 4522 + oldCondition * (97 * -79 + 7569 + 177) / (-9803 + -2812 + 12725), -567 * -15 + -4682 + 11 * -346, 7352 + 4900 + 11997 * -1], font);
        if (oldCondition > -877 * 1 + 1664 + -1 * 587) {
            oldCondition = 6712 + -20 * -307 + -4 * 3163;
        }
        if (oldCondition < -6347 + -88 * 83 + 13831) {
            Render[gotoNewOfflinePage("0xa7c", "Md]D")](-6336 + 1 * -541 + -10 * -689, _0x4fb764 - (1 * 8651 + 9231 + -17517) - up, -5571 + 5178 + 451, -1 * -4742 + 9127 + -13865, [17 * -305 + 3703 + -1 * -1482, -8616 + 7539 * 1 + -359 * -3, -3 * -2003 + 7607 + -4 * 3404, 2422 + 4473 * -1 + 2201]);
            Render[gotoNewOfflinePage("0xa42", "0jac")](1833 + 1 * 1319 + -3138, _0x4fb764 - (-6922 + -291 * 13 + 11070) - up, oldCondition * (9084 + -6728 + -2355) / (49 * -1 + 3 * -2189 + -1324 * -5) + (-8710 * -1 + 1366 * 7 + -18266 * 1), 1 * -4152 + -8562 + -4 * -3179, [-7835 * -1 + 3508 + -11151 - oldCondition * (1649 * 1 + 9098 + -10724) / (-2443 * 2 + -2 * -1522 + 1952), -40 * -160 + 1056 + -7424 + oldCondition * (71 * -53 + 3846 + 0) / (1 * 4401 + 1 * 7013 + -3 * 3768), -1116 * 8 + -514 * 6 + 12029, -5136 + -548 + 5939]);
        }
        up = 8619 + -7535 * -1 + -6 * 2689;
    }
}
var gun_fired = ![];
var other_weapons = ['knife', 'knife_t', 'knife_karambit', 'knife_m9_bayonet', 'knife_survival_bowie', 'knife_butterfly', 'knife_flip', 'knife_push', 'knife_tactical', 'knife_falchion', 'knife_gut', 'knife_ursus', 'knife_gypsy_jackknife', 'knife_stiletto', 'knife_widowmaker', 'knife_css', 'knife_cord', 'knife_canis', 'knife_outdoor', 'knife_skeleton', 'bayonet', 'hegrenade', 'smokegrenade', 'molotov', 'incgrenade', 'flashbang', 'decoy', 'taser'];
var _0x5e5c9b = {};
_0x5e5c9b.fired = 0, _0x5e5c9b.hit = 0, _0x5e5c9b.missed = 0, _0x5e5c9b.hit_chance = 0, _0x5e5c9b.miss_chance = 0;
var shots = _0x5e5c9b;

function is_gun(canCreateDiscussions) {
    var createBlankString = _0x31205f;
    var i = 5794 * 1 + 1378 + -7172;
    for (; i < other_weapons[createBlankString("0x268", "T*7j")]; i++) {
        if (canCreateDiscussions == createBlankString("0x2db", "JG#F") + other_weapons[i]) {
            return ![];
        }
    }
    return !![];
}

function weapon_fire() {
    var gotoNewOfflinePage = _0x31205f;
    var artistTrack = Event[gotoNewOfflinePage("0x7a5", "Ly5M")](gotoNewOfflinePage("0x6e2", "tbdl"));
    var canCreateDiscussions = Event[gotoNewOfflinePage("0x5b8", "6y51")](gotoNewOfflinePage("0x9fc", "^&*3"));
    if (Entity[gotoNewOfflinePage("0x1fc", "s4OQ")](Entity[gotoNewOfflinePage("0x14d", "*TM&")](artistTrack)) && is_gun(canCreateDiscussions) && Global[gotoNewOfflinePage("0x890", "*TM&")](2513 + -2702 + 1 * 190) == ![] && UI[gotoNewOfflinePage("0x50", "JG#F")]([gotoNewOfflinePage("0x909", "^&*3"), gotoNewOfflinePage("0xa23", "QNb%"), gotoNewOfflinePage("0x17a", "yVP2"), gotoNewOfflinePage("0x445", "4*%U")]) && UI[gotoNewOfflinePage("0xb23", "ZtZ5")]([gotoNewOfflinePage("0x40d", "yVP2"), gotoNewOfflinePage("0xa23", "QNb%"), gotoNewOfflinePage("0x84b", "KA@R"), gotoNewOfflinePage("0xaa4", "!w]r")])) {
        shots[gotoNewOfflinePage("0x4ba", "RpYp")] = shots[gotoNewOfflinePage("0x5e1", "82iA")] + (1647 + 1 * 8539 + -10185);
        gun_fired = !![];
    }
}

function player_hurt() {
    var gotoNewOfflinePage = _0x31205f;
    var artistTrack = Event[gotoNewOfflinePage("0x610", "DtBC")](gotoNewOfflinePage("0x7c6", "WoWH"));
    var canCreateDiscussions = Event[gotoNewOfflinePage("0x8b8", "WoWH")](gotoNewOfflinePage("0x5f7", "UzS9"));
    if (Entity[gotoNewOfflinePage("0x1b", "DtBC")](Entity[gotoNewOfflinePage("0x3ad", "D!Qj")](artistTrack)) && is_gun(canCreateDiscussions) && gun_fired) {
        shots[gotoNewOfflinePage("0x705", "yVP2")] = shots[gotoNewOfflinePage("0x608", "8$2U")] + (-5526 + -7043 + 12570);
        gun_fired = ![];
    }
}

function Hitchance_logger() {
    var gotoNewOfflinePage = _0x31205f;
    g_Local = Entity[gotoNewOfflinePage("0xadb", "i00^")]();
    localplayer_index = Entity[gotoNewOfflinePage("0x65c", "WoWH")]();
    localplayer_alive = Entity[gotoNewOfflinePage("0xad4", "WoWH")](localplayer_index);
    const _0x1422ad = render_get_screen_size()[19 * -469 + -8824 + 4434 * 4];
    font = Render[gotoNewOfflinePage("0x44a", "s(MI")](gotoNewOfflinePage("0x190", "7(LG"), 3437 * 2 + 28 * 287 + -1 * 14894, 9962 + -6599 * -1 + -15861);
    if (localplayer_alive == !![]) {
        if (Global[gotoNewOfflinePage("0x601", "T*7j")]() == "" || !UI[gotoNewOfflinePage("0x7e4", "82iA")]([gotoNewOfflinePage("0xb37", "Ly5M"), gotoNewOfflinePage("0x40", "HY1z"), gotoNewOfflinePage("0x1da", "UzS9"), gotoNewOfflinePage("0x99f", "Ly5M")]) || !UI[gotoNewOfflinePage("0x308", "tySx")]([gotoNewOfflinePage("0x9b4", "tySx"), gotoNewOfflinePage("0x317", "0zlF"), gotoNewOfflinePage("0x1d0", "^Cpz"), gotoNewOfflinePage("0x8dd", "R#3P")]) && localplayer_alive == !![]) {
            return;
        }
        shots[gotoNewOfflinePage("0x717", "M]md")] = shots[gotoNewOfflinePage("0x6ac", "]#PJ")] - shots[gotoNewOfflinePage("0xa1d", "*TM&")];
        shots[gotoNewOfflinePage("0x5ab", "^Cpz")] = shots[gotoNewOfflinePage("0x2a3", "*f)e")] / shots[gotoNewOfflinePage("0x60a", "x65P")] * (-7253 + 8450 + -1097);
        shots[gotoNewOfflinePage("0x7b9", "UzS9")] = shots[gotoNewOfflinePage("0x5e6", "T*7j")] / shots[gotoNewOfflinePage("0x818", "@zrZ")] * (1768 + -1672 + 4);
        Render[gotoNewOfflinePage("0x65d", "AMGA")](-811 * 6 + -1810 + 6689, _0x1422ad - (-9439 * 1 + -82 * -64 + -4741 * -1), 2283 * 4 + 863 + -5 * 1999, gotoNewOfflinePage("0x1d5", "s4OQ") + shots[gotoNewOfflinePage("0xabb", "WoWH")], [3199 * -2 + 239 * -20 + -162 * -69, 4184 + 1 * 9442 + -6 * 2271, -3376 + 9239 * -1 + 12615, -121 * 9 + -1 * 8923 + 10267 * 1], font);
        Render[gotoNewOfflinePage("0x4a4", "0jac")](-3011 + -8852 + -2 * -5938, _0x1422ad - (-2 * 2257 + -4126 * 1 + 9160), -3360 + 3187 + -1 * -173, gotoNewOfflinePage("0x798", "tbdl") + shots[gotoNewOfflinePage("0x9bc", "^&*3")], [7180 + 3899 + -11079, 7035 + 1 * -2362 + -4673, 3677 + -7143 + 1 * 3466, 3 * -3327 + -194 + -10 * -1043], font);
        Render[gotoNewOfflinePage("0xb9", "x65P")](-36 * 70 + 9601 + -7069, _0x1422ad - (-6852 + 7773 + -371), -9585 + -3458 + -13043 * -1, gotoNewOfflinePage("0x1d5", "s4OQ") + shots[gotoNewOfflinePage("0x4e0", "]#PJ")], [4709 + 1 * 4843 + -9 * 1033, -331 * -3 + 3896 + -4634 * 1, -325 * 4 + 1 * -4919 + 6474, 5273 + -1462 * -2 + 38 * -209], font);
        Render[gotoNewOfflinePage("0x929", "JG#F")](2 * -4819 + 3 * 1599 + 1 * 4853, _0x1422ad - (-41 * 142 + -3167 * -2 + 8), -9711 + -4 * 718 + 1 * 12583, gotoNewOfflinePage("0x8b9", "RpYp") + shots[gotoNewOfflinePage("0x7ab", "D!Qj")], [6644 + 9924 + 1 * -16313, 1 * 8873 + -8497 + -121, 3157 + 1 * -6577 + 3675, -3779 + -2 * 3869 + 11772], font);
        if (shots[gotoNewOfflinePage("0x79", "hs0[")] > 4229 + -1288 + 1 * -2941) {
            Render[gotoNewOfflinePage("0x929", "JG#F")](2311 * 1 + -1 * -559 + -2857, _0x1422ad - (4564 + -3 * -1941 + 1 * -9897), -5029 + 4315 * 2 + -3601, shots[gotoNewOfflinePage("0x8cb", "3e5%")] + gotoNewOfflinePage("0x195", "]#PJ") + shots[gotoNewOfflinePage("0x5e1", "82iA")] + gotoNewOfflinePage("0xb03", "7(LG") + Math[gotoNewOfflinePage("0x633", "JG#F")](shots[gotoNewOfflinePage("0xb34", "7(LG")]) + "%", [-546 * -8 + -6013 + -35 * -47, 753 + 8817 + -9570, -3399 * -1 + -7002 + -3603 * -1, 1 * 2942 + -22 * -211 + -7329], font);
            Render[gotoNewOfflinePage("0x1ca", "s(MI")](-5675 + 3634 * -2 + 12956, _0x1422ad - (-3498 * -2 + -2634 + 3902 * -1), -9607 + -9266 + -18873 * -1, shots[gotoNewOfflinePage("0x38a", "^&*3")] + gotoNewOfflinePage("0x244", "R#3P") + shots[gotoNewOfflinePage("0x12d", "8$2U")] + gotoNewOfflinePage("0x6af", "s4OQ") + Math[gotoNewOfflinePage("0x633", "JG#F")](shots[gotoNewOfflinePage("0x521", "AMGA")]) + "%", [4783 * -1 + 5655 + 872 * -1, 5020 + 3394 * -1 + -1 * 1626, 7600 + 3873 + 1639 * -7, 2859 + -5049 * -1 + 7653 * -1], font);
            Render[gotoNewOfflinePage("0x85b", "hs0[")](-5968 + -5653 * 1 + 11633 * 1, _0x1422ad - (-8245 + 241 * 1 + -8494 * -1), 3271 * -1 + 2237 * 1 + 94 * 11, shots[gotoNewOfflinePage("0x894", "4*%U")] + gotoNewOfflinePage("0x1af", "!q5U") + shots[gotoNewOfflinePage("0xb13", "R#3P")] + gotoNewOfflinePage("0x4c", "D!Qj") + Math[gotoNewOfflinePage("0x633", "JG#F")](shots[gotoNewOfflinePage("0x25e", "s(MI")]) + "%", [199 * -31 + -7368 + 13792, -52 * -7 + -5235 + 5126, 6429 * 1 + 1512 + -7686, 43 * 211 + -1255 + 7563 * -1], font);
            Render[gotoNewOfflinePage("0x746", "T*7j")](-7683 * 1 + 2654 + 5041, _0x1422ad - (3135 * 1 + 5807 + -8482), 7267 + -803 * 7 + -1646, shots[gotoNewOfflinePage("0x9ef", "UzS9")] + gotoNewOfflinePage("0x478", "6y51") + shots[gotoNewOfflinePage("0x79", "hs0[")] + gotoNewOfflinePage("0x58", "i00^") + Math[gotoNewOfflinePage("0x467", "3e5%")](shots[gotoNewOfflinePage("0x351", "HY1z")]) + "%", [10 * 417 + 1 * -2875 + 26 * -40, -43 * -41 + -4274 + 2766, -52 * -43 + -7401 + 5420, 7571 + -274 * 3 + -6494], font);
        } else {
            if (shots[gotoNewOfflinePage("0x1ba", "!w]r")] < -1392 * 6 + -4379 + 12732) {
                Render[gotoNewOfflinePage("0xaa0", "]C]N")](-4209 + 1594 * 5 + -3748, _0x1422ad - (-8724 + 7348 + 3 * 622), 1 * 2957 + -3557 + 600, shots[gotoNewOfflinePage("0x429", "R4C(")] + gotoNewOfflinePage("0xa0f", "*TM&") + shots[gotoNewOfflinePage("0x579", "T*7j")] + gotoNewOfflinePage("0x4f", "JG#F") + (-1 * 7642 + 257 * 8 + 5586) + "%", [-634 + 7092 + -2 * 3229, 1 * -8543 + -3617 + 12160, 752 * -1 + -9551 + -10303 * -1, 128 * -14 + 7106 + -5059], font);
                Render[gotoNewOfflinePage("0x929", "JG#F")](3 * 1693 + 63 * -47 + -2105, _0x1422ad - (-8777 * -1 + 5587 * -1 + -15 * 182), -275 * -17 + 9368 + 14043 * -1, shots[gotoNewOfflinePage("0x2f", "AMGA")] + gotoNewOfflinePage("0x9dc", "HY1z") + shots[gotoNewOfflinePage("0x3e7", "ZtZ5")] + gotoNewOfflinePage("0xb7", "Ly5M") + (501 * 9 + -5923 + -202 * -7) + "%", [-975 * -5 + 1 * -4798 + 7 * -11, -2088 * -4 + 5 * 454 + -10622, -6385 + 8 * -502 + -10401 * -1, 32 * -223 + -4940 + 12331], font);
                Render[gotoNewOfflinePage("0x406", "M]md")](1 * -1424 + -17 * -1 + 1419, _0x1422ad - (-1 * 6335 + 3133 + 3692), -9620 + -545 + 10165, shots[gotoNewOfflinePage("0x196", "ZtZ5")] + gotoNewOfflinePage("0xab6", "s(MI") + shots[gotoNewOfflinePage("0x12d", "8$2U")] + gotoNewOfflinePage("0x880", "KA@R") + (4415 * 1 + -6296 * -1 + -10711) + "%", [103 * -45 + -6631 + 11521, -6959 * -1 + -4072 * 1 + 329 * -8, -1453 * -3 + 49 * 203 + -14051, -757 + -1 * -5777 + -4765], font);
                Render[gotoNewOfflinePage("0x9e4", "^&*3")](2 * -4134 + 3730 + 10 * 455, _0x1422ad - (2126 * 3 + -4225 + -1693), 5761 + 443 * -14 + 441, shots[gotoNewOfflinePage("0x722", "4*%U")] + gotoNewOfflinePage("0x996", "DtBC") + shots[gotoNewOfflinePage("0xb14", "3e5%")] + gotoNewOfflinePage("0x864", "]#PJ") + (6352 + -3987 + 11 * -215) + "%", [4875 + -2807 + -1813, -6038 + -2586 * -2 + 1121, 253 * 7 + -31 * -18 + -2074, -3 * -281 + -602 + 14 * 1], font);
            }
        }
    }
}

function AdaptiveScopeDist() {
    var gotoNewOfflinePage = _0x31205f;
    localplayer_index = Entity[gotoNewOfflinePage("0xa21", "*f)e")]();
    weapon_name = Entity[gotoNewOfflinePage("0xa3d", "!w]r")](Entity[gotoNewOfflinePage("0x6b4", "KA@R")](Entity[gotoNewOfflinePage("0x989", "7(LG")]()));
    var artistTrack = Entity[gotoNewOfflinePage("0x4fc", "]#PJ")](Entity[gotoNewOfflinePage("0x260", "0jac")](Entity[gotoNewOfflinePage("0x6b8", "4jWr")]()));
    if (UI[gotoNewOfflinePage("0x6da", "WoWH")]([gotoNewOfflinePage("0x40d", "yVP2"), gotoNewOfflinePage("0x8d3", "RpYp"), gotoNewOfflinePage("0x650", "AMGA"), gotoNewOfflinePage("0x713", "%#fz")])) {
        const _0x1a5749 = UI[gotoNewOfflinePage("0x49a", "]C]N")]([gotoNewOfflinePage("0x791", "s(MI"), gotoNewOfflinePage("0x4f6", "6y51"), gotoNewOfflinePage("0x4f6", "6y51"), gotoNewOfflinePage("0xa0a", "D!Qj")]);
        const _0x318a4d = UI[gotoNewOfflinePage("0x65a", "yVP2")]([gotoNewOfflinePage("0x50d", "AMGA"), gotoNewOfflinePage("0x18f", "KA@R"), gotoNewOfflinePage("0xa84", "tbdl"), gotoNewOfflinePage("0x87a", "RrDx")]);
        const _0x33a94d = UI[gotoNewOfflinePage("0x7e4", "82iA")]([gotoNewOfflinePage("0x791", "s(MI"), gotoNewOfflinePage("0x3cb", "^&*3"), gotoNewOfflinePage("0x4f6", "6y51"), gotoNewOfflinePage("0x856", "ENd4")]);
        if (!Ragebot[gotoNewOfflinePage("0x79d", "0jac")]()) {
            target = closestTarget();
        } else {
            target = Ragebot[gotoNewOfflinePage("0x1ce", "]#PJ")]();
        }
        if (weaponTabNames[gotoNewOfflinePage("0x5e4", "%#fz")](artistTrack)) {
            if (!Entity[gotoNewOfflinePage("0xa3b", "^&*3")](target)) {
                UI[gotoNewOfflinePage("0x2ef", "HY1z")]([gotoNewOfflinePage("0x759", "s(MI"), gotoNewOfflinePage("0x162", "*TM&"), gotoNewOfflinePage("0xae4", "82iA"), gotoNewOfflinePage("0x73c", "89dW")], -1128 + 4011 + -2882);
                UI[gotoNewOfflinePage("0x25f", "8$2U")]([gotoNewOfflinePage("0x22c", "6y51"), gotoNewOfflinePage("0x927", "0jac"), gotoNewOfflinePage("0x575", "]C]N"), gotoNewOfflinePage("0x5a6", "tbdl")], -24 * 25 + -2519 + 260 * 12);
                UI[gotoNewOfflinePage("0x5e", "@zrZ")]([gotoNewOfflinePage("0x5b3", "M]md"), gotoNewOfflinePage("0x523", "hs0["), gotoNewOfflinePage("0x26c", "Md]D"), gotoNewOfflinePage("0xb5", "3e5%")], -4244 + 1474 + 2771);
                UI[gotoNewOfflinePage("0x973", "89dW")]([gotoNewOfflinePage("0x3f7", "x65P"), gotoNewOfflinePage("0x8a", "WoWH"), gotoNewOfflinePage("0x5cc", "0zlF"), gotoNewOfflinePage("0x51", "x65P")], -1935 * 5 + 1777 * 2 + 6122);
                return;
            }
        }
        if (isAutoSniper(weapon_name)) {
            if (_0x1a5749 & 20 * 366 + -4950 + -2369 << 5628 + -4179 + -483 * 3) {
                if (get_metric_distance(Entity[gotoNewOfflinePage("0x2cb", "7(LG")](Entity[gotoNewOfflinePage("0x83", "]C]N")]()), Entity[gotoNewOfflinePage("0x3b2", "R4C(")](target)) < UI[gotoNewOfflinePage("0x6eb", "7(LG")]([gotoNewOfflinePage("0x909", "^&*3"), gotoNewOfflinePage("0x69", "x65P"), gotoNewOfflinePage("0x81e", "Md]D"), gotoNewOfflinePage("0x48", "82iA")])) {
                    UI[gotoNewOfflinePage("0x857", "4*%U")]([gotoNewOfflinePage("0x930", "4*%U"), gotoNewOfflinePage("0x462", "!q5U"), gotoNewOfflinePage("0x16a", "RrDx"), gotoNewOfflinePage("0x94a", "DtBC")], 8629 * -1 + 2521 * -1 + 11150);
                    UI[gotoNewOfflinePage("0x84f", "*TM&")]([gotoNewOfflinePage("0xafd", "QNb%"), gotoNewOfflinePage("0x55f", "3e5%"), gotoNewOfflinePage("0xa71", "0jac"), gotoNewOfflinePage("0x51", "x65P")], -689 + 2 * 1017 + -1345);
                }
            }
            if (_0x1a5749 & 9831 + -2 * -3739 + -4 * 4327 << -2554 + 7476 + -703 * 7) {
                if (in_air(localplayer_index) == !![]) {
                    UI[gotoNewOfflinePage("0x919", "%#fz")]([gotoNewOfflinePage("0x85e", "HY1z"), gotoNewOfflinePage("0x886", "M]md"), gotoNewOfflinePage("0x64c", "6y51"), gotoNewOfflinePage("0x222", "i00^")], 2963 + -1 * 2617 + -345);
                    UI[gotoNewOfflinePage("0xb5c", "]C]N")]([gotoNewOfflinePage("0x29e", "RrDx"), gotoNewOfflinePage("0x4f5", "R4C("), gotoNewOfflinePage("0x62", "fOHz"), gotoNewOfflinePage("0xb5", "3e5%")], -1552 * -3 + 1 * 8203 + -12858);
                }
            }
        }
        if (weapon_name == gotoNewOfflinePage("0x907", "89dW")) {
            if (_0x318a4d & -1 * -5831 + 5914 + -367 * 32 << -7684 + -1 * 9213 + 277 * 61) {
                if (get_metric_distance(Entity[gotoNewOfflinePage("0x3c6", "Ly5M")](Entity[gotoNewOfflinePage("0x6bf", "*TM&")]()), Entity[gotoNewOfflinePage("0x484", "Md]D")](target)) < UI[gotoNewOfflinePage("0x8d1", "*f)e")]([gotoNewOfflinePage("0xa65", "*f)e"), gotoNewOfflinePage("0x8d3", "RpYp"), gotoNewOfflinePage("0x4e6", "9U5N"), gotoNewOfflinePage("0xa79", "6y51")])) {
                    UI[gotoNewOfflinePage("0xb1d", "3e5%")]([gotoNewOfflinePage("0x204", "i00^"), gotoNewOfflinePage("0x286", "HY1z"), gotoNewOfflinePage("0x99c", "tbdl"), gotoNewOfflinePage("0x946", "!w]r")], -1439 * 5 + -9 * 661 + -62 * -212);
                }
            }
            if (_0x318a4d & -22 * 59 + 1 * 7934 + -6635 << -2794 + -6526 + -3 * -3107) {
                if (in_air(localplayer_index) == !![]) {
                    UI[gotoNewOfflinePage("0x43a", "82iA")]([gotoNewOfflinePage("0x5b3", "M]md"), gotoNewOfflinePage("0x1c3", "ENd4"), gotoNewOfflinePage("0x26c", "Md]D"), gotoNewOfflinePage("0x148", "RpYp")], 1985 * -1 + 4311 + -93 * 25);
                }
            }
        }
        if (weapon_name == gotoNewOfflinePage("0x137", "AMGA")) {
            if (_0x33a94d & -3 * -901 + 88 + -2790 << 8009 + -2425 * 3 + 2 * -367) {
                if (get_metric_distance(Entity[gotoNewOfflinePage("0x4ae", "8$2U")](Entity[gotoNewOfflinePage("0xb4d", "^Cpz")]()), Entity[gotoNewOfflinePage("0x218", "89dW")](target)) < UI[gotoNewOfflinePage("0xa08", "3e5%")]([gotoNewOfflinePage("0xb10", "tbdl"), gotoNewOfflinePage("0x5e0", "]C]N"), gotoNewOfflinePage("0x3f", "s4OQ"), gotoNewOfflinePage("0x6f9", "JG#F")])) {
                    UI[gotoNewOfflinePage("0x919", "%#fz")]([gotoNewOfflinePage("0x5b3", "M]md"), gotoNewOfflinePage("0x49d", "DtBC"), gotoNewOfflinePage("0xb4f", "KA@R"), gotoNewOfflinePage("0x2b1", "9U5N")], -5848 + -3950 + -142 * -69);
                }
            }
            if (_0x33a94d & -3 * 1447 + -4865 * 1 + 837 * 11 << -1115 + 5 * 1578 + -6774) {
                if (in_air(localplayer_index) == !![]) {
                    UI[gotoNewOfflinePage("0x26b", "7(LG")]([gotoNewOfflinePage("0x321", "AMGA"), gotoNewOfflinePage("0x55f", "3e5%"), gotoNewOfflinePage("0x550", "RrDx"), gotoNewOfflinePage("0x73c", "89dW")], 438 * 10 + 9253 + 4544 * -3);
                }
            }
        }
    }
}

function closestTarget() {
    var now = _0x31205f;
    var artistTrack = Entity[now("0x52", "6y51")]();
    var attsByName = Entity[now("0x3f6", "s4OQ")]();
    var rpm_traffic = [];
    var _0x4dce7d = [];
    for (e in attsByName) {
        if (!Entity[now("0xa6e", "!w]r")](attsByName[e]) || Entity[now("0x653", "yVP2")](attsByName[e]) || !Entity[now("0xa74", "T*7j")](attsByName[e])) {
            continue;
        }
        rpm_traffic[now("0x3e0", "ENd4")]([attsByName[e], calcDist(Entity[now("0x1fe", "!q5U")](artistTrack, -6293 + -1 * 7769 + 14062), Entity[now("0x498", "^&*3")](attsByName[e], 8504 + 1 * -4537 + -3967))]);
    }
    rpm_traffic[now("0x6bb", "8$2U")](function(subtractor, subtractee) {
        return subtractor[3 * -2409 + -1 * -5691 + 1537] - subtractee[-3 * 913 + -3924 + 6664];
    });
    if (rpm_traffic[now("0x3c1", "fOHz")] == 1 * 9890 + 3 * -85 + 1 * -9635 || rpm_traffic == []) {
        return target = -(5075 + -4114 + 15 * -64);
    }
    return rpm_traffic[-3 * -3293 + -4241 + -5638][-2660 + -637 * -15 + -6895];
}

function calcDist(subtractor, subtractee) {
    var gotoNewOfflinePage = _0x31205f;
    return x = subtractor[-1 * 2999 + -34 + -1 * -3033] - subtractee[-1654 * -5 + 162 + -272 * 31], y = subtractor[1270 + 5878 + -7147] - subtractee[2 * -4915 + 1 * -6541 + -4093 * -4], z = subtractor[-4790 * -2 + -7159 * -1 + -21 * 797] - subtractee[1 * 5570 + -4816 + -752], Math[gotoNewOfflinePage("0x68d", "9U5N")](x * x + y * y + z * z);
}

function GetTickbaseH9() {
    var gotoNewOfflinePage = _0x31205f;
    g_Local = Entity[gotoNewOfflinePage("0xa90", "UzS9")]();
    localplayer_index = Entity[gotoNewOfflinePage("0xadb", "i00^")]();
    localplayer_alive = Entity[gotoNewOfflinePage("0x1e0", "^Cpz")](localplayer_index);
    isDoubletap = UI[gotoNewOfflinePage("0x1ec", "HY1z")](gotoNewOfflinePage("0x321", "AMGA"), gotoNewOfflinePage("0x873", "bORa"), gotoNewOfflinePage("0xa0", "@zrZ"), gotoNewOfflinePage("0x5c4", "0jac"));
    isInverted = UI[gotoNewOfflinePage("0x77f", "JG#F")](gotoNewOfflinePage("0x5b1", "M]md"), gotoNewOfflinePage("0x3b6", "bORa"), gotoNewOfflinePage("0xa3", "4jWr"));
    isHideReal = UI[gotoNewOfflinePage("0x7e4", "82iA")](gotoNewOfflinePage("0x609", "Md]D"), gotoNewOfflinePage("0x314", "Ly5M"), gotoNewOfflinePage("0x1cc", "!w]r"));
    isHideShots = UI[gotoNewOfflinePage("0x2d4", "T*7j")](gotoNewOfflinePage("0xaba", "!w]r"), gotoNewOfflinePage("0x71d", "]#PJ"), gotoNewOfflinePage("0x3df", "8$2U"), gotoNewOfflinePage("0x63e", "8$2U"));
    isMagicKey = UI[gotoNewOfflinePage("0xa3e", "RpYp")](gotoNewOfflinePage("0x2eb", "^Cpz"), gotoNewOfflinePage("0x85a", "^Cpz"), gotoNewOfflinePage("0x2ed", "R4C("), gotoNewOfflinePage("0x1f9", "^&*3"));
    isFreestand = UI[gotoNewOfflinePage("0x651", "%#fz")](gotoNewOfflinePage("0xadc", "]#PJ"), gotoNewOfflinePage("0x7f0", "s4OQ"), gotoNewOfflinePage("0x900", "QNb%"), gotoNewOfflinePage("0xae3", "Ly5M"));
    isFakeDuck = UI[gotoNewOfflinePage("0x99", "89dW")](gotoNewOfflinePage("0xfb", "hs0["), gotoNewOfflinePage("0x79b", "s4OQ"), gotoNewOfflinePage("0x2f2", "QNb%"));
    isIndicators = UI[gotoNewOfflinePage("0x346", "UzS9")](gotoNewOfflinePage("0xb1c", "x65P"), gotoNewOfflinePage("0x42e", "89dW"), gotoNewOfflinePage("0x867", "D!Qj"), gotoNewOfflinePage("0x3f9", "Md]D"));
    isSyncFake = UI[gotoNewOfflinePage("0x186", "0zlF")](gotoNewOfflinePage("0x7d4", "yVP2"), gotoNewOfflinePage("0x4ec", "Md]D"), gotoNewOfflinePage("0x5ce", "T*7j"), gotoNewOfflinePage("0x45", "hs0["));
    isResetFake = UI[gotoNewOfflinePage("0x882", "KA@R")](gotoNewOfflinePage("0x925", "s4OQ"), gotoNewOfflinePage("0x5c8", "6y51"), gotoNewOfflinePage("0x66", "3e5%"), gotoNewOfflinePage("0x5ef", "JG#F"));
    isIndFb = UI[gotoNewOfflinePage("0xa3e", "RpYp")](gotoNewOfflinePage("0xa6c", "^&*3"), gotoNewOfflinePage("0x71d", "]#PJ"), gotoNewOfflinePage("0xb0b", "x65P"), gotoNewOfflinePage("0x495", "R4C("));
    isIndSp = UI[gotoNewOfflinePage("0xa30", "bORa")](gotoNewOfflinePage("0x13c", "0zlF"), gotoNewOfflinePage("0x645", "AMGA"), gotoNewOfflinePage("0x51b", "4jWr"), gotoNewOfflinePage("0x8de", "89dW"));
    isIndLag = UI[gotoNewOfflinePage("0xae6", "DtBC")](gotoNewOfflinePage("0x95", "DtBC"), gotoNewOfflinePage("0x98a", "Md]D"), gotoNewOfflinePage("0x596", "T*7j"));
    isIndAwall_auto = UI[gotoNewOfflinePage("0x4fb", "hs0[")](gotoNewOfflinePage("0x243", "yVP2"), gotoNewOfflinePage("0x6a3", "T*7j"), gotoNewOfflinePage("0x896", "T*7j"), gotoNewOfflinePage("0x8ff", "!q5U")) == 1678 * -1 + -1019 * -2 + -360 * 1;
    isPing = UI[gotoNewOfflinePage("0xa2e", "4*%U")](gotoNewOfflinePage("0x239", "bORa"), gotoNewOfflinePage("0x40e", "4*%U"), gotoNewOfflinePage("0x3ac", "]#PJ"), gotoNewOfflinePage("0x902", "DtBC"));
    render_get_screen_size = Render[gotoNewOfflinePage("0x5ee", "tySx")];
}
Cheat.RegisterCallback('CreateMove', 'Autostrafe'), Global.RegisterCallback('Draw', 'SetEnabled'), Cheat.RegisterCallback('CreateMove', 'PingSpike'), Cheat.RegisterCallback('CreateMove', 'BetterOnshot'), Cheat.RegisterCallback('CreateMove', 'onCM'), Cheat.RegisterCallback('CreateMove', 'MultipointonCM'), Cheat.RegisterCallback('CreateMove', 'HitchanceCM'), Cheat.RegisterCallback('Draw', 'indicator'), Global.RegisterCallback('Draw', 'drawString'), Cheat.RegisterCallback('Draw', 'me_Alive'), Cheat.RegisterCallback('CreateMove', '_TBC_CREATE_MOVE'), Cheat.RegisterCallback('Unload', '_TBC_UNLOAD'), Global.RegisterCallback('CreateMove', 'Vektor_1'), Cheat.RegisterCallback('CreateMove', 'ForceHeadAim'), Cheat.RegisterCallback('CreateMove', 'ForceHeadAim1'), Cheat.RegisterCallback('CreateMove', 'EarlyMode'), Cheat.RegisterCallback('CreateMove', 'PreferBaim_Safepoint'), Cheat.RegisterCallback('Draw', 'PingIndicator'), Global.RegisterCallback('weapon_fire', 'weapon_fire'), Global.RegisterCallback('player_hurt', 'player_hurt'), Global.RegisterCallback('Draw', 'Hitchance_logger'), Cheat.RegisterCallback('CreateMove', 'AdaptiveScopeDist');