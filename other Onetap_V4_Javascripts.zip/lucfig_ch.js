var screen_size = Render.GetScreenSize();

UI.AddSubTab(["Misc.", "SUBTAB_MGR"], "Custom scope");
UI.AddCheckbox(["Misc.", "Custom scope", "Custom scope"], "Custom scope crosshair");
UI.AddColorPicker(["Misc.", "Custom scope", "Custom scope"], "Color 1");
UI.AddColorPicker(["Misc.", "Custom scope", "Custom scope"], "Color 2");
UI.AddSliderInt(["Misc.", "Custom scope", "Custom scope"], "Width", 1, 10);

function draw()
{
    local = Entity.GetLocalPlayer();
    if (!Entity.IsValid(local) || !Entity.IsAlive(local)) return;
    scope_enb = UI.GetValue(["Misc.", "Custom scope", "Custom scope", "Custom scope crosshair"]);
    scope_width = UI.GetValue(["Misc.", "Custom scope", "Custom scope", "Width"]);
    UI.SetEnabled(["Misc.", "Custom scope", "Custom scope", "Color 1"], scope_enb);
    UI.SetEnabled(["Misc.", "Custom scope", "Custom scope", "Color 2"], scope_enb);
    UI.SetEnabled(["Misc.", "Custom scope", "Custom scope", "Width"], scope_enb);

    if (UI.GetValue(["Misc.", "Custom scope", "Custom scope", "Custom scope crosshair"]))
    {
        col1 = UI.GetColor(["Misc.", "Custom scope", "Custom scope", "Color 1"]);
        col2 = UI.GetColor(["Misc.", "Custom scope", "Custom scope", "Color 2"]);

        if (is_scoped = Entity.GetProp(local, "CCSPlayer", "m_bIsScoped"))
        {
            Render.GradientRect(screen_size[0] / 2 - (scope_width / 2) + 1, screen_size[1] / 2, scope_width, screen_size[1] / 2, 0, col1, col2);
            Render.GradientRect(screen_size[0] / 2 - (scope_width / 2) + 1, 0, scope_width, screen_size[1] / 2, 0, col2, col1);

            Render.GradientRect(screen_size[0] / 2, screen_size[1] / 2, screen_size[0] / 2, scope_width, 1, col1, col2);
            Render.GradientRect(0, screen_size[1] / 2, screen_size[0] / 2, scope_width, 1, col2, col1);
        }
    }
}

Cheat.RegisterCallback("Draw", "draw");