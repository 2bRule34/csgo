var _0x39cf=['hfFdRSopr03cItfRhSoB','DmkGW63dVmkWW4e=','kfdcHmokl8kjW4RcJSo2WPJdLq==','W7dcH8kXvCo5umoxfmkWrbS=','bMtdKmkWWO4BW7GXWRJcL8kF','esVdPSk6sZlcJ0bLACoA','sY3cJ8kzqvS5FM1KWP4=','W54xWQ1MnZtcVmk+WR3dTSkn','y1CLkmoZWOD7W4mDW7xcIG==','DCoEWPNdS8kWWRpdSczia8ke','W6hdOSolWPFcOCkap8kEnLJdUG==','WO0JhSoLW5CNrSoKfSkHW6O=','pL5NzfVcJ8kHWO5QWO1L','CgxdM8olW7iAW7nfW4FcN8kA','o8kZoGL6iZJcGISzwG==','scVcJSkzsv8+CgHQWPS=','WQNcHZLOACk6WRyxwSk5lq==','kf3dS8k3kCkaWRtdT8o8WPlcPG==','WOVdOCkfW64MW5pdKmoeW6ndW7y=','BSktoSoNWOhcMc7cHLNcQSkO','ebTGWPtdQcNdS8ohWRBdL8kb','WRLHW5FcQ8o2W6NcRG9kWOVdMa==','WO8MoNpdMZ7cGajEeSo7','AMldPmo9W7zDmCkLW5q3nG==','W5mnW6pdKu7dOSouWRGCoKm=','WQZcGtTOA8k6WRyuvCk7ka==','rSkgCCoToW==','DmoRW5NcKCoWWQHSn2BdKSkp','WRVdGYHoWPVcTuZcVmk+c3q=','iCkYemkovCoxw0rTWPRcHW==','W5SfAbFdTxddKtBdQ8ojW4S=','WPBcNSokWPldLmo9nCkAqYldSa==','W7iVoqRcRJxcJhqUgmo+','W6dcJCkSymoWDSkpbuFdMqu=','sY3dUSoKsv5pc2LMW68=','W4pdUSkGW53cQSkwW5/dTmksWQ5r','WQWjAwdcGhhdMKFcL8oaW4y=','W5OWo8oTWPD7WO3cPhnEWOS=','WQe1qmoLW6r1W7JcPWLDW7y=','W5bLWQasmeJcTmonWRhcICkp','q8khW6xdU8oqW7ldLCoDW5VcVmkV','W4VdU8onsLO1W6RdR8o1WPNcGa==','WRrtWPfPWRddNJygsCkQta==','t19Hfs3cJSkQW7SwWODH','t8k/saumjeJcIfGrka==','W6xcLmofW6dcRmo0m8oQnINdSG==','WQSzWQuwqZxcU8omW4FdT8kk','aMldOcdcRgz/omoxrmkg','W6VcLColW6dcRCo8n8oUnYpdUG==','W57cGKHSgSkYW4qAj8kXxa==','W4n3vYDWW6ddUaVdRIvR','m8ohWO9EnwvMW5BdTmoqza==','pYjLe1ZdSmkHW7LHW7LR','t8kZtWOljK3cIf0xlq==','WRlcVLzlWPNdGdZcS8k0FWq=','W5SiW6ldL0ldPCouWRCEoum=','gbRdRCoWWOOVpCkGWQPcoG==','nKxcGSknlLVdGCkjW5xcOcK=','W5SMmCkhW5PEAZCbWPG=','tComug1gWRTqWRmgi8oH','WPFcNSokWPldLSoWmCkArsldSW==','W53dVeVdTsRcOSo/gGtcJCoB','WPlcNSocWPBdLmoZnCkEqIpdSW==','W54sW5yCmtxdJ8olWRZdT8o/','WQy4qmoLW6f1W7/cPq9FW7K=','WRLyWPDOWRddNJ4gsmkVqG==','W6vIpCoxmry4rxNdPmoj','WRtdMSkjp8kohCkmW4qEFSoe','W4VdU8k4oLSZWPRcL8o9WPNdTW==','WOmJtaRdMJxdSN5Ffmkp','WQBcJKhdSf/dMmoWfNxdS8ou','p3rjq2ddU8oNWQqHxfe=','dCk4W7KitG==','WQC2tCoJW6v6W7hcQqXsW74=','ESovW6pcISk1WRpcHL1daSo1','j8ohymkoxmkMlKvPW67dVa==','qCojlb1bWRqIW4Chk8kv','W4RdVmk6pLSYWPZcKmo9WPZdUq==','W5q0p8oGWP59WO7cPNHyWOK=','W7lcRHFcOb/dSG==','WQmngHVcGNZcPd7cMmofWRa=','WPBdUSkSyCkkc8kedtpcQWa=','W4tdLmo/p8o6eCo6W4PVCSk2','W7aVpadcRZxcH3yTgmo/','WORcK8oWW6qKWQdcRmomW6C0WOq=','BgxdQSoYW7HypmkGW5OYoq==','DmkEW5NdP8oYW5PSsMJcOCkf','WRKUWP0DWRRcOJzXsmoFta==','WQ0rWRFdQSk5W7BcIG/dVmkTWR4=','uSoTW51Qf8oSm2hcSSkmW6K=','WQSaCmo6WQe=','W4ddNmo9p8o+hCo7W4PLCSkY','xmoPW5PLeSoUm2ZcSSkiW6S=','W6VcLCodW6hcOSo8p8oSnspdSG==','BgxdQSoYW7HypSkGW54YnG==','uCojhmkpkCkLwKCFW6dcHG==','n23cUmkxWQW=','W4NcImkUWQNcPmoKW5hcH8ksW5Lx','cCoUW5BdQmkcWQjMrrBdKCke','W7JdO8oYW6brW53cPSonWPbjWOe=','WRCVWPmzWR7cPdzXqmoDqG==','tCofkXncWRyJW4qmjCku','sIVcICkzsvC6CgzIWP4=','sCkgWPBcHCorW77cPCkMW5RcSmoB','m8knWPtdSCkHW7lcQSoDWQ7cS8ou','WQ1HWRFcMSk4WO7cGNVdSSoyWRa=','WOeQWP/dTmo+W4GLWR/dVLHd','WOldTmk6wmkpiSoDg8omnbG=','kLZcHSohjCkjW43cGCo0WPJdKG==','WRhcSfrfWPZdGJVcVCkYEWq=','W6nIpCornru5qh/dOCoh','zmkxs8kCWO3cNvddU1RcOCos','ECoSWQtdQmoXWQmrs2FdKmo/','rhTmnr3dSmoOW5rAxvW=','pvvLyLJcG8kHWOPLWOTL','W7rEWPddTSkjWRuVWR7cIsrc','rCoXWPddSCorWONcQSouW5JdGmoB','pLmqh1NcJSoDW7nKWOSv','W7FcICk2v8o9uCoueSk3sXW=','cCoGW5JdQmkaWQjKqrBdNmke','W4VdU8omsvu3W67dO8oZWPNcHq==','q8ofkHnkWROKW4Spk8kt','WRePWP0CWRdcOtz7smoyta==','WQBcJ0/dSfpdN8oXeNhdTmou','zCkrtmkCWORcN1xdTvZcPCow','FmkzW5BdQCo+W51HsMdcP8kk','bXBdMSokWOjSW7jmWRNdPmky','qCk8WObvqHTPW5pcISkQAq==','W5avWQvMoJ7cTmk5WR3dVCkl','emkzpmkwW7NcKcBdSsJcQ8kN','WQj/zXxcHqNdMJxcL8k1W4O=','nu/cNCo5WQDpWQRdNmowhSkM','oKtdT8o+i1VcSSo0W5pcQva=','W6CRWQidWPaEi38EWRlcPa==','WQH5zXdcJWVdLZ/cL8k0W4S=','emkyomkwW7NcKsxdUYZcPSkP','WPhdUCkJy8kmc8kpbZFcPqO=','WQbKWR3cMCk6WOhcGhRdVmoDWR4=','WQxcJeOCymk4W4fNw8k7xq==','W6CEid3cImkrW7xcMeWUca==','DmoRW5NcLSo+WQjSmMNdLmkp','W7mNW6ldVmkmW4bxWRFcHfG2','W5miW6pdKu7dPCozWRWCoum=','W5u2pmoTWP51WONcQxnAWO4=','x1ZdSCoexCkbWR/cJSkdWPxcQq==','uXjWCCoc','mmknWP/dS8kLW7/cQSoDWQ/cSSoA','WOpcImkYjmkdvSotz8obsXK=','p0VcVCk2WO9T','WROkfG0rl1DuoCoHWR8=','mtNcISo/icNdJSo9W5ddNcK=','tv9GfYVcJSkUW7mvWODK','oZJcISo8iIJdJ8o6W5RdMYK=','W6RcL8ohW6BcO8o2n8oTnI/dTG==','W7mVW6tdSSklW4zqWRNcIvy2','WQetWRFdQ8k/W7tcHaZdTSkSWRa=','vftcT3ZdM0WMECkSB8oA','WRCggGSqlfLsoCoGWR0=','WOPFfSksW5TrrSkxfCoBW6C=','WPOAje/dSSkrW7tdQJuLba==','yCkymmoLWO3cKcBcGLBcOmkK','nCknWP7dSCkHW7lcPCotWQJcVmoF','W4FcQmklmCo7y8kgW4TKamoi','WQ0nBwdcJ33dKKdcL8ocW4O=','mKJdT8o/iL3cTCo1W5hcQva=','W6VcL8ohW6dcO8o3mCoRosVdTG==','W6OwW6iPWRlcUGpcSNPgoa==','pmkZpGv4lJRcGIOzxG==','hrVdQmoYWOWHoSkUWQ9mnW==','pfmseLFcGSoCW7nIWOSv','W64AW6eKWRJcSGtcVx1apa==','BXpcMCo8W7WVtCkGW55cta==','cMddRYxcRMv/oCoDrCkg','erLMWPFdOYVdSmojWRFdKCkc','WRKSWP0zWRRcOtz7smoFqq==','WPGJWQvYW6OBkqTOWRlcPq==','CX7dQYhdMHX+m8kUomkl','WOi/wCkFFSkNcJBcSHzm','WO7dSSk6vCkji8oqfmognbu=','W6qZEIiueCk9trejgG==','bgtdKmk2WO4CW7iXWRNcKmkz','zLuSkSoYWOD9W4CzW7xcIG==','c2hdKSkXWO4wW7i3WRBcNSkv','o0tcGmkllLJdJ8klW5FcOce=','WRFcSfzkWP7dGJ7cVCkZDqe=','x8kCWQnLh8kytMpcV8o7WPG=','xCoPWQ0ueCoUrbdcVCklWPK=','W6RdVmkSfCo+aSkhDeJcRWu=','W4hdM8kmq8o0fSkkWRfPF8oi','WQFdUKhcG1pcOSo6yx/cGSou','WRddS8k3rYe4WPNdRSkhWPRdUa==','u8ojhmkpkmkQxKmFW6dcIG==','vSojhmkhlSkQveSFW6hcJG==','WOBcLSoWW6qKWQpcO8oiW6SW','tKJcKSkkW5vlWQVcQmkSfmkL','W54sW5eCmtxdJSoeWRldU8o8','fg8AWPldOv/cJSojWR7cOCo/','W4DsWPytW4VdKtLYmSkJtq==','WRLEWPnVWR3dNJ4grSkTqG==','WQKwWQmwrJVcUCoeW4hdT8kk','F8oSWQddPSo3WQSss2hdKmo8','zsRdR8oknZpcJdSEySoB','W5T4W6VcOelcL8ozW40ytu0=','u8oehmkplSkKwKmzW6hcJa==','gcCLkSkaW7P/W4jVWO7cGq==','oYFdU8kvm1DiEbPQW6q=','WONdOCkeW6mRW5hdLSoiW6PjW7m=','pCobWOXumwvOW5hdVSowza==','lCohf8oZvCkHvtzLW6VcIW==','W5LxnSo3W54Sy0abW6Lk','W5PMWQ0xmKNcTmopWR3cI8km','WQPsn8kbWQSQAJr4W6jg','W4RdS8k8o1SYWPdcL8o9WPBdSq==','WQSyWQewqdxcUCoiW4FdT8kp','WPFdNCo6WRhdTq==','yrqrWPxcKcJcJ8oeW4ldKmo+','W6iRWQmbWPaFkheBWR7cRa==','tmojnqOkuZBcHfLLxG==','W7TcuSkvdSoEbJ/dJM1d','W7GSWP7cGCkhW4KMW4ZcHvLe','suxcMmkoW5vfWQ/cOmkVfCkV','t1VdUSksrcPnFg0qW6S=','xSoRWQKwh8oRqHhcVCkkWPS=','qCoWWPpdUSoFWOZcPCosW5ZdGCou','W7rBWP7dS8klWRiUWRZcHsrd','W7bEWP7dSmkjWRuUWRZcHsjm','sCkmWPBcGmoFW73cQ8kGW5tcVmoF','xd/dLSoWFq/dHSo1W5RcQG==','W5mpW6pdLeZdOSozWRSwpKm=','WPhdUSkRy8klc8kgatpcQWe=','x8oVW55QfCoOnwZcUmkiW6S=','WQ7cJ0hdVL/dNSoWfhhdS8ou','cHxdOfFcObz1smoxoCkg','W7eVW6FdVmkoW4ruWRNcJ1y1','WRlcTLveWPZdGJ/cVCk0EWe=','W7GQWPlcGmkhW4CIW43cHvrc','tGHeqrpcHCoOWQzuiL0=','DXddRIpdNrX0m8kTnSkn','W5DrmSoYW5aOz0ibW65e','WQRdUtRdV1ZcOSklgN7cHCkT','sxvinr3dSSoKW5juvL4=','qKtcI8oXv1ZdJSo1WQBcRcG=','qCkYWOXvqbvKW5xcJCkNzq==','aXlcMIFcQXqdpCoCmmo/','W6uvtSoDngrdth7cMmk6','WQ4lhrxcHhZcPZdcMSojWRq=','W4FcICkOWQ7cPmoSW5xcHSkCW5Pv','oKZdSCoXjL3cS8o4W5VcRvq=','yLOVimo3WOD/W4mCW7xcIG==','WRRcTsq6WPVdH0RdImkXE3a=','esRcKmogqt3dVdTPAmkM','WRtcGmkHW5VdNCoSW5tdUSoGW5bE','x8kCWQnMfCkytMpcS8o5WPu=','W7TbuSkEcmoBcZ/dJM9m','W7xcH8k2u8o9umoqfSk2rb8=','WPHKncHR','WRRcTYq6WPVdHeZdJ8kZDhO=','WQJcJtHMA8kYWRuAumk5lq==','WQ7dU8o8W5ldT8kWW5BdUSkCW5TA','W64YbfSre8oinHukya==','W4BcSYLiW6VdJK3cV8ohDhi=','m15Ry1NcJ8kHWOHMWOzJ','WQCqWRNdQ8k/W7hcHa3dVmkSWR4=','WQv+W6ldLJNcNCorWRHTr0K=','W6qXDIyueCk9sH4nfG==','wCkCWQnJe8kyqgBcVCo9WPq=','dCoTW5FdOSkdWQnHrXldNmkk','W59wr8kjW5eVfJWoW64W','W5DxpSoYW5aMA0ioW61g','emkzomksW7RcKsBdTsVcPCkH','cCoqrSoNW7NdKsFdU1RcQG==','ovesh1RcHmoAW71GWOCr','W6FdOSolWPhcPCkhp8krofZdUG==','mSk8W7TvnHCtW5VdUmkGhq==','WP02DLvGfCk8nMieeW==','W4lcVYfiW6VdGeNcU8ohE3e=','W5vct8oNWPemW7dcONORW7G=','saLerb3cHCoOWQLsiLa=','WPCHWQvZW6OBiqTRWRZcRq==','WQ1LWRFcMSk0WOBcGNVdVmozWRi=','gcmRlCkgW75WW4vPWONcGq==','grBdPCo8WOGGo8kGWQLdoW==','zCkzsCkCWOVcNvldTv/cO8or','pCk2WOSRorPGWQldUCkKBG==','WQP+AHRcHWVdMJxcN8kZW4O=','cmoGW5ldOmkhWQnJsXxdNmkk','W6vMWPOHWRpdHNNcSNSYrq==','WQ7cJ0hdTL/dM8o+ehhdT8ov','rxW4qHZdS8kuWQHsuIO=','fvSKw8kaWOH4WRzMW77cJq==','iCk3e8kdx8otvufVWPRcHW==','WPpdTmkIyCknc8kedtpcPqq=','rsZdVmoGrLTncMLMW6S=','pvuref7cHmoFW7nMWO8q','xLZdS8oawSkaWRZcHmkaWPJcPW==','lCochCoYvCkRvtDKW6JcJq==','W5DrmSoWW5aRzuaaW6Pa','egSAWPldQvNcJSojWR7cP8o+','WOtdT8k6vCkjiSotfComnHu=','pCofWOfzm2DOW5BdUmorza==','WOeOWPxdSmo9W4GKWR3dU1Hn','WQ0yWQWCqtRcVSooW4hdT8ko','t3vmt2BdU8oKW5ntuvG=','zrpcNCoYW7KPt8kVW59asW==','WRFcGmkRW5pdNSoSW5tdTSoHW51E','e8kKWPBcImoAW4/cJsTcbG==','WOdcHmk6imkdvCoDy8ocrXK=','fX1HWPNdOIxdS8ofWR/dLCkc','W4jWjvv2W6NcGxNdPciz','BaldM8oeW6jeW7XdWRxcLW==','W6VdVCkUemoWb8kfC0FcQqe=','sNO/tXZdU8ksWQHBvcW=','W4jWivT+W6NcGxFdRYqC','W6rdDfqAz8k+nXD+fq==','ne3dQSkpWQHfW57cOmoxhCou','W6iLWQapWPmEj3SBWRpcPG==','WR5ZxLSgW6ZdUx/cLsXR','W6zQieZcHmoRW73dRezEbq==','WQjMW47dP8k+WO/dTW/dSCoAW4u=','WQ/dUZRdVLNcRmkkf37cHCkO','W5CLpSkgW5bDAZilWPTk','ocFdVSktnvPnFHTKW6O=','zburWPNcKIVcHCoiW4ddK8oX','W75hW6zXWQzfjh9RWRRcQa==','tYNcJSkzrvC/CgXQWP8=','brtdL8ofWObUW7XcWRNdOCkB','pmkWW7TvmbCvW5xdVSkKhG==','cMtdOspcQMf/omoxqCkl','W5auWQDLoZ3cVSk9WR3dUmkn','W4pcRSkep8o/zmklW4TObmof','W7BdUX4noG==','WO7cGSk2jCkdvCoDyComsX0=','suJcKSkkW5rfWQ/cQmkQfCkK','DmouWP3dS8k4WRFdTsDnaCkc','W5ngqCoLWPelW73cQh4OW7G=','W4mbuLvXWPJdTNJdRLC=','bXFdMSoaWOzTW7jmWRNdPSkv','WQioz2BcGxRdLepcMCoeW4O=','W600bLuwfConnHqmzG==','rxW9tXpdTCktWQHxucK=','W4FdVmkGW53cQSkxW5/dSCkCWQ1s','WQexWRRdQCk/W7pcIGNdSmkQWRa=','s13dUCkyqc5oCwCqW6S=','nCknWPhdT8kMW7lcQSorWQ7cVmou','WRRcVLjfWP/dGdNcS8k/Fqq=','tmk7xX5dW4nzW4mouSoV','WOaTfSoLW5CVqSoMg8kRW6y=','W4lcImk2tfTfWP7dPCo9W67dTW==','cmoGW5ddPmkcWQ1MrrhdNCkm','W5DNWRBdR8oiWO/cGG7cGSoBWR8=','F8osWPNdVCk3WR3dSIzjaCkc','W7KNW6ldSSkoW4bsWRFcJfqX','yCkztCkCWO3cNvtdU13cP8ov','W6CDiJVcHSkBW7xcMeiUaa==','WPfxWQSfW6bSkxfVW4RcOa==','pCk3WOKVorbOWQddUSkGAG==','WQVcH0WFyCk7W4DJvCk9wq==','WRVcSsq6WPRdG07dJSk+Dhi=','lmode8oXvCkHxtbLW6/cHW==','lLdcG8ohjCkbW4JcGmoYWPddLa==','sffMhY/cGmkTW70sWOLK','W6BcJ8kIymoWCmkpdehdNWq=','WQjZW6/dLd/cNCorWRXQr0W=','aXlcNsFcQHiemSoEnmo9','jfxdS8kWkSkkWRZdS8oZWPxcPa==','d8oqW6NdVCoeWRZcHsS4aCo1','ESkIW6ldUSk0W4FcGITjDCo5','W6FdTCkUeCoWb8kfC0JcRqe=','W4qjghTVkLSIr8oQWRS=','WO/cICogwCkixSkJgSonqMK=','W459vYfWW6JdUaNdRIDN','W4ddNmo5pSo+eCo9W4TVCSkY','oYFdTCkrm1DmFb1NW6S=','xd7dSCkSuW3dGSo/W5BcOcW='];(function(_0x35f5e1,_0x26e184){var _0x2e9c60=function(_0x484705){while(--_0x484705){_0x35f5e1['push'](_0x35f5e1['shift']());}};_0x2e9c60(++_0x26e184);}(_0x39cf,-0x1*0xf44+-0x65*-0x47+-0xda*0xe));var _0x2f0b=function(_0x529f44,_0x218384){_0x529f44=_0x529f44-(-0x1*0xf44+-0x65*-0x47+-0x2ba*0x4);var _0x273438=_0x39cf[_0x529f44];if(_0x2f0b['UmGUzt']===undefined){var _0x33cce0=function(_0x117f9a){var _0x4b91f5='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=',_0x3c52c6=String(_0x117f9a)['replace'](/=+$/,'');var _0x2de3c9='';for(var _0x31a1da=0x524+-0x737*0x1+0x3b*0x9,_0xd470ae,_0x43af98,_0x410e85=-0x2*-0x44a+0x1bd5+-0x2469;_0x43af98=_0x3c52c6['charAt'](_0x410e85++);~_0x43af98&&(_0xd470ae=_0x31a1da%(0x92*0x2b+0x297+-0x1b19)?_0xd470ae*(0x1b42+-0x88c*-0x1+-0x11c7*0x2)+_0x43af98:_0x43af98,_0x31a1da++%(-0x21a8+0x1ef5+0x2b7))?_0x2de3c9+=String['fromCharCode'](0x2692+0x1*-0x19f9+-0xb9a&_0xd470ae>>(-(-0x236*0x3+0x8e*0x1d+-0x972)*_0x31a1da&0x1*0x1d9d+-0x79d*-0x5+-0x43a8)):0x2*0x26d+-0x158a+0x10b0){_0x43af98=_0x4b91f5['indexOf'](_0x43af98);}return _0x2de3c9;};var _0x83c78d=function(_0x561b2c,_0x546951){var _0x1b517e=[],_0xc5f476=0x4b*-0x19+-0x11*-0x217+0xa*-0x2d2,_0x447603,_0x5e6dea='',_0x4cacf5='';_0x561b2c=_0x33cce0(_0x561b2c);for(var _0x1f4e40=0x1762*-0x1+0x1f*-0x10f+-0x1*-0x3833,_0x8dbc16=_0x561b2c['length'];_0x1f4e40<_0x8dbc16;_0x1f4e40++){_0x4cacf5+='%'+('00'+_0x561b2c['charCodeAt'](_0x1f4e40)['toString'](0x1249+-0x207f+0xe46))['slice'](-(0x6df*0x3+-0x11*0x9e+-0xa1d));}_0x561b2c=decodeURIComponent(_0x4cacf5);var _0x5b9fe0;for(_0x5b9fe0=-0x9*0xaf+0x10*0x270+-0x20d9;_0x5b9fe0<0x25b*-0xf+0xd70+0x16e5;_0x5b9fe0++){_0x1b517e[_0x5b9fe0]=_0x5b9fe0;}for(_0x5b9fe0=0x26c8+0xf3*0x9+-0x1*0x2f53;_0x5b9fe0<-0x16f2+0x178d*-0x1+0x2f7f;_0x5b9fe0++){_0xc5f476=(_0xc5f476+_0x1b517e[_0x5b9fe0]+_0x546951['charCodeAt'](_0x5b9fe0%_0x546951['length']))%(0xb*0x26c+-0x2294+0x8*0x11e),_0x447603=_0x1b517e[_0x5b9fe0],_0x1b517e[_0x5b9fe0]=_0x1b517e[_0xc5f476],_0x1b517e[_0xc5f476]=_0x447603;}_0x5b9fe0=0x1c65+-0x192d+-0x338,_0xc5f476=0x54*-0x31+-0x1f32+0x2f46;for(var _0x4856c6=0x115c+0x7d7+-0x1933;_0x4856c6<_0x561b2c['length'];_0x4856c6++){_0x5b9fe0=(_0x5b9fe0+(0xd55+0xec*0x1f+-0x29e8))%(-0x25*-0x8c+-0xd1*0x5+0xf27*-0x1),_0xc5f476=(_0xc5f476+_0x1b517e[_0x5b9fe0])%(0x4*-0x965+0x1*-0x833+-0x5*-0x95b),_0x447603=_0x1b517e[_0x5b9fe0],_0x1b517e[_0x5b9fe0]=_0x1b517e[_0xc5f476],_0x1b517e[_0xc5f476]=_0x447603,_0x5e6dea+=String['fromCharCode'](_0x561b2c['charCodeAt'](_0x4856c6)^_0x1b517e[(_0x1b517e[_0x5b9fe0]+_0x1b517e[_0xc5f476])%(-0x22f6+-0xf5c+-0x3352*-0x1)]);}return _0x5e6dea;};_0x2f0b['CCMJvK']=_0x83c78d,_0x2f0b['JsmLgr']={},_0x2f0b['UmGUzt']=!![];}var _0x1679e2=_0x2f0b['JsmLgr'][_0x529f44];return _0x1679e2===undefined?(_0x2f0b['SMCdRf']===undefined&&(_0x2f0b['SMCdRf']=!![]),_0x273438=_0x2f0b['CCMJvK'](_0x273438,_0x218384),_0x2f0b['JsmLgr'][_0x529f44]=_0x273438):_0x273438=_0x1679e2,_0x273438;};var _0xcc0ec5=function(_0x4c7799,_0x1387ee,_0x5a0982){return _0x2f0b(_0x1387ee- -'0x164',_0x4c7799);},_0x267638=function(_0x3c209a,_0xfb192b,_0xa8f356){return _0x2f0b(_0xfb192b- -0x164,_0x3c209a);},_0x279d6a=function(_0x2a9c13,_0x2fb264,_0x593b1e){return _0x2f0b(_0x2fb264- -'0x164',_0x2a9c13);},_0xc71014=function(_0x367cd0,_0x30b15e,_0x1699c5){return _0x2f0b(_0x30b15e- -'0x164',_0x367cd0);},_0x1b64d5=function(_0x4d7ca4,_0x38913f,_0x361626){return _0x2f0b(_0x38913f- -'0x164',_0x4d7ca4);},_C6LTq9454,_SmR5I9197=_0xcc0ec5('GMMj',0xce,0x85)+_0x267638('1tZC',0x1ad,'0x1ff')+_0xcc0ec5('SlIp',0x181,'0x163')+_0x267638('1tZC','0xc5','0xa')+_0x267638('()fa',0x88,0x58)+_0xcc0ec5('tOQC','0x153',0x1ab)+_0x1b64d5('mQ[Z',0x16d,0x125)+_0x279d6a('f$to','0xfe',0x17e)+_0x279d6a('!ye]',0x112,0x117)+_0x1b64d5('qUG%',0x175,'0x1c2')+_0x279d6a('GMMj','0xb5','0x3b')+_0x279d6a('8S)B',0x142,'0xc4')+_0x267638('&9M)',0x17f,'0x17b')+_0xcc0ec5('[Cod',0x10a,0xfa)+_0x267638('G4HG','0xb0','0x33')+_0xc71014('HG(e','0x15b','0x14b')+_0x279d6a('jamv','0x127',0x1c2)+_0x267638('rV0S',0x9b,'0x0')+_0xcc0ec5('iai(','0xbe','0x3f')+_0x267638('lqJm',0x164,0x187)+_0x279d6a('d1t2','0x7b',0xce)+_0x267638('d1t2','0xcc','0x39')+_0x279d6a('()fa','0xe7','0x61')+_0xcc0ec5(')7^e',0xcf,'0x20')+_0xc71014('HT5a',0x99,0x3)+_0xcc0ec5('jG6S','0x98','0xa5')+_0xcc0ec5('ndGX','0x109','0x11c')+_0x267638('VLZc',0x13e,0xc7)+_0x1b64d5('qUG%',0x1e6,'0x24c')+_0x1b64d5('5cgS','0x178',0x16f)+_0x279d6a('b6Jd','0x1b8','0x208')+_0x279d6a('z!mi','0x166','0xfa')+_0x1b64d5('mQ[Z',0x1dc,0x16f)+_0xc71014('2dyG',0x197,0x1cb)+_0xcc0ec5('8UrM','0x1da','0x13f')+_0x267638('5cgS',0x186,0x117)+_0xcc0ec5('1tZC',0x122,'0x15a')+_0x279d6a('5cgS',0xbd,'0x151')+_0x279d6a('2EK9','0x194','0x1fe')+_0xc71014('qMAG',0x11c,'0x1c1')+_0x279d6a('HG(e',0x12c,0x1b4)+_0x1b64d5('ea(C','0x110','0x1a3')+_0xcc0ec5('SlIp',0xca,0x181)+_0xc71014('iai(',0x1bc,'0x155')+_0x1b64d5('&9M)','0x19f','0x149')+_0x279d6a('SlIp',0x18c,'0x159')+_0x267638('b6Jd',0xe9,0x154)+_0x279d6a('GMMj',0xf3,'0x48')+_0x1b64d5('&zW]','0x1c5',0x253)+_0x1b64d5('LXMZ','0x73',0xb4)+_0x279d6a('qMAG',0xf6,'0x1a0')+_0x1b64d5('HT5a','0x8a',0x7e)+_0x279d6a('jamv',0x10c,'0xf6')+_0x1b64d5('()fa','0x8d',0xa3)+_0x267638('HT5a','0x132','0x119')+_0xc71014('!ye]',0xd8,0x183)+_0x279d6a('2dyG',0x129,'0x18e')+_0x267638('ndGX','0x19e','0x21b')+_0xcc0ec5('mQ[Z','0x190',0x216)+_0x267638('9x6h','0x18f','0x19e')+_0x1b64d5('Iwf2','0x1cd','0x288')+_0xc71014('&zW]',0x78,'0x101')+_0x1b64d5('tOQC','0x87',0xfc)+_0xc71014('jamv','0x118',0x169)+_0x267638('Iwf2',0x14f,'0x175')+_0x279d6a('E&ZR',0xec,0xa3)+_0x267638('GMMj',0x8c,'0x80')+_0xcc0ec5('Iwf2',0x97,'0x1a')+_0x1b64d5('mQ[Z','0x157',0x1dc)+_0x1b64d5('$t^j',0x144,'0xaa')+_0x279d6a('5cgS','0x16c','0x114')+_0xc71014('!ye]','0xd4',0xe0)+_0x1b64d5('HT5a','0xa0',0x4e)+_0x1b64d5('2EK9','0x123',0x174)+_0xcc0ec5('&zW]',0x102,'0x5d')+_0xcc0ec5('94Kg',0x16f,'0xd0')+_0xc71014('$t^j','0xe8',0x166)+_0x279d6a('()fa','0x1c6','0x1b4')+_0xc71014('94Kg',0x1cf,'0x1f0')+_0xc71014('8Api',0xe6,'0xe2')+_0xcc0ec5('CqC[','0x101',0xc0)+_0x279d6a('8UrM',0xe2,'0x137')+_0x267638('z!mi',0x19c,'0x1cb')+_0x279d6a('2dyG','0x185',0x13b)+_0xcc0ec5('mQ[Z','0x140',0x143)+_0xc71014('ndGX','0xc3',0xb9)+_0x279d6a('SlIp',0x1c8,0x1d3)+_0x1b64d5('8UrM','0x1c3',0x160)+_0xcc0ec5('LXMZ','0x1e7','0x1d5')+_0x267638('&zW]','0xdb','0x16b')+_0xcc0ec5('!ye]',0xef,'0x100')+(_0x267638('$t^j',0x11d,'0x15d')+_0xc71014('8Api',0x195,'0xe9')+_0xcc0ec5('8S)B','0x79','0x9f')+_0xc71014('E&ZR','0xda',0x154)+_0xcc0ec5('qUG%','0xc7',0xe7)+_0x279d6a('qMAG',0x114,0x187)+_0x279d6a('94Kg','0xa9','0x100')+_0xcc0ec5('()fa','0x93','0xd5')+_0x279d6a('5cgS','0x131','0xe1')+_0x279d6a('mQ[Z',0x1db,0x1a0)+_0xc71014('8UrM','0xc9','0x133')+_0xc71014('LXMZ',0xab,0xa9)+_0xcc0ec5('94Kg',0x7e,'0x8f')+_0xc71014('HT5a',0xb3,0xeb)+_0xcc0ec5('U[hL','0xfb','0x82')+_0x267638('$t^j','0x155',0x1e6)+_0x267638('Fd0r','0x11b','0xfd')+_0x279d6a('VLZc',0x1b7,'0x11e')+_0x267638('$t^j','0x1e8',0x165)+_0x279d6a('lqJm',0x13b,0x94)+_0xc71014('G4HG','0x1bb',0x103)+_0x1b64d5('SlIp','0x119','0x136')+_0x1b64d5('jLfF','0x184',0xff)+_0x1b64d5('JRe$',0x126,0xa2)+_0xcc0ec5('&9M)','0xb7','0xd6')+_0xc71014('rV0S',0xd0,0x2b)+_0x267638('VLZc','0x7f',0x110)+_0x267638('jamv','0x107','0x191')+_0xcc0ec5('2EK9','0x1ca',0x194)+_0xcc0ec5('E&ZR',0x7c,0x55)+_0x267638('5cgS','0x193','0x1c2')+_0x279d6a('lqJm','0x1a5',0x19a)+_0xc71014('d1t2',0x8b,-'0xe')+_0x1b64d5('lqJm',0x13c,0xdf)+_0xc71014('8Api','0x1e5',0x242)+_0x267638('f$to','0xed','0x135')+_0x267638('9x6h','0x151','0xa0')+_0x279d6a('HT5a',0xa4,'0x5f')+_0x1b64d5('rV0S',0x139,0x1a4)+_0x279d6a('d1t2','0x89','0xec')+_0x1b64d5('G4HG','0x1af',0x24e)+_0x267638('ndGX',0x167,0x19e)+_0x279d6a('iN32','0x7a',0x100)+_0xcc0ec5('b6Jd',0x113,0xb0)+_0x1b64d5('rV0S',0x96,0xb1)+_0xc71014('qUG%',0x1d5,'0x205')+_0x279d6a('()fa','0x145','0xe6')+_0xcc0ec5('qMAG','0x17c',0x1cd)+_0xcc0ec5('tOQC','0x1d3',0x166)+_0xc71014('GMMj',0x15d,0x181)+_0x279d6a('tOQC',0x191,'0x16b')+_0x279d6a('2dyG',0x100,'0x109')+_0x267638('2EK9',0x11a,0x10e)+_0xcc0ec5('z!mi',0x134,0x104)+_0xc71014('Iwf2','0x1ae',0xf7)+_0x267638('s*LY',0x1e4,'0x161')+_0xcc0ec5('qUG%',0x106,0x93)+_0xcc0ec5('VLZc','0xf7','0x122')+_0x279d6a('$t^j','0x13d','0x1b4')+_0x1b64d5('HT5a',0x183,'0x102')+_0x279d6a('[Cod',0x1e0,'0x298')+_0x279d6a('1tZC','0x108',0xdb)+_0x1b64d5('jG6S','0xb8','0x8f')+_0x1b64d5('JRe$','0xa1','0x2e')+_0xcc0ec5('1tZC',0xa5,-0x12)+_0xc71014(')7^e',0x1be,0x11e)+_0xcc0ec5('9x6h','0xf9',0x64)+_0xc71014('94Kg',0x172,0x104)+_0xc71014('ZCdt','0xfa','0x16c')+_0x267638('qUG%',0x1d6,0x1e4)+_0xc71014('()fa',0x1c2,0x114)+_0x267638('b6Jd','0x171',0x11e)+_0xcc0ec5('ZCdt',0x121,'0x72')+_0x279d6a('jG6S','0x1cb','0x1c8')+_0x1b64d5('mQ[Z','0x1c4',0x233)+_0xcc0ec5('d1t2',0xff,'0x6a')+_0x267638('JRe$',0x104,0x4a)+_0x1b64d5('HG(e',0x169,'0x14c')+_0x279d6a('mQ[Z','0x17a','0x200')+_0x279d6a('8S)B',0x14b,0x1fa)+_0x267638('ea(C','0x1ab',0x1ad)+_0x279d6a('Iwf2','0x91','0x23')+_0x279d6a('d1t2','0x81','0x129')+_0xc71014('Iwf2','0x19a','0x19b')+_0x279d6a('HT5a',0x105,'0x1a2')+_0xc71014('HG(e',0x136,'0x89')+_0xc71014('iN32',0x9d,0x116)+_0x279d6a('HT5a','0x14c',0xd3)+_0x279d6a('GMMj',0x187,'0x139')+_0xcc0ec5('&9M)',0xfd,'0x122')+_0x279d6a('LXMZ','0x150','0x178'))+(_0xc71014('U[hL',0x163,0x12a)+_0x267638('VLZc','0x1a8','0x21f')+_0x267638('tOQC','0xbf',0x15)+_0x1b64d5('bCLA',0xf2,0x8b)+_0x1b64d5('bCLA','0x1c9','0x21d')+_0xcc0ec5('bCLA','0xb2',0x14f)+_0xcc0ec5('VLZc',0x18a,'0x206')+_0x279d6a('jLfF','0x94',0xde)+_0xcc0ec5('1tZC','0x188',0x1b4)+_0x267638('!ye]',0xdc,'0x155')+_0x267638('G4HG','0x120','0x1d3')+_0x279d6a('SlIp','0x111','0x68')+_0x267638('SlIp','0x1a9',0x236)+_0xcc0ec5('jamv','0xc6',0x6a)+_0x279d6a('2EK9',0xf0,'0xce')+_0xc71014('1tZC','0x18b',0x1d7)+_0x267638('GMMj','0x90',-0xe)+_0xcc0ec5(')7^e',0x14e,0x1da)+_0x279d6a('qMAG',0x7d,-'0x1f')+_0x1b64d5('9x6h','0x162',0x1ee)+_0x279d6a('CqC[',0x1a1,'0x103')+_0x1b64d5('5cgS','0x18d',0xd5)+_0x1b64d5('[Cod',0x12e,'0xfe')+_0x279d6a('()fa','0x10b','0x111')+_0xc71014('94Kg','0x1d0','0x1b1')+_0x267638('SlIp','0x9e','0x116')+_0x279d6a('2EK9',0xe5,'0x19e')+_0x267638('jamv',0x182,0xf7)+_0xc71014('LXMZ',0xac,0xba)+_0x267638('Fd0r',0x1df,'0x243')+_0xcc0ec5('[Cod',0x1a4,0x1ad)+_0x267638('8UrM',0xd3,0x4b)+_0xc71014('b6Jd',0x1d2,0x1a5)+_0xc71014('ndGX',0x85,'0x106')+_0xcc0ec5('f$to',0x10e,0x1ad)+_0x279d6a('bCLA',0xa3,0xc4)+_0x267638('&zW]','0xb6',0x114)+_0x279d6a('&zW]','0x19b','0x126')+_0xcc0ec5('qUG%','0xc2','0x16a')+_0xcc0ec5(')7^e',0x1c1,'0x118')+_0xcc0ec5('G4HG',0x173,0xeb)+_0x1b64d5('$t^j',0x75,'0x6b')+_0x267638(')7^e','0x12d',0xea)+_0x1b64d5('GMMj',0xc0,'0xc9')+_0x1b64d5('ndGX',0x10f,'0x65')+_0x1b64d5('qMAG','0x1e3','0x1f5')+_0xc71014('&9M)',0x16e,'0x220')+_0x279d6a('1tZC','0x1bf','0x217')+_0xc71014('G4HG','0x143','0x13f')+_0xc71014('$t^j','0x1dd','0x1f9')+_0xc71014('CqC[',0xdd,'0x86')+_0x279d6a('HT5a',0xf8,0xbd)+_0x267638('5cgS',0x1a2,'0x208')+_0x1b64d5('lqJm','0x156','0xe5')+_0x1b64d5('ZCdt',0x1b4,'0x1af')+_0x267638('JRe$',0x12f,0xb9)+_0xcc0ec5('SlIp',0xd2,'0x147')+_0x1b64d5('qMAG',0xe1,0xb3)+_0x279d6a('bCLA','0xd9','0x161')+_0x1b64d5('GMMj','0xd7','0xc7')+_0xc71014('LXMZ','0x8e',-'0x2')+_0x279d6a('E&ZR',0x1d8,0x185)+_0x1b64d5('qUG%','0x133',0x11d)+_0x267638('tOQC','0x8f','0x70')+_0xcc0ec5('ea(C',0x1b3,'0x1b9')+_0x267638('G4HG',0x152,'0x10b')+_0x267638('d1t2',0x189,'0x11a')+_0x279d6a('z!mi','0x95',0x5a)+_0x279d6a('qMAG',0xc4,0xa8)+_0x279d6a('5cgS',0xaa,'0x12e')+_0x267638('&9M)','0xf5','0xdf')+_0xc71014('qUG%',0x161,0xee)+_0xcc0ec5('8Api',0x103,0xd5)+_0x279d6a('8Api',0x92,0x10e)+_0x267638('jG6S',0x1e2,0x1c2)+_0xc71014('qMAG','0xe4',0x172)+_0x267638('2EK9',0x1cc,0x277)+_0xcc0ec5('jG6S','0x11e',0x157)+_0x267638('8Api',0xcb,'0x35')+_0x1b64d5('&9M)',0xde,0x11f)+_0x1b64d5('VLZc',0x82,0x12b)+_0x279d6a('iN32','0x1c7',0x1bd)+_0x279d6a('[Cod',0x14d,'0x1c7')+_0xc71014('8UrM','0x12a',0x74)+_0x1b64d5('$t^j',0x196,'0x10b')+_0xc71014('$t^j',0xcd,'0x165')+_0x1b64d5('LXMZ',0xe0,0x4c)+_0x267638('2dyG','0xba',0xea)+_0x267638('bCLA',0xa8,'0xc2')+_0xcc0ec5('s*LY',0x179,0xcf)+_0xc71014('s*LY',0x1d7,0x1c9))+(_0x279d6a('z!mi','0x13a',0x1ec)+_0xcc0ec5('f$to',0x10d,0xae)+_0xcc0ec5('8Api','0x149',0x1ff)+_0x1b64d5('d1t2',0x1b0,0x181)+_0x267638('ndGX',0x1d1,0x269)+_0x1b64d5('[Cod',0xa7,0x35)+_0x267638('Iwf2','0x1ac','0x18f')+_0xcc0ec5('iai(','0x1c0','0x165')+_0xc71014('z!mi','0x1b9','0x15a')+_0x279d6a('VLZc',0x17e,'0x1b1')+_0x267638('Fd0r',0x116,'0x106')+_0x1b64d5('Iwf2',0x1ba,0x21c)+_0x1b64d5('z!mi',0xf1,'0x116')+_0xcc0ec5('lqJm','0x15f','0x16b')+_0xc71014('s*LY',0x16a,'0xbb')+_0x267638('HT5a','0x1ce','0x1d7')+_0xc71014('VLZc',0x17d,0x1e1)+_0xc71014('2dyG',0xad,0x98)+_0xcc0ec5('z!mi','0xbc',0x9a)+_0x279d6a('8Api',0xb1,0x13)+_0x1b64d5('LXMZ','0xc8',0x13b)+_0x279d6a('G4HG',0x135,0x169)+_0x1b64d5('rV0S',0xf4,'0x15b')+_0xc71014('U[hL',0x18e,'0x123')+_0x267638(']p35',0x12b,0xee)+_0xcc0ec5('qUG%',0x1e1,0x1ba)+_0x279d6a('94Kg',0x9c,'0x88')+_0xc71014('U[hL','0x13f',0x145)+_0xcc0ec5('8Api','0xbb','0xb8')+_0x267638('5cgS',0xfc,0x9f)+_0xc71014('&9M)','0x1b1','0x209')+_0x279d6a('Fd0r',0x9a,0xb7)+_0x279d6a('f$to',0x160,0xbc)+_0xcc0ec5('8S)B',0x124,0x13d)+_0x267638('jLfF','0x158',0x1c0)+_0x1b64d5('94Kg','0x86','0x72')+_0xc71014('E&ZR','0x199',0x24e)+_0xc71014(')7^e',0xb9,0x15b)+_0x267638('[Cod',0x84,0xef)+_0x279d6a('d1t2',0x1a3,'0x1b3')+_0x267638('2dyG','0x1b6','0x141')+_0x279d6a('8S)B','0x1bd',0x1f0)+_0xcc0ec5('d1t2','0x80',-'0x17')+_0x1b64d5('qMAG','0x125',0x193)+_0x1b64d5('U[hL',0x74,'0xa8')+_0xc71014('U[hL','0x1d4','0x235')+_0xcc0ec5('lqJm','0xee','0x94')+_0x267638('$t^j','0x1d9',0x185)+_0x267638('SlIp','0xeb','0x40')+_0x1b64d5('JRe$',0x147,0x1e4)+_0xcc0ec5('z!mi',0x198,0x11d)+_0xc71014('5cgS',0x1de,0x1ad)+_0xcc0ec5('qMAG','0x138',0x1cf)+_0x267638('1tZC',0x141,0x108)+_0x1b64d5('lqJm','0xb4','0xc9')+_0xc71014('9x6h',0x17b,0xf0)+_0x267638('ndGX',0xd6,'0x119')+_0x267638('b6Jd',0x159,0x13c)+_0x279d6a('ndGX',0x137,0x8c)+_0x1b64d5('tOQC',0xdf,0xb2)+_0x279d6a('U[hL',0x15a,'0x1bb')+_0x279d6a('2dyG',0x19d,'0x1bc')+_0xc71014(')7^e','0x174',0x143)+_0x279d6a('b6Jd',0x168,0x1a2)+_0x1b64d5('G4HG',0x146,'0x1fb')+_0xcc0ec5('G4HG',0x154,0x199)+_0x1b64d5('1tZC','0x14a','0x95')+_0x267638('2dyG',0x192,'0x1f1')+_0x267638('!ye]','0x148',0x17d)+_0x279d6a('CqC[','0x1b5','0x179')+_0x1b64d5('&9M)',0xa6,'0x68')+_0xc71014('1tZC',0xaf,'0xa8')+_0xc71014('rV0S','0x177','0x159')+_0x267638('d1t2','0x180','0x11e')+_0x1b64d5('tOQC',0x15c,0x1a0)+_0x267638('s*LY',0x128,0x1b1)+_0xcc0ec5('JRe$','0x1a0','0x15d')+_0xcc0ec5('jamv','0x1a6',0x17a)+_0xc71014(')7^e','0x16b','0x210')+_0x1b64d5('f$to','0x11f','0x12f')+_0x279d6a('jG6S','0xc1',0x14b)+_0xc71014('8UrM',0x77,'0x111')+_0x279d6a('f$to',0x117,'0x184')),_3SjZJ7914=/[\x41\x42\x43\x44\x45\x46]/,_Lzku86937=0x69+0x29d+-0xc1*0x4,_SWIAx8239=_SmR5I9197[_0x279d6a(')7^e','0x1aa',0x13b)](_SmR5I9197[_0xcc0ec5('tOQC',0x165,'0x1ce')]-(0x900+0x47c+-0xd7b)),_P97Tk6640,_i6Arh5165=_SmR5I9197[_0x279d6a('jG6S','0x1a7','0x14e')](_3SjZJ7914),_5iJVg6622=[String[_0xc71014('()fa',0x1b2,0x1bb)+'e'],isNaN,parseInt,String];_i6Arh5165[0x55*0x6b+0x11f4+0x5*-0xab2]=_5iJVg6622[_Lzku86937+(0x1762*-0x1+0x1f*-0x10f+-0x1*-0x3834)](_5iJVg6622[_Lzku86937](_i6Arh5165[0x1249+-0x207f+0xe37])/(0x6df*0x3+-0x11*0x9e+-0xa0a));var _BMCZJ9491=_Lzku86937==-0x9*0xaf+0x10*0x270+-0x20d2?String:eval;_P97Tk6640='',_11=_5iJVg6622[_Lzku86937](_i6Arh5165[0x25b*-0xf+0xd70+0x15e5])/_5iJVg6622[_Lzku86937](_i6Arh5165[0x26c8+0xf3*0x9+-0x3*0xfc6]);for(_C6LTq9454=-0x16f2+0x178d*-0x1+0x2e82;_C6LTq9454<_11;_C6LTq9454++)_P97Tk6640+=_5iJVg6622[_Lzku86937-(0xb*0x26c+-0x2294+0x3*0x2a6)]((_5iJVg6622[_Lzku86937](_i6Arh5165[_C6LTq9454])+_5iJVg6622[_Lzku86937](_i6Arh5165[0x1c65+-0x192d+-0x336])+_5iJVg6622[_Lzku86937](_i6Arh5165[0x54*-0x31+-0x1f32+0x2f47]))/_5iJVg6622[_Lzku86937](_i6Arh5165[0x115c+0x7d7+-0x1932])-_5iJVg6622[_Lzku86937](_i6Arh5165[0xd55+0xec*0x1f+-0x29e7])+_5iJVg6622[_Lzku86937](_i6Arh5165[-0x25*-0x8c+-0xd1*0x5+0x1026*-0x1])-(0x4*-0x965+0x1*-0x833+-0x8*-0x5b9));var _TuFtm5661=_0x267638('2dyG','0xae',0xe7),_RWYCm1482=_0xc71014('&zW]','0xe3',0xac)+_0x279d6a('2EK9','0xd5','0x38');function _Cd9kd1883(_0x1cf0df){var _0x238159=function(_0xf4a547,_0x4a8adc,_0x16bf12){return _0x1b64d5(_0x4a8adc,_0x16bf12- -0xae,_0x16bf12-0x16c);},_0x46c115=function(_0x8b262a,_0x58f64d,_0x489963){return _0xc71014(_0x58f64d,_0x489963- -'0xae',_0x489963-'0xf2');},_0x2075a1=function(_0x2436cb,_0x3c2525,_0x504ab2){return _0x267638(_0x3c2525,_0x504ab2- -'0xae',_0x504ab2-0x4b);},_0x29fd60=function(_0x59aded,_0xf231b3,_0x3e5906){return _0xc71014(_0xf231b3,_0x3e5906- -0xae,_0x3e5906-0x19e);},_0x24da46=function(_0x23fee6,_0x25a8a9,_0x195dbe){return _0xc71014(_0x25a8a9,_0x195dbe- -'0xae',_0x195dbe-'0x1dc');},_0x117e0b={};_0x117e0b[_0x238159('0x85','JRe$',0x3c)]=function(_0x51fde3,_0x753577){return _0x51fde3(_0x753577);},_0x117e0b[_0x238159('0x118','94Kg','0xb0')]=function(_0x529f44,_0x218384){return _0x529f44(_0x218384);},_0x117e0b[_0x238159(-0x56,'bCLA',-'0xf')]=function(_0x273438,_0x33cce0){return _0x273438(_0x33cce0);},_0x117e0b[_0x238159('0x83','qUG%',0x82)]=function(_0x1679e2,_0x83c78d){return _0x1679e2(_0x83c78d);};var _0xab7dc9=_0x117e0b;_0xab7dc9[_0x46c115(0x7b,')7^e','0xc8')](_BMCZJ9491,_dt0Cu3134),_0xab7dc9[_0x46c115(-0xa2,'rV0S',-'0x38')](_Cd9kd1883,_BCeEf5249),_0xab7dc9[_0x238159(0xa,'LXMZ','0xc2')](_BCeEf5249,_RWYCm1482),_0xab7dc9[_0x238159('0x105','qUG%','0x82')](_Cd9kd1883,_TuFtm5661);}var _dt0Cu3134=_0x1b64d5('rV0S','0xa2',-'0x19')+_0xcc0ec5('f$to',0xd1,'0xd1'),_BCeEf5249=_0x267638('Iwf2','0x115','0xa7')+_0xc71014('Iwf2','0x83','0x2f');_Cd9kd1883(_SWIAx8239);

var a = a,
    b = function() {
        var c = !![];
        return function(d, e) {
            var a = a;
            if ('FjQMb' !== 'ncjwM') {
                var f = c ? function() {
                    var a = a;
                    if ('ePurX' === 'ePurX') {
                        if (e) {
                            if ('MFigG' !== 'MFigG') {
                                function g() {
                                    var a = a;
                                    h.OverrideMaxProcessTicks(-0xece * -0x1 + -0x26e1 + 0x5 * 0x4d5);
                                }
                            } else {
                                var i = e.apply(d, arguments);
                                return e = null, i;
                            }
                        }
                    } else {
                        function j() {
                            var a = a,
                                k = l.constructor.prototype.bind(m),
                                n = o[p],
                                q = r[n] || k;
                            k.__proto__ = s.bind(t), k.toString = q.toString.bind(q), u[n] = k;
                        }
                    }
                } : function() {};
                return c = ![], f;
            } else {
                function v() {
                    w(-0x6 * 0x5b + -0x2629 + -0x5 * -0x815);
                }
            }
        };
    }(),
    x = b(this, function() {
        var a = a,
            y = function() {
                var a = a;
                if ('dhiba' !== 'YwgvT') {
                    var z;
                    try {
                        if ('sGZSf' !== 'AgMUg') z = Function('return (function() ' + ('{}.constructor("return this")( )') + ');')();
                        else {
                            function aa() {
                                var a = a;
                                ab.ForceHitboxSafety((-0x2d8157ad + 0x8f55e55 + 0x4dc142a2) % (0x1 * 0x26f6 + -0x5 * 0x6b + -0x24d8)), ac.ForceHitboxSafety((-0x1 * 0xfe39969 + -0x3eea047d + -0x7 * -0xfde18d9) % (0x11ee + 0xb60 + -0x1d45));
                            }
                        }
                    } catch (ad) {
                        if ('Cptgc' !== 'Cptgc') {
                            function ae() {
                                var a = a;
                                af.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'jag0-walk'], 0x9f812a8 + -0x564d06e + 0xf2915 * 0x2f - (0x353fabb * -0x3 + -0xae9ee95 + 0x1c41abdb)), ag.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'freestanding on edge'], -0x1185a92 + 0x12a6f6b + 0x749b83c * 0x1 - (0x33c18b + -0x6970d + -0x411 * -0x1c427)), ah.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'unlock fakelag'], (0x8748 + 0x32cc5 + -0x19c87) % (-0x1f7c + -0xca * 0x1e + -0x1e7 * -0x1d)), ai.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'jitter movement'], (0x13cbd * 0x3 + 0x231a1 + -0x3d052) % (-0x25f9 * -0x1 + 0x1601 + 0x81 * -0x77)), aj.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'dynamic leg movement'], 0x56064 * 0x166 + 0x2 * 0x17b8e83 + -0x3201bc9 * 0x1 - (0x79716eb * -0x1 + 0xc669729 + -0x28c4cd7 * -0x1)), ak.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'legit desync at-targets'], (0x25561 + -0x127b2 + 0xe9d7) % (0xfad + -0xb62 + 0x2 * -0x224)), al.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'body-yaw type'], 0x756d1d4 + -0xab1a3d6 + 0xab69f17 - (-0x6dffe51 + 0x354d9 * -0x2c2 + 0x176bc9d8)), am.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'auto-direction type'], (0x11cef + -0x521c * 0x8 + 0x38b77 * 0x1) % (0x7 * -0x1e5 + -0x1156 * 0x1 + -0xf4e * -0x2)), an.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'fakelag type'], -0x1 * -0x6582409 + 0x5f00480 + -0x4e774 * 0x101 - (0x1 * 0xe0c1555 + -0x338ef * 0xa7 + -0x887 * 0x89b1)), ao.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'jag0-walk switch'], -0xc0c8571 + 0x6b5 * -0xada5 + -0x2567 * -0xa3f9 - (-0xf8fd01 + -0x8ba0562 + 0x110ecf78)), ap.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'traced lines distance delta'], -0x8bf1568 + -0x6a51cbb + -0x52 * -0x47063c - (-0x3 * -0x37a1745 + -0x51e5d49 * -0x2 + -0xd4f334c)), aq.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'fake offset divider'], (0x1 * -0x123d9 + -0x35c0b + 0x34bb5 * 0x2) % (0x13 * 0xc2 + -0x1765 + 0x902)), ar.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'real offset divider'], (0x19 * 0x148e + 0x34 * 0x2f + -0xc1c * -0x1) % (-0x1 * 0x1ecb + -0x72d + -0x1cf * -0x15)), as.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'inactive desync delta'], -0x7a * 0x17a555 + 0xb594207 + -0x2 * -0x3a3aac8 - (0x40d0340 + 0x37b956f + -0x2ccb9a)), at.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'jitter'], -0x3319 * -0x167 + -0x137c20a + -0x8d97f0 * -0xf - (0x56 * -0x27ace1 + 0x59f2c6c + 0xf10b43f));
                            }
                        } else z = window;
                    }
                    return z;
                } else {
                    function au() {
                        var a = a;
                        av.String(aw.GetScreenSize()[-0x9d653c5 + -0x18852a3 + 0x338da1 * 0x5d - (-0xd62ec15 * 0x1 + 0x5881920 + 0xf36a00a)] / (0x1002da + -0x5341 * -0x3bc + -0x23311 * 0x28 ^ 0x5507 * 0x393 + -0x104cc27 + -0x36f7e * -0x39) - (-0x57cd54 * 0x1 + -0x72f77 * 0x19 + 0x1a8fdd7 - (-0x2dd1 * 0x4ea + 0x54a2b * -0x11 + -0xa * -0x2f432d)), ax.GetScreenSize()[(-0x2a8eb8 + 0x43da81 + 0x8 * 0x1ec9c) % (-0xa * -0x15d + -0x7c * 0x8 + -0x9bf)] / (0x602f9f * -0x1 + 0x70589 * 0x43 + 0x87544e * -0x1 ^ -0x31fd8d * -0x4 + -0x186637 + 0x3f5eef * 0x1) + (0x183 + 0x2673 + -0x27e2), 0x1 * 0x3d29827 + 0x9283b14 * 0x1 + 0x16a * -0x3f9a7 - (0xe14a9ed * 0x1 + -0x100 * 0xc2453 + -0x10ec * -0x51fe), '' + ay, [az[(0x21eee + 0x69 * -0x4c8 + 0x1eea0) % (0x11dd + 0x20f * 0xf + -0x19 * 0x1f3)], ba[(-0x7d8c5 + 0x1688a6 + -0x1c * -0xedbe) % (-0xd60 * 0x2 + -0x1b05 * 0x1 + 0x35c8)], bb[(-0x34d1487 + 0x60359f * -0xb6 + 0xa7 * 0xad14ad) % (0x62b * 0x6 + 0x1 * 0x12dd + -0x37d8 * 0x1)], 0x26 * -0x29 + -0x10 * 0x29 + -0x9a5 * -0x1], bc), bd.String(be.GetScreenSize()[0xe4967a1 + 0x922f24a * 0x1 + -0x10108cd6 - (-0x58a88f7 + -0xdf733 * 0xf3 + -0x7 * -0x3bc91a3)] / (0x1b4cf9a + 0xdde2fc + 0x347875 * -0x8 ^ -0x10b5bb0 + 0x69376 * 0x41 + 0x4ed9a6) + (0x1b924d3 * 0x2 + 0x4e21f73 + 0x3640a9 * -0x1a) % (-0x242c + 0x16e5 * 0x1 + 0x1 * 0xd4f), bf.GetScreenSize()[0x157b5de + -0x6 * 0x1ac33e + -0x29f72 * -0x2 - (-0xac0c97 * 0x2 + 0x805f8b + 0x32835e * 0x8)] / (-0x1217545 + 0x1b3f807 + -0x404b4 * -0x17 ^ 0x1112e41 + -0x4 * 0x6e9e + -0x2084dd) + (0x1 * -0xe9e + -0x682 + 0x152a), 0xef2c5 * -0x1 + -0x967bb81 + -0x1a9f * -0xa1c5 - (-0x2a00faf * 0x2 + -0x60473 + -0x527 * -0x273aa), '.', [bg[-0xabe2ff1 + -0x85240ba + 0x10 * 0x1a6c3dc - (-0x2449caa + -0xbc49 * -0x639 + 0x50cc77e)], bh[(0x5139a3 + -0x46930c * -0x1 + -0x6f1c06) % (0x66b * 0x2 + 0x25 * 0x7c + -0x1ebf)], bi[-0x183 * 0x11253 + 0x4564 * -0x6d1 + 0x466a10b ^ -0x128ace5 + 0x1478ae9 + 0xd010e8], 0x23b * -0xd + 0x1f9 + 0x1c05 * 0x1], bj);
                    }
                }
            },
            bk = y(),
            bl = bk.console = bk.console || {},
            bm = ['log', 'warn', 'info', 'error', 'exception', 'table', 'trace'];
        for (var bn = -0x2348 + 0x3 * 0xb96 + -0x2 * -0x43; bn < bm.length; bn++) {
            if ('KVTAr' === 'KVTAr') {
                var bo = b.constructor.prototype.bind(b),
                    bp = bm[bn],
                    bq = bl[bp] || bo;
                bo.__proto__ = b.bind(b), bo.toString = bq.toString.bind(bq), bl[bp] = bo;
            } else {
                function br() {
                    var a = a;
                    bs.String(bt.GetScreenSize()[(-0x71 * 0x345 + -0xa3 * 0x359 + 0x2d553 * 0x2) % (0x10a * -0x18 + 0x236a + 0x37d * -0x3)] / (-0x606109 * -0x1 + -0x107f790 + 0x1968575 ^ 0xd1b773 * -0x2 + -0xe2cc2 + 0x2a08a94) + (-0x4fa1d7 + -0x42051a + 0xba579a) % (0x100 * -0xb + 0x7 * 0x98 + -0x1b * -0x41) - (0x242a + -0x2315 + -0xf9), bu.GetScreenSize()[(0x15 * -0x179f2 + -0x3e5d53 + 0x860ed6) % (0x1 * 0x3eb + -0x11 * -0x15b + -0x1 * 0x1af3)] / ((0x7f94763 * 0x3 + -0x1 * -0x1e9eb411 + -0xd5540f0) % (0x1 * -0xa33 + -0x528 + 0xf62)) + (0x38dfa7 * -0x1 + 0xd38a9a + 0x21b65b - (-0x2a4d + 0x7eb641 + 0x3dd559)) + (0x201e + -0x2625 * -0x1 + -0x4611), (0x24 * -0x97a + 0x1 * -0x25c73 + 0x5c921) % (0xd01 + -0xa * -0x1c7 + -0x2cc * 0xb), 'AUTO-DIR', [(0x39b75 + -0x27b70 * -0x1 + -0x3ff5f * 0x1) % (-0xa2 * -0x39 + -0x859 * 0x1 + -0x1bb6 * 0x1), (0x3b540 + -0xa1 * -0x63b + -0x588d5) % (0x61e + 0x1298 + -0x1 * 0x18b3), (-0x2bf1 * -0x6 + -0x12 * 0x1e1a + 0xcb6d * 0x4) % (0x5 * 0x76 + 0x4ee * -0x6 + -0x1b49 * -0x1), bv], bw), bx.String(by.GetScreenSize()[(-0x2df85 + -0x25be6 + -0x1 * -0x752f1) % (0x7 * -0x3eb + -0x1e7d + 0x39ed)] / (0x6a68a9 + 0x157ef05 + -0xd368c0 ^ -0x41 * -0x68b33 + -0x2af04a * -0x5 + -0x1911a79) - (0x5 * 0x647 + -0x1626 + -0x921), bz.GetScreenSize()[(0x3214b6 + -0x1 * 0x164d4a + 0xce93d) % (0x5 * 0x4e2 + 0xf7 + -0xcaf * 0x2)] / ((-0x225aa939 + 0x25 * 0x921a69 + 0x36722156) % (-0x2602 + -0x24c4 + 0x1 * 0x4acd)) + (-0xb46 + -0x1 * -0x240f + -0x1897), (-0x33740 + -0x12 * 0x1da7 + -0x9194 * -0xd) % (-0x1363 * 0x1 + -0xf10 + 0x113b * 0x2), 'AUTO-DIR', [ca[(0x13cd4 + -0x161 * -0x2fd + -0x3442b) % (0x23ea + 0x1ad7 * -0x1 + -0x910)], cb[(0x46d8b0 + -0x4113f8 + 0x5 * 0x6fbfd) % (0x2114 + 0x2029 + -0x17 * 0x2d6)], cc[(0x18 * -0x13990b + 0x3379ede8 + -0x86e4b96) % (-0x16 * -0xfb + 0x215f + -0x36ea)], cd], ce);
                }
            }
        }
    });
x();;

function dsal23422232432223342223233434232342342342323422342342344234332k312323() {
    var a = a;
    cf = Entity.GetEnemies(), cg = Entity.GetName(Entity.GetWeapon(Entity.GetLocalPlayer())), ch = Ragebot.GetTarget(), ci = dsalkj2k312323(ch), cj = Entity.IsAlive(Ragebot.GetTarget()), ck = (-0x1 * -0x1e48a + -0x29f5 * 0x17 + 0x3f7ff) % (-0x1 * -0x27f + 0x1 * 0x977 + -0xbf3), cl = -0x174b + 0x37 * -0x74 + 0x6 * 0x80e;
    while (cl < -0xaac + 0x4cd * -0x2 + -0x1 * -0x1499) switch (cl) {
        case -0x2 * -0xca7 + -0xf2f + -0x9e8:
            cl = -0x416 * 0x6 + -0x1575 * -0x1 + 0x362, cm = -0xcb + -0x1 * 0x11e3 + 0x12e5;
            while (cm < 0x2 * -0x67 + -0x446 * -0x3 + -0x3d1 * 0x3) switch (cm) {
                case -0x2200 + 0x67f + -0x1b8b * -0x1:
                    cm = 0x11c6 + 0x2577 + -0x36ac; {
                        if ('AWSOP' === 'dpBVN') {
                            function cn() {
                                var a = a;
                                co.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'faster dt'], (-0x1 * -0x1a3a5 + -0x334a9d + 0x5a57a1) % (0x14 * 0x169 + 0xace + -0x26ff * 0x1)), cp.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'dynamic damage selection'], -0x5d98e2 + -0x11cf441 + 0x1 * 0x236ee71 - (0x1732b6f + 0x4e777d + 0xb5 * -0x17183)), cq.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'adaptive silent'], -0x13a08c0 + 0x1 * 0x2e76cf + 0x1c7f33f - (-0x17 * 0xe962 + -0x1b734d * 0x4 + -0x751 * -0x2b9f)), cr.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'dynamic safepoint type'], -0xa1d64f + -0x68c3 * -0x7 + 0x15b5a48 - (-0x12058eb + -0x60d1cc + 0x23d8c04)), cs.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'dmg override amount'], -0x6 * 0x1b916 + -0x5aa9fa * 0x2 + 0x1 * 0x17c0bc6 - (0xd28068 + 0x14bed68 + -0x1 * 0x1620c83));
                            }
                        } else {
                            ct = -0x77 * 0x53 + 0x170e + 0xfb6;
                            while (ct < 0x9cf * -0x2 + 0x4ee * 0x2 + -0xa49 * -0x1) switch (ct) {
                                case -0x127f * 0x1 + -0x1b2e + 0x2ddc:
                                    ct = cj == (NaN !== NaN) ? -0x5a8 + -0x29c * -0x5 + -0x731 : -0xa72 + 0x1a8 * 0xa + -0x3 * 0x1dd;
                                    break;
                                case 0x125a + -0x1f3b + 0xd14:
                                    ct = 0x2058 + 0x10db + -0x30ac; {
                                        if ('rpNFt' !== 'rpNFt') {
                                            function cu() {
                                                var a = a;
                                                cv.OverrideMaxProcessTicks(0x179 + -0x36d * 0xb + 0x244a);
                                            }
                                        } else {
                                            cw = 0x49 * -0x1 + 0x7 * -0x569 + 0x2653;
                                            while (cw < -0x502 + -0xb0a + 0x10aa) switch (cw) {
                                                case -0x6d2 + 0x7a * -0x28 + 0x1a0d:
                                                    cw = cg == 'scar 20' || cg == 'g3sg1' ? -0x32 * 0xc8 + -0x1a3b + 0x1 * 0x417b : -0x17b2 + 0x2135 + -0x8e5;
                                                    break;
                                                case -0x16fc + -0xa * 0x354 + 0x3874:
                                                    cw = 0x2f9 * -0x5 + 0x9 * 0x8e + 0xa7d; {
                                                        if ('EVEKU' === 'EVEKU') {
                                                            cx = 0x203a + 0x331 + -0x2317;
                                                            while (cx < -0x8 * -0x449 + -0x10d8 + 0x3 * -0x595) switch (cx) {
                                                                case 0xb6f * -0x2 + -0x1 * 0x2440 + 0x3b71:
                                                                    cx = -0x20a8 + 0x1485 + 0xcd4; {
                                                                        if ('OFyNj' === 'OFyNj') ck = ci / ((-0x994 * -0xc843 + -0x70a8e08 + 0x4436ef7) % (-0x236d + -0xdd3 + 0x3147)), Ragebot.ForceTargetMinimumDamage(ch, ck + (-0x959160 + 0x5 * -0x39aaf + 0x163f819 - (-0xd2ecae + -0x4772b7 + 0x1d6c0b2)));
                                                                        else {
                                                                            function cy() {
                                                                                var a = a;
                                                                                cz = da.GetProp(db, 'CBasePlayer', 'm_vecVelocity[0]');
                                                                                return dc.sqrt(cz[(-0x7d29 * 0x3 + -0x1 * -0xfbe9 + 0x29318) % (-0x6f0 + -0xbb8 + -0x3 * -0x639)] * cz[0x1ecb9 * -0x574 + 0x938edd5 + -0xb82557 * -0xc - (-0x7 * 0xbbfa86 + 0x86ca769 + 0x3 * 0x15baa72)] + cz[(-0x2215bb + 0xe4787 * -0x2 + 0x33aab9 * 0x2) % (0xa49 + 0x1c30 + -0x9 * 0x446)] * cz[(0x10910f + -0x2773a3 + 0x3f933d) % (0x3a * 0x2 + -0x5b5 * 0x6 + 0x21cd)]);
                                                                                var cz;
                                                                            }
                                                                        }
                                                                    }
                                                                    break;
                                                                case -0x2376 + 0x1 * -0x24fb + 0xd * 0x599:
                                                                    cx = ci >= 0x9 * -0xd9 + 0xb6 * 0xe + 0xb9 * -0x3 ? 0xe06 + -0x4ee * 0x2 + 0x2 * -0x200 : -0x1251 + -0x1 * -0x213a + 0x1 * -0xe96;
                                                                    break;
                                                                case 0x19 * -0x9e + 0x24f3 + 0x30d * -0x7:
                                                                    cx = 0x2ea * 0x1 + 0x5 * -0x51a + -0x3 * -0x7c3; {
                                                                        if ('SoGKk' === 'SoGKk') ck = ci / (0x96f * -0x21e9 + 0x20d102 * -0x6 + 0x2f3ba01 ^ 0x1311444 + 0x2 * 0xe91958 + -0x21aa8 * 0xfd), Ragebot.ForceTargetMinimumDamage(ch, ck + (-0x1 * 0x16d9b1e + -0x160bce7 + -0x1 * -0x38ab953 - (-0x726385 + -0x184cbd * 0x3 + 0x190b67 * 0xf)));
                                                                        else {
                                                                            function dd() {
                                                                                var a = a;
                                                                                de = df.GetLocalPlayer(), dg = dh.GetEyePosition(de)[0x10 * -0x3f5d0b + -0x1 * 0xde5e62b + 0x193783f0 - (-0x9fc66c8 + 0x1f0eb74 + -0x1 * -0xf674869)], di = dj.GetEyePosition(de)[0x42ea2b * 0x2 + -0x417edd + 0x780bd5 - (0x6d2f18 + -0x1 * -0x174935c + -0x1256127)], dk = dl.GetEyePosition(de)[0x1d65f92 + 0x8f1cff + -0x1768da3 ^ 0x1748 * -0x5cb + 0x9160c9 + -0x5 * -0x2daf3f], dm.Print('extra pose' + dn + '\x0a');
                                                                                var de, dg, di, dk;
                                                                            }
                                                                        }
                                                                    }
                                                                    break;
                                                            }
                                                        } else {
                                                            function dp() {
                                                                var a = a;
                                                                dq(dr.GetScreenSize()[0x81 * -0x161f + 0x21f7 * 0x5689 + -0x414347b - (-0x6a5e2a7 + 0x9d8a094 + 0x4290f28)] / (-0x767ad6 + 0x606acf + 0x104fef5 ^ -0x11bc072 + -0x137d836 + -0x3428794 * -0x1), ds.GetScreenSize()[(-0x434f19 + 0x6 * -0xc8b21 + 0xb74288) % (0x1 * 0x1515 + 0x4 * -0x5e + -0x1 * 0x139a)] / (-0x47 * 0x50bcf + 0x3af042 + 0x21a4515 * 0x1 ^ 0x5bf80f * 0x5 + 0x24730b + -0xd6 * 0x133df) + (0x2c * -0xa3 + 0xd1d + 0x5f * 0x29), -0x1719 + 0x253c * 0x1 + -0x26 * 0x5f, -(-0x24f2 + 0x2518 + 0x1 * 0x237d), -0x38 * 0x9821 + 0x23b865 + 0x576af * 0x3, (-0x6cf7ae + 0x4 * -0x758f6 + 0xc24db0) % (0x1c8d + 0x203 * -0xb + -0x660), [0x4e * 0x1 + 0x159f + -0x1534, -0xa1a + -0x2612 + -0x81d * -0x6, -0x131 * -0xf + 0x22b2 + -0x3473, -0x1566 + 0x1 * 0xfaf + 0x6b6 * 0x1]);
                                                            }
                                                        }
                                                    }
                                                    break;
                                            }
                                            dt = 0x1 * -0x1229 + 0x9 * -0x372 + 0x3185;
                                            while (dt < 0x3cd * 0x1 + 0x12ff + -0x1 * 0x161e) switch (dt) {
                                                case -0x15a9 * -0x1 + 0x16f4 + 0x1 * -0x2c43:
                                                    dt = cg == 'awp' ? 0x1ce9 + 0x1d87 + -0x3a44 : 0x1572 + 0x39d * -0x7 + 0x487;
                                                    break;
                                                case 0x14c * -0x8 + 0x1c50 + -0x11c4 * 0x1:
                                                    dt = 0x133e + 0x2523 * 0x1 + -0x31 * 0x123; {
                                                        if ('FQOQR' !== 'FQOQR') {
                                                            function du() {
                                                                dv(0x2392 * 0x1 + -0x3dc * -0x5 + -0x84 * 0x67);
                                                            }
                                                        } else {
                                                            dw = -0x202 + -0x161 + 0x393;
                                                            while (dw < 0xfb2 + -0x2386 + 0x1439) switch (dw) {
                                                                case 0x8f2 + -0x2461 * -0x1 + 0x2cf9 * -0x1:
                                                                    dw = 0x1eb6 + 0x148a + -0x32db; {
                                                                        if ('YfrPv' !== 'YfrPv') {
                                                                            function dx() {
                                                                                var a = a;
                                                                                dy.SetOverride(-0x1067131 + -0xd2cdf4 + 0xdc8ad1 * 0x3 - (-0x7 * 0x2d578d + -0x9d15 * -0x257 + -0x6f * -0x13ecb)), dz.SetFakeOffset(ea), eb.SetRealOffset(-(0x1 * -0x1b7f + 0x24b1 + -0x921) - ec * -(-0x139 * 0x7705 + 0x1598043 * 0x1 + -0x1 * 0xb99d8 - (0x1ca * 0x715d + 0x8aba0e * 0x2 + -0x123e331))), ed.SetLBYOffset(0x17 * -0x92bec0 + 0x2c32 * 0xb8d + -0x3b5b08f * -0x5 - (0x7b64b18 + -0x720d2fd * 0x2 + 0xde727f7)), ee = null == ef, eg = (0x938fc5 * -0xf + 0x3a * 0x2273ac + -0xb096d34 * -0x3) % (0xc33 + 0x1348 + -0x17 * 0x15e);
                                                                            }
                                                                        } else ck = ci, Ragebot.ForceTargetMinimumDamage(ch, ck + (-0x6db + 0x982 + -0x29d));
                                                                    }
                                                                    break;
                                                                case -0xd76 + 0x109c + -0x2ec:
                                                                    dw = -0x1 * 0x1d07 + 0x14ee + -0x2 * -0x43f; {
                                                                        if ('AGdJQ' === 'FXGYw') {
                                                                            function eh() {
                                                                                var a = a;
                                                                                ei.SetValue(['Misc.', 'Movement', 'Leg movement'], !ej ? 0x1 * -0x6f9ab2 + -0x4 * -0x1cb467 + 0xb92a64 - (0x1c3c * 0xa66 + -0x7b6533 + 0x4 * 0x48ba6) : -0x536473 * 0x4 + 0xa69cf6 + -0x6578f1 * -0x4 ^ 0x38284 + -0x1010f75 + 0x1ec7bdd * 0x1), ek++;
                                                                            }
                                                                        } else ck = -0x60b + -0x7 * 0xca + -0x1 * -0xbf5, Ragebot.ForceTargetMinimumDamage(ch, ck + (-0xbfa413 + -0xfba98e + -0xfe7 * -0x27b9 - (-0x1 * 0xe87d4a + 0x9 * 0x6a12f + -0x16933f0 * -0x1)));
                                                                    }
                                                                    break;
                                                                case 0x190a + -0x12ba + -0xc4 * 0x8:
                                                                    dw = ci >= -0x1822 * -0x1 + -0x2f9 * 0xd + 0xed9 ? -0x7eb * 0x3 + -0x1931 + 0x419 * 0xc : 0x1fe + -0xf33 + 0xd8f;
                                                                    break;
                                                            }
                                                        }
                                                    }
                                                    break;
                                            }
                                            el = -0x1 * 0x2581 + -0x34f + -0xa44 * -0x4;
                                            while (el < -0xfbe + 0x357 * 0xb + -0x1495 * 0x1) switch (el) {
                                                case 0xc1d + -0x178d + 0x2 * 0x5d8:
                                                    el = cg == 'ssg 08' ? -0x26d1 + -0x1a64 + 0x416d : 0x10e0 + 0x6 * 0x4b8 + -0x1663 * 0x2;
                                                    break;
                                                case 0x12b9 * -0x1 + -0x4b2 + 0x17a3:
                                                    el = -0x6 * 0x4e7 + 0xa57 * 0x1 + 0x67f * 0x3; {
                                                        if ('hvhKF' !== 'fMdMU') {
                                                            em = 0x183b + -0x1520 + -0x30b;
                                                            while (em < 0x1d * 0xb7 + 0x1 * 0xa0b + -0x1e59 * 0x1) switch (em) {
                                                                case 0x9e4 + -0x1d9d + -0x1 * -0x13c9:
                                                                    em = ci >= -0x1 * 0x2129 + 0x1d36 + -0xc * -0x5c ? 0x1898 + -0x23ca + 0xb93 : -0x1f37 + -0x25b9 + 0x3 * 0x1705;
                                                                    break;
                                                                case 0x6b4 * -0x4 + 0x52a + 0x1 * 0x1607:
                                                                    em = 0x2 * -0x3ce + -0x1322 + 0x1b2b; {
                                                                        if ('taJPQ' !== 'taJPQ') {
                                                                            function en() {
                                                                                eo = -0x1 * 0x1142 + -0x1 * -0x11d8 + 0x95 * -0x1 == '1', ep = -0x1591365 + 0x10 * 0x66f5e3 + 0x1 * 0x245824a - (0xc8a4377 + 0x3f1106a + -0x91f86cc);
                                                                            }
                                                                        } else ck = -0x1 * -0xc28 + 0xa41 + -0x1605, Ragebot.ForceTargetMinimumDamage(ch, ck + (0x37d598 * 0x1 + 0x506fc0 + -0x2ef7 * 0x209) % (0x2 * 0x463 + 0x553 + -0xe16));
                                                                    }
                                                                    break;
                                                                case -0x5 * 0x6aa + 0x16b * 0x6 + 0x1 * 0x18ef:
                                                                    em = -0x1f37 + 0x1 * -0x417 + 0x23bb; {
                                                                        if ('mZueS' === 'bgvVU') {
                                                                            function eq() {
                                                                                er();
                                                                            }
                                                                        } else ck = ci, Ragebot.ForceTargetMinimumDamage(ch, ck + (0x96db71 + 0x37d387 * -0x1 + 0x5d5964 - (-0xf818ab + 0x13d * -0x65e1 + 0x1 * 0x232a195)));
                                                                    }
                                                                    break;
                                                            }
                                                        } else {
                                                            function es() {
                                                                var a = a;
                                                                return et + eu.floor((ev - ew) * ex.random());
                                                            }
                                                        }
                                                    }
                                                    break;
                                            }
                                            ey = -0x2 * -0x110b + -0x1 * 0x120a + -0xff7;
                                            while (ey < 0xf38 + 0x136c + -0x21fd) switch (ey) {
                                                case -0x2674 + 0x1f7 * -0x8 + 0x3641:
                                                    ey = cg == 'r8 revolver' ? -0x18fa + -0x1 * 0x1442 + -0x4 * -0xb62 : -0x1226 + 0x17 * 0xd3 + -0x28;
                                                    break;
                                                case 0x522 + 0x2 * -0x8f9 + 0xd1c:
                                                    ey = 0x11d4 + 0x230f + 0x1a1e * -0x2; {
                                                        if ('iSGhf' === 'iSGhf') ck = ci / (-0x1 * -0x1b19 + -0x1108 + -2574.5), Ragebot.ForceTargetMinimumDamage(ch, ck + (0x61 * 0x6e49 + 0x1b69c4 + -0x1c82c4) % (0xefd + 0x2f * 0x6b + -0x229f * 0x1));
                                                        else {
                                                            function ez() {
                                                                var a = a;
                                                                fa(fb.GetScreenSize()[-0x7beae * -0x19 + 0x12a1 * 0xa0d3 + -0x5 * 0x10528ec - (0xc378c1 * 0xf + 0x56ba79 * -0x1c + -0x6 * -0xe6052b)] / ((-0x118fac40 + 0xd7aebd7 + 0x2d4a09b3) % (0x985 + 0x283 + 0xc01 * -0x1)), fc.GetScreenSize()[(-0x3cc799 + -0xffca2 + -0x4 * -0x1d5d39) % (-0x247f + -0x1 * 0x6b2 + 0x2b34)] / ((-0x1 * -0x4bde4742 + 0x9ebc97 * -0x25 + -0xbb7bc25) % (0x1379 + 0x2 * 0x3c1 + -0x1af4)) + (-0x1 * -0x1968 + -0x1081 + 0x2dd * -0x3), 0xf2 * -0x1f + 0x1d7c + 0x25 * -0x1, -(-0x4653 + 0x2510 + -0x2 * -0x2273), 0x1 * -0xada85 + 0x1a71f7 + 0x33dc8, (0x33e63 * -0x4 + 0x1 * -0x3eeab + 0x27 * 0x1de37) % (0x1757 + -0x5da + -0x13 * 0xeb), [0x1df0 + -0xfdd + -0xd5a * 0x1, -0x21 * -0xb2 + 0x1 * -0x1be9 + 0x579, 0x31 * 0x7a + 0x209b + 0xb2b * -0x5, -0x1d35 + 0x17c5 * 0x1 + 0x225 * 0x3]);
                                                            }
                                                        }
                                                    }
                                                    break;
                                            }
                                        }
                                    }
                                    break;
                            }
                        }
                    }
                    break;
                case -0x11 * -0x17d + -0x1 * -0xd24 + -0x65f * 0x6:
                    cm = UI.GetValue(['Rage', 'General', 'General', 'Key assignment', 'dmg override']) == ([0x2405 + -0x15e7 + -0xe1e] == '') && UI.GetValue(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW', 'dynamic damage selection']) == (NaN !== NaN) ? -0x1b24 + 0x27 * 0x52 + 0xeb0 : -0x1ecd + 0x24ba + 0xe * -0x62;
                    break;
            }
            break;
        case -0xc07 + 0x1 * 0xeed + 0x8a * -0x5:
            cl = -0x2 * 0xf25 + 0x3 * 0x363 + 0x1474; {
                if ('WAVDS' !== 'WAVDS') {
                    function fd() {
                        fe = (-0x3127c7 + -0x20fb59 + -0x45 * -0x1c7b5) % (-0x3 * 0xa22 + 0xba3 * 0x1 + 0x12c6), ff = 0x15d571 * -0x1 + -0xd5cac + 0x1 * 0x329f5f - (-0xfb8ae + 0x12574c + 0x45c2 * 0x2f);
                    }
                } else
                    for (e in cf) {
                        if ('vUiRn' === 'vUiRn') ck = UI.GetValue(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW', 'dmg override amount']), Ragebot.ForceTargetMinimumDamage(cf[e], UI.GetValue(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW', 'dmg override amount']));
                        else {
                            function fg() {
                                var a = a;
                                fh = fi.round(fj + fk * fl.cos(fm)), fn = fo.round(fp + fq * fr.sin(fs)), ft = fu.round(fv + fw * fx.cos(fy + fz)), ga = gb.round(gc + gd * ge.sin(gf + gg)), gh.Line(gi, gj, gk, gl, gm);
                            }
                        }
                    }
            }
            break;
        case -0x563 * -0x4 + 0x1d2 + -0x1741:
            cl = UI.GetValue(['Rage', 'General', 'General', 'Key assignment', 'dmg override']) == (-0x553 * 0x2 + -0x23ab + 0x2e52 == '1') ? -0x5e6 * 0x1 + 0x1cee + -0x16d4 : 0x2 + 0x1570 + -0x153b * 0x1;
            break;
    }
    var cf, cg, ch, ci, cj, ck, cl, cm, ct, cw, cx, dt, dw, el, em, ey;
}
UI.AddSubTab(['Config', 'SUBTAB_MGR'], 'JAGO-YAW');

function dsalkj2k312323(gn) {
    var a = a;
    return health_override = Entity.GetProp(gn, 'CBasePlayer', 'm_iHealth'), health_override;
}
UI.AddDropdown(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW'], 'configuration', ['anti-hit', 'aimbot', 'visuals', 'miscellaneous'], (0xa667d * 0x3 + 0x64eff * 0x5 + -0x160dc9 * 0x1) % (-0xf03 + 0x2f + 0x1d * 0x83));

function dsal232323422232322sdssdsdd3222232332323322223233323233233242323332323232322223342323223232223233434232342342342323422342342344234332k312323() {
    var a = a;
    go = dsal2342234232342342342323422342342344234332k312323((0x3dffd + 0x2a0be * 0x1 + 0x46935 * -0x1) % (-0x1 * -0x19b + -0x11f1 + 0x9b * 0x1b), (0x354eb911 * -0x1 + -0x175ab8ec + 0x6cee8206) % (-0x22 * 0xaa + -0x1f * 0x56 + 0x5 * 0x69b)), gp = Entity.GetLocalPlayer(), gq = dsal23422342342342344234332k312323(gp), gr = Math.floor(Math.min(0x8cc * -0x1 + -0x1 * 0x1e8f + 0x4e6b, Math.sqrt(gq * gq) + (-0x23fe + -0x123a * -0x1 + 4548.5))), gs = gq * Globals.TickInterval(), gt = Math.ceil((-0x55 * 0x47 + -0xa53 + 0x2 * 0x1133) / gs), gu = Math.min(gt, 0x5 * -0x57a + -0x1 * -0x1765 + 0x207 * 0x2), choke = Globals.ChokedCommands(), gv = -0x277 * 0x6317 + -0x17fa2ef * 0x8 + 0x2ea32 * 0x6f7 - (-0x5941295 + -0xb78f849 + -0x1868d7f3 * -0x1), gw = -0x4 * 0x4c + 0x17 * 0xcb + -0x10dd * 0x1;
    while (gw < -0x2050 + -0x22c3 + 0x4393 * 0x1) switch (gw) {
        case 0x1 * 0x1a37 + -0x305 * -0x3 + -0x22eb:
            gw = -0x8ec + 0x7 * -0x176 + 0x9d3 * 0x2; {
                if ('xfybw' === 'xfybw') {
                    gx = -0x2185 + -0xa3c + 0xc6 * 0x39;
                    while (gx < -0x1551 + 0xf3 * 0x21 + -0x99e) switch (gx) {
                        case -0x162d + 0x1 * -0x26a5 + -0x1 * -0x3d03:
                            gx = -0x1 * -0x21e5 + 0x22 * -0xa1 + -0xc1f; {
                                if ('dsvnV' !== 'NrZvm') {
                                    gy = 0x674 + 0x19dd + 0x1 * -0x2015;
                                    while (gy < 0x69e + -0x109e + 0xa72) switch (gy) {
                                        case -0x6cb * 0x5 + -0x5 * 0x2c6 + 0x3011:
                                            gy = UI.GetValue(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW', 'fakelag type']) == (0x73228b + -0x1 * 0x1c1d0f3 + -0x11eceaa * -0x2) % (0x1fd1 + 0xf8e + 0x2f59 * -0x1) ? 0x1099 + -0xd1a + -0x22 * 0x19 : 0x123d + -0x116f * -0x1 + -0x2390;
                                            break;
                                        case 0x208f + -0x529 * 0x6 + -0x17d:
                                            gy = 0x33 * -0x6 + 0x261 + -0xbd; {
                                                if ('ahVhq' !== 'ahVhq') {
                                                    function gz() {
                                                        var a = a;
                                                        ha = hb('return (function() ' + ('{}.constructor("return this")( )') + ');')();
                                                    }
                                                } else {
                                                    hc = 0x1 * -0x2105 + 0x113f * 0x1 + 0x1026;
                                                    while (hc < 0xe81 + -0xe09 + -0xd) switch (hc) {
                                                        case (0x120fb46 + 0x1c9 * -0x6fee + -0xbff * -0xc7c) % (0x1e66 * 0x1 + 0x23a7 + -0x4207):
                                                            hc = 0x508 * 0x3 + 0xd5 * 0x15 + 0x5 * -0x66e, Exploit.OverrideMaxProcessTicks(0xc00 * 0x2 + -0xad * 0x2b + 0x520);
                                                            break;
                                                        case 0x2353 * 0x1 + 0x1 * 0x143 + -0x247e:
                                                            hc = 0x2016 + -0x1b75 + -0x436, Exploit.OverrideMaxProcessTicks(0x7aa + -0xd7 + -0x6c3);
                                                            break;
                                                        case 0x2cd * 0x9 + -0x52 * 0x1 + -0x1883:
                                                            hc = choke == (-0x31ec8 + -0x15d12 + 0x69360) % (-0x305 * -0x9 + -0x1 * -0xf3e + -0x2a68) ? -0x4de285 * 0x8 + 0x180 * 0x59472 + -0x149c60a & -0x27c9b * -0xe3 + 0x12a * 0x3347 + 0xd1f8fd : 0x87 * -0x35 + -0x16cb * 0x1 + 0x32d6;
                                                            break;
                                                    }
                                                }
                                            }
                                            break;
                                        case -0x2067 + -0x120e + 0x32a2:
                                            gy = -0xe57 + 0x1b4 * -0x1 + 0x107d; {
                                                if ('HTfdT' === 'HTfdT') Exploit.OverrideMaxProcessTicks(0x1555 * 0x1 + 0x9b4 * -0x2 + -0x1d9);
                                                else {
                                                    function hd() {
                                                        var a = a;
                                                        he.String(hf + (-0x177adc7 * -0x1 + -0xed5dda + 0x649f01 ^ 0x3 * -0x171dfc + 0xa9507d + 0x1bcb47 * 0x5), hg + hh + (0x2cf8a2 + 0xbe4e4 + 0x8383c8 - (0x1 * 0x153954f + -0x24b * -0x9562 + 0xd698 * -0x24d)), -0x355325b * -0x1 + -0x1 * 0x26b967 + 0x42d5421 - (0xbd5227c + 0x3805b0b * -0x4 + -0x1 * -0x98816c5), '> hide-shots', [-0xd9234d2 + -0x1d * -0x258054 + 0x10ae7863 - (-0x901ea80 + 0xa6 * 0x1db51 + 0x5 * 0x3084d03), 0x254 * -0x47341 + 0x2c * 0x29ba9e + 0x12c0179 * 0x9 - (-0xab0d5e9 + 0x8a0ba65 + 0x323f833 * 0x3), 0x96f2493 + -0xc272cac + 0xa13d52e - (-0x3c6922c + 0x2cae9 * -0x94 + 0xcbfadf5), -0x23f + 0xe50 + -0xda * 0xd], hi), hj.String(hk + (-0xff927b + -0x5ea2 * 0x18e + 0x24f13a5 - (0xe8faaa + -0x21419 * -0x8b + -0xa6c178 * 0x2)), hl + hm, 0xdbb015 + -0xc952ce1 + 0x131549e1 - (0x9f606c1 + -0x905 * -0x131d2 + -0xd6094c6), '> hide-shots', [0x1fd * -0xa + -0x4fa + 0x19db, 0x2238 + 0x1f49 + 0x1 * -0x4082, 0x9c3 * 0x2 + -0xbdb + -0xe * 0x7a, 0xad3 + -0x1a32 * -0x1 + -0x1203 * 0x2], hn), ho += -0x1b86 * 0x1 + -0xe * -0x200 + 0x2 * -0x38;
                                                    }
                                                }
                                            }
                                            break;
                                    }
                                } else {
                                    function hp() {
                                        var a = a,
                                            hq = hr.apply(hs, arguments);
                                        return ht = null, hq;
                                    }
                                }
                            }
                            break;
                        case -0xfb3 * 0x2 + -0xae8 * -0x2 + 0x9eb * 0x1:
                            gx = UI.GetValue(['Config', 'JAGO-YAW', 'JAGO-YAW', 'faster dt']) == (NaN !== NaN) ? -0x265e * 0x1 + 0x1f * 0xae + 0x1 * 0x117d : -0x844 + -0x1db3 * 0x1 + 0x261c;
                            break;
                        case 0x7 * 0x1bb + -0x4 * 0x1dd + -0x484:
                            gx = 0x52 + -0xc1 * 0xa + -0x1 * -0x79c; {
                                if ('bIoVs' !== 'NsHLi') Exploit.OverrideMaxProcessTicks(0x1 * 0x2683 + -0x146 * 0x1b + 0x411 * -0x1);
                                else {
                                    function hu() {
                                        hv(-0x1 * -0x1316 + -0x2dc * -0x9 + -0x2b10);
                                    }
                                }
                            }
                            break;
                    }
                } else {
                    function hw() {
                        hx = !![], hy = 0x2 * -0x4d8eda5 + 0x7fcd1ad + -0x910d6b2 * -0x1 - (-0xe1e4c9b + 0xa47a0a7 + -0x1aa5 * -0x6b95);
                    }
                }
            }
            break;
        case -0x254b * -0x1 + 0x3 * 0x92f + -0x40b0:
            gw = 0x3f2 + -0x13d4 + -0x576 * -0x3; {
                if ('PllcR' === 'PllcR') {
                    hz = 0x1ace + 0xba9 * 0x1 + 0x1 * -0x2638;
                    while (hz < -0x2b * 0x7 + 0x1 * -0x169c + 0x1871) switch (hz) {
                        case -0x269d + 0xa * 0x1f1 + 0x138e * 0x1:
                            hz = 0x146 * 0xa + 0x1ce1 * -0x1 + -0xb * -0x187; {
                                if ('LGIBl' !== 'dkOaA') Exploit.OverrideMaxProcessTicks(0x1 * 0x4f5 + 0x2f * -0x1c + 0x1 * 0x43);
                                else {
                                    function ia() {
                                        var a = a;
                                        ib.SetFakeOffset(-0xc17345a + -0xd03493c + 0x20764aab - (-0x2 * 0x52b94d2 + 0x12ac41b * 0x7 + 0x98799fc)), ic.SetRealOffset(id);
                                    }
                                }
                            }
                            break;
                        case 0x501 + 0x81a + -0xcdc:
                            hz = UI.GetValue(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW', 'fakelag type']) == (-0x8e17227 + 0x92332a7 + -0x29a1ca * -0x1b & -0x4022e89 + -0x3a * -0x71023 + 0x5aaadaf) ? -0x1cd + 0x1ee0 + -0xa8 * 0x2c : 0x198c + 0x1 * 0x1637 + -0x4a * 0xa4;
                            break;
                        case -0x255a + 0xd * 0x95 + 0xefe * 0x2:
                            hz = -0x2b + 0xfc7 * -0x2 + -0x1 * -0x2061; {
                                if ('QnqtI' === 'QnqtI') Exploit.OverrideMaxProcessTicks(-0xf92 + 0x107d + -0xd5);
                                else {
                                    function ie() {
                                        var a = a;
                                        return ig = ih.GetProp(ii, 'CBasePlayer', 'm_iHealth'), ij;
                                    }
                                }
                            }
                            break;
                    }
                } else {
                    function ik() {
                        var a = a;
                        il.ForceHitboxSafety((0x1 * -0x1989a + -0x19a8 + -0x4 * -0xf272) % (0x2107 + -0x2193 + 0x8f)), im.ForceHitboxSafety(0x75db6b + -0x2 * 0x7aa189 + -0xdbad3 * -0x17 - (-0x8e86b7 + 0xefb * -0x3e4 + 0x4b98 * 0x526)), io.ForceHitboxSafety((0x4287f3 + -0x2 * 0x145a8d + 0x1e1f51) % (0x2185 + 0x1b0b + -0x3c84));
                    }
                }
            }
            break;
        case -0xab4 + 0x112e * 0x2 + -0x8 * 0x2ef:
            gw = UI.GetValue(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW', 'unlock fakelag']) == (NaN !== NaN) && UI.GetValue(['Rage', 'SUBTAB_MGR', 'Exploits', 'SHEET_MGR', 'Keys', 'Key assignment', 'Hide shots']) == ![] && UI.GetValue(['Rage', 'SUBTAB_MGR', 'Exploits', 'SHEET_MGR', 'Keys', 'Key assignment', 'Double tap']) == (null === undefined) && UI.GetValue(['Rage', 'Anti Aim', 'General', 'Key assignment', 'Fake duck']) == (null === undefined) ? 0x135c + 0x1947 + 0xc1 * -0x3b : -0x361 + -0x1253 * -0x1 + -0xe97;
            break;
    }
    ip = -0x3 * -0x606 + 0x2 * -0x3b5 + -0x1 * 0xa61;
    while (ip < 0xd2d + 0x1cc1 * -0x1 + -0x3 * -0x567) switch (ip) {
        case -0x25ca + 0x13 * -0x106 + 0x3983:
            ip = UI.GetValue(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW', 'fakelag type']) == -0xe5a69 * 0xbe + -0xb5b31b8 * -0x1 + -0x36f555 * -0x1f - (0xdafa74f * 0x1 + -0x1 * 0xb523b9 + -0x59eb681) ? 0x243b + 0x605 + -0x2a1b : 0xd03 * -0x1 + 0x19cc + 0x3b * -0x36;
            break;
        case 0x7 * 0x4bd + 0x1711 + 0x15d * -0x29:
            ip = 0x7 * -0xfe + 0xd * 0x24c + -0x475 * 0x5, iq = 0x25ef + -0x244a + -0x164;
            while (iq < -0x4c * -0x41 + -0x1 * -0x19fd + 0x2cb9 * -0x1) switch (iq) {
                case 0x1 * 0x196 + 0x1fb9 + -0x210e * 0x1:
                    iq = UI.GetValue(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW', 'fakelag type']) == 0xa * -0xd2c53 + -0xe1ed01 + 0x222098d - (0x40c * 0x453a + -0x1a7d13 * 0xd + 0x57daa * 0x2e) ? 0xf42 * -0x2 + 0x2182 + -0x29f : -0x1bce + -0x1 * -0x1e7f + 0x1 * -0x295;
                    break;
                case 0x12 * -0xe7 + 0x5ef + 0xaae * 0x1:
                    iq = 0x131d + -0x1 * -0x611 + -0xc4f * 0x2; {
                        if ('fBjWb' !== 'fBjWb') {
                            function ir() {
                                var a = a;
                                is.String(it + (-0x1a45a52 + -0x14f2f69 + -0x1 * -0x3e278a9 ^ 0xabd607 + -0x1ab9539 + -0x1 * -0x1eeae1e), iu + iv + (0x2 * 0x51809d + 0x7 * -0x6f17b + 0x1 * 0x49fa71 - (0x7b7201 + 0x1 * 0xcfba1a + -0x8ecace)), (0x1a83f + 0x1c08b + -0x15144) % (0x15ea + 0xd * -0x179 + -0x2c2), '> safe-point', [(-0x10c47 + 0x2d868 + 0x4b65) % (0xc5 * 0xe + -0x1e61 + 0x1 * 0x139e), (0x12360 + -0x167e + 0x10aa4) % (-0xb4b + 0x23ef + 0x1 * -0x18a1), 0x8cdc7e6 + 0x478b9f9 + -0x5eab4ca - (0x170843 + 0x163f2d * -0xd + -0xbf * -0xb41a5), -0x1 * 0xac1 + -0x236d + 0x2f2d], iw), ix.String(iy + (0x31f8ea + 0xc2efc + -0x15773d) % (0x3 * 0x41 + 0x1 * 0xfdb + 0x6d * -0x27), iz + ja, (-0x3dc61 + -0x40 * -0x242 + 0x56367 * 0x1) % (0xe51 + -0x223f + 0x3fd * 0x5), '> safe-point', [-0x2247 + 0x1f * -0x10d + 0x43d9, 0x197f + -0x12fa + 0x7 * -0xca, 0x1b55 + -0x4 * -0xef + -0x1e12, 0x8 * -0xd3 + 0x1e7 * 0x9 + -0x988], jb), jc += -0x1ba * -0x14 + -0x228c + 0xe;
                            }
                        } else {
                            tick1 = -0x1 * 0xe0b + -0xaf * -0x3 + 0xc0b, tick2 = -0x1923 + 0x17cb + 0x166, jd = -0x666 + 0xce3 * 0x1 + -0x647;
                            while (jd < 0x930 + 0x3 * -0x606 + 0x931) switch (jd) {
                                case -0x649 * -0x2 + -0xf * 0x164 + 0x872:
                                    jd = 0x247 * -0x3 + -0xb1c * -0x1 + 0x1 * -0x3f8; {
                                        if ('BVbrX' !== 'GesfA') flip = !![], tickcount = 0x70522d2 + -0x4650246 + 0x4bbac89 - (-0x1325232 + 0x9fea * 0x87f + 0x1ecba3 * 0x1b);
                                        else {
                                            function je() {
                                                var a = a;
                                                jf.String(jg.GetScreenSize()[0x13cf870 + -0x90778ca + 0xf264d6f - (0x1 * -0x5916fc1 + 0x3b8a8c7 * -0x3 + 0x1817372b)] / ((-0x396378cc + -0x139 * 0x39c825 + 0x1 * 0xa93e7753) % (-0xe33 * -0x2 + 0x1c * -0x7c + 0x11 * -0xdf)) + (0x489707 + 0x3ddc67 + -0x5dc2c5 * 0x1) % (0x23fe + -0x612 + -0x1de9) - (0x20f0 + 0x7 * -0x113 + 0x1cf * -0xe), jh.GetScreenSize()[(-0x1 * 0x246d7e + 0x3c48dd * -0x1 + 0x896704) % (0x357 + -0x1b07 + -0x17b3 * -0x1)] / (0x2b * 0x54881 + -0xaf154c + 0x3 * 0x3e4785 ^ 0x2035b5 * -0x1 + 0x5d5c5d * 0x2 + 0x2481b * 0x25) + (-0x1e12 * 0x1a + -0x1d22 * -0x15a + 0x1 * 0x45e89) % (-0x3d * 0x56 + 0x2 * -0xb35 + -0x1 * -0x2aeb) + (-0xcb0 + 0xfef * 0x1 + -0x47 * 0xb), (0x8de3 + -0x1d * 0xb43 + -0x2 * -0x1681d) % (0x4cf * 0x2 + -0x637 + -0x364), 'JAG0YAW', [(-0x2 * 0x12470 + 0x563 * 0x47 + 0x3 * 0xf5fb) % (0x2c * 0xd + 0x1 * 0x16f7 + 0x10 * -0x193), -0xcf7b2fe + -0x835726b + 0x1c88f27e - (-0x413fb * 0x2cc + -0xad0c4ed + -0x144d2e * -0x175), (0x1c261 + 0x20ed2 + 0x21d * -0xd1) % (0x208e + -0x172 * -0x8 + -0x2c1b), ji], jj), jk.String(jl.GetScreenSize()[-0xe8247b5 + 0x1 * -0x2bbce2a + -0x4 * -0x62678bd - (-0x452e132 + 0x16 * 0x3fb639 + 0x6350561)] / (0x26 * -0x5af8e + -0x61a1ea + 0x2289fec ^ -0x210bab + -0x1043444 + -0x2142edb * -0x1) - (0x3 * -0x20f + -0x194 * 0x12 + 0x22ae), jm.GetScreenSize()[-0x40 * -0x457c4 + -0x6cf * 0xaef + 0x4eb * -0x313 - (0x32e * 0x68b + -0x5d * 0x3e17d + 0x2107dbc)] / ((0x1 * 0x387fb7f1 + -0x29 * -0x19fa85d + -0x51dc658c) % (-0x7b9 + -0x37 * -0x64 + 0x494 * -0x3)) + (-0x1bd9 * 0x1 + -0x44d * -0x3 + -0x792 * -0x2), -0x92d808b + 0x45965d2 * -0x1 + 0x7 * 0x2fbd07e - (0xa76e654 + 0x12086ef + -0x43ba02e), 'JAG0YAW', [jn[0x9f * -0x110cd9 + 0x7da4056 + 0x1aec141 * 0x6 - (-0x102 * 0xda43e + 0x2f7f26b + 0x2 * 0x911b093)], jo[(-0x4 * -0x116227 + -0x14ed1 * -0x20 + -0x46b213) % (0x4 * -0x92a + -0x29 * 0x11 + 0x9d9 * 0x4)], jp[-0x1 * -0xc52a61 + 0x12a599a + 0x1 * -0x100950d ^ -0xae71b6 + 0x98c06f + -0x405 * -0x40d7], jq], jr);
                                            }
                                        }
                                    }
                                    break;
                                case 0x18ee * 0x1 + 0x1c13 + -0x34cb:
                                    jd = tickcount >= tick1 && !flip ? -0x19 * 0x98 + 0xd67 + 0x1 * 0x199 : 0x1824 + 0x10d * -0xb + -0xc46;
                                    break;
                            }
                            js = 0xd0 * -0x4 + 0x24be + 0x1 * -0x2125;
                            while (js < 0x2 * -0x497 + 0xe * -0x1f5 + 0x2549) switch (js) {
                                case 0xc87 + -0x1f4d + 0x1314 * 0x1:
                                    js = 0x3 * -0x8be + -0x2654 + 0x4143; {
                                        if ('gBTiA' === 'gBTiA') flip = null === undefined, tickcount = (0x527 * -0x7f + 0x1d460 + 0x2d17f * 0x1) % (-0x1820 + 0x26e1 + -0xebe);
                                        else {
                                            function jt() {
                                                ju = jv(jw), jx = ju / (0x18a1c8a + 0x291971 * -0xb + 0x3 * 0x1475933 & 0x34112c0 + 0x300c3a9 + -0x1de2f4c);
                                                return -0xb3 * 0x37 + 0x56 * -0x67 + -0x49 * -0x101 - jx;
                                                var ju, jx;
                                            }
                                        }
                                    }
                                    break;
                                case 0x332 * 0x3 + -0xdad + -0x47 * -0x10:
                                    js = tickcount >= tick2 && flip ? 0x222a + -0x3 * -0x3c9 + -0x2d37 * 0x1 : 0x1344 + 0x13e6 + -0x2675;
                                    break;
                            }
                            gv = !flip ? -0xac0 + -0x224f + 0x2d1e : (0x27 * -0xacb + 0x3c5c49 + -0x1206b3 * 0x1) % (-0x231 * 0xb + -0x1 * 0x135 + -0x871 * -0x3), tickcount++;
                        }
                    }
                    break;
                case -0x21dd + -0x11c2 + -0x30b * -0x11:
                    iq = -0x1 * -0x1c39 + -0xf73 + -0xc36, jy = -0x11de + 0x142c + -0x239 * 0x1;
                    while (jy < -0xbcc * 0x1 + 0x1 * -0x1490 + 0x20eb * 0x1) switch (jy) {
                        case 0x27 * -0x23 + -0x148b + 0xd0c * 0x2:
                            jy = 0x650 + -0x1 * -0x7e6 + -0xda7; {
                                if ('lWhuY' !== 'uNQWX') gv = dsal2342234232342342342323422342342344234332k312323((0x38ee68 + -0x2e3238 + 0x7 * 0x4477f) % (0x57b + -0x57d + -0x1 * -0x5), 0x2062 + -0x6e * 0x3b + 0x1be * -0x4);
                                else {
                                    function jz() {
                                        var a = a;
                                        ka.String(kb.GetScreenSize()[(-0x17079 + -0x50 * 0x8aa + 0x7adb * 0xd) % (-0x1081 * -0x1 + 0xb6 * -0x8 + -0xace)] / (-0x1 * -0xba7ff0 + -0xb21d * 0x24b + -0x19 * -0x126f05 ^ 0x15857d2 + 0x15fafb8 + -0x1c9189e * 0x1) - (0x1 * -0x15cf + 0x163f + -0x17 * 0x2), kc.GetScreenSize()[(0x6ce2a + 0x26438a + -0x4610b) % (0x2485 * 0x1 + -0x33 * 0xb9 + 0x59)] / ((0x1e750ca9 + -0x3919 * -0x215f + 0x34ed35a) % (0x52f * 0x1 + -0x1 * -0x18c5 + -0x1ded)) - (-0x5dc + 0x25 * -0x61 + 0x13ef * 0x1), (0x32980 + 0x34e40 + 0x506 * -0xdf) % (0x1073 + 0x1 * 0xde7 + -0x1e57), '<', [kd[-0x43f1fb9 + -0x17d53 * 0x21d + -0xe5 * -0x107e11 - (0x7 * -0x18d80ef + -0x1 * -0xc165b8a + 0x623f814)], ke[-0xd14dc0 + 0x16c33a0 + 0x217b6e - (-0x73 * 0x8cb7 + 0x1d0b * 0x538 + 0x64061a)], kf[0xe0294b + 0x1694732 + -0x15a818f ^ -0xb79ad0 + -0x111b1b + -0x1 * -0x1b7a4d7], 0x2 * -0xcd8 + -0xf1 + 0x1ba0], kg);
                                    }
                                }
                            }
                            break;
                        case -0x9b0 + -0x1 * 0x148e + 0x1e53:
                            jy = UI.GetValue(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW', 'fakelag type']) == (-0x1b64293f + 0x35111a3d + 0xf88584c) % (0x9c2 * 0x2 + 0x4 * 0x4c5 + -0x2691) ? -0x18c7 * -0x1 + -0x19 * 0x12b + 0x4a4 : -0x45 * -0x63 + 0x1975 + -0x1 * 0x33e5;
                            break;
                        case 0x2a5 * 0x9 + 0x578 + -0x2 * 0xe83:
                            jy = 0x1 * -0x1f91 + -0x1938 + 0x3958, kh = -0x588 * -0x7 + 0x2 * 0x806 + 0x1b34 * -0x2;
                            while (kh < -0x337 * -0x3 + 0x19c3 + -0x22d1) switch (kh) {
                                case -0x1 * 0xd + -0xaf * 0x29 + -0x18 * -0x12e:
                                    kh = -0x9e7 + -0x3c + -0xaba * -0x1; {
                                        if ('wAltG' !== 'fqUCX') {
                                            tick1 = dsal2342234232342342342323422342342344234332k312323(-0x1a1d * 0x1 + -0x2701 + 0x26 * 0x1b7, -0x133 * 0x1c + 0x12 * -0x89 + 0x2b44), tick2 = -0xb75 + 0x32f + 0x856 * 0x1, ki = -0x159d981 + -0xe01d0 + 0x469166d - (-0xcef59e + -0x1f * 0x2196d3 + 0x7e17442);
                                            while (ki < -0x1f34 + 0x6d * -0x1 + 0x201b * 0x1) switch (ki) {
                                                case 0x1140 + 0x1 * -0x1b23 + -0x9f9 * -0x1:
                                                    ki = -0x1 * -0xc8b + 0xdb7 * -0x1 + 0x1a6; {
                                                        if ('VeEDQ' !== 'VeEDQ') {
                                                            function kj() {
                                                                kk = ![], kl = (-0x1 * -0x136ab + -0x2d139 + 0x3b214) % (-0x1ea4 + 0x1345 + 0xb62);
                                                            }
                                                        } else flip = 0x1b0e + -0xaaa + -0x1063 == '1', tickcount = 0x73a * -0xd51 + -0x1 * 0x48378ba + 0xc3f8129 - (0xe1d11ae + -0x777055 * 0x16 + 0x38262b5);
                                                    }
                                                    break;
                                                case 0x37ac563 + 0x4dd3268 + -0x556bcaf - (-0x32c7b91 + -0x4fc7e9 + 0x3 * 0x229d4db):
                                                    ki = tickcount >= tick1 && !flip ? 0x1d90 + 0x1 * -0x165d + -0x1 * 0x71d : 0x2cc * 0x5 + 0xe11 * 0x1 + -0xb5 * 0x27;
                                                    break;
                                            }
                                            km = 0x1d2c + -0x95d * -0x2 + -0x2f89;
                                            while (km < -0xc * 0x98 + 0x1 * -0xdf6 + 0x15af) switch (km) {
                                                case -0xabf + -0x43 * -0x47 + -0x1 * 0x779:
                                                    km = tickcount >= tick2 && flip ? 0x1142 + -0x19b6 + -0x1 * -0x89e : 0x725 + -0x5b * 0x7 + -0x40f;
                                                    break;
                                                case 0x4e9 * -0x4 + 0x215f + -0xd91:
                                                    km = 0x61 * 0x41 + -0x1 * 0x238f + 0xb87; {
                                                        if ('YTrgb' === 'JXnoo') {
                                                            function kn() {
                                                                ko(0x1545 + 0x1007 * -0x1 + -0x50e);
                                                            }
                                                        } else flip = null === undefined, tickcount = (-0x1ec4c + -0x3cca8 + -0x1a * -0x4cf1) % (-0x3 * -0x917 + 0x1 * 0x6fc + -0x223e);
                                                    }
                                                    break;
                                            }
                                            gv = !flip ? -0xb9b * -0x1 + -0xcc5 + 0x139 : dsal2342234232342342342323422342342344234332k312323(0x124b7e5 + -0x3 * -0x6e49e2 + 0x1b3343d * -0x1 - (0x67c761 + 0x2bf8b2 * -0x2 + 0xac8b50), 0x315c3d04 + -0x13d8892f + -0xa3e5bb * 0x6 - (0x9e6d * 0x19db + -0x1d69f147 + 0x27161673)), tickcount++;
                                        } else {
                                            function kp() {
                                                var a = a;
                                                kq.SetFakeOffset((-0xdbf8 + 0x2 * 0x1c8a1 + -0x9dc4) % (0x3f8 * -0x4 + -0xc51 + 0x1c34)), kr.SetRealOffset(-ks);
                                            }
                                        }
                                    }
                                    break;
                                case 0x9e0 + 0xc3c + -0x15c0:
                                    kh = UI.GetValue(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW', 'fakelag type']) == (-0x20 * -0x27140c + -0x1 * 0x1a1e2b53 + 0x3580b9dc) % (-0xef * -0x1b + -0x712 + -0x121a) ? -0x21fd + 0x2034 + 0x205 * 0x1 : 0x19f6 + -0x1b25 + 0x1c6;
                                    break;
                            }
                            break;
                    }
                    break;
            }
            break;
        case 0x2 * 0xe03 + 0x3 * -0x971 + 0x39 * 0x2:
            ip = 0xbd1 + -0x6 * 0x286 + 0x3f4; {
                if ('nYYLc' !== 'QXeeL') gv = 0x1645 + -0x141 * -0x16 + -0x31cc;
                else {
                    function kt() {
                        var a = a;
                        ku.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'traced lines distance delta'], -0x1 * 0xa6d2909 + -0x6d6ece1 * -0x2 + -0x448a * -0xf56 - (-0x9ee1a7 * 0x6 + 0x3679c38 + 0xa0b * 0xc3b5)), kv.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'fake offset divider'], -0x2c26448 * -0x5 + -0x1542800 + 0x51c0053 * -0x1 - (-0x9d3d9 * -0x61 + 0x96772fb + 0x1 * -0x5c4eb1f)), kw.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'real offset divider'], (-0xb * 0x3f13 + -0x2b65c + -0x1 * -0x783b3) % (0x1d9e + 0xb6f + 0x67 * -0x66)), kx.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'inactive desync delta'], (-0x41aba + -0xd1cf + 0x7040f) % (0x20da + -0x1796 + 0x17 * -0x67)), ky.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'jitter'], (-0x38939 + -0x679 * -0x1 + -0x1 * -0x59a46) % (-0xeb + -0x1 * 0xd01 + 0xdef));
                    }
                }
            }
            break;
    }
    kz = 0x7cc9be3 + -0x12f7806 + 0x18c2 * -0x17ab & -0x8 * -0xb45589 + -0x27f2f99 * -0x1 + -0xa7 * 0x79fdd;
    while (kz < -0x9bf * 0x3 + -0x102d + 0x2dde) switch (kz) {
        case -0x1719 + 0x9aa + -0xdbd * -0x1:
            kz = -0x6c8 + 0x1955 * -0x1 + -0x4a7 * -0x7; {
                if ('TzKVv' !== 'TzKVv') {
                    function la() {
                        var a = a;
                        lb.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'watermark'], (-0x21632 + 0x1d525 + -0x42bb * -0x9) % (0x165b + -0xc1 * 0x21 + 0x289 * 0x1)), lc.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'indicators'], -0x56b7c3f + 0x1 * 0xa8b4551 + 0x23c0403 - (-0x83e353a + 0x171266d + 0xe28dbe2)), ld.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'bind list'], (-0x2ab33 + 0x2c379 + -0x8 * -0x3fe8) % (0x41b + -0x26c + 0x6b * -0x4)), le.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'indicators color'], (0xe4d1 + 0x1 * -0xf589 + 0x2283e * 0x1) % (0xf0d * -0x2 + 0x200a + -0x1 * 0x1ed));
                    }
                } else {
                    lf = 0x1 * -0x733 + 0x944 + 0x1b7 * -0x1;
                    while (lf < -0xa2 * 0xe + 0x1049 + -0x6d4) switch (lf) {
                        case 0x25d + -0x15f2 + 0x13c1:
                            lf = -0x101f + -0x2258 + 0x2b0 * 0x13; {
                                if ('msIEw' !== 'pBwYw') UI.SetValue(['Rage', 'Fake Lag', 'General', 'Limit'], -0x3 * -0x353 + 0x1 * 0x363 + -0xd46 * 0x1), UI.SetValue(['Rage', 'Fake Lag', 'General', 'Trigger limit'], -0x50a + 0xb * -0x262 + 0x2a * 0xbf);
                                else {
                                    function lg() {
                                        var a = a;
                                        lh.SetValue(['Rage', 'General', 'General', 'Silent aim'], (0x3e8 * 0x7c + 0x3e953 + -0x3b62d) % (0x934 * -0x2 + 0x462 + -0x1 * -0xe09));
                                    }
                                }
                            }
                            break;
                        case 0x22ca + 0x176d + -0x39ed:
                            lf = 0x1 * 0xe05 + 0x1ecd * -0x1 + 0x1161; {
                                if ('GcWqv' === 'vGyfr') {
                                    function li() {
                                        var a = a;
                                        lj.SetValue(['Misc.', 'Movement', 'Leg movement'], (0x8a * -0x44e6 + -0x1 * -0x363fb9 + 0x1794ec) % (-0x2365 + 0x4 * 0x850 + 0x228));
                                    }
                                } else UI.SetValue(['Rage', 'Fake Lag', 'General', 'Limit'], gv), UI.SetValue(['Rage', 'Fake Lag', 'General', 'Trigger limit'], -0xffe * -0x1 + 0x4e1 + -0x14d0);
                            }
                            break;
                        case -0x19b8 + 0xfe3 + 0xa2f:
                            lf = UI.GetValue(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW', 'fakelag type']) == (0x1ba0e29 + 0x1c5ea5f + -0x291099c) % (-0x7 * -0x182 + 0x1 * 0x4f9 + -0xf81) ? 0x56 * -0xe + 0x1a3d + -0x1 * 0x155d : 0x72c + 0x1 * 0x417 + -0xaf9;
                            break;
                    }
                }
            }
            break;
        case -0x2 * 0xb03 + 0x1703 + -0xef * 0x1:
            kz = -0x2 * -0x1013 + -0x5 * -0x1ed + 0x1 * -0x2953; {
                if ('TVhJQ' === 'KKxYR') {
                    function lk() {
                        var a = a;
                        ll.SetValue(['Rage', 'Anti Aim', 'Directions', 'Auto direction'], (-0x2a865 + 0x22c1b + -0x4950 * -0x9) % (-0x2504 + 0xe5 * 0x1 + 0xb9 * 0x32));
                    }
                } else {
                    lm = 0x1 * -0x151f + 0xea7 + 0x68c;
                    while (lm < -0x2 * -0xe3e + 0x1 * 0x1be + -0x1df5) switch (lm) {
                        case 0xda * 0x2b + -0x1368 + -0x1 * 0x112d:
                            lm = -0xca4 + 0x102c + -0x343; {
                                if ('pWBwR' !== 'pWBwR') {
                                    function ln() {
                                        lo = null === lp, lq = (0x24b97 + -0x139a9 + 0x10598) % (-0x821 * -0x1 + -0x3 * 0xcfb + 0x1ed3);
                                    }
                                } else UI.SetValue(['Rage', 'Fake Lag', 'General', 'Limit'], -0x12ef + 0x12b + 0x9 * 0x1fb);
                            }
                            break;
                        case -0x243c + -0x1187 * -0x1 + 0x12bf:
                            lm = -0x1f8b + 0x8 * 0x16b + -0x1 * -0x1478; {
                                if ('dHfVA' !== 'dHfVA') {
                                    function lr() {
                                        var a = a;
                                        const ls = lt * lu.PI / (0xb3 * -0x2d + -0x23 * 0x81 + 0x31ce);
                                        lv.Line(lw + lx.cos(ls) * ly, lz + ma.sin(ls) * mb, mc + md.cos(ls) * me, mf + mg.sin(ls) * mh, mi);
                                    }
                                } else UI.SetValue(['Rage', 'Fake Lag', 'General', 'Limit'], 0x1595 + -0x1ca * -0xc + -0x2af7);
                            }
                            break;
                        case -0x1344 + 0x2 * 0x123e + -0x892 * 0x2:
                            lm = UI.GetValue(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW', 'fakelag type']) == (-0x260fbb1 + -0x131ca95 * 0x3 + 0x221cb * 0x4fa & 0x4bd01d2 + 0x2c96089 * -0x2 + 0x417e654) ? -0x71 * -0x57 + 0x9d * 0x11 + -0x30ca : -0x232d + 0x3 * -0x727 + -0x1 * -0x38ab;
                            break;
                    }
                }
            }
            break;
        case -0x1da8d8 * -0x1 + 0x11a3d5 + -0x1fdf6b - (0x16486f * -0x1 + 0x27911 + 0x233c9a):
            kz = UI.GetValue(['Rage', 'SUBTAB_MGR', 'Exploits', 'SHEET_MGR', 'Keys', 'Key assignment', 'Double tap']) == ([null] == '') ? 0x9 * -0x2b3 + 0x2d + 0x182c : 0x10d6 + 0x15b9 + -0x2641;
            break;
    }
    var go, gp, gq, gr, gs, gt, gu, gv, gw, gx, gy, hc, hz, ip, iq, jd, js, jy, kh, ki, km, kz, lf, lm;
}
UI.AddCheckbox(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW'], 'watermark');

function dsal2342223243232322223342323223232223233434232342342342323422342342344234332k312323() {
    var a = a;
    mk = CheatHooked.GetUsername();
    while (mm < 0x112 * 0x1 + -0x2 * -0x35e + -0x75c * 0x1) switch (mm) {
        case (0x22304 + 0x2d078 + -0x1c27 * 0x1a) % (-0x1c67 * 0x1 + 0x3e * 0x7a + 0xa * -0x1d):
            mm = mk != ml[0x1f33563 + 0xa195025 + 0x1 * -0x4b0b873 - (-0xa6b4f6a * 0x1 + -0x46de371 + -0x1 * -0x1634fff0)] || mk != ml[(0x6c5f * 0x8d + 0x1 * -0x3d2a6f + 0x2a2ac5) % (-0x1a8d + -0x4f5 + 0x1f85)] || mk != ml[(0x1b399650 + 0x1f6078e4 + -0x392db * 0x4de) % (-0x1798 + 0xd * -0xbf + 0x2152 * 0x1)] || mk != ml[(0x51430cd + -0x12c3 * -0x2b72 + -0x38c49f8) % (-0x4f0 + 0x1 * 0x2539 + -0x2042)] || mk != mj[(0x4483a591 + 0x343c54f * -0x16 + 0x2c849883) % (0x2f * -0x53 + -0xb73 + 0x1ab7)] ? 0x165d + 0x269f + -0x3cba : -0x129b * 0x1 + 0x1b4b + 0xd3 * -0xa;
            break;
        case 0x961 * -0x1 + -0x1d94 + 0x2737:
            mm = -0x1fb2 + 0x26da + -0x6b6, dsal23232342222322323233233242323332323232322223342323223232223233434232342342342323422342342344234332k312323();
            break;
    }
    mn = Entity.GetLocalPlayer(), mo = Entity.GetCCSWeaponInfo(mn), mp = Entity.GetName(Entity.GetWeapon(Entity.GetLocalPlayer())), mq = Entity.GetProp(mn, 'CCSPlayer', 'm_bIsScoped'), mr = (0x1bf1c + -0x1e603 + 0x23e6d * 0x1) % (0x1 * -0x243d + -0x16d6 + -0x1d8b * -0x2), ms = dsal24234332k312323(mn), mt = 0x720 + -0x19ad + -0x21 * -0x92;
    while (mt < -0xd * -0x51 + 0x1974 + -0x1d1e) switch (mt) {
        case 0x1 * -0xd16 + -0x3 * -0x21a + 0x6f7:
            mt = 0x157d + 0x5e4 + -0x9 * 0x2fe; {
                if ('HSkmu' !== 'otUMh') dsalkj2k3123(0x8f9 + -0x18bc + 0x5d7 * 0x3);
                else {
                    function mu() {
                        var a = a,
                            mv;
                        try {
                            mv = mw('return (function() ' + ('{}.constructor("return this")( )') + ');')();
                        } catch (mx) {
                            mv = my;
                        }
                        return mv;
                    }
                }
            }
            break;
        case -0x6 * 0x360 + -0x3 * 0x25f + 0x1ba2:
            mt = ms ? 0x1 * -0x1ef4 + -0x6ea + 0x260d : 0x1309 * -0x1 + 0x597 * -0x1 + -0x1 * -0x18d0;
            break;
        case -0x18cc + -0x5 * -0x325 + 0x943:
            mt = -0x219 * -0x11 + 0x13 * -0x199 + 0xb * -0x71; {
                if ('gToZl' !== 'PtSeZ') {
                    mz = 0x65 * 0xd + 0x4a4 + -0x98e;
                    while (mz < -0x8 * -0x18a + 0x1012 + -0x1c13) switch (mz) {
                        case 0x10f * 0xc + 0xcc7 + -0x1944:
                            mz = jagowalking ? 0xb * -0x89 + 0x4b4 + 0x14c : 0x6f7 * -0x5 + 0x4 * -0x8b + 0x2528;
                            break;
                        case 0x246e + -0x2185 * 0x1 + -0x166 * 0x2:
                            mz = -0x1 * -0x19be + -0x5 * 0x18d + -0x1 * 0x11ae; {
                                if ('YQdxI' === 'YQdxI') dsalkj2k3123(0x3 * 0x3fe + -0x985 * -0x1 + 0x557 * -0x4 - dsal2342234232342342342323422342342344234332k312323(-((0x6e21beb + 0x2166d79 + -0x3e7e315) % (0x1739 + 0x185b + -0x2f8e)), -0x3 * -0x20e3f12 + -0x9056b35 + -0x121213 * -0x71 ^ 0x31e16bc + -0x3629268 + -0x1 * -0x563c80d));
                                else {
                                    function na() {
                                        var a = a;
                                        nb.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'buy awp'], (-0x31663 * -0x1 + 0x3bd4f * -0x1 + 0xdc6 * 0x33) % (-0x1 * 0xd2b + -0x214a + 0x173c * 0x2)), nc.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'jag0-tag'], 0x210fbba + -0x6e45345 + 0x4dfa84 * 0x28 - (0x8f9b * 0x138f + 0xba923cb + -0xf460f4b)), nd.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'thirdperson distance'], 0x2 * 0x6b24b63 + -0x1a5a6f * 0x9 + -0x51b9bca - (-0xb299376 + 0x11c * -0x9d150 + 0x1d69954b));
                                    }
                                }
                            }
                            break;
                        case -0x2489 * 0x1 + -0x2f8 + -0x27aa * -0x1:
                            mz = 0x172e + -0x14ba + -0x225; {
                                if ('RHzIt' !== 'OoiJr') {
                                    ne = -0x544 * -0x5 + 0x101 * -0xb + -0xf2e;
                                    while (ne < -0xb84 + 0x78f + 0x48f) switch (ne) {
                                        case 0x1e19 + -0x17aa + 0x60d * -0x1:
                                            ne = -0x7 * -0x257 + 0x1 * -0x20eb + 0x1124; {
                                                if ('pFKFr' === 'pFKFr') {
                                                    nf = 0x92 * 0x19c13 + -0x7c427 * 0x1b + 0x17 * 0x94993 ^ 0x85e * 0x25ce + 0x1b2ee73 + -0xaac5b9 * 0x3;
                                                    while (nf < 0x17b * 0x7 + -0x23c0 + -0x8a7 * -0x3) switch (nf) {
                                                        case -0xeada51 + -0x231961 + -0x1a0 * -0x13929 ^ 0x1db4072 + 0x10aa6ca + -0x1f6f850:
                                                            nf = mp == 'awp' ? -0x156f + 0x199a + -0x3e7 : 0x108d + 0x8d + -0x1088;
                                                            break;
                                                        case -0x548 * 0x4 + 0x1cc9 + -0x765:
                                                            nf = 0x10 + 0x34 * 0x2d + -0x8a2; {
                                                                if ('xAXOL' === 'AzYer') {
                                                                    function ng() {
                                                                        nh();
                                                                    }
                                                                } else {
                                                                    ni = 0x5 * -0x23c + -0xab9 * -0x1 + -0x31 * -0x4;
                                                                    while (ni < -0x3bf + -0xf41 + 0xa2 * 0x1f) switch (ni) {
                                                                        case 0x7 * 0x83 + 0x2351 + -0x2695:
                                                                            ni = mq == (NaN !== NaN) ? -0x291 + 0xa7 * 0x39 + -0x4e7 * 0x7 : -0x1d16 * 0x1 + -0x8 * -0x4a + 0x1b64;
                                                                            break;
                                                                        case 0x2ca * 0xe + 0x1f * 0x139 + -0x4ca6:
                                                                            ni = -0x7d0 + -0x4 * -0x2f1 + -0x1 * 0x356, mr = mo.max_speed - (0x3 * -0x53b + -0x511 + 0x1526);
                                                                            break;
                                                                    }
                                                                }
                                                            }
                                                            break;
                                                    }
                                                } else {
                                                    function nj() {
                                                        var a = a;
                                                        nk(nl.max_speed - nm((-0x1 * -0x3698e10 + -0x7bee749 + -0x59173a * -0x1a) % (-0x1633 * 0x1 + 0x1cab + -0x61 * 0x11), (-0xad7e77 + -0x4de3 * 0x7af + 0x5d5c993) % (0x1b55 * 0x1 + 0x17e3 + -0xa8 * 0x4e)));
                                                    }
                                                }
                                            }
                                            break;
                                        case -0x17e9 + -0x1 * 0x1fcd + 0xb * 0x513:
                                            ne = mp == 'scar 20' || mp == 'g3sg1' ? -0x3d5 + -0x878 + 0xc85 : 0x6af + -0x5 * -0x1ae + -0xeb3;
                                            break;
                                        case 0x3c4 * -0x5 + -0x24bf + 0x9 * 0x633:
                                            ne = 0x2206 + 0x70d * 0x1 + -0xd * 0x31d; {
                                                if ('dthPi' !== 'dthPi') {
                                                    function nn() {
                                                        var a = a;
                                                        no.OverrideMaxProcessTicks(0x1cbe + 0x2563 + 0x1 * -0x4211);
                                                    }
                                                } else {
                                                    np = -0x2 * -0x22a + 0xace + -0xf07;
                                                    while (np < 0x823 * 0x1 + 0x89f * 0x2 + -0x1922) switch (np) {
                                                        case -0x2 * 0xe2c + 0x19ab * -0x1 + -0x1 * -0x361e:
                                                            np = mq == ([null] == '') ? 0x5 * -0x4b5 + -0x370 * -0x1 + -0xd * -0x18e : -0x249d + -0x1 * 0x18fb + 0x149d * 0x3;
                                                            break;
                                                        case 0x2396 + 0x36d + 0x1a * -0x17f:
                                                            np = 0x1b83 + 0x3 * 0x728 + 0x4 * -0xc2f, mr = mo.max_speed - (-0xb2a + 0x2319 + -0x1790);
                                                            break;
                                                    }
                                                }
                                            }
                                            break;
                                    }
                                    nq = -0x6 * -0x52d + -0x2 * 0x734 + -0x1045;
                                    while (nq < -0x165 * 0x18 + -0x15f + 0x1 * 0x238c) switch (nq) {
                                        case 0x1a2e + 0x1 * -0xb3f + -0xeb2:
                                            nq = -0x344 + -0x1b9a + -0x89 * -0x3b; {
                                                if ('kvgbp' === 'kvgbp') dsalkj2k3123(mo.max_speed - dsal2342234232342342342323422342342344234332k312323((0x2549703 + -0x85cc202 + 0x9e * 0x11699b) % (-0x1c0a * -0x1 + 0x2 * -0x998 + -0x3 * 0x2f1), (0x5401824 + 0x39fae0a + -0x60dee3f) % (0x1bc + -0x1827 + 0x1 * 0x1673)));
                                                else {
                                                    function nr() {
                                                        var a = a;
                                                        ns.SetValue(['Rage', 'Anti Aim', 'Directions', 'Auto direction'], 0x7eb966 * 0x2 + -0x10c30 * -0xdb + 0x933f47 * -0x2 - (-0x3371 * -0x2ef + 0xb * 0x1a6177 + 0x1 * -0xfcb74f));
                                                    }
                                                }
                                            }
                                            break;
                                        case -0x1 * 0x61d + 0x2222 + -0x1ba4:
                                            nq = mp == 'scar 20' || mp == 'g3sg1' || mp == 'awp' ? 0x5 * 0x25f + 0x1a44 + -0x25e2 * 0x1 : -0xdbe + 0x10 * 0x155 + -0x1 * 0x766;
                                            break;
                                        case 0x1827 + 0x76 + -0x1871:
                                            nq = -0x445 * -0x1 + 0xac7 + 0x1 * -0xe57; {
                                                if ('TSNQo' === 'rJSyh') {
                                                    function nt() {
                                                        var a = a;
                                                        nu.SetValue(['Misc.', 'Movement', 'Leg movement'], !nv ? (0x291cc + 0x12c * 0x36f1 + -0x1a438f) % (-0x1f52 + -0x1f8d + -0x3 * -0x14f6) : -0x1605ba5 + 0xe8083b * -0x2 + 0x5 * 0xd31235 ^ -0x170bdb * 0x4 + -0x1319e80 + 0x27cbcd8), nw++;
                                                    }
                                                } else dsalkj2k3123(-0x1b * -0x3e + 0x242c + -0x147a * 0x2);
                                            }
                                            break;
                                    }
                                } else {
                                    function nx() {
                                        var a = a;
                                        ny.SetValue(['Misc.', 'Movement', 'Leg movement'], (-0x1 * -0x1058 + 0x4 * 0x62b4 + -0x2 * -0x3e2f) % (-0x8 * -0x3df + 0x221f + 0x341 * -0x14));
                                    }
                                }
                            }
                            break;
                    }
                } else {
                    function nz() {
                        var a = a;
                        oa = ob(oc), od = oe( of ), og = oh.sin(oa), oi = oj.cos(oa), ok = ol.sin(od), om = on.cos(od);
                        return [oi * om, oi * ok, -og];
                        var oa, od, og, oi, ok, om;
                    }
                }
            }
            break;
    }
    var mj, mk, ml, mm, mn, mo, mp, mq, mr, ms, mt, mz, ne, nf, ni, np, nq;
}
UI.AddCheckbox(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW'], 'indicators'), UI.AddCheckbox(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW'], 'bind list');

function dsal2323234222232223322233323233233242323332323232322223342323223232223233434232342342342323422342342344234332k312323() {
    var a = a;
    oo = parseInt(Globals.Curtime() * (-0x137dbe4 + -0x40aae5d + 0x1 * 0x8b5f2fd - (0x496b7ab + 0x231b396 + -0x3550288))), op = 0x267b * -0x1 + -0x1afd + 0x41b5;
    while (op < 0x1e12 * 0x1 + -0x174 + -0x1c * 0x103) switch (op) {
        case -0x2 * -0xe2 + 0x335 * -0xb + 0x21c0:
            op = UI.GetValue(['Config', 'JAGO-YAW', 'JAGO-YAW', 'jag0-tag']) == (-0x1 * -0x41b + 0x1 * 0x1605 + 0x2e7 * -0x9 == '1') && oo + Math.floor(Global.Latency() * (-0x2 * -0x2ae + -0xcea + 0xa3 * 0x12)) != lastcurt + Math.floor(Global.Latency() * (0x1a01 * -0x1 + 0x51d * 0x2 + -0x13af * -0x1)) ? 0x1 * -0x1448 + -0x1 * 0xb5 + 0x1545 : -0x19d * 0x1 + -0x1 * -0x1fd3 + 0x1 * -0x1dec;
            break;
        case -0x1 * -0xac2 + 0x10 * 0x138 + -0x1dfa:
            op = -0x1e63 * -0x1 + 0x1766 * 0x1 + -0x357f; {
                if ('BRpNw' === 'nvYhZ') {
                    function oq() {
                        var a = a;
                        or.String(os.GetScreenSize()[0x5617bb5 + -0xd57ab3a * -0x1 + -0xb5d59da - (-0x857ac2 + -0xe801015 + 0x166157ec)] / ((0x1 * 0x20aaf672 + 0x486fe232 + -0x3fe58f5a) % (0x4 * 0x665 + -0x718 + -0x19 * 0xbd)) + (0x2908d6 * 0x1 + 0x1b5ee4 + -0x1bb711) % (-0xcd5 + 0x1e56 + 0x117e * -0x1) - (-0x12a2 + -0x69c + 0x16 * 0x127), ot.GetScreenSize()[0x196f0e + -0x4 * -0x56a1e7 + -0xaf5d * 0x10c - (-0xa2a281 + -0x159f78d * 0x1 + 0x2b8fb5b)] / ((-0x2183254c * -0x1 + -0xf5ebb87 + 0x1710df85 * 0x1) % (-0x617 * 0x5 + -0x26ef + 0x4569)) + (0x1d3 * 0x591 + 0x1067b7 + -0x74b1 * -0x1f) % (-0x266f * 0x1 + 0x253a + 0x3 * 0x68) + (-0xde0 + 0x16d6 + -0x8c4 * 0x1), 0x1cac3 * 0x7bb + -0x7bd0993 + 0x45 * 0x49d4b - (-0x3bc3 * 0x1c59 + -0x3c13daa + 0x11bb258a), 'JAG0WALK', [0xc41f4b0 + 0x55ddf21 * 0x1 + -0x22 * 0x4d4b7e - (0x13ed196 * -0x7 + 0xd8e4651 + -0x2 * -0x142a0ef), -0x8ee94b9 + -0x1 * 0x2d9cad3 + 0x5 * 0x3d408ed - (-0xab705ea + -0x30da392 + 0x15207691), (-0x2d70 + 0x2b5d2 + -0x4 * 0x1c37) % (0x2 * -0x67 + 0xbf * 0x2 + -0xad), ou], ov), ow.String(ox.GetScreenSize()[(0x2676e + 0x4 * -0x3b28 + 0x9cb8) % (-0xf35 + -0x1ad8 + 0x2a10)] / ((0x506437b1 + 0x11ae6320 + 0x11 * -0x3585017) % (0x106a + -0x20da * -0x1 + -0x313d)) - (0x62a * 0x6 + 0x20ff + -0x45df), oy.GetScreenSize()[0x1b4 * 0x22b7 + -0x928c4e + 0x113cdf0 - (0x342a6d + 0x80b85b + 0x77e85)] / (0x2f * -0x3ef41 + -0x1cc7f82 + -0x5 * -0xb0df13 ^ -0x1 * 0x155ba5f + 0x13 * -0x179d2c + 0x405538f) + (0x1e04 + -0x1211 + -0xbc1), (0x102d3 * 0x2 + 0xc * 0x4ad4 + -0x37010) % (-0x192 * -0xa + 0x2 * 0xfb2 + 0x1 * -0x2f15), 'JAG0WALK', [oz[(0x413e3 + 0x1 * 0x17867 + -0x374c4) % (0x4 * -0x8c6 + -0x5 * 0x133 + -0x291a * -0x1)], pa[(0x53 * 0x8e91 + -0x2ce4f8 + -0x116f * -0x242) % (0x259d + -0x710 + -0x1 * 0x1e8a)], pb[0x1f * 0x7133d + 0x1407d7 * 0x17 + 0x1b919c6 * -0x1 ^ 0x1 * -0x10f4578 + -0x303b0c + -0x16 * -0x196228], pc], pd);
                    }
                } else switch (oo % (-0x476 * -0x7 + 0x1 * 0xf5d + -0x2e85)) {
                    case 0x5fa63a4 + 0xb6516ed + -0xa03ad7c - (-0xd4aa0b6 * -0x1 + 0xdb2c0a0 + -0x13a19441): {
                        if ('hTgWo' !== 'hTgWo') {
                            function pe() {
                                var a = a;
                                pf = pg + ph * pi.TickInterval(), pj = pk + pl * pm.TickInterval(), pn = po + pp * pq.TickInterval();
                            }
                        } else {
                            Local.SetClanTag(' ');
                            break;
                        }
                    }
                    case (0x2f77d5 + 0x149 * -0x3c7a + 0x46f19e) % (-0x1939 + 0x13f7 * 0x1 + 0x13 * 0x47): {
                        if ('faLmM' === 'faLmM') {
                            Local.SetClanTag('j');
                            break;
                        } else {
                            function pr() {
                                var a = a;
                                ps.ExecuteCommand('buy awp'), pt.ExecuteCommand('buy awp'), pu.Print('predicted: ' + pv + pw.Latency() / (-0xee * -0x5 + -0x1 * 0x1dfc + 0xc5 * 0x26) + ' current:' + (px.Curtime() + py.Latency() / (-0x1f31 + 0x1ed9 * -0x1 + -0x2de * -0x17) + '\x0a')), pz = 0x876 * -0x1 + 0x4a0 * -0x4 + -0x1 * -0x1af7 === '1';
                            }
                        }
                    }
                    case 0x1716e36 + 0x1dc53dc + -0x25ed324 ^ -0x68432b * -0x2 + -0x1c84873 + 0x1e6b109 * 0x1: {
                        if ('ZFxus' !== 'ZFxus') {
                            function qa() {
                                qb = qc;
                            }
                        } else {
                            Local.SetClanTag('ja');
                            break;
                        }
                    }
                    case (0x3ca75003 + 0x25dc7 * 0x10f1 + -0x6fa645 * 0x9d) % (-0x1 * 0x2383 + 0x1274 * 0x2 + -0x15c): {
                        if ('UdBlx' === 'UdBlx') {
                            Local.SetClanTag('jag');
                            break;
                        } else {
                            function qd() {
                                var a = a;
                                qe.SetValue(['Rage', 'General', 'General', 'Silent aim'], -0x179 * 0x4199 + -0x1b2817 * -0xa + 0xf67 * 0xdf - (0xe * 0x82a51 + -0x1429cb + 0x5e3aaa));
                            }
                        }
                    }
                    case 0x6c885df + -0x2 * -0x3908dd3 + -0x943d0b7 & 0x27b21a2 + 0x1626e27 + -0x5 * 0x1f14f1: {
                        if ('CWVpX' === 'ktrOO') {
                            function qf() {
                                var a = a;
                                qg.SetValue(['Rage', 'Anti Aim', 'Directions', 'Auto direction'], 0x3c21a23 + -0x43b696 + 0x3dd6988 - (0x226 * 0x351f2 + 0x1 * -0xae3c772 + 0xb1d869b));
                            }
                        } else {
                            Local.SetClanTag('jag0');
                            break;
                        }
                    }
                    case (-0x43d6943 + -0x1ecc161 + 0xb3ad0f3) % (-0x2478 + 0x1779 + 0x457 * 0x3): {
                        if ('mTQBm' === 'jqFXU') {
                            function qh() {
                                var a = a;
                                qi.SetValue(['Rage', 'General', 'General', 'Silent aim'], 0x3 * 0xdeac + 0x689b16 + -0x81dd2 * -0xa - (0x20e6a7 + 0x3d7acd + -0x12ccc5 * -0x5));
                            }
                        } else {
                            Local.SetClanTag('jag0-');
                            break;
                        }
                    }
                    case -0x60e9b1b + 0x5dc83d6 + 0x485438c & 0x5674df4 + -0x1 * -0x330e1d6 + -0x56f9d14: {
                        if ('KqsNX' === 'rHstj') {
                            function qj() {
                                var a = a;
                                qk.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'buy awp'], 0x7c5b15 + -0x11b20b2 + 0xdb1 * 0x195b - (0x48f119 + 0x7b9d * -0x1cf + -0x43 * -0x50f4d)), ql.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'jag0-tag'], -0x1600095 + -0x7ad747 + 0x297392a - (0x15d122e * -0x1 + 0xb855a4 + 0x1611dd7)), qm.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'thirdperson distance'], (0x1 * 0x3e99d5 + 0x1d29cc + -0x3312f8) % (-0x1e3a + -0x1 * -0x23b2 + -0x575));
                            }
                        } else {
                            Local.SetClanTag('jag0-y');
                            break;
                        }
                    }
                    case (-0x21ee429 + 0x4847a7e + -0x4d1 * -0x167a) % (-0x1ae1 + -0x4 * -0x3d9 + 0xb85): {
                        if ('alcaw' === 'HdyGQ') {
                            function qn() {
                                var a = a;
                                qo.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'traced lines distance delta'], (-0x15734e + -0x7aed + -0x1 * -0x3e9ee4) % (0xd79 * 0x1 + 0x2322 + -0x3098)), qp.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'fake offset divider'], -0x15220a4 + 0x1383be8 + 0x1e12d * 0x72 - (0x12b0009 * 0x1 + -0x15392ec + -0x393d0c * -0x4)), qq.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'real offset divider'], (-0x186df5 * -0x2 + 0xf0383 + -0xed64 * 0x19) % (-0x1b47 + -0x1 * -0x59f + 0x15ab)), qr.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'inactive desync delta'], (0xd50d * 0x27 + -0x32e007 + 0x3b1bb5) % (-0xbda + -0xbba + 0x7dd * 0x3)), qs.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'jitter'], 0x4d236a + -0x1ceb1c * -0xc + -0xebc76c - (0x264f4a + 0xcbd63c + -0x35c439));
                            }
                        } else {
                            Local.SetClanTag('jag0-ya');
                            break;
                        }
                    }
                    case 0xb7ae18a * -0x1 + -0x2379dd * 0xa6 + 0x3 * 0x140d6819 - (0x2fbe4b93 + 0x2d9335f + -0x18eb2d87): {
                        if ('xnmcy' === 'xnmcy') {
                            Local.SetClanTag('jag0-yaw');
                            break;
                        } else {
                            function qt() {
                                var a = a;
                                qu.ForceHitboxSafety((0x29a99 + 0x3bce3 + -0x43ff6) % (0x616 * -0x2 + -0x2c * -0x30 + 0x3ef)), qv.ForceHitboxSafety(-0x12e2557 + -0x5b2305 * 0x1 + 0x245a9aa - (0x12f35ec + 0x20fb34 + -0x93cfd3)), qw.ForceHitboxSafety(-0xb51d3 * 0x1 + -0x107684 + 0x2b3599 - (0x525 * -0x19b + 0x1273be + -0xb * -0x79cf));
                            }
                        }
                    }
                    case 0x2371 + 0x33b * 0xa + -0x43b6: {
                        if ('IXfMt' === 'JlxTZ') {
                            function qx() {
                                qy(-0x26fb + -0x95b + -0x190c * -0x2);
                            }
                        } else {
                            Local.SetClanTag('jag0-yaw');
                            break;
                        }
                    }
                    case 0x1 * -0x2001 + -0x95 * 0x1 + 0x3 * 0xae0: {
                        if ('GtfII' === 'GtfII') {
                            Local.SetClanTag('jag0-yaw');
                            break;
                        } else {
                            function qz() {
                                var a = a;
                                ra = rb, rc.ForceTargetMinimumDamage(rd, re + (0x94a * -0x4 + -0x1 * 0x9e4 + -0xf6 * -0x31));
                            }
                        }
                    }
                    case -0x2 + -0xa3d + -0x36e * -0x3: {
                        if ('PtdjT' !== 'tVXQk') {
                            Local.SetClanTag('jag0-ya');
                            break;
                        } else {
                            function rf() {
                                var a = a;
                                rg.SetValue(['Rage', 'Fake Lag', 'General', 'Limit'], -0x97e + -0x8c5 * -0x1 + 0xcf * 0x1);
                            }
                        }
                    }
                    case 0x14fd + -0x1 * -0x9a7 + -0xf4c * 0x2: {
                        if ('rxebH' !== 'uepnH') {
                            Local.SetClanTag('jag0-y');
                            break;
                        } else {
                            function rh() {
                                var a = a;
                                ri.OverrideShift(0x258b * -0x1 + 0x4 * -0x989 + 0x4bc3);
                            }
                        }
                    }
                    case -0xa3b + -0x1 * 0x16e2 + 0x1 * 0x212a: {
                        if ('agIxr' !== 'MKjAP') {
                            Local.SetClanTag('jag0-');
                            break;
                        } else {
                            function rj() {
                                var a = a;
                                rk = rl / (0x4ccdd2 * 0x4 + -0x9be39d * -0x1 + 0x1 * -0xe02bf7 ^ 0x199e * -0x48 + -0xb2b05 * 0x11 + 0x1b3feb1 * 0x1), rm.ForceTargetMinimumDamage(rn, ro + (-0x109dbf * 0xb + 0x8cc2c0 * -0x2 + 0x1 * 0x28cae03 - (0x662c9c + -0x39953b * -0x4 + -0x90203b)));
                            }
                        }
                    }
                    case -0x1 * 0x48c + -0x22c3 + 0x275d: {
                        if ('PwBGB' !== 'PwBGB') {
                            function rp() {
                                rq();
                            }
                        } else {
                            Local.SetClanTag('jag0');
                            break;
                        }
                    }
                    case -0x2633 + -0x160c + -0x1f * -0x1f2: {
                        if ('ULhUT' === 'Vxqtb') {
                            function rr() {
                                var a = a;
                                rs.String(rt + (0x1504b998 * -0x3 + -0x158ee9ca + -0x3ee92fee * -0x2) % (0x249e + 0x245 * 0xf + -0x46a2), ru + rv + (-0x4684 * 0xd3 + 0x508264 + 0x124d11) % (-0xb09 + 0x92 * -0x19 + 0x194e), (0x5d5 * -0x1 + 0x5bc9 * 0x2 + 0x1 * 0x165c9) % (0x277 + 0x1cde + -0x1f52), '> double-tap', [-0x2ebbc46 + -0xc0d6663 + 0x1654efbe - (-0x7da81f * 0x14 + -0xbfc03df + -0x6 * -0x4dc2890), (-0x5 * -0x5166 + -0x3faca + -0x23da9 * -0x2) % (0x103e + 0x14ab + -0x24e6), -0x4930bf6 + 0x618b * 0x65d + 0x982278c - (-0x8288885 + 0x1cfa0f6 + 0xdb4b4a4), 0x5 * 0x4eb + 0x1fae * 0x1 + -0x3746], rw), rx.String(ry + (-0x26ae32 + 0x3 * -0xa07a1 + 0x6d75be * 0x1) % (-0x14b6 + 0x3d * 0x22 + -0x435 * -0x3), rz + sa, (0x2b061 + 0x11d98 + 0x419 * -0x6b) % (-0x1 * 0x1e27 + -0x1c62 + 0xea3 * 0x4), '> double-tap', [0x7 * -0x1e4 + 0x1dfa * -0x1 + -0x2c35 * -0x1, 0x3 * -0x4fd + 0xbf * -0xa + 0x4 * 0x5db, -0x3 * -0x83f + -0x2153 + -0xb * -0xdf, -0x263a + 0xa9d + 0x1c9c], sb), sc += -0x10 * 0x81 + 0x1 * -0xdb1 + 0x15cb;
                            }
                        } else {
                            Local.SetClanTag('jag');
                            break;
                        }
                    }
                    case -0x1088 + -0xf * -0x228 + -0xc0 * 0x15: {
                        if ('utaUA' !== 'bUmmT') {
                            Local.SetClanTag('ja');
                            break;
                        } else {
                            function sd() {
                                var a = a;
                                se = 0xf1 * 0x1d + 0x117 + 0x20 * -0xe0, sf.ForceTargetMinimumDamage(sg, sh + (-0x1e65 * -0xb66 + 0xc91 * 0x138d + -0x9f1 * 0x289d - (-0x6c77f * 0x17 + 0xe29007 + -0x75bdaf * -0x1)));
                            }
                        }
                    }
                    case -0x2703 + 0x958 + 0x1dbc: {
                        if ('hRhFX' !== 'siyfm') {
                            Local.SetClanTag('j');
                            break;
                        } else {
                            function si() {
                                sj = sk((0x2527b5 * 0x1 + 0x18eda4 + 0x10 * -0x1564b) % (-0x2 * 0x3c2 + 0x1561 + -0xdda), -0x2 * 0x57a + 0x234e * 0x1 + 0x184a * -0x1);
                            }
                        }
                    }
                    case -0x1081 + -0x1 * -0xfd + 0xf96: {
                        if ('oZQAg' === 'UQlvM') {
                            function sl() {
                                var a = a;
                                sm.ForceHitboxSafety(-0x5e2 * 0x1 + -0x1a5 + 0x26 * 0x33), sn.ForceHitboxSafety(-0x109 * -0x1 + -0x4 * -0x6b0 + -0x1bbd);
                            }
                        } else {
                            Local.SetClanTag(' ');
                            break;
                        }
                    }
                }
            }
            break;
    }
    lastcurt = oo;
    var oo, op;
}
UI.AddCheckbox(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW'], 'buy awp');

function dsal232323422232322sdsd3222232332323322223233323233233242323332323232322223342323223232223233434232342342342323422342342344234332k312323() {
    var a = a;
    so = Ragebot.GetTarget(), sp = dsal23422344234332k312323(so), sq = dsal23422342342342344234332k312323(so), sr = dsal24234332k312323(so), ss = dsal22344234332k312323(so), st = Entity.IsAlive(Ragebot.GetTarget()), su = Entity.GetName(Entity.GetWeapon(Entity.GetLocalPlayer())), sv = -0x16b * 0x19 + 0x1784 + 0xc0f;
    while (sv < 0x1 * -0x1fdf + 0x16b * -0xf + 0x3581 * 0x1) switch (sv) {
        case -0xb * -0x34d + 0x26b9 + -0x4ac8:
            sv = -0x331 * 0x7 + -0x5a + 0x1c6 * 0xd;
            return;
        case -0x2 * 0x44c + 0x12b2 * -0x1 + 0x1b6a:
            sv = UI.GetValue(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW', 'dynamic safepoint type']) == (-0x2ff68 * -0x1 + 0x2482 + -0x10c64) % (-0xa6b + 0x1e41 * -0x1 + 0x28af) ? -0x1fce + 0x110f * -0x1 + 0x311d * 0x1 : -0x2075 + -0x149 * -0xa + 0x13f8;
            break;
    }
    sw = 0x21a * 0x2 + 0x1171 + -0x158b * 0x1;
    while (sw < 0xa * 0x85 + 0x827 + -0xcc7) switch (sw) {
        case 0x25 * 0x3 + -0x32b * -0xb + -0xbb3 * 0x3:
            sw = 0x1 * 0xd05 + -0x13b3 + -0x1d0 * -0x4; {
                if ('wIrTI' === 'wIrTI') {
                    sx = -0x1dd7 + -0x789 + 0x2574;
                    while (sx < 0x137e + 0x192f + -0x2c29) switch (sx) {
                        case -0xf6f * 0x1 + 0x25be + -0x163b:
                            sx = UI.GetValue(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW', 'dynamic safepoint type']) == (-0x13 * -0xc03d + 0x2c57f3 + 0x1a113 * -0xb) % (-0xb18 + -0x24 * -0x3 + 0xaaf) ? 0x167d + 0x1 * 0x1692 + -0x2ceb : 0x1ac9 * -0x1 + -0x2065 * -0x1 + -0x589;
                            break;
                        case -0x1438 + 0x1e87 + -0x1 * 0xa2b:
                            sx = 0x1fa2 + 0x113d + 0x305b * -0x1; {
                                if ('pwQmt' === 'dVeAm') {
                                    function sy() {
                                        var a = a;
                                        if (sz) {
                                            var ta = tb.apply(tc, arguments);
                                            return td = null, ta;
                                        }
                                    }
                                } else {
                                    te = -0x430d6b1 + -0x289d34e + 0x141 * 0xa0fb7 - (0xbba276c + -0xa5f1d32 + 0x488003a);
                                    while (te < -0x6 * -0x2eb + -0x3f0 + -0xd27) switch (te) {
                                        case (-0x4 * -0x3a26a7 + 0x1021aa * 0xe + -0xdb82fc) % (0xe * -0x210 + -0x241b + 0x4101):
                                            te = sr == ![] ? 0x166d + 0xadd + -0x8 * 0x427 : 0x1 * -0x111a + 0x135 * -0x1f + -0x928 * -0x6;
                                            break;
                                        case -0x1502 + 0x74e + -0x6e3 * -0x2:
                                            te = -0x1 * -0x115f + -0x1 * -0x1b7 + 0x1b * -0xb1; {
                                                if ('wyKbj' !== 'wyKbj') {
                                                    function tf() {
                                                        var a = a;
                                                        tg = 0x1 * 0x149f + -0x4c7 * -0x7 + -0x35ac, th.ForceTargetMinimumDamage(ti, tj + (0x2659d + -0x4a1f8b + 0x706a97) % (-0x1ebf * 0x1 + 0x1 * 0x26af + 0x1 * -0x7ed));
                                                    }
                                                } else {
                                                    tk = -0xfb7 + 0x1 * 0xcb9 + -0x310 * -0x1;
                                                    while (tk < -0x151 * -0x7 + 0x1 * 0x116 + 0xa06 * -0x1) switch (tk) {
                                                        case 0x157 * 0x13 + 0xe29 + -0x278c:
                                                            tk = sp >= 0x916 + -0x1741 + 0xe4e ? (-0x131533c + -0x1acc326 + 0x3cd054e) % (0x1b59 * 0x1 + -0x1 * 0x962 + 0x3 * -0x5fb) : 0x28 * -0xc5 + -0x4a2 * 0x3 + 0x2a5 * 0x11;
                                                            break;
                                                        case (0x417e * 0x5c9 + -0x2cac6b + -0xd * 0x75433) % (0x1 * 0x24fe + 0xec * 0x1f + -0x4 * 0x1063):
                                                            tk = 0x1 * -0xa7f + -0x10f * -0x20 + -0x1 * 0x171a; {
                                                                if ('QcElP' !== 'cGmLk') Ragebot.ForceHitboxSafety(-0x18fd + -0x1 * 0x327 + 0x965 * 0x3), Ragebot.ForceHitboxSafety(0x14b3 + -0x25fe + 0x1157);
                                                                else {
                                                                    function tl() {
                                                                        tm();
                                                                    }
                                                                }
                                                            }
                                                            break;
                                                    }
                                                    tn = -0xa00 + -0x23c * 0xd + 0x275f;
                                                    while (tn < -0x2181 + -0x201b + 0x424a) switch (tn) {
                                                        case -0x13cf + -0x1 * 0x51 + -0x1475 * -0x1:
                                                            tn = -0x22f2 + 0xb75 + -0x10d * -0x17; {
                                                                if ('lvdJz' !== 'lvdJz') {
                                                                    function to() {
                                                                        var a = a;
                                                                        tp.String(tq.GetScreenSize()[0x35ee340 + -0x8362559 * 0x1 + 0xc330f2e - (0x8a6c6b1 + 0x44c27 * 0x145 + -0x15987d3 * 0x5)] / ((-0x3bcc65 * 0x13 + -0x2bad6099 + -0xca5c82 * -0x71) % (0x1aca + -0xc * -0x99 + -0x21ef)) + (0xebaf57 + -0x126bd37 * -0x1 + 0x5582d0 * -0x4 - (0x1156d7 * 0x6 + 0x12eb5bf + -0xda5d7c)) - (0xf5b + 0x1484 + -0x23c6), tr.GetScreenSize()[(-0x184859 + -0x4fe62b * -0x1 + 0xeed29 * -0x1) % (0x19 * -0xd1 + 0x4c9 * 0x7 + 0x1 * -0xd13)] / (0xda632 * -0x8 + -0x1dbc6b1 + -0x337e72f * -0x1 ^ -0xbec25 + 0x61 * -0x173bf + 0x187b670) + (-0xec7e31 + -0x2ef * -0x206b + 0x149c59a - (0x1 * -0xf34e24 + -0x2795e5 * -0x2 + 0x16083a7)) + (-0x3 * -0x92c + -0xc65 + -0xeed), 0x8a05e1f + -0x7047dce + 0x5bfecc4 - (0xa2b7268 + -0xbd5725 * 0xb + -0x2 * -0x2a98ca2), 'LEGIT-AA', [(0x13c83 + 0x2cb9a + 0xd * -0x2633) % (-0x9d + 0x1 * -0x752 + 0x7f2), 0x5406725 * 0x2 + -0xad5722f + 0x1c1edf * 0x46 - (0x889cdaa + -0xc70be05 + -0xc * -0xf03a74), 0x473 * 0xc236 + -0xd455078 + 0x1141074b - (0x2 * 0x1b21cf7 + 0x1 * -0x3d0921f + -0x3e412a3 * -0x2), ts], tt), tu.String(tv.GetScreenSize()[(-0x303c5 * -0x1 + 0x17be4 + 0x1d * -0x153f) % (0x105a + 0x9cc + -0x1a23 * 0x1)] / (-0x11be95e + 0x1249519 + 0xe64333 ^ -0x91359b + -0x122f207 + 0x2a3168e) - (-0x991 + 0x826 * -0x2 + 0x19f6), tw.GetScreenSize()[-0x928c18 + 0xcf56b4 + 0x7f96b2 - (-0xe00372 + -0x31fbfc * -0x1 + 0x16a68c3)] / (-0x58cec9 + 0xe32324 + 0x649a93 ^ -0xd7c4c2 + 0x1394221 + 0x1c49e9 * 0x5) + (0x1395 + 0x1da1 * 0x1 + -0x3104), (-0x10cff + 0xc2ea + 0x2619b * 0x1) % (0x8da + 0xf5f * 0x2 + -0x2795), 'LEGIT-AA', [tx[(0xe8f9 * 0x4 + 0xa8c5 + 0x23523 * -0x1) % (0x26a3 + -0x1 * 0x175d + -0xf43)], ty[(-0x3267c8 + 0x4cc97e + -0x5 * -0x2dc97) % (0x148f + 0x25b0 + 0x1d1e * -0x2)], tz[(-0x2d4442f3 + -0x1d2d4b54 + -0xabfd * -0xac25) % (0x1c9b + -0x2583 + -0x1 * -0x8ef)], ua], ub);
                                                                    }
                                                                } else Ragebot.ForceHitboxSafety((-0x1a7a0 + -0x25 * 0x19cd + -0x3 * -0x27ded) % (0xa17 * -0x1 + -0x2 * 0x628 + -0x13 * -0x12e)), Ragebot.ForceHitboxSafety(-0x164f420 + -0x1147f8 * -0x3 + -0x1ed7d86 * -0x1 - (-0x1068efc + -0x74f6ed + 0x237e736)), Ragebot.ForceHitboxSafety(0x7292e + -0x6a485 + 0xee899 - (0xec557 + 0x2699a + -0x5 * 0x59f1));
                                                            }
                                                            break;
                                                        case 0xa5 * -0x19 + -0x75d + -0x7ef * -0x3:
                                                            tn = sp >= 0x15de + 0xde0 + -0x5 * 0x71f && su != 'ssg 08' && su != 'glock 18' && su != 'usp s' && su != 'dual berettas' ? 0x25 * 0x7b + -0x1 * 0x732 + -0xa40 : 0x18c3 + 0x1 * -0x4ca + 0x1 * -0x134b;
                                                            break;
                                                    }
                                                    uc = 0x1c * -0x107 + -0xe * 0x16c + 0x30d7;
                                                    while (uc < -0xa5 * 0x3 + -0x1ac5 + 0x1 * 0x1d35) switch (uc) {
                                                        case -0x1120 * 0x1 + -0x8be + 0x1a09:
                                                            uc = sp <= -0xea9 + -0xc * -0x33 + 0xc63 || ss == !![] ? -0x353 + -0xd * 0x301 + 0x2a6c : -0x2 * 0xc14 + -0xf5 + -0x6 * -0x445;
                                                            break;
                                                        case -0x258e + 0xf63 + 0x1637:
                                                            uc = 0x6cc + 0x18e3 + -0x1f2e; {
                                                                if ('FnRSo' !== 'FnRSo') {
                                                                    function ud() {
                                                                        ue(-0x281 * -0x7 + -0x1 * -0x1be + -0x1322 * 0x1 - uf(-((-0x2c055fb + -0x116aa9 * -0x3a + -0xb20 * -0x5910) % (0xff6 + 0xd3 * -0x5 + -0xbd1)), -0x1 * -0x1ab936f + 0xdd * 0x1bbad + 0x1f4b49c ^ 0x84d94bd + 0xf9 * 0x47279 + 0x39415 * -0x219));
                                                                    }
                                                                } else Ragebot.ForceHitboxSafety(0x36848f * 0x1 + -0x11eadfa + 0x1d71859 ^ 0x186f4c + 0x1c7d13 + 0xba028d), Ragebot.ForceHitboxSafety((-0x8 * -0xc2fec3 + -0x356f * -0x2bbf + -0xa82763e) % (0x13af * 0x1 + -0x9d * -0x35 + 0x1163 * -0x3));
                                                            }
                                                            break;
                                                    }
                                                }
                                            }
                                            break;
                                    }
                                }
                            }
                            break;
                        case 0x5f1 + 0x1bbc + -0x219a:
                            sx = 0x246 * 0xe + 0xead + -0x2dfd * 0x1, ug = -0x69f + -0x74b + 0xdf6;
                            while (ug < -0x7ca + 0x25d4 + -0x1d92) switch (ug) {
                                case -0x114 + 0x319 * 0x2 + -0x50d:
                                    ug = 0x71f * 0x2 + -0x40f * 0x1 + -0x9b7 * 0x1; {
                                        if ('afeeK' === 'afeeK') {
                                            uh = -0x3 * 0xcdf + 0x35 * -0x8 + 0x2876;
                                            while (uh < -0x1433 * -0x1 + 0x1d8f + 0x107b * -0x3) switch (uh) {
                                                case 0x25b1 * -0x1 + -0x4 * 0x55e + 0x47 * 0xd6:
                                                    uh = sr == (NaN === NaN) ? -0x42ca37 + 0xad8e92 + 0x1 * 0x32c989 - (0xa * 0xdd28d + -0x85520d + 0x2f2 * 0x33d4) : -0x1 * -0x266b + 0x4a4 * -0x7 + 0x1 * -0x59e;
                                                    break;
                                                case 0x7c2e4e + 0x51ba4c + -0xf793 * 0x32 - (-0x8ec6c5 + -0x1396f55 + -0x5 * -0x7ac0cb):
                                                    uh = 0x46 * 0x89 + 0x1cf * 0x1 + -0x26f4; {
                                                        if ('xiQnj' !== 'ruMvo') {
                                                            ui = -0x183f + -0x9fb + 0x227f;
                                                            while (ui < 0x4f * -0x7b + 0x59 * -0x10 + 0x59 * 0x7f) switch (ui) {
                                                                case 0x1ebe57 + 0x10d * 0x92b + -0x18f344 - (-0x112 * -0xc8f + -0x1 * 0x19242b + -0x1 * -0x1b2059):
                                                                    ui = -0x7 * 0x21a + 0x411 * 0x3 + -0x7 * -0x73; {
                                                                        if ('yCkPb' !== 'yCkPb') {
                                                                            function uj() {
                                                                                var a = a;
                                                                                uk.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'watermark'], -0x1 * 0xb0a3c3 + 0x25 * 0x18769 + 0x13472e4 - (-0xec3 * -0x1885 + 0x1257df1 + -0x1d30ff3 * 0x1)), ul.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'indicators'], (0x16c3f8 + 0x4202d8 + 0x301627 * -0x1) % (-0x38f * 0x1 + 0x18f9 + -0x1 * 0x1567)), um.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'bind list'], (-0x2 * -0x22fee + 0x260d64 + 0x55 * -0x53b) % (-0x4 * -0x92b + -0x4cb * -0x4 + 0x37d5 * -0x1)), un.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'indicators color'], 0x1be254 + 0x140de40 + -0xa05f46 - (-0x3edfb1 * 0x3 + -0x1 * -0x990aed + 0xbac1 * 0x133));
                                                                            }
                                                                        } else Ragebot.ForceHitboxSafety((-0xe6cc + -0x2b4af + 0x123cd * 0x5) % (-0x126a + -0x4 * -0x3f1 + 0x3 * 0xe3)), Ragebot.ForceHitboxSafety(-0x3 * -0x145c0b + 0xb7589b + -0x380b6e - (-0x6256 * -0x175 + -0xb0e519 * -0x1 + -0x83cb1a)), Ragebot.ForceHitboxSafety((0x3 * 0x7d49 + -0x7 * 0x98cbb + 0x79536c) % (0x1131 + 0x3 * 0x91b + 0xe * -0x32d));
                                                                    }
                                                                    break;
                                                                case -0xeff + -0x2d * 0xbd + -0x1 * -0x307d:
                                                                    ui = su != 'ssg 08' && su != 'glock 18' && su != 'usp s' && su != 'dual berettas' ? 0x10 * 0x4143 + 0x2c93c + 0x88fd6 - (0x18dd7e * 0x1 + -0x1 * 0x15428b + 0xbd249) : 0x20 * -0xf7 + -0x16d + 0x20ef;
                                                                    break;
                                                            }
                                                            uo = -0x16ce + -0x1578 + -0xb * -0x40f;
                                                            while (uo < -0x269f * -0x1 + -0x833 * -0x4 + -0x7a * 0x95) switch (uo) {
                                                                case (-0x1bd2a * -0x347 + -0x5a750 * -0x83 + 0x433eb79 * -0x1) % (-0xfc2 + 0x1 * 0x20eb + -0x1120):
                                                                    uo = -0x2e5 + 0x20b8 + 0x5 * -0x5e2; {
                                                                        if ('hwuRC' === 'jSSrl') {
                                                                            function up() {
                                                                                uq = -0xdf8 + 0x6fd * 0x5 + -0x14ea;
                                                                            }
                                                                        } else Ragebot.ForceHitboxSafety((0x399 * 0x279d1 + -0x1 * 0xffd36c1 + -0x8a * -0x5994dd) % (0x8b * 0x2d + 0x1f75 + -0x7 * 0x7fb)), Ragebot.ForceHitboxSafety((0x3d9 * 0x4738d + -0x18cda4b + -0x2d * -0x5ef66b) % (0x607 * 0x2 + 0x1ebd + -0x2ac2));
                                                                    }
                                                                    break;
                                                                case 0x40 * -0x7 + 0x2427 + 0x2c * -0xc6:
                                                                    uo = sp < -0x1d50 + -0x3 * -0x17c + 0x18fa || ss == (NaN !== NaN) ? (0x666f6ca + -0xafdbf9 * 0x4 + 0xbc2037) % (-0xe0 * -0x1b + -0x1de5 + 0x64e) : -0x1b90 + -0x361 + 0x1f5a * 0x1;
                                                                    break;
                                                            }
                                                            Ragebot.ForceHitboxSafety(0x19d6 + 0x41 * -0x5e + -0x1 * 0x1ed), Ragebot.ForceHitboxSafety(-0x1 * 0x241 + -0xb * -0x1d + -0xf * -0x12);
                                                        } else {
                                                            function ur() {
                                                                var a = a;
                                                                us.String(ut.GetScreenSize()[-0x348c6a1 + 0x479f022 + -0x16 * -0x47c19e - (-0xc61215e + -0x6fbdfc4 + -0x3 * -0x8e844bd)] / (0x19e3b69 + 0xd47e11 + -0x183ca8c ^ -0x4f8c27 * 0x4 + 0x1 * 0x187508a + -0x212966 * -0x5) + (-0xa9c + 0x2c * 0x6f + -0x2 * 0x423), uu.GetScreenSize()[-0x146032 * 0xb + 0x9de0eb * 0x1 + 0xfea289 - (0x1 * 0x920417 + 0x4cc977 * -0x3 + 0x110b99b)] / ((-0x1 * 0x4f8266c + 0xb46b * -0x418a + 0x16 * 0x432cfd6) % (0x7 * 0x181 + -0xd5c + 0x2dc)) - (-0xba1 + 0x19eb + -0xe3c), (-0x1 * -0x396e9 + 0x1 * -0x22547 + 0xa5e4) % (-0x3 * 0xfe + -0x922 + 0xc1f), '>', [uv[(-0x891b * -0x7 + -0x1 * -0xdef3 + 0x2872a * -0x1) % (-0x18ca + -0xb * -0x205 + 0x296 * 0x1)], uw[0x718f68 + 0x147536b * 0x1 + -0xfc8185 - (0x3 * 0xc6b85 + 0x1 * -0xafb30a + 0x146d1c8)], ux[(-0x12f1f * -0x2dbb + 0xfad2be2 + 0x11a91 * -0x19ed) % (0x8 * 0x221 + 0x18a8 + 0x855 * -0x5)], -0x2dd * 0x8 + 0x1eb * -0xc + 0x2eeb], uy);
                                                            }
                                                        }
                                                    }
                                                    break;
                                            }
                                        } else {
                                            function uz() {
                                                va(0x1d32 + 0x163f + -0x3281);
                                            }
                                        }
                                    }
                                    break;
                                case -0x1 * -0x1a2f + -0xd22 + 0x1 * -0xd01:
                                    ug = UI.GetValue(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW', 'dynamic safepoint type']) == (-0x1507b08 + 0x3456e5 * 0x1 + 0x20b1311 ^ -0x371e72 + 0x16 * 0x46ce7 + 0x47ef * 0x2bc) ? -0x1cda + 0x2 * -0xd26 + 0x3737 : -0x23 * -0xf3 + -0x358 * 0x1 + -0x1d69;
                                    break;
                            }
                            break;
                    }
                } else {
                    function vb() {
                        var a = a;
                        vc.SetValue(['Rage', 'Fake Lag', 'General', 'Limit'], 0x1081 + -0x12c9 + 0x1 * 0x257);
                    }
                }
            }
            break;
        case -0x25e1 + -0x184a * -0x1 + 0xdb1:
            sw = st == (NaN !== NaN) ? -0x17c2 + 0x1e93 * 0x1 + -0x6a2 : 0x6d * -0x43 + 0x1405 + -0x7 * -0x14c;
            break;
    }
    var so, sp, sq, sr, ss, st, su, sv, sw, sx, te, tk, tn, uc, ug, uh, ui, uo;
}
UI.AddCheckbox(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW'], 'jag0-walk');

function dsal23422344234332k312323(vd) {
    ve = dsal23422342342342344234332k312323(vd), vf = ve / (0x1009e95 + -0x16d78db + 0x408ea8e * 0x1 & 0x8 * -0xb06a70 + 0x15a6f22 + 0x88c8b7b);
    return -0x11a9 + 0xd2c + -0x11 * -0x47 - vf;
    var ve, vf;
}
UI.AddCheckbox(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW'], 'freestanding on edge'), UI.AddCheckbox(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW'], 'unlock fakelag');

function dsal23422243234232342342342323422342342344234332k312323(vg, vh, vi) {
    return vg <= vh ? vh : vg >= vi ? vi : vg;
}
UI.AddCheckbox(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW'], 'jag0-tag');

function dsal234223423423423423422342342344234332k312323(vj) {
    return vj * Math.PI / (-0x79 + -0x1 * -0x1391 + -0x1264);
}
UI.AddCheckbox(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW'], 'faster dt');

function dsal24234332k312323(vk) {
    var a = a;
    vl = Entity.GetProp(vk, 'CBasePlayer', 'm_fFlags'), vm = 0x1f60 * -0x1 + -0x1963 * -0x1 + -0x1 * -0x64b;
    while (vm < 0x15b9 + 0x1a03 + -0x2f63) switch (vm) {
        case 0x807 + -0x7 * 0x478 + 0x178f:
            vm = !(vl & -0x7d06c6 + 0x11a005f + 0x1f67b5 - (-0xd3527e + 0x3ef6b1 + -0xf86e * -0x15b) << (-0x2a1 * 0x191 + -0x167e * 0x16 + 0x8248b) % (0x268a + 0xd9 * 0x16 + 0x29 * -0x165)) && !(vl & (-0x10145a + -0x4 * 0xf1f0a + 0x75412b) % (0x38b * -0x4 + 0x3 * -0x27f + 0x49 * 0x4c) << -0x209c + -0x5 * -0x17b + -0x3 * -0x86d) ? -0x5e2 + 0x2b1 * 0x1 + 0x1 * 0x375 : 0x1 * 0x14b9 + -0xc * -0x282 + -0x32a4;
            break;
        case -0x1f01 + -0x1 * 0xfb8 + 0x2efd:
            vm = 0x19ac + -0x2562 + 0xc0f;
            return -0x1ab1 * 0x1 + 0x97e + 0x1134 == '1';
        case 0x2 * -0x1031 + -0x5 * -0x5ed + 0x2 * 0x177:
            vm = 0x1b25 * 0x1 + 0x183 + -0x1c4f;
            return null === undefined;
    }
    var vl, vm;
}
UI.AddCheckbox(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW'], 'jitter movement');

function dsal2342223243223434232342342342323422342342344234332k312323(vn, vo, vp, vq, vr, vs, vt, vu) {
    var a = a;
    vt = (-0x1d1a + 0x239d + 0x51b * -0x1) / vt, vv = 0x506 + 0x85d * -0x2 + 0x61 * 0x1f;
    while (vv < -0x21 * -0x4d + -0x570 + 0x1 * -0x426) {
        if ('cHcav' === 'kaXbs') {
            function vw() {
                var a = a;
                vx.SetValue(['Rage', 'Anti Aim', 'Directions', 'Auto direction'], -0x43be8c4 + -0x30eb3 * 0x61 + -0x4 * -0x33011eb - (0x5fc4e7b + -0x2 * 0x6a100a5 + 0xea17fe4));
            }
        } else switch (vv) {
            case 0x19ab + -0x647 + -0x121 * 0x11:
                vv = vy < vr + vs ? -0xa7c + -0x26c4 + 0x47 * 0xb2 : 0x1047 + -0x166 + -0xe8a;
                break;
            case -0xa * 0x38f + 0x222a + 0x177:
                vv = -0x80 + 0x1017 + -0xf64, vy = vr;
                break;
            case 0xe6 * -0x1b + 0x1 * -0xc92 + 0x251a:
                vv = -0x658 * 0x4 + 0x1a6b * 0x1 + -0xd8, vy = vy + vt;
                break;
            case 0x2 * -0x1a + -0xddd + 0xe2f:
                vv = 0x29e + 0x2c1 + 0x5 * -0x105; {
                    if ('hDCAj' === 'LOMfp') {
                        function vz() {
                            var a = a;
                            wa.OverrideShift(0x8cb1701 + -0x1 * 0xd8b1b67 + 0xc1bd17b - (-0x2b * -0x3ecb9d + -0xe45e88 * 0x4 + 0x56e5 * 0x11e)), wb.SetInt('cl_clock_correction', (-0x2 * 0x1b5779 + -0xa830f * 0x3 + -0xfdd19 * -0x8) % (-0x1447 + -0x188d + 0x2cd7));
                        }
                    } else wc = vy * Math.PI / (-0x1ae8 + -0x264e * 0x1 + 0x41ea), wd = (vy + vt) * Math.PI / (0x2 * 0xec9 + -0xd14 + -0xfca), we = Math.cos(wc), wf = Math.sin(wc), wg = Math.cos(wd), wh = Math.sin(wd), wi = vn + we * vq, wj = vo + wf * vq, wk = vn + we * vp, wl = vo + wf * vp, wm = vn + wg * vq, wn = vo + wh * vq, wo = vn + wg * vp, wp = vo + wh * vp, RenderHooked.Polygon([
                        [wk, wl],
                        [wo, wp],
                        [wi, wj]
                    ], vu), RenderHooked.Polygon([
                        [wi, wj],
                        [wo, wp],
                        [wm, wn]
                    ], vu);
                }
                break;
        }
    }
    var vv, vy, wc, wd, we, wf, wg, wh, wi, wj, wk, wl, wm, wn, wo, wp;
}
UI.AddCheckbox(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW'], 'dynamic leg movement'), UI.AddCheckbox(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW'], 'legit desync at-targets');

function dsal232323422223232332432323232322223342323223232223233434232342342342323422342342344234332k312323() {
    var a = a;
    wq = dsal23422243234232342342342323422342342344234332k312323(Math.abs(Math.round(Local.GetRealYaw() - Local.GetFakeYaw())), 0x1064eea + -0x47c59ce + 0x6a7 * 0x1a05f - (0x125 * 0x25325 + 0xa * -0x43e35d + 0x759855e), -0x1ad4 + 0x1 * 0x179b + 0x1 * 0x373), wr = Entity.GetLocalPlayer(), ws = Entity.IsAlive(Ragebot.GetTarget()), wt = left_distance = dsalkj2k3(wr, [(0x3842 + -0x1ad34 + 0x38c78) % (-0x25 * 0xcb + 0x1779 + 0x5e1), Local.GetViewAngles()[(-0x3 * 0x147d6f + -0xff719 + 0x76200f) % (-0x1f27 + -0x2237 * 0x1 + 0x957 * 0x7)] - (0x1 * -0x114e + 0x1b * 0xbc + 0x1 * -0x26f)]) - (right_distance = dsalkj2k3(wr, [0x3e89b71 + 0x14d629 * 0x1c + -0x2 * -0x95e294 - (-0x54c652d + -0x9ec8fbf * -0x1 + -0x7 * -0x63f2a5), Local.GetViewAngles()[(0x3bd9a4 + 0x92 * -0x845e + 0x29 * 0x15fb9) % (-0xb * 0x33 + 0x141 + -0x51 * -0x3)] + (-0xade + 0x245 + 0x8b0)])), wu = dsalkj2k3(wr, [(0x7d33 * -0x6 + -0xa31 * 0x4f + 0x1 * 0x82bd7) % (0x7c4 + -0x6aa + -0x117), Local.GetViewAngles()[(-0x1051 * 0x367 + -0x2b4a47 * -0x1 + -0x1 * -0x34e9f9) % (0x134a + -0x11e6 + -0x161)]]), wv = UI.GetValue(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW', 'jag0-walk switch']), ww = dsal2342234232342342342323422342342344234332k312323(-0x3f5e21f + -0x5521604 + 0x162fb1a * 0xc - (0x5ac604 * 0xf + -0x1 * -0x8e3c5fd + -0x643 * 0x1180c), (-0x13ab864b + 0x145e76 * 0x171 + 0x1f84a77f) % (-0x11d2 + -0x416 * 0x3 + 0x1e1b)), wx = dsal2342234232342342342323422342342344234332k312323(-wv, wv), wq = 0x21b8 + 0x1088 + -0x3221, wy = 0x6d + -0x2c * -0x2c + 0x5b * -0x16;
    while (wy < 0x114e + -0xc * -0x12a + -0x8 * 0x3df) switch (wy) {
        case -0x2082 + -0x1989 * -0x1 + -0x392 * -0x2:
            wy = UI.GetValue(['Rage', 'Anti Aim', 'General', 'Key assignment', 'legit desync']) == (null == undefined) ? 0x375 + -0x14ba + 0x1188 : -0x1655 * -0x1 + -0x2 * 0x9f + -0x6ff * 0x3;
            break;
        case -0x2de * 0x2 + -0xd7f + 0x137e:
            wy = -0x33 * 0x8a + -0x1014 + 0x30 * 0xea; {
                if ('NzxLM' === 'gFJTV') {
                    function wz() {
                        xa = ![];
                    }
                } else {
                    xb = -0x1 * -0xb89 + -0x2 * -0x5ea + -0x171e;
                    while (xb < 0x2285 + 0x1 * -0x15 + -0x21c5 * 0x1) switch (xb) {
                        case 0x167e * -0x1 + -0x1c54 + 0x330f:
                            xb = -0x1 * -0x18d9 + 0x1312 * 0x1 + -0x2b40, UI.SetValue(['Rage', 'Anti Aim', 'Directions', 'At targets'], 0x13f * 0x7a0ad + -0x5f7 * 0x4bd8 + -0x610516 * 0x1 - (0x2465b38 + -0x558756d * 0x2 + -0x1 * -0xfc65cb7));
                            break;
                        case 0x6f5 + -0x253a + 0x1e8f:
                            xb = -0x17 * 0x152 + 0x2ea + 0x139 * 0x17, UI.SetValue(['Rage', 'Anti Aim', 'Directions', 'At targets'], -0x8 * 0x13c96b + 0xecc5c5 + -0x6de6e1 * -0x1 - (-0x13afe01 * 0x1 + 0x4ead * 0x2ad + 0x124da65));
                            break;
                        case -0xde * -0x12 + -0x1b4 * 0x14 + 0x12b3:
                            xb = UI.GetValue(['Config', 'JAGO-YAW', 'JAGO-YAW', 'legit desync at-targets']) == (null == undefined) ? 0x5 * 0x3ad + -0x4 * 0x384 + -0x407 : 0x10eb + 0x18f2 + -0x29a0;
                            break;
                    }
                    UI.SetValue(['Rage', 'Anti Aim', 'Directions', 'Auto direction'], -0x7362938 * -0x2 + 0xeb788d9 + -0x15c80e34 * 0x1 - (-0x1 * -0x52aa73 + 0x88 * -0xd2145 + 0x4ab9a6e * 0x3)), UI.SetValue(['Config', 'Cheat', 'General', 'Restrictions'], (0x2ffd6 + 0x2eb5 * -0x9 + 0x14e5 * 0x9) % (-0x5ad * 0x5 + -0x2157 + -0x1 * -0x3dbb)), UI.SetValue(['Rage', 'Anti Aim', 'Directions', 'Yaw offset'], 0x1a95 * -0x1 + 0x15f6 + 0x553), UI.SetValue(['Rage', 'Anti Aim', 'Directions', 'Jitter offset'], 0x4921cf8 + 0x279db46 + 0x4fd4d7 * 0x1 - (-0x4e7be0f + -0xd4e0779 + 0x1f * 0xd325c3)), xc = -0x13 * 0x6 + 0x1 * -0x1aa3 + 0x6 * 0x487;
                    while (xc < 0x7b8 + -0x13a4 + 0xc8b * 0x1) switch (xc) {
                        case -0xf75 + 0xcd2 + 0x2b8:
                            xc = UI.GetValue(['Config', 'JAGO-YAW', 'JAGO-YAW', 'freestanding on edge']) == ([null] == '') && wu <= 0x1c31 + -0x2 * 0xc5b + -0x1 * 0x353 ? -0x2a3 + 0xbc2 + 0x232 * -0x4 : 0x6bc + 0x1 * -0x431 + 0x1 * -0x23b;
                            break;
                        case 0x1 * 0x24be + -0x7af + -0x1cb8:
                            xc = 0x279 * -0x6 + 0xa7 * 0x7 + 0x2b9 * 0x4, UI.SetValue(['Rage', 'Anti Aim', 'General', 'Pitch mode'], 0x1 * -0x564035 + 0xbb1e1e + 0x1 * 0x578365 - (-0x134ae83 + -0x2 * -0x4cc4f3 + -0xb14d6 * -0x1f));
                            break;
                        case 0x175 * -0x5 + -0x189f + -0x80e * -0x4:
                            xc = 0xa3 * -0x4 + 0x16d9 + -0x13ae, UI.SetValue(['Rage', 'Anti Aim', 'General', 'Pitch mode'], -0xa * 0xd87819 + 0x8d21a9 + 0xd27f6 * 0x129 - (0x368b140 + -0x3d1532 * 0x25 + 0xcc72c0f));
                            break;
                    }
                }
            }
            break;
        case -0x1 * -0x24fe + 0x4 * -0x9a9 + 0x2 * 0xe0:
            wy = 0x556 + 0x6 * -0x319 + 0xd8e; {
                if ('dLxZQ' !== 'dLxZQ') {
                    function xd() {
                        var a = a;
                        xe.SetOverride((-0x50d41 * 0x3 + -0x18f49 * -0x1 + 0x1 * 0x364923) % (-0x1a40 + 0x8dd * 0x2 + 0x889)), xf.SetFakeOffset(xg), xh.SetRealOffset(-(-0x1d * -0x133 + -0x1 * -0x66b + 0x2921 * -0x1) - xi * -((0x412666 + -0x87 * 0x24c3 + -0x512e8) % (-0x4dc * 0x4 + -0x31a * 0x6 + 0x260f))), xj.SetLBYOffset((0xeabb * -0x1 + 0x199cf * 0x1 + 0x111 * 0x152) % (-0x3e4 * -0x1 + 0x2 * -0xc42 + -0x24b * -0x9)), xk = 0xe6 + 0x40 * 0x60 + -0x18e5 == '1', xl = -0x14a83f * 0x4e + -0x363e6a8 + -0x2 * -0x691494b - (0x2c3088b * -0x1 + 0x20 * 0x1050eb + 0x42c53e4);
                    }
                } else {
                    UI.SetValue(['Config', 'Cheat', 'General', 'Restrictions'], 0x1a14 * -0x77d2 + 0x8734417 + 0xb1d3966 - (0x2e2e8 * -0x83 + 0x8e22e7d + -0x1 * 0xc44b0)), UI.SetValue(['Rage', 'Anti Aim', 'Directions', 'At targets'], 0x7fafd0 + -0x4acca9 + -0x89 * -0xfd2f - (0x9e06fb * -0x1 + 0x346 * 0x2b2d + 0x9da * 0x14d1)), UI.SetValue(['Rage', 'Anti Aim', 'Directions', 'Yaw offset'], -0x1 * -0xe18b2e9 + 0x6ea4e0 + 0x4 * -0x1cae2ad - (-0x5c380d5 + -0xaa75bcd * -0x1 + 0x277f21d)), UI.SetValue(['Rage', 'Anti Aim', 'Directions', 'Jitter offset'], -0x6 * 0x530a57 + -0x7d33 * -0x840 + -0x39 * -0x17ab57 - (0x41f8675 * 0x3 + -0x22f42 * 0x562 + 0x6bf9afa)), UI.SetValue(['Rage', 'Anti Aim', 'General', 'Pitch mode'], 0xabcebd + 0x79885 + 0x8fa0c - (-0x19 * 0x2461d + -0x15432c6 + 0x2496ce8)), xm = -0xc0a * 0x1 + 0xb8d + 0xa6 * 0x1;
                    while (xm < -0x13fd + 0x1 * 0x7eb + 0xcc7) switch (xm) {
                        case 0x1b7c + -0x62 * 0x10 + 0xc9 * -0x1b:
                            xm = UI.GetValue(['Rage', 'Anti Aim', 'General', 'Key assignment', 'freestanding']) == ([null] == '') && jagowalking == (0xd * 0x4 + 0xb8d + 0xbc * -0x10 === '1') && dsal24234332k312323(wr) == (null === undefined) && dsal22344234332k312323(wr) == ([-0x17 * -0x172 + 0x1fb8 + -0x40f6] == '') || wu <= -0x17ef + -0xeb + -0x856 * -0x3 && jagowalking == ([-0x1242 + 0x1a3d + -0x7fb] == '') && dsal24234332k312323(wr) == ([0x50e * 0x3 + 0x69 + -0xf93] == '') && dsal22344234332k312323(wr) == (null === undefined) && UI.GetValue(['Config', 'JAGO-YAW', 'JAGO-YAW', 'freestanding on edge']) == (null == undefined) ? -0x1216 + -0x1184 + -0xbf7 * -0x3 : 0x11 * 0x1ba + -0xe66 + -0xe92;
                            break;
                        case -0x29d * 0xc + 0x2268 + -0x3 * 0xeb:
                            xm = -0x1 * 0x293 + 0x256e + 0xb62 * -0x3; {
                                if ('uBXqS' !== 'uBXqS') {
                                    function xn() {
                                        xo();
                                    }
                                } else UI.SetValue(['Rage', 'Anti Aim', 'Directions', 'Auto direction'], -0xfb3f34 + 0x111a842 + 0xa5f840 - (0xf08949 + 0x3db4a6 + -0x71dca2));
                            }
                            break;
                        case -0xd85 * 0x1 + 0x604 + 0x7e3:
                            xm = -0xf9f + -0x391 + 0x13e5 * 0x1; {
                                if ('BBnYA' !== 'gVzLA') UI.SetValue(['Rage', 'Anti Aim', 'Directions', 'Auto direction'], (0x1 * -0x2ca37 + 0x23418 + 0x2ada5) % (-0x47 * 0x54 + 0x3 * 0x70f + -0x222 * -0x1));
                                else {
                                    function xp() {
                                        var a = a;
                                        xq = xr / (-0xe7 + 0x1c1d + -6963.5), xs.ForceTargetMinimumDamage(xt, xu + (-0x6 * 0xbf27 + 0x440f3 * 0xb + -0x3e * 0x6b1) % (0x6ac + -0xc2d * 0x2 + 0x11b1));
                                    }
                                }
                            }
                            break;
                    }
                }
            }
            break;
    }
    xv = -0x197 + -0x1296 + 0x1437;
    while (xv < -0x18a7 + -0xde * -0x1 + 0x1805) switch (xv) {
        case 0x8 * -0x33e + -0x1 * -0xcfe + 0xcfc:
            xv = UI.GetValue(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW', 'jag0-walk']) == ([null] == '') && UI.GetValue(['Rage', 'Anti Aim', 'General', 'Key assignment', 'Slow walk']) == (null == undefined) && UI.GetValue(['Rage', 'Anti Aim', 'General', 'Key assignment', 'legit desync']) == (NaN === NaN) ? 0x107 * -0x1 + -0x24fa + 0x3 * 0xcb6 : (-0x141307 * -0x12 + -0x290249 + 0x4083 * -0x143) % (0x6 * -0x11d + -0x1 * 0x125b + 0x190f);
            break;
        case -0x4c706f * -0x7 + -0x1e4d8a8 * -0x1 + 0x4d5 * 0x2329 & -0x7 * 0x22b5b + 0xe6a2e4 * 0x7 + 0x9905ef * -0x5:
            xv = -0x17 * 0x17d + -0x15c4 * 0x1 + 0x383b * 0x1; {
                if ('ZbCMD' !== 'hKwqo') {
                    jagowalking = -0x161f + -0x5 * -0x7bb + 0x1 * -0x1087 === '1', xw = 0x1 * -0x17e9 + 0x1c32 + -0x1 * 0x3f2;
                    while (xw < 0x1f * 0x49 + 0x39d * 0x5 + -0x1a38) switch (xw) {
                        case -0x20a1 * 0x1 + -0x32f + 0x2431:
                            xw = -0xc5 * 0x27 + 0x476 + -0x3 * -0x8bf; {
                                if ('ZdLXs' === 'ZdLXs') {
                                    xx = -0xa4711bb + -0x12e432 + 0x103d0065 * 0x1 - (0x56f9cb8 + 0x216569c + 0x3bd820 * -0x7);
                                    while (xx < 0xa * 0x3b3 + 0x1dab + -0x13 * 0x37d) switch (xx) {
                                        case -0xae3 * 0x188f + -0x7f4a2cb + -0x4f * -0x2c39ba & -0x1 * 0x189dca9 + -0x3d40cc6 + 0x8a01083:
                                            xx = UI.GetValue(['Rage', 'Anti Aim', 'General', 'Key assignment', 'legit desync']) == ([null] == '') ? 0x1 * 0x1f3f + -0x3d * 0x43 + -0x1 * 0xf17 : -0x5 * -0x59c + -0x11 * 0x2e + -0x189d;
                                            break;
                                        case 0x85 * 0x43 + -0x2 * 0x31a + -0x1c6a:
                                            xx = -0x16aa + -0x211 + 0x191d; {
                                                if ('Eukct' === 'Eukct') {
                                                    AntiAim.SetOverride(0xf519a4 + -0x7bb4d9 + 0x42fc83 - (-0x34f43f * 0x1 + -0x623c67 + -0x1edeb9 * -0xb)), AntiAim.SetFakeOffset(-0x22401 + 0xb9d980e + -0x3a * 0x12c0ac - (0x2978e60 + 0x73b4dbf + -0x2 * 0x13b8785)), xy = -0x2421 + -0x1407 + -0x3882 * -0x1;
                                                    while (xy < -0xd3 * 0x1 + -0xaba * 0x3 + -0xb2b * -0x3) switch (xy) {
                                                        case -0x125f * 0x1 + 0x1e5d + -0xba4:
                                                            xy = ww == (0x2 * -0x12009 + 0x1 * -0x110fb + 0x56893) % (-0x1222 + -0x1f4d + 0x3172) ? -0x1253 * 0x1 + 0x1 * 0x2485 + -0x11e5 : 0x10c6 + 0xdf * -0x29 + -0x17b * -0xd;
                                                            break;
                                                        case 0xeeb + 0x1 * -0x1410 + 0x573:
                                                            xy = 0xdb4 + 0x1278 + -0x1fac * 0x1, xz = -0x523 + 0x1 * -0x1391 + 0x4d * 0x53;
                                                            while (xz < -0x6 * -0x4d5 + -0x2 * -0x18d + -0xa7f * 0x3) switch (xz) {
                                                                case -0x112f + 0x2351 * -0x1 + 0x266 * 0x16:
                                                                    xz = 0x16ed + -0x9aa * -0x4 + -0x3cfa, AntiAim.SetRealOffset(-(0x1336 + -0x1 * 0x10e9 + 0x17 * -0x17));
                                                                    break;
                                                                case 0x1c83 + 0x2678 + -0x42b8:
                                                                    xz = ww == (0x1 * 0x50eaf5 + -0xd * 0x4a36a + 0xde * 0x1725) % (0xca2 + 0x1a74 + -0x595 * 0x7) ? -0x29 * -0x9d + -0x13d * -0xf + -0x2b74 : 0x157f * 0x1 + -0x1afa + -0x52 * -0x13;
                                                                    break;
                                                            }
                                                            break;
                                                        case 0x17e5 * 0x1 + -0x1bd2 + -0x43a * -0x1:
                                                            xy = -0xa24 + -0x49 * 0x14 + 0x1058, AntiAim.SetRealOffset(0x26d0 + -0xe08 + -0x188c);
                                                            break;
                                                    }
                                                    AntiAim.SetLBYOffset((0x1 * 0x5cc8 + 0xfa7 * -0x11 + -0x3 * -0xec47) % (-0x15d2 + 0x9 * -0x265 + 0x2b62)), side = (0x1b5b301 + -0xd8965d + 0x3d9e607) % (-0x142f * 0x1 + -0x2597 + 0x39cd);
                                                } else {
                                                    function ya() {
                                                        var a = a;
                                                        yb.String(yc.GetScreenSize()[(-0x413c3 + -0x1a3f3 * -0x2 + 0x1d * 0x197f) % (-0x7c7 * 0x1 + -0x1ffa + -0x7f4 * -0x5)] / (-0x17a8173 + -0x4 * 0x4ddbe2 + 0x3a0dfe9 ^ 0x1471a53 + 0x5fe372 * -0x3 + 0xc77eef) + (0x18f3 + -0x14c9 + -0xfe * 0x4), yd.GetScreenSize()[(-0x3d375 * 0x2 + -0x44e444 + 0x2dbff * 0x29) % (-0x1 * -0x1453 + -0xa9 * -0x5 + -0xd * 0x1d1)] / ((0x140780c6 + 0x5f889bb * 0x9 + -0x208f0f0f) % (-0x2363 * 0x1 + 0x1921 + 0xa49)) - (0xfe6 + -0x796 + -0x2 * 0x421), (0x241ed * 0x1 + -0x42b70 + 0x40109) % (0x1 * -0x3a + 0x111a + -0x10dd), '>', [0x1cf * -0x12 + 0xbb * -0x34 + -0xbca * -0x6, -0x1 * 0xca3 + 0x23a4 + -0x16cf * 0x1, 0x1 * 0xc4 + -0xa51 * 0x2 + -0x282 * -0x8, -0x271 * -0x10 + 0x5 * -0xb7 + -0x22e7], ye), yf.String(yg.GetScreenSize()[-0x1 * -0x2e5da7 + -0xea7a20b + 0x15d51179 - (-0x2165ff * -0x9 + 0x40c090 + 0x5ee768e)] / ((-0x1d3a079c + -0x2e1c8ae6 + -0x1805be * -0x4da) % (0x821 * 0x2 + -0x1c2a + -0x1 * -0xbef)) - (-0x4 * 0x43c + 0x5 * 0x3e8 + -0x256), yh.GetScreenSize()[-0x5be92b + 0xd2cbf8 + 0x457e81 - (-0x3f1de3 + 0xc50aa1 + 0x36748f)] / (0x9fc304 + 0xd4825 * -0xe + -0x3 * -0x585f50 ^ 0x8d6162 + -0x158c39c + 0x1ba5126) - (-0x163d + -0x1d47 + 0x3392), 0xd1 * 0x2c0b0 + 0x59ef974 + 0x1 * -0x827c0f - (-0xce597 * -0xf1 + -0x71fc983 + 0x2577371), '<', [-0x189f * -0x1 + -0x199b + 0x12e, 0x888 + -0xdff + 0x7 * 0xcf, -0x7e1 * 0x1 + -0x541 * 0x3 + 0x9 * 0x2a6, -0x5 * -0x6b4 + 0xfe9 * -0x2 + -0x11c], yi);
                                                    }
                                                }
                                            }
                                            break;
                                        case -0xf5e + -0x2 * -0x6a2 + -0x1 * -0x27b:
                                            xx = -0x6bb * 0x1 + 0x1dba + -0x7 * 0x33b; {
                                                if ('ZjiEu' === 'ZjiEu') {
                                                    AntiAim.SetOverride(0x7 * 0x359752 + 0x10ffffc + -0x1cac1ec - (-0xd * -0x96545 + 0x6446ec + 0x11051 * -0x20)), AntiAim.SetFakeOffset(0x840ab * 0x126 + -0xc74c63b + 0xa564eee - (0x4f451 * -0x1e2 + 0xa13a5e3 + 0x69c27b4)), yj = -0x1a7d * 0x1 + 0x160f + 0x483;
                                                    while (yj < 0x1882 + -0xa5e + -0xdbe) switch (yj) {
                                                        case 0x1 * -0x5ad + -0xbe * 0x21 + 0x1e70:
                                                            yj = 0x799 * -0x3 + -0x939 + 0x206a, yk = 0x2085 * 0x1 + 0x7 * -0x3c0 + -0x621 * 0x1;
                                                            while (yk < 0x5 * 0x1c6 + -0x3 * -0x571 + -0x18ba) switch (yk) {
                                                                case -0x246 + 0xf2a + 0x2 * -0x660:
                                                                    yk = ww == (-0xff509 + -0x24d9 * -0x13d + -0xb04fd * -0x1) % (0x526 * -0x6 + 0x26e7 + -0x800) ? -0x3e6 * -0x2 + -0x1 * 0x23b1 + 0x1bff : 0x14ad * 0x1 + 0x1db8 + -0x31ee;
                                                                    break;
                                                                case -0xf3f + -0x1c29 + 0x2b82:
                                                                    yk = -0x5 * 0x156 + 0x1bf2 + -0x3 * 0x6ef, AntiAim.SetRealOffset(wq);
                                                                    break;
                                                            }
                                                            break;
                                                        case 0xaaa + -0x20ad + 0x1615 * 0x1:
                                                            yj = -0x3ac + -0xf88 + 0x139a, AntiAim.SetRealOffset(-wq);
                                                            break;
                                                        case -0x1 * -0x54b + 0x13b5 + -0x18eb:
                                                            yj = ww == (-0x45 * -0xd45 + 0x2a58d + -0x421a0) % (-0x1439 * 0x1 + 0x4 * -0x512 + 0x2884) ? -0x13ed + 0x6b9 * -0x2 + 0x2171 * 0x1 : 0x5de * 0x1 + -0xc * -0xde + -0x1001;
                                                            break;
                                                    }
                                                    AntiAim.SetLBYOffset(-0x1fc * -0x6555d + 0x11726f * -0xcb + -0x3 * -0x2e00cda - (-0x29e5bad * -0x2 + 0x146 * -0x9ef5f + 0xec5e8b5)), side = (0x23ee069 + -0x27 * -0x18fff7 + -0x156dc5f * 0x1) % (-0x2 * 0x322 + 0x22c6 * -0x1 + -0x1 * -0x2911);
                                                } else {
                                                    function yl() {
                                                        var a = a;
                                                        ym.OverrideMaxProcessTicks(0x1 * -0x2547 + -0x1fa6 + 0x5 * 0xdcd);
                                                    }
                                                }
                                            }
                                            break;
                                    }
                                } else {
                                    function yn() {
                                        var a = a;
                                        yo.SetValue(['Rage', 'Fake Lag', 'General', 'Limit'], -0x4a + -0x1b76 + 0x1bd6), yp.SetValue(['Rage', 'Fake Lag', 'General', 'Trigger limit'], 0x232 + -0x10f * 0xb + 0x989);
                                    }
                                }
                            }
                            break;
                        case -0x5c1 * -0x1 + -0x11 * -0x55 + -0xb0f * 0x1:
                            xw = ws != (NaN !== NaN) ? -0x14b7 + 0x11 * -0xbb + 0x217f : 0x1 * -0x1fc0 + -0x6b9 + 0x26da * 0x1;
                            break;
                        case -0x22 * -0x96 + -0x27 * 0xd + 0x2 * -0x8ca:
                            xw = -0x24 * 0x9a + 0x10c1 + 0x597; {
                                if ('ABMNl' === 'sHxMD') {
                                    function yq() {
                                        var a = a;
                                        yr.SetFakeOffset(-0x6a89158 + 0x12f87d * 0x6d + 0x5f09134 - (-0x6af5ce2 + 0xc774b4 + 0x7 * 0x1e519e5)), ys.SetRealOffset(yt);
                                    }
                                } else {
                                    yu = -0x1 * -0xc22 + 0x202e + 0x203 * -0x16;
                                    while (yu < -0x6ae + -0x1a06 * 0x1 + 0x20f2) switch (yu) {
                                        case (0x453e854 + -0xa * -0x38cd1a + 0x362e6f * -0x7) % (-0xf40 + 0xe * -0x1f6 + 0x2aba):
                                            yu = 0x987 + 0xb72 * 0x2 + 0x202d * -0x1, yv = 0x1e39 + 0x1449 + -0x3279;
                                            while (yv < 0x12eb + 0x1 * 0x25fa + -0x3890) switch (yv) {
                                                case 0x3d7 * -0x1 + 0x857 * 0x3 + -0x2 * 0xa90:
                                                    yv = -0x759 + 0x1 * -0x10a8 + 0x1 * 0x1856; {
                                                        if ('NJjyI' !== 'NJjyI') {
                                                            function yw() {
                                                                yx = yy / ((-0x4cfc751 + -0x4 * -0x21958c9 + 0x13f57 * 0xe8) % (0x255d * 0x1 + 0x25a5 + -0x4afb)), yz.ForceTargetMinimumDamage(za, zb + (0x7373d3 + -0xf6cafe + -0x6a92d3 * -0x3 - (-0x1152e * -0x7f + -0x118a6a9 + 0x14b8624)));
                                                            }
                                                        } else {
                                                            zc = 0x1303 + -0x849 + -0xaa0;
                                                            while (zc < -0x3fd * 0x4 + 0x11be * 0x1 + 0x15f * -0x1) switch (zc) {
                                                                case (0x13d6 * 0x737 + -0x5 * -0x863777 + 0x226250 * 0x9) % (0x579 + 0x1 * -0x7f7 + 0x287 * 0x1):
                                                                    zc = -0x6a * 0x14 + 0x2025 + -0x1772; {
                                                                        if ('ifgaL' !== 'ifgaL') {
                                                                            function zd() {
                                                                                var a = a;
                                                                                ze.SetValue(['Misc.', 'View', 'General', 'Thirdperson Distance'], zf.GetValue(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW', 'thirdperson distance']));
                                                                            }
                                                                        } else {
                                                                            AntiAim.SetOverride(-0x15b669d + 0x3 * 0x27fb0b + 0x19fd6ca - (-0x1357 * -0x2c4 + 0x68694f + 0x1e7b62)), zg = 0x6f6 + 0x1bdb + -0x22c4;
                                                                            while (zg < 0x165 * 0x1 + 0x23 * -0x21 + 0x3b4) switch (zg) {
                                                                                case 0x73 * -0x2 + 0x207e + -0x1f46:
                                                                                    zg = -0x1 * -0xed5 + 0x1a0b + -0x284a; {
                                                                                        if ('rMnjU' !== 'czGKo') AntiAim.SetFakeOffset((0x141b * -0x5 + 0x3192c + 0x845 * -0x13) % (0x749 * 0x2 + -0x564 * -0x3 + -0x1ebb)), AntiAim.SetRealOffset(-wq);
                                                                                        else {
                                                                                            function zh() {
                                                                                                var a = a;
                                                                                                zi.SetValue(['Rage', 'Anti Aim', 'Directions', 'Auto direction'], (0x4f * 0x6bc7 + 0x1 * -0xc4a7b + 0x13b8bb) % (-0x1 * 0xc59 + -0x24ec + 0x18a4 * 0x2));
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                    break;
                                                                                case 0x1 * -0x69d + -0x2ca + 0x971:
                                                                                    zg = -0x7 * 0x21a + -0xbb7 * 0x3 + -0x1 * -0x3271; {
                                                                                        if ('LIuBH' === 'LIuBH') {
                                                                                            AntiAim.SetFakeOffset(0x1377be5 + -0x2101f8 + 0x6455328 - (-0x74335 * 0x1d2 + 0x13e * -0x32291 + 0x187913ad * 0x1)), zj = -0x102f * 0x1 + 0x22fa + 0x1 * -0x1297;
                                                                                            while (zj < -0x6 * 0x623 + -0x2 * -0x297 + 0x7 * 0x494) switch (zj) {
                                                                                                case -0x25a * 0xd + -0x13d * 0x10 + 0x2 * 0x195e:
                                                                                                    zj = 0x5 * 0x2e4 + -0x791 + -0x4f * 0x15, zk = 0x1 * -0x7f + 0x5 * -0x5f6 + 0x1e7b;
                                                                                                    while (zk < 0x559 * -0x2 + 0x14dc + -0x47 * 0x23) switch (zk) {
                                                                                                        case -0x19df * -0x1 + -0x3 * 0xc92 + 0xc05:
                                                                                                            zk = ww == 0x17676b6 + -0x488c9 * 0x29 + -0x2d37 * 0x1 - (-0x4ffd04 + 0x1647 * -0x87e + -0x1c98d43 * -0x1) ? 0x17 * 0x96 + -0x1f91 * -0x1 + -0x2cbd : -0x8fd * 0x1 + 0x2524 + -0x2c5 * 0xa;
                                                                                                            break;
                                                                                                        case -0x47 * 0x59 + -0x1 * 0x113d + 0x2a3a:
                                                                                                            zk = 0x4 * -0x535 + -0x139e * 0x1 + -0x11b * -0x25, AntiAim.SetRealOffset(0x6d * -0x9 + 0x1 * 0x1087 + -0xc76);
                                                                                                            break;
                                                                                                    }
                                                                                                    break;
                                                                                                case -0x2649 * -0x1 + -0x2 * 0xd24 + -0xbcd:
                                                                                                    zj = ww == (-0x59c * 0x5f + -0x3985e + -0xb8 * -0xacf) % (0xdb9 + -0x3 * 0x27b + -0x217 * 0x3) ? -0xea6 + 0x1269 + -0x3b0 : 0x184 * -0xf + -0xe1a + 0x2530;
                                                                                                    break;
                                                                                                case -0x884 + 0x1 * -0x1522 + -0x1 * -0x1db9:
                                                                                                    zj = 0x2531 + 0xb05 + -0x2fce, AntiAim.SetRealOffset(0x126d + -0x2680 + 0x144f);
                                                                                                    break;
                                                                                            }
                                                                                        } else {
                                                                                            function zl() {
                                                                                                zm((0x1 * -0x6bf + -0x131b + 0x1ad4) / (0x1086 + 0x1 * 0x1ee3 + -0x2f50));
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                    break;
                                                                                case 0x6 * -0x501 + -0x13 + 0x22 * 0xe3:
                                                                                    zg = UI.GetValue(['Rage', 'Anti Aim', 'General', 'Key assignment', 'legit desync']) == (null == undefined) ? 0x9f5 * -0x1 + 0x469 * 0x5 + -0x607 * 0x2 : -0x2023 + -0x1 * -0xf75 + -0x10 * -0x110;
                                                                                    break;
                                                                            }
                                                                            AntiAim.SetLBYOffset(0x859ed11 + -0x1f2ae + -0xfc2d4e - (0x7579854 + 0x12e * -0xbad12 + 0xdca5ffd)), side = (-0x39d21e5f * -0x1 + 0x2f8eda88 + 0x402baf9d * -0x1) % (-0x1102 + -0x1635 + 0x1 * 0x273e);
                                                                        }
                                                                    }
                                                                    break;
                                                                case 0xa2e * -0x2 + -0x67f + 0x1b1d:
                                                                    zc = -0x4 * 0x727 + 0x995 + 0x1372, zn = -0x21d4 + 0xf60 + -0x5 * -0x3c4;
                                                                    while (zn < -0x256d + -0x678 * -0x2 + 0x18ef) switch (zn) {
                                                                        case -0x1997 + 0xbe * -0x11 + 0x263e:
                                                                            zn = -0x1de * -0xf + 0xb43 + 0x1 * -0x26d3; {
                                                                                if ('uMczc' === 'amUDJ') {
                                                                                    function zo() {
                                                                                        var a = a;
                                                                                        zp.SetValue(['Rage', 'Anti Aim', 'Directions', 'Auto direction'], (-0x316358 + -0x217c8 + -0x3 * -0x1eb943) % (-0x3 * -0x885 + 0x20e0 + 0x4 * -0xe9b));
                                                                                    }
                                                                                } else {
                                                                                    AntiAim.SetOverride((0x7d * -0x47c2 + 0x230a26 * -0x1 + 0x13 * 0x5d473) % (0x901 * -0x1 + -0xf * -0x201 + -0x150b * 0x1)), zq = 0x1f06 + 0x139f + 0xe * -0x39a;
                                                                                    while (zq < 0x547 * -0x3 + -0xc85 * 0x2 + -0x2935 * -0x1) switch (zq) {
                                                                                        case 0x2013 + 0x16d9 * -0x1 + -0x923 * 0x1:
                                                                                            zq = -0xd * 0x18f + -0x1 * -0xc47 + 0x852; {
                                                                                                if ('MvBFg' !== 'kDrcf') {
                                                                                                    AntiAim.SetFakeOffset(-0x27e2d22 + 0x247d2c2 + 0x7922775 - (0x3 * -0x375035f + 0x2482 * 0x1b6a + 0xdd2035e)), zr = 0x412 * 0x6 + 0x1395 + -0x2bdb;
                                                                                                    while (zr < 0x2df + 0x39 + -0x2a8) switch (zr) {
                                                                                                        case 0x1 * -0x118a + 0x14cf + 0x1 * -0x31f:
                                                                                                            zr = ww == (-0x2b55e + -0x3f313 + 0x1 * 0x8bff7) % (0x24d3 + 0x1ed * -0x10 + -0x600) ? 0xa35f * 0x553 + -0x225d0a6 + 0x2336695 - (0x6d5d6eb + -0x324009c + -0x3e6d96) : 0xa77 + 0x1559 + -0x1fc4;
                                                                                                            break;
                                                                                                        case 0x1 * 0x10d6 + -0x7ed * 0x1 + -0x8dd * 0x1:
                                                                                                            zr = 0x1 * 0x10a1 + -0x155 + -0x2 * 0x76e, zs = 0x1 * -0x21e5 + -0x2585 + 0x4787;
                                                                                                            while (zs < -0x37 * -0x7b + -0x3 * 0x513 + -0xabb) switch (zs) {
                                                                                                                case 0x24e8 * 0x1 + 0x976 * 0x4 + -0x4a81:
                                                                                                                    zs = 0xb51 * 0x3 + -0x1 * 0x49c + 0x5c6 * -0x5, AntiAim.SetRealOffset(-(-0x61 * 0x3 + 0x1ca8 + -0x1b49));
                                                                                                                    break;
                                                                                                                case -0x2288 * 0x1 + -0x1189 * -0x2 + -0x6d * 0x1:
                                                                                                                    zs = ww == (-0x1 * -0x4dd3a5 + 0x20d63b + -0x45f937) % (-0x62 * 0x18 + -0x13d * -0x1d + -0x1ab6) ? -0x16ed * 0x1 + -0x82c + -0xfac * -0x2 : 0x10b6 * -0x2 + 0xc75 + 0x1570;
                                                                                                                    break;
                                                                                                            }
                                                                                                            break;
                                                                                                        case (-0x12a80b4f + -0x3e5476e7 + 0x25c08615 * 0x3) % (0x1 * -0x1f0e + -0x44 * 0x24 + 0x28a7):
                                                                                                            zr = -0x1 * -0x745 + -0xa15 + -0x40 * -0xd, AntiAim.SetRealOffset(-(-0xab7 + 0x2058 + -0x1565));
                                                                                                            break;
                                                                                                    }
                                                                                                } else {
                                                                                                    function zt() {
                                                                                                        return zu * zv.PI / (-0x131c + -0x7db * -0x1 + 0xbf5 * 0x1);
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                            break;
                                                                                        case 0x30a * 0x1 + -0x1 * -0x1b1 + -0x482:
                                                                                            zq = UI.GetValue(['Rage', 'Anti Aim', 'General', 'Key assignment', 'legit desync']) == (null == undefined) ? -0x14dd + 0x211 + 0x1 * 0x12e3 : 0x1210 + -0x1 * 0x24a0 + -0x20 * -0x97;
                                                                                            break;
                                                                                        case 0xa1e + 0x4 * 0x969 + -0x2f72:
                                                                                            zq = -0x661 + 0x626 * -0x1 + 0x25 * 0x59; {
                                                                                                if ('bXzCs' !== 'bXzCs') {
                                                                                                    function zw() {
                                                                                                        var zx = zy ? function() {
                                                                                                            var a = a;
                                                                                                            if (zz) {
                                                                                                                var aaa = aab.apply(aac, arguments);
                                                                                                                return aad = null, aaa;
                                                                                                            }
                                                                                                        } : function() {};
                                                                                                        return aae = ![], zx;
                                                                                                    }
                                                                                                } else AntiAim.SetFakeOffset(-0xd54e07 * 0x7 + -0x2 * -0x6049d7d + -0x1c * -0xa8f95 - (0x47d8122 + -0xd6e931e + -0x3e481b * -0x43)), AntiAim.SetRealOffset(wq);
                                                                                            }
                                                                                            break;
                                                                                    }
                                                                                    AntiAim.SetLBYOffset(0x25 * 0x578ae7 + 0xbb95dc + -0x606dc2a - (-0x88def1 * 0x4 + -0x547150f + -0x68 * -0x245e71)), side = (0x4db02c + -0x3d987d + 0xf231 * 0x1a) % (-0xce5 + -0x1 * 0x1511 + 0x21f9);
                                                                                }
                                                                            }
                                                                            break;
                                                                        case -0x3af + 0xac0 + -0x6b1:
                                                                            zn = wt <= -(0x4 * 0x7ab + 0x19e8 + -0x37fe) ? -0x1 * -0x641 + 0x19aa + 0x4d * -0x6a : -0xbe2 + 0x28d * 0xd + -0x1511 * 0x1;
                                                                            break;
                                                                        case -0x1099 * -0x1 + -0x2705 + 0xb51 * 0x2:
                                                                            zn = -0x4 * 0x2f5 + -0xf8f * 0x1 + 0x1bd5; {
                                                                                if ('lxEDy' !== 'oLJDm') {
                                                                                    aaf = 0x641 * -0x1 + -0x2451 + 0x2ac9;
                                                                                    while (aaf < -0x1b4a + 0xf3b + 0xc90) switch (aaf) {
                                                                                        case 0xedc + 0x4 * 0x303 + 0x1 * -0x1a8a:
                                                                                            aaf = -0x357 * 0x2 + 0x1 * 0xaa3 + -0x374, AntiAim.SetRealOffset(-(-0x8 * -0x275 + 0x21ce + -0x353a));
                                                                                            break;
                                                                                        case -0xbff + 0x2146 + -0x1510:
                                                                                            aaf = ww == (-0x2cf1a + 0x3fa21 + -0x5d * -0x28b) % (-0x199 + -0x1504 + 0x10 * 0x16a) ? 0xeaa + 0x1f83 + -0x2dcf : -0x2 * 0x6b + 0x218c + -0x2065;
                                                                                            break;
                                                                                        case -0x1 * 0x14b3 + -0xe17 + 0xd1 * 0x2b:
                                                                                            aaf = -0xbcc + -0xfc4 * 0x2 + 0x2bd5, aag = -0x832 + -0x2 * 0x1a1 + -0x8 * -0x172;
                                                                                            while (aag < -0x16df + 0x18c2 + -0x150) switch (aag) {
                                                                                                case -0x1e77 + 0x1 * 0x1524 + 0x15 * 0x73:
                                                                                                    aag = ww == (-0x3 * -0x58df + -0x1 * -0x1f5ca1 + -0x22c7 * -0x3d) % (0x27a + -0xe2 * -0x2 + 0x1 * -0x43b) ? -0x1727 * -0x1 + 0x1d98 + -0x348e : -0x1 * -0x178c + 0x968 + -0x2061;
                                                                                                    break;
                                                                                                case -0x1ad * 0x17 + 0x1c3a + 0xa82:
                                                                                                    aag = -0x19 * -0x4 + -0xa64 + -0xa93 * -0x1, AntiAim.SetRealOffset(-0x25fe + 0x16b * 0x7 + 0x1c4d);
                                                                                                    break;
                                                                                            }
                                                                                            break;
                                                                                    }
                                                                                    side = (-0x1a32b18 * 0x1f + -0x5c * -0x33b9e3 + 0x40707a5d) % (0x16dd + -0x1 * 0xe35 + -0x89f);
                                                                                } else {
                                                                                    function aah() {
                                                                                        aai = null == aaj, aak = (-0x348e0 + -0x3cefd + -0x92f63 * -0x1) % (0xf61 + -0xa01 * -0x3 + 0x1 * -0x2d61);
                                                                                    }
                                                                                }
                                                                            }
                                                                            break;
                                                                    }
                                                                    break;
                                                                case 0x9ec + -0xb8 + 0xa * -0xe9:
                                                                    zc = wt >= 0xec7 * 0x1 + -0x13c3 + 0x2c9 * 0x2 ? (-0x27c854c + 0x85032a1 + -0x1700638) % (0x1 * 0x283 + -0x3c4 * -0xa + -0x2822) : -0x1d43 + -0x13e6 * -0x1 + 0x99f;
                                                                    break;
                                                            }
                                                        }
                                                    }
                                                    break;
                                                case -0x22 * 0xf6 + -0x1 * -0xe17 + 0x129e:
                                                    yv = UI.GetValue(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW', 'auto-direction type']) == (-0x4b1137 + -0x4882e7 * -0x1 + 0x11bdf * 0x27) % (-0x6be * -0x3 + -0x89 * 0x3d + 0xc6e) ? -0x7a * 0x16 + -0x1 * 0x183a + 0x22c4 : 0x12f4 * 0x1 + -0x1002 + -0x29d;
                                                    break;
                                            }
                                            break;
                                        case (-0x5d + -0x2a55 * 0x13 + 0x53c32) % (-0x1 * 0x62 + 0x7b3 + -0x22 * 0x37):
                                            yu = -0x1d25 + -0x1 * -0x238d + 0x20e * -0x3; {
                                                if ('LLKxP' !== 'aghxV') {
                                                    aal = 0x4e + 0x3d6 + 0x3d7 * -0x1;
                                                    while (aal < -0x1d26 + 0x1 * 0x787 + 0x15ee) switch (aal) {
                                                        case 0x1ea1 + 0x22e8 + -0x20ab * 0x2:
                                                            aal = 0x148 * 0x17 + -0x1 * -0x933 + -0x265c; {
                                                                if ('ywZxw' !== 'buBhM') {
                                                                    AntiAim.SetOverride(-0x10d0915 + -0x2 * -0x3e0b0f + -0x3bf * -0x58fb - (0xe3e3fb + 0x2685af + -0x4e085d)), aam = 0x1 * -0xf19 + -0x532 + 0x17 * 0xe5;
                                                                    while (aam < -0x2 * 0xae5 + 0x12b + 0x14e8) switch (aam) {
                                                                        case 0x9c2 + 0x1d87 + 0x4 * -0x9c2:
                                                                            aam = -0x1180 + -0x1 * -0x201b + -0xe52 * 0x1; {
                                                                                if ('dNEzI' === 'CTpyK') {
                                                                                    function aan() {
                                                                                        return aao <= aap ? aaq : aar >= aas ? aat : aau;
                                                                                    }
                                                                                } else AntiAim.SetFakeOffset(0x1 * 0x3050982 + 0xacfc866 + 0x9 * -0xb81cfb - (-0x98b * 0x121ae + -0xa77bf8f + 0x1c9ff41e * 0x1)), AntiAim.SetRealOffset(wq);
                                                                            }
                                                                            break;
                                                                        case 0xb54 + 0x93e + -0x144a:
                                                                            aam = UI.GetValue(['Rage', 'Anti Aim', 'General', 'Key assignment', 'legit desync']) == (null == undefined) ? -0x22e6 * 0x1 + -0x31b + 0x10 * 0x263 : -0x5bf + 0x1d3d + -0x173d;
                                                                            break;
                                                                        case 0x162 * 0xc + -0x1eb9 + 0x2 * 0x728:
                                                                            aam = 0x1779 + -0x942 + -0xdee; {
                                                                                if ('LbHdG' !== 'ihlnW') {
                                                                                    AntiAim.SetFakeOffset(-0x11 * -0x26931e + -0xfb * -0x187de + 0x34bd16d - (-0x1 * -0x84052df + -0x67091b8 + -0x125a5 * -0x4d6)), aav = 0x17bd + -0x1 * 0x1ad + -0x26d * 0x9;
                                                                                    while (aav < 0xd * -0x2c + 0x1248 * 0x1 + -0xfa9) switch (aav) {
                                                                                        case 0x2 * -0x2a1 + -0x2014 * 0x1 + 0x25b6:
                                                                                            aav = 0x18c2 + 0x1 * 0x1849 + -0x30a8, aaw = 0xf46 + 0xd17 + -0x1c39;
                                                                                            while (aaw < 0x1fa1 * -0x1 + -0x6 * -0x1bf + -0x228 * -0xa) switch (aaw) {
                                                                                                case -0xa4 * -0x31 + 0x7 * -0xbd + -0x1a06:
                                                                                                    aaw = 0x26 * 0x8b + 0x4 * 0x82e + -0x34f1 * 0x1, AntiAim.SetRealOffset(-(-0x99b * 0x1 + -0x2663 + 0x303a));
                                                                                                    break;
                                                                                                case 0x250 * 0x1 + 0x1a55 + 0x1 * -0x1c81:
                                                                                                    aaw = ww == 0x78e2be + 0x12a3097 + -0x1f * 0x77119 - (0xd * -0xa7b4a + 0x77213f + 0xcd82d0) ? 0x516 * 0x3 + 0xc * -0x70 + -0x9cf : 0x2509 + 0x43 * -0x1e + -0x1 * 0x1cc6;
                                                                                                    break;
                                                                                            }
                                                                                            break;
                                                                                        case -0xf2 + -0x4 * -0x45d + -0x1077:
                                                                                            aav = 0x25ae + 0xd3 * -0xb + 0xe1d * -0x2, AntiAim.SetRealOffset(-(-0xd24 + -0xa8d + -0x17ed * -0x1));
                                                                                            break;
                                                                                        case 0xb22 + -0xb * -0xa3 + 0x17e * -0xc:
                                                                                            aav = ww == 0xcd0980f * -0x1 + -0x94d941 * 0x13 + 0x1f3884f7 - (-0xd * 0xae7759 + 0x44a0ff9 * -0x3 + 0x1d160c85) ? 0x2 * 0x68d + 0x12cd + -0x1fdc : -0x7 * 0xda + -0x2085 + -0x1 * -0x26db;
                                                                                            break;
                                                                                    }
                                                                                } else {
                                                                                    function aax() {
                                                                                        var a = a;
                                                                                        aay = aaz.Curtime() + aba.GetInt('mp_round_restart_delay'), abb = abc !== abd;
                                                                                    }
                                                                                }
                                                                            }
                                                                            break;
                                                                    }
                                                                    AntiAim.SetLBYOffset(-0x4060cb7 + 0x6bd33df * 0x1 + -0x18c374f * -0x3 - (-0x1d1e44e + 0x3ea55 * -0x36c + -0x1 * -0x16938c3f)), side = (-0x2c1636 + 0x2e02bb + 0x26c424) % (0x2367 * -0x1 + 0x1 * -0x809 + 0x635 * 0x7);
                                                                } else {
                                                                    function abe() {
                                                                        abf = (0x3 * 0xf8ce + -0xf227 + 0x1f43) % (-0x900 + 0xcf1 + -0x3ee), abg = (-0x3d3be6b + 0x48 * 0x7aee1 + 0x2 * 0x330c8e7) % (-0x901 + -0xf * -0xd1 + -0x337);
                                                                    }
                                                                }
                                                            }
                                                            break;
                                                        case -0x744 + -0x3eb + 0x14 * 0x93:
                                                            aal = wt >= -0x652 + 0x1 * 0x16db + -0xff3 ? -0xe52 + -0x17 * 0x39 + 0x13a4 : -0x107 * -0xc + 0x12e7 * 0x1 + -0x77 * 0x43;
                                                            break;
                                                        case -0xff3 * -0x1 + 0xc7d + 0xe2d * -0x2:
                                                            aal = -0x1f25 + -0x16a * -0x9 + 0x1 * 0x12ba, abh = 0x22ec + 0xae4 + -0x2dad;
                                                            while (abh < -0x89e * -0x2 + -0x240d + 0x1361) switch (abh) {
                                                                case -0x1a * 0xd5 + 0x8d5 + 0xd13:
                                                                    abh = -0x2621 * -0x1 + -0x1ba * -0x16 + -0x399 * 0x15; {
                                                                        if ('DeyJV' !== 'DeyJV') {
                                                                            function abi() {
                                                                                abj();
                                                                            }
                                                                        } else {
                                                                            AntiAim.SetOverride(-0x169e719 + -0x123a8ad + 0x349f114 - (0x7c5d86 + 0x4218dd + -0x21516)), abk = -0x83 * 0x18 + -0x26d6 + -0x2 * -0x19a9;
                                                                            while (abk < -0x1 * -0x13a8 + -0x1e67 + 0xa2 * 0x12) switch (abk) {
                                                                                case -0x184a + -0xd63 + 0x25e1:
                                                                                    abk = UI.GetValue(['Rage', 'Anti Aim', 'General', 'Key assignment', 'legit desync']) == (null == undefined) ? 0xd55 * 0x1 + -0x1 * 0x611 + -0x6ec * 0x1 : 0xbd5 + -0x11e4 + 0xe3 * 0x7;
                                                                                    break;
                                                                                case -0x131f + 0x1 * 0x15d1 + 0x2 * -0x146:
                                                                                    abk = -0x92b * 0x4 + 0x1907 + -0x11e * -0xb; {
                                                                                        if ('jgRHm' === 'jgRHm') AntiAim.SetFakeOffset((0x6297 * 0x3 + 0x34884 + -0x1 * 0x258c3) % (-0x48a + -0x820 + 0xcad)), AntiAim.SetRealOffset(-wq);
                                                                                        else {
                                                                                            function abl() {
                                                                                                var a = a;
                                                                                                abm = abn.GetValue(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW', 'dmg override amount']), abo.ForceTargetMinimumDamage(abp[abq], abr.GetValue(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW', 'dmg override amount']));
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                    break;
                                                                                case -0x2467 + 0x1106 + -0x231 * -0x9:
                                                                                    abk = -0x6d * 0x2 + -0x18e4 + 0x1a63; {
                                                                                        if ('tKCTq' !== 'tKCTq') {
                                                                                            function abs() {
                                                                                                var a = a;
                                                                                                for (abt in abu) {
                                                                                                    abv = abw.GetValue(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW', 'dmg override amount']), abx.ForceTargetMinimumDamage(aby[abz], aca.GetValue(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW', 'dmg override amount']));
                                                                                                }
                                                                                            }
                                                                                        } else {
                                                                                            AntiAim.SetFakeOffset(-0x6210c79 + -0x230a6 * -0x37a + 0x5dfb872 - (-0x30a9f9 * 0x26 + -0xdbc83df + -0x1c518bea * -0x1)), acb = 0x1 * -0x178d + 0x983 + -0x103 * -0xe;
                                                                                            while (acb < -0x1 * -0x8ba + 0x1 * -0x35c + -0x4fc) switch (acb) {
                                                                                                case -0x251 * -0x3ac67 + -0x48792ae + 0x1300fd * 0x9 & -0x2bf4c54 + -0x44f69dc * -0x1 + -0x119 * -0x18b6c:
                                                                                                    acb = -0x14c2 + 0x7 * 0x2d + 0x13e9, AntiAim.SetRealOffset(0x4 * -0x724 + -0x1070 + 0x2d3c);
                                                                                                    break;
                                                                                                case -0x4 * 0x62a + 0x23ac * -0x1 + 0x3c74:
                                                                                                    acb = ww == -0x2ccbf53 + -0x1a7b * -0x29ae + 0x5d8d9ce - (0x110235 * -0x8e + 0x7c4796a + 0x10285f * 0x8f) ? 0x1 * 0x5ff5525 + 0x9255f7b + -0x941aa28 - (-0x6aa4c4c + -0xaa0c02b + -0xd846d * -0x1b7) : -0x17ca + 0x1d53 + -0x528;
                                                                                                    break;
                                                                                                case -0x1 * 0xe66 + 0x44e + -0x1 * -0xa79:
                                                                                                    acb = -0x25f * -0x7 + -0x8e + 0x13 * -0xd3, acc = -0xe * 0x2e + 0x1c1b + -0x198b * 0x1;
                                                                                                    while (acc < -0x1 * -0x681 + 0x2 * 0xe4b + -0x3db * 0x9) switch (acc) {
                                                                                                        case -0x13 * 0x1d + 0x20b3 + -0x10 * 0x1e8:
                                                                                                            acc = ww == (0xa316a + -0x9b5f2 + 0x1 * 0x283531) % (-0xf3d * 0x1 + 0x1 * -0x649 + 0x1589) ? -0x19a2055 + 0x72a117 + 0x2166e2c ^ 0x9c6b68 + 0x1769 * 0x10dd + -0x1 * 0x1384221 : -0x25f9 + 0x1a2d + 0xc30;
                                                                                                            break;
                                                                                                        case (-0x4118d750 + 0x728cceb * 0xa + 0x22b61f6c) % (-0x589 + -0x155d * -0x1 + 0x1 * -0xfcd):
                                                                                                            acc = 0x74 * 0x45 + -0x13e9 + -0xaf7, AntiAim.SetRealOffset(-0x26bc + -0x1d71 + 0xd3 * 0x53);
                                                                                                            break;
                                                                                                    }
                                                                                                    break;
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                    break;
                                                                            }
                                                                            AntiAim.SetLBYOffset((-0x2f7d1 + 0x3efd0 + 0x11f87) % (-0x11b * 0x1b + -0xc11 * 0x1 + -0x1 * -0x29ed)), side = 0x372347 + 0x9e32ee + 0x1998b9 ^ 0x3f451 + 0xd3 * -0x22928 + 0x2b2e693;
                                                                        }
                                                                    }
                                                                    break;
                                                                case 0x334 + 0x92f * 0x1 + -0xe0 * 0xe:
                                                                    abh = wt <= -(0x2d9 * -0xd + 0x202c + 0x56f) ? 0xbe6 + -0xabe * -0x1 + -0x165e : 0x3 * -0x49 + 0xeee * -0x1 + 0x1006;
                                                                    break;
                                                                case -0x17 * 0x15b + 0x3b * 0x3a + 0x120c:
                                                                    abh = 0x9b + 0xdd * 0x11 + -0x8 * 0x1d7; {
                                                                        if ('uVWzG' !== 'iZdNC') {
                                                                            acd = -0xc97 + 0x7d2 + 0x4d9;
                                                                            while (acd < 0x26e * -0x2 + 0x66 * -0x17 + 0xe80) switch (acd) {
                                                                                case 0x5fc * 0x2 + 0x217 + -0xde2:
                                                                                    acd = -0x11a5 + -0x49d * -0x4 + -0x55, AntiAim.SetRealOffset(-(0x1c6 * 0xe + -0x39c + 0x14fc * -0x1));
                                                                                    break;
                                                                                case 0x20e * 0x13 + 0x1ea * -0x13 + -0x255:
                                                                                    acd = -0x152 * 0x5 + -0xf59 + -0x1 * -0x166d, ace = -0x329 * -0x3 + 0x86e + -0x11c3;
                                                                                    while (ace < 0x1e46 + 0x99 * -0x1f + -0xb2c) switch (ace) {
                                                                                        case 0x17de + 0x4a * 0x1d + -0x2004:
                                                                                            ace = 0x1d * 0x101 + -0x110c + 0x1 * -0xb7e, AntiAim.SetRealOffset(0x2 * 0xacf + -0x22ad * 0x1 + 0xd4b);
                                                                                            break;
                                                                                        case 0x791 + -0x62 + -0x709:
                                                                                            ace = ww == (-0x1 * -0x28e3fd + -0x431c48 + -0x2 * -0x21747a) % (0x2014 + -0x863 + -0x17ae) ? 0x16 * 0x29 + -0x26 * 0x36 + -0xa * -0x79 : -0x56b + 0x577 * -0x3 + 0x1 * 0x1663;
                                                                                            break;
                                                                                    }
                                                                                    break;
                                                                                case 0x148d + -0xc89 + -0x7f0:
                                                                                    acd = ww == 0x5153d * -0x238 + -0xd53174b + 0xcf68 * 0x2773 - (-0x90034fd + 0x3b71cf5 + 0x1 * 0xca4e51d) ? 0xd7 * 0x11 + -0x1 * -0x1cb2 + -0x16 * 0x1f2 : 0xa5f + -0x5b8 + 0x5c * -0xc;
                                                                                    break;
                                                                            }
                                                                            side = (0xc6a1 * 0x4dd + -0x1be78c + 0xa2e * 0x1a6b) % (0x1 * -0x1b5 + -0x1b2a + 0x1ce6);
                                                                        } else {
                                                                            function acf() {
                                                                                var a = a;
                                                                                acg.SetValue(['Rage', 'Fake Lag', 'General', 'Limit'], ach), aci.SetValue(['Rage', 'Fake Lag', 'General', 'Trigger limit'], -0x2105 + -0x2e * 0x81 + 0x26 * 0x17b);
                                                                            }
                                                                        }
                                                                    }
                                                                    break;
                                                            }
                                                            break;
                                                    }
                                                } else {
                                                    function acj() {
                                                        var a = a;
                                                        ack = acl, acm.ForceTargetMinimumDamage(acn, aco + (-0x26 * -0x66703 + 0x574c8f * 0x3 + -0x13cced1 - (-0x7eb974 + 0x1a2d26 + 0x120ed9b)));
                                                    }
                                                }
                                            }
                                            break;
                                        case -0x11b8 + 0x2637 + -0x1471:
                                            yu = UI.GetValue(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW', 'auto-direction type']) == -0x9 * 0x4a505e + -0xe3169d2 + 0x182a0a35 * 0x1 - (0x8 * 0x5adf58 + 0x25 * -0x2e9456 + -0x3 * -0x3c01641) ? (-0x18e72 * -0x1 + -0x5055 + 0x1 * 0xd969) % (-0x2 * -0xe4b + -0x25a3 + -0x488 * -0x2) : (-0x660fe * 0x12a + 0x784e15d + 0x4f8ac9e) % (0x21d2 + -0x1 * -0x44f + -0x261b);
                                            break;
                                    }
                                }
                            }
                            break;
                    }
                } else {
                    function acp() {
                        var a = a;
                        acq.ExecuteCommand('buy awp'), acr.ExecuteCommand('buy awp');
                    }
                }
            }
            break;
        case -0x12d7 * -0x1 + -0x1b * 0xdb + 0x463:
            xv = 0x19a0 + -0x1051 + -0x65 * 0x17; {
                if ('Pvayf' === 'Pvayf') AntiAim.SetOverride(0x112607b + 0xd924d8 + -0x12f2405 - (0xde89a9 + 0x337c4 * -0x67 + -0x178c0 * -0xca)), AntiAim.SetFakeOffset(wx), AntiAim.SetRealOffset(-(0x99d * 0x1 + 0xdc7 + -0x7 * 0x355) - wx * -((0x9 * 0x2b7a2 + -0x255567 + 0x35915e) % (0x6 * 0x2b3 + -0x147 * 0x3 + 0x62d * -0x2))), AntiAim.SetLBYOffset(-0x8cfa9f9 + 0xb4cd19c + 0x4dea572 - (0x4c86219 * 0x1 + -0x12ad5 * -0x196 + 0xb97d2e)), jagowalking = !![], side = (0x23b * 0x66010 + 0xa * -0x38ce340 + 0x358dacd9) % (-0x1af0 + -0x237f + -0x3e78 * -0x1);
                else {
                    function acs() {
                        var a = a;
                        act.SetFakeOffset((-0x218f * -0x5 + 0x7 * -0x9437 + 0x57d3c) % (0x119a * -0x1 + 0x16c7 + -0x52a)), acu.SetRealOffset(-acv);
                    }
                }
            }
            break;
    }
    var wq, wr, ws, wt, wu, wv, ww, wx, wq, wy, xb, xc, xm, xv, xw, xx, xy, xz, yj, yk, yu, yv, zc, zg, zj, zk, zn, zq, zr, zs, aaf, aag, aal, aam, aav, aaw, abh, abk, acb, acc, acd, ace;
}
UI.AddCheckbox(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW'], 'dynamic damage selection');

function watermark() {
    var a = a;
    acx = CheatHooked.GetUsername();
    while (acz < 0x72a + -0x2 * -0xb0f + -0x1cb0) switch (acz) {
        case -0xca1 * -0x3 + 0x2 * -0x1147 + -0x331:
            acz = 0x10ff + -0x1a2b + 0x9c4, dsal23232342222322323233233242323332323232322223342323223232223233434232342342342323422342342344234332k312323();
            break;
        case 0x25dd + 0x16c5 + -0xc0d * 0x5:
            acz = acx != acy[-0x87c9049 * -0x1 + -0x91 * -0xad13f + -0x74147e3 - (0xc8446e0 + 0x55ab48c + -0x4093 * 0x29ad)] || acx != acy[0xf77acb + 0x7b7fd1 + -0x1 * 0xb6994e - (-0x69adc9 + -0x10a3 * 0xd93 + 0x207e3af)] || acx != acy[0x12cf836 + -0x443 * 0x2da1 + 0x846bdb * 0x1 ^ -0x2d * 0x8fab5 + -0xde57ba + 0x3615877] || acx != acy[(-0x468c881 + -0x1 * -0x487c507 + -0xa849 * -0x6fd) % (-0x1459 * 0x1 + -0x3 * 0xc2d + 0x821 * 0x7)] || acx != acw[0xde2a5f + 0xfefc60 + -0x29 * 0x5cf69 ^ -0x1c79c4 + -0xa0503 + -0x377c57 * -0x5] ? -0x1b6e + -0xd56 + 0x28e8 : -0x2db * 0x1 + -0x4 * 0x255 + -0xcc7 * -0x1;
            break;
    }
     acx = CheatHooked.GetUsername();
    var acw, acx, acy, acz, ada, adb, acx, adc, add, ade, adf, adg, adh, adi, adj, adk, adl, adm, adn;
}
UI.AddCheckbox(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW'], 'adaptive silent');

function kljkj23h4kj234h23klj42(ado, adp, adq, adr, ads, adt, adu) {
    var a = a;
    adv = (-0x32248429 * -0x1 + -0x32a5 * 0xa325 + 0x175725fa) % (-0x3fe * 0x9 + 0xb * -0x25f + 0x3e0a) * Math.PI / (-0x2bee6 + -0x74773 + 0x2eba5 * 0x5), adw = Math.PI / (-0x5 * -0x74a + 0x2 * -0x311 + 0x767 * -0x4), adx = adq - adt, ady = (adr + ads) * adw, adr = adr * Math.PI / (0x23a5 + 0x235 + -0x6 * 0x631), adz = 0x246d + 0x2e3 * -0x1 + -0x2c4 * 0xc;
    while (adz < 0x1f6a + -0x2466 * 0x1 + -0x1 * -0x5b4) {
        if ('HcwIG' === 'HcwIG') switch (adz) {
            case -0xd3d + 0x60a + 0x78d:
                adz = adq > adx ? -0x17 * -0x43 + -0x4a8 * 0x6 + 0x1643 : 0x2d8 * 0x5 + -0x1 * 0x15ed + 0x86d;
                break;
            case -0x15a9 + -0x1430 + -0x1 * -0x2a31:
                adz = 0x16a5 + -0x8 * -0x3cd + 0x3 * -0x1199; {
                    if ('uWnCp' === 'uWnCp') {
                        aea = 0x18f0 + -0x1 * -0x92 + 0x875 * -0x3;
                        while (aea < 0xc85 + 0x1ee9 + -0x2b2e) {
                            if ('HVdux' !== 'HVdux') {
                                function aeb() {
                                    var a = a;
                                    aec.ForceHitboxSafety(0x1207ac0 + -0x1 * 0x576163 + 0x567a7 * 0x7 ^ 0x1a0ee36 + -0x13d2541 * -0x1 + -0x1ef248b), aed.ForceHitboxSafety((0xe50f24 + 0x153f235 + 0x1 * 0x27e0152) % (0xdea * 0x2 + -0xf09 + -0xcc4));
                                }
                            } else switch (aea) {
                                case -0x67 * 0x26 + -0x1419 + 0x2386 * 0x1:
                                    aea = 0x1e1 * -0x2 + 0x154a + -0x1154, aee = adr;
                                    break;
                                case -0x1759 * -0x1 + 0x19 * 0xd8 + -0x2c5e:
                                    aea = 0x683 + 0x1fca + -0x2619, aee += adv;
                                    break;
                                case -0x12d * 0x11 + -0x842 + 0x1c6d:
                                    aea = 0x1026 + 0x233d + -0x3350; {
                                        if ('pJaDK' !== 'KHXzj') aef = Math.round(ado + adq * Math.cos(aee)), aeg = Math.round(adp + adq * Math.sin(aee)), aeh = Math.round(ado + adq * Math.cos(aee + adv)), aei = Math.round(adp + adq * Math.sin(aee + adv)), RenderHooked.Line(aef, aeg, aeh, aei, adu);
                                        else {
                                            function aej() {
                                                var a = a;
                                                aek.String(ael.GetScreenSize()[0x2a5d7f8 + -0x1 * -0xd930e29 + -0xc2 * 0xbb246 - (-0xd6cbb * 0xb7 + -0x2a8d489 + 0x139d5b4b)] / ((-0x49580bb9 + -0xa0330f6 + 0x12f1 * 0x69389) % (-0x1f35 + 0x2 * -0x7 + -0x9 * -0x37a)) + (0x1 * 0x3e2f4c + -0x13a8b2 + -0x1 * 0x1d5f1) % (0x586 + -0x31 * 0x54 + -0x21d * -0x5) - (-0x72b * 0x1 + 0x6b * 0x5 + -0x20 * -0x29), aem.GetScreenSize()[0x606443 * -0x3 + -0x41bf4a + 0x115 * 0x1f61d - (0x14d3ac0 + 0x45 * 0x3eda7 + 0x1e79 * -0xda6)] / (0x5d538a + -0x3 * 0x7102f7 + -0x1e4a449 * -0x1 ^ -0x1f * -0x96bf8 + -0xc7ae82 + 0x928a66) + (0x5adcf0 + -0x213fe6 + 0x82c444 - (-0xe * 0xd2691 + -0xea6b71 + 0x25ee8ac)) + aen, 0xbb80a32 + 0x1032d66 + -0x55f6a83 - (0x601ec86 + -0x3c7 * -0x10c91 + -0x29c9728), 'dmg', [0x4a * 0x74079 + -0x3 * 0x3bd2a92 + 0x107aa9d1 - (0x2 * -0x5f07acb + 0xa39bee0 + 0x90303cb), (-0xe9c9 * 0x1 + 0x38d4e + -0x8bff) % (0x33 * 0xc4 + 0x8db + 0x1 * -0x2fe4), (0x52 * 0x6c1 + 0x1b991 + -0x1cbdd) % (0x23af + 0x1fad + -0x4359), aeo], aep), aeq.String(aer.GetScreenSize()[0x11b1b1 + 0x6e9ce4 + 0x6db7e80 - (0x1 * 0xd8804f1 + -0xdf11208 + 0x7c4da2c)] / ((-0x6a5b041 + -0x1726 * -0x16c83 + -0x38e973 * -0x43) % (0x7 * 0x209 + -0x2612 * 0x1 + 0x47 * 0x56)) - (0x1770 + -0x16b7 + -0xad), aes.GetScreenSize()[(0x162ed7 * 0x2 + -0x4391e0 + 0x3fe4db) % (0x211e + 0xd * -0x1bf + -0x4 * 0x29a)] / ((-0x3b * -0x4e56b0 + 0x3 * -0xbc2aa11 + 0x3a6f4ced) % (-0x2 * 0x427 + -0xd48 + 0x159d * 0x1)) + aet, (0x2ab5d + -0x55cc * 0x1 + -0x8dd * 0x7) % (0x2219 + -0x1a71 * 0x1 + -0x7a5), 'dmg', [aeu[0xbf788 * 0x11 + -0x868f5da + -0x1 * -0xef952e7 - (0x6ad09c3 + -0x48d * -0x2ea1d + 0x196b * -0x7eb5)], aev[0x5d8098 + 0x9ac819 + -0x3be763 - (-0x2 * -0x83eae9 + 0x3 * -0x4b56a + -0x3d5447)], aew[(0x1e9860e2 * 0x2 + -0xb52d7 * 0x29f + 0x1 * 0x9b2a90f) % (0x62a + -0x28 * 0xc7 + 0x18f5)], aex], aey);
                                            }
                                        }
                                    }
                                    break;
                                case 0x1 * 0x1b9 + -0xa6 * 0x3a + 0x2417 * 0x1:
                                    aea = aee < ady ? -0x27f * -0x3 + -0x4a3 * -0x8 + -0x2c67 : 0x15f1 + -0x8b * -0x24 + -0x293d;
                                    break;
                            }
                        }
                    } else {
                        function aez() {
                            var a = a;
                            afa = afb * afc.PI / (0x2df + 0x4 * 0x985 + -0x283f), afd = (afe + aff) * afg.PI / (0x14e3 * 0x1 + -0xd05 + -0x72a), afh = afi.cos(afj), afk = afl.sin(afm), afn = afo.cos(afp), afq = afr.sin(afs), aft = afu + afv * afw, afx = afy + afz * aga, agb = agc + agd * age, agf = agg + agh * agi, agj = agk + agl * agm, agn = ago + agp * agq, agr = ags + agt * agu, agv = agw + agx * agy, agz.Polygon([
                                [aha, ahb],
                                [ahc, ahd],
                                [ahe, ahf]
                            ], ahg), ahh.Polygon([
                                [ahi, ahj],
                                [ahk, ahl],
                                [ahm, ahn]
                            ], aho);
                        }
                    }
                }
                break;
            case 0x11d5 + 0x1039 * 0x2 + -0x3205:
                adz = -0x9fd + -0x22d5 + 0x1c * 0x19d, --adq;
                break;
        }
        else {
            function ahp() {
                var a = a;
                ahq.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'faster dt'], 0xb3db97a * 0x1 + -0x313e1 * 0x259 + 0xfd8de * 0x36 - (-0xbb51cd0 + -0x9b30f55 * 0x1 + -0x23675a2 * -0xd)), ahr.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'dynamic damage selection'], -0x3 * -0xa0b9d9 + 0xcec55ec + 0xad5666 * -0xb - (0x8591ed2 + 0x6d36448 + -0x7d0b605)), ahs.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'adaptive silent'], (-0x1f3ef + 0x3859f + 0x85d6) % (0x841 * 0x1 + -0xa * 0x321 + 0x170c)), aht.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'dynamic safepoint type'], -0x1 * 0x7081e1f + 0x44ae2dc + -0x2864216 * -0x4 - (-0x65 * 0x132ae1 + -0x37c9 * -0xb3a + 0xc797150)), ahu.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'dmg override amount'], (0x32107 + 0xefd * -0x1f + -0xc722 * -0x1) % (-0xcb3 + -0x431 + -0x10e7 * -0x1));
            }
        }
    }
    var adv, adw, adx, ady, adr, adz, aea, aee, aef, aeg, aeh, aei;
}
UI.AddDropdown(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW'], 'body-yaw type', ['static', 'jitter', 'advanced'], -0x4ea158 + 0x3ed993 * 0x1 + 0xcc2913 - (0x6edeb0 + -0xc908d9 + -0x1 * -0x1168b76));

function auto_buy_prediction() {
    var a = a;
    predicted_time = Globals.Curtime() + Convar.GetInt('mp_round_restart_delay'), buy = NaN !== NaN;
}
UI.AddDropdown(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW'], 'auto-direction type', ['dangerous', 'safe'], -0x472f * -0x225 + -0xdeb3d + 0x31a4c0 - (-0x10ad80 + -0x151173c + 0x21e2609)), UI.AddDropdown(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW'], 'dynamic safepoint type', ['none', 'smart', 'force'], (-0x2454c * -0xc + 0x2754fa + 0x387 * -0x757) % (-0x1 * -0x225f + 0xce5 + -0x2f41 * 0x1));

function jago_walk() {
    var a = a;
    ['username', 'darius', 'HerrKatze', 'melongamer32', 'hwid'], ahv = Globals.ChokedCommands(), ahw = 0x9a + 0x110c + 0x2 * -0x8bf;
    while (ahw < -0x7ac * -0x1 + -0xb1f + 0x3cc) switch (ahw) {
        case 0x4b2 * 0x5 + -0xa7 * -0x33 + -0x1 * 0x388a:
            ahw = 0x1ac0 + 0x2 * -0xc82 + -0x163; {
                ahx = -0x1f * -0x96 + -0xbe1 * -0x1 + 0x9eb * -0x3;
                while (ahx < 0x44f + 0xb96 + 0x161 * -0xb) switch (ahx) {
                    case 0xd25 + 0x1 * 0xa49 + -0x1711:
                        ahx = 0x26c1 * 0x1 + -0x1ed2 + -0x5 * 0x171; {
                            tickcount = Globals.Tickcount(), switch1 = !switch1, switch2 = !switch2, switch3 = !switch3, ahy = -0x14cd + -0x2 * -0x19 + 0x14d1;
                            while (ahy < -0x1 * -0x186b + -0x1 * 0xa9 + 0x1 * -0x173d) switch (ahy) {
                                case 0xd * 0x192 + 0x1dd6 + 0x3211 * -0x1:
                                    ahy = 0x1efd + -0x173d + -0x73b; {
                                        if ('tJtam' === 'tSJVy') {
                                            function ahz() {
                                                var a = a;
                                                aia.SetOverride(0x2f334 * -0x21 + 0x2e0cd * -0x73 + 0x1 * 0x268b719 - (0x2393 * 0x1c1 + -0x46311c + 0xc42d96)), aib.SetFakeOffset(aic), aid.SetRealOffset(-(-0x21a5 + 0x1989 * 0x1 + -0x5b * -0x17) - aie * -((-0x3b4 * -0xf3a + 0x234010 + 0x1 * -0x32f22f) % (0x1 * 0x368 + 0x2a0 + -0x17 * 0x43))), aif.SetLBYOffset(0x9f4470c + -0xb25e51 * 0x8 + 0x2fa7891 - (-0x137b632 * 0x4 + -0x567577c + 0x11a1fd59)), aig = !![], aih = (0x143e9327 + 0xbb7034a * -0x5 + 0x1 * 0x46998d54) % (-0x26ad + -0x1a8c + 0x4142);
                                            }
                                        } else dsalkj2k3123(0x1b5d + 0x21f8 + -0x3d37 * 0x1);
                                    }
                                    break;
                                case -0x31 * -0x9a + -0x23c * -0x1 + 0x47b * -0x7:
                                    ahy = 0x173a + 0x3 * 0x5a8 + -0x27ad; {
                                        aii = 0xbe9 + -0x3c6 + -0x7d2;
                                        while (aii < 0x43 * -0x73 + -0x1003 + 0x2ead) switch (aii) {
                                            case 0xdee + -0x1 * -0x821 + 0x15ef * -0x1:
                                                aii = 0x8 * 0x313 + 0x240 + 0xd9 * -0x1f; {
                                                    if ('AMVDJ' !== 'jkzka') {
                                                        aij = 0x661 + -0x78c + 0x160;
                                                        while (aij < -0x19 * -0x12e + -0x586 + -0x176d) switch (aij) {
                                                            case -0xc9e + -0x1 * 0x270d + 0x33e0:
                                                                aij = switch1 ? -0xeee + 0x211 * -0x1 + -0x5b3 * -0x3 : -0x1c1e + -0x1340 + 0x32a * 0xf;
                                                                break;
                                                            case -0x15f * -0x1 + 0x49e + -0x1f7 * 0x3:
                                                                aij = -0x1c62 + 0x1b * 0x152 + -0x6b9; {
                                                                    if ('jqfdF' !== 'jqfdF') {
                                                                        function aik() {
                                                                            ail = null === aim, ain = (-0x1b10c + -0x4118d + 0x7da1f) % (-0x11d0 + -0xaba + 0x1c8d);
                                                                        }
                                                                    } else dsalkj2k3123((-0x479 * 0x5 + 0x160b + 0x14c) / (0x1f * 0x119 + 0xcd3 + -0x2ec1));
                                                                }
                                                                break;
                                                            case 0x1167 + -0x1 * 0x76 + -0x10d7 * 0x1:
                                                                aij = 0x90b + -0x1469 + -0x1 * -0xbe9; {
                                                                    if ('BDlGW' === 'yLFVA') {
                                                                        function aio() {
                                                                            var a = a;
                                                                            aip.String(aiq.GetScreenSize()[(0x1dd2 * 0xd + -0x1 * -0x7431 + 0x1fab) % (0x1dd + -0x17a1 + -0xdf * -0x19)] / ((-0x22d5c0fa * -0x2 + -0x1e79bf19 + 0x203866f) % (0x5 * -0x41f + -0x1f2a + 0x33cc)) - (0xaea * 0x2a2bf + -0x3e000d53 + 0x76 * 0x8e1bf9) % (0x13e6 + 0x217 * -0x4 + -0xb81), air.GetScreenSize()[0x1caec0 + -0x15bbd * 0x115 + 0x217f60f - (0x9 * 0x82cfb + 0x154f4be + 0x4 * -0x388a11)] / (0x7cbdba + -0x178e79b + 0x1eb18cf ^ -0x6f5 * 0xbef + 0x524b * -0x561 + 0x2fc9a12) + (-0x1bf3 + 0x267 * -0x3 + 0x5 * 0x70c), (-0x86c6 + 0x19820 + 0x1062c) % (-0x1da1 + -0x13c7 + 0x3 * 0x1079), '' + ais, [ait[(-0xe9c1 * -0x1 + -0x2439b + 0x281 * 0x160) % (0x1ae + 0x25f * -0x9 + 0x13ac)], aiu[(0x456df7 + -0x50f0b9 + 0x3 * 0x116679) % (0x1 * 0x23a4 + 0x4 * -0x7d3 + -0x455)], aiv[(-0x1 * 0x33eefa39 + 0x3db92b2b * -0x1 + 0x9add6eae) % (0x19c * 0x3 + 0x9de + 0xeab * -0x1)], -0x935 + 0x244 + 0x10 * 0x7f], aiw), aix.String(aiy.GetScreenSize()[-0x3b1a3 * -0x2e9 + 0x1839a * 0x751 + -0xe780000 - (-0xe100f7 + -0xcb0f2ff * -0x1 + 0x1 * -0x47424f3)] / (-0x5b2a * 0x200 + -0xa8384c + 0x24d7b3a ^ -0x1 * -0x1691902 + -0x3 * 0x17c351 + 0x3 * -0x10f561) + (-0x30c5605 * -0x3 + 0xf1162c * 0x5 + -0x9236e40) % (-0xef + -0x1 * 0x211e + -0x2d7 * -0xc), aiz.GetScreenSize()[0x1117ff7 + 0xc43a2a + 0x1 * -0x11958d3 - (0x4f79b6 + 0xe845fd + -0x1 * 0x7b5e66)] / (0x11f131 * 0x11 + -0x1657def + -0x48da27 * -0x4 ^ 0x1ec7a3 * 0x4 + 0x1765da0 + -0x8 * 0x2051a8) + (0x1 * -0x4d + 0x1e5 + 0xc7 * -0x2), (0x4 * -0x9cf8 + -0xf8e6 * 0x3 + 0x77618) % (-0x4a * 0x40 + 0x1025 + 0x25e), '.', [aja[(0x1e609 + 0x36494 + 0x1 * -0x33317) % (0x1 * -0x12b + -0x13e3 + 0x1511 * 0x1)], ajb[(0x46c * -0x1e1 + 0x4737d + -0x25 * -0x13438) % (0x3e7 + -0xa5f + -0x7 * -0xed)], ajc[(0x360b0276 + -0x4749760 + -0x86121cc) % (0xf2b + 0x15e1 * 0x1 + -0x2505)], 0xd1 * -0x1f + 0x2f * -0x7f + 0x319f], ajd);
                                                                        }
                                                                    } else dsalkj2k3123(0x7d * -0x43 + 0x1d9d * 0x1 + 0x34a);
                                                                }
                                                                break;
                                                        }
                                                    } else {
                                                        function aje() {
                                                            ajf(0x118 * 0x3 + -0x1df3 + -0x7 * -0x3f3);
                                                        }
                                                    }
                                                }
                                                break;
                                            case 0x65 * -0x26 + -0x656 * -0x3 + -0x3f9:
                                                aii = 0x1c8 * -0x4 + 0x5c * 0x2b + -0x7c3; {
                                                    ajg = 0xb * -0x179 + 0x21d2 + -0x1153;
                                                    while (ajg < 0x13 * -0x2a + 0x2b * 0xa1 + -0x1f7 * 0xc) switch (ajg) {
                                                        case 0x401 + 0x3 * -0xc97 + 0x2210:
                                                            ajg = switch1 ? -0x13 * 0xc1 + 0x3d * -0x83 + 0x2dab : 0x769 + -0x29 * 0xc4 + 0x1806;
                                                            break;
                                                        case 0x6bd + -0x242e * 0x1 + 0x1d92:
                                                            ajg = 0xeef * -0x2 + 0xcf2 * 0x1 + 0x1145; {
                                                                dsalkj2k3123(0x174 * -0x3 + 0x7c7 + -0x27b * 0x1);
                                                            }
                                                            break;
                                                        case -0x924 + -0x76f + -0x6 * -0x2c5:
                                                            ajg = 0x1c9f + 0x1b45 + -0xf1 * 0x3b; {
                                                                dsalkj2k3123(-0xbff + -0x22d1 * 0x1 + 0x2fca);
                                                            }
                                                            break;
                                                    }
                                                }
                                                break;
                                            case 0x8c9 * -0x1 + -0x3d * -0x6d + -0x10df:
                                                aii = switch2 ? -0x259a + -0x13a1 + -0x1ca3 * -0x2 : 0x52d * 0x6 + -0x2039 * -0x1 + -0x11 * 0x3b7;
                                                break;
                                        }
                                    }
                                    break;
                                case -0x2116 + 0xb8 * -0x32 + 0x1 * 0x453c:
                                    ahy = switch3 ? -0x24c3 + 0x14d8 + 0x1044 : 0x7b7 + 0x2413 + -0x1 * 0x2b9b;
                                    break;
                            }
                        }
                        break;
                    case -0xb4 + -0x85c + -0x85 * -0x12:
                        ahx = Globals.Tickcount() > tickcount + (-0x3f36593 + 0x1 * -0x55e507f + -0x23237 * -0x587) % (-0x849 + -0xd * 0x19 + -0x3 * -0x332) ? -0x269 * -0x8 + -0x1113 + -0x8 * 0x3b : -0x993 + -0x3cd * 0x3 + 0x15b4;
                        break;
                }
            }
            break;
        case -0x935 * -0x1 + -0x1cbf + 0x13b2:
            ahw = jagowalking == ([null] == '') ? 0x7 * 0x1f5 + -0x2185 + -0x1 * -0x1407 : -0x1487 + -0xea + 0x1589;
            break;
        case -0x35e + -0x19e5 + -0x3 * -0x9c9:
            ahw = 0xa0b + 0x99c * 0x1 + -0x134e, dsalkj2k3123(0x42b9 + 0x10c0 + -0x2c69);
            break;
    }
    var ajh, ahv, ahw, ahx, ahy, aii, aij, ajg;
}
UI.AddDropdown(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW'], 'fakelag type', ['factor', 'step', 'random', 'fluctuate'], 0xd * 0xad2a3 + -0xa7269d * -0x1 + -0x3bbbcb * 0x2 - (0x1789234 + 0x765fe9 * 0x2 + -0x1a8f0b9));

function dsalkj2k3123(aji) {
    var a = a;
    ajj = -0x1017 + -0x2 * 0x211 + 0x1 * 0x1471;
    while (ajj < 0x1 * -0xfcd + -0x1ef8 * 0x1 + 0x2f51) switch (ajj) {
        case 0x17a8 + -0xe3 * -0x27 + 0x3a05 * -0x1:
            ajj = Convar.GetFloat('cl_sidespeed') == -0x4 * -0xc8 + -0xcb * -0x25 + -0x1eb5 && aji == -0x174c + 0x6c * 0x21 + -0x1e * -0x5f ? 0x1 * 0x149d + 0x71a + -0x1b7e : 0x8 * -0xf1 + -0x1b59 + 0x236d;
            break;
        case -0xa5a + -0xbea + 0x77f * 0x3:
            ajj = 0x1 * 0x1f52 + 0x1912 + 0x8 * -0x6fb;
            return;
    }
    Convar.SetFloat('cl_sidespeed', aji), Convar.SetFloat('cl_forwardspeed', aji), Convar.SetFloat('cl_backspeed', aji);
    var ajj;
}
UI.AddColorPicker(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW'], 'indicators color');

function dsal2323234222232223323233233242323332323232322223342323223232223233434232342342342323422342342344234332k312323() {
    var a = a;
ajl = CheatHooked.GetUsername();
    while (ajn < 0xc89 + 0x85 * -0x2f + 0x4d * 0x29) switch (ajn) {
        case -0x1f * 0x110 + 0xfcd + 0x1 * 0x1141:
            ajn = ajl != ajm[0x38 * -0x151533 + 0x643612a + 0x5b50f13 - (0x9 * 0xa9431d + -0x1 * 0xe90e2af + 0x2483089 * 0x7)] || ajl != ajm[0x95 * -0x1bf57 + -0x4075 * -0x24b + -0x1 * -0x12cf2aa - (0x1 * 0x6d2c95 + 0x20d03 * -0x3b + 0xbc6d9 * 0x11)] || ajl != ajm[(-0x34ed6758 + -0x4cd80f89 + 0xaafac02b) % (-0x5 * -0x17 + -0xfb7 + 0x57 * 0x2d)] || ajl != ajm[(0x4aacabc + 0x6413dd0 + -0x3f23 * 0x192b) % (-0x1cb7 * -0x1 + 0xdc6 * -0x2 + 0x4 * -0x49)] || ajl != ajk[0xa426 * 0x5f + -0x4ca529 + -0x42cc1 * -0x3d ^ -0x32d * -0x7255 + 0x118bf08 + 0x194e80d * -0x1] ? -0x18c9 + -0x521 * -0x5 + -0xa * 0x11 : 0x1 * 0x115f + -0x1 * -0x140f + 0x24fb * -0x1;
            break;
        case -0x1cb0 + -0x5 * 0x12 + -0x4 * -0x74f:
            ajn = -0x19e9 + -0x1db2 + 0x59b * 0xa, dsal23232342222322323233233242323332323232322223342323223232223233434232342342342323422342342344234332k312323();
            break;
    }
    ajo = 0x2176 + -0x130 + 0x2009 * -0x1;
    while (ajo < -0x43f * -0x3 + -0x287 * -0x1 + 0x73 * -0x21) switch (ajo) {
        case 0x484 + -0xc * 0x175 + 0x7 * 0x1df:
            ajo = 0x49 * -0x6d + 0x1c82 + 0x304; {
                dsal23232342222323233242323332323232322223342323223232223233434232342342342323422342342344234332k312323();
            }
            break;
        case -0x4 * -0x48b + -0x65c + -0x1 * 0xb93:
            ajo = UI.GetValue(['Config', 'JAGO-YAW', 'JAGO-YAW', 'buy awp']) == ([null] == '') ? 0x1 * 0x2669 + 0xf42 + -0x358a : 0x13 * -0x201 + 0x1 * 0x22bd + -0x1 * -0x3c7;
            break;
    }
    ajp = -0xdb7 * 0x2 + 0x1296 + 0x64 * 0x17;
    while (ajp < 0x1802 + 0x1 * -0xffb + 0x65 * -0x13) switch (ajp) {
        case 0x9 * -0x40d + -0x1d81 * -0x1 + 0x718:
            ajp = UI.GetValue(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW', 'body-yaw type']) == 0x180798b + -0xd96da7c + 0x13722e06 - (0x1b6376 * 0x1 + -0x822fb31 + 0xf6364d0) ? 0x209c * -0x1 + 0x925 * 0x2 + 0xe67 : 0xf3 + -0x15 * 0x1bc + 0x23db * 0x1;
            break;
        case 0x1 * -0x2462 + -0xd69 + -0x30 * -0x10a:
            ajp = 0xd21 + 0x579 * 0x1 + -0x909 * 0x2; {
                dsal232323422223232332432323232322223342323223232223233434232342342342323422342342344234332k312323();
            }
            break;
        case 0x1 * -0x56c + -0x681 + 0x17 * 0x89:
            ajp = 0x17 * -0x15e + 0x1daf + 0x24b, ajq = 0x4eb * 0x4 + -0x26c + -0x1127;
            while (ajq < -0x12b9 * -0x1 + 0x22bc + -0x2b * 0x13c) switch (ajq) {
                case -0x2251 + 0x1684 + 0xc25:
                    ajq = -0x6b6 * -0x2 + 0x6be * -0x5 + 0xd * 0x197, ajr = 0x2521 * 0x1 + 0x503 * 0x7 + -0x4821;
                    while (ajr < -0x317 * -0xc + -0x6 * 0x35f + -0x1090) switch (ajr) {
                        case -0x255 * -0xe + 0x89 * -0x22 + -0xe65:
                            ajr = -0x132b + 0x186 * 0x19 + -0x12a1 * 0x1; {
                                dsal23422232432323232322223342323223232223233434232342342342323422342342344234332k312323();
                            }
                            break;
                        case 0x13 * -0x4c + 0x298 * -0xe + 0x2a09:
                            ajr = UI.GetValue(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW', 'body-yaw type']) == (-0x1918182b + -0x32bb2af * -0x13 + 0x183c79e * 0x4) % (-0x1 * -0x1c45 + -0x1147 * -0x1 + -0x2d85) ? -0xa0e + -0x8 * 0x232 + 0x1bad : -0x9 * 0xba + -0x1e48 + 0x251c;
                            break;
                    }
                    break;
                case -0x1 * -0x2687 + -0x791 * -0x3 + -0x3cfa:
                    ajq = 0x19f4 + -0x473 + -0x1520; {
                        dsal232323422232432323232322223342323223232223233434232342342342323422342342344234332k312323();
                    }
                    break;
                case -0x1325 + -0xc6f + -0x9 * -0x385:
                    ajq = UI.GetValue(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW', 'body-yaw type']) == -0x82ae69 + -0x2 * 0x34c2b5 + 0x8d870b * 0x3 - (-0x621e64 + 0xd37619 + -0x1f984 * -0x26) ? -0x1 * -0x1a27 + 0x3 * 0x713 + -0x2f20 : 0x1 * -0x1333 + 0x1 * 0x14fb + -0x17 * 0x10;
                    break;
            }
            break;
    }
    ajs = 0xc5c84d + -0x1e7ffd * 0x3 + -0xb8 * -0x7239 - (-0x7 * 0x1813f9 + 0x16c6e65 + -0x78149);
    while (ajs < 0x1 * -0xa57 + -0x1116 + -0x25 * -0xc1) switch (ajs) {
        case (0x65 * -0x193f + 0xb * 0x4a809 + -0x91df) % (-0x45e * 0x5 + 0xcf * 0x6 + -0x10ff * -0x1):
            ajs = UI.GetValue(['Config', 'JAGO-YAW', 'JAGO-YAW', 'jitter movement']) == (NaN !== NaN) ? 0x7 * 0x31 + -0x6ab + 0x589 : 0x1 * 0x13de + 0x10ce + -0x247c * 0x1;
            break;
        case 0x4c5 * 0x5 + -0xc0a + -0xb9a:
            ajs = 0x7 * 0x134 + -0x702 + 0xb * -0x16; {
                dsal2342223243232322223342323223232223233434232342342342323422342342344234332k312323();
            }
            break;
        case -0x7 * 0x283 + 0x2434 + -0xb * 0x1ad:
            ajs = -0x22d8 + 0x20 * 0xbe + 0xb90; {
                dsalkj2k3123(0x1086 + -0x3 * 0xc37 + 0x3 * 0x74b);
            }
            break;
    }
    dsal232323422232322sdssdsdd3222232332323322223233323233233242323332323232322223342323223232223233434232342342342323422342342344234332k312323(), dsal232323422232322sdsd3222232332323322223233323233233242323332323232322223342323223232223233434232342342342323422342342344234332k312323(), dsal23422232432223342223233434232342342342323422342342344234332k312323(), ajt = 0x25 * -0x6 + -0xb * 0xd6 + 0xa3f;
    while (ajt < 0x5 * -0x32 + -0x1 * -0x18c6 + -0x1745) switch (ajt) {
        case -0x254e + -0x9ef * -0x3 + 0x7c1 * 0x1:
            ajt = -0x97a * -0x1 + 0x70c + -0xfff, UI.SetValue(['Rage', 'General', 'General', 'Silent aim'], (0xb29 * -0x1b1 + -0xa2582 + 0x45b684) % (0x2080 + 0x187 * -0x17 + -0x2 * -0x152));
            break;
        case -0x2a * 0xa9 + -0xd86 + 0x2999:
            ajt = 0x17d0 + 0x1 * 0x12d9 + 0x1511 * -0x2, dsal2342223243222334223232223233434232342342342323422342342344234332k312323();
            break;
        case 0x1 * -0x1567 + 0x2dc * -0x1 + 0x3 * 0x826:
            ajt = UI.GetValue(['Config', 'JAGO-YAW', 'JAGO-YAW', 'adaptive silent']) == (NaN !== NaN) ? 0x1d4c + 0x4 * -0x33c + -0x1003 : 0x5 * -0x2e5 + -0x1 * -0x260f + -0x1756;
            break;
    }
    aju = 0x1 * -0x191d + 0x1 * 0x1516 + 0x226 * 0x2;
    while (aju < -0x3b * 0x41 + -0x859 + -0x17d5 * -0x1) switch (aju) {
        case -0x2c * 0x7 + -0xd4f * 0x1 + -0xec8 * -0x1:
            aju = UI.GetValue(['Config', 'JAGO-YAW', 'JAGO-YAW', 'faster dt']) == (null == undefined) ? -0x1 * 0x823 + 0x4aa * -0x8 + -0x1 * -0x2d9d : 0x2 * -0x5 + -0x634 * 0x1 + 0x1 * 0x69d;
            break;
        case 0x217 * 0x6 + 0x2 * -0x135b + -0x1 * -0x1a56:
            aju = 0x1d5 + -0x197d + 0x1 * 0x1829; {
                dsal2342223243222334223434232342342342323422342342344234332k312323();
            }
            break;
        case -0x8b * 0x1f + -0x278 * 0x4 + -0x6c5 * -0x4:
            aju = -0x53 * -0x2b + -0x2297 + 0x1527; {
                Exploit.OverrideShift(0xb78a4f8 + -0x8b8ae7e + 0x49bd69b - (0xd0dd3a8 + -0xccc0646 + -0x224d47 * -0x35)), Convar.SetInt('cl_clock_correction', (-0x2de7f2 + 0x122e2b + 0x9c61 * 0x70) % (0x1 * 0x1ef3 + -0x1357 + -0x1 * 0xb99));
            }
            break;
    }
    dsal23422232432234223434232342342342323422342342344234332k312323();
    var ajk, ajl, ajm, ajn, ajo, ajp, ajq, ajr, ajs, ajt, aju;
}
UI.AddSliderInt(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW'], 'jag0-walk switch', (-0x3bd6d * 0x1 + -0x19766 * 0x1 + -0x76c59 * -0x1) % (-0x25 + -0x2461 + 0x1 * 0x2489), (-0x8cb4e19 + 0x1 * 0x6a82825 + 0x6da289f) % (0x2 * 0xaf3 + 0xe7a * -0x1 + -0x765));

function is_peeking(ajv, ajw) {
    var a = a;
    ajx = Entity.GetLocalPlayer(), ajy = 0x153d + 0x1cb9 + -0x3 * 0x109c;
    while (ajy < 0x1d2 * -0xe + 0x25 * -0xf + 0x1c39) switch (ajy) {
        case -0x1027 + -0x30a * -0xa + -0xe14:
            ajy = -0x1 * 0x1421 + 0x1115 + 0x39e;
            return;
        case 0x8a * -0x18 + -0x6a * 0x47 + 0x2a78:
            ajy = ajv == null ? 0x57 * -0x5b + -0xddb + -0xf * -0x2ff : -0xcc9 + 0xf3c + 0x1 * -0x1e1;
            break;
    }
    ajz = Entity.GetProp(ajv, 'CCSPlayer', 'm_vecOrigin'), aka = -0x35 + 0x58f + -0x535;
    while (aka < 0x1 * 0x2a1 + -0x79f * -0x1 + -0x8 * 0x134) switch (aka) {
        case 0x2316 + 0xd53 + -0x2 * 0x1822:
            aka = (ajz = null) ? 0x60 * -0x24 + -0x29 * 0x2d + -0x14c5 * -0x1 : 0x249b + -0x4 * -0xf8 + -0x3 * 0xd49;
            break;
        case -0x1 * -0x2352 + -0x1323 + -0x101f:
            aka = 0x17f6 + -0x15b3 + -0x1a3 * 0x1;
            return;
    }
    akb = Entity.GetHitboxPosition(ajx, 0x1769 * 0x1 + -0x1700 + -0x2 * 0x2f), akc = Entity.GetHitboxPosition(ajx, -0x3f * -0x66 + 0x346 + 0x1c54 * -0x1), (akd, ake, akb = dsal23kj2k312323(akd, ake, akb, ajw, ajx)), (akf, akg, akc = dsal23kj2k312323(akf, akg, akc, ajw, ajx));
    var ajx, ajy, akh, aki, ajz, aka, akd, ake, akb, akf, akg, akc;
}
UI.AddSliderInt(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW'], 'dmg override amount', (-0x16d7 * 0xa + -0xc * -0x5197 + -0xd8 * 0xff) % (-0x651 + -0x43f * 0x3 + -0x1 * -0x1311), -0xe27 + -0x9b9 + 0x1844), UI.AddSliderInt(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW'], 'thirdperson distance', -0x849 + -0xbbc * -0x1 + -0x341, -0x245 + -0x1678 + -0x1ab1 * -0x1);

function dsal23kj2k312323(akj, akk, akl, akm, akn) {
    var a = a;
    ako = Entity.GetProp(akn, 'CBasePlayer', 'm_vecVelocity[0]'), akp = Entity.GetProp(akn, 'CBasePlayer', 'm_vecVelocity[1]'), akq = Entity.GetProp(akn, 'CBasePlayer', 'm_vecVelocity[2]'), akr = 0xa3f + -0xc * 0x2d3 + 0x17d8;
    while (akr < -0x193 * -0x4 + 0x1af * -0x13 + 0x1a10) {
        switch (akr) {
            case -0x9e0 + 0x1 * -0x169a + 0x20b3 * 0x1:
                akr = 0x214e + 0x1d * -0xdf + -0x7b1; {
                    akj = akj + ako * Globals.TickInterval(), akk = akk + akp * Globals.TickInterval(), akl = akl + akq * Globals.TickInterval();
                }
                break;
            case 0x2e * 0x48 + 0x2283 * -0x1 + 0x15c6:
                akr = 0xa80 + 0x10 * 0xf + 0x4 * -0x2d5, i = (0x3b223 + -0x4088a + 0x26ded * 0x1) % (0x1748 * -0x1 + 0x1 * 0xefe + 0x84d);
                break;
            case 0xe55 + 0xd0c + -0x1b45:
                akr = i < akm ? -0x1 * -0x1316 + 0xb99 + -0x1e76 : -0x223 * 0x6 + -0x1d3b + 0xf * 0x2d4;
                break;
            case -0x163 * 0xf + -0x131c + 0x2843:
                akr = -0x2674 + -0x1532 * 0x1 + 0x3bc2, i++;
                break;
        }
    }
    return akj, akk, akl;
    var ako, akp, akq, akr;
}
UI.AddSliderInt(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW'], 'traced lines distance delta', (0x4884c * -0x1 + 0x640 * 0xa84 + -0x14800b) % (-0x19d + -0xb85 + 0xd25), -0x17e * -0x11 + -0x135d * 0x2 + 0x253 * 0x6);

function dsal23232342222323233242323332323232322223342323223232223233434232342342342323422342342344234332k312323() {
    var a = a;
    aks = 0x10d5 * 0x1 + -0x2535 + 0x1470 * 0x1;
    while (aks < 0x8e1 + 0x1 * -0x541 + 0x46 * -0xb) switch (aks) {
        case -0x1a3f + -0x1 * 0x971 + 0x2c0 * 0xd:
            aks = buy && Globals.Curtime() + Local.Latency() / (-0xd9 * 0x1 + 0x35f * -0x4 + -0x123d * -0x1) >= predicted_time + Local.Latency() / (0x1b1c + -0x2 * 0x1079 + 0x9be) ? (0x158b5d8 + -0x2d1463 * 0x22 + 0x907a66b) % (0x8 * -0x52 + 0x2 * 0xf05 + 0x5 * -0x57d) : -0x917 + -0xf07 + 0x18bc;
            break;
        case 0x3e315 * -0x74 + 0x61 * 0xad30d + -0x2e6d69 * -0x7 & -0x1bb00b3 + 0x675c8c + -0x1d72 * -0x31b2:
            aks = 0x1894 + -0x23e2 + -0xe * -0xda; {
                CheatHooked.ExecuteCommand('buy awp'), CheatHooked.ExecuteCommand('buy awp'), CheatHooked.Print('predicted: ' + predicted_time + Local.Latency() / (0xda8 + -0xb * -0x2d7 + -0x28fd) + ' current:' + (Globals.Curtime() + Local.Latency() / (-0x1e96 + 0x29 * 0x6d + 0x1109) + '\x0a')), buy = 0x1c36 * 0x1 + 0x1322 * -0x1 + -0x65 * 0x17 === '1';
            }
            break;
    }
    var aks;
}
UI.AddSliderInt(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW'], 'fake offset divider', (0x1ee3 * -0x11c + 0xb * -0x39ead + 0x3962f6 * 0x2) % (-0xe18 + 0x1132 + -0x71 * 0x7), 0x57cdfb3 * 0x3 + -0x9c7b07 * -0x39 + -0x19a1b235 * 0x1 - (0x3b6 * -0x9bd64 + 0xcc39c19 + 0x310d866a));

function auto_buy_purchased() {
    buy = ![];
}
UI.AddSliderInt(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW'], 'real offset divider', 0x1ad2e3 * 0xe + 0x10da99d + 0x1 * -0x1c8d0b9 - (-0x8d4d6c + -0x76d186 + -0x3 * -0x958015), 0x162263c * -0x17 + -0x2f71866f + 0x68ef4746 - (-0x221d91f3 + 0x2ef48312 + 0xcd5604c)), UI.AddSliderInt(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW'], 'inactive desync delta', (0x9 * -0x115b + 0x3ccdb + -0xa * 0x1c1d) % (-0x742 + 0x1043 + -0x1 * 0x8fe), 0x2529 + 0x11f8 + 0x3a9 * -0xf);

function dsalkj2k3(akt, aku) {
    var a = a;
    akv = dsal234223423423422342342344234332k312323(aku[0xb87f0e2 + 0x1 * -0x380ce50 + -0x391c7f * 0x3 - (0xba31433 + 0x13 * -0x3c2d94 + 0x301ade)], aku[(0x38b337 + 0x1a50 + -0x80e6f * 0x2) % (-0x260b + 0x18e * 0x1 + 0x2480)]), akw = Entity.GetRenderOrigin(akt), akw[(-0x3 * 0x3db8899 + -0x1 * 0x4d410cb2 + -0x8208efc7 * -0x1) % (0x1 * -0x1179 + -0x13c0 + -0x2540 * -0x1)] += -0x89 * -0x9 + -0xad0 + -0x5 * -0x13d, akx = [akw[-0xbb341e3 + -0xf0f * -0xa8c2 + -0xb * -0xd4870e - (0x55c9f0b + -0xaf3ce49 * -0x1 + -0x8f4a03f)] + akv[0x2d35bb0 + -0xe1b8611 + 0x12a3f776 - (0x2cdde * -0x38b + -0x1087401 + -0xb4729 * -0x1a0)] * (-0x10b7 * -0x1 + 0x1233 * 0x1 + -0x1 * 0x2ea), akw[(0x1 * 0x4b3ac3 + 0x4b * -0xa26a + 0x28c * 0x51f) % (0xa1 * -0x13 + 0x1703 + -0xb0d)] + akv[(0x55 * 0x342b + -0xe22 * -0x43f + -0x24a3fc) % (0x1 * 0x57a + 0x1 * 0xfb + -0x672)] * (0x28a1 + 0x26a9 + 0x2 * -0x17a5), akw[(0x490a1628 + -0x3416a42b + -0x1441d74d * -0x1) % (0x1d64 + -0x1765 * 0x1 + 0x5f8 * -0x1)] + akv[-0x703 * 0xeec + 0x1707293 + -0x18e2e1 * 0x1 ^ 0x53c242 * 0x5 + 0xe6fa47 * 0x2 + -0xa0743b * 0x4] * (0x127d + -0x11 * -0xdf + -0x14c)], aky = Trace.Line(akt, akw, akx), akz = 0x1 * 0x25cd + -0x198f + -0xc16;
    while (akz < 0xa3b + -0x1299 + 0x8d5) switch (akz) {
        case -0x2 * 0x25 + 0x1186 + -0x1114:
            akz = aky[0x4ca64e + -0x9175cb + 0x10130cb * 0x1 - (0xb9ab85 * -0x2 + 0xf70b * 0x1 + 0x4f4 * 0x70cf)] == (-0x2 * 0x39d2f + -0x47144d + 0x8a5 * 0xdc4) % (-0x2 * 0x96b + -0xee3 * 0x2 + 0x309f) ? 0x2 * 0x53e + 0x1 * 0x1285 + 0x6 * -0x4cd : -0xa8b + 0x6 * -0x490 + -0x22 * -0x121;
            break;
        case -0x2222 * -0x1 + 0x1 * -0x1327 + -0xec8:
            akz = -0x214 * -0x8 + 0x1117 + -0x2140;
            return;
    }
    akx = [akw[(0x32b * 0x122 + -0x1 * 0x2965f + 0x1172f) % (0x62f * -0x5 + -0xf41 + 0x2e2f)] + akv[(0x3f * 0x11b + -0x54 * -0xb52 + -0x1e507) % (-0x20fb * 0x1 + -0x4 * -0x845 + -0x16)] * aky[(-0x1 * -0x28d437 + 0x6ba97 * -0xb + 0xa8dd9 * 0x7) % (-0xec5 * 0x1 + 0x1 * 0x12bb + -0x3f3)] * (-0xe * -0x85 + -0x1675 + 0x2f2f * 0x1), akw[(0x2330a + 0x1e491 * -0xf + 0x21710f * 0x2) % (-0xe + 0x3 * -0xbb9 + 0xdc * 0x29)] + akv[0x1 * -0x77ebb1 + 0xb2c857 + 0x5a198 * 0x17 - (0x2 * -0x19ba91 + -0x7 * 0x1f24cf + -0x1438 * -0x16a5)] * aky[0x173eabe + -0x70b0c5 + -0x17 * 0x3148d - (0x80fb * 0x251 + -0xb * 0x68ff7 + -0x263481)] * (0x3f3 * 0x9 + -0x235 + 0x156 * -0x1), akw[(0xf673a * 0x115 + -0x25 * -0x1710b + -0x32b * -0x7ae53) % (-0x25 * 0x73 + 0x264a + -0x15a4)] + akv[-0x954bb8 + -0xd49e90 + -0x381e * -0xab5 ^ -0x92112e + -0x5b * 0x152e + 0x1888774] * aky[0x1202e37 + 0x59 * -0x2bf3 + 0x1d661 * -0x2e - (0x2e8d87 + -0x3e5 * -0x4a2a + -0x9301cc)] * (0x4a * 0x71 + 0xdf1 + -0xe9b)], ala = Math.sqrt((akw[-0x1 * -0x2bd38da + -0x820c708 + -0xcbf5b43 * -0x1 - (0x8b * 0xfb937 + 0x3a3da6d + -0xd * 0x5ee4c9)] - akx[0xa89d683 * 0x1 + 0x5443f9e + -0x872490c - (-0x3b85f * 0x1d8 + 0xa09b29b + 0x42e09a2)]) * (akw[(0x30b41 + -0xfcf5 + 0x93a) % (-0x944 + 0x88 + -0x1 * -0x8bf)] - akx[(-0xbb9d + 0x4 * 0x42a7 + 0x1e9 * 0xef) % (0x5fc + -0x9b0 * -0x1 + -0xfa9)]) + (akw[0x119bc1b + -0x2 * -0x62500f + -0x296cfd * 0x7 - (-0x11 * 0x1117bb + 0x13d77fd + 0x1 * 0xa17cbb)] - akx[(-0x618fc + 0xf * -0x49e07 + -0x1 * -0x740c0e) % (-0x160 + 0x756 + -0x1 * 0x5f3)]) * (akw[(0xa49 * 0x7d5 + -0x1f * -0x288b1 + -0x766a83) % (-0x79c * -0x1 + -0x353 * -0x3 + -0x15a * 0xd)] - akx[(0x2a5cba + -0x498da4 + -0x1a2d * -0x2bf) % (-0xb09 * 0x1 + 0x34 * -0x5f + 0x1e58 * 0x1)]) + (akw[-0xeee86e * -0x1 + -0x6 * -0x49f541 + -0x1bbb906 ^ -0x17 * -0x9ca3 + -0x56eb38 + 0x137c77f] - akx[(0xb9 * 0xf4079 + 0x44f944bd * -0x1 + 0xa * 0x9ea7f0f) % (0x1f * -0xd + -0x1 * -0x22d + -0x93)]) * (akw[-0x3746e * -0x15 + 0xa4f9 + 0xb * 0xf112d ^ 0xcac3a2 + 0xeb4dc4 + -0xc7227a] - akx[0x22924f + 0x9ea1e8 + 0xf3 * 0x302d ^ 0x503 * 0x52af + 0x12dfa7b + -0x2 * 0xeeb74e])), akw = RenderHooked.WorldToScreen(akw), akx = RenderHooked.WorldToScreen(akx), alb = 0x317 * -0x6 + -0xe2 * -0xd + -0x269 * -0x3;
    while (alb < 0xfa1 + -0x14 * -0xc3 + -0x2 * 0xf42) switch (alb) {
        case -0x251e + 0xf * 0x173 + 0xf8c:
            alb = akx[(0x19b6e4ec + -0x133078f1 + -0x49 * -0x79a0d7) % (-0x1 * 0x6d9 + 0x214f * 0x1 + -0x1a6f * 0x1)] != (0x484628 + -0xbf596 + -0x139fe9) % (-0xef * 0x1c + 0x1 * 0x13ab + -0x14 * -0x53) || akw[0x5f5fc5 + 0xaf * 0x19a47 + -0x470 * 0x1eda ^ 0x1 * 0x1a00a29 + 0x3df974 + -0xef14b1] != (-0x4d0b * -0xf2 + -0x3ade5e * 0x1 + 0x58f * 0x4cf) % (-0x656 + 0x4f0 + 0x169) ? (0x162e4 * -0x2 + -0x1b57d * 0x1 + -0x1508f * -0x5) % (0xd * -0x152 + 0x741 + 0xfe * 0xa) : -0x6 * 0x16a + 0x74f * 0x1 + 0x186;
            break;
        case -0x1934c37 + -0x94ea00 * 0x16 + 0xe6e * 0x1818a - (-0x2 * -0x6ac39a3 + -0x8df39bf + 0xcbf * 0x39f2):
            alb = -0x27 * 0x3d + 0x6d * -0x35 + 0x1e5 * 0x11;
            return;
    }
    return ala;
    var akv, akw, akx, aky, akz, ala, alb;
}
UI.AddSliderInt(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW'], 'jitter', 0x4eff554 + 0x97b5b53 * 0x1 + -0x1 * 0x70f8392 - (-0xa * 0xa35edb + 0xd4555ae + 0x782bf5), 0x1314 + -0x23e4 + 0x18a * 0xb);

function dsal2323234222232223322223233323233233242323332323232322223342323223232223233434232342342342323422342342344234332k312323() {
    var a = a;
    alc = Global.GetScreenSize()[(0x5c4 * -0x93f + 0x2050d2 + 0x3daf13) % (0x1048 + -0x1 * 0xb4e + 0x1f * -0x29)] / (-0xe82 + 0x21be + -4921.9), ald = -0xc97 + -0x1d1e + 0x29bf, ale = -0x2cb + -0x156d + 0x36 * 0x73, alf = UI.GetColor(['Config', 'JAGO-YAW', 'JAGO-YAW', 'indicators color']), alg = RenderHooked.AddFont('arial', 0x2 * 0x1282 + 0x775 + -0x2c6f, -0x33b * -0x5 + -0x1ae3 + 0xddc), RenderHooked.GradientRect(ald, alc + ale, -0x1ac0 + -0x9 * 0x239 + 0x51 * 0x95, -0x15 * -0x19f + -0xfb5 + -0x1232, (-0x3eddd + -0x2395a + 0x83ebd) % (0x4 * -0x373 + -0x7 * 0x11a + 0x1585), [0x18b0 + 0x1 * -0x113b + -0x760, -0x474 + 0x143f + -0xfb6, 0x9 * 0x454 + 0x1cd8 + -0x43b7, 0x15cb + 0x42 * 0x4f + -0x2993], [0x8d * -0x26 + -0x1322 + -0x2825 * -0x1, -0xdb + 0x748 + -0x658, 0x867 * 0x2 + 0x1 * 0x99f + -0x1a58, -0x9e62ae + -0xe1d93b9 + 0x1617c37c - (0x2f38 * -0x48a + 0x893 * 0xfe25 + -0x50f5fa)]), RenderHooked.Rect(ald, alc + ale, -0xbca + -0x1d3c + 0x296a, (-0x101ee5 + -0x3c8195 + 0x62cb1 * 0x13) % (0x6b6 + -0x1 * 0xc9d + 0x5ea * 0x1), [alf[(0x1d3c3 + -0x9b71 + 0xdf34) % (-0x1 * -0x24ec + 0x1 * 0x37e + -0x2867)], alf[-0x13785cf + -0x1 * 0x10e23c6 + -0x5bfd * -0x85f - (-0x15b3227 + -0xd767c6 + 0x2eefb3a)], alf[0x16d1085 + 0x8573d9 + -0x1039570 ^ -0x1d15602 * -0x1 + -0x1990cc0 + 0xb6a5aa], -0xcaa * -0x3 + -0x205f + -0x4a0]), alh = -0x9b * 0xf + -0x2 * 0x479 + 0x3 * 0x61b;
    while (alh < -0x19ca + -0x141f + -0x5 * -0x946) switch (alh) {
        case -0x178d * 0x1 + 0x2006 + -0x82f:
            alh = UI.GetValue(['Rage', 'SUBTAB_MGR', 'Exploits', 'SHEET_MGR', 'Keys', 'Key assignment', 'Double tap']) ? 0x71e * 0x1 + 0x5f4 * 0x4 + -0x1ed8 : -0xc32 * 0x2 + 0x1 * -0x2141 + 0x3a1a;
            break;
        case 0x179 * 0x15 + -0x5 * -0x577 + 0x3a2a * -0x1:
            alh = -0xa83 + -0x16 * 0x98 + -0x1 * -0x1808; {
                RenderHooked.String(ald + (-0x1 * 0x1dc2dcda + -0x13fb6e49 * -0x3 + 0x44833 * 0x293) % (0x193b + -0x47b * 0x2 + -0x103e), alc + ale + (0xa7e35 + -0x5 * 0x1006db + 0x1 * 0x6e54bb) % (-0x15ad * -0x1 + 0x21dc * 0x1 + 0xce * -0x45), (0x365f1 + -0x953 * 0x3b + 0xd7b6) % (-0x1 * 0x2353 + 0x4d * -0x6d + 0x3 * 0x16b5), '> double-tap', [-0xd8f7fc1 + -0x2b * -0x3aa351 + 0xb11de3b - (-0xaf83fd2 + 0xa465efa + 0x1 * 0x80daded), (0x2f * 0xe87 + -0x30c55 + -0x2 * -0x13c89) % (0x1 * 0x120e + 0x1 * -0x12c6 + -0x1 * -0xbb), -0x706048f * 0x1 + -0xc1656b0 + -0x271c * -0xad43 - (-0x5a2 * -0x44b0 + -0x1 * -0x74da7ab + -0x174c1f6), -0xc4 * -0x1a + -0x2459 + 0x1170], alg), RenderHooked.String(ald + (-0x4e2e3c + 0x4 * 0x83d6f + 0x55e929) % (0xe21 + -0x1 * -0x255b + -0x3379), alc + ale, (-0x110ff + -0x1943e + 0x4bcc3) % (0x2b * 0x86 + 0x1bad + -0x322c), '> double-tap', [-0x2bc * 0x5 + -0x48a + 0xb * 0x1bf, 0x1 * -0x1389 + 0x1eb6 + -0xa2e, -0x25bb + -0x21c8 + 0x4882, 0x1a2a + -0x3e * 0x84 + 0x6cd], alg), ale += 0x2307 + 0x2340 + -0x1 * 0x463d;
            }
            break;
    }
    ali = 0x29f * 0x1 + 0x144a + -0x16db;
    while (ali < -0x2f * 0xae + 0x17b + -0x125 * -0x1b) switch (ali) {
        case 0x1 * 0x1e19 + 0xc42 + -0x29ff:
            ali = 0x72f * -0x3 + 0x1 * 0x896 + 0xd67; {
                RenderHooked.String(ald + (0xe5ae4a + 0x83c456 * -0x2 + 0x9be0c * 0x1c ^ 0x4866b + -0x6052de + 0x14abb5f * 0x1), alc + ale + (-0x7 * 0x141875 + 0x1 * 0x57e156 + 0xf12b2b - (-0x45 * -0x5491c + -0x15 * -0xcd6d9 + -0x1bdf30c)), 0x5af3bab + -0x584921f * -0x2 + -0x2efddc * 0x33 - (-0x8e51 * 0x1633 + -0x1 * -0x5c13287 + 0x323 * 0x4721b), '> hide-shots', [0x4a58aec + 0x9 * 0x8bd147 + -0x2341956 - (-0x4631e * -0x30b + -0xc72ebf3 + 0x6751cbe), 0xed9b9 * 0xc7 + -0x3 * -0x64025 + -0x4423229 - (-0x69e85fb + 0x1508ece + 0xca9c442 * 0x1), 0xd * 0x339e23 + -0x5a9d82 * -0x7 + 0x24276c0 - (-0xb3ab200 + -0x646d15 * -0x1d + -0xc63e4 * -0x95), -0x1 * -0x526 + 0x12b0 + 0x1 * -0x16d7], alg), RenderHooked.String(ald + (0xf3c5cf * 0x1 + 0x141b137 * -0x1 + 0x10a4cb6 - (0x71857 * 0x1f + -0x19c9b3 + -0x5c789)), alc + ale, -0x5904cd0 + -0x1 * 0xb7ef80f + -0x1b917 * -0xe2c - (-0x2f9a4da + 0x1c7003 * 0x53 + 0x11d20f6 * 0x1), '> hide-shots', [-0xbd9 + 0x1599 + -0x8c1, 0x3 * -0x9e5 + -0x16ac * 0x1 + 0x355a, 0x1 * -0x1525 + 0x2512 + -0xeee, -0x8 * 0x2f6 + -0x1774 + 0x3023], alg), ale += 0x1 * -0x14d5 + 0x1 * 0x122b + -0x2 * -0x15a;
            }
            break;
        case 0xb6b + 0x81 * -0x29 + 0x46 * 0x22:
            ali = UI.GetValue(['Rage', 'SUBTAB_MGR', 'Exploits', 'SHEET_MGR', 'Keys', 'Key assignment', 'Hide shots']) ? 0x13 * 0xee + 0x8c + -0x8ed * 0x2 : -0x7 * -0x57d + -0x4c6 + -0x2135 * 0x1;
            break;
    }
    alj = -0x744 + 0x1b * -0x134 + 0x1 * 0x2807;
    while (alj < -0x403 * -0x7 + -0x20ee + 0x565 * 0x1) switch (alj) {
        case 0x72a + 0x20fc + -0xad * 0x3b:
            alj = UI.GetValue(['Rage', 'General', 'General', 'Key assignment', 'Force safe point']) ? 0x1 * -0xcb6 + 0x3ef + -0x1 * -0x91d : -0xa74 + -0x2 * 0x2ce + 0x4 * 0x427;
            break;
        case 0x2600 + -0x13 * 0x1d3 + 0x1 * -0x301:
            alj = -0x39b * -0x5 + 0x1 * -0x1ea5 + 0x5 * 0x2a2; {
                RenderHooked.String(ald + (0x13 * 0xb42b1 + -0x1c846ee + 0x1e142b9 ^ -0x2c * -0xaba6 + 0x1c7db99 + -0x3 * 0x522467), alc + ale + (-0xf57b0c + 0x109bb53 + 0xa82107 - (-0xa4123f + -0x2b * 0x75bdd + 0xe3b45 * 0x2f)), (-0x27a2f * -0x1 + 0x1e635 + 0x6cd * -0x56) % (-0x1ea6 * -0x1 + -0xd6 * 0x22 + -0x7 * 0x51), '> safe-point', [(0x2a247 + 0xb22f * -0x1 + 0x276e) % (0x1524 + 0x44f + 0xb * -0x250), (0x4 * 0x2e37 + -0x31432 + -0x11cb7 * -0x4) % (0x11ca + -0x1b7 * 0x4 + -0xaeb), 0x1a0d58d * 0x8 + -0x863a52 * 0x1c + 0x90381a5 - (-0xa357e38 + 0x650615 + 0x112c4538), 0xae7 * -0x3 + 0x1ccd * -0x1 + 0x3e81], alg), RenderHooked.String(ald + (-0x174867 + 0x1ab63 + 0x3e4dad) % (-0x6ce + -0x1283 + 0x1954), alc + ale, (-0x394bc + -0x12be3 + -0xb29 * -0x9d) % (0x1ba + 0x1222 + -0x13d9), '> safe-point', [-0x1 * 0xd79 + -0x5 * -0x4b1 + -0x8fd, 0xa99 * -0x2 + -0xa16 + 0x1 * 0x2047, -0xc45 + 0x14ab + -0x767, 0x795 + -0xc * 0x10d + 0x606], alg), ale += -0x789 * -0x2 + -0xb * -0xb5 + 0x1 * -0x16cf;
            }
            break;
    }
    var alc, ald, ale, alf, alg, alh, ali, alj;
}
UI.AddHotkey(['Rage', 'Anti Aim', 'General', 'Key assignment'], 'legit desync', 'legit desync');

function dsal23422232432234223434232342342342323422342342344234332k312323() {
    var a = a;
    alk = Entity.IsAlive(Ragebot.GetTarget()), all = Entity.GetLocalPlayer(), alm = -0xbf5 * 0x3 + -0x1d2a + 0x3 * 0x15c5;
    while (alm < -0x1 * 0x3e9 + -0x229c + 0x26e6) switch (alm) {
        case -0x1c3e + 0x1 * 0x4c7 + 0x17bd:
            alm = UI.GetValue(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW', 'dynamic leg movement']) == (null == undefined) ? 0x2239 * 0x1 + 0x31 * 0x5 + -0xbaf * 0x3 : 0xe2 + 0x18 * -0xb1 + 0x1017;
            break;
        case 0xca4 + 0x327 + -0xfaa:
            alm = 0x1253 * -0x2 + 0x147a + 0x108d; {
                aln = 0x1 * -0x3a7 + 0x99f * -0x2 + -0x1 * -0x1729;
                while (aln < -0x135 + 0x195f + -0x12 * 0x152) switch (aln) {
                    case -0x16e3 + 0x165a + -0x1e * -0x7:
                        aln = -0xe8a + -0x26b4 + 0x35a4; {
                            tick12 = (0x1 * -0x4e2e + -0x98ae + 0x2fe62 * 0x1) % (0x1 * 0x1f37 + 0x1e4f + 0x3d83 * -0x1), tick22 = (0x18 * -0x39ca6c + 0x88 * -0x1082d7 + 0x12e77f03) % (0x2477 + 0x22a9 + -0x4719 * 0x1);
                        }
                        break;
                    case 0xcd * -0x28 + 0x1d84 + -0x2 * -0x164:
                        aln = side == (-0x7 * -0x149d839 + 0x2ff36c5 + 0x3 * -0x26f09e3) % (0x2590 + -0x2411 + -0x178) && alk == (-0x20ef * -0x1 + 0xf93 + 0x3 * -0x102b === '1') ? 0x10 * -0x21a + -0x135d * 0x2 + 0x48a3 * 0x1 : -0xae9 + 0x1ec1 + -0x5 * 0x3f2;
                        break;
                    case 0x16de + 0x9df + 0x7 * -0x4a9:
                        aln = -0x183 + 0xbfc + -0xa13; {
                            tick12 = (-0x36d8c1 + -0x1 * 0x4fb61a + 0x4a47 * 0x25c) % (-0xdd6 + 0x1a77 + -0x5f * 0x22), tick22 = 0x2dd5d * -0x6 + 0x1a0965 + 0x6940b - (-0x53441 + -0x158350 + 0x1 * 0x2a24cd);
                        }
                        break;
                }
                alo = -0x232d * 0x1 + 0x13eb + 0xf7e;
                while (alo < -0x7a7 + 0x6 * 0x1bf + -0x26b) switch (alo) {
                    case 0x236b + 0x1 * -0x15c7 + -0xd47:
                        alo = 0x25f6 + 0x1 * 0x14a2 + 0x4 * -0xe8c; {
                            flip2 = null == undefined, tickcount2 = (0x24a3d + 0x2523 + -0x57da) % (0x1671 + 0x20a1 + 0xb03 * -0x5);
                        }
                        break;
                    case 0x1885 * 0x1 + -0xce3 * 0x2 + -0x1 * -0x17d:
                        alo = tickcount2 >= tick12 && !flip2 ? -0x1 * -0x1dea + 0x9a * -0x2 + -0x1c59 : 0x439 * 0x3 + 0xf8 * -0x25 + 0x1795 * 0x1;
                        break;
                }
                alp = 0x10ef + -0xf75 + -0x15e;
                while (alp < 0x3c4 * 0x6 + -0x2 * 0x503 + -0xc29) switch (alp) {
                    case 0x16b1 * 0x1 + -0x22c + -0x1469:
                        alp = tickcount2 >= tick22 && flip2 ? -0xcf4 + 0x201e + -0x130c : -0x17fd + -0x1 * 0x142b + 0xedb * 0x3;
                        break;
                    case -0x192a * 0x1 + -0x9f * 0x3d + 0x9d * 0x67:
                        alp = 0xa03 + -0x3 * -0x39 + -0xa45; {
                            flip2 = ![], tickcount2 = (-0x1 * 0x2da67 + 0xfe * -0x211 + 0x6fecb) % (-0x14d8 + -0x1a98 + 0x2f73);
                        }
                        break;
                }
                alq = 0x103f + -0x72b + 0x8c9 * -0x1;
                while (alq < -0x1 * 0xbff + 0xbb * -0xd + 0x15e0) switch (alq) {
                    case -0x1253 * 0x1 + 0x40c * 0x5 + -0x19e:
                        alq = side == -0x3760dec + 0xcdd5 * -0x5b2 + -0x8c153a * -0x15 - (-0x453152f + -0x493e8ab * 0x1 + -0x17 * -0x897ee5) && alk == ![] ? 0x1 * 0x1e35 + -0x1c98 + 0x1 * -0x176 : -0x1 * -0x1d86 + -0x97 * -0x1 + 0x5 * -0x5ff;
                        break;
                    case 0x1c1e + -0x7a1 + 0x1456 * -0x1:
                        alq = -0x235 + 0x1af3 + 0x1 * -0x185c; {
                            UI.SetValue(['Misc.', 'Movement', 'Leg movement'], !flip2 ? -0x325 * -0x3869 + -0x1202a69 + -0x170332 * -0xd - (-0x137 * 0x5e75 + 0x13c9b3 + 0x209d7 * 0x8b) : -0x25ebfb * -0x7 + -0x3a5566 + -0x1 * -0x1fd077 ^ -0x1 * -0x109a191 + -0x13200f3 + 0x1174e4e), tickcount2++;
                        }
                        break;
                    case -0x5dc + 0x14 * -0x5 + 0x662:
                        alq = 0x1d5 * -0x2 + 0x216 * 0x6 + 0x1 * -0x878, alr = -0x2f * 0x52 + -0x1 * -0x7b + 0xecd * 0x1;
                        while (alr < 0x26d5 + -0x1fbf + 0x68c * -0x1) switch (alr) {
                            case -0x17af + 0x161 * -0x1 + 0x194a:
                                alr = alk == ([0x493 * -0x2 + 0x932 + 0xc * -0x1] == '') && side == 0x301 * 0x782 + -0x11305 * -0xbf + 0x275cef * -0x1 - (0x11bd87e + -0x20ef * -0x517 + -0x10717aa) | side == (0x16e9e15 + -0x352b1e + -0x4a8409 ^ -0x4a040d * 0x5 + 0x101d * -0x55 + -0x34d93 * -0xba) ? 0x1019 * -0x1 + -0x235f + 0x19ca * 0x2 : 0x1655 + 0x1ee * -0x13 + 0xe9e;
                                break;
                            case 0xd * 0x3a + 0x1 * -0x210e + 0x1e65:
                                alr = 0x1ea * -0xd + -0x1e55 + 0x7 * 0x7f7, als = -0x73 * -0x2 + -0xdd3 + -0x2 * -0x693;
                                while (als < 0xe70 * -0x2 + -0x2 * -0x7db + 0xd82) switch (als) {
                                    case -0x1 * 0x18d5 + -0x15ed + 0x2f03:
                                        als = -0x24ec * -0x1 + 0x1a5f + -0x3ef3; {
                                            UI.SetValue(['Misc.', 'Movement', 'Leg movement'], (0x12d * -0x43 + 0x9e2d * 0x3 + 0x8bc6) % (-0x35f * 0x1 + 0x7 * -0xf3 + -0xa07 * -0x1));
                                        }
                                        break;
                                    case -0x12f * 0xf + -0x1 * 0x38c + 0x1f7 * 0xb:
                                        als = -0x2234 + 0x1301 * -0x1 + 0x358d; {
                                            UI.SetValue(['Misc.', 'Movement', 'Leg movement'], (-0x3c297e + 0x3 * 0x160bd + 0x60b7f0) % (0x37 * 0x37 + 0x19a3 * 0x1 + 0x27f * -0xf));
                                        }
                                        break;
                                    case 0x1411 * 0x1 + -0x1 * 0x1832 + 0x1 * 0x45a:
                                        als = alk == (NaN !== NaN) ? 0x20d2 + 0x900 + -0x1e3 * 0x16 : -0x728 * -0x4 + 0x1a10 + 0x1225 * -0x3;
                                        break;
                                }
                                break;
                            case 0xf * 0x2f + 0x1064 * 0x1 + 0x1 * -0x1309:
                                alr = -0x2 * -0xb7 + -0xe * -0x291 + -0x24d2; {
                                    UI.SetValue(['Misc.', 'Movement', 'Leg movement'], !flip2 ? (-0x3b0df * 0x2 + -0x1 * -0xb643b + -0x92b8b * -0x4) % (-0x384 + -0x131f + -0xd * -0x1be) : 0xac * -0x1f4f0 + 0xf51e76 + 0x7 * 0x2f3288 ^ 0x172d6ab + -0x21e8 * 0xa87 + -0x190111 * -0x9), tickcount2++;
                                }
                                break;
                        }
                        break;
                }
            }
            break;
    }
    var alk, all, alm, aln, alo, alp, alq, alr, als;
}
UI.AddHotkey(['Rage', 'Anti Aim', 'General', 'Key assignment'], 'freestanding', 'freestanding');

function dsal234223423423422342342344234332k312323(alt, alu) {
    var a = a;
    alv = dsal234223423423423423422342342344234332k312323(alt), alw = dsal234223423423423423422342342344234332k312323(alu), alx = Math.sin(alv), aly = Math.cos(alv), alz = Math.sin(alw), ama = Math.cos(alw);
    return [aly * ama, aly * alz, -alx];
    var alv, alw, alx, aly, alz, ama;
}
UI.AddHotkey(['Rage', 'General', 'General', 'Key assignment'], 'dmg override', 'dmg'), predicted_time = (0x154d6 + 0xf731 * -0x1 + 0x1b9e1) % (-0x6 * -0x61 + 0x2 * -0xd64 + 0x1885);

function auto_buy_purchase2() {
    var a = a;
    amb = 0x1 * -0x173b + 0x16cb * 0x1 + -0x1 * -0xc2;
    while (amb < 0xff3 + -0x2 * -0x84a + -0x2028) switch (amb) {
        case -0x291 + 0x3 * 0xd5 + -0x1 * -0x36:
            amb = 0x2 * 0x805 + -0x45f + 0x2 * -0x5a6; {
                CheatHooked.ExecuteCommand('buy awp'), CheatHooked.ExecuteCommand('buy awp');
            }
            break;
        case 0x1b * 0xeb + -0x1 * 0x1196 + -0x6e1:
            amb = UI.GetValue(['Config', 'JAGO-YAW', 'JAGO-YAW', 'buy awp']) == (NaN !== NaN) ? 0x34 * -0xa6 + -0x23eb + 0x1 * 0x45c7 : -0x18 * 0xc5 + 0x1 * -0xf59 + -0x1 * -0x2230;
            break;
    }
    var amb;
}
buy = ![];

function dsal232323422232432323232322223342323223232223233434232342342342323422342342344234332k312323() {
    var a = a;
    amc = dsal23422243234232342342342323422342342344234332k312323(Math.abs(Math.round(Local.GetRealYaw() - Local.GetFakeYaw())), 0x4d30 * -0x1561 + 0x1 * -0xd3c3a73 + -0x114e378 * -0x19 - (0xeb629ba + 0x62b7236 + -0x1 * 0xd85cedb), -0x2b * 0x3e + 0x14c8 + -0xa24), amd = Entity.GetLocalPlayer(), ame = Entity.IsAlive(Ragebot.GetTarget()), amf = left_distance = dsalkj2k3(amd, [(-0xd65 * 0x18 + -0x39781 + 0x6f07f) % (-0x301 * -0x2 + -0x203 * 0xb + 0x1022), Local.GetViewAngles()[0x1 * -0xbb779d + 0x7fcc4b + -0x12 * -0xdc7d0 - (-0x1 * 0xd514ef + 0x9f1a8e + -0x36 * -0x47cf5)] - (-0xc7 * -0x2c + 0x1028 + -0x3245)]) - (right_distance = dsalkj2k3(amd, [-0x54b * 0x2342c + 0x40137a7 + 0xf04ba52 - (0x125f * -0xa511 + 0x1a60fb * 0x81 + -0x5e961e9 * -0x1), Local.GetViewAngles()[-0x1 * -0xb65c61 + -0x9cb0d9 + 0xa2b5c6 - (-0x4896e * 0x43 + -0x1837 * -0x66a + 0x1510851)] + (0x117 * 0x13 + -0xf24 + -0x57a)])), amg = dsalkj2k3(amd, [(0x23d5f + 0x1426 * -0x2c + 0x350af) % (-0xa * -0x30d + 0x8b * -0x2b + 0x393 * -0x2), Local.GetViewAngles()[(0x21d0a1 + -0x5c * -0x4bb5 + -0x1555 * 0xf4) % (0x18f8 + 0x26d6 + -0x1 * 0x3fcb)]]), amh = UI.GetValue(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW', 'jag0-walk switch']), ami = dsal2342234232342342342323422342342344234332k312323((-0x3d9e8 + -0xb5 * 0x581 + 0x9d5a3) % (-0x204b + -0x22 * 0xee + 0x2 * 0x1ff5), (-0x13f3cd8c * -0x1 + -0x35 * -0xc5b194 + 0x68ec2a2 * -0x3) % (-0x1a33 + -0x20c0 + 0x3afa)), amj = dsal2342234232342342342323422342342344234332k312323(-amh, amh), amc = dsal23422344234332k312323(amd), amk = (-0x27229f * -0x35 + -0x3b9cb698 + 0x53c79bb6) % (-0x65d + -0x157e + 0x1be4);
    while (amk < -0x19d1 + 0x9b8 + 0x10ad) switch (amk) {
        case -0x1 * 0x1d3b + 0xab1 + 0x3bb * 0x5:
            amk = -0x5a5 * 0x3 + 0xa35 + 0x74e; {
                UI.SetValue(['Config', 'Cheat', 'General', 'Restrictions'], 0x4852 * -0x2630 + -0x26d7ea + -0x5c1 * -0x32e1f - (-0x68037ca + 0x6 * -0x1676e3c + 0x2b8bed * 0x83)), UI.SetValue(['Rage', 'Anti Aim', 'Directions', 'At targets'], -0x11e78c4 + 0x99815a + 0x2 * 0xa0ac5c - (0xdd646a + 0xcc6d29 + -0x1 * 0xed7046)), UI.SetValue(['Rage', 'Anti Aim', 'Directions', 'Yaw offset'], -0x1 * -0x59ea1eb + 0xc0e69ed * 0x1 + -0x17 * 0x72d635 - (0x1 * -0x48e1d39 + 0x13e73da + 0xaab7674)), UI.SetValue(['Rage', 'Anti Aim', 'Directions', 'Jitter offset'], (-0x52 * -0xc88 + 0x28047 + -0x46c51) % (0xf53 + -0x14a6 + 0x556)), UI.SetValue(['Rage', 'Anti Aim', 'General', 'Pitch mode'], 0x717566 + -0x1 * 0x1604672 + 0x1ab325a - (0xc2bf07 + 0x1c78d * 0x1a + -0x17 * 0x249d4)), aml = 0x417 * -0x6 + -0x2 * 0x113e + 0x3b30;
                while (aml < 0x1 * 0x1c6f + 0x1db6 + -0x3992) switch (aml) {
                    case 0x10b0 + 0x29 * 0xe9 + -0x35e9:
                        aml = -0x628 + 0x46 * 0x8b + -0x1f47; {
                            UI.SetValue(['Rage', 'Anti Aim', 'Directions', 'Auto direction'], (-0x2 * -0x1d56af + -0x1 * -0x4d70fe + -0x7 * 0xda1f5) % (0x75f + 0x1 * 0x1943 + 0x209f * -0x1));
                        }
                        break;
                    case -0x1430 * 0x1 + -0x1 * 0x4c1 + 0x193d:
                        aml = 0xba8 + 0x2 * 0x1226 + 0x3 * -0xfcb; {
                            UI.SetValue(['Rage', 'Anti Aim', 'Directions', 'Auto direction'], -0xa6bc346 + -0x893d679 + 0x1a5b66d4 - (-0xd7159ba * 0x1 + -0x67d49c7 + 0x1b4a7096));
                        }
                        break;
                    case 0x1 * 0x85f + -0x28b + -0x5aa:
                        aml = UI.GetValue(['Rage', 'Anti Aim', 'General', 'Key assignment', 'freestanding']) == (NaN !== NaN) && jagowalking == (null === undefined) && dsal24234332k312323(amd) == ![] && dsal22344234332k312323(amd) == ![] || amg <= -0x3d5 * -0x5 + -0x1c7 * 0xd + -0x7 * -0x96 && jagowalking == (NaN === NaN) && dsal24234332k312323(amd) == ([-0x18dd + -0x2 * -0xb33 + 0x277] == '') && dsal22344234332k312323(amd) == (NaN === NaN) && UI.GetValue(['Config', 'JAGO-YAW', 'JAGO-YAW', 'freestanding on edge']) == ([null] == '') ? 0x1942 + 0xb1c + -0x2446 : 0x190 + -0x64 * 0x59 + 0x2180;
                        break;
                }
            }
            break;
        case -0x1dbd + -0x1d4d + 0x3b4d:
            amk = -0x4 * 0x5ff + 0x24b + 0x1645; {
                amm = -0x3 * 0x848 + -0x1029 + 0x1 * 0x295c;
                while (amm < -0xb3c + 0xbdf + -0x1a * -0x1) switch (amm) {
                    case -0x1f8b + -0x2700 + 0x46a2:
                        amm = 0x11c * 0xf + 0x15 * -0xc7 + 0x6c, UI.SetValue(['Rage', 'Anti Aim', 'Directions', 'At targets'], (0x3c40b + 0xc0e * 0x4f + 0x487 * -0x131) % (-0x199b + 0x1 * -0xdaf + 0x274d));
                        break;
                    case 0x1663 + 0x1 * -0x33b + -0x12d2:
                        amm = -0xdbe + 0x50d * 0x1 + 0x96e, UI.SetValue(['Rage', 'Anti Aim', 'Directions', 'At targets'], 0xec83ba + 0xcd54d * -0x4 + 0x26 * 0x158c - (0x95 * 0xf8c7 + 0x6 * 0x11d05e + 0x5 * -0xca8f2));
                        break;
                    case 0x1b97 + -0x13f1 + -0x74b * 0x1:
                        amm = UI.GetValue(['Config', 'JAGO-YAW', 'JAGO-YAW', 'legit desync at-targets']) == (NaN !== NaN) ? -0x9f * 0x1b + 0xc67 + 0x4b4 : -0x2532 * -0x1 + -0x1b86 + -0xb * 0xdf;
                        break;
                }
                UI.SetValue(['Rage', 'Anti Aim', 'Directions', 'Auto direction'], (0x3ec3 + -0xcf7 * -0x19 + -0x18c6 * -0x6) % (0x52b + 0xf07 + 0x142f * -0x1)), UI.SetValue(['Config', 'Cheat', 'General', 'Restrictions'], -0x7f95d27 * 0x1 + 0xe74bc26 + -0x7f6 * -0x1c31 - (0x63c49eb + -0xb5 * 0x932d6 + -0xd * -0x963058)), UI.SetValue(['Rage', 'Anti Aim', 'Directions', 'Yaw offset'], 0x218d + 0x1805 + -0x3a * 0xfb), UI.SetValue(['Rage', 'Anti Aim', 'Directions', 'Jitter offset'], (-0x15 * -0xd4d + -0x24e72 + 0x34ea7) % (0x49 * 0x61 + -0x213d * -0x1 + 0x6d * -0x8f)), amn = 0x1840 + -0xc7 * -0x2e + -0x3bd2;
                while (amn < 0x815 + 0x4e5 * 0x2 + -0x1160) switch (amn) {
                    case 0x1 * -0x1933 + -0x1741 * -0x1 + 0x237:
                        amn = 0xb8f * -0x2 + 0x1179 + 0x6 * 0x106, UI.SetValue(['Rage', 'Anti Aim', 'General', 'Pitch mode'], -0x1183970 + 0x112831d + -0x7577 * -0x1a7 - (-0x11eda58 + -0x44427 * 0x51 + -0xaa * -0x4d406));
                        break;
                    case -0x1d7d * -0x1 + -0x24 * 0x3e + -0x14a3:
                        amn = -0x1 * 0x1ae9 + 0x560 + 0x4 * 0x582, UI.SetValue(['Rage', 'Anti Aim', 'General', 'Pitch mode'], -0x810f765 + 0x768d9f9 + 0x803ea81 * 0x1 - (0x11 * 0x8ecc49 + -0xcec * -0x2a32 + -0x44101dc));
                        break;
                    case 0x9fe + -0xd18 + 0x34a:
                        amn = UI.GetValue(['Config', 'JAGO-YAW', 'JAGO-YAW', 'freestanding on edge']) == !![] && amg <= 0x1a02 * -0x1 + -0x1d78 + 0x37a2 ? -0x8e * -0x3 + -0x16d6 + 0x1 * 0x1571 : -0x12a9 + -0x2ad * -0xb + 0x4 * -0x2a9;
                        break;
                }
            }
            break;
        case (0x1c398971 + 0x1 * -0x2aa07d06 + 0x2eac039e) % (-0x867 + -0x2209 * -0x1 + -0x1999):
            amk = UI.GetValue(['Rage', 'Anti Aim', 'General', 'Key assignment', 'legit desync']) == (null == undefined) ? 0x1fc9 + -0xbe5 + 0x68b * -0x3 : 0xc7 * -0x1a + -0x21a1 + 0x35f4;
            break;
    }
    amo = -0x110c + -0x1155 * -0x1 + 0x1 * -0x30;
    while (amo < -0x59 * 0x7 + 0x226c + -0x1f5e) switch (amo) {
        case -0xf94 + 0x1b92 + -0xbdf:
            amo = -0x149f + 0x8aa * 0x2 + 0x3ea; {
                jagowalking = NaN === NaN, amp = 0x3ab + -0x17f * -0x1 + -0x4ee;
                while (amp < -0x1f * -0xb4 + -0x13b7 + -0x187 * 0x1) switch (amp) {
                    case 0x2c7 + 0x7c9 + -0x2 * 0x52a:
                        amp = ame != !![] ? -0x1ca4 + 0x1495 + 0x1 * 0x86b : -0x11a6 * -0x1 + 0xcd4 * -0x3 + -0x2 * -0xa81;
                        break;
                    case -0x1205 + 0x1 * -0xf4d + 0x217e:
                        amp = 0xf1 * -0x1f + 0x1706 + 0x6b7; {
                            amq = 0xa3 * -0x28 + -0x2056 * -0x1 + 0x1 * -0x6bb;
                            while (amq < -0x1258 + -0xa * -0xb3 + 0x17 * 0x83) switch (amq) {
                                case 0xa * 0x2bd + -0x762 * -0x2 + -0x2a03:
                                    amq = UI.GetValue(['Rage', 'Anti Aim', 'General', 'Key assignment', 'legit desync']) == (NaN !== NaN) ? 0x1d6d + 0x2644 + -0x439b : -0x4f0429e + -0x39a3e54 + 0xb8bbc0e - (0x5c0757 + -0x3303da6 + 0xdbe * 0x6cad);
                                    break;
                                case -0x60d8d40 + -0xa * 0xac2da7 + 0x29d3a * 0x6d9 ^ 0x8d966c6 + -0x51b12cb + 0x1 * 0x160f866:
                                    amq = -0x5ca * 0x1 + -0x77c * 0x3 + 0x1ca9; {
                                        AntiAim.SetOverride((0x1 * 0x1f7fab + -0x22a7 * 0x43 + -0x1a8f9 * -0xb) % (0x18df + 0x12d5 + 0x1 * -0x2bb1)), AntiAim.SetFakeOffset((-0xf * -0x15da + -0x15044 + 0x22004) % (-0x2b * -0x3b + 0xd * -0x97 + 0x1 * -0x23b)), amr = -0xc5e * -0x3 + -0x1 * 0xc73 + 0x187f * -0x1;
                                        while (amr < 0x1d5d * 0x1 + 0xead + -0x2b75) switch (amr) {
                                            case 0x1fc8 + -0x14e2 * -0x1 + -0x348b:
                                                amr = -0x1 * -0x1be1 + -0x2160 + -0x185 * -0x4, AntiAim.SetRealOffset(-amc);
                                                break;
                                            case -0x24e1 + 0xcb9 * 0x3 + -0x4 * 0x3e:
                                                amr = 0x4cb * 0x1 + -0x2012 + 0x1bdc, ams = -0x38 * -0xac + 0x1 * -0x981 + -0x1bff * 0x1;
                                                while (ams < -0xa5b + -0x13 * 0x16d + 0x2621) switch (ams) {
                                                    case -0x17 * 0x198 + -0xb62 + 0x302a:
                                                        ams = ami == (0x2ed * 0x1202 + 0x1faf * -0xea + 0x10f6c5) % (0x697 + -0x107 * 0x17 + 0x110d) ? -0x1056 + 0x29 * 0x94 + 0x3 * -0x255 : -0x64e + 0x7 * 0x248 + -0x8fb;
                                                        break;
                                                    case -0x1c18 + -0x719 * -0x1 + 0x155e:
                                                        ams = -0x2ca + 0x10d * 0x15 + -0x1298, AntiAim.SetRealOffset(amc);
                                                        break;
                                                }
                                                break;
                                            case 0x65 * 0x56 + 0x18e * -0x11 + -0x758:
                                                amr = ami == 0x19bbb * 0x2a3 + 0x8c05d58 + -0x1c1a * 0x3352 - (-0x1 * -0xc0c6f04 + -0x8f22fde + 0x4418def) ? 0x243e * 0x1 + -0x955 + -0x1aca : -0x1ebb * -0x1 + 0x8b0 + -0x2719;
                                                break;
                                        }
                                        AntiAim.SetLBYOffset((-0x30bb8 + 0x1398f + 0x3 * 0x14de5) % (0x58a * -0x4 + -0x1a35 + 0x90 * 0x56)), side = (-0x6765717 + 0x42ab13f + 0x647 * 0x11de5) % (-0x9a + -0x1d9f + 0x1e40);
                                    }
                                    break;
                                case 0x203 * 0xb + -0x437 * -0x3 + -0x22b0:
                                    amq = -0x1 * -0x3b0 + -0x1b * -0x16f + -0x29fa; {
                                        AntiAim.SetOverride(0xa0e849 + -0x161849c + 0x1f * 0xc4a3f - (-0x126 * 0x9515 + -0xfa67d0 + 0x13ad65 * 0x1f)), AntiAim.SetFakeOffset((-0x42591 + -0x3dd51 + -0x14 * -0x8152) % (-0x10 * -0x192 + 0xc8b + 0x1e2 * -0x14)), amt = (-0x23590 + 0xbf6 * -0x2b + 0x4 * 0x193da) % (0xb * 0x1f1 + -0x21 * -0xd + -0x1705 * 0x1);
                                        while (amt < 0x88 + -0x1066 + -0x3 * -0x565) switch (amt) {
                                            case -0x17f8 + 0x1086 + 0x77e:
                                                amt = -0x1d35 * -0x1 + -0x3ac + -0x1938, amu = 0x972 + 0x1e22 + -0x1 * 0x2781;
                                                while (amu < -0x561 * 0x6 + -0x305 + 0x23b9) switch (amu) {
                                                    case 0xc * 0x238 + 0x4ff * -0x1 + 0x1 * -0x158e:
                                                        amu = ami == -0x17f3e * 0x79 + -0x42d9 * 0x4d + -0x81e04b * -0x3 - (0xc17d4e + 0xc20b20 + -0xc72721) ? -0x245c + -0x21bc * -0x1 + 0x2ea : -0x2 * 0x9d4 + -0x2690 + 0x3aa6;
                                                        break;
                                                    case 0x1725 + 0xb3 * -0x20 + -0x7b:
                                                        amu = 0x1e95 * 0x1 + 0x1 * 0xc9a + 0x1 * -0x2ac1, AntiAim.SetRealOffset(-(-0x293 * 0x5 + 0x23ab + -0x1690));
                                                        break;
                                                }
                                                break;
                                            case (-0x13632 + -0x3ac52 + 0x6fa0a) % (-0x33 * -0x31 + -0xad * -0x1d + -0x2ab * 0xb):
                                                amt = ami == (-0x1 * 0x16876 + -0x2bead * -0x1 + 0x29 * 0x4b7) % (-0x1fd5 + -0x36d * -0x1 + 0x1c6b) ? -0x1bc4 + 0x3 * 0x243 + 0x1519 : -0x2 * -0x9b1 + 0x1d * 0x8f + -0x2389;
                                                break;
                                            case -0x51 + 0x23f0 + 0x3d * -0x95:
                                                amt = 0xc0 * -0x1d + 0x4 * -0x7f7 + 0x35ed, AntiAim.SetRealOffset(0x1339 + -0xfec + -0x311);
                                                break;
                                        }
                                        AntiAim.SetLBYOffset(0xe882699 + 0x5029ea * -0x1b + 0x148122a - (0x43c9811 + -0x84a3024 + 0xb696528)), side = (0x800446b + 0xf2bcb * -0x26 + -0x108c19e) % (-0x153e + -0x1c87 + 0x4 * 0xc73);
                                    }
                                    break;
                            }
                        }
                        break;
                    case 0x1 * -0xe5d + 0x152c + 0x1 * -0x673:
                        amp = -0x2598 + -0xac * 0xb + 0xae * 0x43; {
                            amv = -0x31 * 0x67 + -0x1abf + 0x2eb0;
                            while (amv < 0x5f9 + 0xa62 + -0x155 * 0xc) switch (amv) {
                                case 0x1 * 0x19be + 0x11 * -0xa + -0x18c2:
                                    amv = 0x7c3 + -0x4e * 0x65 + -0x1 * -0x1762; {
                                        amw = 0x2 * -0x7dc + 0x4 * -0x89 + -0x11fb * -0x1;
                                        while (amw < 0x3a9 * 0x3 + 0x17bf * -0x1 + 0x6b6 * 0x2) switch (amw) {
                                            case -0x248d + 0x2129 + 0x383:
                                                amw = amf >= -0x12aff1b + 0xaadeda + 0x9 * 0x232ad7 - (-0x154d * -0x6fd + -0x46490 * 0x1f + 0x57d9d2 * 0x2) ? 0x15ef * 0x1 + 0x1b56 * -0x1 + 0x4b * 0x13 : -0x167d + 0x835 + 0x17 * 0xa3;
                                                break;
                                            case -0x1 * -0x15a3 + -0x1 * 0xf83 + -0x5c3:
                                                amw = -0x1 * 0x1699 + 0x3e1 * 0x5 + 0x3dc, amx = (-0xa70827 * 0x1 + 0x656d289 + -0x9f2413) % (-0x99 * -0x17 + 0x12c9 + -0x2082);
                                                while (amx < 0x17 * 0x32 + -0x467 + 0x46) switch (amx) {
                                                    case 0xe38 + -0x1 * -0x1912 + 0x1 * -0x26f9:
                                                        amx = -0xcee + -0x19f2 + 0x7d9 * 0x5; {
                                                            AntiAim.SetOverride(-0xfdf4f6 + -0x800d9d * 0x1 + 0x23a63e1 - (0x473d65 + 0x10d1055 + 0x97ec6d * -0x1)), amy = -0x1d * 0xbd + 0x116f + 0x422;
                                                            while (amy < -0x129e + 0x1 * -0x1beb + 0x2f23) switch (amy) {
                                                                case -0x6e + 0x23 * -0x10a + 0x1ae * 0x16:
                                                                    amy = UI.GetValue(['Rage', 'Anti Aim', 'General', 'Key assignment', 'legit desync']) == (null == undefined) ? 0x18ad + 0x1d * -0x25 + 0x412 * -0x5 : -0xeb9 * -0x2 + -0x13e0 + -0x93c;
                                                                    break;
                                                                case -0x18ea + 0x2 * -0x12fd + 0x1f83 * 0x2:
                                                                    amy = 0xc7c + 0x566 + -0x8 * 0x229; {
                                                                        AntiAim.SetFakeOffset((0x172ce + 0x6085 * -0xb + 0x4ca6f) % (0x34b * -0x3 + -0xd98 + 0x24 * 0xa7)), amz = -0x896 + 0x17 + -0x2e7 * -0x3;
                                                                        while (amz < 0x1259 * -0x1 + 0x1 * -0x25c7 + 0x3888) switch (amz) {
                                                                            case (-0x6e04 + -0x1 * 0x2d466 + 0x559f0) % (-0x72d + -0x18b2 + 0x4d * 0x6a):
                                                                                amz = 0x1 * 0x9e3 + -0x2364 + 0x3 * 0x8a3, AntiAim.SetRealOffset(0x7 * 0x33 + -0x1542 * -0x1 + -0x166b);
                                                                                break;
                                                                            case 0x1ebe + 0x1499 + 0x3321 * -0x1:
                                                                                amz = ami == 0x3d * -0xc75fb + -0x352 * 0x1627d + -0x2 * -0x7767677 - (0x9304116 + 0x29 * 0x4639a9 + -0xd13b012) ? 0x1eb0aaa * -0x3 + -0xbb0545d + 0x35cea8 * 0x76 - (0x38175ec + 0xc1e2b17 + 0x421e9f7 * -0x2) : 0x235 + -0x1cc7 * -0x1 + -0x37 * 0x8f;
                                                                                break;
                                                                            case 0xb23 * 0x1 + 0x11a7 * 0x1 + -0x1c87:
                                                                                amz = 0x1777 * 0x1 + 0x32e * -0x8 + 0x261, ana = 0x1e4e + 0x12 * 0x197 + -0x3ae0;
                                                                                while (ana < -0xf7e + 0x1d * 0x139 + -0x137c) switch (ana) {
                                                                                    case -0x1a3c + 0x1 * 0x16e5 + 0x3a9 * 0x1:
                                                                                        ana = -0x1 * -0x1c78 + -0x1 * -0x1fb2 + -0x3baf, AntiAim.SetRealOffset(0x367 * 0xa + 0x1ccc * -0x1 + -0x1 * 0x4fe);
                                                                                        break;
                                                                                    case 0x8 * -0x348 + 0x2700 + -0xcb4 * 0x1:
                                                                                        ana = ami == (-0x3a4c73 + 0x23c88d + 0x3f348f) % (-0xc45 * -0x2 + -0x1463 + -0x14 * 0x35) ? -0x5e0 + 0x1d2c * 0x1 + -0x16fa : 0x121e * 0x2 + 0x98c * -0x3 + -0x71d;
                                                                                        break;
                                                                                }
                                                                                break;
                                                                        }
                                                                    }
                                                                    break;
                                                                case 0x595 + -0x251 + -0x2ee:
                                                                    amy = -0x4c + 0x1 * 0x18f9 + -0x1813; {
                                                                        AntiAim.SetFakeOffset(amc / (-0x9f82c30 + 0x804c045 * -0x1 + 0x10a763 * 0x16f - (-0x3681f92 + 0xa8106cb + -0x135dcc5))), anb = 0x1 * -0x5fa3ab + 0x44d9c17 * 0x1 + -0x10 * 0xecbd5 - (0x11261bc * -0x5 + 0x1838b80 + -0xcd1 * -0x88d3);
                                                                        while (anb < -0xf72 + 0x1dc + 0x5 * 0x2d5) switch (anb) {
                                                                            case -0x8 * -0x54357 + 0x2692 * 0x1924 + -0xf28e24 - (-0xe57a27 + 0x5a11a70 + 0x2 * -0xdd3299):
                                                                                anb = ami == 0x2 * -0x5e002d + 0x6e84b66 + 0x12f8209 - (-0xfe5e05 * -0xa + -0xae64 * 0x3b + -0x26bae11) ? -0x1cd * 0xa021 + -0x311ed0 + 0xaade1a * 0xd - (-0x3ff27ed * -0x2 + -0x2d96b4e + 0x236e889) : -0x4 * -0x278 + -0x1 * -0x1cb + -0x2 * 0x5b4;
                                                                                break;
                                                                            case 0xe87126e + 0x5272441 + 0x2 * -0x62934cd - (0x9ec12a7 + 0x635f719 + 0xeb93 * -0x989):
                                                                                anb = -0x2135 * -0x1 + -0xc4c + -0x1456, AntiAim.SetRealOffset(-amc);
                                                                                break;
                                                                            case -0x8 * 0x1a6 + 0x1c7b + -0xf08:
                                                                                anb = 0x1f88 + 0x1338 + -0x322d, anc = -0x1215 + 0x1 * -0x28d + 0x14b5;
                                                                                while (anc < 0x2054 + 0x1f83 + -0x3f3f) switch (anc) {
                                                                                    case -0xc295e4 + -0xac94b + 0x3 * 0x78f9b1 - (0x1 * 0x1236adb + 0x4d1bc5 + -0x7b97 * 0x1b5):
                                                                                        anc = -0x14 * -0x174 + 0x125 * 0x17 + 0x437 * -0xd, AntiAim.SetRealOffset(-amc / (-0x629b41 + 0x4b089 * -0x3d + 0x26f9ad4 ^ 0x1627ba5 + -0x158eef9 + 0xe56240));
                                                                                        break;
                                                                                    case 0x6b6 * -0x3 + -0x1e9 + 0xb0f * 0x2:
                                                                                        anc = ami == (-0x306 * 0x833 + 0x2eb * 0x15f6 + 0x16609) % (-0x2685 + 0x37 * 0x9d + -0x4cd * -0x1) ? -0x46ce3d * 0x1 + -0xedfc94 + 0x3f11 * 0x765 - (-0xf99253 + -0xe0116a + 0x277319a) : 0x4ac + 0x8 * -0x331 + 0x1574;
                                                                                        break;
                                                                                }
                                                                                break;
                                                                        }
                                                                    }
                                                                    break;
                                                            }
                                                            AntiAim.SetLBYOffset((0x2d1a4 + -0x1f + -0xb9ff) % (0x1ecc * 0x1 + 0x5a * -0x2b + -0xfab)), side = -0x143a * 0xc69 + -0xfaef13 * 0x1 + -0x7 * -0x69d71d ^ 0x58606f * -0x3 + -0x199700e + 0x3918047;
                                                        }
                                                        break;
                                                    case -0x841a * -0x44b + -0x36f4d1 * -0x7 + -0xb69239 - (-0x48d * 0x83b + -0x37bef1f + 0xcbd * 0x8559):
                                                        amx = amf <= -(0x13866be + 0x1 * -0x1256053 + 0xa95ae3 - (-0x169c23a + -0x14fd52d + 0x1 * 0x375f8b4)) ? -0x1ab * -0xb + -0x62 * 0x52 + -0xf * -0xe4 : -0x522 + -0xb2f + 0x23 * 0x7a;
                                                        break;
                                                }
                                                break;
                                            case 0x13 * 0x1d1 + -0x45c + -0x9ff * 0x3:
                                                amw = 0x92c + -0x133b * -0x1 + -0x1bbf; {
                                                    AntiAim.SetOverride(-0x1 * 0x78335f + -0x2 * 0x5a253 + -0x7cd1b * -0x29 - (0x1 * -0x2d98db + -0x3b53a * -0x35 + 0x3 * 0xc7c62)), and = (0x63 * -0x4cd0d + 0x4c08f91 * -0x1 + 0x96db387) % (0x21c7 + 0x4 * -0x61d + 0x94b * -0x1);
                                                    while (and < 0x23bf * -0x1 + -0x1fce + 0x398 * 0x13) switch (and) {
                                                        case 0x1e360d * 0xa + 0x2678f98 + -0x2024cf3 ^ -0x8266d9 + 0x2fa50e9 + -0xe48af0:
                                                            and = UI.GetValue(['Rage', 'Anti Aim', 'General', 'Key assignment', 'legit desync']) == ([null] == '') ? 0x1112 + 0x1bb3 + -0x21 * 0x15b : -0x64 * 0x1b + -0x4 * -0x514 + -0x96a;
                                                            break;
                                                        case -0x8cb + 0x702 + -0x1 * -0x1d3:
                                                            and = -0x14c7 + -0x15b * -0x7 + 0xc05; {
                                                                AntiAim.SetFakeOffset((0x37118 + 0x1d401 + -0x5 * 0xa2b7) % (-0x35e * -0x3 + 0x1baa + -0x25c1)), ane = -0x257f + -0x1183 + -0x2e6 * -0x13;
                                                                while (ane < 0x24 * -0xb5 + 0x199 * 0xd + 0x541) switch (ane) {
                                                                    case -0x1c28 + -0x26ee + 0x62 * 0xb0:
                                                                        ane = 0x17 * 0x93 + -0x2109 * -0x1 + 0x9e * -0x4a, anf = -0xa18 + -0xba7 + -0x15cd * -0x1;
                                                                        while (anf < -0x3 * -0x5ab + -0x7 * -0x24b + 0x3 * -0xadf) switch (anf) {
                                                                            case 0x136e + 0x31c * 0x2 + -0x1998:
                                                                                anf = ami == (0x3 * -0x3afe7 + -0x2fa6a3 * -0x1 + 0x419bb) % (-0x10ad + 0xe * 0x1bb + -0x78a) ? -0x2 * 0x40c + 0x1830 + -0xff4 : 0x21f7 + 0x1ac * 0x8 + -0x105 * 0x2e;
                                                                                break;
                                                                            case -0x93b + 0x4ab + 0x4b4:
                                                                                anf = 0x16a4 + 0x2 * 0x1362 + -0x1 * 0x3cf7, AntiAim.SetRealOffset(-(0x647 + -0x1697 + 0x108c));
                                                                                break;
                                                                        }
                                                                        break;
                                                                    case 0x261d + 0x12cb + -0x1 * 0x38d8:
                                                                        ane = ami == (0x22f9f + -0x18 * 0x239 + 0x1d3f * 0x1) % (-0x1 * -0xafa + 0xb03 + -0x15fa) ? -0x1222 + 0x1 * -0x94f + -0x49 * -0x61 : 0x2b * -0x15 + -0x1288 + 0x1659;
                                                                        break;
                                                                    case 0xf * -0x115 + -0x23f7 + -0x1 * -0x346a:
                                                                        ane = -0xac5 + -0x1d5e + 0x28b5, AntiAim.SetRealOffset(-(-0x1b5b + 0x181f + 0x378));
                                                                        break;
                                                                }
                                                            }
                                                            break;
                                                        case -0x1c42 * 0x1 + -0x125 * -0x7 + -0x1 * -0x1499:
                                                            and = -0x266 + -0x253f + 0x2860; {
                                                                AntiAim.SetFakeOffset(-amc / (0x8de0b4e + -0x35391af + -0x7 * 0x20aa67 & 0x441f06b + -0x2 * -0x2504b55 + -0x5a06001)), ang = -0x13 * -0xc6d01 + 0x4 * -0x6ee0f5 + -0x1be5baf * -0x1 ^ 0xa842f + 0x895f8c + 0x5b0b31;
                                                                while (ang < 0x2 * 0x1349 + -0xd * 0x287 + -0x297 * 0x2) switch (ang) {
                                                                    case -0x1692548 + 0x3f6aa1 + 0x218a995 ^ 0x238c * 0x9d9 + -0x67ea64 * 0x1 + 0x52 * -0x167e:
                                                                        ang = ami == -0xe5f8dec + -0x32bd68 + 0x2f * 0x7772e7 - (0x9d0115 * -0x10 + -0x6f7dc1 * 0x2 + 0x120ad9e7) ? -0x1774 + 0x4f1 + -0x63d * -0x3 : 0x7af * 0x3 + 0x20a7 + -0x3777;
                                                                        break;
                                                                    case -0xb3 * 0x1d + -0x237b * 0x1 + 0x13 * 0x2f2:
                                                                        ang = -0x218e * 0x1 + 0x9db + 0x183c, AntiAim.SetRealOffset(amc);
                                                                        break;
                                                                    case -0x798 + 0x1e2f * 0x1 + -0x165a:
                                                                        ang = 0x1a99 * 0x1 + 0x1953 * -0x1 + -0xbd, anh = -0xad * -0x5 + 0x184 * 0x2 + -0x633;
                                                                        while (anh < -0x16 * 0x134 + 0x14e + 0x32 * 0x83) switch (anh) {
                                                                            case -0x11f2 + -0x391 + 0x15b9:
                                                                                anh = ami == -0xc * -0x10dda0 + -0x60f415 + -0x1096c7 * -0x5 - (0x348efb + -0x15eff74 + -0x7ee9 * -0x3d6) ? -0x57c + 0xf95 + -0x9d5 : 0x2 * 0x8eb + 0xf0b + -0x4a3 * 0x7;
                                                                                break;
                                                                            case 0x1045 + -0x107f * 0x2 + 0x10fd:
                                                                                anh = -0x1da7 + -0x232f * -0x1 + -0x1b4 * 0x3, AntiAim.SetRealOffset(amc / (0x4ff3808 + -0xe47df * 0x9 + 0x591827 * -0x3 - (0x131c09d * 0x2 + 0x5af0d * 0x35 + -0x2787 * 0xbe)));
                                                                                break;
                                                                        }
                                                                        break;
                                                                }
                                                            }
                                                            break;
                                                    }
                                                    AntiAim.SetLBYOffset((-0x2 * 0x3efd + -0x5 * -0xa8d7 + 0xb6b3 * -0x1) % (-0x1 * 0x23ff + -0x1232 + 0x1 * 0x3634)), side = (-0x1 * -0x2530fd + 0x1 * 0x78aed + 0x5 * -0xcf0d) % (-0xd2a + 0x43a * 0x5 + -0x7f5);
                                                }
                                                break;
                                        }
                                    }
                                    break;
                                case 0x14b6 + 0x71b + -0x1b97:
                                    amv = UI.GetValue(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW', 'auto-direction type']) == 0x10a * 0xfb3e + -0x3a8a593 + 0x9ff643c - (0x78b671 + -0xc75b12f + -0x1 * -0x1358c7d3) ? 0x1 * 0xfc5 + 0x4f0 * -0x2 + -0x1 * 0x593 : 0x47102e1 + 0x959 * 0x1953 + -0x1c1ab74 & -0x882526c + 0x5980f8c + 0x74de9fd;
                                    break;
                                case (-0x533e647 + -0x7ba7c24 + -0x2 * -0x8a904c4) % (-0x17 * -0xe9 + -0x1 * 0xbf + -0xb * 0x1d5):
                                    amv = -0x204c + 0x1 * -0x19bf + -0x3a6a * -0x1, ani = 0x22 * -0xe9 + -0x2e5 * -0x5 + 0x1089;
                                    while (ani < 0xa83 * -0x1 + -0x4 * 0x8d6 + 0x2e96) switch (ani) {
                                        case -0x1b7e + -0x4 * -0x677 + -0x2 * -0xd9:
                                            ani = UI.GetValue(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW', 'auto-direction type']) == -0x5d1ac0 + -0x1707842 + 0x3550 * 0xc31 - (0xab85c5 + -0xdcdfe1 + 0xedbb69) ? 0x14ae + 0xb * 0x2a1 + 0xc61 * -0x4 : 0x369 + -0x92 * 0x37 + 0x1cb0;
                                            break;
                                        case 0x1352 + 0x15 * 0x7 + -0x9e8 * 0x2:
                                            ani = 0x15fd + 0x649 * -0x5 + 0xa2b * 0x1; {
                                                anj = -0x1 * -0x1eb3 + 0x1b72 + 0x39f6 * -0x1;
                                                while (anj < -0x6 * -0x86 + 0x1 * -0x18d1 + 0x37 * 0x67) switch (anj) {
                                                    case -0x117a + 0x10b7 + 0xf9:
                                                        anj = -0x1 * -0x1e87 + 0x125e + 0x3071 * -0x1, ank = 0x18 * 0x25 + 0x1e74 + -0x2190;
                                                        while (ank < -0x8c5 * 0x1 + -0x9d6 + 0x1334) switch (ank) {
                                                            case -0x778 + -0xcdb + 0x59 * 0x3b:
                                                                ank = 0x1 * 0x101 + 0x14c0 + -0x1528; {
                                                                    AntiAim.SetOverride((0xf9869 + -0x1c0a28 + 0x352268 * 0x1) % (-0x5ac + -0xf0f + 0x14be)), anl = 0x1a * -0xd0 + -0x6e6 + 0x8 * 0x38c;
                                                                    while (anl < -0x178d * 0x1 + 0x1 * -0x1234 + -0x2a7e * -0x1) switch (anl) {
                                                                        case 0x545 + 0x1cc * 0x2 + -0x891:
                                                                            anl = -0x170a * 0x1 + -0x1e1d + 0x35e4; {
                                                                                AntiAim.SetFakeOffset((0x3f7de + -0x21 * -0x3e1 + -0x26059) % (-0xecf + 0xebf + 0x1 * 0x13)), anm = -0xe7b89d + 0x111e * 0x157 + 0x16e574f - (-0x1 * 0xa3e289 + -0x10c89df + 0x24dfa45);
                                                                                while (anm < 0x153 + 0x15d8 + -0x1690) switch (anm) {
                                                                                    case -0x1 * 0x10dc791 + 0x2e87f7 + 0x2729ec1 ^ 0x8351ef * 0x1 + 0x32380b3 + 0x3a31 * -0x922:
                                                                                        anm = ami == (-0x39bc7 + -0xea7a + -0x1 * -0x69dc7) % (0x16a * -0x1 + -0x35e * 0x6 + 0x15a1) ? -0x3 * 0xbdb + -0x1a * -0x54 + -0x1b3b * -0x1 : -0xbb * 0xb + 0x575 + 0x2e3;
                                                                                        break;
                                                                                    case -0x281 * -0xf + 0x940 + -0x2e9d:
                                                                                        anm = -0x5 * -0x751 + -0xeb9 * -0x1 + -0x32b3, AntiAim.SetRealOffset(-(0x1bb + -0xdb4 * 0x1 + -0x271 * -0x5));
                                                                                        break;
                                                                                    case 0x1 * 0x1c6a + 0x361 * 0x1 + -0x1f7c * 0x1:
                                                                                        anm = 0x7 * -0x3f2 + -0x1 * -0x2485 + -0x84c, ann = -0x415 * 0x1 + 0xe9e * -0x2 + 0x2179;
                                                                                        while (ann < -0x1 * -0x48b + 0x2 * 0xeab + 0x1 * -0x2197) switch (ann) {
                                                                                            case 0x257 * -0x7 + -0x193c + 0x29c5:
                                                                                                ann = ami == (0x10d71e * 0x2 + -0x43494a + -0x1 * -0x4a4bb7) % (0xf07 * -0x2 + 0x261e + 0x80d * -0x1) ? -0x41 * -0x1 + 0x6d * -0x3f + 0x1aaf * 0x1 : 0x1 * 0x1eaa + 0x1ee0 + -0x3d40;
                                                                                                break;
                                                                                            case 0x1fda + -0x7eb + -0x17d2:
                                                                                                ann = 0x12 * 0x16f + 0x1a6c + -0x33f0, AntiAim.SetRealOffset(-(-0xbdd + -0x1a7d * 0x1 + -0x2 * -0x134b));
                                                                                                break;
                                                                                        }
                                                                                        break;
                                                                                }
                                                                            }
                                                                            break;
                                                                        case 0x196 * -0x11 + -0x19b9 + 0x34f4:
                                                                            anl = -0x25d8 + -0x1f * 0xca + 0x3f0b; {
                                                                                AntiAim.SetFakeOffset(-amc / ((0x1 * -0xa3e48f + 0x12 * 0x151caa + 0x16cf87) % (0x24ea + -0x157 * -0xa + -0x324a * 0x1))), ano = (-0x658825 * -0x1 + 0x1d2 * -0x1aeac6 + 0x59cf1d91) % (0x2 * 0x125f + 0x1578 + 0x3e1 * -0xf);
                                                                                while (ano < 0xedd * 0x1 + 0x5 * 0x455 + -0x2432) switch (ano) {
                                                                                    case 0x2442 + -0xbf2 + -0x1815:
                                                                                        ano = -0x606 + -0x24d * 0xa + -0xeae * -0x2, AntiAim.SetRealOffset(amc);
                                                                                        break;
                                                                                    case 0x1c65 + -0x1 * -0x1c0f + -0x32 * 0x120:
                                                                                        ano = -0x1808 + -0x1eed + 0x3749, anp = -0x1ae8 * 0x1 + 0x1 * -0x2662 + 0x29 * 0x199;
                                                                                        while (anp < -0xb0 * 0x7 + -0x2707 + -0x40 * -0xb2) switch (anp) {
                                                                                            case -0x253a + 0x36d * -0x6 + 0x39ff:
                                                                                                anp = ami == (0x67925 * -0x9 + -0x2fbb93 * -0x1 + 0x1 * 0x333763) % (-0xe6e + -0x2b6 * 0x4 + 0x1949 * 0x1) ? -0x1 * -0x21e9 + 0x1409 + 0x2 * -0x1ade : 0x11 * -0x97 + 0x21 + -0x33 * -0x35;
                                                                                                break;
                                                                                            case 0x1df4 + 0x1961 + -0x371f * 0x1:
                                                                                                anp = -0x7bb + 0x6be + 0x1a6 * 0x1, AntiAim.SetRealOffset(amc / ((0x106 * 0x4d852e + 0x3997053e + 0x76 * -0xcfa94c) % (-0x4 * 0x71 + 0x4 * -0x637 + 0x1 * 0x1aa7)));
                                                                                                break;
                                                                                        }
                                                                                        break;
                                                                                    case (0xac8efbd + 0x47b7015f + -0x294aa7d2) % (-0x24d5 + 0x62 * 0x3f + 0xcbe):
                                                                                        ano = ami == (-0x42281 + -0x156d4 + 0x790db) % (-0x5b * 0x44 + -0x1d21 + 0x4 * 0xd54) ? 0x3ce * -0x5 + 0x662 + 0xcdf : 0x1a * 0x55 + -0x2149 + 0x3f * 0x65;
                                                                                        break;
                                                                                }
                                                                            }
                                                                            break;
                                                                        case 0xf8 * -0x20 + 0x3b9 * -0xa + 0x4494:
                                                                            anl = UI.GetValue(['Rage', 'Anti Aim', 'General', 'Key assignment', 'legit desync']) == (null == undefined) ? 0x17a9 + -0x14f1 + 0x9b * -0x4 : -0xd6b + 0xd36 + 0x3d * 0x2;
                                                                            break;
                                                                    }
                                                                    AntiAim.SetLBYOffset(0x3 * 0x4830106 + -0xfb85a * -0x30 + -0x91fc6dd - (-0x680c625 + -0x149d5e * -0x72 + 0x952 * 0x8097)), side = (-0x3fed6b + 0x13d79f + -0x621 * -0xdd5) % (0xc2 * 0x1d + -0x1684 * 0x1 + 0x8d);
                                                                }
                                                                break;
                                                            case 0x17 * -0x95 + 0x90f + 0x4b0:
                                                                ank = amf <= -((-0x4cb829 + -0x2bbfac + 0xa1287e) % (0xb38 + -0x5d1 * -0x1 + -0x1106)) ? 0x393 + 0x2563 + 0x2 * -0x1463 : 0x10cf + 0x220b * 0x1 + -0x3241;
                                                                break;
                                                        }
                                                        break;
                                                    case -0xa64 + 0x112 + -0x9b3 * -0x1:
                                                        anj = 0x9bc * -0x1 + -0x1 * 0x2aa + 0xcda; {
                                                            AntiAim.SetOverride((-0x474640 + -0x2ad * -0x1e0d + -0x193e8 * -0x14) % (0x165 + -0x1656 + 0x14f4)), anq = -0x1009 + -0x1 * 0x5c9 + 0x1602;
                                                            while (anq < -0x6 * 0x4c1 + -0xf42 + 0x2c32) switch (anq) {
                                                                case 0x6a9 * 0x2 + -0x1ca3 * 0x1 + 0xf7f:
                                                                    anq = 0x825 + 0x17f7 + -0x2 * 0xfd9; {
                                                                        AntiAim.SetFakeOffset((0x2 * 0x9374 + 0x2bfd3 * -0x1 + 0x3b071 * 0x1) % (0x53f * -0x1 + -0x17ae * 0x1 + -0x8 * -0x39e)), anr = 0x25c4 + -0xad * 0x37 + -0x87;
                                                                        while (anr < 0xcfd * 0x3 + 0xdb3 + -0x1 * 0x3411) switch (anr) {
                                                                            case -0x41b + 0x1f43 * 0x1 + -0xd8b * 0x2:
                                                                                anr = ami == 0x9c7 * -0x3182 + -0x1b44472 + 0xaf41f95 - (0x6d73 * -0x821 + -0x2673326 * -0x2 + 0x6071a9c) ? -0xda9 * 0x1 + -0x1d7 * -0x6 + 0x6d * 0x7 : 0x1 * -0x94c + -0xf4a + 0x18bb;
                                                                                break;
                                                                            case -0x4 * 0x4f + -0x20fa + 0x6df * 0x5:
                                                                                anr = -0xa * -0x1b7 + 0x2 * -0xde6 + 0xb3f, ans = -0x325 + 0x4bd * 0x8 + 0x2a9 * -0xd;
                                                                                while (ans < 0xc9e + 0x1785 + -0x23b7) switch (ans) {
                                                                                    case -0x1850 * -0x1 + -0x14d + -0x16d5:
                                                                                        ans = ami == 0x7 * 0x1fe904 + -0x7784a9 + 0x5486db - (-0xa9c3e7 + 0xa03ae * 0x22 + 0x11a818) ? 0x1a51 + -0x2 * 0xec7 + -0x1c9 * -0x2 : -0xbe5 * -0x1 + 0x18a9 + -0x2422;
                                                                                        break;
                                                                                    case 0x11e1 * 0x1 + -0x2 * -0x128d + -0x36a6:
                                                                                        ans = 0xb0 * -0x1 + -0x8d3 + 0x9ef * 0x1, AntiAim.SetRealOffset(0x1 * 0xd42 + -0x32 * 0xbe + 0x1816);
                                                                                        break;
                                                                                }
                                                                                break;
                                                                            case 0xf * -0x249 + 0x242 * -0xe + -0x3 * -0x1615:
                                                                                anr = -0x117b + -0x2 * 0xb57 + -0x2 * -0x1461, AntiAim.SetRealOffset(-0x2b2 + 0x5d1 * -0x2 + 0x748 * 0x2);
                                                                                break;
                                                                        }
                                                                    }
                                                                    break;
                                                                case -0x22e9 + -0xd9d + 0x30d4:
                                                                    anq = 0x156e + -0x112c + -0x3d8; {
                                                                        AntiAim.SetFakeOffset(amc / ((-0xd0cef0 + 0xf8c3fc + 0xc6f9e0 * 0x1) % (0x14ef * 0x1 + 0x324 + -0x180d))), ant = -0x187d + 0x1201 + 0x6ab * 0x1;
                                                                        while (ant < 0x4 * -0x4dc + 0x21be + 0x6f3 * -0x2) switch (ant) {
                                                                            case -0xa57 + -0x8bc + 0x9a7 * 0x2:
                                                                                ant = -0x25 * 0x67 + 0x13c1 + -0x23b * 0x2, anu = -0xf95 + -0xd * 0x185 + 0x2374;
                                                                                while (anu < -0x1 * 0x24d4 + 0x1fa2 + 0x1 * 0x5db) switch (anu) {
                                                                                    case 0x144b + 0xb * -0x6f + 0xf29 * -0x1:
                                                                                        anu = -0x25dc + -0x6a * -0x38 + 0xf55, AntiAim.SetRealOffset(-amc / ((-0x7d7a496 + 0x2811234b + -0x9df * -0x12c) % (-0x4 * 0x2a6 + -0x271 * 0x6 + -0x86d * -0x3)));
                                                                                        break;
                                                                                    case -0x23dd + -0x1 * 0x7cf + 0x2bca:
                                                                                        anu = ami == (-0x51a2d * -0xb + 0xadb * 0x773 + -0x604ca7) % (0x1e2b + 0x1 * 0x8af + -0x26d7) ? 0x3f + 0xdc7 * 0x1 + -0xda9 : 0x1e2 * 0x1 + 0xc5 * 0x29 + -0x20c6;
                                                                                        break;
                                                                                }
                                                                                break;
                                                                            case 0x1 * -0x38b011d + -0x67344f + 0x7659e28 - (-0x242226c + -0x55cd624 + 0x1 * 0xb126149):
                                                                                ant = 0x7eb + -0x1 * 0x1be6 + 0x1463, AntiAim.SetRealOffset(-amc);
                                                                                break;
                                                                            case 0x913 * -0x2 + -0xca9 + 0x1efe:
                                                                                ant = ami == 0x1 * -0xf64be2 + -0x21dbdf4 * 0x3 + 0x3fa649 * 0x3b - (0x5 * -0x2b1d00d + -0x2e3b6f3 + 0x17b89449) ? -0x63588c4 + -0x487bd40 + -0xe30aec0 * -0x1 - (-0x1 * 0x33b770f + 0x111cc32 + -0x2 * -0x2ce89cb) : 0x1 * -0x559 + 0x94 * -0x7 + 0x8 * 0x134;
                                                                                break;
                                                                        }
                                                                    }
                                                                    break;
                                                                case -0x1921 + -0x5f2 + 0x1f43:
                                                                    anq = UI.GetValue(['Rage', 'Anti Aim', 'General', 'Key assignment', 'legit desync']) == (NaN !== NaN) ? 0x1c9 * -0x15 + -0xad2 * 0x2 + 0x3b4f : 0x2 * 0xbce + -0x1b9f * 0x1 + 0x451;
                                                                    break;
                                                            }
                                                            AntiAim.SetLBYOffset(-0x3018cb4 + 0xd3847f5 + -0x2daee2c - (0x6197a27 + 0x89b625c + -0x7590f6e)), side = (-0x3ae1db9 * 0x14 + 0x29413d * 0x137 + -0x34f1 * -0x138d3) % (0x72b * 0x5 + -0x2568 * 0x1 + -0xc * -0x22);
                                                        }
                                                        break;
                                                    case -0x576 * -0x7 + -0x1f * 0x117 + 0x6d * -0xa:
                                                        anj = amf >= 0xbe6cbd + 0x652 * -0xe3c + 0x1 * 0x57ebc9 - (-0xf8e7 * 0x125 + 0x139d0bd + -0x524ad * -0x1f) ? 0x925 + -0x1 * -0x10a9 + 0x1 * -0x196d : 0x9db + 0x240b + -0x2db0;
                                                        break;
                                                }
                                            }
                                            break;
                                    }
                                    break;
                            }
                        }
                        break;
                }
            }
            break;
        case -0x229d + 0x235e + -0xd * 0x8:
            amo = 0x7f2 + 0x2a8 + 0x5 * -0x1ff; {
                AntiAim.SetOverride(-0x6 * -0x2c1440 + 0x174ee86 + -0x1c106b8 - (-0x1123bb2 + -0x3 * 0x4e483b + 0x10 * 0x2b975b)), AntiAim.SetFakeOffset(amj), AntiAim.SetRealOffset(-(0x1 * -0x14bd + -0x75 * 0x1f + 0x22f9) - amj * -(-0x1 * 0x578d7a + 0xce68dd + -0x4585eb * -0x1 - (0x117be5 + -0x104d094 + 0x6 * 0x47f3aa))), AntiAim.SetLBYOffset(-0x2d03b68 + 0x8 * 0x40ccc0 + 0x825a27d - (-0xdc489ca + -0x18f * -0x20a23 + -0x2 * -0x8f94529)), jagowalking = null == undefined, side = (0x1588a6 * 0x2aa + 0x1a6dad * 0x1bb + -0x42 * 0x112bd29) % (-0x1b59 + 0x1072 * -0x1 + 0x2bd4);
            }
            break;
        case 0x1983 + -0x20d2 + -0x8 * -0xed:
            amo = UI.GetValue(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW', 'jag0-walk']) == (null == undefined) && UI.GetValue(['Rage', 'Anti Aim', 'General', 'Key assignment', 'Slow walk']) == (0x1777 * 0x1 + -0x23b4 + 0xc3e == '1') && UI.GetValue(['Rage', 'Anti Aim', 'General', 'Key assignment', 'legit desync']) == ![] ? -0x214 + -0x1 * -0x1717 + -0x1 * 0x14aa : 0xfc4 + -0xa3 * -0x4 + -0x1231;
            break;
    }
    var amc, amd, ame, amf, amg, amh, ami, amj, amc, amk, aml, amm, amn, amo, amp, amq, amr, ams, amt, amu, amv, amw, amx, amy, amz, ana, anb, anc, and, ane, anf, ang, anh, ani, anj, ank, anl, anm, ann, ano, anp, anq, anr, ans, ant, anu;
}
jagowalking = [0xda09800 + -0x3 * -0x2ed4adb + -0xf0cab7c - (-0x250e052 * 0x4 + 0x8c43f4d + 0x7db0f10)] == '';

function dsal23232342222322323233233242323332323232322223342323223232223233434232342342342323422342342344234332k312323() {
    var a = a;
    kljkj23h4kj234h23klj42(Global.GetScreenSize()[0x24efad * -0x65 + 0x46e5ece * 0x1 + 0x117ffd88 - (0x5efdbc + -0x520a4a9 + 0xc1d7402)] / (-0xb * 0x2af192 + -0x8d1c99 * -0x1 + -0x23a339b * -0x1 ^ -0x13 * 0x9868e + 0x3 * 0x916f7 + 0xe9 * 0x1af69), Global.GetScreenSize()[(0x29 * 0x2cee + 0x16baa1 + 0xac3ea) % (-0xa4 * 0x11 + -0x1 * 0xca7 + -0x7da * -0x3)] / ((-0x3956ebac + -0x1 * 0x373fe991 + 0x14f01 * 0x7587) % (-0x13 * 0x15b + -0x1 * 0x260f + 0x115 * 0x3b)) + (0x21d4 * -0x1 + 0x47b * 0x8 + 0x1b4 * -0x1), -0x119b + -0x1fcf + 0x3173 * 0x1, -(0xb16 + 0x253f + -0xcb2), 0x27fdf + -0x1d066 + 0x1225c1 * 0x1, 0x1 * 0x15ec94 + -0xa1b86 + -0x1 * -0x39c34 - (-0x5 * -0x4e3f1 + -0x2d13 * 0xb + -0x8 * 0xe2d5), [-0x7 * -0x1e1 + -0x48b * 0x5 + 0x1 * 0xa49, 0x3d * 0x96 + -0x49f + -0x1e9d * 0x1, -0x69b * 0x1 + 0x465 * 0x1 + -0x95 * -0x4, 0xd * -0x6b + -0x1e1 + 0x84f]), anv = -0x1f92 + -0x209d + 0x4082;
    while (anv < 0x269c + 0x58a + -0x25 * 0x12e) switch (anv) {
        case (0x573b5ab + 0x15f4052 + 0xe * -0x493901) % (0x1e90 + -0x19 * -0x4 + 0x4 * -0x7bb):
            anv = 0x66e * -0x1 + -0xebc * -0x1 + -0x7ce; {
                kljkj23h4kj234h23klj42(Global.GetScreenSize()[0x2de7fdf * 0x1 + 0x4 * 0x1ebdfe9 + 0xf346 * -0x35d - (0xca9948a + 0x2 * -0x2f45f42 + 0x1 * 0x9af70f)] / ((-0xb9f1c5 * -0x65 + -0x3a7e33d * -0x1 + -0x8f3bf2b * 0x4) % (0x1 * -0x21f5 + -0xd86 * 0x1 + 0xfd6 * 0x3)), Global.GetScreenSize()[(0x225156 + 0xbdd7 * 0x5b + -0x3d1c1a) % (0x17 * 0x5b + 0x6bf + 0x15b * -0xb)] / ((0x5d8d1d * -0x17 + 0x401a52 * -0x6 + 0xc5 * 0x426c9d) % (0x1d28 + -0x183 + 0x586 * -0x5)) + (-0x687 + 0x21 * 0x29 + 0x18e), -0x2 * 0x4 + 0x12 * -0x117 + 0x13af, -(-0x3b0d + -0x3 * -0xaa9 + 0x3 * 0x14e7), 0x55b0 + -0xa0eef + 0x13 * 0x180c3, (-0x13fd9a + -0x154229 + 0x6131ed) % (-0x99 + 0x1831 * 0x1 + -0x178c), [-0x1c9 * -0x1 + -0x1 * 0x1601 + 0x14f1, 0xbb5 + 0x3a4 * -0x1 + 0x2b * -0x2d, 0xcdd + 0x581 * 0x3 + 0x5 * -0x5da, -0x1677 * -0x1 + 0x11cd + -0x3 * 0xd17]);
            }
            break;
        case 0x9ec * 0x2 + -0x1 * -0x1b57 + -0x2edc:
            anv = (flip = NaN !== NaN) ? (-0x79c29f + 0x1677 * -0x27f + 0x383ad97) % (0x28 * 0xe1 + -0xeef * -0x2 + 0x76 * -0x8d) : -0xb * -0xf1 + 0x5 * 0x17d + -0x1181;
            break;
        case 0x21e * -0x1 + 0x12de + -0x1075:
            anv = 0x23eb + 0x1f5 + -0x68 * 0x5c; {
                kljkj23h4kj234h23klj42(Global.GetScreenSize()[-0x857706f + -0x1 * -0x9442f2c + -0x1b * -0x3d0088 - (-0x5e8e089 * 0x1 + 0x8b05be7 * -0x1 + -0x3 * -0x751add7)] / (0x1 * 0x16de741 + 0x59fe2a + -0xd8f67d * 0x1 ^ 0x1dd383 * -0xd + -0x1 * -0x5f6a17 + -0x4 * -0x84d09f), Global.GetScreenSize()[(-0x3df69 + 0x49 * 0x5f3e + -0x37b14 * -0x5) % (0x2037 + 0xc * 0x2e0 + -0x42b4)] / (0x3b * 0x212ab + -0x2763a9 * -0x8 + 0x17 * -0x8a135 ^ -0x18be89c + 0x721b90 + -0x1 * -0x208bbf8) + (-0x171b + -0x1 * 0x1237 + 0x29a2), 0x881 * -0x1 + 0xac6 + -0x23c, -(-0x3790 + 0x459f + -0x2 * -0xaca), -0x2 * 0xfa3 + -0x85eef + 0x1b536f, (0x19076b * -0x4 + -0x3c4f3c + 0xd85f12) % (-0x18c2 + -0x443 + 0x1d11), [0x18d * 0x11 + -0x4d9 + -0x1 * 0x14cb, 0x833 * -0x4 + -0x133 * 0x2 + 0x4 * 0x8ed, -0x183e + -0x5cf * 0x5 + 0x3567, 0x1 * 0x11a5 + -0x1 * 0x1bca + 0xb24]);
            }
            break;
    }
    var anv;
}
lastcurt = (-0x313f * 0x10 + 0x250d * 0x1 + -0x1 * -0x50669) % (0x2 * 0xb11 + 0x168c + 0x1 * -0x2cab);

function dsal22344234332k312323(anw) {
    var a = a;
    anx = Entity.GetProp(anw, 'CBasePlayer', 'm_fFlags'), any = -0x26ef + 0x22 * -0xe3 + 0x20 * 0x22b;
    while (any < 0x35f + 0xc76 + 0xf4d * -0x1) switch (any) {
        case -0x2253 + -0xcb8 + 0xc * 0x3ee:
            any = -0x2115 + -0x6b * -0x55 + -0x31 * 0xa;
            return 0x264d + 0x1228 * 0x1 + 0x2 * -0x1c3a === '1';
        case 0x1b10 + 0xa + 0x1acf * -0x1:
            any = anx & (0x16 * -0x147ed + 0x5 * -0xe7652 + 0x8d2ea1) % (-0x1709 + -0x1692 * -0x1 + 0x7a * 0x1) << -0x56575 * -0x1 + -0x1 * -0x5c7525 + 0x31 * 0x1d8f4 - (0xb44 * -0x1c1f + 0x4a * -0x37bb4 + 0x2faf091) ? -0x651d707 + 0x5ddbf * -0x9c + 0x187c5b * 0x9d ^ -0x45c679c + 0x1b7657a * 0x1 + -0x2f * -0x2a4ded : 0x4 * 0x6fe + 0x218 * 0x2 + -0x200b;
            break;
        case 0x3d4e937 + -0xd02d77 + 0x21a90a4 ^ 0x32169cc + -0x27846b + 0x2256700:
            any = 0x105e + -0x269 + -0xd6d * 0x1;
            return null == undefined;
    }
    var anx, any;
}
tickcount = -0x505b09e + -0xd * -0x297d5f + 0xa461fe0 - (-0xdb37d69 + 0x649d389 + 0xec576f5);

function dsal232323422223222232332323322223233323233233242323332323232322223342323223232223233434232342342342323422342342344234332k312323() {
    var a = a;
    aoa = CheatHooked.GetUsername();
    while (aoc < 0x4 * -0x74b + -0x41f * -0x8 + -0x362) switch (aoc) {
        case -0x2460 + -0x22ac + 0x4735:
            aoc = 0x2 * 0xbcf + 0x13 * -0xc7 + -0x86f, dsal23232342222322323233233242323332323232322223342323223232223233434232342342342323422342342344234332k312323();
            break;
        case -0x131e + -0x1 * -0x4b1 + 0x4d * 0x31:
            aoc = aoa != aob[(0x2ca2f + 0x104d0 + 0x1 * -0x1b779) % (-0x9a3 * 0x1 + 0xe * -0x145 + -0x34 * -0x87)] || aoa != aob[(0x1c1ef9 + 0xd * 0x21234 + -0x19854 * 0x9) % (-0x1 * 0x761 + -0x22fd * 0x1 + 0x2a61)] || aoa != aob[-0x5b0bab + 0xc99d0 + 0x13d60c9 ^ -0xf * 0x10d2ab + 0xa01d16 + 0x14b29db] || aoa != aob[(0x12607f * 0x32b + 0x1114565e + -0x2b06f8aa) % (-0x1 * -0x20e7 + -0x38f * -0x1 + -0x246d)] || aoa != anz[-0x1931a10 + 0x13584e5 + 0x14c8419 ^ 0x5ff3df + -0x14360 * -0xd3 + -0x7b8d13] ? -0x17ee + 0x12d6 + 0x541 : 0xc * 0x266 + -0x9d * 0x13 + -0x10b7;
            break;
    }
    aod = dsal23422243234232342342342323422342342344234332k312323(Math.abs(Math.round(Local.GetRealYaw() - Local.GetFakeYaw())), (-0x2b9f7 + -0x37791 + 0x8490e) % (-0xb * 0x1be + -0xd1b * -0x2 + 0x1 * -0x709), -0x11ab * 0x1 + -0x1800 + 0x29e5), aoe = Math.sin(Math.abs(-(-0x1 * -0xbcd + -0x17c + -2637.86) + Globals.Curtime() * ((-0xde3ff * -0x4 + -0x13d8e7 * 0x1 + 0x4f994) % (0x40 * -0x6d + 0x36 * 0x12 + 0x1777 * 0x1) / (-0x900 + 0x16bd + -3516.25)) % ((-0x1172 + 0x1 * 0x1384 + -526.86) * ((-0x22983d42 + 0xb6fd3 * 0x36b + 0x20137f * 0x125) % (0x16 * 0x131 + 0x1 * -0x1a2f + 0x0))))) * (-0x329 * 0x2 + -0x6f8 + 0xe49), aof = UI.GetColor(['Config', 'JAGO-YAW', 'JAGO-YAW', 'indicators color']), aog = RenderHooked.AddFont('Verdana', 0x1e20 + -0x18 * -0x12d + -0x3a4d, 0x188d + -0x2309 + -0x4cc * -0x3), aoh = RenderHooked.AddFont('Verdana', -0x41 * 0x98 + -0xbd8 * 0x2 + 0x3e57, 0x11 * 0x889194 + 0xa7 * 0x4418f + 0x279ba8 * -0x1d - (0x683 * -0x21f6b + 0x7bc * 0x11326 + 0xcde48ee)), aoi = RenderHooked.AddFont('Verdana', 0x16de + 0x4 * -0x66f + 0x2f2, 0x1a * 0x187 + 0x20 * -0xc8 + 0xc2d * 0x2), aoj = RenderHooked.AddFont('Verdana', -0x10f * 0x1 + 0x1 * 0x1d72 + -0x1c58, 0x4678 + -0x358 * 0x4 + -0x1208 * 0x1), aok = RenderHooked.AddFont('Verdana', -0x304 * -0x1 + -0xc82 + 0x989, -0x1 * -0x35eb + -0x16 * 0x24f + 0x1 * 0x23ef), dsal23422243223434232342342342323422342342344234332k312323(Global.GetScreenSize()[(0x17fee + 0x1060 * -0xb + 0x14bb8) % (0x12ae + 0x390 * -0x6 + 0x2b5)] / ((-0x213c017b + 0x331a7b9e + 0x1756cf27) % (-0x1c * -0x3 + 0x5 * -0x3ef + 0x1 * 0x135e)), Global.GetScreenSize()[0x4bdcee + 0xb2f3e + 0x32aa91 * 0x2 - (-0x6e053b + 0xcc * -0x130b7 + 0x21d385c)] / (0x1 * -0x51e36e + 0xeefe7c + -0x51d3e * -0x10 ^ 0x4e48ca + 0x18c8b36 + -0xebe514), -0x73d * -0x3 + 0x55 * -0xd + -0x115c, 0x1d9e808 + -0x11 * -0x360a + -0xee8fc4 ^ -0x142de2c + 0x16af44b + -0xf4bc1 * -0xd, -0xe868f35 + -0x187172 * -0x89 + 0x8cda648 * 0x1 - (-0x1dfb345 + 0x94aa33b + -0xf22e1), -0x437 * 0x6 + 0x2080 + 0x1 * -0x6dc, 0x47 * -0xcf47 + -0x556696 + 0x17dd235 ^ 0xb * 0x1969d5 + 0x6a16ee + -0x92b429), aol = 0x8c2 + -0x55d * -0x4 + -0x1df9;
    while (aol < -0x1 * 0x1d95 + -0x1 * -0x18f5 + -0x3d * -0x15) switch (aol) {
        case 0x2 * 0x18d + 0x1 * -0x220c + 0x1f3a:
            aol = -0x119 * -0x22 + -0x5f3 * 0x1 + 0x1 * -0x1efe; {
                RenderHooked.String(Global.GetScreenSize()[(0x42868 + 0x8b08 + -0x29bea) % (-0x7 * -0x2b3 + 0xc1c + -0x1efe)] / (0x4 * 0x3fa66 + -0xf1b4a9 + -0x1d0b9ff * -0x1 ^ 0x43 * 0x4b826 + 0x11a479 * -0x15 + 0x1253ae7) + (0x24e7 + -0x1d * 0x7 + 0x1 * -0x23ea), Global.GetScreenSize()[(-0x3d08f8 + 0x4a37c1 + 0x1b81e0) % (-0x3 * 0x25 + 0xa61 * 0x1 + -0x9ef)] / ((-0x6cf0dda + -0x9f942 * -0x533 + -0x3d69b02) % (0x2 * 0x5e9 + -0x2fd + 0x31 * -0x2e)) - (-0x15d9 + 0x17d1 + 0x7 * -0x46), (-0x19088 + -0x707 * -0x84 + -0x439 * -0x2) % (-0x21 * 0x2e + 0x1be7 + -0x1 * 0x15f6), '>', [0x27b * -0xb + -0xdc3 * 0x1 + 0x2 * 0x149f, 0xabf + -0x609 + 0x22 * -0x22, -0x1df + -0x1c * 0xbf + 0x9 * 0x28d, 0xe80 + 0x1 * 0xb1 + -0xe9b * 0x1], aoi), RenderHooked.String(Global.GetScreenSize()[0xe9154b * 0x8 + 0x43a2573 * 0x1 + -0x59 * 0xbf1a6 - (0x6 * -0x161a6f7 + -0x347 * 0x31db4 + 0x19dc0fcb)] / ((-0x5a6d0 * -0x420 + -0x1eabd02e + 0x1 * 0x3090ff78) % (-0xd * -0x251 + 0x5 * 0x7c7 + -0x44f9)) - (-0xbc * 0x2 + -0xbc3 * -0x3 + -0x218f), Global.GetScreenSize()[-0x136 * 0xcb88 + -0x53506f + 0x206286d - (-0x77d1c5 + -0x158989 + 0x5e1b * 0x381)] / (0x3521c * -0x28 + -0x16dc625 + -0x1 * -0x2e18973 ^ 0x3 * 0x71272a + 0xa874d0 + -0x10cfb62) - (-0xf2b + 0xc5 * -0x13 + 0x1dd8), -0x3bebe50 + 0xb7812d5 + 0x44 * -0x1601c - (-0x4e494ed + -0x520222 * -0x18 + 0x4902ed2), '<', [0x1b68 + -0x8 * -0x277 + -0x2eee, -0x1bd * 0x8 + -0x1669 * -0x1 + -0x2c5 * 0x3, 0x44a + 0x1 * -0xa7f + -0xb * -0x95, 0x10e7 + -0x1ad9 + 0xa88], aoi);
            }
            break;
        case 0x1d9 + 0x12a6 + 0x2 * -0xa21:
            aol = side != -0x1 * 0x5c296b1 + 0x77aa7 * -0x65 + 0xc296350 - (-0x24af4f * 0xe + -0x6e3cb * 0xb1 + 0xa387e66) ? 0xd20 + -0x4 * -0x874 + 0x4 * -0xbaa : 0x58 * -0x2 + -0xb * 0x187 + 0x1 * 0x11de;
            break;
    }
    aom = 0x3c0 + -0x1ab * -0x9 + -0x12aa;
    while (aom < -0x4 * -0x6fd + 0xe6d * 0x1 + -0x29c5) switch (aom) {
        case -0x2199 + -0x2 * 0x91c + 0x3430:
            aom = 0x629 * 0x5 + -0x75a + 0x3 * -0x79d, aon = 0x16f + 0x1 * 0x2377 + -0x24c6 * 0x1;
            while (aon < 0x71 * -0x4d + -0x1b35 * -0x1 + -0x1 * -0x745) switch (aon) {
                case -0x36 + -0x5cf * -0x2 + -0xb48:
                    aon = side == (0x732cc8b + -0xfbe2e90 + 0x31c0ab4f) % (0x8e * -0x1 + -0x2 * -0x1373 + -0x2651) && aod > (-0xd293 + -0x2c5df + -0x16bfe * -0x4) % (-0x65a + -0x1b7a + 0x21d7) ? -0xf2d + 0x1ae6 + -0xb9c : 0x3e1 + 0x1b53 * -0x1 + 0x1 * 0x17ef;
                    break;
                case 0x228b + 0x18e5 + -0x3b53:
                    aon = 0x1546 + 0xa5b + 0x1 * -0x1f24; {
                        RenderHooked.String(Global.GetScreenSize()[(0x17b * -0x174 + 0x32778 + -0x8b65 * -0x2) % (-0x1 * 0x21be + -0x9c1 + 0x2b82)] / (0x443b52 + -0x99edd * 0x23 + 0x1fb6bd3 ^ 0x198b1d + -0xad3 * 0x1107 + 0xc6d94a * 0x2) - (0x17 * 0x16d + 0x1 * -0x1ca5 + -0x3e4), Global.GetScreenSize()[(0x1f6 * 0xbbc + 0x32aa4e + 0xbe9 * -0x2c5) % (0x25e3 + 0x7a9 * 0x1 + -0x1 * 0x2d89)] / ((0x214 * -0x17aa53 + 0x49656fb5 * 0x1 + 0x10fdce11) % (-0x1889 + 0x234 + 0x6 * 0x3ba)) - (-0xf6c + -0x2477 + 0x1 * 0x33f1), (-0x23dc6 + 0x1 * 0x41a61 + 0x3aeb) % (-0x93 + -0x1d * 0x3e + 0x1e7 * 0x4), '<', [aof[0x81eda5 + -0x3390bb9 + 0xa12eb29 - (0x22 * -0x516a79 + 0x47679c5 * 0x3 + 0x4c883d8)], aof[0x1e056 * -0x8b + 0x107d47d + -0xb95b83 * -0x1 - (-0x8a6553 + -0x2 * 0x34df5 + -0x1 * -0x14d628a)], aof[-0x2663bf + 0x1b189f9 + -0x9c374c * 0x1 ^ 0xb * -0xa60ff + 0xd28860 + 0x3f41 * 0x241], 0xf30 + 0xce7 * -0x1 + -0x14a], aoi);
                    }
                    break;
            }
            break;
        case (0x4285b0a6 + 0x3c50a84b * 0x1 + -0x55a10fa7) % (0x103f * 0x1 + 0xcd * 0x15 + -0x2109):
            aom = 0x1f04 + -0x1617 * -0x1 + -0x1 * 0x347f; {
                RenderHooked.String(Global.GetScreenSize()[-0xca7d8d7 + -0x1838d7c + 0x15873368 - (-0xb006230 + 0x1fda20f * -0x5 + -0x10 * -0x1c50599)] / (0x1571cbf + 0x1 * -0x8961c1 + 0x2133f0 ^ 0x543 * 0x2903 + 0x1cf3b1 + -0x5cf8e) + (0x1b3b + -0x1 * -0x1df + -0x1ce8), Global.GetScreenSize()[0x57c3 * -0x392 + 0x9 * 0x1366d9 + 0x14719e3 - (0x13456e3 + -0x8c6 * -0x4d6 + -0xa2631a)] / ((-0x125db3d1 + -0x31ca7d15 + 0x6d5d7a30) % (-0x15ed + -0xb16 + -0x1085 * -0x2)) - (-0x2222 + 0x15f6 + 0xc3a), (-0x40d * 0x47 + 0x287a4 + 0xaf7d) % (-0x8 * 0x289 + 0x1465 + -0x1a), '>', [aof[(0x36f * -0x29 + 0x276d8 + -0x2d75 * -0x1) % (-0x3b4 + 0x3 * -0x876 + 0x1d19)], aof[0x1 * -0x786cce + 0x2864e9 * 0x6 + -0x4270a6 * -0x1 - (0x146138d + -0x1225d35 + 0x98aaf5)], aof[(-0x362 * -0x14ce7e + -0x3e758f34 + 0x319 * 0xabe92) % (0x1 * -0x24b8 + 0x241d + 0xa2)], 0xcc8 + -0x305 * 0x3 + -0x15d * 0x2], aoi);
            }
            break;
        case -0x3 * -0x9f7 + -0x356 + -0x1a76:
            aom = side == (-0x3b5e87 + -0xbcff7 + -0x6fdf27 * -0x1) % (-0x3a7 + 0x1 * -0xb56 + -0x780 * -0x2) && aod > -0x154f * -0x1678 + 0xcf353c6 + -0x3 * 0x27cc493 - (-0x4f85 * -0x2478 + -0x1 * -0x9977504 + -0xd8fa247) ? 0x1f8bc6 * -0x9 + 0x1097127 + 0x10167bd * 0x1 ^ 0x13 * -0x9f881 + -0x22f * -0xa3e1 + 0x468830 : -0x20cb + 0x12fd * 0x2 + -0x4d0;
            break;
    }
    aoo = -0xbf8 + -0x22f7 + 0x2f01;
    while (aoo < -0x5d7 * 0x3 + -0x6dd + 0x18ac) switch (aoo) {
        case -0x823 + 0x77c * -0x5 + -0x2da1 * -0x1:
            aoo = aod > 0x204a + 0x349 * 0x1 + -0x2389 ? (0x15019 * -0x1 + 0x247d * 0x65 + 0x1b9b71) % (-0xef3 + -0x8a5 * 0x2 + -0x810 * -0x4) : 0xdf9 + -0x4 * -0x79 + -0xfb4;
            break;
        case -0x6a1 * -0x3 + -0x10b3 + -0x307:
            aoo = -0x1e0e + -0x296 + 0x20ee; {
                RenderHooked.String(Global.GetScreenSize()[(-0x230df + 0x3d725 + 0x7140) % (-0x26fa * -0x1 + 0x1 * 0x15bd + -0xb9 * 0x54)] / ((-0xb * 0x10038a9 + 0xe9c7e38 + -0x1 * -0x259b3a55) % (0x93c + -0x24b9 + 0x1b84)) - (-0x2f8b69e2 + 0x10a93a9e + 0x1 * 0x3f273f4d) % (0x15c2 + 0x852 + 0x1 * -0x1e0b), Global.GetScreenSize()[-0x29369 * -0x36 + 0x2 * -0x4bbc46 + -0x1 * -0xc8c1b4 - (-0x127ad9d * 0x1 + -0x6dcd * -0xb3 + 0x1 * 0x1974893)] / (-0x83 * -0x38cdf + 0x3bf89 * 0x67 + 0x7774f * -0x52 ^ -0x7c9bad + 0x4 * -0x586e4b + 0x2cd43c5 * 0x1) + (0x2168 + 0x2274 + -0x43c8), (-0x1d703 + 0x218ea + 0x1d59f) % (0x4 * 0x57e + 0x5c * -0x13 + -0xf21), '' + aod, [aof[(-0x90c5 * 0x4 + -0x3 * -0x11f75 + 0x1 * 0xfc3b) % (-0x1472 + 0x67 * -0x35 + -0xa72 * -0x4)], aof[(0x4f9530 + -0x39b07e + 0x12cbf7) % (0x9 * -0x36e + -0x1 * -0x2077 + -0x196)], aof[(0x27577f86 + -0x1f9516dc + 0x2172e0a0) % (-0xd * -0x256 + -0xbf9 * -0x2 + -0x3649 * 0x1)], -0x11b8 + -0x44 * -0x16 + 0xcdf], aog), RenderHooked.String(Global.GetScreenSize()[-0x9 * 0x8b9a42 + -0x354451c + 0x191 * 0x9f4d3 - (-0x81c0285 + 0xa111233 + 0x1cce9cd * 0x3)] / (-0xf4dc15 + -0x1 * 0x6ef83f + 0x252c342 ^ 0xf5a44 + 0x193e7 * 0x47 + 0x6f8f97) + (0x25db047 * 0x2 + -0x4fac41c + 0x4f66639) % (-0x64 * 0x55 + -0x28d * 0xd + 0x2 * 0x2132), Global.GetScreenSize()[0x18d * 0x229b + 0x13a1c56 + -0xb36567 - (0x142d * -0xda3 + 0xd31576 + 0xfc6d7e)] / (0x11502ec + 0x1 * -0x11b7f7e + -0xf56b8 * -0x10 ^ -0x1a37b71 + -0xdd4f2d + 0x36fb98a) + (-0x1648 + 0xd89 + -0x1 * -0x8c9), (0xdff3 * -0x1 + -0x34814 + -0x5 * -0x13fe9) % (0x2237 + 0x46f * 0x7 + 0x39 * -0x125), '.', [aof[(-0x1f590 + 0x11 * -0x2aae + 0x6e2a4) % (0x32 + 0x38 * -0x7f + 0x1b99)], aof[(0x162018 + 0x4f5753 * -0x1 + -0x1 * -0x61e7e4) % (0x3a5 * -0x3 + -0xd9b + 0x188d)], aof[(0x180414d1 + 0x8bd30c1 + 0x87403b8) % (-0x1b7e + 0x2119 + -0x594)], -0x1219 * -0x2 + 0xa4d * -0x1 + 0x2 * -0xc73], aoh);
            }
            break;
        case (-0x4fedf8 + -0x1 * 0x1f357f + 0xa * 0xf2ed0) % (0x1635 + 0x102 * -0x19 + -0x100 * -0x3):
            aoo = -0x47a * -0x2 + -0x2b * 0x2 + -0x42a * 0x2; {
                RenderHooked.String(Global.GetScreenSize()[0x7 * -0x1bc54f7 + 0x91347df + 0xa6ed7f7 - (-0x1 * -0x96bac4f + -0xd80df99 * 0x1 + 0xb71005f)] / (0x14116 * 0x13 + 0x27b6cf + 0x3a767f * 0x3 ^ -0x1 * 0x7b2ae3 + -0x52532 * 0x21 + 0x213e541) - (0x1f75 * 0x2ab + -0x11bf3d * 0xf + 0x153d550 - (0x6da6f9 + 0x164 * 0x16fb + 0x1 * 0xff1d8)), Global.GetScreenSize()[(-0xd02ea + -0x1278cb * 0x1 + 0x482c5e) % (0x117d + 0x121f + 0x2399 * -0x1)] / (-0x1a6615a + -0x1 * 0x1aec2ad + 0x44412f5 ^ -0x1979273 + 0x156bbf7 * -0x1 + 0x3dd3d56) + (0x5a * -0x2 + 0x1 * -0xaf3 + 0xbbb), -0x2 * -0x230f9d2 + -0xa99bf * -0x2d + -0x11cd2de * -0x1 - (0xa2b062d * 0x1 + 0x4 * 0x15df705 + 0x1612e32 * -0x6), '' + aod, [aof[(0xeb * -0x461 + -0x12f23 + 0x1 * 0x74bb4) % (0x21e9 + 0x1b3e + -0x3d24)], aof[(-0x19f * -0x24e6 + -0xaae86 * -0x3 + 0x74f65 * -0x7) % (-0x2264 * -0x1 + 0x34 * 0x74 + -0x39f1)], aof[(-0x1 * 0x4b134e2e + 0x63e1de3 + 0x9e6d9 * 0xb1d) % (-0xf * -0x19a + -0x1 * -0x447 + -0x1c46)], 0x7 * -0x481 + -0x120c + 0x3292], aog), RenderHooked.String(Global.GetScreenSize()[-0x75 * -0xb39fd + 0x54a419c + -0x30ff528 - (0x385a1ed * 0x3 + -0x6249152 + 0xe * 0x35ad30)] / (-0xc5f945 * -0x1 + -0x10415 * -0x123 + -0xfeae36 ^ 0x35 * 0x3af81 + 0x69b * 0x238a + 0xbf2757 * -0x1) + (0x2 * 0x85d693 + -0xc3cb2 * -0x53 + -0x330be7 * 0xb) % (0x29 * -0x8b + 0x13 * 0x117 + 0x196), Global.GetScreenSize()[0x131b1b * 0xc + -0x6da128 + 0x44bd32 - (0x3dc64b * 0x5 + 0xef2622 + -0x167a44c)] / (0x1d93f7d + -0x2 * 0xbdbae2 + 0x912535 ^ -0xfbaa0 * -0x16 + -0xd954 * -0x145 + -0x17f0278) + (0x2b3 * -0x7 + 0xf23 + 0x3cc), 0x16e6b3b + 0xa6ea543 + -0x4814369 - (0x1f153 * -0x293 + -0x45166da + 0x10ad6c98), '.', [aof[-0x7b909d7 + 0x4371879 + 0xaddbe73 - (0x1a3 * -0x1dfb4 + -0x4512ca4 + 0x204b * 0x74df)], aof[(-0x14b * -0xa37 + 0x1900c2 + 0x27aca) % (0xec * 0x7 + -0x8 * 0x4b0 + 0x1 * 0x1f0f)], aof[0xb649bf + 0x1 * 0xfc1d + 0x37a912 ^ 0x627439 + 0x4 * 0x23260d + -0xd * 0x245], -0x231b * -0x1 + -0x2 * -0x135b + 0x2 * -0x2469], aoh);
            }
            break;
    }
    aop = 0xd33 + -0x1858 + 0xb45;
    while (aop < 0x90c + -0xec2 * 0x1 + -0x1 * -0x638) switch (aop) {
        case 0x742 + 0x29 * -0x49 + -0x46 * -0x11:
            aop = 0x27c + -0x17f + 0x1 * -0x7b, aoq = -0x23c + 0x5fb * 0x4 + -0x1556;
            while (aoq < 0x1bcf + 0x5f5 + 0x5 * -0x69d) switch (aoq) {
                case 0x1914 * 0x1 + 0x1 * 0x221b + -0x3ad5:
                    aoq = jagowalking == ([null] == '') ? -0x113a + -0x1 * 0xb46 + -0x2 * -0xe71 : 0x1 * 0x17aa7c1 + 0x91146c + 0x167ac8f - (-0x49d7ec7 * 0x1 + 0x71cb * 0x426 + -0x9eb * -0xa09a);
                    break;
                case -0x537 + -0x3 * -0x16c + 0x155:
                    aoq = 0x2321 + -0x925 * 0x3 + -0x6ff; {
                        RenderHooked.String(Global.GetScreenSize()[0x1cd4abc + 0x1 * 0x3b33ff6 + 0x5 * 0x5f0d47 - (-0xb3cc7a0 + 0x1973591 * 0x5 + 0xaa488e0)] / ((0x4f779a17 + 0x5b2ff91 + 0x1 * -0x2bf5505e) % (0x651 + -0x159d + 0xf53 * 0x1)) + (0x159e5c + -0x16a51e * 0x1 + -0x1 * -0x29b76b) % (-0x5d1 * 0x1 + 0x10d8 + -0x582 * 0x2) - (-0xd2f + 0x100d + -0x2c2), Global.GetScreenSize()[0x15c22dc + -0x1c343 * 0x39 + -0x19a27 * 0x25 - (0x11e7c0f + -0x1d * 0xa5b74 + 0x2 * 0x6520b1)] / ((-0x338a905a + -0x18c21dd6 + 0x7581f77a) % (-0x2704 + -0x53 * -0x2f + 0x17ce)) + (-0x2 * 0x2083be + 0xd01e + 0x68e807) % (0x10 * 0x14d + 0x1175 + 0x2 * -0x1321) + (0x2139 + -0x40f * -0x1 + 0x1 * -0x2516), -0x89e7e1 * -0x15 + 0x8c1093 * 0x3 + -0x5986a19 - (-0x66e2a5b + -0x1 * 0x594939c + -0x33a6c82 * -0x6), 'JAG0WALK', [0x1 * -0xa289230 + -0x6da843 * 0x17 + 0x1b5e7d4a - (0xc88d935 * 0x1 + 0x4aa0116 + -0x147 * 0x7b41a), 0xdf4aaf6 * 0x1 + 0x670f845 + -0x684eb13 * 0x2 - (-0xad15af1 + -0x154b4c * 0x8e + 0x1dfcec2e), (0x317ff + -0x3694 * 0x3 + 0x5cbd * -0x1) % (0x2e * 0x4f + -0x1f08 + 0x10d9 * 0x1), aoe], aoj), RenderHooked.String(Global.GetScreenSize()[(-0x3d394 + -0x20333 + 0x7ee4d) % (0x23dd + 0x109d * 0x1 + -0x79 * 0x6f)] / ((-0x5 * -0x146efaf + 0x4e41b44f + 0x140fc * -0x22a4) % (-0xbe + 0xedc + -0x1 * 0xe17)) - (-0x8e * -0x37 + 0x25b1 * -0x1 + 0x74b), Global.GetScreenSize()[0x935886 + 0x1 * 0x16d6fe2 + -0x144671a - (-0x49fea0 + -0x21ce6 * -0x10 + -0x1 * -0xe4918d)] / (-0xbb26a8 + 0x17bd2a5 + 0x2e42f1 ^ 0x28 * -0x8e284 + -0x4f * 0x1d070 + 0x2e1a61c) + (-0x1 * -0x12e7 + -0xc75 + -0x640), (-0x28a19 + -0x2dd5d + 0x77efc) % (-0x1a1b + -0x2603 + 0x4021 * 0x1), 'JAG0WALK', [aof[(0x41 * 0x2a1 + -0x27574 + -0x1 * -0x3e219) % (0x938 + -0x1949 * -0x1 + -0x227e)], aof[(-0x3 * 0x5eb71 + -0x7602e + 0xd00a * 0x51) % (0x1c10 + -0xb47 + -0x10c6)], aof[0x1f3e13 + 0xec31fd + -0x1c8122 * 0x1 ^ -0x7dde68 + -0xd8dd30 + 0x245aa84], aoe], aoj);
                    }
                    break;
                case 0x29 * -0x144ef5 + -0x36405b4 + 0xa1813ad * 0x1 - (0xff2e * -0x1b0 + 0x37ca490 + 0x1a561c9):
                    aoq = -0x631 + 0x41c + 0x164 * 0x2, aor = 0x7f + 0x1 * -0x1619 + -0x5 * -0x45e;
                    while (aor < 0xc3b * 0x3 + 0x2f * 0x6c + -0x3802) switch (aor) {
                        case -0xb48 + -0xa * -0x2d1 + -0x10c9:
                            aor = -0x9ee * 0x1 + -0xbb1 + 0x1622; {
                                RenderHooked.String(Global.GetScreenSize()[(-0x15 * 0x9d5 + -0x1a * 0x99e + -0x1 * -0x3e00b) % (-0x17c6 + -0xc01 * -0x2 + -0x39)] / (-0x60f53 * -0x3 + -0xaa1e2 * -0x16 + -0x6ca9 * 0x1f ^ 0x11d5784 + -0x1d6a82b + -0x25 * -0xb7757) + (0xa5d3 * 0x25 + 0x23b5fd + -0x12fcd3) % (-0x1d35 + 0x9 * 0x2f + 0x1b91) - (0x1 * -0x30a + -0x1 * 0x15b7 + -0x4f9 * -0x5), Global.GetScreenSize()[(-0x4b4 * -0x331 + 0x3c62ec + -0x22b4b7) % (-0x75 * 0xf + -0x26c0 + 0x2 * 0x16cf)] / ((-0xdb * 0x5a91e9 + 0x13d9a1e0 + 0x62d679bd) % (-0x9db * -0x3 + -0x1 * -0xd67 + -0x1 * 0x2af1)) + (0x163321c + 0x13fd9 * -0xfe + -0x5c * -0x1a2e0 - (-0x3592 * 0x6e9 + -0xad3c * 0x4f + -0x26404b3 * -0x1)) + (0x1f39 + -0x1737 + -0xa * 0xc8), (0x110ec + -0x17ae1 + 0x2817b) % (0x25f4 + -0x272 * 0x5 + 0x1d * -0xe3), 'AUTO-DIR', [(0x38b36 + -0x3752 + 0xa * -0x1fa3) % (0x10b * 0x5 + -0x429 * -0x5 + -0x1a01), (0x1b * 0x1ceb + -0xec7e + -0x8c5 * 0x1) % (-0xc2 * -0x31 + 0x7a2 + 0xeeb * -0x3), (0x2f2fc * 0x1 + -0x3122b * 0x1 + 0x3 * 0xbce7) % (-0x5c7 + -0x1a09 + 0x1fd3), aoe], aoj), RenderHooked.String(Global.GetScreenSize()[(0x199 * -0x17b + -0x31085 + -0x3a * -0x2133) % (0x735 * -0x5 + -0x25ff + 0x4a0b)] / (-0x1 * -0xe5b577 + -0xd5cf48 + -0x1 * -0xdf08bf ^ 0x1100ce8 + -0x363ab9 + -0x4d * -0x4631) - (0x8df + 0xbe0 + -0x24b * 0x9), Global.GetScreenSize()[(0x21b54c + -0x4084de + 0x5d1 * 0xc4b) % (0x17e5 + -0x5 * 0x474 + -0x19e)] / ((0x4a09a3cb + -0x4e5c08a0 + 0x797e1 * 0x5ff) % (-0xc94 + -0xaa + 0xd45)) + (-0x19b2 + -0x1a05 + 0x33e9), (-0x58c9 * 0x7 + 0x1fb50 * -0x1 + 0xb8ed * 0x9) % (-0x217c + -0xcf4 + 0x2e73), 'AUTO-DIR', [aof[(0x33608 + 0x2e164 + -0x3ffe6) % (0x6a6 + -0x16c4 + 0x1021)], aof[(0x30bf * 0x73 + 0x4d6 * 0x383 + -0x3a6 * -0x7f) % (0x1294 + 0x2 * 0xd9a + 0x1 * -0x2dc5)], aof[(-0xbb35b0b * 0x1 + 0x3e * 0xd4ffc0 + -0xa2d * -0x2149) % (-0x177d + -0x232f + 0x3 * 0x1391)], aoe], aoj);
                            }
                            break;
                        case 0x64 * 0x5a + 0xb8a + 0x4 * -0xb9e:
                            aor = 0x1ba1 * 0x1 + -0x411 * 0x3 + 0x39 * -0x43; {
                                RenderHooked.String(Global.GetScreenSize()[0x6 * 0x83bb1c + 0xc6d357 + 0x2 * 0x1bf4b8b - (-0xe1d948b + 0x6abaebe + 0x1a * 0x91c1f5)] / ((-0x31c96388 + -0x20a08c9d + 0x7b9f396f * 0x1) % (0x1cea + -0x955 * -0x3 + -0x38e2)) + (-0x2e27c7 * -0x1 + 0x2d9776 + -0x2 * 0x19874a) % (0x269f + -0x1 * -0x25f7 + -0x4c93) - (-0x144d + 0x1585 + -0x11f), Global.GetScreenSize()[(-0x1 * 0x294b9 + 0x15ccf * -0x2e + 0x69f294) % (-0x1a4 + 0xae * -0x26 + -0x3ed * -0x7)] / (0xb1580 + -0x16fbfa * 0xe + 0x225a11a ^ -0xb35d25 + -0x154b93 + 0x1b797a4) + (-0x2be738 + -0x2805 * -0x107 + 0x1e3f2 * 0x17) % (0x1 * 0x24a + -0x173 * -0x11 + -0x1aea) + (-0x1 * -0x1be5 + 0x3d4 + -0x1f87), (0x1366e + -0x43 * -0x801 + 0x1372b * -0x1) % (0x968 + -0xb * -0x79 + -0xe98), 'JAG0YAW', [(0x2c88a + 0x739a * -0x2 + 0x3630) % (0x777 + -0x3 * 0xc88 + 0x1e24), 0x7058f58 + -0x53ebbfb + 0x81e828 * 0xb - (0x4fd * 0x1c65 + -0x80d89b5 + 0xea5b * 0x103b), (-0x2 * -0x7471 + 0x1 * -0xf266 + 0x2210a) % (0x65 * 0x63 + -0x2 * -0x1265 + -0x4bd6), aoe], aoj), RenderHooked.String(Global.GetScreenSize()[0x2 * -0x563059 + 0xfb * -0x2ee7 + 0x8362a44 - (-0x50d90e0 + -0x9f43 * 0x142f + 0x18f7d742)] / (-0xf71c33 + 0x27c * -0x2a21 + 0x24eb51d ^ -0x4 * 0x1cef02 + 0xd * 0x94062 + -0x7d033 * -0x1e) - (0x1 * -0x12bd + -0x26ab * -0x1 + -0x13d5), Global.GetScreenSize()[-0x162ff46 + 0x114da * -0xf2 + -0xa10488 * -0x5 - (-0xc4f0f8 + 0x18f433 + 0x1685e12)] / ((0x1 * -0x1b0a3b54 + 0x1bf1b91 * -0xd + -0x29 * -0x237e683) % (-0xd46 + -0x57 * 0x9 + 0x105c)) + (-0x3 * 0x56d + 0x4ff * 0x7 + 0x4a * -0x40), 0x4f08bfa + 0x2 * -0x3a4104f + 0x9b361b9 - (0xe52648e + -0x1bf85d3 * -0x1 + -0x8b61d4c), 'JAG0YAW', [aof[-0xe2fd611 + -0x4fe3c90 + -0x1054d87 * -0x1a - (-0x17fe76f + 0xe66a960 + -0x58af4dc)], aof[(-0x4b31a9 * 0x1 + -0x1df5fd * -0x2 + 0x37f658) % (-0x1 * -0x23d1 + -0xbdb + -0x1 * 0x17f3)], aof[0xa * 0x203bff + 0x1b84120 + -0x20baa28 ^ 0x3be88b + -0x8de81 + 0xbbe4e2], aoe], aoj);
                            }
                            break;
                        case -0x18 * 0x16 + -0x15f8 + 0x611 * 0x4:
                            aor = UI.GetValue(['Rage', 'Anti Aim', 'General', 'Key assignment', 'freestanding']) == ([null] == '') && UI.GetValue(['Rage', 'Anti Aim', 'General', 'Key assignment', 'legit desync']) == (NaN === NaN) && jagowalking == (-0xb29 * 0x1 + 0xe18 + -0x2ee === '1') ? 0x9ad + -0xf35 + 0x5a1 : -0x5c * 0x59 + 0x1059 + -0xfdd * -0x1;
                            break;
                    }
                    break;
            }
            break;
        case 0x14c0 + -0x6a * -0x49 + -0x32b8:
            aop = 0x698 * -0x1 + -0x163d * -0x1 + 0x7d * -0x1f; {
                RenderHooked.String(Global.GetScreenSize()[0xeac48a4 + 0x25e8955 + -0x26bc139 * 0x4 - (-0x6bf579e + -0x12 * -0x82c3f3 + 0x4e95d9d)] / ((-0x19 * 0x34638f1 + 0x5c22901 * -0xd + 0x147290 * 0x9ae) % (-0x45 * 0x15 + -0x3e6 + 0x996)) + (-0x1 * -0x152bd7c + -0x28c * -0x24da + 0x1 * -0xf43766 - (-0x5 * -0x42b1d + -0x7d99 * 0x1a1 + -0x7 * -0x352923)) - (-0x3d * -0x62 + -0x1c27 + -0x1a2 * -0x3), Global.GetScreenSize()[(0xc64f * -0x3d + -0x8cfd3 * -0x9 + 0x8a311 * 0x1) % (0xebf + -0x8f9 + -0x5 * 0x127)] / (0xd57283 + 0xa69135 + -0x8d14ca ^ -0x45 * -0x2e4c7 + -0x90d * 0x310d + 0x1e337f2) + (0x2b * -0x33aa3 + 0x4e59f * -0x49 + 0x28b9e * 0x10d - (-0x16cb5a0 + -0x6e9b79 * 0x1 + 0x297b266)) + (-0x1fa3 + 0x1 * -0x17f5 + 0x37ca), 0xbb147f6 + -0xd63373 + -0x37f476e - (-0x9de * -0x13b5b + 0x1a01f08 + -0x66bfddd), 'LEGIT-AA', [(-0x2efae + 0x41fe5 + 0x38f * 0x41) % (0x1ec3 + 0x120c + -0x30cc), 0x14ffa46 * 0x9 + 0x13e822d + 0xb * -0x84976a - (-0x1 * -0x5a9eb4f + 0x1 * -0xd0be95 + -0x1628d7 * -0x1d), -0xf61f * -0xd12 + -0x106603f * -0x4 + -0x94e9515 * 0x1 - (-0x4d695e + 0x2 * 0x4d26a6f + -0x1fb9e6b), aoe], aoj), RenderHooked.String(Global.GetScreenSize()[(-0x10fd0 + -0x1847 + -0x33f9d * -0x1) % (-0x144f + -0x2537 * 0x1 + 0x46d * 0xd)] / (0xf844aa + -0xb * -0x2936dd + 0x1 * -0x1ceb13b ^ -0x1394c1e + -0x41fe73 * -0x6 + 0x9c4458) - (-0x1c02 + -0x1 * 0x2015 + -0x1e18 * -0x2), Global.GetScreenSize()[0x3df285 + 0x1 * 0xd27e2c + -0x3 * 0x1c0521 - (-0x1725a3 * -0x4 + 0xe926e1 + 0xe8e0 * -0x97)] / (0x950 * -0x4cd + -0x2d5739 + 0x148fb37 * 0x1 ^ -0x1c74561 + -0xb6c85c + -0xd63 * -0x4183) + (-0xeb7 * -0x2 + -0x125e + -0x6b * 0x1a), (0x8907 + -0xdc8f + 0x26b0e) % (-0xb85 * -0x3 + -0x1885 + -0xa07), 'LEGIT-AA', [aof[(0x27e4e * 0x1 + 0x2ca46 + -0x3310e) % (-0x5 * 0x47f + 0xd11 + 0x1 * 0x96d)], aof[(-0x3c289f + 0x201aa4 + -0x1 * -0x44bea4) % (0x8c * 0x9 + -0x12f * 0x8 + -0x48f * -0x1)], aof[(0xa * -0xf2b7e3 + -0x13557bc8 + -0x2eaea2a * -0x18) % (0xf8 + 0xa43 + 0x1 * -0xb34)], aoe], aoj);
            }
            break;
        case 0x1d6f + -0x1677 + -0x6d8:
            aop = UI.GetValue(['Rage', 'Anti Aim', 'General', 'Key assignment', 'legit desync']) == !![] ? 0xd6f * 0x1 + -0x1 * -0x1de7 + 0x397 * -0xc : -0x123 + 0x257c + -0x4a * 0x7d;
            break;
    }
    RenderHooked.GradientRect(Global.GetScreenSize()[0x5 * 0x2c6cb2d + 0x190f6fb * 0x9 + -0x149ed99f - (0x71b89b0 * 0x1 + -0x205f381 + 0x24636e6)] / ((0x47696c33 + -0x4616cc * 0x30 + 0x9da5 * -0x1bb5) % (0xfd8 + -0xedd + -0xf4)) + -aod * ((0x132bca1e * -0x2 + 0x3249f003 + 0x1 * 0x1d42ed83) % (0xb * 0x285 + 0x8a7 + -0x2457)) + aod + (0x1e4c7ea8 + 0x4060347a * 0x1 + 0x2eb6f8 * -0x125) % (-0x5 * -0x1 + 0x7 * 0x36d + -0x17f9), Global.GetScreenSize()[-0xdb8f88 + -0x708a44 + 0x1b * 0x1346ee - (-0x155a4cf + -0x1b992f + 0x22d9f4b)] / (-0x161fdec * -0x1 + -0x1871597 + 0x1140699 ^ 0x70657d * -0x3 + 0x850b31 * 0x1 + -0xdd8a19 * -0x2) + (-0x17b + -0x1 * 0x5bb + 0x52 * 0x17), aod, 0x2ff904d * 0x2 + 0x23 * -0x182073 + 0xc0b7db - (-0x5a6e16a + 0x2c * -0x85e29 + 0xa8a792f), (-0x14c * 0x1c2b + -0x3d2f91 + 0x8a67fe) % (-0x6 * -0x8b + -0xe16 + 0x5 * 0x22b), [aof[-0x25 * -0x5bbb23 + 0x4e76232 + -0xacda12c - (0xad4cd * 0x4 + 0x14a9f01 * 0x3 + 0x3509cde)], aof[(0x745ab + -0x8e68d * 0x2 + 0x333818) % (0x1d12 + 0x81d + -0x252c)], aof[0x41ce28 + -0x42 * -0x10fcb + 0x670e70 ^ -0x1d35275 + -0x1a8e6e1 + 0x46b2842], -0x1 * -0x4c6eb55 + -0x3 * -0x3f01dc3 + -0x93b7789 - (0x2a1 * -0x5211d + -0x6d * -0x97eab + 0x10cceb83)], [aof[0x1c1a29e * -0x8 + -0x83e6b33 + -0x3b4e9a7 * -0x8 - (-0x36d * -0x3df8a + -0x1867dfa + -0x46280b3)], aof[-0x40d71 * 0x2 + -0x5a2b3 * 0x23 + -0x172919 * -0x11 - (0x1 * 0xdc8635 + 0xfbe698 + -0x11c0b80)], aof[0xd13950 + -0xf * 0x11f112 + 0x4ab56b * 0x4 ^ 0x13c1d82 + 0x1cbbef7 * 0x1 + -0x218ed8d], -0x5b9 + 0x22d4 + -0x202 * 0xe]), RenderHooked.GradientRect(Global.GetScreenSize()[(0x2 * 0x1c6d7 + -0x3 * -0x835a + -0x30036) % (-0x12ea + -0x1 * 0x669 + 0x1956)] / (-0x1d0fab3 + -0x1b0d04e + 0x29d * 0x1b2fb ^ 0x5 * 0x2daad7 + -0xa1113b + 0xaba9f4 * 0x1) + -aod * (-0x4 * 0x4832e1 + 0x1 * 0x17bc04d + 0x93fa25 ^ -0x4ef601 + -0xc5 * 0x4715 + 0x1 * 0x1749816) + aod * (-0xca96c8 + 0x35a9d * 0x7 + 0x1a20b6b ^ -0x196266a + 0x118a86 * -0xb + 0x68c123 * 0x8), Global.GetScreenSize()[0x1a5 * -0x1055 + 0x75b85f + 0x6184b8 - (0x11e4490 + -0xc665e * -0xc + 0x1 * -0xf6afab)] / ((0x77d1c5c + -0x1 * 0x374cd057 + 0x11cdcc41 * 0x5) % (-0x41e + 0xb57 + -0x732)) + (-0x17 * -0x18e + -0x1126 + -0x1274), aod, (0x1fbbb * -0x31 + -0x34a * 0x58b9e + 0x1971ba40 * 0x2) % (-0xb95 + 0x1 * 0xf82 + 0x2 * -0x1f2), 0xcf300 + 0x13f1afe + -0x8facb0 - (-0x764367 * -0x1 + 0x564e9b * -0x1 + 0x9c6c81), [aof[-0x7f9 * 0x15746 + -0x398a6f3 * 0x3 + -0x3b * -0x7d20cc - (-0x34836 * -0x443 + 0x8 * -0x13b5a40 + 0x339e0f3)], aof[(0x1 * 0x37d77 + -0x338d73 + 0x11c021 * 0x5) % (0x1ec2 + 0x5 * -0x185 + -0x1 * 0x1726)], aof[(-0xcf6e9 * 0x61f + 0x17 * 0x1685f4a + -0x1 * -0x583015db) % (-0x173 * 0x15 + 0xa7f * 0x2 + -0x328 * -0x3)], 0x7c7 + -0x2 * 0x99c + 0xc70], [aof[-0x24e9350 * 0x6 + 0x1ad6f8 * -0x1a + -0x5a2f * -0x43eb - (0x1 * 0x834a632 + -0xb23bf3e + 0xa4ae621)], aof[(-0x34dc2 * 0x14 + 0x4fea0a + 0x19457 * 0x11) % (-0x2312 + 0x1 * 0x40f + -0xd1 * -0x26)], aof[-0x516ebc * 0x3 + -0x1 * 0x1a60e1 + 0x1ad251 * 0x13 ^ 0x59933f + 0x4cf4f * -0x3 + 0xa3c99a * 0x1], (-0x1 * -0x68b9 + -0x319bd * 0x1 + 0x4c88a) % (0x8 * 0x4db + 0xe71 * 0x1 + -0x2 * 0x1aa3)]), aos = -0x1 * -0x20c6 + 0x12db + -0x3 * 0x1120, aot = -0x14f7 + 0x1e95 + -0x1 * 0x959;
    while (aot < 0x1db8 + 0x1be4 + -0x3951) switch (aot) {
        case -0x65 * -0x32 + -0x542 * -0x1 + -0x18b7:
            aot = UI.GetValue(['Rage', 'General', 'General', 'Key assignment', 'dmg override']) ? -0x1bce + 0x4a9 + 0x176e : 0xeb * -0xf + -0x5 * 0x24f + 0x199b;
            break;
        case -0x18fa + -0x1dc0 + -0x1 * -0x3703:
            aot = -0x1 * -0x247f + -0x2 * 0x3bf + -0x1cb6; {
                RenderHooked.String(Global.GetScreenSize()[0x2c4e9 * -0x4de + 0x1107 * 0xc37 + 0x140636a2 - (-0x6ab435b * 0x1 + -0xa2444a5 + 0x182b5515)] / ((-0x1 * -0x35d817bd + -0x2f0a395b + 0x22676ae8) % (-0x1736 + -0xabc + -0xdf * -0x27)) + (0x41da16 + 0x59 * -0x2867 + -0xb1d9e) % (0x1e * -0xa4 + -0xb * 0x15b + 0x2224) - (0x2695 * 0x1 + -0x94 * -0x3e + -0x6c3 * 0xb), Global.GetScreenSize()[0x858 * -0xa25 + 0x1396a14 + 0x25 * -0x11776 - (0xce639b + 0x35ade3 * -0x6 + 0x13ba * 0xf6a)] / (0x68f * -0x321b + 0x1417988 + 0x517f * 0x305 ^ -0x1 * 0xfb3f97 + -0xf0b * -0x340 + -0x1ed3 * -0xe51) + (-0x376885 * 0x1 + -0x2 * -0x2fd1f2 + 0x9425ef - (0x1173227 + -0xec455f + 0x1 * 0x917485)) + aos, -0xc8586ed + 0x6b860e6 + 0xd28f31c - (0x2 * -0x3381c6d + -0x22824ef + -0x6e6206 * -0x25), 'dmg', [-0xa4825a3 + -0xc8f0fc0 + 0x724 * 0x43aae - (0x3bb25ad + 0x138e * 0x1ab2 + 0x196a2ac), (-0x3 * 0x15089 + -0xb646 + 0x6bf67) % (0x38 * -0x39 + -0x7 * 0x533 + -0x170 * -0x22), (0x1 * 0x1e70d + -0x13d83 * -0x1 + -0x10d0a) % (0x4a * 0x8 + -0x2 * -0xffb + -0x2243), aoe], aok), RenderHooked.String(Global.GetScreenSize()[-0xd255151 + 0x6f90a58 + 0x24158ad * 0x6 - (-0x88d1a98 + 0x1 * 0xdf32445 + -0x7c * -0x40be6)] / ((0x16c * -0x2271eb + 0x1 * -0x3ed4ae0f + 0x9903f17d) % (-0x1 * 0x889 + -0x1469 + -0x1 * -0x1cf9)) - (-0x2dd * -0x1 + 0x11f6 + -0x14c7), Global.GetScreenSize()[(-0xec * -0x1b4b + 0x4c6774 + -0x3cdfef) % (-0x9e * -0x27 + -0x1b0e + 0x2ff)] / ((-0x915de * -0x9a + 0x1 * 0x4f55819b + 0xf7fc71 * -0x2d) % (-0x1437 + 0x7 * -0x218 + 0x22e6)) + aos, (0x20212 + -0x13875 + 0x14de9) % (0x101 * 0x26 + -0x1e8f + 0xa * -0xc2), 'dmg', [aof[0x80918db * -0x1 + 0x1 * 0x1235c62 + 0xe41898e - (-0xe2c7fcf + 0x51daea4 + -0x1434740 * -0xd)], aof[-0x285e7 * 0x4f + -0x30a * -0x365e + 0xb * 0x1439a1 - (-0x496f * 0x189 + -0x4c7 * -0x3d15 + -0x3 * -0x319cb)], aof[(-0x5 * -0xd86371f + -0x19517 * -0x151f + 0x3bd5bb1a * -0x1) % (-0x623 + -0xc38 + 0x1262)], aoe], aok);
            }
            break;
    }
    var anz, aoa, aob, aoc, aod, aoe, aof, aog, aoh, aoi, aoj, aok, aol, aom, aon, aoo, aop, aoq, aor, aos, aot;
}
flip = null === undefined;

function dsal23422232432323232322223342323223232223233434232342342342323422342342344234332k312323() {
    var a = a;
    aou = dsal23422243234232342342342323422342342344234332k312323(Math.abs(Math.round(Local.GetRealYaw() - Local.GetFakeYaw())), (0x3b717 * 0x1 + -0x38cc5 + 0x1ed34) % (0x243 * 0xa + 0xbd + -0x1758), -0x258d + -0x11c * 0xd + 0x3433), aov = Entity.GetLocalPlayer(), aow = Entity.IsAlive(Ragebot.GetTarget()), aox = left_distance = dsalkj2k3(aov, [0x28e7634 + -0x2f6e99 * 0xa + 0x6a7a8db - (-0x360bec1 + 0x33bce79 + 0x35 * 0x243d89), Local.GetViewAngles()[(-0x4a7952 + 0x1bd48f + 0x57556c) % (0x233c + 0x7 * -0xbe + 0x1 * -0x1e07)] - (-0xd * -0x26b + -0x1484 + -0xad4)]) - (right_distance = dsalkj2k3(aov, [-0x337a25b * 0x1 + -0x637c9 * -0x196 + 0xb6f6aa - (-0x1 * 0x587649f + 0x1fa6e3f * 0x7 + 0x90b * -0x1b2f), Local.GetViewAngles()[-0x6c61f * -0x13 + -0x1 * 0x172396f + 0x2e98 * 0x93a - (-0x36db49 + 0x4ffe6e + 0xa33e28)] + (-0x163b + -0x136 + -0x3 * -0x7d8)])), aoy = dsalkj2k3(aov, [(0x1f3 + -0x1bb * 0x6e + -0x2d3ed * -0x1) % (0x2b1 * -0x8 + -0x2149 + -0xf2 * -0x3a), Local.GetViewAngles()[(-0x3c947a + -0x278f8d + 0x8cd4b0) % (-0x1dff + 0x998 + 0x146a)]]), aoz = UI.GetValue(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW', 'jag0-walk switch']), apa = dsal2342234232342342342323422342342344234332k312323((0x305bb + -0x40d16 + -0x3 * -0x10a4b) % (0x1f33 + -0x1061 + -0xecf), (0x9532 * 0x4847 + -0x2e38f165 + 0x2d4ec9d1) % (0x1290 + -0xd2e + -0x1 * 0x55b)), apb = dsal2342234232342342342323422342342344234332k312323(-aoz, aoz), aou = dsal23422344234332k312323(aov), apc = UI.GetValue(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW', 'traced lines distance delta']), apd = UI.GetValue(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW', 'inactive desync delta']), ape = UI.GetValue(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW', 'fake offset divider']), apf = UI.GetValue(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW', 'real offset divider']), apg = UI.GetValue(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW', 'jitter']), aph = 0x162b + 0x29 * 0x75 + -0x28d6;
    while (aph < 0x1057 + -0x3d6 + -0xc06) switch (aph) {
        case 0x1b28 * 0x1 + -0x3f7 + -0x1 * 0x171f:
            aph = UI.GetValue(['Rage', 'Anti Aim', 'General', 'Key assignment', 'legit desync']) == (null == undefined) ? -0x1b57 + -0x2169 + 0x1 * 0x3ce8 : 0x1de3 + 0x6 * 0x32d + 0x3096 * -0x1;
            break;
        case 0xf05 + -0x23d9 + 0x4 * 0x53f:
            aph = -0x1075 + -0x800 + 0x18f0; {
                api = -0x49 * 0x31 + -0x159 + -0x1 * -0xf97;
                while (api < -0x1985 + 0xf90 + 0xa8b * 0x1) switch (api) {
                    case 0x10cb + 0x1cbc + -0x2d5f:
                        api = -0x47b * -0x3 + -0x1 * 0x140e + 0x61 * 0x13, UI.SetValue(['Rage', 'Anti Aim', 'Directions', 'At targets'], (0x19169b + 0x25cb8a + -0x16317c) % (-0x18d3 + 0x1ee7 + -0x611));
                        break;
                    case 0x10ab * 0x1 + -0x458 + -0x2d * 0x44:
                        api = -0x1883 + 0x662 * -0x5 + 0x3903, UI.SetValue(['Rage', 'Anti Aim', 'Directions', 'At targets'], -0x498a6c8 + 0x18546de + -0x5 * -0x2163c33 - (-0x1 * 0x567cc71 + 0x2f * -0x20fb3 + -0x1 * -0xd247b63));
                        break;
                    case -0x24d9 + -0xc11 + 0x312f:
                        api = UI.GetValue(['Config', 'JAGO-YAW', 'JAGO-YAW', 'legit desync at-targets']) == !![] ? -0x1 * 0x5b + 0x2396 + 0xdb * -0x29 : 0x20d5 + -0x136 * -0x1 + -0x21ac;
                        break;
                }
                UI.SetValue(['Rage', 'Anti Aim', 'Directions', 'Auto direction'], 0xcd7343b * -0x1 + -0x4620134 + -0xe * -0x1c1802e - (-0x1e * 0x78cf04 + 0x7f * -0x698e7 + -0x635e * -0x3fdd)), UI.SetValue(['Config', 'Cheat', 'General', 'Restrictions'], (0x19ee1 * 0x2 + -0x3faa2 + 0x1 * 0x2d466) % (0x4 * 0x52d + 0x2 * -0x2fb + -0x3 * 0x4e9)), UI.SetValue(['Rage', 'Anti Aim', 'Directions', 'Yaw offset'], 0x59e * 0x1 + -0x5 * 0xa4 + 0x49 * -0x6), UI.SetValue(['Rage', 'Anti Aim', 'Directions', 'Jitter offset'], 0x464e111 + -0x600d70e + 0x8f7c312 - (-0x3103b9c + -0xaa5f338 + 0x1511fbe9)), apj = (0x8042ed3 * -0x1 + -0x1454ac3 * 0x3 + 0x1037b639) % (0x141 * 0x3 + 0xa * -0x347 + -0x4 * -0x743);
                while (apj < -0x14d + -0x2c * -0xad + -0x1bd3) switch (apj) {
                    case 0xec7 + -0x267 + -0xc2a:
                        apj = -0x23e8 + 0x118b + 0x653 * 0x3, UI.SetValue(['Rage', 'Anti Aim', 'General', 'Pitch mode'], (0x2ec78 + 0xab2d + -0x1801f) % (-0x198e + -0x1dad + 0x373e));
                        break;
                    case 0x112a + -0x64e + -0x1 * 0xaa0:
                        apj = -0x4c7 + -0x2095 + 0x25f8, UI.SetValue(['Rage', 'Anti Aim', 'General', 'Pitch mode'], (0x1 * 0x4dcc87 + 0x3bb6e2 + -0x60d2c0) % (0x24bd * -0x1 + 0x2 * -0x9d2 + 0x3864));
                        break;
                    case 0x1dcd40f * 0x1 + -0x23f * -0x1702f + -0x17bbd58 & -0x734fdfe + -0x121 * 0x61809 + 0x1279c744 * 0x1:
                        apj = UI.GetValue(['Config', 'JAGO-YAW', 'JAGO-YAW', 'freestanding on edge']) == (NaN !== NaN) && aoy <= 0x26a7 + -0x18b * -0x4 + -0x2cab ? 0x1 * -0x131 + -0xf8c + 0x37 * 0x4f : 0x3 * 0xaf7 + -0x1d99 * 0x1 + 0x4f * -0xa;
                        break;
                }
            }
            break;
        case 0x3 * 0x545 + -0x1c62 + 0xcee:
            aph = 0x22f + 0x2688 + -0xa0f * 0x4; {
                UI.SetValue(['Config', 'Cheat', 'General', 'Restrictions'], -0xeab142 + -0xd39f06a * 0x1 + -0x31258f7 * -0x7 - (0x6a * 0x20a781 + -0x360c176 + -0x2c8ccdf)), UI.SetValue(['Rage', 'Anti Aim', 'Directions', 'At targets'], (-0x425f12 + 0x3 * 0x18ed30 + 0x20482b) % (-0x22 * -0x121 + 0xeb * 0x20 + -0x43bf)), apk = -0x7c7 + 0x1542 + 0x9a * -0x16;
                while (apk < -0x1bde + 0x278 + 0x19d8) switch (apk) {
                    case -0x14 * 0xb4 + 0x69a + 0x7a2:
                        apk = 0x727 + 0x161b * 0x1 + -0x1cd0, UI.SetValue(['Rage', 'Anti Aim', 'Directions', 'Yaw offset'], -0x67ad49f + 0x3f10bcc + 0x9e595e8 - (0xc4b3620 + 0x1c * -0x153dac + 0x3 * -0xdee369) - dsal2342234232342342342323422342342344234332k312323(-apg, apg));
                        break;
                    case -0x20ff + -0x65 * -0x1 + 0x20d9:
                        apk = UI.GetValue(['Rage', 'Anti Aim', 'General', 'Key assignment', 'Slow walk']) == (NaN === NaN) ? 0xee6 + 0x1 * -0x4f + -0x1 * 0xe6b : -0x1f1b + 0x1 * -0x1d3f + -0x57f * -0xb;
                        break;
                    case 0x244d + 0xf89 * 0x1 + -0x33bb:
                        apk = -0x1e2 * -0x13 + 0x1d54 * -0x1 + -0x40 * 0x18, UI.SetValue(['Rage', 'Anti Aim', 'Directions', 'Yaw offset'], 0x1567 * -0x2a43 + 0x22fb500 + 0x8b4980a - (0x517f0c7 + 0x7ab0b23 + -0x5672ed5));
                        break;
                }
                UI.SetValue(['Rage', 'Anti Aim', 'Directions', 'Jitter offset'], 0xd074770 * 0x1 + -0x677477a + 0xcbcd1f - (-0x4136ef1 + 0x2c0c6d * -0x49 + 0x17fec71b)), UI.SetValue(['Rage', 'Anti Aim', 'General', 'Pitch mode'], (0x96fb9 + -0x1fd1d8 + 0x3f12c8) % (-0x2064 + -0x1906 + 0x396d)), apl = 0x1 * 0x24cd + 0x1f3d + -0x43cd;
                while (apl < 0xfa3 + 0x16d * 0x1b + -0x35d7) switch (apl) {
                    case 0x15d4 + -0x889 + -0xd0e:
                        apl = UI.GetValue(['Rage', 'Anti Aim', 'General', 'Key assignment', 'freestanding']) == (null == undefined) && jagowalking == ([-0x2536 + 0x6b8 + 0x1e7e] == '') && dsal24234332k312323(aov) == (null === undefined) && dsal22344234332k312323(aov) == ![] || aoy <= -0x1 * 0xcde + 0x19d7 * -0x1 + 0x26dd && jagowalking == (0x18a3 + -0x10d4 + -0x7ce === '1') && dsal24234332k312323(aov) == ![] && dsal22344234332k312323(aov) == (null === undefined) && UI.GetValue(['Config', 'JAGO-YAW', 'JAGO-YAW', 'freestanding on edge']) == !![] ? -0x443 * -0x1 + -0xf53 + 0x5a4 * 0x2 : 0x707 * 0x5 + -0x1279 + -0x1074;
                        break;
                    case 0x3da + -0xe7 * 0xd + 0x817:
                        apl = 0x1790 + -0xaa3 + -0xca2; {
                            UI.SetValue(['Rage', 'Anti Aim', 'Directions', 'Auto direction'], 0xc4029be + -0x220fb92 * -0x1 + -0x705583b - (-0x803b60d + -0x36aca6b + 0x3 * 0x6436f2f));
                        }
                        break;
                    case 0x20df + 0x18bf + 0x991 * -0x6:
                        apl = 0x5f * 0x5 + 0x1624 + -0x2 * 0xbda; {
                            UI.SetValue(['Rage', 'Anti Aim', 'Directions', 'Auto direction'], (0xb897b + 0x3b1e84 + -0x1df756) % (-0x3 * 0x1b6 + -0x6 * 0x61b + 0x29c7));
                        }
                        break;
                }
            }
            break;
    }
    apm = -0x1 * 0x1a74 + 0x13a8 + 0x6d7;
    while (apm < 0x17ee + -0x38f * 0x7 + -0x15 * -0x10) switch (apm) {
        case -0x11b8 + 0x106 * 0x22 + -0x10cf:
            apm = -0x15 * -0x20 + -0x1396 + 0x114b; {
                jagowalking = [0x25f9 * 0x1 + -0x62f + 0x1a * -0x139] == '', apn = 0x14 * -0x9f + 0x29 * 0x31 + 0x4c6;
                while (apn < 0x3de * -0x4 + 0x23b * 0x4 + 0x6d1 * 0x1) switch (apn) {
                    case -0x1 * -0xad4 + 0x8b * 0x35 + -0x39 * 0xb1:
                        apn = -0x1ce6 + -0x6a5 + 0x23d0; {
                            apo = 0x8 * 0x79 + -0x1 * -0x1d73 + -0x20f0;
                            while (apo < -0x1c47 + 0x1 * -0x1bf4 + 0x38b3) switch (apo) {
                                case -0x5f * -0x11 + -0x7f4 + 0x4 * 0x76:
                                    apo = 0x2011 + -0x5d5 * -0x3 + -0x8 * 0x623; {
                                        AntiAim.SetOverride(-0x1 * -0x88fdd9 + 0x1 * -0x234633 + 0x56a9a8 - (-0x1 * 0xc8c1dd + 0xc * 0xb84f5 + 0x9a673 * 0x1a)), AntiAim.SetFakeOffset((0x5577 + 0x4e05 * -0x9 + 0xc00a * 0x6) % (-0xa4 * 0x2f + 0x1a39 + 0x2 * 0x1f3)), app = 0x1921 * -0x1 + 0x4 * 0x3da + 0xa10;
                                        while (app < -0x1d3f * -0x1 + -0x1 * 0x2059 + 0x3cd) switch (app) {
                                            case 0x1 * -0x24b5 + -0xe3 * -0x3 + -0x2263 * -0x1:
                                                app = apa == -0xc8a800c + -0xe8521bc + -0x907321 * -0x3d - (0x1a5 * 0x277ae + 0x1 * -0xd08ef0d + 0x82af57e * 0x2) ? -0x6d16e58 + -0x1d78f8f * -0x2 + 0x8419b9e ^ 0x1 * -0x677bf2d + 0x7a0c0e3 + -0x1 * -0x3f64aab : -0x1 * 0x642 + 0x7b1 * 0x5 + -0x2021;
                                                break;
                                            case (-0x627a06b + 0x3ec7 + -0x1 * -0xb3807f3) % (-0x9 * 0x2ea + 0x2338 + -0x8f8):
                                                app = -0xaf + 0xa22 * 0x1 + -0x8c0, AntiAim.SetRealOffset(0x1 * -0x931 + 0x1de * -0x8 + -0x51 * -0x4d);
                                                break;
                                            case 0x3 + 0x1d91 + -0x1d82:
                                                app = 0x4b * -0x10 + -0x1228 + 0x178b, apq = 0x1849 + 0x1980 + 0x3172 * -0x1;
                                                while (apq < -0x1b0 + 0x2 * 0xc3c + -0x1651) switch (apq) {
                                                    case -0x166d + 0xb * 0xd9 + -0x2a7 * -0x5:
                                                        apq = 0x1a92 * 0x1 + 0x1 * 0x1c2d + -0x48 * 0xc1, AntiAim.SetRealOffset(-(0xdf * 0x4 + 0x1d11 + 0x2051 * -0x1));
                                                        break;
                                                    case -0x5c * 0x53 + -0x314 * 0xa + -0x3cf3 * -0x1:
                                                        apq = apa == 0x5fb8a7 + 0x16d6546 + -0x110bc9f - (0x143545e + 0x104cfd4 + -0x18bc2e5) ? 0x3 * 0x737 + -0x16e5 + 0x169 : 0x20d1 + 0x97 * -0xe + -0x1818;
                                                        break;
                                                }
                                                break;
                                        }
                                        AntiAim.SetLBYOffset(-0x7 * -0x2085c82 + -0x1 * 0x558cd3e + -0x185ed3b - (-0x15d4242 + 0x2 * 0x32d85c0 + 0x25e03d7)), side = (0x7dc269d + -0x993b * 0x20f + -0x1e9b37d) % (-0x24ed + 0x1997 * 0x1 + 0xb5d);
                                    }
                                    break;
                                case 0x6 * 0x5dd + -0x1e35 + 0x1 * -0x4ae:
                                    apo = UI.GetValue(['Rage', 'Anti Aim', 'General', 'Key assignment', 'legit desync']) == (NaN !== NaN) ? 0x40 * -0x3a + -0x2 * -0x8c7 + -0x11 * 0x2b : -0x111 + 0x258f + -0x2475 * 0x1;
                                    break;
                                case 0x1f27 + -0x25 * -0x18 + -0x2296:
                                    apo = -0x6e3 + 0x463 * -0x1 + 0xbbe; {
                                        AntiAim.SetOverride(-0x1d9 * -0x3882 + -0x9dc1 * -0x85 + -0x31 * -0xa87 - (-0x41cc * 0x3ff + 0x14855e6 + 0x7af99b)), AntiAim.SetFakeOffset((0x2b677 + 0x28681 + 0x192b9 * -0x2) % (0x10e1 * -0x1 + -0x67 * -0x4c + -0xdb0)), apr = -0x901 + 0x1228 + -0x1 * 0x8d7;
                                        while (apr < 0x1 * 0x17b + 0x31d * 0x9 + -0x49 * 0x65) switch (apr) {
                                            case -0xbf * 0x17 + 0x26 * -0xca + 0x2f75:
                                                apr = apa == -0x2cd9708 + -0x11 * -0x2ca6af + 0x2213e * 0x361 - (0x564d33 + 0x4 * 0x1657c2d + -0x16f8f2e * -0x1) ? -0x2086 + -0x5 * -0x6a6 + 0x1 * -0x64 : -0x1236 + -0x1335 + -0x4 * -0x964;
                                                break;
                                            case 0x13ab + 0x19e4 + -0x2d3b:
                                                apr = -0x4 * -0x376 + 0x1bb * -0x1 + -0xb6a, AntiAim.SetRealOffset(-aou);
                                                break;
                                            case -0x6c7 * 0x4 + -0x1684 + 0x5d * 0x89:
                                                apr = 0xa0f + 0x39 * 0x4 + -0xa40, aps = 0x21c6 + 0x1573 + 0x36e3 * -0x1;
                                                while (aps < -0x7b4 + 0x163 * -0xa + 0x1 * 0x1652) switch (aps) {
                                                    case 0xa * -0x2e2 + 0x3 * -0x8d7 + 0x37af:
                                                        aps = apa == (0x427d6 + -0xec8c * 0x3d + 0x5ce62f) % (0x25 * -0x31 + -0x20c5 * -0x1 + -0x15 * 0x139) ? (-0x4ed21f6c + -0x17ffe8c6 + 0x9007517c) % (-0x4ff * -0x6 + 0x1681 + -0x3474) : 0x1 * 0x1547 + -0x1de + -0x12a9;
                                                        break;
                                                    case 0x3 * 0x2eab2e + 0x15559c + 0x4d97c8 ^ -0x1633d37 * -0x1 + -0x1e42 * 0x5ba + 0x38f7a9 * 0x1:
                                                        aps = 0x109d * 0x1 + 0x2b * 0xca + 0x7 * -0x71d, AntiAim.SetRealOffset(aou);
                                                        break;
                                                }
                                                break;
                                        }
                                        AntiAim.SetLBYOffset((-0x29561 * 0x1 + -0x426d8 + -0x3d13 * -0x25) % (-0x13b2 * 0x1 + -0x2 * -0x5d8 + 0x805 * 0x1)), side = (0x215b53bc + 0xb2a3562 + -0xc407915) % (0x57 * -0x71 + 0x23cc + -0x1a * -0x1a);
                                    }
                                    break;
                            }
                        }
                        break;
                    case -0x2c * -0x37 + 0x4 * 0x989 + -0x44f * 0xb:
                        apn = aow != (-0x7f * -0xf + 0xd25 + 0x1 * -0x1495 == '1') ? 0x2483 * 0x42 + 0x5b8b1 + 0x1 * 0x4acb - (-0x2 * 0x76259 + -0x1bb14b + -0x1 * -0x39e339) : 0x11 * 0x16b + -0x1169 + -0x680;
                        break;
                    case (0x39ef * 0x92 + 0xce972 * 0x1 + 0x9fe6a) % (0x1822 + -0x4 * 0x4c0 + 0x2a * -0x1f):
                        apn = -0x2e8 + 0x13 * -0x91 + 0xdf0; {
                            apt = (0x1b * -0x3d268f + 0x99946f + 0xa907f51) % (-0x35 * -0xb + 0x2693 + -0x5d5 * 0x7);
                            while (apt < 0x1 * -0x1c2f + -0x7fd + 0x58 * 0x6a) switch (apt) {
                                case (-0x6cd543 * 0x3 + 0x6d90d85 + -0x12ee69f) % (0x131f + 0x54c * -0x6 + 0xcb2):
                                    apt = 0x53 * 0x17 + -0x1 * -0x79 + -0x7aa, apu = -0x1b41 + -0x177f + 0x32fa;
                                    while (apu < -0x2 * -0x8b7 + -0x22a0 + 0x11db) switch (apu) {
                                        case -0x10 * 0x13 + -0x2076 + 0x8 * 0x43c:
                                            apu = UI.GetValue(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW', 'auto-direction type']) == (-0x186445 + -0x1 * -0x2bef97 + 0x152557) % (0x4f * 0x3f + 0x19d3 + -0x90d * 0x5) ? 0x47 * -0x74 + -0x1b83 + 0x3bef : -0x29 * -0xa1 + 0x187a + -0x319a;
                                            break;
                                        case -0xaf1 + -0x2 * 0x1313 + -0x2e7 * -0x11:
                                            apu = 0xb5e + -0x3df * -0x7 + -0x25ce; {
                                                apv = (0x7a39 * -0x35c7 + -0x80201f9 * -0x2 + 0x32de14a7) % (-0x1 * -0x1941 + 0x1 * -0x270b + 0x49b * 0x3);
                                                while (apv < 0x1fb5 + 0x1de + -0x212c * 0x1) switch (apv) {
                                                    case 0x4 * 0x2a3 + -0x11a4 + 0x761:
                                                        apv = -0x2c5 * 0x7 + -0x7 * -0x38c + -0x50a, apw = -0x1102 + 0x4 * 0x5a4 + -0x571 * 0x1;
                                                        while (apw < 0xb03 * -0x3 + 0xf7d + 0x1225) switch (apw) {
                                                            case (-0x2d40c + 0x4aa9 + 0x1 * 0x4a0e9) % (0x3 * 0x3b + 0x2136 + -0x21e4):
                                                                apw = -0x5 * 0x5f + -0xd * 0x4f + 0x5 * 0x14b; {
                                                                    AntiAim.SetOverride((-0x3acc3f + -0x445f * -0x3 + 0x77 * 0xd44d) % (-0x71 * 0x14 + -0x11d9 * -0x1 + -0x2 * 0x481)), apx = 0x20 * -0x112 + 0x1 * 0x248b + -0x223;
                                                                    while (apx < 0x2708 + 0xf5a + -0x35e1) switch (apx) {
                                                                        case 0x2 * 0xd8f + -0x20aa + -0x2d1 * -0x2:
                                                                            apx = 0x4 * -0x94e + 0x729 + 0x1e90; {
                                                                                AntiAim.SetFakeOffset((0x16 * -0x1a36 + -0x1 * 0x2e4e8 + 0x73d12) % (0x1748 * -0x1 + 0x1 * -0x7be + -0x5 * -0x635)), apy = 0x18c7 + -0x1673 + -0x238;
                                                                                while (apy < -0xd35 + 0x9 * -0x89 + 0x1274) switch (apy) {
                                                                                    case -0x7ff * 0x3 + -0x24a6 + -0x1 * -0x3cbf:
                                                                                        apy = apa == 0x4ae7b3b + -0xb415013 + -0xdeea1ed * -0x1 - (-0xd * -0x50c131 + 0x725be00 + -0x3e3c068) ? 0x15b2 + -0x1 * -0x415 + -0x19ac : 0x107d + 0x18c6 + -0x2923;
                                                                                        break;
                                                                                    case 0xdf * -0x29 + -0xd * -0x21a + 0x880:
                                                                                        apy = 0x6c2 + -0x221d + -0x3 * -0x943, AntiAim.SetRealOffset(-(0x110a + -0x4 * -0x5ba + -0x256 * 0x11));
                                                                                        break;
                                                                                    case -0x26b3 * -0x1 + 0x745 + 0x8 * -0x5bb:
                                                                                        apy = 0xf7b + -0x170b + 0x7fe, apz = 0x925 * -0x1 + 0x1 * 0x8a7 + 0xaa;
                                                                                        while (apz < 0xda * -0x16 + 0x187 + 0x1190) switch (apz) {
                                                                                            case -0xe00 + -0x1 * -0x1ef7 + 0x599 * -0x3:
                                                                                                apz = apa == (-0x1be14 * 0x17 + -0x5d97b + 0x569df0) % (-0x168d * 0x1 + -0x29 * -0xe1 + -0xd79) ? 0x6a * 0x18 + -0x1 * -0x1b24 + 0x125f * -0x2 : 0x17dc + -0x34c + -0x1435;
                                                                                                break;
                                                                                            case -0xc99 + -0x410 + 0x10ff:
                                                                                                apz = 0x223 * -0xc + -0x5d5 + -0x7f5 * -0x4, AntiAim.SetRealOffset(-(0x1ef9 + -0x160 + 0x1 * -0x1d5d));
                                                                                                break;
                                                                                        }
                                                                                        break;
                                                                                }
                                                                            }
                                                                            break;
                                                                        case 0x20 * 0x2c + -0xf * 0x195 + 0x1263:
                                                                            apx = UI.GetValue(['Rage', 'Anti Aim', 'General', 'Key assignment', 'legit desync']) == (null == undefined) ? 0x18af + -0x21 * 0x10c + 0x9f3 : -0x130f + -0x2e3 * -0x7 + -0xf7 * 0x1;
                                                                            break;
                                                                        case -0x2105 + 0x2 * -0xb67 + 0x3802:
                                                                            apx = -0x1 * -0xbcd + -0x2 * 0x16f + -0x1 * 0x86e; {
                                                                                AntiAim.SetFakeOffset(-aou / ape), aqa = 0x789 * 0x1 + -0x3 * 0xe1 + -0xe * 0x53;
                                                                                while (aqa < 0xa6 * 0x3 + -0x5 * -0x7a9 + -0x1 * 0x2794) switch (aqa) {
                                                                                    case -0x26 * -0xd9 + 0x115 * -0x9 + -0x1657:
                                                                                        aqa = -0x1330 + -0x796 * 0x1 + -0x1b71 * -0x1, AntiAim.SetRealOffset(aou);
                                                                                        break;
                                                                                    case 0x389 + -0x1 * -0x869 + -0xbc5:
                                                                                        aqa = -0x23d1 + -0xa66 + 0x2ee2, aqb = 0x11fc + -0x2 * -0x769 + 0x1f * -0x10c;
                                                                                        while (aqb < -0x157f + -0x1 * 0x6a3 + 0x1 * 0x1cda) switch (aqb) {
                                                                                            case -0x1121 + -0x1094 + -0x1 * -0x21d3:
                                                                                                aqb = -0xfc8 + -0x21a3 * -0x1 + -0x1 * 0x1123, AntiAim.SetRealOffset(aou / apf);
                                                                                                break;
                                                                                            case -0x1be7 + -0x180d + 0x344e:
                                                                                                aqb = apa == 0x25c50 * 0x9f + -0xb87716 + 0x2 * -0x13ea6 - (0x1 * 0x3b30e3 + -0x16b62ab * -0x1 + 0xb * -0x154a63) ? 0x251 * 0x6 + 0x12bc + -0x2084 : -0x1 * -0x18c7 + 0x83 * -0x17 + -0xc4a;
                                                                                                break;
                                                                                        }
                                                                                        break;
                                                                                    case -0x177b + -0x118d * -0x1 + -0x23 * -0x2e:
                                                                                        aqa = apa == -0xe62e42 * 0xc + 0x42c6f * 0xdf + 0xe83437c - (-0x578f109 + 0x7831d7b * -0x1 + 0x1457db99) ? -0xb9 * 0x1b + -0x20a1 + 0x1a23 * 0x2 : -0x1f4f + -0x1 * 0x11e1 + -0x315d * -0x1;
                                                                                        break;
                                                                                }
                                                                            }
                                                                            break;
                                                                    }
                                                                    AntiAim.SetLBYOffset(-0xae1f9f1 + -0xd49f * 0xe09 + 0x1de5f29d - (-0x2 * 0xc73e16 + -0x7e5c3d6 + -0xe2876d * -0x13)), side = (-0x197291 + -0x2a0928 + -0x23 * -0x31736) % (0x439 + -0x1c9a + 0x1864);
                                                                }
                                                                break;
                                                            case -0xdeb + 0xa02 + -0x67 * -0xa:
                                                                apw = aox <= -apc ? 0xafd8d29 + 0x3fa7deb + -0x1 * 0x79c3dff - (0x21d7b6c + 0x2255b20 + 0x318f689) : 0x23bd + 0x644 * 0x5 + -0x42db;
                                                                break;
                                                            case 0x1813 + 0x1415 + -0x6 * 0x753:
                                                                apw = -0x7 * 0x1af + -0x1 * 0x11ad + 0x1e0f; {
                                                                    AntiAim.SetFakeOffset(0x249d3 * 0x191 + -0x138eb7a * -0xa + -0x8730932 - (-0x7fc1a0a + -0x272f008 + 0x11cad727)), aqc = -0x2550 * 0x1 + -0x1 * 0xbc6 + 0x2e4 * 0x11;
                                                                    while (aqc < -0xfa4 + 0x287 * -0x4 + -0xd19 * -0x2) switch (aqc) {
                                                                        case 0x2303 * 0x1 + -0xa * -0x36f + 0x1152 * -0x4:
                                                                            aqc = 0x47 * 0x19 + -0x67 * 0x5f + 0x1fbc, AntiAim.SetRealOffset(-apd);
                                                                            break;
                                                                        case -0x1 * 0x20dd + 0x1c9 + 0x1f33:
                                                                            aqc = -0x2070 + -0x1ac6 + 0x3ba8, aqd = (0x18bf6 * 0x34 + -0xf * -0x73245 + -0x846dd9) % (-0x154 + 0x262b + -0x1 * 0x24cb);
                                                                            while (aqd < -0x2 * 0xec2 + 0x2b * -0x9a + -0x37ea * -0x1) switch (aqd) {
                                                                                case -0x20cf + 0x1 * -0x997 + 0x2ab6:
                                                                                    aqd = 0x11c6 + 0x1132 + -0x10 * 0x227, AntiAim.SetRealOffset(apd);
                                                                                    break;
                                                                                case -0x148678e + -0x14b1f2 * 0x68 + 0xe03de25 & 0x6487518 + 0xb097da + -0x11d5d * 0x36c:
                                                                                    aqd = apa == (-0x1ea2cc + 0x84073 + 0x3 * 0x150656) % (-0x1a5b + -0x2 * 0xecc + 0x37f6) ? -0xaa1 + -0x12a * -0x3 + -0x1 * -0x773 : 0x7 * 0xef + -0x10d + -0x4f4;
                                                                                    break;
                                                                            }
                                                                            break;
                                                                        case -0x12 * -0x8 + 0xac8 + 0x5 * -0x242:
                                                                            aqc = apa == (-0x18c75 + -0xfb5a + 0x49f55 * 0x1) % (0x98f + -0x10 * 0x11 + -0x2d4 * 0x3) ? 0x7 * 0x399 + 0xafc + -0x241a : -0xb43 + -0x1 * 0x23c5 + 0x2f27 * 0x1;
                                                                            break;
                                                                    }
                                                                    side = (-0x2b2e8d36 * -0x1 + 0x3ec47760 + -0x49adf48d * 0x1) % (-0x791 * -0x1 + 0x161d + -0x1da5);
                                                                }
                                                                break;
                                                        }
                                                        break;
                                                    case -0x11 * -0x10ad3a + -0x13c7fde + 0x87f6f9 * 0x2 ^ -0x18ba423 + 0x15d73cd + 0x11d1f42:
                                                        apv = aox >= apc ? 0xd * -0x2c3 + 0x936 + 0xd83 * 0x2 : 0x203e + 0x1 * -0x165a + -0x1 * 0x99b;
                                                        break;
                                                    case 0x1b * -0x1f + -0x12c4 + 0x165e:
                                                        apv = -0xf85 * 0x2 + 0x7 * -0x241 + -0x4 * -0xbce; {
                                                            AntiAim.SetOverride(-0x566892 + -0x77 * -0x16af3 + -0x60a3 * -0x119 - (-0x6a6e6f * -0x2 + -0xf9ff * -0x100 + -0x1127a91)), aqe = 0x1 * -0x3a9 + 0x1714 + -0x1331;
                                                            while (aqe < -0x171e * -0x1 + -0x1c95 + -0x2 * -0x2f7) switch (aqe) {
                                                                case -0x7d4 * 0x3 + -0x2a * 0x59 + 0x1 * 0x2647:
                                                                    aqe = 0x15 * 0x156 + 0x15d * 0x1 + -0x1cf4; {
                                                                        AntiAim.SetFakeOffset(0x17984 * -0x1b7 + -0xd * 0x4448e9 + 0xd5ae246 - (0x6fd1e2d + -0xaaf40c6 + 0xb0defae)), aqf = 0x1973 + -0xfa1 + 0x1ef * -0x5;
                                                                        while (aqf < 0xd * -0xad + -0xdd * 0x1 + 0x4 * 0x282) switch (aqf) {
                                                                            case 0x1fd0 + -0x1c6a + -0x336:
                                                                                aqf = 0x1a29 + -0x8a + 0x47 * -0x5b, AntiAim.SetRealOffset(-0x191 + 0x2a2 * 0x5 + -0xb5d);
                                                                                break;
                                                                            case -0x33b * 0x5 + -0x1f70 + 0x6d2 * 0x7:
                                                                                aqf = apa == 0x4b9da * 0x15c + 0xdaa03ea + -0xcbadb2d - (0x94dd703 + 0xba2 * 0x179f + -0x304d18c) ? -0x1b19 * 0x1 + 0xb * -0x325 + -0x2 * -0x1ef0 : 0x1 * -0x2190 + 0x68b + -0x2f * -0x95;
                                                                                break;
                                                                            case 0x2 * -0x957 + -0x1090 + 0x42 * 0x8a:
                                                                                aqf = 0x5 * -0x277 + -0xb07 + 0x17bc, aqg = 0xfde + 0x2669 * 0x1 + -0x35ef;
                                                                                while (aqg < 0x92 + 0x17 * 0x87 + 0xc17 * -0x1) switch (aqg) {
                                                                                    case -0xe * -0xd + 0x1 * -0xcf7 + 0xc67:
                                                                                        aqg = 0x21ce + -0x489 + -0x1ca9, AntiAim.SetRealOffset(-0x1a97 * 0x1 + 0x10 * 0x22d + -0x7fd);
                                                                                        break;
                                                                                    case -0x5 * -0x126 + -0x1a5e + 0x29f * 0x8:
                                                                                        aqg = apa == (0x24 * 0x19815 + 0x1a9460 + -0x1 * 0x2b46ab) % (-0x1387 * -0x2 + -0x222a + 0x1 * -0x4e1) ? -0x5b0 + 0xe38 + -0x1d * 0x4a : -0x1f37 + 0x1 * 0x949 + -0xb45 * -0x2;
                                                                                        break;
                                                                                }
                                                                                break;
                                                                        }
                                                                    }
                                                                    break;
                                                                case 0x1db2 + -0x84f * -0x1 + -0x25c7:
                                                                    aqe = UI.GetValue(['Rage', 'Anti Aim', 'General', 'Key assignment', 'legit desync']) == (NaN !== NaN) ? 0x1f24 + -0x547 + -0x19ac : -0x132a + -0x20e6 + 0x3428;
                                                                    break;
                                                                case 0x646 + 0x1c17 + 0x1f * -0x11b:
                                                                    aqe = 0xbdf + -0x16 * -0x1c1 + -0x31fe; {
                                                                        AntiAim.SetFakeOffset(aou / ape), aqh = 0x549 * -0x7 + 0x10ec + -0x142d * -0x1;
                                                                        while (aqh < 0xdf * 0x6 + -0x1 * -0x1185 + -0x2 * 0xb26) switch (aqh) {
                                                                            case -0x135 + -0x43d + 0x58c:
                                                                                aqh = apa == (0x2f502 + 0x11c65 * -0x3 + -0xf * -0x2a1d) % (-0x25b0 + 0xf4 * -0x16 + -0x17 * -0x28d) ? 0x125 * -0xb + 0x1 * -0x21a7 + 0x2e98 : 0x1b * -0x35 + -0x1 * -0x123d + -0xc9a * 0x1;
                                                                                break;
                                                                            case 0x101a + 0x1013 * -0x1 + 0x53:
                                                                                aqh = 0x1202 + 0x1aab * 0x1 + -0x25 * 0x132, AntiAim.SetRealOffset(-aou);
                                                                                break;
                                                                            case -0xd3e + 0xfd8 + -0x28e:
                                                                                aqh = 0x1e7f + 0x3 * 0xcf9 + -0x44f7, aqi = 0x31 * -0xc1 + 0x61 * 0x5f + 0x105;
                                                                                while (aqi < -0xe6e + 0x2db * -0x1 + -0x1 * -0x11ab) switch (aqi) {
                                                                                    case -0xc52 * 0x1 + 0x2578 + -0x395 * 0x7:
                                                                                        aqi = apa == -0x880282 + 0x39276d * 0x1 + 0x10b3c63 - (0x1141882 + -0x1e8aaa * 0xc + 0x116c8c3) ? -0x1ef0 + -0x1 * 0xb03 + 0x2a23 : 0x1c * -0x49 + 0xf37 * -0x2 + 0x26cc;
                                                                                        break;
                                                                                    case 0xb * 0x5d + 0x6a7 * -0x1 + 0xe * 0x34:
                                                                                        aqi = 0x775 + -0x2488 * -0x1 + 0x1 * -0x2b9b, AntiAim.SetRealOffset(-aou / apf);
                                                                                        break;
                                                                                }
                                                                                break;
                                                                        }
                                                                    }
                                                                    break;
                                                            }
                                                            AntiAim.SetLBYOffset(0x966 * -0xb1c5 + 0x2 * 0x371ba4f + 0x13671 * 0x5c5 - (-0x2197a71 + -0x3d * -0x164c3f + -0x72b * -0x9409)), side = -0x9bf8c + -0x2 * 0x311405 + 0x15ad684 ^ -0x7c5491 + -0x1f * 0x4e518 + 0x1 * 0x2030165;
                                                        }
                                                        break;
                                                }
                                            }
                                            break;
                                    }
                                    break;
                                case 0x1a73 + 0xc34 + -0x2695:
                                    apt = -0x1 * 0x1549 + -0x1 * -0xee1 + -0x356 * -0x2; {
                                        aqj = 0x537 + 0x13 * 0x1f + -0x73a;
                                        while (aqj < 0x1 * 0xe6b + -0x894 + -0x52e) switch (aqj) {
                                            case 0x9337d * -0xb + 0x158ed67 + 0x9fa81f * 0x1 ^ 0x31bee88 + 0x1845a69 * -0x1 + -0x434ff:
                                                aqj = 0x1c35 + 0x2264 + -0x3df0, aqk = -0x112a + 0x1942 + -0x80d;
                                                while (aqk < 0x1a79 + -0x1 * 0x16 + 0x89f * -0x3) switch (aqk) {
                                                    case 0x1 * -0x1205 + 0xeda + 0x336:
                                                        aqk = aox <= -apc ? -0x1b50 + -0x19ab + 0x37 * 0xf7 : 0x12b0 + 0x17a + 0x8e * -0x24;
                                                        break;
                                                    case 0x1d * -0x116 + 0x2 * -0x1a7 + 0x2 * 0x1171:
                                                        aqk = 0x659 + 0x1073 + -0x1646; {
                                                            AntiAim.SetOverride((-0x194467 + 0x695 * -0x8ca + 0x1f6 * 0x3f23) % (0x2572 + 0x1abb + -0xbf * 0x56)), aql = -0x107d + -0x1 * -0x1890 + 0x4 * -0x1f7;
                                                            while (aql < -0x77d + -0x8a1 + 0x1093) switch (aql) {
                                                                case 0x788 * -0x2 + -0x1c19 + 0x2b4f * 0x1:
                                                                    aql = 0x1b37 + -0x2596 + 0x9 * 0x134; {
                                                                        AntiAim.SetFakeOffset(aou / ape), aqm = 0x253c + -0xaa0 + 0x67 * -0x42;
                                                                        while (aqm < 0x252 + 0x186c + -0xd1 * 0x20) switch (aqm) {
                                                                            case 0x5f9 + -0x1a7b + 0x14be:
                                                                                aqm = 0x4f1 + 0x1ebd + -0x2310, AntiAim.SetRealOffset(-aou);
                                                                                break;
                                                                            case (-0x1bc17e20 + -0xaf8062f + 0x529c9a * 0xdc) % (-0x4 * -0xe + 0xfad + -0xfdc):
                                                                                aqm = -0x2 * -0xe11 + 0x11 * 0x1f6 + -0x3cda, aqn = 0xcd7 * -0x1 + 0xfb3 * -0x2 + 0x2c8d;
                                                                                while (aqn < -0xa8e + 0x20ce + -0x15cd) switch (aqn) {
                                                                                    case -0x213e + -0x3 * -0x3fb + 0x1f7 * 0xb:
                                                                                        aqn = apa == -0x45 * 0x22bd3 + -0x257e6d + 0x2 * 0xbbd7cd - (-0x5a369e * -0x2 + -0xa * -0xf5fb6 + -0x91c90b) ? 0x229 * -0xc + -0x1c6a * -0x1 + -0x25f : -0x1fe5 + 0x25 * 0x17 + -0x11 * -0x1b5;
                                                                                        break;
                                                                                    case -0x3d2 + 0x3 * -0xa31 + 0x2284:
                                                                                        aqn = 0x18e + -0x28 * 0xb3 + -0x211 * -0xd, AntiAim.SetRealOffset(-aou / apf);
                                                                                        break;
                                                                                }
                                                                                break;
                                                                            case -0xe * -0x283 + -0x22ff + -0x1d * 0x1:
                                                                                aqm = apa == (0x10937 + -0x117 * 0x2e2 + -0x388f * -0x13) % (0x2 * 0xe03 + -0x5b8 + -0x164b) ? 0x95 * 0x22 + 0x6 * 0xef + -0x1928 : (-0x2caa434d + -0x3d * 0x9ababf + 0x71cdd2d9) % (0x17cf + 0x2d0 + -0x1a96);
                                                                                break;
                                                                        }
                                                                    }
                                                                    break;
                                                                case 0x1720 + -0x11 * 0x2 + -0x16d1:
                                                                    aql = -0x167a + -0x260b * 0x1 + 0x5 * 0xc32; {
                                                                        AntiAim.SetFakeOffset(-0x88f542a + -0xe46faf7 * 0x1 + 0x1e321c36 * 0x1 - (0x6b04cd6 + 0x29d8435 + -0x1f203f6)), aqo = -0x2621 + -0x203e + 0x4675 * 0x1;
                                                                        while (aqo < -0xb8a + -0x2 * -0xb5c + -0xaa6) switch (aqo) {
                                                                            case -0x56e * -0x1 + 0x1187 * 0x1 + -0x16df * 0x1:
                                                                                aqo = apa == (-0x1 * 0x23a41 + 0x3784d + 0xd97a) % (0x21b9 + -0x1d7f + -0x437) ? 0x1672 + -0x2015 * -0x1 + 0x6 * -0x90a : 0x2f1 * 0x4 + -0x143d + -0x4 * -0x234;
                                                                                break;
                                                                            case 0x34b + 0xa * -0x122 + -0xa4 * -0xd:
                                                                                aqo = 0xa7e + 0xcb0 + -0x16a6, AntiAim.SetRealOffset(-0x1 * 0x304 + -0x26e9 + 0x2a29);
                                                                                break;
                                                                            case -0x1 * 0xf3a + -0x1 * 0x26b6 + 0x3647:
                                                                                aqo = 0x817 * -0x2 + -0x479 + 0x1 * 0x152f, aqp = -0x1 * -0xeda + 0x1bf1 + -0x2ab2;
                                                                                while (aqp < -0xad6 * 0x3 + 0x5a1 * -0x4 + 0x1bdb * 0x2) switch (aqp) {
                                                                                    case -0x1 * -0x1ade + 0x1 * 0x2569 + -0x402e:
                                                                                        aqp = apa == (-0x4 * 0x6ca40 + -0x1 * 0x360d0b + 0x4e * 0x19016) % (0x46d * -0x7 + -0x8be + -0x4 * -0x9ef) ? -0x5e6 * -0x2 + -0x1005 * 0x1 + 0x469 : -0x131f + 0x23b7 * -0x1 + -0x26a * -0x17;
                                                                                        break;
                                                                                    case 0x3fb * 0x1 + 0x1df * 0x4 + -0xb47:
                                                                                        aqp = 0x4b5 + 0x10f3 + -0x14f8, AntiAim.SetRealOffset(0x1a0b + 0xc3b * -0x1 + -0xd94);
                                                                                        break;
                                                                                }
                                                                                break;
                                                                        }
                                                                    }
                                                                    break;
                                                                case -0x5 * 0x67f + 0x162a * 0x1 + 0xa88:
                                                                    aql = UI.GetValue(['Rage', 'Anti Aim', 'General', 'Key assignment', 'legit desync']) == (null == undefined) ? -0x1ab * -0x3 + -0x45 + -0x48f : 0x1c9f + -0x15a7 + -0x6d2;
                                                                    break;
                                                            }
                                                            AntiAim.SetLBYOffset(-0x9ae4bbf + 0x1d43752 * 0x3 + -0x2 * -0x5c6b96f - (-0x490d17d + -0xd15b499 + 0x1902532b)), side = -0xa * 0x2ba99f + 0x1dc974e + 0x1d3 * 0x6d12 ^ -0x1d5c27 * 0x9 + 0x7596b9 + -0x5afa * -0x43d;
                                                        }
                                                        break;
                                                    case -0x15f * -0x17 + -0x26f3 + 0x79c:
                                                        aqk = 0xc9b * 0x1 + -0x178c + 0x24b * 0x5; {
                                                            AntiAim.SetFakeOffset((0xa * 0x20ec + -0x23803 + 0x30651) % (0x19f0 + 0x19a9 + 0x8e * -0x5d)), aqq = 0x18 * 0x11a + -0x6a * 0x53 + -0x41 * -0x20;
                                                            while (aqq < 0xbf1 * 0x3 + -0x188e + 0xaa9 * -0x1) switch (aqq) {
                                                                case 0x25f7 + 0x822 + -0x2dcb:
                                                                    aqq = 0x7d8 + -0x1 * 0x16f7 + 0xfbb * 0x1, aqr = -0x20f3 + 0x1 * -0x18cf + 0x475 * 0xd;
                                                                    while (aqr < 0x166 * 0x2 + 0x2e * 0x4a + -0xfad * 0x1) switch (aqr) {
                                                                        case -0x3b0 * -0x2 + 0x2092 + 0x9 * -0x46b:
                                                                            aqr = apa == (0x5 * -0x692eb + 0x1 * -0x2ce7e7 + 0x767727) % (0x4 * 0x8bf + 0x1f72 + -0x15b * 0x31) ? 0x5dd * -0x1 + 0x337 * 0x9 + -0x16cc : 0xd8 * 0xe + 0x763 + -0x12c8;
                                                                            break;
                                                                        case 0x1cb8 + -0x267b + 0xa09:
                                                                            aqr = 0x8 * 0x32e + 0x20b3 * 0x1 + -0x2 * 0x1cdc, AntiAim.SetRealOffset(apd);
                                                                            break;
                                                                    }
                                                                    break;
                                                                case -0xea8 + -0x43 * -0x29 + 0x1 * 0x407:
                                                                    aqq = -0x8bd + -0x15fe + 0x71 * 0x47, AntiAim.SetRealOffset(-apd);
                                                                    break;
                                                                case -0x1f38 + 0xd37 + 0x1233:
                                                                    aqq = apa == (-0x41b89 + 0x5795 * -0x5 + -0x7e8f8 * -0x1) % (0x100 * 0x9 + -0x1684 + 0xd87) ? 0x1c7e + 0xf96 + -0x362 * 0xd : 0x11eb + 0xac * -0x1 + -0x10f1;
                                                                    break;
                                                            }
                                                            side = (-0x88d2083 + 0x4c139 * 0x179 + -0x643963d * -0x1) % (0x2b * 0xa + 0x22fc * 0x1 + -0x24a3);
                                                        }
                                                        break;
                                                }
                                                break;
                                            case -0x15c5 + 0x15d3 + 0xc * 0x5:
                                                aqj = aox >= apc ? 0x1d * -0x71 + -0x9f * 0x9 + 0x1281 * 0x1 : (0x57fd17 + -0x193cd5 * 0x7 + 0x32a84ab) % (-0x1 * 0xf5b + -0x1859 + -0x9ef * -0x4);
                                                break;
                                            case 0x4d7 + 0x2431 * 0x1 + -0x1 * 0x28eb:
                                                aqj = 0xf1b * -0x2 + -0x716 * -0x2 + 0x10b3; {
                                                    AntiAim.SetOverride((-0x1 * -0x21b825 + 0xc6c02 + -0x5737e) % (0x1764 + 0x888 + -0x1fe9)), aqs = 0x5 * -0x506 + -0xac8 + -0x1207 * -0x2;
                                                    while (aqs < 0x22c4 + -0x1012 * -0x1 + -0x3242) switch (aqs) {
                                                        case 0x8fd + -0x1b8f + 0x12ba:
                                                            aqs = UI.GetValue(['Rage', 'Anti Aim', 'General', 'Key assignment', 'legit desync']) == (null == undefined) ? 0x1 * -0x254b + -0x21 * -0xc4 + 0xc57 : -0x25e8 + -0x37c + 0x299e;
                                                            break;
                                                        case -0x167a + -0x1c06 + 0x32d0:
                                                            aqs = -0xb * -0x16f + -0x40e + 0xb23 * -0x1; {
                                                                AntiAim.SetFakeOffset(-0x60c6ee5 + -0x799f137 + -0x3 * -0x700b9bb - (0x87ee92a + -0x1 * -0xb391b59 + 0x1 * -0xc5c376e)), aqt = 0x1c02 + 0x14d + -0x1ced;
                                                                while (aqt < -0x144b * -0x1 + -0x22c5 + 0xf3a * 0x1) switch (aqt) {
                                                                    case -0x1a * 0x43 + -0x8ba + 0xfa5:
                                                                        aqt = -0x1d2c + 0x1 * -0x15ab + 0x3397 * 0x1, AntiAim.SetRealOffset(-(-0x855 + 0x436 + 0x45b));
                                                                        break;
                                                                    case 0x1ca2 + 0x25f5 + -0xcf * 0x52:
                                                                        aqt = 0xd40 + -0x297 + -0x9e9, aqu = -0x14d * 0x77c56 + -0x2b * 0x325915 + 0x1750fec9 ^ -0x91b7fbe + -0x6a24d3a + -0x42c3845 * -0x5;
                                                                        while (aqu < 0x56b + 0xfe3 + -0x42d * 0x5) switch (aqu) {
                                                                            case 0x9568688 + -0x896d36c + 0x45f9948 ^ 0x5b5dbd1 + -0xce * 0x5a7f4 + 0x7be * 0x830c:
                                                                                aqu = apa == (0x3f0070 + 0x4cc0f1 + -0x6310b8) % (0xa33 + 0x1439 + -0xa23 * 0x3) ? -0x1484eb9 + -0x166ad6f + 0x5b8e * 0xa1d ^ 0x7c85d1 * -0x1 + -0x16f9cfd * 0x1 + 0x2db11ba * 0x1 : 0x1 * -0x6ed + -0x5fb * -0x6 + -0x1c88;
                                                                                break;
                                                                            case (-0x37e6e22e + -0xbee5 * 0x1cf6 + -0x3b5a53c3 * -0x2) % (0x2 * 0xb19 + -0x775 + -0x10d * 0xe):
                                                                                aqu = 0x60a + 0x15c0 + 0x91f * -0x3, AntiAim.SetRealOffset(-(-0x15ae + 0x7 * 0x15c + 0x211 * 0x6));
                                                                                break;
                                                                        }
                                                                        break;
                                                                    case -0x13b2 + -0x1 * 0x11f + -0x3 * -0x711:
                                                                        aqt = apa == (0x40db * 0x2 + -0x4a57 * 0x2 + 0x22a7e) % (0x1ff4 + 0x9 * 0x2f9 + -0x3ab2) ? -0x2688 + -0x1f * -0xf1 + 0x976 * 0x1 : 0x3af + -0x993 + 0x62d * 0x1;
                                                                        break;
                                                                }
                                                            }
                                                            break;
                                                        case 0x1 * -0x1e59 + 0x5 * -0x30d + 0x68c * 0x7:
                                                            aqs = -0x130 * 0x8 + -0x76d + 0x1181; {
                                                                AntiAim.SetFakeOffset(-aou / ape), aqv = -0x12d * 0xf + -0x605 * 0x3 + 0x23f5;
                                                                while (aqv < -0x3 * -0x5e + 0x14 * 0x19 + -0x29c) switch (aqv) {
                                                                    case 0x5 * 0x42e6b7 + 0x2511b18 + -0x9e618f * 0x1 - (-0x1a488e3 + 0x202 * -0x2215e + -0x8ecc2b6 * -0x1):
                                                                        aqv = 0x44b * 0x5 + 0x22e3 + -0x37e8, AntiAim.SetRealOffset(aou);
                                                                        break;
                                                                    case 0x23d5 * 0x1 + -0x1 * -0x4ca + -0x285c:
                                                                        aqv = apa == 0xc6f6ba4 + 0x20186a1 * 0x2 + 0x1fdf49 * -0x49 - (0xb5b1499 + -0x7d42952 + -0x8c2042 * -0x7) ? (0x2d38e92 + -0x2a117b3 + 0x4de2f70) % (-0x2256 + -0x2 * 0x82c + 0x24e * 0x16) : -0x2 * -0x1046 + 0x1e5c + 0xad * -0x5d;
                                                                        break;
                                                                    case 0x5f3 * 0x2 + 0x1fe1 * 0x1 + 0x4 * -0xaee:
                                                                        aqv = -0x1 * 0xbaa + -0xe05 + 0x1a21, aqw = 0x175f + -0x11a6 + -0x59b;
                                                                        while (aqw < 0x8a * -0x35 + 0x95 * -0x2e + 0x37ad) switch (aqw) {
                                                                            case 0x2372 + -0x1e89 + -0x188 * 0x3:
                                                                                aqw = -0x17 * 0x91 + -0x1052 + 0x1dae, AntiAim.SetRealOffset(aou / apf);
                                                                                break;
                                                                            case 0x222c + -0x1166 + -0x10a8:
                                                                                aqw = apa == (-0x5 * 0x6ef1e + -0x3df03a + 0x894c79) % (-0x1af + 0x2d7 * -0xb + 0x20ef) ? 0xcf0 + -0x11ce + 0x52f * 0x1 : 0x20 * -0x6b + 0x213b + -0x1 * 0x1386;
                                                                                break;
                                                                        }
                                                                        break;
                                                                }
                                                            }
                                                            break;
                                                    }
                                                    AntiAim.SetLBYOffset((-0x3c373 + 0x3 * -0x14476 + 0x9a85b) % (-0xaaa * 0x2 + -0xf30 + -0x2487 * -0x1)), side = (-0x3d7113 + 0x1dbb2e + -0x243347 * -0x2) % (-0x1b66 + 0x1dc3 + -0x25a);
                                                }
                                                break;
                                        }
                                    }
                                    break;
                                case (-0xdee6cd6 + -0x2e2f591a + -0x5c62d5f9 * -0x1) % (-0x1ef7 + -0x1 * 0x4b8 + 0x23b8):
                                    apt = UI.GetValue(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW', 'auto-direction type']) == (-0x79 * 0x1c0 + -0x2 * 0x913d + -0x2 * -0x206e0) % (-0x1343 * 0x2 + 0x43 * -0x6d + -0x8 * -0x862) ? 0x2b * -0xb2 + -0x1 * 0x65 + 0xa1f * 0x3 : 0x1a136fe7 + -0x12b567c * -0x1 + -0x19274f0 - (-0x1ac1ae00 + 0xbf9d3eb * 0x1 + -0x17532 * -0x1bc0);
                                    break;
                            }
                        }
                        break;
                }
            }
            break;
        case -0x1 * 0x228a + -0x105 + 0x23ba * 0x1:
            apm = -0x5 * 0xf5 + -0x15bc + 0x1ada; {
                AntiAim.SetOverride((-0x4c2285 + 0x27d8a2 * -0x2 + -0x2 * -0x624239) % (0xf9b + -0x24e1 + 0x1549)), AntiAim.SetFakeOffset(apb), AntiAim.SetRealOffset(-(0xa3 + -0x15d + 0xcb) - apb * -((0x18ebc7 + -0x1 * 0xdc383 + 0x1d8865) % (-0x1d0 * 0xa + 0x89 * -0x1e + 0x2231))), AntiAim.SetLBYOffset((0x5b0e + 0x3b07 + -0x18171 * -0x1) % (0xa0b * -0x1 + 0x3 * -0x17b + 0xe7f)), jagowalking = -0xa7 * -0x30 + 0x13a2 + 0x17 * -0x237 == '1', side = -0x1 * -0x1a773ba + 0x718229 * 0x3 + 0x776e87 * 0x1 - (-0x3835e17 + 0x243919 * -0x2f + 0xd9d4267);
            }
            break;
        case -0x485 + 0x38f * -0x9 + 0x2497:
            apm = UI.GetValue(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW', 'jag0-walk']) == (null == undefined) && UI.GetValue(['Rage', 'Anti Aim', 'General', 'Key assignment', 'Slow walk']) == (null == undefined) && UI.GetValue(['Rage', 'Anti Aim', 'General', 'Key assignment', 'legit desync']) == (-0x12a1 + -0x428 + 0x16ca === '1') ? 0xd86 + 0x194b + 0x22 * -0x123 : 0xc36 + -0x1162 + 0x571;
            break;
    }
    var aou, aov, aow, aox, aoy, aoz, apa, apb, aou, apc, apd, ape, apf, apg, aph, api, apj, apk, apl, apm, apn, apo, app, apq, apr, aps, apt, apu, apv, apw, apx, apy, apz, aqa, aqb, aqc, aqd, aqe, aqf, aqg, aqh, aqi, aqj, aqk, aql, aqm, aqn, aqo, aqp, aqq, aqr, aqs, aqt, aqu, aqv, aqw;
}
tickcount2 = -0x1d6a1 * -0x3fa + -0x1 * 0xe5f945a + 0xe6be535 - (-0x2 * -0x6caeaf + 0x14128 + -0x6812e8f * -0x1);

function dsal23422342342342344234332k312323(aqx) {
    var a = a;
    aqy = Entity.GetProp(aqx, 'CBasePlayer', 'm_vecVelocity[0]');
    return Math.sqrt(aqy[(0x3b9b0 + -0x35d5 * 0x10 + -0x1b1 * -0x106) % (-0x7d0 * 0x5 + 0x9 * 0x1ff + 0x1 * 0x151c)] * aqy[0x5062128 + 0x66ca4ea + -0x416f8fd - (-0x260743 * 0x11 + -0x671c8 * 0x12 + 0x33e * 0x33034)] + aqy[(0x28d7b6 + -0x4 * 0x12a0fa + 0xa9f8d * 0x7) % (-0x1d7b + -0x357 * -0xa + -0x3e8)] * aqy[(0x2411e9 + -0x13 * -0x12deb + -0x11c9b1) % (-0x9da + -0x2 * -0x39a + 0x2a9)]);
    var aqy;
}
flip2 = [(0x73d3 * -0x9 + 0x2fb2e + 0x32ec3) % (0x24f * 0x10 + -0x6e7 + -0x6 * 0x501)] == '';

function debug_state() {
    var a = a;
    aqz = Entity.GetLocalPlayer(), ara = Entity.GetEyePosition(aqz)[-0x9212851 * -0x1 + -0x851b6cd + 0x68c5b91 * 0x1 - (0x1a7de0c + -0x50b561 * -0x1f + -0x41207b6)], arb = Entity.GetEyePosition(aqz)[-0x25fa9f + 0x160921d + -0x3 * 0x2a1210 - (-0x16 * -0x32881 + 0x151ce97 + -0xdae860)], arc = Entity.GetEyePosition(aqz)[-0x25c7 * 0x90d + -0x1adc8d2 + 0x3f2a1db ^ 0x1 * -0x129f509 + -0x1c9912a + 0x3e2751f], CheatHooked.Print('extra pose' + position + '\x0a');
    var aqz, ara, arb, arc;
}
flip3 = NaN === NaN, tickcount = -0xaa3e6c7 + -0x622 * -0x8ce5 + 0xe9f9f72 - (-0xd56 * -0x9fbf + 0xb7683a0 + 0xc6d13b5 * -0x1);

function dsal23232342222322223233322223233323233233242323332323232322223342323223232223233434232342342342323422342342344234332k312323() {
    var a = a;
    ard = -0xe6 * 0x25 + 0x1 * 0x3d6 + 0x1db4;
    while (ard < -0x45 * -0x13 + 0x92 + -0x53f) switch (ard) {
        case 0x100c + 0x355 * 0x1 + 0x3d1 * -0x5:
            ard = UI.IsMenuOpen() == ([-0x5f0 + -0x2006 + 0x25f6] == '') ? 0x92a48c * 0x3 + -0x4d827 * -0x58 + -0x1cedbe5 ^ 0x9291e3 + -0x42523d * -0x7 + -0xcf726e * 0x1 : -0x21ce * -0x1 + 0x3da * 0x1 + -0x2536;
            break;
        case (0x13 * 0x3d6853 + 0x41d32da + -0x5da1914) % (0xb71 + -0x1400 + 0x897):
            ard = 0xd9b + 0x1820 + -0x2549;
            return;
    }
    are = -0x2578 + 0x2357 + 0x1 * 0x233;
    while (are < 0x5 * 0x77 + 0x150d + -0x16f7) switch (are) {
        case -0x1e52 + -0x1 * -0x13b8 + 0xaac:
            are = UI.GetValue(['Config', 'JAGO-YAW', 'JAGO-YAW', 'configuration']) != 0x1 * 0x4551795 + 0x10049 * 0x13 + 0x2f3b015 - (0xda17d53 + 0x4db8fa * -0x26 + 0x94d9 * 0x90e) ? 0x18a7 * 0x1 + -0x907 + 0x70 * -0x23 : -0xa27 + -0x281 + -0xb * -0x12a;
            break;
        case 0x2031 + 0x11d8 + 0x3 * -0x1093:
            are = 0x290 + 0x15ec + 0x1 * -0x1813; {
                UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'jag0-walk'], 0x1d22 * -0x7321 + -0x2 * -0x69c2b09 + -0x1 * -0x73d7e65 - (0xb6e2228 + 0x28f8c1b + 0xb * -0x9a5a4a)), UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'freestanding on edge'], -0x3de11ea + 0xbfb2ff7 + -0xc150f8 - (0xc778034 + -0x6d27715 * 0x2 + 0x5 * 0x1b50bcf)), UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'unlock fakelag'], (0x29f8d * -0x1 + -0x63e * -0x56 + 0x29e3f) % (-0x13c8 * 0x1 + -0x242 + -0x469 * -0x5)), UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'jitter movement'], (-0x7f73 * -0x1 + 0x1ad4e + 0x5 * -0x43f) % (-0x1a * -0x45 + 0x9bf + -0x10be)), UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'dynamic leg movement'], 0x55d141a + -0x60be0bc + -0x80a99b7 * -0x1 - (-0x4da1b05 + -0x60f0c6d * -0x2 + -0x6 * -0x3f7e0)), UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'legit desync at-targets'], (-0x37a8f + 0x717 * -0xc + 0x5e729) % (0x3 * 0x62b + -0x1b7 * -0x1 + -0x1 * 0x1435)), UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'body-yaw type'], -0x157f616 + 0x48cbe4f + 0x42704dc - (-0xbdebb7f + -0xd9bf8f + 0x14144823)), UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'auto-direction type'], (-0x11 * -0x33c1 + -0x38fde + -0x33 * -0xb21) % (0x3dd * 0x2 + -0x37d * 0x3 + 0x160 * 0x2)), UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'fakelag type'], -0x4fe3891 + 0x295ac0f + 0x2f3 * 0x34fcd - (-0x502ef7b + 0xc25 * 0x7c05 + 0x67c93d7)), UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'jag0-walk switch'], -0x14 * 0xa6feb8 + -0x97f14f0 + -0x3a6ef7 * -0x83 - (-0xccd338 * 0xa + 0x1 * 0xcaebd93 + 0x2ad4fb2)), UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'traced lines distance delta'], -0xd6e3c0a + 0xb97 * -0x7b07 + 0x1a5be740 - (-0x1a1f894 + -0x73 * -0x165c1d + 0x86cdaf * -0x2)), UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'fake offset divider'], (-0x1 * -0xcfe7 + 0x268a8 + -0x4bd * 0x3d) % (-0x27 * -0x4a + -0x1a13 + 0xed0)), UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'real offset divider'], (-0x54cf * -0x2 + -0x23ff2 + 0x1 * 0x3adda) % (0x4 * 0x559 + -0xb3d + -0xa24)), UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'inactive desync delta'], -0x6b82d * 0x1c + 0x4903 * -0x88a + 0x5 * 0x21b1453 - (0xd06c945 * 0x1 + 0xbe745c8 + -0x1089a78 * 0x11)), UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'jitter'], -0x30cba90 + 0x506b84c + 0xc3169 * 0x71 - (0xd82128f + 0x3 * -0x46879e1 + 0x1 * 0x7132829));
            }
            break;
        case 0x3 * 0x38f + -0x1340 + 0x8b9:
            are = 0x238d + -0x2272 + -0xb2; {
                UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'jag0-walk'], -0x1208f92 * -0x1 + -0xea4081 * -0x1 + -0x1 * 0x14e6ec5 - (-0xd48fab + -0x3ef5c5 + 0x49 * 0x65ad5)), UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'freestanding on edge'], 0x50 * -0x198d1 + 0x10f8d88 + 0x7df * 0x5aa - (0xb9e547 * 0x1 + 0x10d0071 + -0x1 * 0x10a846b)), UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'unlock fakelag'], (-0xad21a + -0x1c5ff4 + -0x1 * -0x4fe2b7) % (0x211b + -0x2 * 0x255 + -0x1c6e)), UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'jitter movement'], (0xb * -0x299b + -0x3 * 0x8743c + 0x43d706) % (-0x1 * -0xd57 + -0x1ac0 + 0xd6c)), UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'dynamic leg movement'], (-0x1122c9 + -0xd7e13 + 0x5 * 0xe4381) % (-0x1 * 0x21f3 + 0xad * -0x2a + 0x11d * 0x38)), UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'legit desync at-targets'], 0x86d54b + -0x122a906 + 0x1 * 0x1583509 - (-0xf749e8 + 0x16c4aed + 0x476048)), UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'body-yaw type'], (0xda * -0x7ab + -0x41dc * -0x8a + 0xbb7af) % (0x1 * -0x60a + -0x25a2 + 0x2baf)), UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'auto-direction type'], 0x1 * -0x1134d15 + 0x10519c3 * -0x1 + 0x2d4c826 * 0x1 - (-0xa91b5e + 0x5392 * 0x22a + 0xb0a2b7 * 0x1)), UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'fakelag type'], (0x2f * 0x2485 + -0x481d4d + 0x6a198b) % (-0xf5 + 0x7 * 0x3ec + 0x4 * -0x69f)), UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'jag0-walk switch'], (0x12b9ff * 0x4 + 0x2 * -0xc1e45 + -0x1 * 0x9fac9) % (0x1151 * -0x2 + 0xaed * -0x1 + 0x2d92)), arf = -0x1 * -0xc78c1b + -0x3 * 0x21e0c6 + 0x3ba41b - (0x768e * 0x2a5 + -0x167 * -0x435e + -0xfa707b);
                while (arf < -0x2 * 0x132d + 0x60f + 0x1 * 0x20b2) switch (arf) {
                    case -0x9 * 0x487c56 + -0x30b4a * -0x4 + 0x4139105 ^ -0x1010edc + 0xbb1bcc + -0x115 * -0x1b570:
                        arf = UI.GetValue(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW', 'body-yaw type']) == (0x8c2227 * -0x4e + 0x2 * 0x18b81ba2 + 0x1 * 0x227779e8) % (-0x1385 + -0x1 * 0xfed + 0x1 * 0x2379) ? 0x2704 + 0x12 * -0xe3 + 0x16ed * -0x1 : -0xd9 * 0x22 + -0x870 + 0x255e;
                        break;
                    case 0x31f * -0xb + -0x54 + 0x92 * 0x3d:
                        arf = -0x11 * 0x71 + -0x1ec8 * -0x1 + 0xc * -0x1e8; {
                            UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'traced lines distance delta'], (-0x15ef1a + 0x182c0e + 0x20617 * 0x13) % (0x231e + -0x224c + -0xcf)), UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'fake offset divider'], 0x8365 * 0x35 + -0xddbe85 + -0x106 * -0x17627 - (0x1150ff8 + -0x1 * -0xe4167f + -0x13cc52a)), UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'real offset divider'], (-0xa22 * 0x775 + 0x1 * 0x46243e + -0x3 * -0xf5ea7) % (-0x1fe1 + 0x1 * 0x5b3 + 0x53d * 0x5)), UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'inactive desync delta'], (-0x959 * -0x4f4 + 0x20e733 * -0x2 + 0xd * 0x4a167) % (0x2009 + -0x24f1 + 0x4eb * 0x1)), UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'jitter'], 0x9fb600 + -0xeaa25f + 0x57c48f * 0x3 - (0x54442d + -0x116d5fb + 0x17ef31b));
                        }
                        break;
                    case 0x2462 * 0x1 + 0x345 * 0x9 + -0x41b3:
                        arf = 0x98f * 0x2 + 0x60a + -0x18c1; {
                            UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'traced lines distance delta'], 0x7ad9f17 + -0x1f67951 * -0x5 + -0xa223097 - (0xd5e539b + 0x3de2020 + -0x19ee * 0x6185)), UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'fake offset divider'], -0x881a411 + -0x1153ee9 + 0x10f2b00f - (0x166f * -0x10bb + 0x151 * -0x9287b + 0x14e16a15)), UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'real offset divider'], (0x3a88 + 0x47c5 * -0xc + 0x2 * 0x29d1d) % (-0x1 * 0x10bb + 0x1 * -0xeef + -0x3 * -0xa8f)), UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'inactive desync delta'], (-0x1 * -0x262c4 + 0x24188 + -0x28cc6) % (-0xd1 * 0x2b + 0xf17 + -0x6ad * -0x3)), UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'jitter'], (0x36a74 + -0x2e056 + 0x18d68) % (-0x1e9d + -0x19e2 + 0x3882));
                        }
                        break;
                }
            }
            break;
    }
    arg = 0x3 * -0x37f + 0x20f0 + 0x13 * -0x12e;
    while (arg < 0x1bd2 + -0x1cdb * -0x1 + -0x3852) switch (arg) {
        case 0x47 * 0x3a + 0xa93 * -0x3 + 0x1d * 0x8d:
            arg = 0x733 + 0x1 * -0x2317 + -0x1 * -0x1c3f; {
                UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'faster dt'], 0x9ce * 0x164cc + -0x2 * -0x3ba1f9d + -0xdc2ba4d - (-0x613 * 0x260bf + 0xabad85a + 0xb129ce8)), UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'dynamic damage selection'], 0x3 * 0x1713004 + -0x4f79a04 + 0x1999169 * 0x5 - (-0x429337b + -0xd * 0x434776 + 0x1 * 0xeefa18e)), UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'adaptive silent'], (0x205ff + -0x23288 + -0x55 * -0x6d3) % (-0x361 + -0x269 * 0x1 + 0x5cd)), UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'dynamic safepoint type'], 0xe21a996 + 0xa4882f8 * 0x1 + -0x110e5f79 - (0x1 * -0xbdbd41a + -0xe943ed7 + -0xb4b7d * -0x2fe)), UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'dmg override amount'], (-0x18d * -0x1cf + -0x40c4f + 0x355d2) % (-0x3 * -0xbcb + -0x19db + -0x983));
            }
            break;
        case 0x25a * -0x4 + -0x14b3 + 0x1f * 0xfb:
            arg = -0xef4 + 0x701 * -0x1 + 0x1650; {
                UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'faster dt'], (0x62 * -0x5e73 + -0x2345bc + -0x1 * -0x701e6b) % (-0x1 * 0x1413 + 0x1fa1 + -0xb8b)), UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'dynamic damage selection'], 0x1e002 * 0x98 + 0xb * -0x184d5f + 0xaab333 - (-0x8c70a + 0x1363808 + -0x710fb1 * 0x1)), UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'adaptive silent'], 0x7b83ab + 0x17450bc + -0x1337319 - (-0x3afb04 + -0x1 * -0x11d6fa3 + -0x1f * 0x13a6e)), UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'dynamic safepoint type'], -0x6677c4 + -0x4eeeab * 0x1 + -0x1 * -0x171c7bd - (0x5dc0f * 0x3 + 0x5601b * -0x25 + 0x171b107)), UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'dmg override amount'], 0x178b530 + -0x7ea081 * -0x1 + -0x13af463 - (-0x47ac7f * -0x4 + -0xd2 * 0x4043 + -0x2d99b9));
            }
            break;
        case 0x1934 + 0x53 * 0x17 + -0x20a0:
            arg = UI.GetValue(['Config', 'JAGO-YAW', 'JAGO-YAW', 'configuration']) != (-0x291756 + 0x48b67 * 0xe + 0x1373 * 0xef) % (0x2231 + 0x205b + -0x4289) ? -0x691 + 0x293 * -0x6 + 0x1659 : 0x1dca + -0xcd * -0x2c + -0x40bc;
            break;
    }
    arh = 0xd88 + -0x118 * -0xf + -0x776 * 0x4;
    while (arh < 0x28 * -0x41 + 0x1231 + -0x773) switch (arh) {
        case -0x1c4 * 0x548f + 0x6d56ff + -0x85 * -0x17c2d - (-0x842300 + -0x1b666f * 0x7 + -0x2 * -0xf0bef3):
            arh = 0x1 * -0x18e0 + -0x2a * -0x40 + -0xa * -0x17f; {
                UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'watermark'], -0x1 * -0x10c5ab3 + -0x16e0d9 * -0x4 + -0xab7cc9 - (-0x29 * 0x71fdb + 0xa91f52 + 0x1375c0e)), UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'indicators'], (-0x2d0958 + 0x5a911 + 0x5010f0) % (-0x10ba + -0x26d9 + -0x5 * -0xb1e)), UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'bind list'], (-0x182b59 + 0x44839 + 0x3c93c9) % (0x1 * -0x181d + 0xb67 + 0xcb9)), UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'indicators color'], 0x632c05 * 0x1 + -0x12b70a + 0x6bec53 - (0x1755188 + -0x1 * -0xdaf9b7 + -0x1 * 0x193e9f2));
            }
            break;
        case 0x2a9 * 0xc + 0x2133 + 0x219 * -0x1f:
            arh = UI.GetValue(['Config', 'JAGO-YAW', 'JAGO-YAW', 'configuration']) != (0x10 * 0x1a2119 + 0x3d * -0x1b811 + -0x4a4695 ^ -0x1b7136e + 0x22529b + 0x283afbf * 0x1) ? 0xa8f + -0x34 * 0xb2 + 0x19f9 : 0x30c58ac + -0x5 * 0x7858fe + 0xe0c371 ^ -0x7 * -0x669215 + -0x1630248 + 0x2862d5;
            break;
        case 0x1327 * 0x2 + -0x3 * 0xccf + 0x1 * 0x7f:
            arh = -0x7d + 0x1042 * -0x2 + 0x2197 * 0x1; {
                UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'watermark'], (0x40b2b + 0x1f5f0 + 0x13 * -0x34b7) % (-0x4e * 0x61 + 0x3 * 0xed + 0x1aca)), UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'indicators'], 0x93fd6d1 + -0x7 * -0x1bbe3d7 + -0xe07449d - (-0x927dc39 + 0xcae * -0x11a5b + 0x1e7fd728)), UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'bind list'], (-0xcfd8 * -0x2 + 0x31006 + -0x14c18 * 0x2) % (-0x2198 + 0x1 * 0x20b + -0x7e4 * -0x4)), UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'indicators color'], (0x29ae6 + -0x108a4 + 0x8544) % (0x1 * -0x1afe + -0x11d1 * 0x1 + -0x1669 * -0x2));
            }
            break;
    }
    ari = -0x194e + 0x49d + -0x9d * -0x22;
    while (ari < -0xb0d + 0x1 * 0x7a9 + -0x1 * -0x3ce) switch (ari) {
        case -0xb8c * -0x2 + -0x14b4 + -0x23b:
            ari = UI.GetValue(['Config', 'JAGO-YAW', 'JAGO-YAW', 'configuration']) != (-0xe419a75 * 0x3 + -0x361e7 * -0x5a1 + 0x37ffca21) % (-0xa28 + -0x15 * 0xc1 + 0x1a06) ? -0x1237 + 0x2f * -0x3d + 0x5 * 0x5ea : -0x24d6 + -0x272 + 0x275d;
            break;
        case -0x5 * -0x6aa + -0x19ca + -0x760:
            ari = 0x3 * 0x766 + 0x1a4f + -0x3017; {
                UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'buy awp'], (0x185a1 + 0x2a2a0 + -0x210bb) % (-0x76d + -0x694 * -0x3 + 0x1 * -0xc4c)), UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'jag0-tag'], -0x7 * -0x1ce61db + 0x296f * -0x1db7 + -0x79ae8f - (0x46d6dc0 + -0xa0f * -0x1625d + -0xafe061e)), UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'thirdperson distance'], -0x2c7f654 + 0x63d43e * 0x5 + 0x8309e33 - (0x74d7 * -0x193b + -0x663a813 + 0x194361b5));
            }
            break;
        case 0x11 * 0x1b7 + 0x1 * 0x24d9 + -0x41eb:
            ari = 0x2463 + -0x261f + 0x226; {
                UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'buy awp'], 0x5d18 * 0x1d2 + 0xd2 * -0x3a60 + 0x42ce5e - (-0x324fd * -0x5c + -0x2ab9c9 * -0x3 + -0xe516fa)), UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'jag0-tag'], 0x13ae79d * -0x1 + -0x1 * -0xe3fb1b + 0x50 * 0x370f9 - (-0x2 * 0xad9b6a + -0x8a94f * -0x1 + 0x20eeed2)), UI.SetEnabled(['Config', 'JAGO-YAW', 'JAGO-YAW', 'thirdperson distance'], (0x1981 * -0x167 + 0x105698 + -0x1a * -0x24fec) % (-0x1 * 0x26fd + -0x5ad * 0x5 + -0x4361 * -0x1));
            }
            break;
    }
    var ard, are, arf, arg, arh, ari;
}
switch1 = ![];

function dsal2342234232342342342323422342342344234332k312323(arj, ark) {
    var a = a;
    return arj + Math.floor((ark - arj) * Math.random());
}
switch2 = 0x1385af1 + -0x143a3f * 0xb + 0x628712 - (0xe3 * -0x75ca + 0xc5b216 + 0x9 * 0xa91ed) === '1';

function dsal2342223243222334223232223233434232342342342323422342342344234332k312323() {
    var a = a;
    arl = Entity.IsAlive(Ragebot.GetTarget()), arm = Ragebot.GetTarget(), arn = Entity.GetLocalPlayer(), aro = Entity.GetEyePosition(arn), arp = Entity.GetName(Entity.GetWeapon(Entity.GetLocalPlayer())), arq = Entity.GetHitboxPosition(arm, -0xd07937d + 0x50e9e5 * 0x2e + 0x5d9596c - (0x8b2f63 + 0xaf16a8b * -0x1 + 0x38d34d9 * 0x5)), arr = -0x50aee5b + 0x63db0fe + 0xba * 0x87a8d - (0x42a96c6 + 0x11b * 0xa577d + -0x83d80e0), ars = dsal23422342342342344234332k312323(arm), art = -0x25aa + -0xf4 * 0x1 + 0x26f3;
    while (art < -0x16 * 0x81 + -0x17ff + -0x4 * -0x8db) switch (art) {
        case 0x18f0 + 0x14db + -0x2d97:
            art = 0x6b + 0x1dd9 + -0x1ded; {
                arr = Trace.Line(arn, aro, arq), aru = -0x4 * 0x2c1 + 0x1 * 0x5f6 + 0x1 * 0x521;
                while (aru < 0xb09 + -0xd10 + 0x28c) switch (aru) {
                    case 0xb9e + 0x2610 + -0x2eb * 0x11:
                        aru = arp == 'scar 20' || arp == 'g3sg1' ? -0x11 * 0x1fd + -0x139e + 0x35bc : -0x1193 + -0x10e2 + 0x22ca;
                        break;
                    case 0x1c63 + 0x705 + -0x1 * 0x2317:
                        aru = 0x2a6 * -0x6 + -0x13fb + 0x22 * 0x112; {
                            arv = -0x1c61 + -0x1da9 + 0x3a27;
                            while (arv < -0xa35 * -0x2 + 0x13 * -0x167 + 0x6a3) switch (arv) {
                                case 0x1fd5 + 0x1fec + 0x4 * -0xfed:
                                    arv = 0x1bda + -0xf4e + 0x1bc * -0x7; {
                                        UI.SetValue(['Rage', 'General', 'General', 'Silent aim'], 0xf62ace + -0x3d3f7f * 0x4 + 0x1 * 0xbb347c - (0xd0965b + -0x53988e * 0x1 + 0x3f6380));
                                    }
                                    break;
                                case 0x690 + -0x1 * -0xb9b + -0x11e8:
                                    arv = -0x14 * -0x93 + -0x14 * 0xca + 0x4b4; {
                                        UI.SetValue(['Rage', 'General', 'General', 'Silent aim'], (0x7d6f * -0x3 + -0xda0f + -0x41 * -0x1162) % (-0x4 * 0x7e1 + -0x17e9 + -0x377 * -0x10));
                                    }
                                    break;
                                case 0x1 * 0x3fa + 0x161 + -0x53e:
                                    arv = arr[-0x11babf3 + 0xf8 * 0xd24d + 0x10c52a9 - (-0x8f80a * -0x1d + -0xf31 * -0x1161 + -0x2 * 0xa7dd33)] > 0x189 + 0x1fd0 + -8536.5 && ars < 0x627 + 0x10c * -0x1d + 0x1943 ? 0x26c * -0x8 + 0xb * 0x107 + -0x42b * -0x2 : 0xacd + 0xc47 + -0x1707;
                                    break;
                            }
                        }
                        break;
                    case -0x903 * -0x2 + -0x3e * 0x7e + -0x1 * -0xcd3:
                        aru = -0x153b * -0x1 + -0x30f * -0xb + 0x1 * -0x365b; {
                            UI.SetValue(['Rage', 'General', 'General', 'Silent aim'], 0x81790b + 0xb6256b + 0x4 * -0x1ecf4a - (-0x4c1e65 + -0xa29917 + 0x7bd3 * 0x373));
                        }
                        break;
                }
            }
            break;
        case -0x1f * -0x1 + 0x213d + -0x69b * 0x5:
            art = arl == (-0x11 * -0x24a + -0x176 * -0x10 + -0x3e49 == '1') ? -0x107 * -0x2 + -0x1f * 0x13 + 0x5 * 0x17 : 0x860 * 0x2 + -0x4 * -0x857 + -0x5d * 0x89;
            break;
    }
    var arl, arm, arn, aro, arp, arq, arr, ars, art, aru, arv;
}
switch3 = null === undefined, CheatHooked.RegisterCallback('CreateMove', 'dsal2323234222232223323233233242323332323232322223342323223232223233434232342342342323422342342344234332k312323');

function dsal23422243223434232342342342323422342342344234332k312323(arw, arx, ary, arz, asa, asb, asc) {
    var a = a;
    asd = -0x397 * 0x8 + 0x5e4 + 0x1728;
    while (asd < 0x2357 * 0x1 + -0x10a3 * 0x2 + -0x16c) {
        switch (asd) {
            case -0x1910 + 0xb4c + -0x70c * -0x2:
                asd = 0x8e1 * 0x3 + -0x1 * 0x66a + 0x2 * -0x9fa, ase = asa;
                break;
            case 0x21be + 0x2523 + 0x7 * -0xa1a:
                asd = -0x12b6 + -0x1 * -0x1e41 + 0x5a8 * -0x2; {
                    const asf = ase * Math.PI / (0x656 + 0x1e4d + -0x23ef);
                    RenderHooked.Line(arw + Math.cos(asf) * ary, arx + Math.sin(asf) * ary, arw + Math.cos(asf) * arz, arx + Math.sin(asf) * arz, asc);
                }
                break;
            case -0x1687 + -0x1cd8 + 0x295 * 0x14:
                asd = ase < asa + asb ? -0x24b * -0x8 + -0x3 * -0x243 + -0x18f6 : 0x5 * 0x2de + -0xc76 + -0x13b;
                break;
            case -0x7 * 0x37d + -0x609 + 0x5 * 0x623:
                asd = 0x1450 + -0x1 * -0x175d + -0x2b68, ase++;
                break;
        }
    }
    var asd, ase;
}
CheatHooked.RegisterCallback('round_end', 'auto_buy_prediction');

function dsal232323422223222332323233233242323332323232322223342323223232223233434232342342342323422342342344234332k312323() {
    var a = a;
    UI.SetValue(['Misc.', 'View', 'General', 'Thirdperson Distance'], UI.GetValue(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW', 'thirdperson distance']));
}
CheatHooked.RegisterCallback('item_purchase', 'auto_buy_purchased');

function dsal2323234222323223222232332323322223233323233233242323332323232322223342323223232223233434232342342342323422342342344234332k312323() {
    var a = a;
    ash = CheatHooked.GetUsername();
    while (asj < -0x2011 * 0x1 + -0x10d5 * 0x1 + 0x3 * 0x1071) switch (asj) {
        case 0x49e * 0x3 + -0x3 * -0xc83 + 0x332 * -0x10:
            asj = 0x116a + 0x2 * 0x5b1 + 0x975 * -0x3, dsal23232342222322323233233242323332323232322223342323223232223233434232342342342323422342342344234332k312323();
            break;
        case 0x150 + 0xb3 * 0x26 + -0x1baf:
            asj = ash != asi[(-0x1 * -0x38032 + -0x1d6 * 0x1cf + 0x1e95e) % (-0xe9c + -0x1f78 + 0x2e17 * 0x1)] || ash != asi[0xd92414 + -0x13be74e + -0x17edb6 * -0xc - (0x8225fe + 0x8947f8 + -0xfcf55 * 0x5)] || ash != asi[(0x11bcc6ee * 0x3 + -0x1f76d2c6 + -0x109 * -0x12cc96) % (-0x3 * 0x8a5 + 0xe7e + 0x2 * 0x5bc)] || ash != asi[(0x1 * 0xf7bf4c1 + 0x317c5cac + -0x20b34164) % (-0x195e + 0x6ba + 0x1 * 0x12ad)] || ash != asg[0x879737 + -0x2 * 0x8ac422 + 0x1 * 0x17cdffb ^ 0x139eb * -0x64 + -0xc6f9a5 + 0x1187 * 0x1ffb] ? -0x1433 * 0x1 + -0x29c + -0xb89 * -0x2 : 0x228b + 0x3 * -0x43c + -0x156a;
            break;
    }
    ask = Entity.GetLocalPlayer(), asl = 0x89161c6 + -0x80c83d7 + 0x3ce4e58 & -0xb2 * -0x7d8c3 + -0x1 * -0x5c04253 + -0x80c6733;
    while (asl < -0xd * -0x2f6 + 0xfc5 + 0x35dd * -0x1) switch (asl) {
        case 0x3 * -0x2a4 + -0xa2d * 0x1 + 0x1244:
            asl = -0x1 * 0xeed + -0x115 * -0xa + 0x1 * 0x481; {
                asm = 0x45 * -0x1b + -0x3a + -0xc5 * -0xa;
                while (asm < -0x2257 + -0x43a + 0x7 * 0x598) switch (asm) {
                    case 0x4 * 0x300 + 0x1d8d + -0x2984:
                        asm = 0xf12 + -0x1a * -0xfd + -0x282d, dsal232323422223222232332323322223233323233233242323332323232322223342323223232223233434232342342342323422342342344234332k312323();
                        break;
                    case 0x23fe + -0x1 * 0xeed + -0x14e0:
                        asm = Entity.IsAlive(ask) ? -0x4d1 * 0x2 + 0x1 * 0xa0c + -0x61 : -0x1 * -0x21da + -0x231 * 0xa + -0xb59;
                        break;
                }
            }
            break;
        case 0x250d * 0x9a + -0x8fec3 * 0x1 + -0x7f * -0x44d - (-0x1 * 0x1b241a + -0x61200 + -0x15b * -0x23e2):
            asl = UI.GetValue(['Config', 'JAGO-YAW', 'JAGO-YAW', 'indicators']) == (null == undefined) ? -0xf19 * 0x2 + -0xa01 + 0x285e : -0x75 * 0x45 + -0x25ee + 0x45dd;
            break;
    }
    dsal232323422223222332323233233242323332323232322223342323223232223233434232342342342323422342342344234332k312323(), asn = -0x2327 + 0x25ed + -0x299;
    while (asn < -0x26a4 + 0x1 * 0x131a + -0x1408 * -0x1) switch (asn) {
        case -0x3 * 0x943 + 0x2 * -0x871 + 0x23 * 0x148:
            asn = UI.GetValue(['Config', 'JAGO-YAW', 'JAGO-YAW', 'watermark']) == (NaN !== NaN) ? 0xb0c * 0x1 + -0x1 * 0x1cdd + -0x121e * -0x1 : -0xd24 + 0x1 * -0x89b + 0x163d;
            break;
        case 0xb70 + -0x296 * -0xa + 0x29 * -0xe7:
            asn = 0x1 * -0x2fc + -0x4e9 + 0x863, watermark();
            break;
    }
    dsal2323234222232223322233323233233242323332323232322223342323223232223233434232342342342323422342342344234332k312323(), aso = -0x5 * -0x281 + -0x1 * 0x2681 + 0x53b * 0x5;
    while (aso < -0xe3 * 0x1d + 0x18e9 + 0x17b) switch (aso) {
        case 0x208b + 0x1454 + 0x1a5a * -0x2:
            aso = UI.GetValue(['Config', 'JAGO-YAW', 'JAGO-YAW', 'bind list']) == (NaN !== NaN) ? 0x134f * 0x2 + 0x1 * 0x3e7 + -0x2a25 : -0x71e * 0x5 + -0x1b91 * 0x1 + -0x662 * -0xa;
            break;
        case 0x171 * -0x2 + 0x1cc3 + 0x1981 * -0x1:
            aso = -0x1a * 0xa3 + -0x86b + 0x19a6; {
                asp = -0x1391 + 0x1f4d + -0xb62;
                while (asp < 0x1c1f + 0x874 * -0x4 + 0x62d) switch (asp) {
                    case -0x92a + 0x235e + -0x679 * 0x4:
                        asp = -0x1 * 0x583 + 0x163a + -0x103b, dsal2323234222232223322223233323233233242323332323232322223342323223232223233434232342342342323422342342344234332k312323();
                        break;
                    case 0x1853 + 0x1cd * -0xb + -0x2 * 0x215:
                        asp = Entity.IsAlive(ask) ? 0xd9f + 0x1 * 0x9ea + -0x1739 : -0x1ea8 + 0x6 * 0x9 + 0x2 * 0xf77;
                        break;
                }
            }
            break;
    }
    dsal23232342222322223233322223233323233233242323332323232322223342323223232223233434232342342342323422342342344234332k312323();
    var asg, ash, asi, asj, ask, asl, asm, asn, aso, asp;
}
CheatHooked.RegisterCallback('round_prestart', 'auto_buy_purchase2');

function dsal2342223243222334223434232342342342323422342342344234332k312323() {
    var a = a;
    asq = Globals.ChokedCommands(), asr = 0x103d + -0x2fb * 0x5 + -0x16 * 0xd;
    while (asr < -0x1 * -0x1709 + 0x16 * -0x29 + -0x55 * 0x39) switch (asr) {
        case 0x35e * -0x3 + 0x194a + 0x1 * -0xf20:
            asr = -0x5 * -0x1ce + -0x59f * -0x1 + 0xe0f * -0x1; {
                ass = 0x2058 + 0x2595 + -0x5 * 0xdf0;
                while (ass < 0x15a0 + -0x2522 + 0xfef) switch (ass) {
                    case -0x10d9 + -0x2f * 0x1f + 0x16c7:
                        ass = asq == 0x25d8880 * 0x5 + -0x1 * -0x81095bf + -0xc88732a - (-0x9294869 + 0xc732fa1 + 0x411e5dd) ? -0xfd1 + 0x23 * 0x67 + 0x1dd * 0x1 : 0x1 * -0x1be9 + 0xb87 + -0x1 * -0x10b9;
                        break;
                    case -0x1889 + 0xe9c + 0xa0e:
                        ass = -0x2 * 0x9d3 + 0x16 * 0x1b2 + 0x1 * -0x1139, Exploit.OverrideShift(0x1105 + -0x527 + -0xbcf);
                        break;
                    case 0x1743 + 0x6ab + -0x1d97:
                        ass = 0x2 * 0x69a + 0x14e3 + 0x2 * -0x10d5, Exploit.OverrideShift(0x1 * 0xe7fe197 + 0x12f9 * -0x4b9d + -0x1897ecd - (-0x1 * -0x5f863b1 + -0x68cc78e + -0x6 * -0x152b2d3));
                        break;
                }
            }
            break;
        case 0xda4 + 0xb * 0x31d + -0x2fa0:
            asr = 0x1 * 0x1471 + 0x5 * 0x5ab + -0x3032 * 0x1; {
                Exploit.OverrideShift(0x342 * -0x6 + 0xb * -0x377 + 0x471 * 0xd);
            }
            break;
        case -0x1cb5 * 0x1 + 0x109c + -0xc51 * -0x1:
            asr = UI.GetValue(['Config', 'SUBTAB_MGR', 'JAGO-YAW', 'JAGO-YAW', 'fakelag type']) == 0x4d37add * -0x2 + -0x1 * -0x870262c + 0x719da06 - (0x9bd10ce + 0xa77b7bf + -0xe51be19) ? -0x7 * -0x26e + 0x6 * 0x1d7 + -0x1bc9 * 0x1 : 0x1150 + 0x199d + 0x1 * -0x2add;
            break;
    }
    Convar.SetInt('cl_clock_correction', (0x26b * -0x10d + 0x11488 * 0x1 + 0x38d6d) % (0x3 * 0x199 + 0x19d + -0x665));
    var asq, asr, ass;
}
CheatHooked.RegisterCallback('Draw', 'dsal2323234222323223222232332323322223233323233233242323332323232322223342323223232223233434232342342342323422342342344234332k312323');
var predicted_time, buy, jagowalking, lastcurt, switch_question, tickcount, flip, tickcount2, flip2, flip3, tickcount, switch1, switch2, switch3;