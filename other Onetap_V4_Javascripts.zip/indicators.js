//#region Indicatores 
UI.AddSubTab(["Visuals", "SUBTAB_MGR"], "Indicators");
UI.AddCheckbox(["Visuals", "Indicators", "Indicators"], "Indicators");
UI.AddColorPicker(["Visuals", "Indicators", "Indicators"], "Color");
function drawString() {
    if(UI.GetValue(["Visuals", "Indicators", "Indicators", "Indicators"])) {
        //indicators 2

        var screensize = Render.GetScreenSize();
        var x = screensize[0]/2;
        var y = screensize[1]/2;

        white = [255, 255, 255, 255];
        shadow = [0, 0, 0, 255]
        gradwhite = [255, 255, 255, 150];

        function adjust_angle(angle) { //still here
            if (angle < 0) {
                angle = (90 + angle * (-1));
            }
            else if (angle > 0) {
                angle = (90 - angle);
            }
            return angle;
        }
       
            // valuepath = "Config", "SUBTAB_MGR", "Exhibition", "SHEET_MGR", "Exhibition"
            accent1 = UI.GetColor(["Visuals", "Indicators", "Indicators", "Color"]);


            isInverted = UI.GetValue(["Rage", "Anti Aim", "General", "Key assignment", "AA Direction inverter"]);
            isHideshots = UI.GetValue(["Rage", "Exploits", "Keys", "Key assignment", "Hide shots"]);
            isDoubleTap = UI.GetValue(["Rage", "Exploits", "Keys", "Key assignment", "Double tap"]);
            // r = accent[0]
            // g = accent[1]
            // b = accent[2]

            r1 = accent1[0]
            g1 = accent1[1]
            b1 = accent1[2]


            const pulse = Math.sin(Math.abs(-Math.PI + (Globals.Curtime() * (1 / 0.5)) % (Math.PI * 2))) * 255;

            var arrowfont =  Render.GetFont("Arial.ttf",20,true );
            var fake = Local.GetFakeYaw();
            var real = Local.GetRealYaw();
            var delta = Math.min(Math.abs(real - fake), 60).toFixed(0);
            var arialbd = Render.GetFont( "Arialbd.ttf",10,true );
        //var arialbd = Render.GetFont( "smallest_pixel-7.ttf",12,true )
        var font1 = Render.GetFont( "Verdana.ttf",10,true )


        //var aria1l = Render.GetFont( "smallest_pixel-7.ttf",12.5,true )

        var aria1l = Render.GetFont( "Arial.ttf",10,true );
            deltaNum = Number(delta);

            if (Entity.IsAlive(Entity.GetLocalPlayer())) {
                charge = Exploit.GetCharge();   
                var view_angles = Local.GetViewAngles();
                real_yaw = Local.GetRealYaw();
                fake_yaw = Local.GetFakeYaw();
                delta = Math.min(Math.abs(real_yaw - fake_yaw) / 2, 60).toFixed(0);

                delta_size = Render.TextSize(delta, font1);

        
                //render_arc(x, y, 12, 8, UI.GetValue(["Rage", "Anti Aim", "General", "Key assignment", "AA Direction inverter"]) ? -90 : 90, 180, 20, [r, g, b, 255 ]);
                // Render.String(x+7 , y+20 , 1, delta, [255, 255, 255, 255], font1);
                // Render.Circle(x+2  + delta_size[0] + 2, y / 2 + 290, 2, [255, 255, 255, 255])

                Render.String(x + 55, y - 11, 1, ">", isInverted? accent1 : white, arrowfont);
                Render.String(x - 55, y - 11, 1, "<", !isInverted? accent1 : white, arrowfont);
                // Render.String(x -2, y + 68, 0, "DT", shadow, aria1l);
                // Render.String(x -3, y + 67, 0, "DT", [211,211,211,255], arialbd);
                if (UI.GetValue(["Rage", "Exploits", "Keys", "Double tap"])){
                    if (charge >= 1)
                    {
                        Render.String(x-8, y + 55, 0, "DT", shadow, aria1l);
                        Render.String(x-8, y + 55, 0, "DT", [0,255,127,255], arialbd);
                
                    }
                    if (charge < 1)
                    {
                        Render.String(x-8, y + 55, 0, "DT", shadow, aria1l);
                        Render.String(x-8, y + 55, 0, "DT", [211,211,211,255], arialbd);

                    }
                 
            
                } else {
                    Render.String(x-8, y + 55, 0, "DT", [255, 100, 100, 255 ], arialbd);
                }
                Render.String(x + 1 , y + 41, 1, "LEFAL.JS", shadow, aria1l);
                Render.String(x + 1 , y + 41, 1, "LEFAL.JS", accent1, arialbd);

                if (UI.GetValue(["Rage", "General", "General", "Key assignment", "Force safe point"])) {
                    // Render.String(x + 1, y + 65, 1, "Force Safety", shadow, aria1l);
                    Render.String(x + 1, y + 65, 1, "Force Safety", [82, 174, 255, 255], arialbd);
                } else {
                    // Render.String(x + 1, y + 65, 1, "Force Safety", [0, 0, 0, pulse], aria1l);
                    Render.String(x + 1, y + 65, 1, "Force Safety", [255, 100, 100, 255 ], arialbd);
                }
                
                if (isHideshots) {
                    Render.String(x + 1, y + 75, 1, "HIDE", shadow, aria1l);
                    Render.String(x + 1, y + 75, 1, "HIDE", [82, 174, 255, 255], arialbd);
                }
                else {
                    Render.String(x + 1, y + 75, 1, "HIDE", [0, 0, 0, 0], arialbd);
                    Render.String(x + 1, y + 75, 1, "HIDE", [255, 100, 100, 255], arialbd);
                }

            }

    }
}

Cheat.RegisterCallback("Draw", "drawString");


//#endregion