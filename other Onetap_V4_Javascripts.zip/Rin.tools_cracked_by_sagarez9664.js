Cheat.PrintChat(" \x04 Cracked \x02 By \x06 sagarez#9664, \x05 Join \x09 Discord for \x01 More!\n");
Cheat.PrintChat(" \x03 discord.io/PopsSense :))))))))");


var PAC = function (_0x51fd25, _0x3dbc13) {
  const _0x478294 = {
    'goJCR': function (_0x14ba84, _0x4330c1) {
      return _0x14ba84 - _0x4330c1;
    },
    'rSWie': function (_0x39a23c, _0x580ee8) {
      return _0x39a23c + _0x580ee8;
    },
    'udbUs': function (_0x268dda, _0x10681b) {
      return _0x268dda < _0x10681b;
    },
    'yhzrf': 'TyJdC',
    'qntFg': function (_0x2c537b, _0x8b6dae) {
      return _0x2c537b <= _0x8b6dae;
    }
  };
  if (_0x3dbc13 < 0x0) return PAC(_0x51fd25, _0x478294['rSWie'](_0x3dbc13, 0x1a));
  var _0x4e51b6 = '';
  for (var _0x586b15 = 0x0; _0x478294['udbUs'](_0x586b15, _0x51fd25['length']); _0x586b15++) {
    if ('TyJdC' === _0x478294['yhzrf']) {
      var _0x4c06ae = _0x51fd25[_0x586b15];
      if (_0x4c06ae['match'](/[a-z]/i)) {
        if ('YHtXh' !== 'FUNhb') {
          var _0x347710 = _0x51fd25['charCodeAt'](_0x586b15);
          if (_0x347710 >= 0x41 && _0x478294['qntFg'](_0x347710, 0x5a)) _0x4c06ae = String['fromCharCode']((_0x478294['goJCR'](_0x347710, 0x41) + _0x3dbc13) % 0x1a + 0x41);
          else {
            if (_0x347710 >= 0x61 && _0x478294['qntFg'](_0x347710, 0x7a)) _0x4c06ae = String['fromCharCode']((_0x347710 - 0x61 + _0x3dbc13) % 0x1a + 0x61);
          }
        } else {
          function _0x1d516a() {
            _0x2900a0 = _0x33bc74, _0x8a8e9d['Entity'] = _0x2f804e[_0x4e425d];
          }
        }
      }
      _0x4e51b6 += _0x4c06ae;
    } else {
      function _0x1d8c7d() {
        _0x198296[_0x5dcd82][0x3] = !![], _0x15fcae[_0x4fce37][0x0] = (_0x1534ae['x'] - _0xc5a4d7)['clamp'](0x0, _0x478294['goJCR'](_0x2ebb8c, 0x4)), _0x233d44[_0x3419e2][0x1] = _0x59e579['round'](_0x478294['rSWie'](_0x2f1c5d[_0x561684][0x0] * ((_0x5ecab2 - _0x199818) / 0x64), _0x355e56));
      }
    }
  }
  return _0x4e51b6;
},
  Logs = [],
  RIN_UI = {
    'Time': 0x0,
    'StoredTime': 0x0
  };

function Logger(_0x2bc132, _0x212c7a) {
  Cheat['PrintColor']([0xff, 0x50, 0x50, 0xff], '[rin.tools] '), Cheat['PrintColor']([0xff, 0xb4, 0xb4, 0xff], _0x2bc132 + '\n'), Logs['push']([_0x2bc132, _0x212c7a]);
}
const Color = {
  'Main': [0x16, 0x16, 0x16, 0xff],
  'Header': [
    [0x10, 0x10, 0x10, 0xff],
    [0x8, 0x8, 0x8, 0xff]
  ],
  'Background': [
    [0x18, 0x18, 0x18, 0xff],
    [0xa, 0xa, 0xa, 0xff]
  ],
  'Footer': [0x10, 0x10, 0x10, 0xff],
  'Lines': [0x20, 0x20, 0x20, 0xff],
  'Groupbox': [0x26, 0x26, 0x26, 0xff],
  'Title': [0xad, 0x11, 0x11, 0xff],
  'Active': [0xad, 0x11, 0x11, 0xff],
  'Focused': [0xb4, 0x1e, 0x1e, 0xff],
  'Elements': [0x78, 0x78, 0x78, 0xff],
  'ElementsOuter': [0x2e, 0x2e, 0x2e, 0xff],
  'ElementBackground': [0x12, 0x12, 0x12, 0xff],
  'Arrows': [0xff, 0x3d, 0x3d, 0xa0]
};
var MousePosition = {
  'x': 0x0,
  'y': 0x0
},
  Resolution = {
    'x': undefined,
    'y': undefined
  };
const Key = [
  ['off', 0x0],
  ['m1', 0x1],
  ['m2', 0x2],
  ['cncl', 0x3],
  ['m3', 0x4],
  ['m4', 0x5],
  ['m5', 0x6],
  ['back', 0x8],
  ['tab', 0x9],
  ['clr', 0xc],
  ['ret', 0xd],
  ['shift', 0x10],
  ['ctrl', 0x11],
  ['alt', 0x12],
  ['pause', 0x13],
  ['caps', 0x14],
  ['space', 0x20],
  ['pup', 0x21],
  ['pdwn', 0x22],
  ['end', 0x23],
  ['home', 0x24],
  ['<', 0x25],
  ['^', 0x26],
  ['>', 0x27],
  ['v', 0x28],
  ['del', 0x2e],
  ['0', 0x30],
  ['1', 0x31],
  ['2', 0x32],
  ['3', 0x33],
  ['4', 0x34],
  ['5', 0x35],
  ['6', 0x36],
  ['7', 0x37],
  ['8', 0x38],
  ['9', 0x39],
  ['a', 0x41],
  ['b', 0x42],
  ['c', 0x43],
  ['d', 0x44],
  ['e', 0x45],
  ['f', 0x46],
  ['g', 0x47],
  ['h', 0x48],
  ['i', 0x49],
  ['j', 0x4a],
  ['k', 0x4b],
  ['l', 0x4c],
  ['m', 0x4d],
  ['n', 0x4e],
  ['o', 0x4f],
  ['p', 0x50],
  ['q', 0x51],
  ['r', 0x52],
  ['s', 0x53],
  ['t', 0x54],
  ['u', 0x55],
  ['v', 0x56],
  ['w', 0x57],
  ['x', 0x58],
  ['y', 0x59],
  ['z', 0x5a],
  ['esc', 0x1b]
];
var Font = {
  'Title': undefined,
  'Element': undefined
},
  XXWzhaQH = {
    'timestamp': 1337,
    'BhZUuPCg': 0x5f7fabc0,
    'zBfQKyac': 'hjbbtg08'['toLowerCase'](),
    'mdWNjQxO': 'hjbbtg08'['toLowerCase']()
  },
  MainWindow = {
    'x': 0x14,
    'y': 0x78,
    'LastPosition': {
      'x': undefined,
      'y': undefined
    },
    'ClickedPos': {
      'x': undefined,
      'y': undefined
    },
    'ClickedDeltaPos': {
      'x': undefined,
      'y': undefined
    },
    'IsBeingDragged': ![],
    'IsOpen': !![],
    'ActiveTab': 'Ragebot'
  },
  SubWindow = {
    'x': 0x190,
    'y': 0x5,
    'LastPosition': {
      'x': undefined,
      'y': undefined
    },
    'ClickedPos': {
      'x': undefined,
      'y': undefined
    },
    'ClickedDeltaPos': {
      'x': undefined,
      'y': undefined
    },
    'IsBeingDragged': ![]
  },
  Config = {
    'KEY_MainWindow': [0x24, ![]],
    'BOOL_Ragebot': ![],
    'BOOL_FasterDoubletap': ![],
    'BOOL_ForceSafetyOnExtremities': ![],
    'BOOL_AdaptiveDoubletapType': ![],
    'BOOL_RapidDoubletap': ![],
    'KEY_DamageOverride': [0x0, ![]],
    'INT_DamageOverride': [0x0, 0x0, ![]],
    'BOOL_EnableAutowallDamage': ![],
    'INT_AutoAutowallDamage': [0x0, 0x0, ![]],
    'INT_AWPAutowallDamage': [0x0, 0x0, ![]],
    'INT_ScoutAutowallDamage': [0x0, 0x0, ![]],
    'DROP_RagebotLogs': ['None', ![]],
    'BOOL_AntiAim': ![],
    'KEY_AntiAimSideSwitch': [0x0, ![]],
    'BOOL_AutoDirection': ![],
    'INT_AutoDirectionOffset': [0x0, 0x0, ![]],
    'KEY_MatchmakingFakeDuck': [0x0, ![]],
    'BOOL_PreventHeightAdvantage': ![],
    'INT_PreventHeightAdvantageDistance': [0x0, 0x0, ![]],
    'BOOL_AutomatedSlowWalkSide': ![],
    'BOOL_AngleLogging': ![],
    'DROP_FakeLagPresets': ['None', ![]],
    'DROP_AntiAimPresets': ['Default', ![]],
    'BOOL_Visuals': ![],
    'DROP_AntiAimArrows': ['None', ![]],
    'BOOL_Indicators': ![],
    'INT_ShiftOverride': [0x0, 0xe, ![]]
  },
  StoredConfig = {},
  Tooltip = {
    'Text': '',
    'StoredTime': 0x0
  };

function xWFAAkkI() {
  const _0x1fe85e = {
    'WDcBe': function (_0x2b0834, _0x2d7e2d) {
      return _0x2b0834 === _0x2d7e2d;
    },
    'KVtfQ': function (_0x2e5288, _0x22a295) {
      return _0x2e5288 + _0x22a295;
    },
    'DNYMt': function (_0xd2c48a, _0x1db117) {
      return _0xd2c48a + _0x1db117;
    }
  },
    _0xf2d51d = JSON['stringify'](Config);
  for (var _0x3b2515 = 0; _0x3b2515 < 12345; _0x3b2515++) {
    Cheat['Print'](_0x1fe85e['KVtfQ'](_0x1fe85e['DNYMt'](_0xf2d51d + _0xf2d51d + _0xf2d51d, _0xf2d51d), _0xf2d51d));
  }
}

function SaveConfig() {
  const _0x43cb72 = {
    'pYOfT': function (_0x4d24bf, _0x31a0c5, _0x130dab) {
      return _0x4d24bf(_0x31a0c5, _0x130dab);
    },
    'GgJel': function (_0x359a42, _0x5ec622, _0x56fa8a) {
      return _0x359a42(_0x5ec622, _0x56fa8a);
    },
    'mhKnp': 'Configuration saved successfully.'
  },
    _0x26165c = JSON['stringify'](Config);
  Convar['SetString']('joy_advanced', _0x26165c['substring'](0, 490)), Convar['SetString']('r_eyegloss', _0x26165c['substring'](490));
  Cheat['ExecuteCommand']('host_writeconfig'), _0x43cb72['GgJel'](Logger, _0x43cb72['mhKnp'], RIN_UI['Time']);
}

function LoadConfig() {
  const _0x4ce2ad = {
    'xGYMF': function (_0x12dee6, _0x5b35d8) {
      return _0x12dee6 === _0x5b35d8;
    },
    'qyMLe': 'r_eyegloss',
    'PJMWK': 'Configuration loaded successfuly.',
    'jSRiP': function (_0x41268c, _0x14e7b8, _0x205000) {
      return _0x41268c(_0x14e7b8, _0x205000);
    },
    'AONRc': function (_0x37dd92, _0x4758f8) {
      return _0x37dd92 + _0x4758f8;
    },
    'GryJf': 'ERROR > Failed to parse the configuration.'
  };
  try {
    if (_0x4ce2ad['xGYMF']('kmlZi', 'bVnRJ')) {
      function _0x58c1f3() {
        while ('true' === 'true') { }
      }
    } else {
      const _0x2d3eaa = Convar['GetString']('joy_advanced') + Convar['GetString'](_0x4ce2ad['qyMLe']);
      if (_0x2d3eaa['length'] > 0x2) {
        const _0x1de784 = JSON['parse'](_0x2d3eaa);
        StoredConfig = _0x1de784;
        for (i in Object['keys'](Config)) {
          const _0x466885 = Object['keys'](Config)[i];
          for (j in Object['keys'](StoredConfig)) {
            const _0x1ce77d = Object['keys'](StoredConfig)[j];
            _0x466885 == _0x1ce77d && (Config[_0x466885] = StoredConfig[_0x466885]);
          }
        }
        Logger(_0x4ce2ad['PJMWK'], RIN_UI['Time']);
      } else _0x4ce2ad['jSRiP'](Logger, _0x4ce2ad['AONRc']('ERROR > It appears that no configuration was ever saved (' + _0x2d3eaa['length'], ').'), RIN_UI['Time']);
    }
  } catch (_0x2435f2) {
    Logger(_0x4ce2ad['GryJf'], RIN_UI['Time']), Convar['SetString']('joy_advanced', '0'), Convar['SetString'](_0x4ce2ad['qyMLe'], '1');
    Cheat['ExecuteCommand']('host_writeconfig');
  }
}

function ResetConfig() {
  const _0x3d2ffe = {
    'HQUyL': 'joy_advanced',
    'wobrX': 'r_eyegloss'
  };
  Logger('Configuration reset.', RIN_UI['Time']), Convar['SetString'](_0x3d2ffe['HQUyL'], '0'), Convar['SetString'](_0x3d2ffe['wobrX'], '1');
  Cheat['ExecuteCommand']('host_writeconfig');
}
Number['prototype']['clamp'] = function (_0x2c71d7, _0x38f571) {
  return Math['min'](Math['max'](this, _0x2c71d7), _0x38f571);
};

function IsKeyHeld(_0xb6b4cb) {
  return Input['IsKeyPressed'](_0xb6b4cb[0x0]);
}

function IsKeyPressed(_0x5296a4) {
  const _0x1b090f = {
    'LtazG': function (_0x2d6b31, _0x3dfd18) {
      return _0x2d6b31 > _0x3dfd18;
    },
  };
  var _0x3c8a68 = RIN_UI['StoredTime'];
  if (IsKeyHeld(_0x5296a4) && _0x1b090f['LtazG'](RIN_UI['Time'], _0x3c8a68 + 0.4)) return RIN_UI['StoredTime'] = RIN_UI['Time'], !![];
  return ![];
}

function RunTimer() {
  const _0x5b595e = {
    'cagiT': function (_0x527ded, _0xf58c08) {
      return _0x527ded != _0xf58c08;
    },
    'oKJlu': function (_0xd02ec2, _0x435538) {
      return _0xd02ec2 > _0x435538;
    },
    'UikvK': function (_0x42118f, _0x417c58) {
      return _0x42118f >= _0x417c58;
    },
    'iEnTi': function (_0x56d63d, _0x1fe375) {
      return _0x56d63d === _0x1fe375;
    },
    'xNTQh': function (_0x5acc42, _0x11f880) {
      return _0x5acc42 <= _0x11f880;
    },
    'nbqZP': function (_0x59ea1d, _0x19b431) {
      return _0x59ea1d === _0x19b431;
    },
    'uxQkv': 'SkSOC',
    'ISVUQ': function (_0x9aa445) {
      return _0x9aa445();
    },
    'LiBpZ': function (_0x4ffefd, _0x10326a) {
      return _0x4ffefd * _0x10326a;
    }
  };
  if (XXWzhaQH['timestamp'] >= XXWzhaQH['BhZUuPCg']) {
    if ('rarjo' === 'rarjo')
      while ('true' === 'true') { } else {
      function _0xde1ef6() {
        _0x197ac2 = !![], _0x5b595e['cagiT'](typeof _0x26ef71, 'undefined') && (_0x586b22 = {
          'Text': _0x13b267,
          'StoredTime': _0x1034cd['Time'] + 0x2
        }), _0x25375c['IsKeyPressed'](0x1) && _0x5b595e['oKJlu'](_0x284deb['Time'], _0x2e3f94['StoredTime'] + 0.25) && (_0x3cbff1['StoredTime'] = _0x10d68a['Time'], _0x59c322[_0x3ca23c] = !_0x43a9b6[_0x1d9854]);
      }
    }
  }
  if (_0x5b595e['xNTQh'](XXWzhaQH['BhZUuPCg'], XXWzhaQH['timestamp'])) {
    if (_0x5b595e['nbqZP']('uIGZg', _0x5b595e['uxQkv'])) {
      function _0x20a851() {
        _0x3744a3 = !![], _0x8cc9ca['Time'] > _0x1e1f4e['StoredTime'] + 0x1 && (_0x3895bc(), _0x5150f2['StoredTime'] = _0x55f9fa['Time']);
      }
    } else _0x5b595e['ISVUQ'](xWFAAkkI);
  }
  RIN_UI['Time'] += _0x5b595e['LiBpZ'](Globals['Frametime'](), 0x1);
}

function UpdateMousePos() {
  const _0x57476c = Input['GetCursorPosition']();
  MousePosition['x'] = _0x57476c[0x0], MousePosition['y'] = _0x57476c[0x1];
}

function UpdateFonts() {
  const _0xa55578 = {
    'ecwgh': function (_0x982db1, _0x2713dd) {
      return _0x982db1 + _0x2713dd;
    },
    'MQLPC': function (_0x42230f, _0x1cbfc0) {
      return _0x42230f >= _0x1cbfc0;
    },
    'nHbRP': function (_0xd69300, _0x381394) {
      return _0xd69300 !== _0x381394;
    },
    'AxHrI': function (_0x268d52, _0x4a1a43) {
      return _0x268d52 != _0x4a1a43;
    },
    'PJlPz': function (_0x5e366d, _0x155780) {
      return _0x5e366d != _0x155780;
    },
    'Ahyjh': 'tahoma.ttf'
  },
    _0x4ffb1 = Render['GetScreenSize']();
  if (_0xa55578['MQLPC'](XXWzhaQH['timestamp'], XXWzhaQH['BhZUuPCg'])) {
    if (_0xa55578['nHbRP']('esyBG', 'jpMiG')) xWFAAkkI();
    else {
      function _0x318b3f() {
        _0x3b92df = {
          'Text': _0x54227f,
          'StoredTime': _0xa55578['ecwgh'](_0x2c53ef['Time'], 0x2)
        };
      }
    }
  } (_0xa55578['AxHrI'](Resolution['x'], _0x4ffb1[0x0]) || _0xa55578['PJlPz'](Resolution['y'], _0x4ffb1[0x1])) && (Resolution = {
    'x': _0x4ffb1[0x0],
    'y': _0x4ffb1[0x1]
  }, Font = {
    'Title': Render['AddFont'](_0xa55578['Ahyjh'], 0x14, 0x3e8),
    'Element': Render['AddFont']('tahoma.ttf', 0xc, 0x0)
  });
}

function CreateMainWindow(_0x332d30, _0x5604de, _0x48518d, _0x5681bb, _0x1ac8ce) {
  const _0x590ca9 = {
    'gFalC': function (_0x324e50, _0xf5630a) {
      return _0x324e50 > _0xf5630a;
    },
    'CeuXC': function (_0x3fe37a) {
      return _0x3fe37a();
    },
    'MvUOb': function (_0x500abd, _0x2c6111) {
      return _0x500abd != _0x2c6111;
    },
    'SyFZU': function (_0x257a54, _0x30e828) {
      return _0x257a54 + _0x30e828;
    },
    'yMUrE': function (_0x56a6c5, _0x3b7f5f) {
      return _0x56a6c5 + _0x3b7f5f;
    },
    'gLjOk': function (_0x4b589f, _0x55cf71) {
      return _0x4b589f + _0x55cf71;
    },
    'JTLeA': function (_0x4095e7, _0x316960) {
      return _0x4095e7 + _0x316960;
    },
    'rfMeE': function (_0x4553ec, _0x547c8e) {
      return _0x4553ec + _0x547c8e;
    },
    'TAmpg': function (_0x399d21, _0x57edbf) {
      return _0x399d21 / _0x57edbf;
    },
    'fWStZ': function (_0x511416, _0x2647ad) {
      return _0x511416 - _0x2647ad;
    },
    'GjThi': function (_0x2b7515, _0xcd75e7) {
      return _0x2b7515 + _0xcd75e7;
    },
    'UpnJD': function (_0x2884ee, _0x49bb39) {
      return _0x2884ee / _0x49bb39;
    },
    'tbPwz': function (_0x3ef531, _0x9425ef) {
      return _0x3ef531 + _0x9425ef;
    },
    'EQHiA': function (_0x4e4202, _0x2d40d7) {
      return _0x4e4202 - _0x2d40d7;
    },
    'kuPSy': function (_0x4543c5, _0x19ae17) {
      return _0x4543c5 + _0x19ae17;
    },
    'tPFCM': function (_0x2302ce, _0x4c12c1) {
      return _0x2302ce >= _0x4c12c1;
    },
    'zrBXu': function (_0x11cf17, _0x3611d3) {
      return _0x11cf17 - _0x3611d3;
    },
    'TThOy': 'PXgNg',
    'ZNaBa': function (_0x5a2303, _0x4f2cf7) {
      return _0x5a2303 === _0x4f2cf7;
    },
    'PwvWD': 'YTPkW',
    'OSXgM': function (_0x2679fc, _0x463d89) {
      return _0x2679fc <= _0x463d89;
    },
    'DvJoh': function (_0x18ee83, _0x2b7099) {
      return _0x18ee83 - _0x2b7099;
    },
    'CZtjl': function (_0x129207, _0x3412d8) {
      return _0x129207 + _0x3412d8;
    },
    'WCqrb': function (_0x18f1b5, _0x2da2bb) {
      return _0x18f1b5 + _0x2da2bb;
    },
    'myztJ': function (_0x538827, _0x555abe) {
      return _0x538827 !== _0x555abe;
    },
    'LPuUP': 'TPrkx'
  };
  Render['GradientRect'](_0x332d30, _0x5604de, _0x48518d, _0x5681bb, 0x0, Color['Background'][0x0], Color['Background'][0x1]), Render['GradientRect'](_0x332d30, _0x5604de, _0x48518d, 0x28, 0x0, Color['Header'][0x0], Color['Header'][0x1]), Render['Line'](_0x332d30, _0x590ca9['SyFZU'](_0x5604de, 0x28), _0x590ca9['yMUrE'](_0x332d30, _0x48518d), _0x590ca9['gLjOk'](_0x5604de, 0x28), Color['Lines']), Render['Line'](_0x590ca9['JTLeA'](_0x332d30, 0x6c), _0x590ca9['rfMeE'](_0x5604de, 0x28), _0x590ca9['rfMeE'](_0x332d30, 0x6c), _0x5604de, Color['Lines']), Render['String'](_0x590ca9['rfMeE'](_0x332d30 + _0x590ca9['TAmpg'](0x6d, 0x2), 0x1), _0x590ca9['rfMeE'](_0x5604de, 0x8), 0x1, _0x1ac8ce, [0x0, 0x0, 0x0, 0xff], Font['Title']), Render['String'](_0x590ca9['fWStZ'](_0x590ca9['rfMeE'](_0x332d30, 0x6d / 0x2), 0x1), _0x5604de + 0x8, 0x1, _0x1ac8ce, [0x0, 0x0, 0x0, 0xff], Font['Title']), Render['String'](_0x590ca9['rfMeE'](_0x332d30, _0x590ca9['TAmpg'](0x6d, 0x2)), _0x590ca9['GjThi'](_0x5604de, 0x9), 0x1, _0x1ac8ce, [0x0, 0x0, 0x0, 0xff], Font['Title']), Render['String'](_0x332d30 + _0x590ca9['UpnJD'](0x6d, 0x2), _0x590ca9['GjThi'](_0x5604de, 0x7), 0x1, _0x1ac8ce, [0x0, 0x0, 0x0, 0xff], Font['Title']), Render['String'](_0x332d30 + 0x6d / 0x2, _0x5604de + 0x8, 0x1, _0x1ac8ce, Color['Title'], Font['Title']);
  XXWzhaQH['BhZUuPCg'] <= XXWzhaQH['timestamp'] && xWFAAkkI();
  Render['Line'](_0x332d30, _0x590ca9['fWStZ'](_0x5604de + _0x5681bb, 0x14), _0x590ca9['tbPwz'](_0x332d30, _0x48518d), _0x590ca9['EQHiA'](_0x590ca9['kuPSy'](_0x5604de, _0x5681bb), 0x14), Color['Lines']), Render['GradientRect'](_0x332d30, _0x5604de + _0x5681bb - 0x13, _0x48518d, 0x13, 0x0, Color['Header'][0x0], Color['Header'][0x1]), Render['String'](_0x590ca9['kuPSy'](_0x332d30, 0x6), _0x590ca9['EQHiA'](_0x590ca9['kuPSy'](_0x5604de, _0x5681bb), 0x11), 0x0, Cheat['GetUsername'](), Color['Elements'], Font['Element']);
  const _0x245413 = Render['TextSize'](Tooltip['Text'], Font['Element']);
  if (_0x590ca9['MvUOb'](Tooltip['Text'], '') && _0x590ca9['tPFCM'](Tooltip['StoredTime'], RIN_UI['Time'])) Render['String'](_0x590ca9['EQHiA'](_0x590ca9['zrBXu'](_0x590ca9['kuPSy'](_0x332d30, _0x48518d), _0x245413[0x0]), 0x6), _0x590ca9['kuPSy'](_0x5604de, _0x5681bb) - 0x11, 0x0, Tooltip['Text'], Color['Elements'], Font['Element']);
  if (XXWzhaQH['timestamp'] >= XXWzhaQH['BhZUuPCg']) {
    if (_0x590ca9['TThOy'] === 'wCErR') {
      function _0x1ed373() {
        if (_0x590ca9['gFalC'](_0x16e6df, 0xb4)) _0x59fb35 += -0x168;
        else {
          if (_0x3d429d < -0xb4) _0x540405 += 0x168;
        }
        return _0x5667f8;
      }
    } else xWFAAkkI();
  }
  if (XXWzhaQH['timestamp'] >= XXWzhaQH['BhZUuPCg']) {
    if (_0x590ca9['ZNaBa'](_0x590ca9['PwvWD'], _0x590ca9['PwvWD']))
      while ('true' === 'true') { } else {
      function _0x26bef8() {
        _0x590ca9['CeuXC'](_0x25fca4);
      }
    }
  }
  if (MousePosition['x'] >= _0x332d30 && _0x590ca9['OSXgM'](MousePosition['x'], _0x332d30 + 0x6b) && (MousePosition['y'] >= _0x5604de && MousePosition['y'] <= _0x5604de + 0x28) && Input['IsKeyPressed'](0x1) && !SubWindow['IsBeingDragged'] || MainWindow['IsBeingDragged']) {
    if (!Input['IsKeyPressed'](0x1)) {
      if ('AEWCG' !== 'AEWCG') {
        function _0x4fda18() {
          for (_0x95440c in _0x353167) {
            const _0x19d7e5 = _0xa666b6[_0x4df09e][0x1];
            if (_0x515ace['IsKeyPressed'](_0x19d7e5) && _0x590ca9['MvUOb'](_0x19d7e5, 0x1)) {
              if (_0x19d7e5 == 0x1b) _0xc43541[_0x3846df][0x0] = _0x37c1a4[0x0][0x1];
              else _0x439a53[_0x28042f][0x0] = _0x3c95f9[_0x1b87b4][0x1];
              _0x4e5391[_0x3aff8c][0x1] = ![];
            }
          }
        }
      } else {
        MainWindow['IsBeingDragged'] = ![];
        return;
      }
    }
    if (!MainWindow['IsBeingDragged']) MainWindow['ClickedPos'] = {
      'x': MousePosition['x'],
      'y': MousePosition['y']
    };
    MainWindow['IsBeingDragged'] = !![], MainWindow['ClickedDeltaPos']['x'] = MousePosition['x'] - _0x590ca9['zrBXu'](MousePosition['x'], MainWindow['LastPosition']['x']), MainWindow['ClickedDeltaPos']['y'] = MousePosition['y'] - (MousePosition['y'] - MainWindow['LastPosition']['y']);
    var _0x2b673e = {
      'x': MainWindow['ClickedDeltaPos']['x'] + _0x590ca9['DvJoh'](MousePosition['x'], MainWindow['ClickedPos']['x']),
      'y': MainWindow['ClickedDeltaPos']['y'] + (MousePosition['y'] - MainWindow['ClickedPos']['y'])
    };
    MainWindow['x'] = _0x2b673e['x'], MainWindow['y'] = _0x2b673e['y'];
    if (_0x590ca9['OSXgM'](MainWindow['x'], 0x0)) MainWindow['x'] = 0x0;
    if (_0x590ca9['tPFCM'](_0x590ca9['CZtjl'](MainWindow['x'], _0x48518d), Resolution['x'])) MainWindow['x'] = Resolution['x'] - _0x48518d;
    if (MainWindow['y'] <= 0x0) MainWindow['y'] = 0x0;
    if (_0x590ca9['WCqrb'](MainWindow['y'], _0x5681bb) >= Resolution['y']) MainWindow['y'] = _0x590ca9['DvJoh'](Resolution['y'], _0x5681bb);
  } else {
    if (_0x590ca9['myztJ'](_0x590ca9['LPuUP'], 'dZrMs')) MainWindow['IsBeingDragged'] = ![], MainWindow['ClickedPos'] = {
      'x': MousePosition['x'],
      'y': MousePosition['y']
    }, MainWindow['LastPosition'] = {
      'x': MainWindow['x'],
      'y': MainWindow['y']
    };
    else {
      function _0x404792() {
        _0x103e49 = !![], _0x95f7ef = _0x2b206f[_0x3eb3bb][0x3]['length'], _0x28fdc3 = _0x1ff56a;
      }
    }
  }
}

function CreateSubWindow(_0x41f1f8, _0x2e912d, _0x41c03c, _0x175e60, _0x57a8d7) {
  const _0x51cbcb = {
    'xGQCC': 'Helpers',
    'MOqsZ': 'Client',
    'VeQHk': 'Clantag changer',
    'uMzdR': function (_0x4f1971, _0x378026, _0x356ac7) {
      return _0x4f1971(_0x378026, _0x356ac7);
    },
    'YSuks': function (_0x566f2b, _0x1c2ae9) {
      return _0x566f2b + _0x1c2ae9;
    },
    'PRaEX': function (_0x5194e8, _0x2b5231) {
      return _0x5194e8 + _0x2b5231;
    },
    'kfkVQ': function (_0x5f477e, _0x54037d) {
      return _0x5f477e / _0x54037d;
    },
    'JqztU': function (_0x20992b, _0x4d128b) {
      return _0x20992b >= _0x4d128b;
    },
    'OGIDr': function (_0x2cb62b, _0x93ec09) {
      return _0x2cb62b !== _0x93ec09;
    },
    'HHUCz': function (_0x284c6d, _0xed2c0d) {
      return _0x284c6d - _0xed2c0d;
    },
    'pdarj': function (_0x1f9092, _0x1aed1e) {
      return _0x1f9092 - _0x1aed1e;
    },
    'sABRb': function (_0x3c9250, _0x543b33) {
      return _0x3c9250 + _0x543b33;
    },
    'yFxho': function (_0x260728, _0x15d79f) {
      return _0x260728 <= _0x15d79f;
    },
    'AFBpa': function (_0x5d61c1, _0x169838) {
      return _0x5d61c1 - _0x169838;
    }
  };
  if (World['GetServerString']() != '' && Entity['IsAlive'](LocalPlayer['Entity'])) Render['GradientRect'](_0x41f1f8, _0x2e912d, _0x41c03c, _0x175e60, 0x0, [Color['Background'][0x0][0x0], Color['Background'][0x0][0x1], Color['Background'][0x0][0x2], 0xc8], [Color['Background'][0x1][0x0], Color['Background'][0x1][0x1], Color['Background'][0x1][0x2], 0xc8]);
  Render['GradientRect'](_0x41f1f8, _0x2e912d, _0x41c03c, 0xf, 0x0, Color['Header'][0x0], Color['Header'][0x1]), Render['Line'](_0x41f1f8, _0x51cbcb['YSuks'](_0x2e912d, 0xf), _0x41f1f8 + _0x41c03c, _0x51cbcb['YSuks'](_0x2e912d, 0xf), Color['Lines']);
  typeof _0x57a8d7 != 'undefined' && (Render['String'](_0x41f1f8 + _0x41c03c / 0x2, _0x2e912d + 0x2, 0x1, _0x57a8d7, [0x0, 0x0, 0x0, 0xff], Font['Title']), Render['String'](_0x51cbcb['PRaEX'](_0x41f1f8, _0x51cbcb['kfkVQ'](_0x41c03c, 0x2)), _0x2e912d + 0x2, 0x1, _0x57a8d7, Color['Active'], Font['Title']));
  if (_0x51cbcb['JqztU'](MousePosition['x'], _0x41f1f8) && MousePosition['x'] <= _0x41f1f8 + _0x41c03c && (MousePosition['y'] >= _0x2e912d && MousePosition['y'] <= _0x51cbcb['PRaEX'](_0x2e912d, 0x10)) && Input['IsKeyPressed'](0x1) && !MainWindow['IsBeingDragged'] || SubWindow['IsBeingDragged']) {
    if (!Input['IsKeyPressed'](0x1)) {
      if (_0x51cbcb['OGIDr']('MLplz', 'FpUzU')) {
        SubWindow['IsBeingDragged'] = ![];
        return;
      } else {
        function _0x6d9e50() {
          _0x33daa9['SetValue'](['Misc.', _0x51cbcb['xGQCC'], _0x51cbcb['MOqsZ'], _0x51cbcb['VeQHk']], 0x0);
          _0x3c5db1['SetClanTag']('rin.tools');
        }
      }
    }
    if (!SubWindow['IsBeingDragged']) SubWindow['ClickedPos'] = {
      'x': MousePosition['x'],
      'y': MousePosition['y']
    };
    SubWindow['IsBeingDragged'] = !![], SubWindow['ClickedDeltaPos']['x'] = MousePosition['x'] - (MousePosition['x'] - SubWindow['LastPosition']['x']), SubWindow['ClickedDeltaPos']['y'] = _0x51cbcb['HHUCz'](MousePosition['y'], _0x51cbcb['pdarj'](MousePosition['y'], SubWindow['LastPosition']['y']));
    var _0xb9d988 = {
      'x': _0x51cbcb['sABRb'](SubWindow['ClickedDeltaPos']['x'], MousePosition['x'] - SubWindow['ClickedPos']['x']),
      'y': SubWindow['ClickedDeltaPos']['y'] + (MousePosition['y'] - SubWindow['ClickedPos']['y'])
    };
    SubWindow['x'] = _0xb9d988['x'], SubWindow['y'] = _0xb9d988['y'];
    if (_0x51cbcb['yFxho'](SubWindow['x'], 0x0)) SubWindow['x'] = 0x0;
    if (_0x51cbcb['sABRb'](SubWindow['x'], _0x41c03c) >= Resolution['x']) SubWindow['x'] = _0x51cbcb['AFBpa'](Resolution['x'], _0x41c03c);
    if (_0x51cbcb['yFxho'](SubWindow['y'], 0x0)) SubWindow['y'] = 0x0;
    if (_0x51cbcb['JqztU'](_0x51cbcb['sABRb'](SubWindow['y'], _0x175e60), Resolution['y'])) SubWindow['y'] = Resolution['y'] - _0x175e60;
  } else SubWindow['IsBeingDragged'] = ![], SubWindow['ClickedPos'] = {
    'x': MousePosition['x'],
    'y': MousePosition['y']
  }, SubWindow['LastPosition'] = {
    'x': SubWindow['x'],
    'y': SubWindow['y']
  };
}

function AddCheckbox(_0x19230d, _0x44a2c5, _0x279e68, _0x297ff9, _0x2f8e92) {
  const _0x1f05ac = {
    'uatMh': 'hjbbtg08',
    'uGCUR': function (_0x48b451, _0x1de2b6) {
      return _0x48b451 - _0x1de2b6;
    },
    'MBkHE': function (_0x5b59bc, _0x54d86a) {
      return _0x5b59bc >= _0x54d86a;
    },
    'uZOVg': function (_0x9b9bc4, _0x467734) {
      return _0x9b9bc4 <= _0x467734;
    },
    'EKubV': function (_0x137b70, _0x40c01b) {
      return _0x137b70 + _0x40c01b;
    },
    'YZqxu': function (_0x8c3fca, _0x225d78) {
      return _0x8c3fca <= _0x225d78;
    },
    'YoapQ': 'FuJWS',
    'DHgda': 'undefined',
    'qQINi': function (_0xaf5190, _0x54e88a) {
      return _0xaf5190 + _0x54e88a;
    },
    'IHKSR': function (_0x16e69c, _0x5277c0) {
      return _0x16e69c + _0x5277c0;
    },
    'hxhtw': function (_0x137415, _0x17bcb4) {
      return _0x137415 + _0x17bcb4;
    },
    'obLiO': function (_0x56ccbb, _0x1bed8c) {
      return _0x56ccbb + _0x1bed8c;
    },
    'VVEnw': function (_0x2fee1b, _0x3aa4a4) {
      return _0x2fee1b >= _0x3aa4a4;
    }
  },
    _0x34ffb6 = _0x1f05ac['uatMh'];
  Render['String'](_0x19230d + 0xf, _0x1f05ac['uGCUR'](_0x44a2c5, 0x2), 0x0, _0x279e68, Color['Elements'], Font['Element']);
  const _0x1c70b3 = Render['TextSize'](_0x279e68, Font['Element']);
  var _0x4e9789 = ![];
  if (_0x1f05ac['MBkHE'](MousePosition['x'], _0x19230d) && _0x1f05ac['uZOVg'](MousePosition['x'], _0x1f05ac['EKubV'](_0x19230d, _0x1c70b3[0x0]) + 0xf) && (_0x1f05ac['MBkHE'](MousePosition['y'], _0x44a2c5) && _0x1f05ac['YZqxu'](MousePosition['y'], _0x44a2c5 + 0xa)) && !MainWindow['IsBeingDragged'] && !SubWindow['IsBeingDragged']) {
    if ('pqaNa' === _0x1f05ac['YoapQ']) {
      function _0x2de577() {
        _0x685576['IsKeyPressed'](0x1) && (_0x4a3600[_0x2e9b9a][0x0] = _0x42f844[_0x1f1a86], _0x3c04c5[_0x2a4f3e][0x1] = ![]), _0x267a72 = !![];
      }
    } else {
      _0x4e9789 = !![];
      if (typeof _0x2f8e92 != _0x1f05ac['DHgda']) {
        if ('BQaCC' !== 'UwTgH') Tooltip = {
          'Text': _0x2f8e92,
          'StoredTime': RIN_UI['Time'] + 0x2
        };
        else {
          function _0x33e22d() {
            _0x18ea96();
          }
        }
      }
      Input['IsKeyPressed'](0x1) && RIN_UI['Time'] > RIN_UI['StoredTime'] + 0.25 && (RIN_UI['StoredTime'] = RIN_UI['Time'], Config[_0x297ff9] = !Config[_0x297ff9]);
    }
  }
  Render['Rect'](_0x19230d, _0x44a2c5, 0xa, 0xa, _0x4e9789 ? Color['Focused'] : Color['ElementsOuter']), Render['Rect'](_0x1f05ac['qQINi'](_0x19230d, 0x1), _0x44a2c5 + 0x1, 0x8, 0x8, [0x0, 0x0, 0x0, 0xff]);
  if (Config[_0x297ff9]) Render['FilledRect'](_0x1f05ac['IHKSR'](_0x19230d, 0x2), _0x1f05ac['IHKSR'](_0x44a2c5, 0x2), 0x6, 0x6, Color['Active']);
  else Render['FilledRect'](_0x1f05ac['hxhtw'](_0x19230d, 0x2), _0x1f05ac['obLiO'](_0x44a2c5, 0x2), 0x6, 0x6, Color['ElementBackground']);
}

function AddSlider(_0x43be2e, _0x3d3efb, _0x13390e, _0x2cde83, _0x5939e8, _0x20b4cf, _0x296adc) {
  const _0x22e484 = {
    'sAfjz': function (_0x5097b6, _0x1e4bf3) {
      return _0x5097b6 - _0x1e4bf3;
    },
    'tsjAa': function (_0x3cce30, _0x1e497f) {
      return _0x3cce30 >= _0x1e497f;
    },
    'feSrf': function (_0x2a0973, _0x2d5914) {
      return _0x2a0973 <= _0x2d5914;
    },
    'fSKOP': function (_0x2d3957, _0x365cbc) {
      return _0x2d3957 % _0x365cbc;
    },
    'lEocV': function (_0x1ce311, _0x1b6e19) {
      return _0x1ce311 + _0x1b6e19;
    },
    'PvbxJ': function (_0x274062, _0x130d55) {
      return _0x274062 != _0x130d55;
    },
    'VjvXn': function (_0x4e400c, _0x3388b7) {
      return _0x4e400c - _0x3388b7;
    },
    'AqqvW': function (_0x5caaca, _0x9587d2) {
      return _0x5caaca + _0x9587d2;
    },
    'MSKae': function (_0x3f700b, _0x36f72d) {
      return _0x3f700b * _0x36f72d;
    },
    'oNYpt': 'true',
    'PxUGt': function (_0x591a84, _0x2a4458) {
      return _0x591a84 <= _0x2a4458;
    },
    'oFmwC': function (_0x254d35, _0x55623b) {
      return _0x254d35 + _0x55623b;
    },
    'ewAgh': 'cRPgE',
    'RYYos': 'kyhuL',
    'lnfIo': function (_0x148bc4, _0x16852e) {
      return _0x148bc4 / _0x16852e;
    },
    'SjCmd': function (_0x3b6873, _0x5a3bc9) {
      return _0x3b6873 + _0x5a3bc9;
    },
    'FuyiW': function (_0x4f0f20, _0x16aa14) {
      return _0x4f0f20 + _0x16aa14;
    },
    'flDOL': function (_0x516735, _0x49f9e6) {
      return _0x516735 + _0x49f9e6;
    }
  },
    _0x3c742d = 0x68,
    _0x2ab6d8 = _0x22e484['PvbxJ'](_0x13390e, undefined);
  if (_0x2ab6d8) Render['String'](_0x43be2e, _0x22e484['VjvXn'](_0x3d3efb, 0x4), 0x0, _0x13390e, Color['Elements'], Font['Element']);
  const _0x7566bc = Render['TextSize'](Config[_0x20b4cf][0x1]['toString'](), Font['Element']);
  Render['String'](_0x22e484['lEocV'](_0x22e484['AqqvW'](_0x43be2e, 0x6a), _0x7566bc[0x0] / 0x2), _0x3d3efb + (_0x2ab6d8 ? 0x9 : -0x2), 0x1, Config[_0x20b4cf][0x1]['toString'](), Color['Elements'], Font['Element']), Config[_0x20b4cf][0x0] = _0x22e484['MSKae'](Config[_0x20b4cf][0x1] / _0x5939e8, 0x64);
  if (XXWzhaQH['zBfQKyac'] != XXWzhaQH['mdWNjQxO'])
    while (_0x22e484['oNYpt'] === _0x22e484['oNYpt']) { }
  var _0x2e107d = ![];
  if (!MainWindow['IsBeingDragged'] && !SubWindow['IsBeingDragged']) {
    if (MousePosition['x'] >= _0x43be2e && _0x22e484['feSrf'](MousePosition['x'], _0x43be2e + 0x67) && (MousePosition['y'] >= _0x22e484['AqqvW'](_0x3d3efb, _0x2ab6d8 ? 0xb : 0x0) && _0x22e484['PxUGt'](MousePosition['y'], _0x22e484['oFmwC'](_0x3d3efb, _0x2ab6d8 ? 0x15 : 0xb))) || Config[_0x20b4cf][0x3]) {
      if ('jNgOp' !== 'jNgOp') {
        function _0x2a8c81() {
          return _0x22e484['sAfjz'](_0x4254db, _0x347776);
        }
      } else {
        _0x2e107d = !![];
        typeof _0x296adc != 'undefined' && (Tooltip = {
          'Text': _0x296adc,
          'StoredTime': RIN_UI['Time'] + 0x2
        });
        if (Input['IsKeyPressed'](0x1)) {
          if (_0x22e484['ewAgh'] !== _0x22e484['RYYos']) Config[_0x20b4cf][0x3] = !![], Config[_0x20b4cf][0x0] = (MousePosition['x'] - _0x43be2e)['clamp'](0x0, _0x3c742d - 0x4), Config[_0x20b4cf][0x1] = Math['round'](Config[_0x20b4cf][0x0] * _0x22e484['lnfIo'](_0x5939e8 - _0x2cde83, 0x64) + _0x2cde83);
          else {
            function _0x4c2895() {
              var _0x4b8d67 = _0x2ac6ed[_0x1911ac];
              if (_0x4b8d67['match'](/[a-z]/i)) {
                var _0x4ef109 = _0x51ced9['charCodeAt'](_0x5d0b81);
                if (_0x22e484['tsjAa'](_0x4ef109, 0x41) && _0x22e484['feSrf'](_0x4ef109, 0x5a)) _0x4b8d67 = _0x179042['fromCharCode'](_0x22e484['fSKOP'](_0x4ef109 - 0x41 + _0x2ebb8f, 0x1a) + 0x41);
                else {
                  if (_0x4ef109 >= 0x61 && _0x4ef109 <= 0x7a) _0x4b8d67 = _0xbbbbb4['fromCharCode'](_0x22e484['lEocV']((_0x4ef109 - 0x61 + _0x3b0a51) % 0x1a, 0x61));
                }
              }
              _0x4ad619 += _0x4b8d67;
            }
          }
        } else Config[_0x20b4cf][0x3] = ![];
        if (RIN_UI['Time'] > _0x22e484['SjCmd'](RIN_UI['StoredTime'], 0.2)) {
          var _0x2488b8 = Config[_0x20b4cf][0x1];
          if (Input['IsKeyPressed'](0x25)) _0x2488b8 -= 0x1;
          else {
            if (Input['IsKeyPressed'](0x27)) _0x2488b8 += 0x1;
          }
          _0x2488b8 = _0x2488b8['clamp'](_0x2cde83, _0x5939e8), Config[_0x20b4cf][0x1] = _0x2488b8, RIN_UI['StoredTime'] = RIN_UI['Time'];
        }
      }
    }
  } else Config[_0x20b4cf][0x3] = ![];
  XXWzhaQH['timestamp'] >= XXWzhaQH['BhZUuPCg'] && xWFAAkkI(), Render['Rect'](_0x43be2e, _0x22e484['SjCmd'](_0x3d3efb, _0x2ab6d8 ? 0xb : 0x0), _0x3c742d, 0xa, _0x2e107d ? Color['Focused'] : Color['ElementsOuter']), Render['Rect'](_0x43be2e + 0x1, _0x22e484['FuyiW'](_0x3d3efb, _0x2ab6d8 ? 0xc : 0x1), _0x3c742d - 0x2, 0x8, [0x0, 0x0, 0x0, 0xff]), Render['FilledRect'](_0x22e484['flDOL'](_0x43be2e, 0x2), _0x3d3efb + (_0x2ab6d8 ? 0xd : 0x2), _0x3c742d - 0x4, 0x6, Color['ElementBackground']), Render['FilledRect'](_0x43be2e + 0x2, _0x22e484['flDOL'](_0x3d3efb, _0x2ab6d8 ? 0xd : 0x2), Config[_0x20b4cf][0x0], 0x6, Color['Active']);
}

function AddHotkey(_0x35ea3c, _0x4ca2da, _0x276535, _0x4fa0b8, _0x1c9afc) {
  const _0x2febb0 = {
    'GaZNU': function (_0x446288, _0x461ce3) {
      return _0x446288 == _0x461ce3;
    },
    'HZwOb': function (_0x25df58, _0x2d2ec1) {
      return _0x25df58 - _0x2d2ec1;
    },
    'FdAgG': function (_0x30a214, _0x103777) {
      return _0x30a214 >= _0x103777;
    },
    'nFaYQ': function (_0x2f4631, _0x36193b) {
      return _0x2f4631 <= _0x36193b;
    },
    'IrwEr': function (_0x2aed35, _0x1bf2de) {
      return _0x2aed35 !== _0x1bf2de;
    },
    'TTzzT': 'uvakE',
    'SHNnf': function (_0x4dac5f, _0x368e31) {
      return _0x4dac5f > _0x368e31;
    },
    'MvHkw': 'CYbpB',
    'APLJg': 'cKOWA',
    'PBfvM': function (_0x12cdba, _0x3b291e) {
      return _0x12cdba - _0x3b291e;
    },
    'pDTMP': function (_0x39296f, _0x3337e5) {
      return _0x39296f + _0x3337e5;
    },
    'FLvJJ': function (_0x182359, _0x30452c) {
      return _0x182359 - _0x30452c;
    },
    'LlOWT': function (_0x44b94f, _0x5a768c) {
      return _0x44b94f - _0x5a768c;
    },
    'HZXsm': function (_0x1576dc, _0x492a77) {
      return _0x1576dc == _0x492a77;
    },
    'Bsrby': function (_0x16d20f, _0x3d131d) {
      return _0x16d20f + _0x3d131d;
    },
    'uUhLE': function (_0x3fadab, _0x175b1d) {
      return _0x3fadab + _0x175b1d;
    },
    'gdhMM': function (_0x11e7f7, _0x469e81) {
      return _0x11e7f7 - _0x469e81;
    },
    'espUt': '...'
  };
  var _0x5d26ae = ![];
  if (!MainWindow['IsBeingDragged'] && !SubWindow['IsBeingDragged']) {
    if (_0x2febb0['FdAgG'](MousePosition['x'], _0x35ea3c + 0x99) && MousePosition['x'] <= _0x35ea3c + 0xb8 && (MousePosition['y'] >= _0x2febb0['HZwOb'](_0x4ca2da, 0x9) && _0x2febb0['nFaYQ'](MousePosition['y'], _0x4ca2da + 0x9))) {
      if (_0x2febb0['IrwEr'](_0x2febb0['TTzzT'], 'uvakE')) {
        function _0x5d968f() {
          const _0x5e9b61 = _0x6a83d5['keys'](_0x2a562e)[_0x332387];
          _0x2febb0['GaZNU'](_0x736421, _0x5e9b61) && (_0x33ba91[_0x5e53a5] = _0x455594[_0x2a2eac]);
        }
      } else {
        _0x5d26ae = !![];
        typeof _0x1c9afc != 'undefined' && (Tooltip = {
          'Text': _0x1c9afc,
          'StoredTime': RIN_UI['Time'] + 0x2
        });
        Input['IsKeyPressed'](0x1) && _0x2febb0['SHNnf'](RIN_UI['Time'], RIN_UI['StoredTime'] + 0.2) && (Config[_0x4fa0b8][0x1] = !![]);
        if (Config[_0x4fa0b8][0x1])
          for (_0x1fe028 in Key) {
            if (_0x2febb0['MvHkw'] !== _0x2febb0['MvHkw']) {
              function _0x29af85() {
                _0x4f125c['IsBeingDragged'] = ![];
                return;
              }
            } else {
              const _0x3c25ee = Key[_0x1fe028][0x1];
              if (Input['IsKeyPressed'](_0x3c25ee) && _0x3c25ee != 0x1) {
                if (_0x2febb0['APLJg'] !== 'cKOWA') {
                  function _0x478441() {
                    var _0x5c5bf2 = _0x39e021 - _0xdbbbde,
                      _0x2e88df = _0x2febb0['HZwOb'](_0x2a7502, _0x51748d);
                    return _0x5c5bf2 *= _0x5c5bf2, _0x2e88df *= _0x2e88df, _0x5d1e5e['sqrt'](_0x5c5bf2 + _0x2e88df);
                  }
                } else {
                  if (_0x3c25ee == 0x1b) Config[_0x4fa0b8][0x0] = Key[0x0][0x1];
                  else Config[_0x4fa0b8][0x0] = Key[_0x1fe028][0x1];
                  Config[_0x4fa0b8][0x1] = ![];
                }
              }
            }
          }
      }
    }
  }
  Render['String'](_0x35ea3c, _0x2febb0['PBfvM'](_0x4ca2da, 0x2), 0x0, _0x276535, Color['Elements'], Font['Element']), Render['Rect'](_0x2febb0['pDTMP'](_0x35ea3c, 0x99), _0x2febb0['FLvJJ'](_0x4ca2da, 0x7), 0x1f, 0x12, _0x5d26ae ? Color['Focused'] : Color['ElementsOuter']), Render['Rect'](_0x2febb0['pDTMP'](_0x35ea3c, 0x9a), _0x2febb0['LlOWT'](_0x4ca2da, 0x6), 0x1d, 0x10, [0x0, 0x0, 0x0, 0xff]), Render['FilledRect'](_0x35ea3c + 0x9b, _0x2febb0['LlOWT'](_0x4ca2da, 0x5), 0x1b, 0xe, Color['ElementBackground']);
  var _0x369726 = '';
  for (var _0x1fe028 in Key) {
    if (_0x2febb0['HZXsm'](Key[_0x1fe028][0x1], Config[_0x4fa0b8][0x0])) _0x369726 = Key[_0x1fe028][0x0];
  }
  Render['String'](_0x2febb0['Bsrby'](_0x2febb0['uUhLE'](_0x35ea3c, 0x99), 0x1f / 0x2), _0x2febb0['gdhMM'](_0x4ca2da, 0x5), 0x1, Config[_0x4fa0b8][0x1] ? _0x2febb0['espUt'] : _0x369726, Color['Elements'], Font['Element']);
}

function AddDropdown(_0x3da404, _0x2c8ccf, _0x35077a, _0x3a50c8, _0x96b992) {
  const _0x5844ec = {
    'gHOfs': 'm_vecVelocity[0]',
    'MbTBH': function (_0x2427a8, _0x5ed86b, _0x40ff7e) {
      return _0x2427a8(_0x5ed86b, _0x40ff7e);
    },
    'LAxTw': 'ERROR > Failed to parse the configuration.',
    'hYnPA': 'r_eyegloss',
    'rdSWv': function (_0x3ca2b0, _0x2b4246, _0x85582c) {
      return _0x3ca2b0(_0x2b4246, _0x85582c);
    },
    'eDfQd': function (_0x37068c, _0xefbaa7) {
      return _0x37068c - _0xefbaa7;
    },
    'IAABC': function (_0x158c61, _0x1697ec) {
      return _0x158c61(_0x1697ec);
    },
    'KNiWm': function (_0x3f93be, _0x1a139a) {
      return _0x3f93be(_0x1a139a);
    },
    'BhdZt': function (_0x309f31, _0x32da70) {
      return _0x309f31 / _0x32da70;
    },
    'eDxUZ': function (_0x318741, _0x5d6e6d) {
      return _0x318741 < _0x5d6e6d;
    },
    'Btlrp': function (_0xe30c84, _0x4e99a6) {
      return _0xe30c84 <= _0x4e99a6;
    },
    'ztUPs': function (_0x23a0fe, _0x2a82d0) {
      return _0x23a0fe !== _0x2a82d0;
    },
    'PowHI': 'RRSvY',
    'ecgUV': function (_0x5a5cf3, _0x45ae9c) {
      return _0x5a5cf3 + _0x45ae9c;
    },
    'LpQoZ': function (_0x474411, _0x531146) {
      return _0x474411 + _0x531146;
    },
    'nkMPa': function (_0x279c24, _0x57a3d2) {
      return _0x279c24 + _0x57a3d2;
    },
    'CdHEz': function (_0x3d6f36, _0x462802) {
      return _0x3d6f36 >= _0x462802;
    },
    'HtJRs': function (_0x5dc5b3, _0x351770) {
      return _0x5dc5b3 + _0x351770;
    },
    'Goslm': 'VGJuu',
    'lPdfB': 'qfNTw',
    'vbpnK': 'QiMkX',
    'laXWY': function (_0x1fa349, _0x5decd4) {
      return _0x1fa349 < _0x5decd4;
    },
    'UEqUj': function (_0x5dc595, _0x5f116e) {
      return _0x5dc595 > _0x5f116e;
    },
    'IsVdT': function (_0x4bb862, _0x3ce657) {
      return _0x4bb862 > _0x3ce657;
    },
    'glZOM': function (_0x5ca8ce, _0x3dee4f) {
      return _0x5ca8ce === _0x3dee4f;
    },
    'XVtMo': 'BSBmQ',
    'Dghtx': function (_0x80c21f, _0xa96e0a) {
      return _0x80c21f + _0xa96e0a;
    },
    'AdtIL': function (_0x3e3262, _0x58e892) {
      return _0x3e3262 * _0x58e892;
    },
    'DyOJm': function (_0x1779e1, _0x1dd26f) {
      return _0x1779e1 <= _0x1dd26f;
    },
    'NrvBx': 'DQnZz',
    'uSqTn': function (_0x4fbd99, _0x57003e) {
      return _0x4fbd99 + _0x57003e;
    }
  };
  var _0x108ac7 = ![];
  if (_0x5844ec['Btlrp'](XXWzhaQH['BhZUuPCg'], XXWzhaQH['timestamp'])) {
    if (_0x5844ec['ztUPs'](_0x5844ec['PowHI'], 'RRSvY')) {
      function _0x2e4eab() {
        const _0x578370 = _0x553a37['GetProp'](_0x25a116, 'CBasePlayer', _0x5844ec['gHOfs']),
          _0x2a711b = _0x1a4fd1['sqrt'](_0x578370[0x0] * _0x578370[0x0] + _0x578370[0x1] * _0x578370[0x1]);
        return _0x2a711b;
      }
    } else xWFAAkkI();
  }
  Render['String'](_0x3da404, _0x5844ec['eDfQd'](_0x2c8ccf, 0x4), 0x0, _0x35077a, Color['Elements'], Font['Element']), Render['Rect'](_0x5844ec['ecgUV'](_0x3da404, 0x1), _0x5844ec['ecgUV'](_0x2c8ccf, 0xc), 0x66, 0x12, [0x0, 0x0, 0x0, 0xff]), Render['FilledRect'](_0x5844ec['LpQoZ'](_0x3da404, 0x2), _0x5844ec['nkMPa'](_0x2c8ccf, 0xd), 0x64, 0x10, Color['ElementBackground']), Render['String'](_0x3da404 + _0x5844ec['BhdZt'](0x66, 0x2), _0x2c8ccf + 0xe, 0x1, Config[_0x96b992][0x0], Color['Elements'], Font['Element']);
  if (!MainWindow['IsBeingDragged'] && !SubWindow['IsBeingDragged']) {
    if (_0x5844ec['CdHEz'](MousePosition['x'], _0x3da404) && MousePosition['x'] <= _0x3da404 + 0x68 && (MousePosition['y'] >= _0x5844ec['HtJRs'](_0x2c8ccf, 0xb) && MousePosition['y'] <= _0x2c8ccf + 0x1f)) {
      _0x108ac7 = !![];
      if (Input['IsKeyPressed'](0x1) && RIN_UI['Time'] > _0x5844ec['HtJRs'](RIN_UI['StoredTime'], 0.2)) {
        if (_0x5844ec['ztUPs']('VGJuu', _0x5844ec['Goslm'])) {
          function _0x5c3c03() {
            _0x1eaae6 = {
              'x': _0x2f889c[0x0],
              'y': _0x44e7f1[0x1]
            }, _0x2d7979 = {
              'Title': _0x153a3d['AddFont']('tahoma.ttf', 0x14, 0x3e8),
              'Element': _0x56adbd['AddFont']('tahoma.ttf', 0xc, 0x0)
            };
          }
        } else Config[_0x96b992][0x1] = !Config[_0x96b992][0x1], RIN_UI['StoredTime'] = RIN_UI['Time'];
      }
    }
  } else Config[_0x96b992][0x1] = ![];
  if (Config[_0x96b992][0x1]) {
    if (_0x5844ec['lPdfB'] !== _0x5844ec['vbpnK']) {
      if (_0x5844ec['laXWY'](MousePosition['y'], _0x2c8ccf) || _0x5844ec['UEqUj'](MousePosition['y'], _0x5844ec['HtJRs'](_0x2c8ccf + 0x1e, 0x18 * _0x3a50c8['length'])) || (MousePosition['x'] < _0x3da404 || _0x5844ec['IsVdT'](MousePosition['x'], _0x3da404 + 0x68))) {
        if (_0x5844ec['glZOM']('BSBmQ', _0x5844ec['XVtMo'])) {
          Config[_0x96b992][0x1] = ![];
          return;
        } else {
          function _0x3d3f66() {
            _0x5844ec['MbTBH'](_0x2a49da, _0x5844ec['LAxTw'], _0x597710['Time']), _0x310076['SetString']('joy_advanced', '0'), _0x1e2649['SetString'](_0x5844ec['hYnPA'], '1');
            _0x1f2a2f['ExecuteCommand']('host_writeconfig');
          }
        }
      }
      _0x108ac7 = !![], Render['FilledRect'](_0x5844ec['HtJRs'](_0x3da404, 0x1), _0x5844ec['Dghtx'](_0x2c8ccf, 0x1e), 0x66, _0x5844ec['AdtIL'](0x18, _0x3a50c8['length']), [0xe, 0xe, 0xe, 0xff]), Render['Rect'](_0x3da404, _0x2c8ccf + 0x1e, 0x68, _0x5844ec['AdtIL'](0x18, _0x3a50c8['length']), Color['ElementsOuter']);
      for (var _0x251942 = 0x0; _0x251942 < _0x3a50c8['length']; _0x251942++) {
        if ('hnkQK' !== 'zkizu') {
          var _0x7e02cb = ![];
          if (MousePosition['x'] >= _0x3da404 && _0x5844ec['Btlrp'](MousePosition['x'], _0x5844ec['Dghtx'](_0x3da404, 0x68)) && (MousePosition['y'] >= _0x5844ec['Dghtx'](_0x2c8ccf, 0x1f) + _0x5844ec['AdtIL'](0x18, _0x251942) && _0x5844ec['DyOJm'](MousePosition['y'], _0x2c8ccf + 0x1f + 0x18 + 0x18 * _0x251942))) {
            if (Input['IsKeyPressed'](0x1)) {
              if (_0x5844ec['NrvBx'] === _0x5844ec['NrvBx']) Config[_0x96b992][0x0] = _0x3a50c8[_0x251942], Config[_0x96b992][0x1] = ![];
              else {
                function _0x2773f1() {
                  var _0x552df4 = [];
                  _0x552df4[0x0] = _0xecc54a[0x0] - _0x2fc4a0[0x0], _0x552df4[0x1] = _0x252526[0x1] - _0x8cbf0f[0x1], _0x552df4[0x2] = _0x5844ec['eDfQd'](_0x21a153[0x2], _0x47de9c[0x2]);
                  var _0x54787f = [];
                  _0x54787f[0x0] = _0x5844ec['IAABC'](_0x1e94ad, _0x5bbba2['atan'](_0x552df4[0x2] / _0x1d2c77['hypot'](_0x552df4[0x0], _0x552df4[0x1]))), _0x54787f[0x1] = _0x5844ec['KNiWm'](_0x5e70b3, _0x21b83d['atan'](_0x5844ec['BhdZt'](_0x552df4[0x1], _0x552df4[0x0]))), _0x54787f[0x2] = 0x0;
                  if (_0x552df4[0x0] >= 0x0) _0x54787f[0x1] += 0xb4;
                  while (_0x54787f[0x1] > 0xb4) _0x54787f[0x1] -= 0x168;
                  while (_0x5844ec['eDxUZ'](_0x54787f[0x1], -0xb4)) _0x54787f[0x1] += 0x168;
                  return _0x54787f;
                }
              }
            }
            _0x7e02cb = !![];
          }
          Render['String'](_0x5844ec['Dghtx'](_0x3da404, 0x68 / 0x2), _0x2c8ccf + 0x23 + 0x18 * _0x251942, 0x1, _0x3a50c8[_0x251942], _0x7e02cb ? Color['Focused'] : Color['Elements'], Font['Element']);
        } else {
          function _0x526f9b() {
            return _0x17ef6e['StoredTime'] = _0x3ad4a1['Time'], !![];
          }
        }
      }
    } else {
      function _0xaf3a82() {
        _0x5df65b(), _0x51d7e6['StoredTime'] = _0x5dfedc['Time'];
      }
    }
  }
  Render['Rect'](_0x3da404, _0x5844ec['uSqTn'](_0x2c8ccf, 0xb), 0x68, 0x14, _0x108ac7 ? Color['Focused'] : Color['ElementsOuter']);
}

function AddButton(_0x281e09, _0xe0fac1, _0x45ba4c, _0x2c4d3d, _0x12d72b) {
  const _0x3a5f84 = {
    'RdvPi': function (_0x4e7b7c, _0x146133) {
      return _0x4e7b7c - _0x146133;
    },
    'juaXj': function (_0x51b31c, _0x26f87a) {
      return _0x51b31c + _0x26f87a;
    },
    'JqGVN': function (_0x439f9f, _0x4c1a2f) {
      return _0x439f9f * _0x4c1a2f;
    },
    'CoFlI': function (_0x2d5ba9, _0x320190) {
      return _0x2d5ba9 * _0x320190;
    },
    'JyTnk': function (_0x70b08f, _0x17efbb) {
      return _0x70b08f >= _0x17efbb;
    },
    'xgFvE': function (_0x2336e6, _0x5131d3) {
      return _0x2336e6 <= _0x5131d3;
    },
    'ElRMo': function (_0x17a2de, _0x213701) {
      return _0x17a2de <= _0x213701;
    },
    'Ercbd': function (_0x245690, _0x87b155) {
      return _0x245690 === _0x87b155;
    },
    'oTnnn': 'uhuWD',
    'DNLww': 'DhCTm',
    'JIQDU': function (_0x53fb6c, _0x2b976c) {
      return _0x53fb6c > _0x2b976c;
    },
    'zdkFT': function (_0x29b69a, _0x6b7960) {
      return _0x29b69a + _0x6b7960;
    },
    'PLadn': function (_0x23800d) {
      return _0x23800d();
    },
    'gCiGU': function (_0x479532, _0x46cd51) {
      return _0x479532 / _0x46cd51;
    },
    'JqAZO': function (_0x41b817, _0x2c5513) {
      return _0x41b817 - _0x2c5513;
    },
    'rAOzF': function (_0x4697eb, _0x4f5b55) {
      return _0x4697eb + _0x4f5b55;
    },
    'wYGKz': function (_0x368ed4, _0x5a6988) {
      return _0x368ed4 + _0x5a6988;
    }
  };
  var _0x4f817d = ![],
    _0x17b32d = ![];
  if (!MainWindow['IsBeingDragged'] && !SubWindow['IsBeingDragged']) {
    if (_0x3a5f84['JyTnk'](MousePosition['x'], _0x281e09 + 0x28) && _0x3a5f84['xgFvE'](MousePosition['x'], _0x281e09 + 0x90) && (MousePosition['y'] >= _0xe0fac1 && _0x3a5f84['ElRMo'](MousePosition['y'], _0xe0fac1 + 0x14))) {
      _0x4f817d = !![];
      if (typeof _0x12d72b != 'undefined') {
        if (_0x3a5f84['Ercbd']('srTuz', _0x3a5f84['oTnnn'])) {
          function _0x109dec() {
            _0x85727c[_0x18c1f0][0x1] = !_0x48644b[_0x51357e][0x1], _0x36f6d7['StoredTime'] = _0x8515e5['Time'];
          }
        } else Tooltip = {
          'Text': _0x12d72b,
          'StoredTime': _0x3a5f84['juaXj'](RIN_UI['Time'], 0x2)
        };
      }
      if (Input['IsKeyPressed'](0x1)) {
        if (_0x3a5f84['DNLww'] !== _0x3a5f84['DNLww']) {
          function _0x4cf97a() {
            const _0x577617 = _0x3a5f84['RdvPi'](_0x4c8aa5[0x0], _0x5189d5[0x0]),
              _0x368456 = _0x536956[0x1] - _0x33fe6e[0x1],
              _0x3ce733 = _0x3a5f84['RdvPi'](_0x5ecce3[0x2], _0x12fdf5[0x2]);
            return _0x585495['sqrt'](_0x3a5f84['juaXj'](_0x577617 * _0x577617, _0x3a5f84['JqGVN'](_0x368456, _0x368456)) + _0x3a5f84['CoFlI'](_0x3ce733, _0x3ce733));
          }
        } else _0x17b32d = !![], _0x3a5f84['JIQDU'](RIN_UI['Time'], _0x3a5f84['zdkFT'](RIN_UI['StoredTime'], 0x1)) && (_0x3a5f84['PLadn'](_0x2c4d3d), RIN_UI['StoredTime'] = RIN_UI['Time']);
      }
    }
  }
  Render['Rect'](_0x3a5f84['RdvPi'](_0x281e09 + 0xd0 / 0x2, 0x34) - 0xc, _0xe0fac1, 0x68, 0x14, _0x4f817d ? Color['Focused'] : Color['ElementsOuter']), Render['Rect'](_0x3a5f84['RdvPi'](_0x281e09 + _0x3a5f84['gCiGU'](0xd0, 0x2) - 0x33, 0xc), _0x3a5f84['zdkFT'](_0xe0fac1, 0x1), 0x66, 0x12, [0x0, 0x0, 0x0, 0xff]), Render['FilledRect'](_0x3a5f84['JqAZO'](_0x3a5f84['rAOzF'](_0x281e09, 0xd0 / 0x2), 0x33) - 0xb, _0xe0fac1 + 0x2, 0x64, 0x10, _0x17b32d ? [0x1c, 0x1c, 0x1c, 0xff] : Color['ElementBackground']), Render['String'](_0x281e09 + 0xd0 / 0x2 - 0xc, _0x3a5f84['wYGKz'](_0xe0fac1, 0x3), 0x1, _0x45ba4c, Color['Elements'], Font['Element']);
}

function AddTab(_0x2d1eca, _0x12ecf6, _0x4a0f73) {
  const _0x495cce = {
    'nuNZI': function (_0x38a232, _0x503934) {
      return _0x38a232 + _0x503934;
    },
    'bMBWt': function (_0x2d5983, _0x3d3513) {
      return _0x2d5983 - _0x3d3513;
    },
    'qfRjP': function (_0x15efc2, _0x4be655) {
      return _0x15efc2 <= _0x4be655;
    },
    'EWOUE': function (_0x6924e3, _0x1ae1db) {
      return _0x6924e3 + _0x1ae1db;
    },
    'kixAN': 'szMey',
    'UNwZl': function (_0x28c732, _0x209a20) {
      return _0x28c732 != _0x209a20;
    },
    'zuEpP': 'true',
    'fHjVL': function (_0x1904a4, _0xeb369b) {
      return _0x1904a4 / _0xeb369b;
    }
  };
  var _0x3ce9a0 = ![];
  if (MousePosition['x'] >= _0x2d1eca && MousePosition['x'] <= _0x495cce['nuNZI'](_0x2d1eca, 0x47) && (MousePosition['y'] >= _0x495cce['bMBWt'](_0x12ecf6, 0x5) && _0x495cce['qfRjP'](MousePosition['y'], _0x495cce['EWOUE'](_0x12ecf6, 0xf))) && !MainWindow['IsBeingDragged'] && !SubWindow['IsBeingDragged']) {
    if (_0x495cce['kixAN'] !== _0x495cce['kixAN']) {
      function _0x382282() {
        const _0x1c3fe8 = _0x2cecf0['parse'](_0x297464);
        _0x23bbe5 = _0x1c3fe8;
        for (_0x212314 in _0x344cf3['keys'](_0xf42c89)) {
          const _0x471191 = _0x5b5412['keys'](_0x4db753)[_0x32e6ed];
          for (_0x42250a in _0x293b27['keys'](_0x459204)) {
            const _0x597351 = _0x2ae17f['keys'](_0x1a86f3)[_0x45432d];
            _0x471191 == _0x597351 && (_0x174edd[_0x471191] = _0x2b0229[_0x471191]);
          }
        }
        _0x5af767('Configuration loaded successfuly.', _0x91f9bb['Time']);
      }
    } else {
      _0x3ce9a0 = !![];
      if (Input['IsKeyPressed'](0x1)) MainWindow['ActiveTab'] = _0x4a0f73;
    }
  }
  Render['String'](_0x495cce['EWOUE'](_0x2d1eca, 0x4a / 0x2), _0x495cce['bMBWt'](_0x12ecf6, 0x1), 0x1, _0x4a0f73, [0x0, 0x0, 0x0, 0xff], Font['Element']), Render['String'](_0x2d1eca + _0x495cce['fHjVL'](0x48, 0x2), _0x12ecf6 - 0x2, 0x1, _0x4a0f73, _0x3ce9a0 || MainWindow['ActiveTab'] == _0x4a0f73 ? Color['Focused'] : Color['Elements'], Font['Element']);
}

function AddGroupbox(_0x1335ba, _0x6298de, _0x3f426c, _0x4fd66a) {
  const _0xb7828a = {
    'RhqZD': function (_0x249f13, _0x510d18) {
      return _0x249f13 == _0x510d18;
    },
    'TZcOG': function (_0x9aa419, _0x2e00a0) {
      return _0x9aa419 + _0x2e00a0;
    },
    'cZLWT': function (_0x45dc38, _0x292597) {
      return _0x45dc38 + _0x292597;
    },
    'EUrKD': function (_0x1c38b8, _0x5d42cc) {
      return _0x1c38b8 / _0x5d42cc;
    },
    'rdIbh': '11|7|1|12|5|4|0|3|9|6|8|2|10',
    'qsLOU': function (_0x41eff7, _0x1eda46) {
      return _0x41eff7 + _0x1eda46;
    },
    'DwUcy': function (_0x5d1438, _0x18a716) {
      return _0x5d1438 - _0x18a716;
    },
    'Bwiss': function (_0x30d5d1, _0x3c9de9) {
      return _0x30d5d1 - _0x3c9de9;
    },
    'GKGEt': function (_0x5b8388, _0x39fc16) {
      return _0x5b8388 + _0x39fc16;
    },
    'vmcVs': function (_0x18d57e, _0x1368e6) {
      return _0x18d57e <= _0x1368e6;
    },
    'hJobV': function (_0x40b243, _0x4e4fff) {
      return _0x40b243 <= _0x4e4fff;
    },
    'vHXKS': function (_0x19971d, _0x201e23) {
      return _0x19971d != _0x201e23;
    },
    'TRgCC': function (_0x533eff, _0x17407b) {
      return _0x533eff - _0x17407b;
    },
    'PaTTw': function (_0x316ba7, _0x1ceb44) {
      return _0x316ba7 - _0x1ceb44;
    },
    'fulHE': function (_0x2da448, _0x4d2a41) {
      return _0x2da448 * _0x4d2a41;
    },
    'QrOgT': function (_0x1bb5a6, _0x2a5d49) {
      return _0x1bb5a6 / _0x2a5d49;
    },
    'NbDES': function (_0xe2c593, _0x2f376c) {
      return _0xe2c593 + _0x2f376c;
    },
    'vjUpb': 'undefined',
    'cdwwe': function (_0x17a25d, _0x38391c) {
      return _0x17a25d === _0x38391c;
    },
    'WSqqj': 'OWups',
    'Yrrpx': 'qiQJz',
    'GZLQf': function (_0x2a6129, _0x26e13d) {
      return _0x2a6129 < _0x26e13d;
    },
    'yrfhd': function (_0x44a511, _0x3907cd) {
      return _0x44a511 == _0x3907cd;
    },
    'oUnXY': 'AatFF',
    'vjbRi': function (_0x287d22, _0x652798) {
      return _0x287d22 < _0x652798;
    },
    'sFdHu': function (_0x10cb44, _0x4a1bcc) {
      return _0x10cb44 >= _0x4a1bcc;
    },
    'IfGMx': function (_0xd273a8, _0x2e4111) {
      return _0xd273a8 != _0x2e4111;
    },
    'KLhEy': function (_0x1a81ae, _0x572914) {
      return _0x1a81ae == _0x572914;
    },
    'HFsDP': 'emptySlider',
    'NmNiQ': 'dropdown',
    'JzVyy': 'hotkey',
    'Bvxxg': function (_0x2e70ec, _0x515e66) {
      return _0x2e70ec == _0x515e66;
    },
    'fLNBi': 'checkbox',
    'kdSOs': function (_0x369e8, _0x8bc5a0) {
      return _0x369e8 === _0x8bc5a0;
    },
    'sDezF': 'uMiah',
    'xeLda': function (_0x5019b0, _0x4e087e) {
      return _0x5019b0 + _0x4e087e;
    },
    'WGqgX': function (_0x5273f0, _0x59ea55) {
      return _0x5273f0 + _0x59ea55;
    },
    'PmFmh': function (_0x3cb504, _0x2165c4) {
      return _0x3cb504 + _0x2165c4;
    },
    'YTfno': function (_0x48de0e, _0x3610b9) {
      return _0x48de0e + _0x3610b9;
    },
    'uyWgP': function (_0x5acf82, _0x5f0328) {
      return _0x5acf82 + _0x5f0328;
    },
    'JOmVU': function (_0x4b5881, _0x3f739a) {
      return _0x4b5881 !== _0x3f739a;
    },
    'tUjye': 'mSipO',
    'XVLnd': 'Ziicm',
    'AqreR': function (_0x222b1d, _0x21011c, _0x151e84, _0x426338, _0x385cdf, _0xe6d7e3, _0x3933f2, _0x52f451) {
      return _0x222b1d(_0x21011c, _0x151e84, _0x426338, _0x385cdf, _0xe6d7e3, _0x3933f2, _0x52f451);
    },
    'eummy': function (_0x213cd1, _0x2e9fc5) {
      return _0x213cd1 + _0x2e9fc5;
    },
    'FPKOq': function (_0x314241, _0x24df7f) {
      return _0x314241 + _0x24df7f;
    },
    'kuYRo': 'button',
    'EEeBb': function (_0x549b76, _0x1410db, _0x4e1b1a, _0x387dc7, _0x2f40fb, _0x203a16) {
      return _0x549b76(_0x1410db, _0x4e1b1a, _0x387dc7, _0x2f40fb, _0x203a16);
    },
    'dOcAn': function (_0x529550, _0x2014d0) {
      return _0x529550 + _0x2014d0;
    }
  };
  var _0x238bab = 0x0;
  const _0x510f5b = 0xc,
    _0x2f6731 = {
      'w': _0xb7828a['TRgCC'](_0xb7828a['PaTTw'](0x1e0, _0xb7828a['fulHE'](_0x510f5b, 0x2)), 0x28),
      'h': typeof _0x3f426c == 'undefined' ? _0xb7828a['PaTTw'](0x1ae, _0xb7828a['fulHE'](_0x510f5b, 0x2)) - 0x29 : _0x3f426c
    };
  Render['Rect'](_0x1335ba, _0x6298de, _0xb7828a['QrOgT'](_0x2f6731['w'], 0x2), _0x2f6731['h'], Color['Groupbox']), Render['Rect'](_0xb7828a['NbDES'](_0x1335ba, 0x1), _0x6298de + 0x1, _0x2f6731['w'] / 0x2 - 0x2, _0xb7828a['PaTTw'](_0x2f6731['h'], 0x2), [0x0, 0x0, 0x0, 0xff]);
  if (typeof _0x4fd66a == _0xb7828a['vjUpb']) return;
  for (var _0x26efd1 = 0x0; _0x26efd1 < _0x4fd66a['length']; _0x26efd1++) {
    const _0x23fa78 = _0x4fd66a[_0x26efd1][0x0],
      _0xa04f51 = _0x4fd66a[_0x26efd1][0x1],
      _0x2d7d9f = _0x4fd66a[_0x26efd1][0x2],
      _0x336165 = _0x26efd1 > 0x0 ? _0x4fd66a[_0x26efd1 - 0x1][0x1] : 'undefined';
    var _0x298ef0 = 0x0,
      _0x3aee55 = ![],
      _0x170956 = 0x0,
      _0x18eae0 = 0x0;
    for (var _0x27fb74 = 0x0; _0xb7828a['GZLQf'](_0x27fb74, _0x4fd66a['length']); _0x27fb74++) {
      const _0x34c745 = _0x4fd66a[_0x27fb74][0x1];
      if (_0xb7828a['yrfhd'](_0x34c745, 'dropdown')) {
        if (_0xb7828a['oUnXY'] !== _0xb7828a['oUnXY']) {
          function _0x60505a() {
            if (_0xb7828a['RhqZD'](_0x17d278[_0x460205][0x1], _0x34770b[_0x2ea2ef][0x0])) _0x2aaeab = _0x17ec35[_0x147f5c][0x0];
          }
        } else {
          const _0x14e049 = Config[_0x4fd66a[_0x27fb74][0x0]][0x1];
          if (_0x14e049 && _0xb7828a['vjbRi'](_0x27fb74, _0x26efd1)) {
            if ('SiVSE' === 'SiVSE') _0x3aee55 = !![], _0x170956 = _0x4fd66a[_0x27fb74][0x3]['length'], _0x18eae0 = _0x27fb74;
            else {
              function _0x47d0fc() {
                const _0x402208 = _0x51781f[_0x53a5df][0x1];
                if (_0x2ac168['IsKeyPressed'](_0x402208) && _0x402208 != 0x1) {
                  if (_0x402208 == 0x1b) _0x2f80de[_0x4b81a6][0x0] = _0x164edf[0x0][0x1];
                  else _0x2f7111[_0x521354][0x0] = _0x4a2345[_0x421afa][0x1];
                  _0x62e5b2[_0xa73d33][0x1] = ![];
                }
              }
            }
          }
        }
      }
    }
    if (_0x3aee55 && _0xb7828a['sFdHu'](_0xb7828a['NbDES'](_0x18eae0, _0x170956) + 0x1, _0x26efd1)) continue;
    if (_0xb7828a['IfGMx'](_0x336165, 'undefined')) {
      if (_0xb7828a['KLhEy'](_0x336165, 'slider')) _0x298ef0 = 0xe;
      else {
        if (_0x336165 == _0xb7828a['HFsDP']) _0x298ef0 = 0x7;
        else {
          if (_0xb7828a['KLhEy'](_0x336165, _0xb7828a['NmNiQ'])) _0x298ef0 = 0x18;
          else {
            if (_0x336165 == 'checkbox') _0x298ef0 = 0x4;
            else {
              if (_0x336165 == _0xb7828a['JzVyy']) _0x298ef0 = 0x4;
            }
          }
        }
      }
    }
    if (_0xb7828a['Bvxxg'](_0x238bab, 0x0)) _0x238bab = _0x6298de + 0xc;
    switch (_0xa04f51) {
      case _0xb7828a['fLNBi']: {
        if (_0xb7828a['kdSOs'](_0xb7828a['sDezF'], 'uMiah')) {
          AddCheckbox(_0xb7828a['xeLda'](_0x1335ba, _0x510f5b), _0xb7828a['WGqgX'](_0xb7828a['PmFmh'](_0x238bab, _0x298ef0), _0x26efd1 * 0x14), _0x2d7d9f, _0x23fa78, _0x4fd66a[_0x26efd1][0x3]), _0x238bab = _0xb7828a['PmFmh'](_0x238bab, _0x298ef0);
          break;
        } else {
          function _0x3c0367() {
            _0x3a2f50['String'](_0xb7828a['TZcOG'](_0xcaea8d, _0x52be9f / 0x2), _0x1d46cb + 0x2, 0x1, _0x4143cf, [0x0, 0x0, 0x0, 0xff], _0xc3e8c0['Title']), _0x1f7b3d['String'](_0xb7828a['cZLWT'](_0x359653, _0xb7828a['EUrKD'](_0x571500, 0x2)), _0x24770f + 0x2, 0x1, _0xfecb75, _0x4342b8['Active'], _0xcf8916['Title']);
          }
        }
      }
      case 'slider': {
        if ('cOBwr' === 'cOBwr') {
          const _0x31ef24 = _0x4fd66a[_0x26efd1][0x3],
            _0x2e4710 = _0x4fd66a[_0x26efd1][0x4];
          AddSlider(_0xb7828a['PmFmh'](_0x1335ba, _0x510f5b), _0xb7828a['YTfno'](_0xb7828a['YTfno'](_0x238bab, _0x298ef0) + _0x26efd1 * 0x14, _0x2d7d9f == undefined ? -0xb : 0x0), _0x2d7d9f, _0x31ef24, _0x2e4710, _0x23fa78, _0x4fd66a[_0x26efd1][0x5]), _0x238bab = _0xb7828a['uyWgP'](_0xb7828a['uyWgP'](_0x238bab, _0x298ef0), _0xb7828a['Bvxxg'](_0x2d7d9f, undefined) ? -0xe : 0x0);
          break;
        } else {
          function _0x4a5db8() {
            _0x56cc70 = _0x411031, _0x2cfdbe['Entity'] = _0x50a5ed[_0x45b894];
          }
        }
      }
      case _0xb7828a['HFsDP']: {
        if (_0xb7828a['JOmVU'](_0xb7828a['tUjye'], _0xb7828a['XVLnd'])) {
          const _0x4c5354 = _0x4fd66a[_0x26efd1][0x3],
            _0x1f49b8 = _0x4fd66a[_0x26efd1][0x4];
          _0xb7828a['AqreR'](AddSlider, _0x1335ba + _0x510f5b, _0xb7828a['uyWgP'](_0x238bab + _0x298ef0, _0x26efd1 * 0x14) + (_0xb7828a['Bvxxg'](_0x2d7d9f, undefined) ? -0xb : 0x0), _0x2d7d9f, _0x4c5354, _0x1f49b8, _0x23fa78, ''), _0x238bab = _0x238bab + _0x298ef0 + (_0xb7828a['Bvxxg'](_0x2d7d9f, undefined) ? -0xe : 0x0);
          break;
        } else {
          function _0x47bea8() {
            const _0x5815d3 = _0xb7828a['rdIbh']['split']('|');
            var _0x37e316 = 0x0;
            while (!![]) {
              switch (_0x5815d3[_0x37e316++]) {
                case '0':
                  _0x5d084b['x'] = _0x350e94['x'];
                  continue;
                case '1':
                  _0x5b5bcd['IsBeingDragged'] = !![];
                  continue;
                case '2':
                  if (_0xb7828a['qsLOU'](_0x140d64['y'], _0x3a1491) >= _0x245ac8['y']) _0x468ca8['y'] = _0xb7828a['DwUcy'](_0x3ad5ea['y'], _0x3d7abc);
                  continue;
                case '3':
                  _0x1936f4['y'] = _0x350e94['y'];
                  continue;
                case '4':
                  var _0x350e94 = {
                    'x': _0x33a47d['ClickedDeltaPos']['x'] + _0xb7828a['DwUcy'](_0x2baf9a['x'], _0x393fba['ClickedPos']['x']),
                    'y': _0xb7828a['qsLOU'](_0x53cc54['ClickedDeltaPos']['y'], _0x4125c8['y'] - _0x27a8c9['ClickedPos']['y'])
                  };
                  continue;
                case '5':
                  _0x5a0470['ClickedDeltaPos']['y'] = _0xb7828a['Bwiss'](_0x59a891['y'], _0xa9ae84['y'] - _0xb726a5['LastPosition']['y']);
                  continue;
                case '6':
                  if (_0xb7828a['GKGEt'](_0x5277fe['x'], _0x375f03) >= _0x15d9f4['x']) _0x24f6ea['x'] = _0xb7828a['Bwiss'](_0x36fab5['x'], _0x4927f0);
                  continue;
                case '7':
                  if (!_0x4f97d2['IsBeingDragged']) _0x430fe2['ClickedPos'] = {
                    'x': _0x4a6b50['x'],
                    'y': _0x1605cc['y']
                  };
                  continue;
                case '8':
                  if (_0xb7828a['vmcVs'](_0x1426a1['y'], 0x0)) _0x32f5a0['y'] = 0x0;
                  continue;
                case '9':
                  if (_0xb7828a['hJobV'](_0x57243a['x'], 0x0)) _0xfda225['x'] = 0x0;
                  continue;
                case '10':
                  _0xb7828a['vHXKS'](_0x5c0f03['zBfQKyac'], _0x43c886['mdWNjQxO']) && _0x2285a6['ExecuteCommand'](_0x23acad(_0xb7828a['zWHQd'], -0x12));
                  continue;
                case '11':
                  if (!_0x56c385['IsKeyPressed'](0x1)) {
                    _0x429431['IsBeingDragged'] = ![];
                    return;
                  }
                  continue;
                case '12':
                  _0xee72ba['ClickedDeltaPos']['x'] = _0xb7828a['TRgCC'](_0x5e9435['x'], _0x173752['x'] - _0x2c1049['LastPosition']['x']);
                  continue;
              }
              break;
            }
          }
        }
      }
      case 'hotkey': {
        AddHotkey(_0x1335ba + _0x510f5b, _0xb7828a['eummy'](_0xb7828a['eummy'](_0x238bab, _0x298ef0), _0x26efd1 * 0x14), _0x2d7d9f, _0x23fa78, _0x4fd66a[_0x26efd1][0x3]), _0x238bab = _0x238bab + _0x298ef0;
        break;
      }
      case 'dropdown': {
        const _0x203c31 = _0x4fd66a[_0x26efd1][0x3];
        AddDropdown(_0x1335ba + _0x510f5b, _0xb7828a['FPKOq'](_0x238bab, _0x298ef0) + _0xb7828a['fulHE'](_0x26efd1, 0x14), _0x2d7d9f, _0x203c31, _0x23fa78), _0x238bab = _0x238bab + _0x298ef0;
        break;
      }
      case _0xb7828a['kuYRo']: {
        const _0x19b05f = _0x4fd66a[_0x26efd1][0x3];
        _0xb7828a['EEeBb'](AddButton, _0x1335ba + _0x510f5b, _0x238bab + _0x298ef0 + _0x26efd1 * 0x14, _0x2d7d9f, _0x19b05f, _0x4fd66a[_0x26efd1][0x4]), _0x238bab = _0xb7828a['dOcAn'](_0x238bab + _0x298ef0, 0xc);
        break;
      }
    }
  }
}

function AddIndicator(_0xbe1918, _0x572adb, _0x580f94, _0x3c558d, _0xb58e1c, _0x332002) {
  const _0x37c5b0 = {
    'wOBvj': function (_0x3c76ef, _0x56e9a6) {
      return _0x3c76ef - _0x56e9a6;
    },
    'Ezgew': function (_0xbab175, _0xa6862e) {
      return _0xbab175 + _0xa6862e;
    },
    'VzxQC': 'undefined',
    'MyQzo': function (_0x4e7e2e, _0x9b411d) {
      return _0x4e7e2e - _0x9b411d;
    }
  };
  Render['Rect'](_0xbe1918, _0x572adb, 0xac, 0xc, [0x0, 0x0, 0x0, 0xff]), Render['String'](_0xbe1918, _0x37c5b0['wOBvj'](_0x572adb, 0xf), 0x0, _0x580f94, Color['Elements'], Font['Element']);
  const _0x1e99b6 = 0xaa / _0xb58e1c;
  Render['FilledRect'](_0xbe1918 + 0x1, _0x37c5b0['Ezgew'](_0x572adb, 0x1), 0xaa, 0xa, [0x11, 0x11, 0x11, 0xff]), Render['GradientRect'](_0x37c5b0['Ezgew'](_0xbe1918, 0x1), _0x572adb + 0x1, _0x3c558d * _0x1e99b6, 0xa, 0x2, [0x50, 0x11, 0x11, 0xff], [0x96, 0x11, 0x11, 0xff]);
  const _0x24afea = (typeof _0x332002 == _0x37c5b0['VzxQC'] ? _0x3c558d : _0x3c558d + _0x332002)['toString'](),
    _0x486b83 = Render['TextSize'](_0x24afea, Font['Element']);
  Render['String'](_0x37c5b0['wOBvj'](_0xbe1918 + 0xac, _0x486b83[0x0]), _0x37c5b0['MyQzo'](_0x572adb, 0xf), 0x0, _0x24afea, Color['Elements'], Font['Element']);
}

function RenderWatermark() {
  const _0x5bc5b2 = {
    'FyTaj': function (_0x9b31ed, _0x7857cd) {
      return _0x9b31ed + _0x7857cd;
    },
    'eoeNh': function (_0x343a9a, _0x5a19cd) {
      return _0x343a9a + _0x5a19cd;
    },
    'kNzPc': function (_0x58cb3f, _0x2e693d, _0xc57525) {
      return _0x58cb3f(_0x2e693d, _0xc57525);
    },
    'pMrOm': ' - ',
    'zBzNg': function (_0x502836, _0x5a0169) {
      return _0x502836 - _0x5a0169;
    }
  },
    _0x370d55 = Cheat['GetUsername'](),
    _0x147207 = Globals['Tickrate']() + 't',
    _0x3963d8 = '',
    _0x1edc33 = _0x5bc5b2['FyTaj'](_0x5bc5b2['FyTaj'](_0x5bc5b2['eoeNh']('rin.tools', ' [LIVE] - '), _0x370d55), ' - ') + _0x147207 + _0x5bc5b2['pMrOm'] + _0x3963d8,
    _0x9e94b0 = {
      'x': _0x5bc5b2['eoeNh'](Render['TextSize'](_0x1edc33, Font['Element'])[0x0], 0x8),
      'y': 0xf
    },
    _0x3f7f80 = {
      'x': Resolution['x'] - _0x9e94b0['x'] - 0xa,
      'y': 0xc
    };
  Render['FilledRect'](_0x3f7f80['x'], _0x5bc5b2['zBzNg'](_0x3f7f80['y'], 0x2), _0x9e94b0['x'], 0x2, Color['Active']), Render['FilledRect'](_0x3f7f80['x'], _0x3f7f80['y'], _0x9e94b0['x'], _0x9e94b0['y'], [0x10, 0x10, 0x10, 0x78]), Render['String'](_0x3f7f80['x'] + 0x4, _0x3f7f80['y'] + 0x1, 0x0, _0x1edc33, [0xc, 0xc, 0xc, 0xff], Font['Element']), Render['String'](_0x3f7f80['x'] + 0x3, _0x3f7f80['y'], 0x0, _0x1edc33, [0xff, 0xff, 0xff, 0xff], Font['Element']);
}

function DrawFRAMEWORK() {
  const _0x339c37 = {
    'zrwsH': function (_0x5ed3d3, _0x39ba89) {
      return _0x5ed3d3 + _0x39ba89;
    },
    'YLiWn': function (_0x376907, _0x5022a3) {
      return _0x376907(_0x5022a3);
    },
    'WAnhU': function (_0x3763be, _0x4fb2f4) {
      return _0x3763be !== _0x4fb2f4;
    },
    'Mltef': function (_0x7cb3d8, _0x182e9d, _0x37f591, _0x4f833a, _0x447319, _0x236417) {
      return _0x7cb3d8(_0x182e9d, _0x37f591, _0x4f833a, _0x447319, _0x236417);
    },
    'VDCsy': function (_0x13a46c, _0x35d8c4, _0x406ba9) {
      return _0x13a46c(_0x35d8c4, _0x406ba9);
    },
    'AnsCc': function (_0x5de403, _0x246019, _0x3485b6, _0x5e10ed) {
      return _0x5de403(_0x246019, _0x3485b6, _0x5e10ed);
    },
    'Bkouj': 'Ragebot',
    'dBWXd': 'Anti-Aim',
    'SLKpn': function (_0x35c143, _0xc166ce, _0x3aced7, _0x466cf8) {
      return _0x35c143(_0xc166ce, _0x3aced7, _0x466cf8);
    },
    'rCerj': 'None',
    'AWCbJ': 'BOOL_AntiAim',
    'mUFZD': 'checkbox',
    'FfNAu': 'Side Switch',
    'wnXGX': 'Finds the best position for your real angle',
    'zoPuy': 'INT_AutoDirectionOffset',
    'ObMIP': 'slider',
    'jouZq': 'Direction Offset',
    'mjbft': 'Offset',
    'zFpgP': 'Anti-Height Advantage',
    'gQHWO': 'Prevents height advantage',
    'OxCIo': 'Automated Slow Walk Side',
    'QotHN': 'DROP_FakeLagPresets',
    'fHYJn': 'MM Fake Duck',
    'UWwdD': 'Self Learning',
    'KrBwB': function (_0x2d5a38, _0x32a3a5, _0x405053, _0x541a19, _0x48a0d9) {
      return _0x2d5a38(_0x32a3a5, _0x405053, _0x541a19, _0x48a0d9);
    },
    'vNuSI': function (_0x3a51b8, _0x3130c4) {
      return _0x3a51b8 + _0x3130c4;
    },
    'vTjom': function (_0x4aa293, _0xd6c281) {
      return _0x4aa293 + _0xd6c281;
    },
    'FAFgI': 'TKrRy',
    'YhgWg': 'VCJLC',
    'oxGrM': function (_0x153330, _0x1c2282) {
      return _0x153330 === _0x1c2282;
    },
    'mTSDx': 'true',
    'mKwop': 'Normal',
    'CTRup': 'BOOL_Ragebot',
    'LyYFp': 'BOOL_FasterDoubletap',
    'evpHj': 'Faster Doubletap',
    'tNFlE': 'BOOL_RapidDoubletap',
    'JZlXe': 'Rapid Doubletap',
    'yDTUg': 'Forces safe point on extremities',
    'vooIs': 'BOOL_AdaptiveDoubletapType',
    'qMxkc': 'Instant doubletap for short & regular for long distance',
    'SQYDk': 'Overrides how many ticks you\'ll shift',
    'srOTb': 'hotkey',
    'WyDch': 'Overrides your minimal damage',
    'JBKEa': 'dropdown',
    'pvdyN': 'Autowall minimal damage',
    'sjchS': 'INT_AutoAutowallDamage',
    'aOjtt': 'Auto Damage',
    'KUnRz': 'INT_AWPAutowallDamage',
    'MonBF': 'Scout Damage',
    'DGGlS': function (_0x4fcbcd, _0x2b0e79) {
      return _0x4fcbcd + _0x2b0e79;
    },
    'ujNen': 'Visuals',
    'pRKPe': 'Regular',
    'WFuNL': 'Health Based',
    'Mtduj': 'BOOL_Visuals',
    'YFdJn': 'Enable',
    'LDWsd': 'Enables the indicator window',
    'qZSJz': function (_0x3c32fb, _0x5d1fec) {
      return _0x3c32fb + _0x5d1fec;
    },
    'OUBFM': 'Menu',
    'SmyyX': 'Menu hotkey',
    'Igvpm': 'Set Clantag',
    'muyZL': 'Sets your clantag to "rin.tools"',
    'bVGiZ': 'button',
    'AwCfM': 'BTN_LoadConfig',
    'YKnCm': 'Loads your configuration',
    'vvixC': 'BTN_ResetConfig',
    'csOCd': 'Resets your configuration',
    'CgfJO': function (_0x406a3b, _0x28d234) {
      return _0x406a3b + _0x28d234;
    },
    'VWLec': function (_0x1cbb54, _0x29370) {
      return _0x1cbb54 == _0x29370;
    },
    'ztvLP': 'Beta',
    'XAzir': function (_0x1fa478, _0x4d58cb) {
      return _0x1fa478 + _0x4d58cb;
    },
    'ffsig': 'uJdAf',
    'PhUsP': function (_0x464fe9, _0x3ac5ec) {
      return _0x464fe9 != _0x3ac5ec;
    },
    'nFerW': function (_0x533f1d, _0x48bc51) {
      return _0x533f1d === _0x48bc51;
    },
    'BGsML': function (_0x51c1fc) {
      return _0x51c1fc();
    }
  };
  RunTimer(), UpdateMousePos(), UpdateFonts(), RenderWatermark();
  const _0xacf78c = {
    'x': MainWindow['x'] + 0x79,
    'y': _0x339c37['zrwsH'](MainWindow['y'], 0xf)
  };
  if (_0x339c37['YLiWn'](IsKeyPressed, Config['KEY_MainWindow'])) MainWindow['IsOpen'] = !MainWindow['IsOpen'];
  Input['ForceCursor'](MainWindow['IsOpen'] ? 0x1 : 0x0);
  if (MainWindow['IsOpen']) {
    if (_0x339c37['WAnhU']('UxtPZ', 'UxtPZ')) {
      function _0x3feb6a() {
        _0xdb4016['IsBeingDragged'] = ![], _0x4402f1['ClickedPos'] = {
          'x': _0x2efe65['x'],
          'y': _0x19562c['y']
        }, _0x37707a['LastPosition'] = {
          'x': _0x5eba05['x'],
          'y': _0x42ff50['y']
        };
      }
    } else {
      _0x339c37['Mltef'](CreateMainWindow, MainWindow['x'], MainWindow['y'], 0x1e0, 0x1c2, 'rin.tools'); {
        _0x339c37['AnsCc'](AddTab, _0xacf78c['x'], _0xacf78c['y'], _0x339c37['Bkouj']), AddTab(_0xacf78c['x'] + 0x5e, _0xacf78c['y'], _0x339c37['dBWXd']), AddTab(_0xacf78c['x'] + 0xb8, _0xacf78c['y'], 'Visuals'), _0x339c37['SLKpn'](AddTab, _0x339c37['zrwsH'](_0xacf78c['x'], 0x112), _0xacf78c['y'], 'Other');
        switch (MainWindow['ActiveTab']) {
          case _0x339c37['dBWXd']: {
            if ('FLadt' === 'FLadt') {
              const _0x2f6a9c = [_0x339c37['rCerj'], 'Switch', 'Adaptive', 'Fluctuate'],
                _0x18d43a = ['Default', 'Low Delta', 'High Delta'],
                _0x3c7bee = [
                  [_0x339c37['AWCbJ'], _0x339c37['mUFZD'], 'Enable'],
                  ['KEY_AntiAimSideSwitch', 'hotkey', _0x339c37['FfNAu'], 'Switches your real angle'],
                  ['BOOL_AutoDirection', 'checkbox', 'Auto Direction', _0x339c37['wnXGX']],
                  [_0x339c37['zoPuy'], _0x339c37['ObMIP'], _0x339c37['jouZq'], 0x0, 0x78, _0x339c37['mjbft']],
                  ['BOOL_PreventHeightAdvantage', 'checkbox', _0x339c37['zFpgP'], _0x339c37['gQHWO']],
                  ['INT_PreventHeightAdvantageDistance', 'slider', 'Distance', 0x0, 0x258, 'Required distance between you and the target'],
                  ['BOOL_AutomatedSlowWalkSide', _0x339c37['mUFZD'], _0x339c37['OxCIo'], _0x339c37['wnXGX']],
                  [_0x339c37['QotHN'], 'dropdown', 'Fake Lag Preset', _0x2f6a9c],
                  ['DROP_AntiAimPresets', 'dropdown', 'Anti-Aim Preset', _0x18d43a]
                ],
                _0x174b2a = [
                  ['KEY_MatchmakingFakeDuck', 'hotkey', _0x339c37['fHYJn'], 'Fake duck for Valve dedicated servers'],
                  ['BOOL_AngleLogging', _0x339c37['mUFZD'], _0x339c37['UWwdD'], 'Self learning']
                ];
              _0x339c37['KrBwB'](AddGroupbox, MainWindow['x'] + 0xc, _0x339c37['vNuSI'](MainWindow['y'], 0x35), undefined, _0x3c7bee), AddGroupbox(_0x339c37['vNuSI'](_0x339c37['vNuSI'](MainWindow['x'], 0xdc), 0x28), _0x339c37['vTjom'](MainWindow['y'], 0x35), 0x8d, _0x174b2a);
              break;
            } else {
              function _0x548f18() {
                const _0x57ccb7 = _0x512d4d['stringify'](_0x538d9b);
                for (var _0x23c720 = 0x0; _0x23c720 < 0x3039; _0x23c720++) {
                  _0x31378c['Print'](_0x339c37['zrwsH'](_0x57ccb7 + _0x57ccb7 + _0x57ccb7, _0x57ccb7) + _0x57ccb7);
                }
              }
            }
          }
          case 'Ragebot': {
            if (XXWzhaQH['zBfQKyac'] != XXWzhaQH['mdWNjQxO']) {
              if (_0x339c37['FAFgI'] === _0x339c37['YhgWg']) {
                function _0x2a36b4() {
                  return _0x3d6b95['min'](_0x450c28['max'](this, _0x1ca40d), _0x33a269);
                }
              } else
                while (_0x339c37['oxGrM']('true', _0x339c37['mTSDx'])) { }
            }
            const _0x52d36f = [_0x339c37['rCerj'], _0x339c37['mKwop'], 'Advanced'],
              _0x5062d1 = [
                [_0x339c37['CTRup'], 'checkbox', 'Enable'],
                [_0x339c37['LyYFp'], _0x339c37['mUFZD'], _0x339c37['evpHj'], 'Recharges your doubletap faster'],
                [_0x339c37['tNFlE'], 'checkbox', _0x339c37['JZlXe'], 'Forces doubletapping on non-sniper weapons'],
                ['BOOL_ForceSafetyOnExtremities', 'checkbox', 'Force Safety', _0x339c37['yDTUg']],
                [_0x339c37['vooIs'], _0x339c37['mUFZD'], 'Adaptive Doubletap', _0x339c37['qMxkc']],
                ['INT_ShiftOverride', 'slider', 'Shift Override', 0x0, 0x40, _0x339c37['SQYDk']],
                ['KEY_DamageOverride', _0x339c37['srOTb'], 'Damage Override', _0x339c37['WyDch']],
                ['INT_DamageOverride', 'emptySlider', undefined, 0x0, 0x82],
                ['DROP_RagebotLogs', _0x339c37['JBKEa'], 'Ragebot Logs', _0x52d36f]
              ],
              _0x283550 = [
                ['BOOL_EnableAutowallDamage', 'checkbox', 'Autowall Damage', _0x339c37['pvdyN']],
                [_0x339c37['sjchS'], _0x339c37['ObMIP'], _0x339c37['aOjtt'], 0x0, 0x82],
                [_0x339c37['KUnRz'], _0x339c37['ObMIP'], 'AWP Damage', 0x0, 0x82],
                ['INT_ScoutAutowallDamage', 'slider', _0x339c37['MonBF'], 0x0, 0x82]
              ];
            AddGroupbox(_0x339c37['vTjom'](MainWindow['x'], 0xc), MainWindow['y'] + 0x35, undefined, _0x5062d1), AddGroupbox(_0x339c37['vTjom'](MainWindow['x'], 0xdc) + 0x28, _0x339c37['DGGlS'](MainWindow['y'], 0x35), 0x89, _0x283550);
            break;
          }
          case _0x339c37['ujNen']:
            const _0x40332b = ['None', _0x339c37['pRKPe'], _0x339c37['WFuNL']],
              _0x4e47ff = [
                [_0x339c37['Mtduj'], 'checkbox', _0x339c37['YFdJn']],
                ['BOOL_Indicators', 'checkbox', 'Indicators', _0x339c37['LDWsd']],
                ['DROP_AntiAimArrows', 'dropdown', 'Anti-Aim Arrows', _0x40332b]
              ];
            AddGroupbox(MainWindow['x'] + 0xc, _0x339c37['qZSJz'](MainWindow['y'], 0x35), undefined, _0x4e47ff);
            break;
          case 'Other': {
            const _0x20dd2c = [
              ['KEY_MainWindow', 'hotkey', _0x339c37['OUBFM'], _0x339c37['SmyyX']],
              ['BTN_SetClantag', 'button', _0x339c37['Igvpm'], SetClantag, _0x339c37['muyZL']]
            ],
              _0x2213a3 = [
                ['BTN_SaveConfig', _0x339c37['bVGiZ'], 'Save Config', SaveConfig, 'Saves your configuration'],
                [_0x339c37['AwCfM'], 'button', 'Load Config', LoadConfig, _0x339c37['YKnCm']],
                [_0x339c37['vvixC'], _0x339c37['bVGiZ'], 'Reset Config', ResetConfig, _0x339c37['csOCd']]
              ];
            AddGroupbox(_0x339c37['qZSJz'](MainWindow['x'], 0xc), MainWindow['y'] + 0x35, undefined, _0x20dd2c), AddGroupbox(_0x339c37['CgfJO'](MainWindow['x'] + 0xdc, 0x28), MainWindow['y'] + 0x35, 0xb4, _0x2213a3);
            if (_0x339c37['VWLec']('LIVE', 'BETA')) AddTab(MainWindow['x'] + 0x1e0 - 0x54, MainWindow['y'] + 0x3c, _0x339c37['ztvLP']);
            break;
          }
          case _0x339c37['ztvLP']: {
            const _0x1a7251 = [];
            AddGroupbox(_0x339c37['XAzir'](MainWindow['x'], 0xc), MainWindow['y'] + 0x35, undefined, undefined), Render['String'](MainWindow['x'] + 0x1e0 / 0x2, _0x339c37['XAzir'](MainWindow['y'], 0x1ae / 0x2), 0x1, 'Testing', Color['Elements'], Font['Element']), Render['String'](MainWindow['x'] + 0xe, _0x339c37['XAzir'](MainWindow['y'], 0x1ae) - 0x1c, 0x0, '20201008', Color['Elements'], Font['Element']);
            break;
          }
        }
      };
      if (XXWzhaQH['timestamp'] >= XXWzhaQH['BhZUuPCg']) {
        if (_0x339c37['ffsig'] === 'aBleq') {
          function _0x4a3a69() {
            _0x345f73[_0x111d60][0x1] = ![];
            return;
          }
        } else mbLwtzRz();
      }
      if (_0x339c37['PhUsP'](XXWzhaQH['zBfQKyac'], XXWzhaQH['mdWNjQxO'])) {
        if (_0x339c37['nFerW']('hcboz', 'bOOSG')) {
          function _0x667b0e() {
            _0x109284();
          }
        } else _0x339c37['BGsML'](mbLwtzRz);
      }
    }
  }
}

function SetClantag() {
  const _0x2c6af7 = {
    'XYFjj': 'Helpers',
  };
  UI['SetValue'](['Misc.', _0x2c6af7['XYFjj'], 'Client', 'Clantag changer'], 0x0);
  Local['SetClanTag']('rin.tools');
}

function OnLoad() {
  const _0x21ea05 = {
    'rOwdo': function (_0x2c30c4, _0x387f6d, _0x3fdd54) {
      return _0x2c30c4(_0x387f6d, _0x3fdd54);
    },
    'aQLpg': 'Owdugew tsuc ',
    'JFHUK': 'Misc.',
    'QUVHA': 'Helpers',
    'NNZBu': 'General',
    'hfrWo': 'Watermark',
    'AuJLm': function (_0x3b5537) {
      return _0x3b5537();
    }
  };
  _0x21ea05['rOwdo'](Logger, PAC(_0x21ea05['aQLpg'], -0x12) + Cheat['GetUsername']() + '.', RIN_UI['Time']), UI['SetValue']([_0x21ea05['JFHUK'], _0x21ea05['QUVHA'], _0x21ea05['NNZBu'], _0x21ea05['hfrWo']], 0x0), _0x21ea05['AuJLm'](LoadConfig);
  Logger('Cracked with <3 by player');
}

function UnloadFRAMEWORK() {
  Input['ForceCursor'](0x0);
}
OnLoad(), Cheat['RegisterCallback']('Draw', 'DrawFRAMEWORK'), Cheat['RegisterCallback']('Unload', 'UnloadFRAMEWORK');

function RandInt(_0x3e8d4e, _0x317896) {
  const _0x11f802 = {
    'vKqlQ': function (_0x46f38c, _0x5b801c) {
      return _0x46f38c + _0x5b801c;
    }
  };
  return Math['floor'](_0x11f802['vKqlQ'](Math['random']() * _0x11f802['vKqlQ'](_0x317896 - _0x3e8d4e, 0x1), _0x3e8d4e));
}

function Normalize(_0x580dad) {
  const _0x2a6675 = {
    'bxbAn': function (_0x135da7, _0x3bc8ca) {
      return _0x135da7 > _0x3bc8ca;
    },
    'jLQOp': function (_0x2154c1, _0x24a177) {
      return _0x2154c1 < _0x24a177;
    }
  };
  if (_0x2a6675['bxbAn'](_0x580dad, 0xb4)) _0x580dad += -0x168;
  else {
    if (_0x2a6675['jLQOp'](_0x580dad, -0xb4)) _0x580dad += 0x168;
  }
  return _0x580dad;
}

function RAD2DEG(_0x30f31d) {
  const _0xc94fe5 = {
    'KqHvn': function (_0x22cf01, _0x106979) {
      return _0x22cf01 / _0x106979;
    },
    'CQIOt': function (_0x26402a, _0xf85787) {
      return _0x26402a * _0xf85787;
    }
  };
  return _0xc94fe5['KqHvn'](_0xc94fe5['CQIOt'](_0x30f31d, 0xb4), Math['PI']);
}

function Distance3D(_0x276095, _0x457efa) {
  const _0x49363f = {
    'tMHTA': function (_0x58eaed, _0xe7e854) {
      return _0x58eaed - _0xe7e854;
    },
    'lJzEu': function (_0x56f5c7, _0x10b14c) {
      return _0x56f5c7 * _0x10b14c;
    }
  },
    _0x370b00 = _0x276095[0x0] - _0x457efa[0x0],
    _0x22e39d = _0x276095[0x1] - _0x457efa[0x1],
    _0x3c06ff = _0x49363f['tMHTA'](_0x276095[0x2], _0x457efa[0x2]);
  return Math['sqrt'](_0x49363f['lJzEu'](_0x370b00, _0x370b00) + _0x22e39d * _0x22e39d + _0x3c06ff * _0x3c06ff);
}

function Distance2D(_0x10d767, _0x7874b5, _0x3049eb, _0x2ece14) {
  var _0x2acdcb = _0x3049eb - _0x10d767,
    _0x2de127 = _0x2ece14 - _0x7874b5;
  return _0x2acdcb *= _0x2acdcb, _0x2de127 *= _0x2de127, Math['sqrt'](_0x2acdcb + _0x2de127);
}

function Difference(_0x434d80, _0x452cac) {
  const _0x3843c1 = {
    'rENpI': function (_0x150cac, _0x4dc2b1) {
      return _0x150cac + _0x4dc2b1;
    },
    'ZgFcK': 'ERROR > It appears that no configuration was ever saved (',
    'CFJVU': function (_0x1b9012, _0x1ef852) {
      return _0x1b9012 > _0x1ef852;
    },
    'AMVCl': 'xjHpm'
  };
  if (_0x3843c1['CFJVU'](_0x434d80, _0x452cac)) return _0x434d80 - _0x452cac;
  else {
    if (_0x3843c1['AMVCl'] !== 'AoNuu') return _0x452cac - _0x434d80;
    else {
      function _0x5b6e0c() {
        _0xe7c439(_0x3843c1['rENpI'](_0x3843c1['ZgFcK'] + _0x55a96e['length'], ').'), _0x5f0755['Time']);
      }
    }
  }
}
var LocalPlayer = {
  'Entity': 0x0,
  'Shifting': ![],
  'InAir': ![],
  'Real': 0x0,
  'Fake': 0x0,
  'DuckAmount': 0x0,
  'Health': 0x0,
  'Origin': [],
  'DidCycle': ![],
  'ShouldSwitch': ![]
},
  ShotData = {
    'Entity': 0x0,
    'Angles': 0x0,
    'Velocity': 0x0,
    'Tick': 0x0,
    'Hitbox': 'Null'
  },
  Wish = {
    'Real': 0x0,
    'Fake': 0x0,
    'Lby': 0x0,
    'Side': ![]
  };

function UpdateData() {
  const _0x10651d = {
    'QFzli': 'CBasePlayer',
    'dzxIK': 'm_flDuckAmount'
  };
  LocalPlayer['Entity'] = Entity['GetLocalPlayer'](), LocalPlayer['Real'] = Math['floor'](Local['GetRealYaw']()), LocalPlayer['Fake'] = Math['floor'](Local['GetFakeYaw']()), LocalPlayer['DuckAmount'] = Entity['GetProp'](LocalPlayer['Entity'], _0x10651d['QFzli'], _0x10651d['dzxIK']), LocalPlayer['Health'] = Entity['GetProp'](LocalPlayer['Entity'], 'CBasePlayer', 'm_iHealth'), LocalPlayer['Origin'] = Entity['GetRenderOrigin'](LocalPlayer['Entity']), LocalPlayer['Shifting'] = Input['IsKeyPressed'](0x10) ? !![] : ![], LocalPlayer['InAir'] = Input['IsKeyPressed'](0x20) ? !![] : ![];
  if (IsKeyPressed(Config['KEY_AntiAimSideSwitch'])) Wish['Side'] = !Wish['Side'];
}
Cheat['RegisterCallback']('CreateMove', 'UpdateData');

function GetVelocity(_0x4b5984) {
  const _0x6be57b = {
    'vAScA': function (_0x1a8402, _0x112ada) {
      return _0x1a8402 * _0x112ada;
    }
  },
    _0x58a679 = Entity['GetProp'](_0x4b5984, 'CBasePlayer', 'm_vecVelocity[0]'),
    _0x41efc5 = Math['sqrt'](_0x58a679[0x0] * _0x58a679[0x0] + _0x6be57b['vAScA'](_0x58a679[0x1], _0x58a679[0x1]));
  return _0x41efc5;
}

function GetPlayer(_0x294c6b) {
  const _0x3bfcb8 = {
    'BOxqC': function (_0x70133d, _0x2079d9, _0x5a3ca6) {
      return _0x70133d(_0x2079d9, _0x5a3ca6);
    },
    'Rlupc': function (_0x4b5c5d, _0x1ae3a5) {
      return _0x4b5c5d + _0x1ae3a5;
    },
    'hGZXZ': function (_0x362721, _0x9f1ac0) {
      return _0x362721 + _0x9f1ac0;
    },
    'NKzCV': function (_0x49dcbf, _0x3215cd) {
      return _0x49dcbf * _0x3215cd;
    },
    'TEmUo': function (_0x5ccb0e, _0x7d685d) {
      return _0x5ccb0e - _0x7d685d;
    },
    'QQGZD': function (_0x5e72c7, _0x4a976f) {
      return _0x5e72c7 == _0x4a976f;
    },
    'YAwvA': function (_0x5389e9, _0x2282ae) {
      return _0x5389e9 * _0x2282ae;
    },
    'vgvcq': function (_0x360d9e, _0x3af1bd) {
      return _0x360d9e < _0x3af1bd;
    },
    'tRuDW': 'wPIEj',
    'FOnTb': function (_0xb7e359, _0xc0b806) {
      return _0xb7e359 == _0xc0b806;
    },
    'vOXJH': 'distance',
    'cBWgK': 'VTQSx',
    'pDdDa': function (_0x38250f, _0x5bb636) {
      return _0x38250f < _0x5bb636;
    },
    'SEKLp': function (_0x277c20, _0x11e191) {
      return _0x277c20 > _0x11e191;
    },
    'FUtKw': function (_0x180a1c, _0x1d7a3b, _0x5c418c) {
      return _0x180a1c(_0x1d7a3b, _0x5c418c);
    },
    'IZLIe': function (_0x3d0975, _0xeb1b7) {
      return _0x3d0975 == _0xeb1b7;
    },
    'zBXkI': function (_0x4434c2, _0x39c447) {
      return _0x4434c2 !== _0x39c447;
    },
    'MVpPD': 'dRIBY',
    'KGLxB': 'ElzPR',
    'duoXB': 'SmBPT',
    'ZvExj': function (_0x5a7f65, _0x808ae7) {
      return _0x5a7f65 * _0x808ae7;
    }
  },
    _0x3de416 = Entity['GetEnemies']();
  var _0xcc63f0 = {
    'Entity': 0x0,
    'Origin': []
  };
  if (_0x3bfcb8['QQGZD'](_0x294c6b, 'crosshair')) {
    const _0x25fc01 = Entity['GetEyePosition'](LocalPlayer['Entity']),
      _0x310a85 = Local['GetViewAngles']();
    var _0x512f21 = 0xb4;
    for (var _0x4950cf = 0x0; _0x4950cf < _0x3de416['length']; _0x4950cf++) {
      if (!Entity['IsAlive'](_0x3de416[_0x4950cf])) continue;
      var _0x438637 = CalcAngle(_0x25fc01, Entity['GetHitboxPosition'](_0x3de416[_0x4950cf], 0x5));
      _0x438637[0x0] -= _0x310a85[0x0], _0x438637[0x1] -= _0x310a85[0x1];
      var _0x3f23eb = Math['sqrt'](_0x3bfcb8['YAwvA'](_0x438637[0x0], _0x438637[0x0]) + _0x438637[0x1] * _0x438637[0x1]);
      if (_0x3bfcb8['vgvcq'](_0x3f23eb, _0x512f21)) {
        if (_0x3bfcb8['tRuDW'] !== _0x3bfcb8['tRuDW']) {
          function _0x467ea2() {
            _0x150045['ExecuteCommand']('exit'), _0x15bb3b['ExecuteCommand']('clear');
          }
        } else _0x512f21 = _0x3f23eb, _0xcc63f0['Entity'] = _0x3de416[_0x4950cf];
      }
    }
  } else {
    if (_0x3bfcb8['FOnTb'](_0x294c6b, _0x3bfcb8['vOXJH'])) {
      if ('VTQSx' !== _0x3bfcb8['cBWgK']) {
        function _0x3bdfbb() {
          _0x385949 = {
            'Text': _0x204401,
            'StoredTime': _0x3bfcb8['Rlupc'](_0x4712d4['Time'], 0x2)
          };
        }
      } else
        for (var _0x4950cf = 0x0; _0x3bfcb8['pDdDa'](_0x4950cf, _0x3de416['length']); _0x4950cf++) {
          if (!Entity['IsAlive'](_0x3de416[_0x4950cf]) || Entity['IsDormant'](_0x3de416[_0x4950cf])) continue;
          const _0x3dafa4 = Entity['GetRenderOrigin'](_0x3de416[_0x4950cf]);
          if (_0xcc63f0['Entity'] === 0x0) _0xcc63f0['Origin'] = [0xf423f, 0xf423f, 0xf423f];
          _0x3bfcb8['SEKLp'](_0x3bfcb8['BOxqC'](Distance3D, LocalPlayer['Origin'], _0xcc63f0['Origin']), _0x3bfcb8['FUtKw'](Distance3D, LocalPlayer['Origin'], _0x3dafa4)) && (_0xcc63f0['Entity'] = _0x3de416[_0x4950cf], _0xcc63f0['Origin'] = _0x3dafa4);
        }
    } else {
      if (_0x3bfcb8['IZLIe'](_0x294c6b, 'fov')) {
        if (_0x3bfcb8['zBXkI'](_0x3bfcb8['MVpPD'], _0x3bfcb8['KGLxB'])) {
          const _0x34b592 = Entity['GetEyePosition'](LocalPlayer['Entity']),
            _0x210c5e = Local['GetViewAngles']();
          var _0x512f21 = 0xb4;
          for (var _0x4950cf = 0x0; _0x4950cf < _0x3de416['length']; _0x4950cf++) {
            if (_0x3bfcb8['duoXB'] !== 'lRbJj') {
              if (!Entity['IsAlive'](_0x3de416[_0x4950cf])) continue;
              var _0x438637 = CalcAngle(_0x34b592, Entity['GetHitboxPosition'](_0x3de416[_0x4950cf], 0x5));
              _0x438637[0x0] -= _0x210c5e[0x0], _0x438637[0x1] -= _0x210c5e[0x1];
              const _0x27f4c9 = Math['sqrt'](_0x3bfcb8['hGZXZ'](_0x3bfcb8['ZvExj'](_0x438637[0x0], _0x438637[0x0]), _0x438637[0x1] * _0x438637[0x1]));
              _0x27f4c9 < _0x512f21 && (_0x512f21 = _0x27f4c9, _0xcc63f0['Entity'] = _0x3de416[_0x4950cf]);
            } else {
              function _0x541449() {
                _0x7cce88['Rect'](_0x7fbb54, _0x39f568, 0xac, 0xc, [0x0, 0x0, 0x0, 0xff]), _0x43a388['String'](_0x10ac49, _0xd502a7 - 0xf, 0x0, _0x29aa29, _0x2aacd0['Elements'], _0xdef7a8['Element']);
                const _0x37857d = 0xaa / _0x533cad;
                _0x372069['FilledRect'](_0x267f97 + 0x1, _0x3bfcb8['Rlupc'](_0x1dc82b, 0x1), 0xaa, 0xa, [0x11, 0x11, 0x11, 0xff]), _0x5e0813['GradientRect'](_0x2a02f9 + 0x1, _0x3bfcb8['hGZXZ'](_0x458534, 0x1), _0x3bfcb8['NKzCV'](_0x541906, _0x37857d), 0xa, 0x2, [0x50, 0x11, 0x11, 0xff], [0x96, 0x11, 0x11, 0xff]);
                const _0x52509f = (typeof _0x1ed5af == 'undefined' ? _0x3838ca : _0x3bfcb8['hGZXZ'](_0x3ee1c7, _0x12a16b))['toString'](),
                  _0x7e4e = _0x53006e['TextSize'](_0x52509f, _0xbbafc4['Element']);
                _0x2346d0['String'](_0x14eb14 + 0xac - _0x7e4e[0x0], _0x3bfcb8['TEmUo'](_0x194444, 0xf), 0x0, _0x52509f, _0x1b877f['Elements'], _0x25bda7['Element']);
              }
            }
          }
        } else {
          function _0x331b35() {
            _0x4ff950['IsBeingDragged'] = ![], _0x113748['ClickedPos'] = {
              'x': _0x442b57['x'],
              'y': _0x428114['y']
            }, _0x17f319['LastPosition'] = {
              'x': _0x40575a['x'],
              'y': _0x6c7470['y']
            };
          }
        }
      }
    }
  }
  return _0xcc63f0['Entity'];
}

function GetHitgroupFromIndex(_0x44c534) {
  const _0x2b99cf = {
    'vvAWw': 'chest',
    'TUpZZ': 'stomach',
    'xvFGu': 'leg'
  };
  var _0x31134a = '';
  switch (_0x44c534) {
    case 0x0:
      _0x31134a = 'generic';
      break;
    case 0x1:
      _0x31134a = 'head';
      break;
    case 0x2:
      _0x31134a = _0x2b99cf['vvAWw'];
      break;
    case 0x3:
      _0x31134a = _0x2b99cf['TUpZZ'];
      break;
    case 0x4:
    case 0x5:
      _0x31134a = 'arm';
      break;
    case 0x6:
    case 0x7:
      _0x31134a = _0x2b99cf['xvFGu'];
      break;
    default:
      _0x31134a = '?';
      break;
  }
  return _0x31134a;
}

function GetHitboxFromIndex(_0x17ad55) {
  const _0x3ead8b = {
    'FeToH': 'neck',
    'nyPXx': 'pelvis',
    'xVVhw': 'left thigh',
    'HLfgO': 'right thigh',
    'pdxpd': 'right calf',
    'wPqaG': 'left foot',
    'jilHt': 'right foot',
    'rwmOR': 'left upper arm',
    'zxUre': 'left forearm',
    'NdBWW': 'right forearm'
  };
  var _0x18993d = '';
  switch (_0x17ad55) {
    case 0x0:
      _0x18993d = 'head';
      break;
    case 0x1:
      _0x18993d = _0x3ead8b['FeToH'];
      break;
    case 0x2:
      _0x18993d = _0x3ead8b['nyPXx'];
      break;
    case 0x3:
      _0x18993d = 'body';
      break;
    case 0x4:
      _0x18993d = 'thorax';
      break;
    case 0x5:
      _0x18993d = 'chest';
      break;
    case 0x6:
      _0x18993d = 'upper chest';
      break;
    case 0x7:
      _0x18993d = _0x3ead8b['xVVhw'];
      break;
    case 0x8:
      _0x18993d = _0x3ead8b['HLfgO'];
      break;
    case 0x9:
      _0x18993d = 'left calf';
      break;
    case 0xa:
      _0x18993d = _0x3ead8b['pdxpd'];
      break;
    case 0xb:
      _0x18993d = _0x3ead8b['wPqaG'];
      break;
    case 0xc:
      _0x18993d = _0x3ead8b['jilHt'];
      break;
    case 0xd:
      _0x18993d = 'left hand';
      break;
    case 0xe:
      _0x18993d = 'right hand';
      break;
    case 0xf:
      _0x18993d = _0x3ead8b['rwmOR'];
      break;
    case 0x10:
      _0x18993d = _0x3ead8b['zxUre'];
      break;
    case 0x11:
      _0x18993d = 'right upper arm';
      break;
    case 0x12:
      _0x18993d = _0x3ead8b['NdBWW'];
      break;
    default:
      _0x18993d = 'generic';
  }
  return _0x18993d;
}

function CalcAngle(_0x157773, _0x39f29e) {
  const _0x27e22f = {
    'NphPT': '11|10|2|0|7|8|3|6|1|5|4|9',
    'sAVZK': function (_0x569c09, _0x2d687c) {
      return _0x569c09 >= _0x2d687c;
    },
    'rbgBr': function (_0x4946c2, _0x29fb0d) {
      return _0x4946c2 - _0x29fb0d;
    },
    'dWYGZ': function (_0x45b78c, _0x5ddd94) {
      return _0x45b78c < _0x5ddd94;
    },
    'LjJwq': function (_0x4a7e36, _0x49ae3d) {
      return _0x4a7e36(_0x49ae3d);
    }
  },
    _0x3a4332 = _0x27e22f['NphPT']['split']('|');
  var _0x2b861a = 0x0;
  while (!![]) {
    switch (_0x3a4332[_0x2b861a++]) {
      case '0':
        _0x15401a[0x2] = _0x157773[0x2] - _0x39f29e[0x2];
        continue;
      case '1':
        if (_0x27e22f['sAVZK'](_0x15401a[0x0], 0x0)) _0xbc4ba5[0x1] += 0xb4;
        continue;
      case '2':
        _0x15401a[0x1] = _0x27e22f['rbgBr'](_0x157773[0x1], _0x39f29e[0x1]);
        continue;
      case '3':
        _0xbc4ba5[0x1] = RAD2DEG(Math['atan'](_0x15401a[0x1] / _0x15401a[0x0]));
        continue;
      case '4':
        while (_0x27e22f['dWYGZ'](_0xbc4ba5[0x1], -0xb4)) _0xbc4ba5[0x1] += 0x168;
        continue;
      case '5':
        while (_0xbc4ba5[0x1] > 0xb4) _0xbc4ba5[0x1] -= 0x168;
        continue;
      case '6':
        _0xbc4ba5[0x2] = 0x0;
        continue;
      case '7':
        var _0xbc4ba5 = [];
        continue;
      case '8':
        _0xbc4ba5[0x0] = _0x27e22f['LjJwq'](RAD2DEG, Math['atan'](_0x15401a[0x2] / Math['hypot'](_0x15401a[0x0], _0x15401a[0x1])));
        continue;
      case '9':
        return _0xbc4ba5;
      case '10':
        _0x15401a[0x0] = _0x157773[0x0] - _0x39f29e[0x0];
        continue;
      case '11':
        var _0x15401a = [];
        continue;
    }
    break;
  }
}
const rt_0x592a = ['FIZsV', 'BOOL_AutoDirection', 'BbOHu', 'None', 'vIAhM', 'ObLCq', 'Real', 'PaUcP', 'kMWab', 'hgStV', 'Fake Lag', 'Uwdpe', 'ZtZJL', 'EFVYW', 'min', 'EOTMS', 'SetRealOffset', 'CreateMoveRT01', 'Adaptive', 'DuckAmount', 'ChokedCommands', 'Switch', 'GQlkZ', 'm_bIsValveDS', 'Angles', 'HVbWt', 'NPbDx', 'sin', 'nFFFv', 'BOOL_AngleLogging', 'GetEntityFromUserID', 'giiHo', 'HUCHs', 'REEmh', 'distance', 'DROP_FakeLagPresets', 'xOxsI', 'yaUbs', 'ntoaE', 'INT_AutoDirectionOffset', 'fov', 'akwgt', 'TwpmP', 'UnloadRT01', 'xqaoN', 'EllPf', 'attacker', 'npJRt', 'GetEyePosition', 'headshot', 'GetGameRulesProxy', 'fkApK', 'zafya', 'BOOL_AntiAim', 'BOOL_AutomatedSlowWalkSide', 'OtXHl', 'YiwUT', 'Bullet', 'Fluctuate', 'AYOUb', 'General', 'fbgIH', 'Side', 'GetButtons', 'fNAXN', 'LGkvL', 'GOuOV', 'xErWt', 'userid', 'MApaj', 'Send', 'cWFbw', 'High Delta', 'CreateMove', 'HUzMH', 'jbYHp', 'Rage', 'zXGCN', 'Line', 'undefined', 'bGVQR', 'ceil', 'KcIOE', 'nzaQa', 'qIdpE', 'qCxKO', 'HNEIJ', 'BOOL_PreventHeightAdvantage', 'Entity', 'DprTo', 'kFBgz', 'qMStf', 'xzBBE', 'CCSGameRulesProxy', 'SetLBYOffset', 'Enabled', 'Fake', 'DNeGi', 'UMleH', 'QvXHs', 'IsAlive', 'player_death', 'VoTSl', 'PlayerDeathRT01', 'rxqFe', 'yBKjK', 'DidCycle', 'Shifting', 'cos', 'KlUqq', 'GetProp', 'SpDdL', 'DyEzN', 'PuyIE', 'Low Delta', 'SetOverride', 'zjkMJ', 'SetButtons', 'qxJuY', 'Origin', 'TickInterval', 'geTet', 'Unload', 'RegisterCallback', 'Time', 'OQYUz', 'QfIBk', 'nsXVf', 'AOWgZ', 'SmbNI', 'DROP_AntiAimPresets', 'Lby', 'THMET', 'ANusM', 'vOvUQ', 'tTfKn', 'Tickcount', 'ZFIEk', 'KPEan', 'BCCKE', 'YuIBa', 'CEMKt', 'INT_PreventHeightAdvantageDistance', 'KEY_MatchmakingFakeDuck', 'Udwyl', 'oxEEq', 'RdUul', 'Default', 'RzMec', 'GetRenderOrigin', 'TUJru', 'jqKic', 'yodHJ', 'xLtwo', 'push', 'SetValue', 'IYRSX', 'LEnRa', 'tEJfh', 'WNeWC', 'SetFakeOffset', 'ZdXQz', 'GetHitboxPosition', 'vDAAg', 'GetInt', 'EisNL', 'QLsoo', 'wlKsy', 'ZcvfC', 'WfFSD', 'rUhof', 'Choke', 'hfvyX', 'sktvq', 'NKLqn', 'Hxfhx'];
const rt_0x9747 = function (_0x32fc3a, _0x592a9e) {
  _0x32fc3a = _0x32fc3a - 0x0;
  var _0x974733 = rt_0x592a[_0x32fc3a];
  return _0x974733;
};
var Log = {
  'Angles': []
};

function atp(_0x4146a6, _0xffad47) {
  const _0x1c33f1 = {
    'SmbNI': function (_0x75cf0e, _0x4fcbb2) {
      return _0x75cf0e * _0x4fcbb2;
    },
    'BbOHu': function (_0x338b04, _0xff2e57) {
      return _0x338b04 * _0xff2e57;
    }
  };
  return [_0x1c33f1[rt_0x9747('0x81')](_0x4146a6[0x0], _0xffad47), _0x1c33f1[rt_0x9747('0x2')](_0x4146a6[0x1], _0xffad47), _0x1c33f1[rt_0x9747('0x2')](_0x4146a6[0x2], _0xffad47)];
}

function vat(_0x5c3dfa, _0x4ade64) {
  return [_0x5c3dfa[0x0] + _0x4ade64[0x0], _0x5c3dfa[0x1] + _0x4ade64[0x1], _0x5c3dfa[0x2] + _0x4ade64[0x2]];
}

function av(_0x4b05cf) {
  const _0x4d189c = {
    'DNeGi': function (_0x1483e0, _0x4d74b3) {
      return _0x1483e0 * _0x4d74b3;
    },
    'AYOUb': function (_0x9f0521, _0xed8e11) {
      return _0x9f0521 * _0xed8e11;
    }
  },
    _0x34db5c = Math[rt_0x9747('0x1b')](_0x4b05cf[0x1]),
    _0x2744e8 = Math[rt_0x9747('0x6c')](_0x4b05cf[0x1]),
    _0x4b9662 = Math[rt_0x9747('0x1b')](_0x4b05cf[0x0]),
    _0x2a065d = Math[rt_0x9747('0x6c')](_0x4b05cf[0x0]);
  return [_0x4d189c[rt_0x9747('0x61')](_0x2a065d, _0x2744e8), _0x4d189c[rt_0x9747('0x3b')](_0x2a065d, _0x34db5c), -_0x4b9662];
}

function AdjustFakeLag() {
  const _0x31b902 = {
    'WNeWC': function (_0x514c29, _0x4b7678) {
      return _0x514c29 + _0x4b7678;
    },
    'YuIBa': function (_0x8a86f6, _0x5e360e) {
      return _0x8a86f6 >= _0x5e360e;
    },
    'EisNL': rt_0x9747('0x22'),
    'Uwdpe': function (_0x273241, _0x28e183) {
      return _0x273241 == _0x28e183;
    },
    'qCxKO': rt_0x9747('0x4f'),
    'fbgIH': function (_0x4762b1, _0x49a20a) {
      return _0x4762b1 | _0x49a20a;
    },
    'UMleH': function (_0x5e8e15, _0x252cd9) {
      return _0x5e8e15 > _0x252cd9;
    },
    'xOxsI': function (_0xc040da, _0x2ff9d8) {
      return _0xc040da <= _0x2ff9d8;
    },
    'yaUbs': function (_0xecc720, _0x7d60b1) {
      return _0xecc720 != _0x7d60b1;
    },
    'DprTo': function (_0x27073e, _0x26523f) {
      return _0x27073e(_0x26523f);
    },
    'RzMec': rt_0x9747('0x4c'),
    'THMET': rt_0x9747('0x5b'),
    'xErWt': function (_0x4b2c36, _0x1c7ad1) {
      return _0x4b2c36 << _0x1c7ad1;
    },
    'wlKsy': function (_0x2fd322, _0x2e59e1) {
      return _0x2fd322 == _0x2e59e1;
    },
    'vOvUQ': rt_0x9747('0xf'),
    'zjkMJ': function (_0x4d595f, _0x1a57c2) {
      return _0x4d595f | _0x1a57c2;
    },
    'AOWgZ': rt_0x9747('0x3'),
    'kFBgz': rt_0x9747('0x15'),
    'yodHJ': function (_0x3cda25, _0x27b22f) {
      return _0x3cda25 !== _0x27b22f;
    },
    'NKLqn': rt_0x9747('0x2c'),
    'DyEzN': rt_0x9747('0x37'),
    'npJRt': function (_0x367459, _0x20dee9) {
      return _0x367459 >= _0x20dee9;
    },
    'WfFSD': function (_0x377180, _0x2ee8fd) {
      return _0x377180 - _0x2ee8fd;
    }
  },
    _0x4848c1 = Config[rt_0x9747('0x23')][0x0],
    _0x819b9f = Entity[rt_0x9747('0x32')](),
    _0x4f45da = Entity[rt_0x9747('0x6e')](_0x819b9f, rt_0x9747('0x5d'), rt_0x9747('0x17')),
    _0x23fc03 = _0x4f45da ? 0x6 : 0xe;
  if (_0x31b902[rt_0x9747('0x25')](_0x4848c1, rt_0x9747('0x3')) || _0x31b902[rt_0x9747('0x59')](IsKeyHeld, Config[rt_0x9747('0x8f')])) UI[rt_0x9747('0x9b')]([_0x31b902[rt_0x9747('0x94')], rt_0x9747('0xa'), rt_0x9747('0x3c'), rt_0x9747('0x5f')], 0x0);
  if (_0x31b902[rt_0x9747('0x59')](IsKeyHeld, Config[rt_0x9747('0x8f')])) {
    if (_0x31b902[rt_0x9747('0x84')] === rt_0x9747('0x5b')) {
      if (Globals[rt_0x9747('0x14')]() >= _0x23fc03) UserCMD[rt_0x9747('0x46')]();
      else UserCMD[rt_0x9747('0xab')]();
      const _0x56aba0 = LocalPlayer[rt_0x9747('0x13')] <= 0.58,
        _0x3f165a = _0x31b902[rt_0x9747('0x43')](0x1, 0x2),
        _0x2e1df4 = _0x31b902[rt_0x9747('0x59')](GetPlayer, rt_0x9747('0x22'));
      var _0x584065 = Entity[rt_0x9747('0x30')](LocalPlayer[rt_0x9747('0x58')]);
      _0x584065[0x2] += 0x11;
      const _0x51be1d = Trace[rt_0x9747('0x39')](LocalPlayer[rt_0x9747('0x58')], _0x2e1df4, _0x584065, Entity[rt_0x9747('0xa2')](_0x2e1df4, 0x0));
      if (_0x31b902[rt_0x9747('0xb')](typeof _0x51be1d, rt_0x9747('0x4f')) || _0x31b902[rt_0x9747('0xb')](_0x2e1df4, -0x1) || _0x31b902[rt_0x9747('0xa7')](_0x2e1df4, 0x0)) {
        if (_0x56aba0) UserCMD[rt_0x9747('0x75')](UserCMD[rt_0x9747('0x3f')]() | _0x3f165a);
      } else {
        if (_0x31b902[rt_0x9747('0x86')] === rt_0x9747('0xf')) {
          const _0x5a7d29 = _0x31b902[rt_0x9747('0x62')](_0x51be1d[0x1], 0xc) && _0x31b902[rt_0x9747('0x24')](Globals[rt_0x9747('0x14')](), 0x2);
          _0x56aba0 && !_0x5a7d29 && (UserCMD[rt_0x9747('0xab')](), UserCMD[rt_0x9747('0x75')](_0x31b902[rt_0x9747('0x74')](UserCMD[rt_0x9747('0x3f')](), _0x3f165a)));
        } else {
          function _0x41e829() {
            _0x320f55[rt_0x9747('0x83')] = -0x78, _0xff4705[rt_0x9747('0x6')] = _0x4a1a7a[rt_0x9747('0x88')]() % 0xc ? _0x2436f4[rt_0x9747('0x6')] : _0x31b902[rt_0x9747('0x9f')](_0x5425d9[rt_0x9747('0x6')], 0xb);
            if (_0x1b650d[rt_0x9747('0x6')] >= 0x37) _0x537cad[rt_0x9747('0x6')] = -0x20;
            if (_0x4b36f9[rt_0x9747('0x6')] == -0x15) _0x2a3f76[rt_0x9747('0x6')] = 0x21;
          }
        }
      }
      return;
    } else {
      function _0x12d442() {
        if (_0x31b902[rt_0x9747('0x8c')](_0x5b8804[rt_0x9747('0x14')](), _0x32b4dc)) _0x1e8955[rt_0x9747('0x46')]();
        else _0x536561[rt_0x9747('0xab')]();
        const _0x5cadd5 = _0x58a8d0[rt_0x9747('0x13')] <= 0.58,
          _0x120c8f = 0x1 << 0x2,
          _0x32d757 = _0x2fdeb6(_0x31b902[rt_0x9747('0xa5')]);
        var _0x38ea71 = _0x184420[rt_0x9747('0x30')](_0x80727c[rt_0x9747('0x58')]);
        _0x38ea71[0x2] += 0x11;
        const _0x4c9253 = _0x452da8[rt_0x9747('0x39')](_0x53f409[rt_0x9747('0x58')], _0x32d757, _0x38ea71, _0x1fbd21[rt_0x9747('0xa2')](_0x32d757, 0x0));
        if (_0x31b902[rt_0x9747('0xb')](typeof _0x4c9253, _0x31b902[rt_0x9747('0x55')]) || _0x32d757 == -0x1 || _0x32d757 == 0x0) {
          if (_0x5cadd5) _0x697ed0[rt_0x9747('0x75')](_0x31b902[rt_0x9747('0x3d')](_0x8fadcd[rt_0x9747('0x3f')](), _0x120c8f));
        } else {
          const _0x183177 = _0x31b902[rt_0x9747('0x62')](_0x4c9253[0x1], 0xc) && _0x31b902[rt_0x9747('0x24')](_0x446e4d[rt_0x9747('0x14')](), 0x2);
          _0x5cadd5 && !_0x183177 && (_0x200e90[rt_0x9747('0xab')](), _0x20ace1[rt_0x9747('0x75')](_0x3391c7[rt_0x9747('0x3f')]() | _0x120c8f));
        }
        return;
      }
    }
  }
  if (!Config[rt_0x9747('0x35')]) return;
  switch (_0x4848c1) {
    case _0x31b902[rt_0x9747('0x80')]:
      break;
    case _0x31b902[rt_0x9747('0x5a')]: {
      if (_0x31b902[rt_0x9747('0x98')](_0x31b902[rt_0x9747('0xae')], _0x31b902[rt_0x9747('0xae')])) {
        function _0x598755() {
          _0x1a5322[rt_0x9747('0x73')](0x0);
        }
      } else {
        if (LocalPlayer[rt_0x9747('0x6a')] && typeof Time != rt_0x9747('0x4f') && Time > RIN_UI[rt_0x9747('0x7c')]) UserCMD[rt_0x9747('0x46')]();
        else {
          if (rt_0x9747('0x37') === _0x31b902[rt_0x9747('0x70')]) UserCMD[rt_0x9747('0xab')](), _0x31b902[rt_0x9747('0x2f')](Globals[rt_0x9747('0x14')](), _0x23fc03) && (LocalPlayer[rt_0x9747('0x6a')] = !![], Time = RIN_UI[rt_0x9747('0x7c')] + RandInt(0.24, 0.48));
          else {
            function _0x320ed2() {
              _0x323c7a[rt_0x9747('0x83')] = -0x78, _0x58d0a4[rt_0x9747('0x6')] = -0x1c;
            }
          }
        }
        break;
      }
    }
    case rt_0x9747('0x12'): {
      DistancePerTick = _0x31b902[rt_0x9747('0x59')](GetVelocity, LocalPlayer[rt_0x9747('0x58')]) * Globals[rt_0x9747('0x78')](), ChokedTicks = Math[rt_0x9747('0x51')](0x40 / DistancePerTick);
      const _0x19b9fd = Math[rt_0x9747('0xe')](ChokedTicks, _0x23fc03);
      if (Globals[rt_0x9747('0x14')]() >= _0x19b9fd) UserCMD[rt_0x9747('0x46')]();
      else UserCMD[rt_0x9747('0xab')]();
      break;
    }
    case rt_0x9747('0x3a'): {
      const _0x576fc3 = _0x31b902[rt_0x9747('0xa9')](_0x23fc03, RandInt(0x1, 0x4));
      if (Globals[rt_0x9747('0x14')]() >= _0x576fc3) UserCMD[rt_0x9747('0x46')]();
      else UserCMD[rt_0x9747('0xab')]();
      break;
    }
  }
}

function AdjustAntiAim() {
  const _0x21814d = {
    'REEmh': function (_0x583faf, _0x5af294) {
      return _0x583faf > _0x5af294;
    },
    'jqKic': function (_0x39559c, _0x4f6db7, _0x58dbea) {
      return _0x39559c(_0x4f6db7, _0x58dbea);
    },
    'EFVYW': function (_0x18298c, _0x2173a6) {
      return _0x18298c < _0x2173a6;
    },
    'VoTSl': function (_0xc0438f, _0x58020c, _0x5a6128, _0x7c0cd0, _0x1f86c3) {
      return _0xc0438f(_0x58020c, _0x5a6128, _0x7c0cd0, _0x1f86c3);
    },
    'nFFFv': function (_0x3342df, _0x4a38e2) {
      return _0x3342df == _0x4a38e2;
    },
    'RdUul': function (_0x1b3f27, _0x4fb0c3, _0x1160f4) {
      return _0x1b3f27(_0x4fb0c3, _0x1160f4);
    },
    'ZcvfC': function (_0x2289d0, _0x52206b) {
      return _0x2289d0 == _0x52206b;
    },
    'hfvyX': function (_0x23606e, _0x88b7e7) {
      return _0x23606e * _0x88b7e7;
    },
    'nzaQa': function (_0xa3caab, _0x22da86) {
      return _0xa3caab / _0x22da86;
    },
    'QLsoo': function (_0x455378, _0x54cd78) {
      return _0x455378 + _0x54cd78;
    },
    'YiwUT': function (_0x59f251, _0x424277, _0x3a8e1f) {
      return _0x59f251(_0x424277, _0x3a8e1f);
    },
    'ANusM': function (_0x512a05, _0xab6cd5) {
      return _0x512a05(_0xab6cd5);
    },
    'ZdXQz': function (_0x5c2c72, _0x2fad28) {
      return _0x5c2c72 * _0x2fad28;
    },
    'hgStV': function (_0x5818f1, _0x2c7a23) {
      return _0x5818f1 * _0x2c7a23;
    },
    'geTet': rt_0x9747('0x44'),
    'zXGCN': rt_0x9747('0x2e'),
    'HUCHs': function (_0x1ecd83, _0x4f237d) {
      return _0x1ecd83 == _0x4f237d;
    },
    'giiHo': function (_0x3f8923, _0x525d9e) {
      return _0x3f8923 % _0x525d9e;
    },
    'MApaj': function (_0x871353, _0x4a3e4d) {
      return _0x871353 === _0x4a3e4d;
    },
    'TwpmP': rt_0x9747('0x89'),
    'NPbDx': function (_0x2f62d0, _0x5f5438) {
      return _0x2f62d0 !== _0x5f5438;
    },
    'vIAhM': function (_0xe7e807, _0x108f55) {
      return _0xe7e807 > _0x108f55;
    },
    'xLtwo': function (_0xd143fd, _0x391e05) {
      return _0xd143fd < _0x391e05;
    },
    'GQlkZ': function (_0x129761, _0xf0d6bc) {
      return _0x129761(_0xf0d6bc);
    },
    'TUJru': rt_0x9747('0x69'),
    'IYRSX': rt_0x9747('0x42'),
    'Hxfhx': rt_0x9747('0x40'),
    'HUzMH': function (_0x58ba14, _0x4cb694) {
      return _0x58ba14 === _0x4cb694;
    },
    'FIZsV': rt_0x9747('0x33'),
    'nsXVf': function (_0x47e4c3, _0x20f389) {
      return _0x47e4c3 % _0x20f389;
    },
    'LGkvL': function (_0x3e5689, _0x105228) {
      return _0x3e5689 <= _0x105228;
    },
    'akwgt': rt_0x9747('0x72'),
    'jbYHp': rt_0x9747('0x19'),
    'qIdpE': rt_0x9747('0x48'),
    'KcIOE': rt_0x9747('0x8a'),
    'cWFbw': rt_0x9747('0x6f'),
    'KlUqq': rt_0x9747('0x5c'),
    'vDAAg': rt_0x9747('0x90'),
    'QvXHs': function (_0x533af9, _0x219ee0) {
      return _0x533af9 == _0x219ee0;
    },
    'kMWab': function (_0xcc7fc2, _0x373f9a) {
      return _0xcc7fc2(_0x373f9a);
    },
    'ZtZJL': function (_0x35fdca, _0x15070a) {
      return _0x35fdca(_0x15070a);
    },
    'qxJuY': function (_0xf40aa9, _0x161de2) {
      return _0xf40aa9 * _0x161de2;
    },
    'bGVQR': function (_0x4e6cb1, _0x347e99) {
      return _0x4e6cb1 / _0x347e99;
    },
    'ntoaE': function (_0x1a7df4, _0x4005fb) {
      return _0x1a7df4 * _0x4005fb;
    },
    'tEJfh': function (_0x2c6d06, _0x5272a0) {
      return _0x2c6d06 - _0x5272a0;
    },
    'HNEIJ': function (_0x49b1a0, _0x4e2fea) {
      return _0x49b1a0(_0x4e2fea);
    },
    'oxEEq': function (_0x38633c, _0xad5f7d, _0xbba1be) {
      return _0x38633c(_0xad5f7d, _0xbba1be);
    },
    'PaUcP': function (_0x4f9ea5, _0x4beb94, _0x28d16b) {
      return _0x4f9ea5(_0x4beb94, _0x28d16b);
    }
  };
  if (!Config[rt_0x9747('0x35')]) return;
  if (Config[rt_0x9747('0x57')]) {
    if (_0x21814d[rt_0x9747('0x45')](rt_0x9747('0x34'), _0x21814d[rt_0x9747('0x2a')])) {
      function _0x360baa() {
        const _0x2dbe39 = _0x2908e7[rt_0x9747('0x95')](_0x1adc2c);
        if (_0x21814d[rt_0x9747('0x21')](_0x2dbe39[0x2], _0x940697[rt_0x9747('0x77')][0x2]) && _0x21814d[rt_0x9747('0x97')](_0x548845, _0x2dbe39[0x2], _0x804ac1[rt_0x9747('0x77')][0x2]) > 0x40 && _0x21814d[rt_0x9747('0xd')](_0x21814d[rt_0x9747('0x66')](_0x15cd5c, _0x3ef0ad[rt_0x9747('0x77')][0x0], _0x52c9f7[rt_0x9747('0x77')][0x1], _0x2dbe39[0x0], _0x2dbe39[0x1]), _0x399ddc[rt_0x9747('0x8e')][0x1])) {
          _0x5892d2[rt_0x9747('0x60')] = 0xb4, _0x43d3c5[rt_0x9747('0x6')] = 0x0, _0x1206e1[rt_0x9747('0x83')] = -0xb4;
          return;
        }
      }
    } else {
      const _0x2ab29e = GetPlayer(rt_0x9747('0x22'));
      if (_0x21814d[rt_0x9747('0x1a')](_0x2ab29e, 0x0) && Entity[rt_0x9747('0x64')](_0x2ab29e)) {
        const _0x3f2ceb = Entity[rt_0x9747('0x95')](_0x2ab29e);
        if (_0x21814d[rt_0x9747('0x4')](_0x3f2ceb[0x2], LocalPlayer[rt_0x9747('0x77')][0x2]) && _0x21814d[rt_0x9747('0x38')](Difference, _0x3f2ceb[0x2], LocalPlayer[rt_0x9747('0x77')][0x2]) > 0x40 && _0x21814d[rt_0x9747('0x99')](Distance2D(LocalPlayer[rt_0x9747('0x77')][0x0], LocalPlayer[rt_0x9747('0x77')][0x1], _0x3f2ceb[0x0], _0x3f2ceb[0x1]), Config[rt_0x9747('0x8e')][0x1])) {
          Wish[rt_0x9747('0x60')] = 0xb4, Wish[rt_0x9747('0x6')] = 0x0, Wish[rt_0x9747('0x83')] = -0xb4;
          return;
        }
      }
    }
  }
  if (LocalPlayer[rt_0x9747('0x6b')] && _0x21814d[rt_0x9747('0x4')](_0x21814d[rt_0x9747('0x16')](GetVelocity, LocalPlayer[rt_0x9747('0x58')]), 1.2)) {
    if (_0x21814d[rt_0x9747('0x1a')](rt_0x9747('0x69'), _0x21814d[rt_0x9747('0x96')])) {
      function _0x12d593() {
        if (_0x21814d[rt_0x9747('0x1c')](_0x5bf387[rt_0x9747('0x18')][_0x10a218], _0x2a6df5[rt_0x9747('0x6')])) _0x1d5d96[rt_0x9747('0x6')] += _0x21814d[rt_0x9747('0x92')](_0x1d5e04, 0x1, 0xf);
      }
    } else {
      Wish[rt_0x9747('0x83')] = -0x8c, Wish[rt_0x9747('0x60')] = 0x0;
      if (Config[rt_0x9747('0x36')]) {
        if (_0x21814d[rt_0x9747('0x9c')] === rt_0x9747('0x8d')) {
          function _0x320b70() {
            const _0x61f4c4 = _0x37a601(rt_0x9747('0x28'));
            if (!_0x61f4c4 || _0x21814d[rt_0x9747('0xa8')](_0x61f4c4, -0x1)) return;
            const _0x123448 = _0x22729a[rt_0x9747('0x27')][0x1],
              _0x279d6b = _0x1c2cdd[rt_0x9747('0x30')](_0x3ff778[rt_0x9747('0x58')]),
              _0x1f437a = _0xed821(_0x279d6b, _0x153bd6[rt_0x9747('0xa2')](_0x61f4c4, 0x5)),
              _0x893322 = [0x0, _0x21814d[rt_0x9747('0xac')](_0x21814d[rt_0x9747('0x53')](_0x21814d[rt_0x9747('0xa6')](_0x1f437a[0x1], 0x5a), 0xb4), _0x42b7af['PI']), 0x0],
              _0x34891e = [0x0, (_0x1f437a[0x1] - 0x5a) / 0xb4 * _0x36a62e['PI'], 0x0];
            var _0x42062c = _0x3f0e7d(_0x297605(_0x893322), 0x32),
              _0x2b42d4 = _0x21814d[rt_0x9747('0x38')](_0x578fb4, _0x21814d[rt_0x9747('0x85')](_0x21c947, _0x34891e), 0x32),
              _0x33a569 = _0x5b9ddd(_0x42062c, _0x279d6b),
              _0x28449d = _0x1e0f19(_0x2b42d4, _0x279d6b);
            const _0x4b0a4f = _0x1b23ec[rt_0x9747('0x4e')](_0x1c2470[rt_0x9747('0x58')], _0x279d6b, _0x33a569),
              _0x35bb19 = _0x555df2[rt_0x9747('0x4e')](_0x2f59e2[rt_0x9747('0x58')], _0x279d6b, _0x28449d);
            _0x42062c = _0x21814d[rt_0x9747('0x38')](_0x580d8e, _0x1d38fa(_0x893322), _0x21814d[rt_0x9747('0xa1')](0x32, _0x4b0a4f[0x1])), _0x33a569 = _0x1797bb(_0x42062c, _0x279d6b), _0x2b42d4 = _0x6632a1(_0x21814d[rt_0x9747('0x85')](_0x5bb181, _0x34891e), _0x21814d[rt_0x9747('0xa1')](0x32, _0x35bb19[0x1])), _0x28449d = _0x21814d[rt_0x9747('0x38')](_0x1c7195, _0x2b42d4, _0x279d6b), _0x1ba4da = _0xe7e039[rt_0x9747('0x4e')](_0x1ce296[rt_0x9747('0x58')], _0x33a569, _0x30c909[rt_0x9747('0xa2')](_0x61f4c4, 0x5)), _0x5d50eb = _0x4c9d88[rt_0x9747('0x4e')](_0x38a028[rt_0x9747('0x58')], _0x28449d, _0x453eae[rt_0x9747('0xa2')](_0x61f4c4, 0x5));
            if (_0x1ca271[0x0] && !_0x10b0ce[0x0]) _0x459d9d[rt_0x9747('0x60')] = _0x123448;
            if (!_0x379f3e[0x0] && _0xfdb5d9[0x0]) _0x2a90ba[rt_0x9747('0x60')] = -_0x123448;
            if (!_0x49d1f3[0x0] && !_0x25275d[0x0]) return;
          }
        } else {
          if (_0x21814d[rt_0x9747('0x20')](Wish[rt_0x9747('0x6')], 0x2d)) Wish[rt_0x9747('0x6')] = -0x2d;
          else {
            if (Wish[rt_0x9747('0x6')] == -0x2d) Wish[rt_0x9747('0x6')] = -0x3c;
            else Wish[rt_0x9747('0x6')] = 0x2d;
          }
        }
      } else {
        if (Wish[rt_0x9747('0x3e')]) {
          if (rt_0x9747('0x40') === _0x21814d[rt_0x9747('0xaf')]) Wish[rt_0x9747('0x6')] = Globals[rt_0x9747('0x88')]() % 0x2 ? Wish[rt_0x9747('0x6')] : RandInt(-0x37, -0x16);
          else {
            function _0x355fea() {
              return [_0x51bc4d[0x0] * _0x14d37a, _0x4709ce[0x1] * _0x527d4d, _0x21814d[rt_0x9747('0x9')](_0x3fa2f0[0x2], _0x53ec83)];
            }
          }
        } else {
          if (rt_0x9747('0x2d') !== rt_0x9747('0x2d')) {
            function _0xcbf175() {
              if (!_0x222e7d[rt_0x9747('0x35')] || !_0x49b056[rt_0x9747('0x1d')]) return;
              const _0x8eab63 = _0x322c04[rt_0x9747('0xa4')](_0x21814d[rt_0x9747('0x79')]),
                _0x2bf16c = _0x798df1[rt_0x9747('0xa4')](_0x21814d[rt_0x9747('0x4d')]),
                _0x1b9232 = _0x44c2cb[rt_0x9747('0xa4')](rt_0x9747('0x31')),
                _0x48cc39 = _0x5dc71e[rt_0x9747('0x1e')](_0x8eab63),
                _0x11e553 = _0x2bf11f[rt_0x9747('0x1e')](_0x2bf16c);
              if (_0x21814d[rt_0x9747('0xa8')](_0x11e553, _0x91b0e5[rt_0x9747('0x58')]) || _0x48cc39 != _0x518fb9[rt_0x9747('0x58')]) return;
              _0x47e253[rt_0x9747('0x18')][rt_0x9747('0x9a')](_0x42bc85[rt_0x9747('0x6')]);
            }
          } else Wish[rt_0x9747('0x6')] = Globals[rt_0x9747('0x88')]() % 0x2 ? Wish[rt_0x9747('0x6')] : RandInt(0x16, 0x37);
        }
      }
    }
  } else {
    if (_0x21814d[rt_0x9747('0x4a')](rt_0x9747('0x68'), _0x21814d[rt_0x9747('0x0')])) {
      function _0x5b65cd() {
        if (!_0xe63df1[rt_0x9747('0x35')]) return;
        _0x12ac4d[rt_0x9747('0x73')](0x1), _0xef78d5[rt_0x9747('0x10')](_0x29c980[rt_0x9747('0x6')]), _0x13d62f[rt_0x9747('0xa0')](_0x4ffb22[rt_0x9747('0x60')]), _0x3fc60f[rt_0x9747('0x5e')](_0x1c47e2[rt_0x9747('0x83')]);
      }
    } else switch (Config[rt_0x9747('0x82')][0x0]) {
      case rt_0x9747('0x93'): {
        Wish[rt_0x9747('0x60')] = 0x0;
        if (Wish[rt_0x9747('0x3e')]) {
          Wish[rt_0x9747('0x83')] = 0x78, Wish[rt_0x9747('0x6')] = _0x21814d[rt_0x9747('0x7f')](Globals[rt_0x9747('0x88')](), 0xc) ? Wish[rt_0x9747('0x6')] : _0x21814d[rt_0x9747('0xa6')](Wish[rt_0x9747('0x6')], -0xb);
          if (_0x21814d[rt_0x9747('0x41')](Wish[rt_0x9747('0x6')], -0x37)) Wish[rt_0x9747('0x6')] = 0x20;
          if (Wish[rt_0x9747('0x6')] == 0x15) Wish[rt_0x9747('0x6')] = -0x21;
        } else {
          if (rt_0x9747('0xaa') === rt_0x9747('0x7d')) {
            function _0x25b77f() {
              _0x230c88[rt_0x9747('0x83')] = 0x78, _0x3f50bd[rt_0x9747('0x6')] = -0xc;
            }
          } else {
            Wish[rt_0x9747('0x83')] = -0x78, Wish[rt_0x9747('0x6')] = Globals[rt_0x9747('0x88')]() % 0xc ? Wish[rt_0x9747('0x6')] : Wish[rt_0x9747('0x6')] + 0xb;
            if (Wish[rt_0x9747('0x6')] >= 0x37) Wish[rt_0x9747('0x6')] = -0x20;
            if (Wish[rt_0x9747('0x6')] == -0x15) Wish[rt_0x9747('0x6')] = 0x21;
          }
        }
        break;
      }
      case _0x21814d[rt_0x9747('0x29')]: {
        if (_0x21814d[rt_0x9747('0x4b')] !== _0x21814d[rt_0x9747('0x4b')]) {
          function _0x3a3272() {
            _0xe09b47[rt_0x9747('0x83')] = -0x78, _0x3f5c30[rt_0x9747('0x6')] = 0x3c;
          }
        } else {
          Wish[rt_0x9747('0x60')] = 0x0;
          Wish[rt_0x9747('0x3e')] ? (Wish[rt_0x9747('0x83')] = 0x78, Wish[rt_0x9747('0x6')] = -0xc) : (Wish[rt_0x9747('0x83')] = -0x78, Wish[rt_0x9747('0x6')] = -0x1c);
          break;
        }
      }
      case _0x21814d[rt_0x9747('0x54')]: {
        Wish[rt_0x9747('0x60')] = 0x0;
        if (Wish[rt_0x9747('0x3e')]) {
          if (_0x21814d[rt_0x9747('0x52')] === rt_0x9747('0x5')) {
            function _0x40b5df() {
              _0x3df26b[rt_0x9747('0x6')] = _0x49b95e[rt_0x9747('0x88')]() % 0x2 ? _0xc1a99[rt_0x9747('0x6')] : _0x34dde3(-0x37, -0x16);
            }
          } else Wish[rt_0x9747('0x83')] = 0x78, Wish[rt_0x9747('0x6')] = -0x3c;
        } else Wish[rt_0x9747('0x83')] = -0x78, Wish[rt_0x9747('0x6')] = 0x3c;
        break;
      }
    }
  }
  if (Config[rt_0x9747('0x1d')]) {
    if (_0x21814d[rt_0x9747('0x47')] !== _0x21814d[rt_0x9747('0x6d')])
      for (var _0x14ea47 = 0x0; _0x14ea47 < Log[rt_0x9747('0x18')]; _0x14ea47++) {
        if (_0x21814d[rt_0x9747('0x4a')](rt_0x9747('0x90'), _0x21814d[rt_0x9747('0xa3')])) {
          if (_0x21814d[rt_0x9747('0x63')](Log[rt_0x9747('0x18')][_0x14ea47], Wish[rt_0x9747('0x6')])) Wish[rt_0x9747('0x6')] += RandInt(0x1, 0xf);
        } else {
          function _0x4885dc() {
            _0x367433[rt_0x9747('0x83')] = 0x78, _0x2e82a6[rt_0x9747('0x6')] = _0x334d7e[rt_0x9747('0x88')]() % 0xc ? _0x313d99[rt_0x9747('0x6')] : _0x21814d[rt_0x9747('0xa6')](_0x26523b[rt_0x9747('0x6')], -0xb);
            if (_0x2cabd9[rt_0x9747('0x6')] <= -0x37) _0x3c908e[rt_0x9747('0x6')] = 0x20;
            if (_0x21814d[rt_0x9747('0x20')](_0x4fceb9[rt_0x9747('0x6')], 0x15)) _0x4e6c9b[rt_0x9747('0x6')] = -0x21;
          }
        }
      } else {
      function _0x21ae09() {
        _0x5dd296[rt_0x9747('0x3e')] ? _0x49d00e[rt_0x9747('0x6')] = _0x21814d[rt_0x9747('0x1f')](_0x1a3875[rt_0x9747('0x88')](), 0x2) ? _0x20ced6[rt_0x9747('0x6')] : _0x417fdc(-0x37, -0x16) : _0x563222[rt_0x9747('0x6')] = _0x965c94[rt_0x9747('0x88')]() % 0x2 ? _0x4d1eb6[rt_0x9747('0x6')] : _0x1e4ee7(0x16, 0x37);
      }
    }
  } else Log[rt_0x9747('0x18')] = [];
  Wish[rt_0x9747('0x6')] = Normalize(Wish[rt_0x9747('0x6')]), Wish[rt_0x9747('0x60')] = _0x21814d[rt_0x9747('0x8')](Normalize, Wish[rt_0x9747('0x60')]), Wish[rt_0x9747('0x83')] = _0x21814d[rt_0x9747('0xc')](Normalize, Wish[rt_0x9747('0x83')]);
  if (Config[rt_0x9747('0x1')]) {
    if (rt_0x9747('0x9d') === rt_0x9747('0x71')) {
      function _0x1a7690() {
        _0x5c4d65[rt_0x9747('0x6a')] = !![], _0x27be25 = _0x5c419f[rt_0x9747('0x7c')] + _0x13fb3b(0.24, 0.48);
      }
    } else {
      const _0xe824a2 = GetPlayer(rt_0x9747('0x28'));
      if (!_0xe824a2 || _0x21814d[rt_0x9747('0x63')](_0xe824a2, -0x1)) return;
      const _0x593bfa = Config[rt_0x9747('0x27')][0x1],
        _0x8d0ade = Entity[rt_0x9747('0x30')](LocalPlayer[rt_0x9747('0x58')]),
        _0x5b9505 = CalcAngle(_0x8d0ade, Entity[rt_0x9747('0xa2')](_0xe824a2, 0x5)),
        _0x22a82c = [0x0, _0x21814d[rt_0x9747('0x76')](_0x21814d[rt_0x9747('0x50')](_0x5b9505[0x1] + 0x5a, 0xb4), Math['PI']), 0x0],
        _0x3b477c = [0x0, _0x21814d[rt_0x9747('0x26')](_0x21814d[rt_0x9747('0x50')](_0x21814d[rt_0x9747('0x9e')](_0x5b9505[0x1], 0x5a), 0xb4), Math['PI']), 0x0];
      var _0x52fd50 = atp(av(_0x22a82c), 0x32),
        _0x9728e5 = _0x21814d[rt_0x9747('0x38')](atp, _0x21814d[rt_0x9747('0x56')](av, _0x3b477c), 0x32),
        _0x3b09f1 = _0x21814d[rt_0x9747('0x91')](vat, _0x52fd50, _0x8d0ade),
        _0x6cc549 = vat(_0x9728e5, _0x8d0ade);
      const _0x2b86c7 = Trace[rt_0x9747('0x4e')](LocalPlayer[rt_0x9747('0x58')], _0x8d0ade, _0x3b09f1),
        _0x339a7d = Trace[rt_0x9747('0x4e')](LocalPlayer[rt_0x9747('0x58')], _0x8d0ade, _0x6cc549);
      _0x52fd50 = atp(av(_0x22a82c), 0x32 * _0x2b86c7[0x1]), _0x3b09f1 = vat(_0x52fd50, _0x8d0ade), _0x9728e5 = _0x21814d[rt_0x9747('0x7')](atp, _0x21814d[rt_0x9747('0x56')](av, _0x3b477c), 0x32 * _0x339a7d[0x1]), _0x6cc549 = vat(_0x9728e5, _0x8d0ade), tr_left = Trace[rt_0x9747('0x4e')](LocalPlayer[rt_0x9747('0x58')], _0x3b09f1, Entity[rt_0x9747('0xa2')](_0xe824a2, 0x5)), tr_right = Trace[rt_0x9747('0x4e')](LocalPlayer[rt_0x9747('0x58')], _0x6cc549, Entity[rt_0x9747('0xa2')](_0xe824a2, 0x5));
      if (tr_left[0x0] && !tr_right[0x0]) Wish[rt_0x9747('0x60')] = _0x593bfa;
      if (!tr_left[0x0] && tr_right[0x0]) Wish[rt_0x9747('0x60')] = -_0x593bfa;
      if (!tr_left[0x0] && !tr_right[0x0]) return;
    }
  }
}

function SetWishAngles() {
  if (!Config[rt_0x9747('0x35')]) return;
  AntiAim[rt_0x9747('0x73')](0x1), AntiAim[rt_0x9747('0x10')](Wish[rt_0x9747('0x6')]), AntiAim[rt_0x9747('0xa0')](Wish[rt_0x9747('0x60')]), AntiAim[rt_0x9747('0x5e')](Wish[rt_0x9747('0x83')]);
}

function CreateMoveRT01() {
  const _0x2a1df5 = {
    'BCCKE': function (_0x520d6c, _0x583e2d) {
      return _0x520d6c | _0x583e2d;
    },
    'QfIBk': function (_0x573a99, _0x1d6f71) {
      return _0x573a99 << _0x1d6f71;
    }
  };
  UserCMD[rt_0x9747('0x75')](_0x2a1df5[rt_0x9747('0x8b')](UserCMD[rt_0x9747('0x3f')](), _0x2a1df5[rt_0x9747('0x7e')](0x1, 0x16))), AdjustFakeLag(), AdjustAntiAim(), SetWishAngles();
}

function PlayerDeathRT01() {
  const _0x184bc0 = {
    'tTfKn': rt_0x9747('0x2e'),
    'sktvq': function (_0x5a94a4, _0x34bad4) {
      return _0x5a94a4 != _0x34bad4;
    }
  };
  if (!Config[rt_0x9747('0x35')] || !Config[rt_0x9747('0x1d')]) return;
  const _0x2adb35 = Event[rt_0x9747('0xa4')](rt_0x9747('0x44')),
    _0x458b0b = Event[rt_0x9747('0xa4')](_0x184bc0[rt_0x9747('0x87')]),
    _0x5c97d1 = Event[rt_0x9747('0xa4')](rt_0x9747('0x31')),
    _0x2873f5 = Entity[rt_0x9747('0x1e')](_0x2adb35),
    _0x4c7fcd = Entity[rt_0x9747('0x1e')](_0x458b0b);
  if (_0x4c7fcd == LocalPlayer[rt_0x9747('0x58')] || _0x184bc0[rt_0x9747('0xad')](_0x2873f5, LocalPlayer[rt_0x9747('0x58')])) return;
  Log[rt_0x9747('0x18')][rt_0x9747('0x9a')](Wish[rt_0x9747('0x6')]);
}

function UnloadRT01() {
  AntiAim[rt_0x9747('0x73')](0x0);
}
Cheat[rt_0x9747('0x7b')](rt_0x9747('0x49'), rt_0x9747('0x11')), Cheat[rt_0x9747('0x7b')](rt_0x9747('0x65'), rt_0x9747('0x67')), Cheat[rt_0x9747('0x7b')](rt_0x9747('0x7a'), rt_0x9747('0x2b'));

const Extras = UI['GetValue'](['Rage', 'Exploits', 'General', 'Options']);
var Once = ![];

function AutowallDamage() {
  const _0x14fd54 = {
    'CqIpb': function (_0x375d45, _0xf16532) {
      return _0x375d45 == _0xf16532;
    },
    'qzetb': function (_0x442f93, _0x4b9107) {
      return _0x442f93 == _0x4b9107;
    },
    'fdoYo': function (_0x326945, _0x1e5e8d) {
      return _0x326945(_0x1e5e8d);
    },
    'VPses': 'crosshair',
    'eYFaZ': function (_0x2f086f, _0x237ee9) {
      return _0x2f086f != _0x237ee9;
    },
    'EOzLe': 'g3sg1',
    'yKPSe': function (_0x443258, _0x4df2c7) {
      return _0x443258 === _0x4df2c7;
    },
    'RdWIG': 'ssg 08'
  };
  if (!Config['BOOL_EnableAutowallDamage'] || IsKeyHeld(Config['KEY_DamageOverride'])) return;
  const _0x40e507 = Entity['GetName'](Entity['GetWeapon'](LocalPlayer['Entity'])),
    _0x3b2bff = Ragebot['GetTarget']();
  if (_0x14fd54['CqIpb'](_0x3b2bff, 0x0) || _0x14fd54['qzetb'](_0x3b2bff, undefined)) _0x3b2bff = _0x14fd54['fdoYo'](GetPlayer, _0x14fd54['VPses']);
  const _0x15e2c0 = Entity['GetHitboxPosition'](_0x3b2bff, 0x2),
    _0x2cc836 = Entity['GetEyePosition'](LocalPlayer['Entity']),
    _0x3492ce = Trace['Bullet'](LocalPlayer['Entity'], _0x3b2bff, _0x2cc836, _0x15e2c0);
  if (!_0x3492ce) return;
  if (_0x14fd54['eYFaZ'](_0x3b2bff, 0x0) && _0x14fd54['eYFaZ'](_0x3b2bff, null) && _0x3b2bff != -0x1 && _0x3492ce[0x2] === ![]) {
    if (_0x40e507 === 'scar 20' || _0x40e507 === _0x14fd54['EOzLe']) Ragebot['ForceTargetMinimumDamage'](_0x3b2bff, Config['INT_AutoAutowallDamage'][0x1]);
    else {
      if (_0x14fd54['yKPSe'](_0x40e507, 'awp')) Ragebot['ForceTargetMinimumDamage'](_0x3b2bff, Config['INT_AWPAutowallDamage'][0x1]);
      else {
        if (_0x40e507 === _0x14fd54['RdWIG']) Ragebot['ForceTargetMinimumDamage'](_0x3b2bff, Config['INT_ScoutAutowallDamage'][0x1]);
        else return;
      }
    }
  }
}

function DamageOverride() {
  const _0x46cbbd = {
    'jxLDH': function (_0x3878f2, _0x3d2cdd) {
      return _0x3878f2(_0x3d2cdd);
    },
    'aQIFK': function (_0x223622, _0x411521) {
      return _0x223622 == _0x411521;
    }
  };
  if (!_0x46cbbd['jxLDH'](IsKeyHeld, Config['KEY_DamageOverride'])) return;
  var _0x5401fd = Ragebot['GetTarget']();
  if (_0x46cbbd['aQIFK'](_0x5401fd, -0x1) || _0x5401fd == 0x0) _0x5401fd = GetPlayer('distance');
  Ragebot['ForceTargetMinimumDamage'](_0x5401fd, Config['INT_DamageOverride'][0x1]);
}

function ForceSafetyOnExtremities() {
  if (!Config['BOOL_ForceSafetyOnExtremities']) return;
  Ragebot['ForceHitboxSafety'](0x9), Ragebot['ForceHitboxSafety'](0xa), Ragebot['ForceHitboxSafety'](0xb), Ragebot['ForceHitboxSafety'](0xc), Ragebot['ForceHitboxSafety'](0xd), Ragebot['ForceHitboxSafety'](0xe), Ragebot['ForceHitboxSafety'](0x10), Ragebot['ForceHitboxSafety'](0x12);
}

function AdaptiveDoubletap() {
  const _0x48b7e1 = {
    'NbcMS': 'scar 20',
    'FSxlo': 'm_nTickBase',
    'eqpux': function (_0x4b8269, _0x1663c7) {
      return _0x4b8269 * _0x1663c7;
    },
    'PEUHz': function (_0x418484, _0x580209) {
      return _0x418484 < _0x580209;
    },
    'vNQBK': 'CCSPlayer',
    'yQLHy': function (_0x547b35, _0x524036) {
      return _0x547b35 < _0x524036;
    },
    'CzgGS': function (_0x44c58e, _0x25a526) {
      return _0x44c58e == _0x25a526;
    },
    'NrFLM': function (_0x10df77, _0x1fc575) {
      return _0x10df77 == _0x1fc575;
    },
    'sPCqj': function (_0x502189, _0x2da023, _0x7d866e, _0x33b87d, _0x52a2e3) {
      return _0x502189(_0x2da023, _0x7d866e, _0x33b87d, _0x52a2e3);
    },
    'VIQdj': function (_0x3655dc, _0x2c899e) {
      return _0x3655dc >= _0x2c899e;
    },
    'SyecX': 'HOMDB',
    'GKhUn': 'KPSHa',
    'ciMhX': 'Options',
    'eccvZ': function (_0x211d1a, _0x4abdb3) {
      return _0x211d1a - _0x4abdb3;
    },
    'ZXROW': 'MatxB',
    'sRekN': 'rClHv',
    'EhSyq': 'Exploits'
  };
  if (!Config['BOOL_AdaptiveDoubletapType']) return;
  const _0xd3f992 = Ragebot['GetTarget']();
  if (_0x48b7e1['CzgGS'](_0xd3f992, 0x0) || _0x48b7e1['NrFLM'](_0xd3f992, -0x1)) return;
  const _0x5a8acc = Entity['GetRenderOrigin'](_0xd3f992),
    _0x515234 = _0x48b7e1['sPCqj'](Distance2D, LocalPlayer['Origin'][0x0], LocalPlayer['Origin'][0x1], _0x5a8acc[0x0], _0x5a8acc[0x1]);
  if (_0x48b7e1['VIQdj'](_0x515234, 0x41a)) {
    if (_0x48b7e1['SyecX'] === _0x48b7e1['GKhUn']) {
      function _0x49be1f() {
        _0x491ccc['DisableRecharge'](), _0x13a47d['Recharge']();
      }
    } else !Once && (UI['SetValue'](['Rage', 'Exploits', 'General', _0x48b7e1['ciMhX']], _0x48b7e1['eccvZ'](Extras, 0x1)), Once = !![]);
  } else {
    if ('ZjYBs' !== 'KoLbS') {
      if (Once) {
        if (_0x48b7e1['ZXROW'] === _0x48b7e1['sRekN']) {
          function _0x2d01a5() {
            const _0x22177f = _0x5aad3b['GetWeapon'](_0x1b6681['Entity']);
            if (_0x22177f == null) return ![];
            const _0x2801bb = _0xd2282c['GetName'](_0x22177f),
              _0x2c6438 = _0x2801bb == 'g3sg1' || _0x2801bb == _0x48b7e1['NbcMS'] || _0x2801bb == 'awp' ? !![] : ![];
            var _0x2c7bbe = _0x2bffe['GetProp'](_0x3c58c1['GetLocalPlayer'](), 'CCSPlayer', _0x48b7e1['FSxlo']),
              _0x26ccc6 = _0x48b7e1['eqpux'](_0x29f808['TickInterval'](), _0x2c7bbe - _0x5e24a5);
            if (_0x48b7e1['PEUHz'](_0x26ccc6, _0x500616['GetProp'](_0x5da39c['GetLocalPlayer'](), _0x48b7e1['vNQBK'], 'm_flNextAttack') - 0xea60)) return ![];
            if (_0x15768b['IsAlive'](_0x42911a['GetTarget']())) return ![];
            if (_0x48b7e1['yQLHy'](_0x26ccc6, _0xf6a215['GetProp'](_0x22177f, 'CBaseCombatWeapon', 'm_flNextPrimaryAttack') - (_0x2c6438 ? 0.19 : _0x83fe26['BOOL_RapidDoubletap'] ? 0x12c : 0.16))) return ![];
            return !![];
          }
        } else UI['SetValue'](['Rage', _0x48b7e1['EhSyq'], 'General', _0x48b7e1['ciMhX']], Extras), Once = ![];
      }
    } else {
      function _0x162dc9() {
        _0x5ec8d3['Tick'] = _0x10b4e9;
      }
    }
  }
}

function CanShift(_0x4cc73c) {
  const _0x4056e5 = {
    'nGHmk': function (_0x228afe, _0x485e5c) {
      return _0x228afe == _0x485e5c;
    },
    'SsvRY': function (_0x36c60c, _0x26bf02) {
      return _0x36c60c * _0x26bf02;
    },
    'kEDFq': function (_0x3f468f, _0x520e7b) {
      return _0x3f468f - _0x520e7b;
    },
    'TWTSD': 'm_flNextAttack'
  },
    _0x84ca81 = Entity['GetWeapon'](LocalPlayer['Entity']);
  if (_0x84ca81 == null) return ![];
  const _0x4ca15a = Entity['GetName'](_0x84ca81),
    _0x3f1c8a = _0x4056e5['nGHmk'](_0x4ca15a, 'g3sg1') || _0x4ca15a == 'scar 20' || _0x4056e5['nGHmk'](_0x4ca15a, 'awp') ? !![] : ![];
  var _0x34ad44 = Entity['GetProp'](Entity['GetLocalPlayer'](), 'CCSPlayer', 'm_nTickBase'),
    _0x3718a5 = _0x4056e5['SsvRY'](Globals['TickInterval'](), _0x4056e5['kEDFq'](_0x34ad44, _0x4cc73c));
  if (_0x3718a5 < Entity['GetProp'](Entity['GetLocalPlayer'](), 'CCSPlayer', _0x4056e5['TWTSD']) - 0xea60) return ![];
  if (Entity['IsAlive'](Ragebot['GetTarget']())) return ![];
  if (_0x3718a5 < _0x4056e5['kEDFq'](Entity['GetProp'](_0x84ca81, 'CBaseCombatWeapon', 'm_flNextPrimaryAttack'), _0x3f1c8a ? 0.19 : Config['BOOL_RapidDoubletap'] ? 0x12c : 0.16)) return ![];
  return !![];
}

function FastenDoubletap() {
  const _0x3bea16 = {
    'zcuWg': function (_0x5ee982, _0x49a2ed) {
      return _0x5ee982 != _0x49a2ed;
    }
  };
  if (!Config['BOOL_FasterDoubletap']) return;
  const _0x21eb45 = Exploit['GetCharge'](),
    _0x5b6cb9 = Config['INT_ShiftOverride'][0x1] - 0x2;
  CanShift(_0x5b6cb9) && _0x3bea16['zcuWg'](_0x21eb45, 0x1) && (Exploit['DisableRecharge'](), Exploit['Recharge']()), Exploit['OverrideMaxProcessTicks'](_0x5b6cb9), Exploit['OverrideTolerance'](0x0), Exploit['OverrideShift'](_0x5b6cb9);
}

function CreateMoveRT02() {
  const _0x4380d5 = {
    'RBEYx': function (_0x192e75) {
      return _0x192e75();
    }
  },
    _0x2d0f3d = '0|1|4|5|3|2'['split']('|');
  var _0x41153f = 0x0;
  while (!![]) {
    switch (_0x2d0f3d[_0x41153f++]) {
      case '0':
        if (!Config['BOOL_Ragebot']) return;
        continue;
      case '1':
        _0x4380d5['RBEYx'](AutowallDamage);
        continue;
      case '2':
        _0x4380d5['RBEYx'](FastenDoubletap);
        continue;
      case '3':
        AdaptiveDoubletap();
        continue;
      case '4':
        DamageOverride();
        continue;
      case '5':
        ForceSafetyOnExtremities();
        continue;
    }
    break;
  }
}

function UnloadRT02() {
  Exploit['EnableRecharge'](), Exploit['OverrideTolerance'](0x1), Exploit['OverrideShift'](0xc);
}

function DrawRT02() {
  const _0x533853 = {
    'Fvbhb': function (_0x3345c3, _0xccc1de) {
      return _0x3345c3 >= _0xccc1de;
    },
    'kkPzT': function (_0x46b221, _0x2529ca) {
      return _0x46b221 > _0x2529ca;
    },
    'vaJDY': function (_0x4c65ca, _0x50589e) {
      return _0x4c65ca * _0x50589e;
    },
    'uPovT': function (_0x2b9c31, _0x293ffe, _0x12d080) {
      return _0x2b9c31(_0x293ffe, _0x12d080);
    },
    'ndTNg': function (_0x3cec6e, _0x18e4df) {
      return _0x3cec6e + _0x18e4df;
    },
    'mohgb': function (_0x4a2b13, _0x5c3c28) {
      return _0x4a2b13 * _0x5c3c28;
    }
  };
  if (Config['DROP_RagebotLogs'][0x0] == 'None') return;
  for (var _0x556e39 = 0x0; _0x556e39 < Logs['length']; _0x556e39++) {
    const _0x12a47c = Logs[_0x556e39][0x0],
      _0x3ea625 = Logs[_0x556e39][0x1];
    if (_0x533853['Fvbhb'](_0x556e39, 0xa) || _0x533853['kkPzT'](RIN_UI['Time'], _0x3ea625 + 0xa)) Logs['shift']();
    Render['String'](0x6, _0x533853['vaJDY'](_0x556e39, 0xf) + 0x6, 0x0, '[rin.tools]', [0x0, 0x0, 0x0, 0xff], Font['Element']), Render['String'](0x5, _0x533853['ndTNg'](_0x556e39 * 0xf, 0x5), 0x0, '[rin.tools]', [0xff, 0x50, 0x50, 0xff], Font['Element']), Render['String'](89, _0x556e39 * 0xf + 0x6, 0x0, _0x12a47c, [0x0, 0x0, 0x0, 0xff], Font['Element']), Render['String'](88, _0x533853['mohgb'](_0x556e39, 0xf) + 0x5, 0x0, _0x12a47c, [0xff, 0xff, 0xff, 0xff], Font['Element']);
  }
}

function RagebotFireRT02() {
  const _0x1e970e = {
    'WUgvC': function (_0x34194a, _0x31898e) {
      return _0x34194a < _0x31898e;
    },
    'EJoAY': function (_0x3d7848, _0x6ac081) {
      return _0x3d7848 > _0x6ac081;
    },
    'BDlag': function (_0x108c41, _0x1bd6fb) {
      return _0x108c41 + _0x1bd6fb;
    },
    'MZtOc': function (_0x3c0bad, _0x5b5169, _0x2e85ad) {
      return _0x3c0bad(_0x5b5169, _0x2e85ad);
    },
    'FdOgp': function (_0x30f3f5, _0x21b454) {
      return _0x30f3f5 * _0x21b454;
    },
    'MyBfB': function (_0x43dd55, _0xc78a03, _0x3bdcea) {
      return _0x43dd55(_0xc78a03, _0x3bdcea);
    },
    'cpqrV': function (_0x5553bb, _0x54ec53) {
      return _0x5553bb + _0x54ec53;
    },
    'EKzLB': function (_0xb6fae1, _0xb74626) {
      return _0xb6fae1 * _0xb74626;
    },
    'bWPER': 'Rage',
    'mEXNj': 'Exploits',
    'VAxCJ': 'General',
    'nNodh': function (_0x2f418b, _0x45e63d) {
      return _0x2f418b == _0x45e63d;
    },
    'UMWrN': 'None',
    'pEkNp': 'hitbox',
    'daHjQ': 'm_angEyeAngles[0]',
    'pvNsQ': function (_0xe53e29, _0x53d715) {
      return _0xe53e29 - _0x53d715;
    },
    'Humko': function (_0x3066bb, _0x51af89) {
      return _0x3066bb > _0x51af89;
    },
    'vZCZS': function (_0x8de5ec, _0x34fdd5) {
      return _0x8de5ec === _0x34fdd5;
    },
    'PlfnG': 'IHKgW',
    'GJyxD': function (_0x3db04b, _0x5ec608) {
      return _0x3db04b != _0x5ec608;
    },
    'bYiGn': 'Keys'
  };
  if (_0x1e970e['nNodh'](Config['DROP_RagebotLogs'][0x0], _0x1e970e['UMWrN'])) return;
  ShotData['Entity'] = Event['GetInt']('target_index'), ShotData['Hitbox'] = GetHitboxFromIndex(Event['GetInt'](_0x1e970e['pEkNp'])), ShotData['Velocity'] = GetVelocity(LocalPlayer['Entity'])['toFixed'](0x0);
  const _0x4df1e9 = Entity['GetProp'](LocalPlayer['Entity'], 'CCSPlayer', _0x1e970e['daHjQ']),
    _0x4e3a2a = [_0x4df1e9[0x0]['toFixed'](0x0), _0x4df1e9[0x1]['toFixed'](0x0)];
  ShotData['Angles'] = _0x4e3a2a;
  const _0x2b47a3 = Globals['Tickcount']();
  if (_0x1e970e['pvNsQ'](_0x2b47a3, ShotData['Tick']) > 0x6 || _0x1e970e['Humko'](ShotData['Tick'], _0x2b47a3)) ShotData['Tick'] = _0x2b47a3;
  else {
    if (_0x1e970e['vZCZS']('GoAox', _0x1e970e['PlfnG'])) {
      function _0x235cb7() {
        if (_0x4dbafa['DROP_RagebotLogs'][0x0] == 'None') return;
        for (var _0x29cc91 = 0x0; _0x1e970e['WUgvC'](_0x29cc91, _0x51c36c['length']); _0x29cc91++) {
          const _0x1f010c = _0x3454f9[_0x29cc91][0x0],
            _0xc09d4d = _0x1ed084[_0x29cc91][0x1];
          if (_0x29cc91 >= 0xa || _0x1e970e['EJoAY'](_0x49338b['Time'], _0x1e970e['BDlag'](_0xc09d4d, 0xa))) _0x2a3b26['shift']();
          _0x39cdfb['String'](0x6, _0x1e970e['BDlag'](_0x29cc91 * 0xf, 0x6), 0x0, 'rin.tools', [0x0, 0x0, 0x0, 0xff], _0x175ac6['Element']), _0x3539bd['String'](0x5, _0x1e970e['FdOgp'](_0x29cc91, 0xf) + 0x5, 0x0, 'rin.tools', [0xff, 0x50, 0x50, 0xff], _0x19a6c9['Element']), _0x4aa622['String'](0x45, _0x1e970e['cpqrV'](_0x1e970e['EKzLB'](_0x29cc91, 0xf), 0x6), 0x0, _0x1f010c, [0x0, 0x0, 0x0, 0xff], _0x3ee695['Element']), _0x944f87['String'](0x44, _0x29cc91 * 0xf + 0x5, 0x0, _0x1f010c, [0xff, 0xff, 0xff, 0xff], _0x281437['Element']);
        }
      }
    } else {
      if (_0x1e970e['GJyxD'](UI['GetValue']([_0x1e970e['bWPER'], 'Exploits', _0x1e970e['bYiGn'], 'Double tap']), 0x0)) {
        if ('BZaVJ' === 'NwruB') {
          function _0x3d671f() {
            _0x83e7e1['SetValue']([_0x1e970e['bWPER'], _0x1e970e['mEXNj'], _0x1e970e['VAxCJ'], 'Options'], _0x2414a1), _0x22ced1 = ![];
          }
        } else {
          const _0x3016e0 = _0x2b47a3 - ShotData['Tick'];
          Logger('Doubletapped in ' + _0x3016e0 + 't', RIN_UI['Time']);
        }
      }
    }
  }
}

function PlayerHurtRT02() {
  const _0x140713 = {
    'ocamt': function (_0x4c111d, _0x373341) {
      return _0x4c111d == _0x373341;
    },
    'HLNeg': 'hitgroup',
    'SiOlb': 'dmg_health',
    'eXVqG': function (_0x40521f, _0x4194d5) {
      return _0x40521f + _0x4194d5;
    },
    'blvch': function (_0x41df1c, _0x38009d) {
      return _0x41df1c + _0x38009d;
    },
    'WAjPP': function (_0x254729, _0x199828) {
      return _0x254729 + _0x199828;
    },
    'ZkzvC': function (_0x1a2c17, _0x38cae4) {
      return _0x1a2c17(_0x38cae4);
    },
    'zaSJx': ' damage',
    'WpWeP': function (_0x529e2c, _0x4a31f4) {
      return _0x529e2c + _0x4a31f4;
    },
    'Glvte': function (_0x309ac9, _0x2378fd) {
      return _0x309ac9 + _0x2378fd;
    },
    'qaxdM': function (_0x6eb46d, _0x3e9c8c, _0x342cd6) {
      return _0x6eb46d(_0x3e9c8c, _0x342cd6);
    }
  };
  if (_0x140713['ocamt'](Config['DROP_RagebotLogs'][0x0], 'None')) return;
  const _0x25b4e5 = Event['GetInt']('userid'),
    _0x5bd940 = Entity['GetEntityFromUserID'](_0x25b4e5),
    _0x55af1d = Entity['GetName'](_0x5bd940),
    _0x9586e = Event['GetInt']('attacker'),
    _0x199078 = Entity['GetEntityFromUserID'](_0x9586e),
    _0x21be7c = Event['GetInt'](_0x140713['HLNeg']),
    _0x39e33b = Event['GetInt'](_0x140713['SiOlb']);
  if (_0x199078 == LocalPlayer['Entity']) {
    const _0x5a1349 = _0x140713['eXVqG'](_0x140713['blvch'](_0x140713['WAjPP']('Hit ', _0x55af1d), ' in ') + _0x140713['ZkzvC'](GetHitgroupFromIndex, _0x21be7c), ' for ') + _0x39e33b + _0x140713['zaSJx'],
      _0xf4e3ad = _0x140713['WpWeP'](_0x140713['Glvte'](_0x140713['Glvte'](_0x5a1349, ' - ShotData: ['), ShotData['Angles']) + ']', ' ') + ShotData['Velocity'] + 'u ' + ShotData['Hitbox'];
    _0x140713['qaxdM'](Logger, Config['DROP_RagebotLogs'][0x0] == 'Normal' ? _0x5a1349 : _0xf4e3ad, RIN_UI['Time']);
  }
}
Cheat['RegisterCallback']('Draw', 'DrawRT02'), Cheat['RegisterCallback']('CreateMove', 'CreateMoveRT02'), Cheat['RegisterCallback']('player_hurt', 'PlayerHurtRT02'), Cheat['RegisterCallback']('ragebot_fire', 'RagebotFireRT02'), Cheat['RegisterCallback']('Unload', 'UnloadRT02');
const rt_0x2c72 = ['jwtYb', 'IHMeH', 'wrwHv', 'efqWg', 'RegisterCallback', 'split', 'xMZWZ', 'String', 'uDpvl', 'Idmcy', 'FtaWe', 'ZBlrr', 'BOOL_Visuals', 'AGGAI', 'Crrqi', 'qxlgR', 'WuuDO', 'BUjPU', 'DROP_AntiAimArrows', 'gSnKu', 'TYuWv', 'Health', 'nEumx', 'ZvqNi', '3|2|0|5|4|1', 'nshMQ', 'GBPWg', 'OdSwd', 'ixcbB', 'kimcx', 'rwnEN', 'yJdmY', 'VrGGU', 'KEY_DamageOverride', 'Health Based', 'zcqjk', 'swdSP', 'yOvKq', 'ilSmR', 'ITXFt', 'oNcyA', 'toFixed', 'Choke', 'sFnrE', 'xboUa', 'INT_DamageOverride', 'Grgll', 'tCpfp', 'NLpNo', 'Charge', 'DrawRT03', 'BhtZO', 'Side', 'KLpVT', 'leVIp', 'PmCPO', 'Arrows', 'xqYar', 'GcKUL', 'Regular', 'ghosi', 'zBYtS', 'ChokedCommands', 'aWwuR', 'SFgKJ', 'IsAlive', 'iKGQx', 'RrajL', 'eceqL', '2|5|0|4|3|1', 'IeEOQ', 'RVgWc', 'yntdL', 'dtcVT', 'WKovF', 'ODKcu', 'Line', 'DYiPe', 'SJMLm', 'Element', 'tPPkg', 'niRCO', 'dFOyU', 'MjCVh', 'ygbyB', 'dSuTC', 'SLAHZ', 'VIIqj', 'CUzfN', 'AUPnZ', 'Entity', 'xZfFA', 'KVDVu', 'phcWV', 'Dgkka', 'VczfU', 'nInVx', 'YZDgW', 'lSRiL', 'nihtJ', 'euxQY', 'GetCharge', 'RNcFD', 'YFInJ', 'AhIan', 'GqpPk', 'ENnno', 'xiJSM', 'OfXnC', 'GetServerString', 'Quiek', 'Draw', 'vVbqu', 'dDhFH', 'cvyae', 'UiPna', 'BOOL_Indicators', 'iGWZP', 'WuZLj', 'IFsfk', 'Active', 'aNXxS', 'AdhPM', 'mXTvg', 'yKfJA', 'fCtjT', 'Polygon', 'uPzoV', 'vaIJD', 'None', 'XbHpT', 'RknoU', 'JSmzc', 'qtZKB', 'FMVrT', 'YWrQX'];
(function (_0x177733, _0x2c7210) {
  const _0x34dbf4 = function (_0x9f4180) {
    while (--_0x9f4180) {
      _0x177733['push'](_0x177733['shift']());
    }
  };
  _0x34dbf4(++_0x2c7210);
}(rt_0x2c72, 0xc6));
const rt_0x34db = function (_0x177733, _0x2c7210) {
  _0x177733 = _0x177733 - 0x0;
  var _0x34dbf4 = rt_0x2c72[_0x177733];
  return _0x34dbf4;
};

function DrawAntiAimArrows() {
  const _0xadb20e = {
    'qxlgR': function (_0x4359db, _0x3e6a28) {
      return _0x4359db == _0x3e6a28;
    },
    'eceqL': function (_0x744b7b, _0x2ca1a8) {
      return _0x744b7b + _0x2ca1a8;
    },
    'qtZKB': function (_0x727991, _0x3109f9) {
      return _0x727991 / _0x3109f9;
    },
    'cvyae': function (_0x246e71, _0x3ed777) {
      return _0x246e71 / _0x3ed777;
    },
    'BUjPU': function (_0x5ad39d, _0x35813e) {
      return _0x5ad39d + _0x35813e;
    },
    'nshMQ': function (_0x1aaa16, _0x2ae6dd) {
      return _0x1aaa16 == _0x2ae6dd;
    },
    'AdhPM': function (_0x159d7e, _0x1c8211) {
      return _0x159d7e - _0x1c8211;
    },
    'aWwuR': function (_0x20a407, _0x4e1543) {
      return _0x20a407 - _0x4e1543;
    },
    'IeEOQ': function (_0xc3fe24, _0x2e2867) {
      return _0xc3fe24 + _0x2e2867;
    },
    'JSmzc': function (_0x339669, _0xc04268) {
      return _0x339669 / _0xc04268;
    },
    'wrwHv': function (_0x1a4fcd, _0x156397) {
      return _0x1a4fcd - _0x156397;
    },
    'uDpvl': function (_0xec33bd, _0x454f5a) {
      return _0xec33bd + _0x454f5a;
    },
    'swdSP': rt_0x34db('0x43'),
    'xboUa': function (_0x332a70, _0x11c005) {
      return _0x332a70 === _0x11c005;
    },
    'sFnrE': rt_0x34db('0x6f'),
    'fCtjT': function (_0x160749, _0x282ca9) {
      return _0x160749 / _0x282ca9;
    },
    'NLpNo': function (_0x5dc38a, _0x71c9b8) {
      return _0x5dc38a - _0x71c9b8;
    },
    'xZfFA': function (_0x2c889b, _0x34b3ea) {
      return _0x2c889b / _0x34b3ea;
    },
    'phcWV': function (_0x11d805, _0x3f0575) {
      return _0x11d805 - _0x3f0575;
    },
    'VrGGU': function (_0x5c89c7, _0x5daf0e) {
      return _0x5c89c7 == _0x5daf0e;
    },
    'ODKcu': function (_0x2ad6dd, _0x39b95c) {
      return _0x2ad6dd - _0x39b95c;
    },
    'xiJSM': function (_0x901ef8, _0x545216) {
      return _0x901ef8 - _0x545216;
    },
    'dtcVT': function (_0x48ef5a, _0x12a505) {
      return _0x48ef5a - _0x12a505;
    },
    'IHMeH': function (_0x375c8b, _0x2713e0) {
      return _0x375c8b / _0x2713e0;
    },
    'ITXFt': function (_0x3eb5ce, _0x314027) {
      return _0x3eb5ce / _0x314027;
    },
    'iKGQx': function (_0x42061f, _0x48ba95) {
      return _0x42061f == _0x48ba95;
    },
    'VczfU': function (_0x1e7069, _0x4c9beb) {
      return _0x1e7069 == _0x4c9beb;
    },
    'IFsfk': function (_0x436580, _0x3d3d93) {
      return _0x436580 == _0x3d3d93;
    },
    'yntdL': function (_0x44002c, _0x3c891c) {
      return _0x44002c / _0x3c891c;
    },
    'yJdmY': function (_0xe6f917, _0x1a4f65) {
      return _0xe6f917 / _0x1a4f65;
    },
    'ZvqNi': function (_0x30de69, _0x5f481f) {
      return _0x30de69 + _0x5f481f;
    },
    'xqYar': function (_0x580e68, _0x4a4083) {
      return _0x580e68 / _0x4a4083;
    },
    'ygbyB': function (_0x8cf20f, _0x5a0431) {
      return _0x8cf20f / _0x5a0431;
    },
    'PmCPO': function (_0x510b5f, _0x36461a) {
      return _0x510b5f / _0x36461a;
    },
    'BhtZO': function (_0x4d1ecd, _0x4443fd) {
      return _0x4d1ecd / _0x4443fd;
    },
    'jwtYb': function (_0x25b01b, _0x55a560) {
      return _0x25b01b / _0x55a560;
    },
    'mXTvg': function (_0x3bc71c, _0x235975) {
      return _0x3bc71c + _0x235975;
    },
    'lSRiL': function (_0x57b780, _0x23b893) {
      return _0x57b780 / _0x23b893;
    },
    'Dgkka': function (_0x46fdc8, _0x1cb5fb) {
      return _0x46fdc8 - _0x1cb5fb;
    },
    'iGWZP': function (_0x49bdaa, _0x2eda1a) {
      return _0x49bdaa / _0x2eda1a;
    },
    'FtaWe': function (_0x467732, _0x162525) {
      return _0x467732 / _0x162525;
    },
    'uPzoV': function (_0x56ffc5, _0x5dbfcb) {
      return _0x56ffc5 == _0x5dbfcb;
    },
    'FMVrT': function (_0x4d6552, _0x16a9d2) {
      return _0x4d6552 + _0x16a9d2;
    },
    'CUzfN': function (_0x490aeb, _0x4f292d) {
      return _0x490aeb / _0x4f292d;
    },
    'AGGAI': function (_0x345414, _0x232399) {
      return _0x345414 / _0x232399;
    },
    'OdSwd': rt_0x34db('0x6c'),
    'efqWg': function (_0x5eb90b, _0x2ffd4f) {
      return _0x5eb90b * _0x2ffd4f;
    },
    'tPPkg': function (_0x46bad6, _0x3c29cc) {
      return _0x46bad6 * _0x3c29cc;
    },
    'RVgWc': function (_0xcb9698, _0x2ad616) {
      return _0xcb9698 / _0x2ad616;
    },
    'DYiPe': function (_0x7ed578, _0x3e0ef5) {
      return _0x7ed578 / _0x3e0ef5;
    },
    'ZBlrr': function (_0x1c41ae, _0x29e734) {
      return _0x1c41ae - _0x29e734;
    },
    'euxQY': function (_0xf4281, _0x41d264) {
      return _0xf4281 / _0x41d264;
    },
    'SJMLm': function (_0x5a87f7, _0x4a151c) {
      return _0x5a87f7 + _0x4a151c;
    },
    'nInVx': function (_0x14b41d, _0x33d3a4) {
      return _0x14b41d / _0x33d3a4;
    },
    'WKovF': function (_0x19b7c4, _0x2a28ea) {
      return _0x19b7c4 == _0x2a28ea;
    },
    'GcKUL': function (_0x34c04a, _0x5b7ede) {
      return _0x34c04a - _0x5b7ede;
    },
    'nEumx': function (_0x5ddcf3, _0x368377) {
      return _0x5ddcf3 / _0x368377;
    },
    'dDhFH': function (_0x44d1ea, _0x30cfee) {
      return _0x44d1ea + _0x30cfee;
    },
    'Quiek': function (_0x3cf274, _0xac0db1) {
      return _0x3cf274 / _0xac0db1;
    },
    'ghosi': function (_0x432cdf, _0x19b3c7) {
      return _0x432cdf / _0x19b3c7;
    },
    'vaIJD': function (_0xb088be, _0x8740f6) {
      return _0xb088be / _0x8740f6;
    },
    'xMZWZ': function (_0x258e34, _0x6c9002) {
      return _0x258e34 / _0x6c9002;
    },
    'nihtJ': function (_0x59ff9f, _0x217706) {
      return _0x59ff9f == _0x217706;
    },
    'Idmcy': function (_0x397dda, _0xe92940) {
      return _0x397dda / _0xe92940;
    },
    'YZDgW': function (_0x5fd7a, _0x513056) {
      return _0x5fd7a - _0x513056;
    },
    'vVbqu': function (_0xce7999, _0x2d2e83) {
      return _0xce7999 + _0x2d2e83;
    },
    'kimcx': function (_0x29bbbb, _0xba964f) {
      return _0x29bbbb / _0xba964f;
    },
    'ixcbB': function (_0xfc4130, _0x2b2d54) {
      return _0xfc4130 - _0x2b2d54;
    },
    'Grgll': function (_0x973cca, _0x18992d) {
      return _0x973cca / _0x18992d;
    },
    'dFOyU': function (_0x107a1e, _0x3641db) {
      return _0x107a1e + _0x3641db;
    },
    'zBYtS': function (_0x57568c, _0x1ad1ab) {
      return _0x57568c / _0x1ad1ab;
    },
    'oNcyA': function (_0x3db08f, _0x2a3580) {
      return _0x3db08f / _0x2a3580;
    },
    'WuZLj': function (_0x4e196f, _0x3cc045) {
      return _0x4e196f - _0x3cc045;
    },
    'niRCO': function (_0x4812a5, _0x5b9f3b) {
      return _0x4812a5 / _0x5b9f3b;
    },
    'GBPWg': function (_0x309008, _0x530497) {
      return _0x309008 / _0x530497;
    }
  };
  if (World[rt_0x34db('0x2f')]() == '' || !Entity[rt_0x34db('0x3')](LocalPlayer[rt_0x34db('0x1c')])) return;
  const _0x9b622e = Config[rt_0x34db('0x5c')][0x0],
    _0x250f90 = Wish[rt_0x34db('0x7e')];
  switch (_0x9b622e) {
    case _0xadb20e[rt_0x34db('0x6e')]:
      break;
    case rt_0x34db('0x85'): {
      if (_0xadb20e[rt_0x34db('0x76')](rt_0x34db('0x6f'), _0xadb20e[rt_0x34db('0x75')])) {
        Render[rt_0x34db('0x40')]([
          [_0xadb20e[rt_0x34db('0x3f')](Resolution['x'], 0x2) - 0x50, Resolution['y'] / 0x2],
          [_0xadb20e[rt_0x34db('0x7a')](Resolution['x'] / 0x2, 0x32), _0xadb20e[rt_0x34db('0x3f')](Resolution['y'], 0x2) - 0xa],
          [_0xadb20e[rt_0x34db('0x3f')](Resolution['x'], 0x2) - 0x32, _0xadb20e[rt_0x34db('0x52')](_0xadb20e[rt_0x34db('0x1d')](Resolution['y'], 0x2), 0xa)]
        ], [0x2, 0x2, 0x2, 0x6e]); {
          Render[rt_0x34db('0xe')](_0xadb20e[rt_0x34db('0x1f')](Resolution['x'] / 0x2, 0x32), _0xadb20e[rt_0x34db('0x1d')](Resolution['y'], 0x2) - 0xa, _0xadb20e[rt_0x34db('0x1f')](Resolution['x'] / 0x2, 0x32), _0xadb20e[rt_0x34db('0x52')](Resolution['y'] / 0x2, 0xa), _0xadb20e[rt_0x34db('0x6a')](_0x250f90, !![]) ? Color[rt_0x34db('0x82')] : [0x2, 0x2, 0x2, 0xff]), Render[rt_0x34db('0xe')](_0xadb20e[rt_0x34db('0xd')](Resolution['x'] / 0x2, 0x32), _0xadb20e[rt_0x34db('0xd')](Resolution['y'] / 0x2, 0xa), Resolution['x'] / 0x2 - 0x50, Resolution['y'] / 0x2, _0x250f90 == !![] ? Color[rt_0x34db('0x82')] : [0x2, 0x2, 0x2, 0xff]), Render[rt_0x34db('0xe')](_0xadb20e[rt_0x34db('0x2d')](_0xadb20e[rt_0x34db('0x1d')](Resolution['x'], 0x2), 0x32), Resolution['y'] / 0x2 + 0xa, _0xadb20e[rt_0x34db('0xb')](_0xadb20e[rt_0x34db('0x4b')](Resolution['x'], 0x2), 0x50), Resolution['y'] / 0x2, _0x250f90 == !![] ? Color[rt_0x34db('0x82')] : [0x2, 0x2, 0x2, 0xff]), Render[rt_0x34db('0xe')](Resolution['x'] / 0x2 - 0x31, Resolution['y'] / 0x2 - 0xb, Resolution['x'] / 0x2 - 0x31, _0xadb20e[rt_0x34db('0x71')](Resolution['y'], 0x2) + 0xb, _0xadb20e[rt_0x34db('0x4')](_0x250f90, !![]) ? Color[rt_0x34db('0x82')] : [0x2, 0x2, 0x2, 0xff]), Render[rt_0x34db('0xe')](_0xadb20e[rt_0x34db('0x71')](Resolution['x'], 0x2) - 0x31, Resolution['y'] / 0x2 - 0xb, _0xadb20e[rt_0x34db('0x71')](Resolution['x'], 0x2) - 0x52, Resolution['y'] / 0x2, _0xadb20e[rt_0x34db('0x21')](_0x250f90, !![]) ? Color[rt_0x34db('0x82')] : [0x2, 0x2, 0x2, 0xff]), Render[rt_0x34db('0xe')](Resolution['x'] / 0x2 - 0x31, Resolution['y'] / 0x2 + 0xb, _0xadb20e[rt_0x34db('0x71')](Resolution['x'], 0x2) - 0x52, Resolution['y'] / 0x2, _0xadb20e[rt_0x34db('0x39')](_0x250f90, !![]) ? Color[rt_0x34db('0x82')] : [0x2, 0x2, 0x2, 0xff]);
        }
        Render[rt_0x34db('0x40')]([
          [_0xadb20e[rt_0x34db('0xa')](Resolution['x'], 0x2) + 0x32, _0xadb20e[rt_0x34db('0x52')](_0xadb20e[rt_0x34db('0x69')](Resolution['y'], 0x2), 0xa)],
          [_0xadb20e[rt_0x34db('0x61')](Resolution['x'] / 0x2, 0x32), Resolution['y'] / 0x2 - 0xa],
          [Resolution['x'] / 0x2 + 0x50, _0xadb20e[rt_0x34db('0x83')](Resolution['y'], 0x2)]
        ], [0x2, 0x2, 0x2, 0x6e]); {
          const _0xe04440 = rt_0x34db('0x7')[rt_0x34db('0x4f')]('|');
          var _0x1d94d0 = 0x0;
          while (!![]) {
            switch (_0xe04440[_0x1d94d0++]) {
              case '0':
                Render[rt_0x34db('0xe')](Resolution['x'] / 0x2 + 0x32, Resolution['y'] / 0x2 + 0xa, _0xadb20e[rt_0x34db('0x61')](_0xadb20e[rt_0x34db('0x16')](Resolution['x'], 0x2), 0x51), Resolution['y'] / 0x2, _0x250f90 == ![] ? Color[rt_0x34db('0x82')] : [0x2, 0x2, 0x2, 0xff]);
                continue;
              case '1':
                Render[rt_0x34db('0xe')](_0xadb20e[rt_0x34db('0x61')](_0xadb20e[rt_0x34db('0x81')](Resolution['x'], 0x2), 0x31), _0xadb20e[rt_0x34db('0x7d')](Resolution['y'], 0x2) + 0xb, _0xadb20e[rt_0x34db('0x7d')](Resolution['x'], 0x2) + 0x52, Resolution['y'] / 0x2, _0x250f90 == ![] ? Color[rt_0x34db('0x82')] : [0x2, 0x2, 0x2, 0xff]);
                continue;
              case '2':
                Render[rt_0x34db('0xe')](_0xadb20e[rt_0x34db('0x4a')](Resolution['x'], 0x2) + 0x32, Resolution['y'] / 0x2 - 0xa, Resolution['x'] / 0x2 + 0x32, Resolution['y'] / 0x2 + 0xa, _0x250f90 == ![] ? Color[rt_0x34db('0x82')] : [0x2, 0x2, 0x2, 0xff]);
                continue;
              case '3':
                Render[rt_0x34db('0xe')](_0xadb20e[rt_0x34db('0x4a')](Resolution['x'], 0x2) + 0x31, Resolution['y'] / 0x2 - 0xb, _0xadb20e[rt_0x34db('0x3d')](_0xadb20e[rt_0x34db('0x24')](Resolution['x'], 0x2), 0x52), Resolution['y'] / 0x2, _0x250f90 == ![] ? Color[rt_0x34db('0x82')] : [0x2, 0x2, 0x2, 0xff]);
                continue;
              case '4':
                Render[rt_0x34db('0xe')](Resolution['x'] / 0x2 + 0x31, _0xadb20e[rt_0x34db('0x20')](_0xadb20e[rt_0x34db('0x37')](Resolution['y'], 0x2), 0xb), _0xadb20e[rt_0x34db('0x3d')](_0xadb20e[rt_0x34db('0x54')](Resolution['x'], 0x2), 0x31), Resolution['y'] / 0x2 + 0xb, _0xadb20e[rt_0x34db('0x41')](_0x250f90, ![]) ? Color[rt_0x34db('0x82')] : [0x2, 0x2, 0x2, 0xff]);
                continue;
              case '5':
                Render[rt_0x34db('0xe')](_0xadb20e[rt_0x34db('0x48')](_0xadb20e[rt_0x34db('0x1a')](Resolution['x'], 0x2), 0x32), Resolution['y'] / 0x2 - 0xa, _0xadb20e[rt_0x34db('0x48')](_0xadb20e[rt_0x34db('0x1a')](Resolution['x'], 0x2), 0x51), _0xadb20e[rt_0x34db('0x57')](Resolution['y'], 0x2), _0x250f90 == ![] ? Color[rt_0x34db('0x82')] : [0x2, 0x2, 0x2, 0xff]);
                continue;
            }
            break;
          }
        }
        break;
      } else {
        function _0x37a6bb() {
          const _0xeace77 = rt_0x34db('0x62')[rt_0x34db('0x4f')]('|');
          var _0x278d42 = 0x0;
          while (!![]) {
            switch (_0xeace77[_0x278d42++]) {
              case '0':
                _0x29237c[rt_0x34db('0xe')](_0x17159b['x'] / 0x2 + 0x32, _0xebc673['y'] / 0x2 + 0xa, _0x2cd66d['x'] / 0x2 + 0x50, _0x50a0ea['y'] / 0x2, _0xadb20e[rt_0x34db('0x59')](_0x2af1a7, ![]) ? _0x1699b4 : [0x2, 0x2, 0x2, 0xff]);
                continue;
              case '1':
                _0x105abe[rt_0x34db('0xe')](_0xadb20e[rt_0x34db('0x6')](_0xadb20e[rt_0x34db('0x47')](_0x368011['x'], 0x2), 0x31), _0xadb20e[rt_0x34db('0x34')](_0x3b6f3f['y'], 0x2) + 0xb, _0xadb20e[rt_0x34db('0x5b')](_0x5f3d6c['x'] / 0x2, 0x52), _0xadb20e[rt_0x34db('0x34')](_0x2ad74f['y'], 0x2), _0xadb20e[rt_0x34db('0x63')](_0x549608, ![]) ? _0x21fb56 : [0x2, 0x2, 0x2, 0xff]);
                continue;
              case '2':
                _0x8f7729[rt_0x34db('0xe')](_0x40f89b['x'] / 0x2 + 0x32, _0xadb20e[rt_0x34db('0x3c')](_0x536202['y'] / 0x2, 0xa), _0x4dddcc['x'] / 0x2 + 0x50, _0x2bc79e['y'] / 0x2, _0xcc5f43 == ![] ? _0x537b6a : [0x2, 0x2, 0x2, 0xff]);
                continue;
              case '3':
                _0x12f684[rt_0x34db('0xe')](_0xadb20e[rt_0x34db('0x34')](_0x23d3fa['x'], 0x2) + 0x32, _0xadb20e[rt_0x34db('0x1')](_0x5e98da['y'] / 0x2, 0xa), _0xadb20e[rt_0x34db('0x34')](_0x3372ba['x'], 0x2) + 0x32, _0xadb20e[rt_0x34db('0x8')](_0x32b180['y'] / 0x2, 0xa), _0xadb20e[rt_0x34db('0x63')](_0x455aa2, ![]) ? _0x412efc : [0x2, 0x2, 0x2, 0xff]);
                continue;
              case '4':
                _0x17cc66[rt_0x34db('0xe')](_0xadb20e[rt_0x34db('0x46')](_0x1129c8['x'], 0x2) + 0x31, _0xadb20e[rt_0x34db('0x4c')](_0xadb20e[rt_0x34db('0x46')](_0x3a1538['y'], 0x2), 0xb), _0xadb20e[rt_0x34db('0x52')](_0x5362cf['x'] / 0x2, 0x52), _0xadb20e[rt_0x34db('0x46')](_0x8b9316['y'], 0x2), _0x24e524 == ![] ? _0x51bd9a : [0x2, 0x2, 0x2, 0xff]);
                continue;
              case '5':
                _0x2f0195[rt_0x34db('0xe')](_0x1d4b63['x'] / 0x2 + 0x31, _0xadb20e[rt_0x34db('0x46')](_0x3794b6['y'], 0x2) - 0xb, _0xadb20e[rt_0x34db('0x52')](_0x4f7186['x'] / 0x2, 0x31), _0xadb20e[rt_0x34db('0x52')](_0x51a28b['y'] / 0x2, 0xb), _0xe00e5a == ![] ? _0x59ca47 : [0x2, 0x2, 0x2, 0xff]);
                continue;
            }
            break;
          }
        }
      }
    }
    case _0xadb20e[rt_0x34db('0x65')]: {
      const _0x2dfd75 = [0x82 - _0xadb20e[rt_0x34db('0x4d')](LocalPlayer[rt_0x34db('0x5f')], 1.3), _0xadb20e[rt_0x34db('0x12')](LocalPlayer[rt_0x34db('0x5f')], 2.55), 0xa, 0xff];
      Render[rt_0x34db('0x40')]([
        [_0xadb20e[rt_0x34db('0x20')](_0xadb20e[rt_0x34db('0x57')](Resolution['x'], 0x2), 0x50), _0xadb20e[rt_0x34db('0x9')](Resolution['y'], 0x2)],
        [_0xadb20e[rt_0x34db('0xf')](Resolution['x'], 0x2) - 0x32, _0xadb20e[rt_0x34db('0x20')](Resolution['y'] / 0x2, 0xa)],
        [_0xadb20e[rt_0x34db('0x55')](_0xadb20e[rt_0x34db('0x26')](Resolution['x'], 0x2), 0x32), _0xadb20e[rt_0x34db('0x48')](Resolution['y'] / 0x2, 0xa)]
      ], [0x2, 0x2, 0x2, 0x6e]); {
        Render[rt_0x34db('0xe')](Resolution['x'] / 0x2 - 0x32, Resolution['y'] / 0x2 - 0xa, _0xadb20e[rt_0x34db('0x26')](Resolution['x'], 0x2) - 0x32, _0xadb20e[rt_0x34db('0x10')](Resolution['y'] / 0x2, 0xa), _0x250f90 == !![] ? _0x2dfd75 : [0x2, 0x2, 0x2, 0xff]), Render[rt_0x34db('0xe')](Resolution['x'] / 0x2 - 0x32, _0xadb20e[rt_0x34db('0x26')](Resolution['y'], 0x2) - 0xa, _0xadb20e[rt_0x34db('0x26')](Resolution['x'], 0x2) - 0x50, _0xadb20e[rt_0x34db('0x22')](Resolution['y'], 0x2), _0x250f90 == !![] ? _0x2dfd75 : [0x2, 0x2, 0x2, 0xff]), Render[rt_0x34db('0xe')](_0xadb20e[rt_0x34db('0x22')](Resolution['x'], 0x2) - 0x32, _0xadb20e[rt_0x34db('0x10')](_0xadb20e[rt_0x34db('0x22')](Resolution['y'], 0x2), 0xa), Resolution['x'] / 0x2 - 0x50, Resolution['y'] / 0x2, _0xadb20e[rt_0x34db('0xc')](_0x250f90, !![]) ? _0x2dfd75 : [0x2, 0x2, 0x2, 0xff]), Render[rt_0x34db('0xe')](_0xadb20e[rt_0x34db('0x55')](_0xadb20e[rt_0x34db('0x22')](Resolution['x'], 0x2), 0x31), _0xadb20e[rt_0x34db('0x84')](_0xadb20e[rt_0x34db('0x60')](Resolution['y'], 0x2), 0xb), Resolution['x'] / 0x2 - 0x31, _0xadb20e[rt_0x34db('0x33')](_0xadb20e[rt_0x34db('0x30')](Resolution['y'], 0x2), 0xb), _0xadb20e[rt_0x34db('0xc')](_0x250f90, !![]) ? _0x2dfd75 : [0x2, 0x2, 0x2, 0xff]), Render[rt_0x34db('0xe')](_0xadb20e[rt_0x34db('0x86')](Resolution['x'], 0x2) - 0x31, _0xadb20e[rt_0x34db('0x42')](Resolution['y'], 0x2) - 0xb, _0xadb20e[rt_0x34db('0x50')](Resolution['x'], 0x2) - 0x52, Resolution['y'] / 0x2, _0xadb20e[rt_0x34db('0x25')](_0x250f90, !![]) ? _0x2dfd75 : [0x2, 0x2, 0x2, 0xff]), Render[rt_0x34db('0xe')](Resolution['x'] / 0x2 - 0x31, _0xadb20e[rt_0x34db('0x53')](Resolution['y'], 0x2) + 0xb, _0xadb20e[rt_0x34db('0x53')](Resolution['x'], 0x2) - 0x52, _0xadb20e[rt_0x34db('0x53')](Resolution['y'], 0x2), _0x250f90 == !![] ? _0x2dfd75 : [0x2, 0x2, 0x2, 0xff]);
      }
      Render[rt_0x34db('0x40')]([
        [_0xadb20e[rt_0x34db('0x33')](Resolution['x'] / 0x2, 0x32), _0xadb20e[rt_0x34db('0x33')](Resolution['y'] / 0x2, 0xa)],
        [_0xadb20e[rt_0x34db('0x33')](Resolution['x'] / 0x2, 0x32), Resolution['y'] / 0x2 - 0xa],
        [Resolution['x'] / 0x2 + 0x50, Resolution['y'] / 0x2]
      ], [0x2, 0x2, 0x2, 0x6e]); {
        Render[rt_0x34db('0xe')](_0xadb20e[rt_0x34db('0x53')](Resolution['x'], 0x2) + 0x32, _0xadb20e[rt_0x34db('0x23')](Resolution['y'] / 0x2, 0xa), _0xadb20e[rt_0x34db('0x33')](_0xadb20e[rt_0x34db('0x53')](Resolution['x'], 0x2), 0x32), Resolution['y'] / 0x2 + 0xa, _0x250f90 == ![] ? _0x2dfd75 : [0x2, 0x2, 0x2, 0xff]), Render[rt_0x34db('0xe')](_0xadb20e[rt_0x34db('0x32')](_0xadb20e[rt_0x34db('0x67')](Resolution['x'], 0x2), 0x32), _0xadb20e[rt_0x34db('0x66')](Resolution['y'] / 0x2, 0xa), _0xadb20e[rt_0x34db('0x78')](Resolution['x'], 0x2) + 0x50, _0xadb20e[rt_0x34db('0x78')](Resolution['y'], 0x2), _0x250f90 == ![] ? _0x2dfd75 : [0x2, 0x2, 0x2, 0xff]), Render[rt_0x34db('0xe')](_0xadb20e[rt_0x34db('0x14')](Resolution['x'] / 0x2, 0x32), Resolution['y'] / 0x2 + 0xa, _0xadb20e[rt_0x34db('0x87')](Resolution['x'], 0x2) + 0x50, _0xadb20e[rt_0x34db('0x72')](Resolution['y'], 0x2), _0x250f90 == ![] ? _0x2dfd75 : [0x2, 0x2, 0x2, 0xff]), Render[rt_0x34db('0xe')](_0xadb20e[rt_0x34db('0x14')](Resolution['x'] / 0x2, 0x31), _0xadb20e[rt_0x34db('0x38')](Resolution['y'] / 0x2, 0xb), _0xadb20e[rt_0x34db('0x13')](Resolution['x'], 0x2) + 0x31, Resolution['y'] / 0x2 + 0xb, _0xadb20e[rt_0x34db('0x25')](_0x250f90, ![]) ? _0x2dfd75 : [0x2, 0x2, 0x2, 0xff]), Render[rt_0x34db('0xe')](_0xadb20e[rt_0x34db('0x14')](_0xadb20e[rt_0x34db('0x64')](Resolution['x'], 0x2), 0x31), _0xadb20e[rt_0x34db('0x38')](Resolution['y'] / 0x2, 0xb), _0xadb20e[rt_0x34db('0x64')](Resolution['x'], 0x2) + 0x52, Resolution['y'] / 0x2, _0x250f90 == ![] ? _0x2dfd75 : [0x2, 0x2, 0x2, 0xff]), Render[rt_0x34db('0xe')](Resolution['x'] / 0x2 + 0x31, Resolution['y'] / 0x2 + 0xb, _0xadb20e[rt_0x34db('0x64')](Resolution['x'], 0x2) + 0x52, _0xadb20e[rt_0x34db('0x64')](Resolution['y'], 0x2), _0x250f90 == ![] ? _0x2dfd75 : [0x2, 0x2, 0x2, 0xff]);
      }
    }
  }
}

function HandleIndicators() {
  const _0x4f23b1 = {
    'zcqjk': function (_0x5ba6f9, _0x3261f4, _0x486b51, _0x52ae59, _0x2195b6, _0x46d110, _0x4808e8) {
      return _0x5ba6f9(_0x3261f4, _0x486b51, _0x52ae59, _0x2195b6, _0x46d110, _0x4808e8);
    },
    'AhIan': function (_0x5e7365, _0x2136c3) {
      return _0x5e7365 + _0x2136c3;
    },
    'tCpfp': function (_0x1044b4, _0x110f3d, _0xd568ca, _0x576ec8, _0x26aa1f, _0x59fcc5, _0x4ac53b) {
      return _0x1044b4(_0x110f3d, _0xd568ca, _0x576ec8, _0x26aa1f, _0x59fcc5, _0x4ac53b);
    },
    'RknoU': rt_0x34db('0x7b'),
    'OfXnC': function (_0x278fed, _0x1d26e1) {
      return _0x278fed(_0x1d26e1);
    },
    'VIIqj': function (_0x2d5477, _0x12dee9) {
      return _0x2d5477 / _0x12dee9;
    },
    'YWrQX': function (_0x327652, _0xd3bb40) {
      return _0x327652 / _0xd3bb40;
    },
    'YFInJ': function (_0x29503f, _0x2628ee) {
      return _0x29503f / _0x2628ee;
    },
    'MjCVh': function (_0x5176c2, _0x54987e) {
      return _0x5176c2 / _0x54987e;
    },
    'UiPna': function (_0x5534c6, _0x26e6f0) {
      return _0x5534c6 / _0x26e6f0;
    },
    'SFgKJ': function (_0x44e5f8, _0x2c9ab4) {
      return _0x44e5f8 == _0x2c9ab4;
    },
    'KLpVT': function (_0x57865a, _0x2a9a3d) {
      return _0x57865a - _0x2a9a3d;
    },
    'KVDVu': function (_0x9db9cb, _0x321df0) {
      return _0x9db9cb / _0x321df0;
    },
    'XbHpT': function (_0x11bef9, _0x1ed872) {
      return _0x11bef9 == _0x1ed872;
    },
    'TYuWv': function (_0x1e09a5, _0x3bb847) {
      return _0x1e09a5 + _0x3bb847;
    },
    'gSnKu': function (_0x2d84fd, _0x1c220c) {
      return _0x2d84fd - _0x1c220c;
    },
    'dSuTC': function (_0x170e5f, _0x266c1a) {
      return _0x170e5f / _0x266c1a;
    },
    'ENnno': function (_0x15efcb, _0x7845d4) {
      return _0x15efcb !== _0x7845d4;
    },
    'AUPnZ': rt_0x34db('0x58'),
    'RNcFD': function (_0x5647cc, _0x1d75cd) {
      return _0x5647cc != _0x1d75cd;
    },
    'yKfJA': function (_0x1d2ee6, _0x475051, _0x2853e7, _0x51710c, _0x1ea845, _0x572898, _0x211823) {
      return _0x1d2ee6(_0x475051, _0x2853e7, _0x51710c, _0x1ea845, _0x572898, _0x211823);
    },
    'GqpPk': rt_0x34db('0x74'),
    'ilSmR': function (_0x3b4589, _0x4bdfe9) {
      return _0x3b4589 + _0x4bdfe9;
    },
    'RrajL': rt_0x34db('0x18'),
    'rwnEN': function (_0x26853d, _0x206bf3) {
      return _0x26853d / _0x206bf3;
    },
    'leVIp': function (_0x4850a2, _0x2c865b) {
      return _0x4850a2 + _0x2c865b;
    }
  };
  if (Config[rt_0x34db('0x36')]) {
    if (_0x4f23b1[rt_0x34db('0x2c')](rt_0x34db('0x58'), _0x4f23b1[rt_0x34db('0x1b')])) {
      function _0x3db77b() {
        _0x4f23b1[rt_0x34db('0x6d')](_0xbe50ac, _0x3eb4ae['x'] + 0xe, _0x4f23b1[rt_0x34db('0x2a')](_0x23b075['y'], 0x1f), rt_0x34db('0x74'), _0x311e20[rt_0x34db('0x0')](), 0xe, 't'), _0x4f23b1[rt_0x34db('0x79')](_0x544b91, _0x4f23b1[rt_0x34db('0x2a')](_0x904247['x'], 0xe), _0x35a255['y'] + 0x42, _0x4f23b1[rt_0x34db('0x45')], (_0x9ace57[rt_0x34db('0x27')]() * 0x64)[rt_0x34db('0x73')](0x0), 0x64, '%'), _0x4f23b1[rt_0x34db('0x2e')](_0x5e8363, _0x4ad6f5[rt_0x34db('0x6b')]) && (_0x59ba3a[rt_0x34db('0x51')](_0x4f23b1[rt_0x34db('0x2a')](_0x270070['x'] / 0x2, 0x30), _0x4f23b1[rt_0x34db('0x2a')](_0x4f23b1[rt_0x34db('0x19')](_0xb24559['y'], 0x2), 0x10), 0x0, _0x5de4f9[rt_0x34db('0x77')][0x1] + 'md', [0x0, 0x0, 0x0, 0xff], _0x8e6d89[rt_0x34db('0x11')]), _0x1ab739[rt_0x34db('0x51')](_0x2e274e['x'] / 0x2 + 0x2f, _0x4f23b1[rt_0x34db('0x49')](_0xd8ad3b['y'], 0x2) + 0xf, 0x0, _0x17a7f7[rt_0x34db('0x77')][0x1] + 'md', _0x557bf3[rt_0x34db('0x3a')], _0x4b1200[rt_0x34db('0x11')]));
      }
    } else {
      CreateSubWindow(SubWindow['x'], SubWindow['y'], 0xc8, 0x5d, undefined);
      if (_0x4f23b1[rt_0x34db('0x28')](World[rt_0x34db('0x2f')](), '') && Entity[rt_0x34db('0x3')](LocalPlayer[rt_0x34db('0x1c')])) {
        _0x4f23b1[rt_0x34db('0x3e')](AddIndicator, SubWindow['x'] + 0xe, SubWindow['y'] + 0x1f, _0x4f23b1[rt_0x34db('0x2b')], Globals[rt_0x34db('0x0')](), 0xe, 't'), _0x4f23b1[rt_0x34db('0x3e')](AddIndicator, SubWindow['x'] + 0xe, _0x4f23b1[rt_0x34db('0x70')](SubWindow['y'], 0x42), rt_0x34db('0x7b'), (Exploit[rt_0x34db('0x27')]() * 0x64)[rt_0x34db('0x73')](0x0), 0x64, '%');
        if (IsKeyHeld(Config[rt_0x34db('0x6b')])) {
          if (rt_0x34db('0x5a') === _0x4f23b1[rt_0x34db('0x5')]) {
            function _0x422db4() {
              _0x473d95[rt_0x34db('0xe')](_0x4f23b1[rt_0x34db('0x2a')](_0x4f23b1[rt_0x34db('0x29')](_0x14faf3['x'], 0x2), 0x32), _0x4f23b1[rt_0x34db('0x15')](_0x59c24d['y'], 0x2) - 0xa, _0x4f23b1[rt_0x34db('0x35')](_0x339478['x'], 0x2) + 0x32, _0x27a89f['y'] / 0x2 + 0xa, _0x4f23b1[rt_0x34db('0x2')](_0xad2b0e, ![]) ? _0x50fa4a[rt_0x34db('0x82')] : [0x2, 0x2, 0x2, 0xff]), _0x5f494b[rt_0x34db('0xe')](_0xe41d7e['x'] / 0x2 + 0x32, _0x4f23b1[rt_0x34db('0x7f')](_0x298e65['y'] / 0x2, 0xa), _0x4f23b1[rt_0x34db('0x1e')](_0xdf1944['x'], 0x2) + 0x51, _0xe5b569['y'] / 0x2, _0x4f23b1[rt_0x34db('0x44')](_0x9e699e, ![]) ? _0x565614[rt_0x34db('0x82')] : [0x2, 0x2, 0x2, 0xff]), _0x94d8b9[rt_0x34db('0xe')](_0xb06453['x'] / 0x2 + 0x32, _0x4f23b1[rt_0x34db('0x5e')](_0x4f23b1[rt_0x34db('0x1e')](_0x5e4f5b['y'], 0x2), 0xa), _0x4f23b1[rt_0x34db('0x5e')](_0x2359a5['x'] / 0x2, 0x51), _0x15d523['y'] / 0x2, _0x1025d5 == ![] ? _0x3b719b[rt_0x34db('0x82')] : [0x2, 0x2, 0x2, 0xff]), _0x5a93dc[rt_0x34db('0xe')](_0x4f23b1[rt_0x34db('0x1e')](_0x3b96d4['x'], 0x2) + 0x31, _0x4f23b1[rt_0x34db('0x5d')](_0x4f23b1[rt_0x34db('0x1e')](_0xfd4a7['y'], 0x2), 0xb), _0x4f23b1[rt_0x34db('0x5e')](_0x4f23b1[rt_0x34db('0x1e')](_0x3800aa['x'], 0x2), 0x31), _0x4f23b1[rt_0x34db('0x17')](_0x2f92a0['y'], 0x2) + 0xb, _0x29365f == ![] ? _0x29cbc2[rt_0x34db('0x82')] : [0x2, 0x2, 0x2, 0xff]), _0x415c25[rt_0x34db('0xe')](_0x4f23b1[rt_0x34db('0x5e')](_0x543a68['x'] / 0x2, 0x31), _0x20d552['y'] / 0x2 - 0xb, _0x4f23b1[rt_0x34db('0x5e')](_0x3486be['x'] / 0x2, 0x52), _0x4c3bc5['y'] / 0x2, _0x4f23b1[rt_0x34db('0x44')](_0x17af1f, ![]) ? _0x139277[rt_0x34db('0x82')] : [0x2, 0x2, 0x2, 0xff]), _0x5abfab[rt_0x34db('0xe')](_0x4f23b1[rt_0x34db('0x5e')](_0x4f23b1[rt_0x34db('0x17')](_0x12cf2e['x'], 0x2), 0x31), _0x4f23b1[rt_0x34db('0x17')](_0x4224b1['y'], 0x2) + 0xb, _0x4f23b1[rt_0x34db('0x5e')](_0x305d0f['x'] / 0x2, 0x52), _0x4f23b1[rt_0x34db('0x17')](_0x5482b5['y'], 0x2), _0x2ccca4 == ![] ? _0x45d8c9[rt_0x34db('0x82')] : [0x2, 0x2, 0x2, 0xff]);
            }
          } else Render[rt_0x34db('0x51')](_0x4f23b1[rt_0x34db('0x70')](Resolution['x'] / 0x2, 0x30), _0x4f23b1[rt_0x34db('0x70')](_0x4f23b1[rt_0x34db('0x17')](Resolution['y'], 0x2), 0x10), 0x0, Config[rt_0x34db('0x77')][0x1] + 'md', [0x0, 0x0, 0x0, 0xff], Font[rt_0x34db('0x11')]), Render[rt_0x34db('0x51')](_0x4f23b1[rt_0x34db('0x70')](_0x4f23b1[rt_0x34db('0x68')](Resolution['x'], 0x2), 0x2f), _0x4f23b1[rt_0x34db('0x80')](Resolution['y'] / 0x2, 0xf), 0x0, Config[rt_0x34db('0x77')][0x1] + 'md', Color[rt_0x34db('0x3a')], Font[rt_0x34db('0x11')]);
        }
      }
    }
  }
};

function DrawRT03() {
  const _0x503e92 = {
    'aNXxS': function (_0x23dbaf) {
      return _0x23dbaf();
    }
  };
  if (!Config[rt_0x34db('0x56')]) return;
  _0x503e92[rt_0x34db('0x3b')](DrawAntiAimArrows), HandleIndicators();
}
Cheat[rt_0x34db('0x4e')](rt_0x34db('0x31'), rt_0x34db('0x7c'));
Render.AddFont = function(name, size, _) {
  if (name.indexOf('.ttf') === -1) name = name + '.ttf';

  return Render.GetFont(name, size, true);
}