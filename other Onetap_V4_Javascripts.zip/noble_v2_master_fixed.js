const _0x3e2b = [
    "Dmodqa==",
    "bmoYW5tdUeGcBSkl",
    "WQuDW6TnDanBWR8=",
    "W47dK8kgnx/cM0q=",
    "f8k+W44zW7NcSSkatSkbdwtdIgZdLMpdK8oVCSoPWO7dUSkJd8oYBLfaWQWG",
    "W43cGhFcTq==",
    "WOBcSSohlge=",
    "wmoosSkxmmkSrmkVc1nPeW==",
    "W4JdKSkwixxcLfZcL8oGW6e=",
    "W7pcNvSpWR8=",
    "W5XopbCl",
    "yCo1W67dLwdcKCkfkZbXBW==",
    "WO9aWRfpW6e=",
    "W7tcLmoDW6JdGKFdV8kPr8kFttu=",
    "uJTdW69O",
    "gh5AWO3cIq==",
    "fCoQbMfFWOr1iCkBWRS=",
    "WRJdNSkuW4ldJhVdRmoBCMKJ",
    "WQtcNbpdRSocmtyyohCHCSo2fCoBWOm=",
    "W5yTFCkgFeOimq==",
    "kCkSW5zYxx3dIq==",
    "W6/cIh/cSGne",
    "v8kqxmoY",
    "W6NcGhtcGW5bW5bkW5nbz10=",
    "nCo2bW==",
    "ACobACkYqxunWR8=",
    "nSovW7zCCLJdR1jNWQHKW7KDW4VcOLe1W41ICCo1k2q2W404W4lcNbLGW5zHzG==",
    "d8oEah/cRd3cKCoYxMncWRjMW71c",
    "W4ZdN8kheMq=",
    "a8kKW5uuW6K=",
    "W69NWPddLe7dUSkM",
    "WOaYCb0+W54fW6u=",
    "igT6WOa=",
    "WOZdUGStWOKIvW==",
    "W7/cUCo4W50=",
    "WO/cJbZcImkO",
    "WQpdRSkTW6tcHN4/W6xdMxVcM8oLCCoYWRW9W61lWQpcUmk/W5xdIcfA",
    "jwhcU8oPwSoYoSkcWRVdNNDOW7X6aG==",
    "WQJdUGGW",
    "rqSEkMHzzSk/",
    "W7P5sYf3WPxdNCose8oPd1e=",
    "nSkNW48yW6ZcTW==",
    "WPO5yaWVW78e",
    "WPe+yW==",
    "aeedWRjzWOGVWOlcQJ7cQXTocG==",
    "BJj5kMpcM8op",
    "gCkAW4ThyL3dPbu=",
    "W5JcLL4gWRpdRSk2",
    "WOWEnSodj2lcMZJdKMal",
    "rCo/W6JdJhtcMSkmfZ13ECkuWP8=",
    "q8oDW5ddTYldM2O4smkK",
    "ltxcP8oVvSo5",
    "WOOUbq==",
    "W6RcKxZcVaDC",
    "CvldGxS=",
    "eItcTmoO",
    "gdpcSmoJs8oQpSomWOlcL31G",
    "mSoxwq7dU8ogWQFcPG==",
    "deGvW7bzWPC=",
    "lSkDW71sza==",
    "pCoGfxC=",
    "kSkhW7LxEvhdPazOW61QW6q=",
    "WQBcVmk6W7ldHq==",
    "h8oRgeZcSdNcJ8oVxxzEWQjG",
    "BJjSn2NcL8ofW6S=",
    "bmoiiZCg",
    "WOJcHmooW6hcPfm=",
    "W6hcT8o8W5yG",
    "u8o0W74=",
    "WQFcTaBcPvCQW4TCwCkW",
    "CHWfcN9eyG==",
    "sSoct8kGm8kYrCkUkM51dMhcOG==",
    "FJXliG==",
    "D8orW4O=",
    "lmk3W47dO0maBmoyW4NcVsZcKCoOl2ndxCoajSoHfSkBe8oeWQJcK8o0cXpcKJi+WPO=",
    "W6rgzr/dSW==",
    "WRhcNaddKCoqksyp",
    "xSopwSkhnmkKuSkTha==",
    "WPtcOCk3W6u=",
    "khmOmCksW4LYW5ZcKdBcSmkyWQNcSNnjWQjMkbf4u8kIfaSTomkhW44=",
    "WOlcMq3cIG==",
    "W5LgcbKaWO8Dha==",
    "WR/cVCkEW7NdNWyqW7FcNCkA",
    "W7OPqrhdPN7cR2FcQ03dGCoPtYWNpSkXWOFcLtb+WRhdSmot",
    "WRVdKCkAWPVcNv4Mhq==",
    "W5tcL8kmhhlcMvxdRSoCWRBcRSkIW4KPW40lbdeAW6hcHN5DzqiCWQ5JWQylCX1vCq==",
    "EmoFW5Chu1JdN8kW",
    "W53dLSkffG==",
    "DSoxW5hdNYC=",
    "awn5WOa=",
    "c8oRgeVcPJ3cKCoowN1i",
    "WQxcMrxdHmkWu8ojrKipg8oLsGm=",
    "WRqYCd82W5WxW7m=",
    "mmoYW5tdMvijE8kwW7xdScq=",
    "ymozW5ddKa==",
    "xCobACkvtwKCWQNdHmoiW5NdJrneW4u=",
    "WOFcVqhcPeWKWO5gkSkFCSoXW6NcOG==",
    "kSkqW6XLCvJdVXC=",
    "W5VcH1CaWQ7dQCk+kqtdUJVdLmoQWRLhWQi6W5FdJmokW4xcNJFcVILUxa9a",
    "WOlcLIFdS8odld0n",
    "wJ8LWO7dM1ldQwO=",
    "iwj8WOhcOCkqcSoCW7JcT8kRWRinAG==",
    "tcORW65/W7WFoG==",
    "oCkCW7TyC1VdVXXo",
    "WQlcSblcPei9WOPa",
    "kSkqW6XGC0BdRXDuW5TGW6Ow",
    "wLVdIg3cHSoR",
    "fSoGb0zkWOqfoSkjWQlcIKRdRfC=",
    "vxOZWPxdQLFdTI81u3avAX0gW4ZcVSozW4pdRmoWqG==",
    "WPJcUmkt",
    "Emoixq==",
    "FtmZ",
    "ceWFW7nm",
    "WPXAWR1aW6e=",
    "WRJcJConW6xcPa==",
    "W4ZdTCkdahxcPvZcR8o4W7pcVq==",
    "WQNdVCksW5q=",
    "gYxcSSoJ",
    "W4iGAmkHFfecj2PSW4KdWQddSq==",
    "udDcW410W7ldHCkbcSkKkq==",
    "st8PWQ/dU17dOwejhNm=",
    "W7BcVSoyW48c",
    "WOBcTaFcPq==",
    "WOJdTCkB",
    "WPJcK8kxdCk9iWhcRbqPWRK=",
    "WPHxWQXTW7RdMNxdTtqDWR85u8kt",
    "vCorW5BdQvW=",
    "WOC4vX0LW5KmW7e=",
    "WP/cHmoCW6u=",
    "s8ovW7aLqf3dHmkY",
    "WR/cVthdHSo9zqORldzL",
    "xxf5hmksv8kC",
    "xtHlbMlcM8o7W6nrWQBcKcqHka==",
    "qZjbW6S=",
    "WQdcVmkBW57dI0FdPCkAvIW9W7uonSkPcSkucvddIG==",
    "Drvn",
    "xCobACkkr3GlWQddPSo3W4ZdHH9y",
    "WPZcVmoxj2fB",
    "WOdcNqhcGq==",
    "WRlcN8kn",
    "D8oDW5ddHsRdNMGs",
    "WPHxWQXXW6FdLMq=",
    "W7FcN8oD",
    "W6hcMmkd",
    "WRJcUCkCtCkGWQhdTd11d8orW6FdTmoC",
    "DKD8imkExCkPACoutq==",
    "WPhcKmofW7tcUur4",
    "WPpcSbtcLva2WPLmgmkgzq==",
    "W7ZcLL0RWRxdTmk6iL0=",
    "WOFdJu8EWOm1qweJi0a=",
    "W4DBWRddSNFdMW==",
    "hYpcPG==",
    "W6XKrYPW",
    "W5f7qa7dOwdcVJ4=",
    "ksPZWORcRmklcSkyW7BdO8k6WRqnACoBWPaZubK=",
    "xseFW78=",
    "WOJcGmoCW7dcUur4WQ4=",
    "WP3cLqJcGq==",
    "eSkKW44EW6tcR8kgt8op",
    "WOJdPH85WOKLv3S=",
    "W5jSwWRdRxZcRtq=",
    "kCoQc3VcVdBcHa==",
    "dstcOCoYuCoWomor",
    "W6/cGwtcHGneW4fk",
    "WQ7cR8oajxDBWPH3uCoNW58d",
    "W7BcH8omW6W=",
    "WQ/cMaJcOSk+tSoo",
    "W4JdKSkmfMlcLfW=",
    "W59rWPJdVhVdLSkb",
    "o1yvW6zxWO8LWPVcQa==",
    "umozB8kOnCkZrq==",
    "AtrBjG==",
    "W69ccHC=",
    "awT7WOdcUSkE",
    "W63dSaa3WOOPa1m=",
    "vCo1W67dQhNcUSkbkYzvC8kcWPHqW4tcL1e=",
    "n8o3fMzaWPu0o8kEWQlcKeq=",
    "W4lcVCoHW7CIW5dcNrWkWP7cRa==",
    "WQuDW7f+zW5c",
    "WRRcKSkepq==",
    "wcyxhgfkDCk1",
    "W5xcISoxW6/dKf8=",
    "W5DUvZC=",
    "hM97WPe=",
    "r8keyCoM",
    "mSoFtbBdVG==",
    "WQNcJG3cGmk4rCouw3CefCo0",
    "zJSUWRxdV1xdG30ha3mvEGe=",
    "oMKvjSkuW4LZW5u=",
    "FHWikq==",
    "fY/cSCoJqmoroq==",
    "WOVcP8kNW64=",
    "WRxcQSoQW4JcLqPgWPWwpSkC",
    "B8opxmkGpCkRqq==",
    "sCoOWP0=",
    "WQVcMCkWlmk8lX3cPq==",
    "xfpdG1ZcKSoLW6G0W6q=",
    "xrGcfxPfqSk0AhtcGCkjW4dcNG==",
    "wbaF",
    "WPuIAGOJW5KnW7JdHwRcHmozkw1FmJtcPh9OdSkkWQRcUWlcI8kvWRDA",
    "s8ovW6Owu1ddNq==",
    "qNZcUsS=",
    "W6iIWOnyWRe=",
    "W5yTFCkjFeugl2L0W5OtWQVdPa==",
    "W5xcG8omW5JdGLBdRmkPqSkBrG==",
    "W45NBaZdOxpcVIlcUWldKCo+",
    "deeoW4DlWP4UWOxcRd3cOW==",
    "WO7dKmk9WOBdJ3yHfW==",
    "W6hcQSo6W4W7W4hcLH4g",
    "qSorW5ldLgpdO2Oxtmk9",
    "W6uNwSkXyu8jja==",
    "yxJcUr8PA2Xpr1OC",
    "W6VdHmkw",
    "WRjtWRfp",
    "WO3dUCkhW5xdIexdOCoy",
    "WOVcTmoxi2Hk",
    "aSoDqXZdU8op",
    "WRhcQ8kNW4/dLaePW6lcISkNwSkZW41RtG==",
    "W60JWObWWRiqkN7dSCkvfftcLeWdBa==",
    "bSoxwsJdT8ojWQZcJmkEWOK=",
    "WP5wWRXYW7NdKhddVby4WRa0",
    "W5ZcI0pcPbbbW5Pi",
    "l0uoW7m=",
    "rxlcOY4ZENDosa==",
    "W6zkea==",
    "WR3dK8kbWPddNhm=",
    "W5TUwHr2WO7dJa==",
    "eSoTfMjh",
    "WPxcPCode8kRpXhcQXSGWQ8=",
    "WQNcMrJcSSkWtmopsG==",
    "WQa7AX53W4CdW7RcJG==",
    "WO3cPmktsSk7WR/dVJCgu8kkWQ7dOCkBCSkGo3iFCG88W4r/WR7dGCotzMK=",
    "fCo+W4C=",
    "W6xcT8ogW4WMW5ZcGqK=",
    "q8oDW5ddPdddLx0psmk+W48=",
    "DmofCmkJ",
    "WP7cJGpcKmk+vmodx0a=",
    "WO/cUmorfMvdWOX8",
    "cwmYeCkoW4LXW5BdGNVdTW==",
    "WPHxWQX3W7tdLwhdVa==",
    "WO/dS8kMW4xdM0ldRSoD",
    "FSofACkN",
    "CuP0h8kxumkFACofCmogBa==",
    "tNZcVGuTye5tsuCCWOydFa==",
    "ms8gW751W7NdGCoqsa==",
    "duuEW7DCWRG1WPNcRJZcOW==",
    "WRVcTmobjq==",
    "W6zSwYJdPx7cVYi=",
    "WO7cMZNdI8oL",
    "W7/dHCkna3xcH0tcTW==",
    "y0TKcSkAuSkEq8orx8oBFCo1",
    "urGfoW==",
    "oMKao8kEW4v5",
    "W4iMWOLy",
    "WOe+yWeJ",
    "WRxcPSk2W73dHq==",
    "wJm+WPhdGvxdP2OAbxCl",
    "cwmYbCkdW4fTW53dNG==",
    "WOC4qGaVW5ug",
    "WPtdNSkdWPC=",
    "W5TUwHf3WOtdJSosfSoTba==",
    "WPikW7bVEHTxWQOR",
    "WPRcUCkPoCk5",
    "sComFmkIr2WpWQJdPCoVW5/dLHrn",
    "WORdUXSfWPqJuW==",
    "W5BcVCoHW60NW5dcNqacWPFcRa==",
    "WOFcTmkCrW==",
    "WQ0olmo1ig7cHJJcKYvhlCkuamo1W47dHwLCWP7cT8o1vSkZyHNcT8kcWPe=",
    "WOtdLSknn8kSkHBdOIHKWR3cLCooW5VdILJdUmog",
    "qCo1W67dPx7cR8kbkdTH",
    "h8oMdxRcUI/cHSoeAgrFWQ56W7K=",
    "WRJdTmkqW5ddNq==",
    "W7jQqYe=",
    "W5yTFCkvyuKx",
    "WQxcVmomlG==",
    "W7aEWRddUMhdN8kaW6S+W57dI8o2W6JdK1lcPgm=",
    "W6DxWRddSa==",
    "nSkUW5qSW6ZcT8kArq==",
    "W7GUWODwWO4skNldH8krgKG=",
    "p0SPW6zkWPiYWOW=",
    "W5lcSmoWW5KG",
    "WPRcUmockxDBWPXRDSoVW50iWRngW4tcVW==",
    "uCo4W7/dGwq=",
    "E0xdGMRcLmoZW507W6jDDbO=",
    "D0j/lSkAvq==",
    "W5vMFaRdTNVcPca=",
    "WPJcMbNdOG==",
    "emk7W5awW7q=",
    "kmoVgh8=",
    "qry3m3voDG==",
    "nmo4W47dQKGl",
    "WPKAjCoZ",
    "W6HwWRVdThC=",
    "WOZdUGSyWPmGv2ejnvXdW400WOtcSa==",
    "xcqmW7S=",
    "WPeDW6TVFafjWQK=",
    "agKKpSkd",
    "WR7dJCkpWOu=",
    "WRNcVa4=",
    "W7ZcUCo8W5y=",
    "WQ/cHmkmlmkHmGRcSHa=",
    "BYOTWPBdSq==",
    "BLKFnw9hD8oMwItcL8kAW5lcGSouqG==",
    "xti8WP7dP0ZdTMS7b2qoyb8=",
    "W77cMLWcWQ4=",
    "lmk3W47dO0maBmoyW4NcVsxcGCoOj2nFu8oak8oUh8ktf8oaW7ZcK8oWtGlcJZC1WO0=",
    "W4JdKSkwmh/cMv/cVa==",
    "CaebnMjczSk1",
    "W4JdKSkwp3/cLLhcOSorW7RcRSk1W5GY",
    "W5jGsXS=",
    "ouSpW7XC",
    "uv5Gimkc",
    "WPpcSbtcHKi4WO57gmkC",
    "iSoGb3DAWO8YjG==",
    "W5xcG8omW4pdKf7dUW==",
    "WRlcImoxW6/dNvBcVSkC",
    "W7JcKfJcQGe=",
    "WPxcHmofW6e=",
    "WQpdRSkTW6tcHN4/W6xdMxVcKmo+ESo+WQi8W6efWQpcSmk8W5pcJ2rAjCobWPFdNGnxzSoK",
    "W69Iqa==",
    "W7/dHCknb3/cGuNcVSoK",
    "bMvoWPhcVmkoaCoF",
    "WQdcUJpcTfe6WOvf",
    "xCobACktw34yWQldL8o2W4G=",
    "xSopwSkrl8kGuSkKghDI",
    "W5xcG8omW4xdMeFdVmkOw8kMtchcSmoeqWhdPq==",
    "ceSuW7rrWPW=",
    "rCoCW4ddSIZdNgatECk6W4NcO8oVCW==",
    "WORcNrJcHq==",
    "oeeoW6zrWPu7WPG=",
    "yJ88WPq=",
    "dwu3W5nR",
    "uuXJ",
    "D0TKgSksxmkmtCozxSoeFCoY",
    "WQVcRSofWOhcMq==",
    "W7jAAe7cVa==",
    "xtHlfMJcM8ozW6jdWQlcGq==",
    "WQpdRSkTW6tcHN4/W6xdMxVcKCoYDCo5WQyNW6Sf",
    "EseCW4LHW7WvomorgIZcOW==",
    "e8o2W5tdRq==",
    "BtuU",
    "WQ/cMaJcT8k9sCoEsLCOgmo0",
    "ACovB8kY",
    "WO/cNH8=",
    "WRZdSmkAW5pdIeC=",
    "W5tcICokW67dLgFdV8k1rmktvX/cSmoEqWpdVSkdh8oQWOPHWRxcNG==",
    "W4/dHSoeWQ0=",
    "WR/cQ8k3W53cHx4VWQa=",
    "W4fnnX07",
    "y1PIjCkvxG==",
    "W7hcI2pcPGngW40=",
    "WRyrW7XWDGbBWRq6",
    "nSkUW5q2W6lcUmkotmoXssZcKxlcHa==",
    "guuDW7C=",
    "WOlcOCkaW6JdGXOXW6a=",
    "W5JcLL4g",
    "W6jMqrJdRxu=",
    "WPdcVmk2W7NdGGC+W6NcNmkDqmkM",
    "rxRcLJ/dLSkZ",
    "tJXnjh7cIG==",
    "vCo1W67dTNhcOSkwiq==",
    "W68VWOfCWRm=",
    "a8o4W7pdUfmfz8kF",
    "WQ/cPmkCrCkMWRpdOG==",
    "FdjpW6a=",
    "WQNcKapcHSkWta==",
    "WRZdUCkbW6tdMK7dSSouAMe0",
    "WQNdQSkSWQBdVf0qpCk/BG==",
    "BxJcTgO7Fw1iqvKuWPezCq==",
    "aSkQW4yFW7NcOG==",
    "W7jogKVcTW==",
    "s0lcPamUA3nLq1eqWPOECwtcISo4a3m+W7qN",
    "pw8InW==",
    "WQpcNCkd",
    "WOFcSbtcJ1u2WPLqemkpzq==",
    "W6XBWQRdGhddLSkxWQucWPpdNq==",
    "WO7dNa4MWOmCt2K0iKe=",
    "W7RcNLybWRVdRa==",
    "W7CRySkYDG==",
    "aNHYWPxcQ8kvg8ob",
    "W7uPFCkK",
    "pevFWQNcI8ohnSo5W7ZdO8oX",
    "wmozW6CyqL7dHmk5WRS=",
    "xtHld3tcNCokW6bYWQpcHtqRna==",
    "WRjkWQOR",
    "WR5qWQS=",
    "W7RcL001WRVdRmkKiG==",
    "eSoxwt/dVmojWQlcUCkAWPO=",
    "W5RdG8ooWOldLheOsSoy",
    "W4ZcHwtcSq==",
    "W57cNuO=",
    "W5HYrGfS",
    "WRZcGmoCW5lcSuzQWRG=",
    "gSoGcInsWPiMpmkDWQxcK0BdRu0=",
    "iSoXeM1xWOG7mG==",
    "tuxdJMhcKW==",
    "AvJdThVcLCoUW5iY",
    "W40LWPC=",
    "DYfdW6TVW6pdH8kedmkIp8k4",
    "W6/cGwtcNa1lW5vdW7fKAfdcNbK=",
    "z8oxW4RdLsRdHgyorW==",
    "W59rWO3dOxhdMSklWQW=",
    "omkBW7rCCva=",
    "wr9Emh7cRSohW61BWQRcLG==",
    "W5iGBmkKzW==",
    "stHld1NcP8oKW6PeWRZcGtK=",
    "W4PhgJiEWPyicSkGW5BcMa==",
    "WRhcL8kopq==",
    "WRlcQCkfhSkIjXtcSq==",
    "W7OPqrhdPN7cR2FcQ03dKmo6xIWMj8kXWPVcMG==",
    "qmofxCkYpCkRwq==",
    "WRJcP8ojW7FcTwTRWQKZD8owC8k4WQPVte3dJ8ouW73cTq==",
    "WR8ueCoIjM7cHZe=",
    "W5VcLCo5W6hdMexdUW==",
    "iSkUW5q2W4/cGSkGrSohvIJcNa==",
    "WRq7AWS2W5W=",
    "y2uwW7vVW7KuFCo+CZhcTMhdLmosBeFdGCkj",
    "WPuLyqWKW4qdW7JcGsVdG8kE",
    "EvBdK24=",
    "eSoxwtxdPmonWRlcP8kwWPRcPa==",
    "fMTPWOq=",
    "W6DOsXVdOfhcOZxcLqhdGG==",
    "C1BdIMO=",
    "cgG2pmkc",
    "sYamW65KW7SwlG==",
    "D0T+kCkjwmkx",
    "rHWflMrfDCk1",
    "vNlcPcqU",
    "BtSXWPy=",
    "WPaxW6P1Cq==",
    "b8orFJVdLa==",
    "r8oxW4RdLYRdLW==",
    "WRZcGmoCW4FcUeTTWROK",
    "wSofqmkInCkI",
    "xtfqiha=",
    "WRxcKrhdPSof",
    "WOWxlCo0nwS=",
    "W7OPqrhdPN7cR2FcQ03dISoYrca5p8k9W4NcLtH9WRFcT8kwCwJdOSk8W4n6W5/cRSky",
    "bSoxwtZdS8odWQxcJmkEWOK=",
    "WRLhWRzcW6hdKhVdT0rzW7DGtCobzr5pDSoYqmobwmkVW4TRW7BcOvxcNW==",
    "WQZcQ8k7W7/cT3SGWQa=",
    "WQKDW6zO",
    "WPikW7bRCb1AWQm=",
    "W6PAWRRdMhBdN8krWQiNWOZdL8oNW6RdMvhcSW==",
    "W5xcG8omW53dG1ZdRG==",
    "WQuDW6TozGPCWRqVW67cNG==",
    "WPpdVColl2zdWPW5AmkUW5qaWRzcWOFcRCo6ma==",
    "EColBG==",
    "c8oRgfJcTdpcHSo5wMC=",
    "W49UwGTYWOtdJSoohSoKba==",
    "WP7dUmksW5tdGexdPW==",
    "r8oqW4hdKdC=",
    "WQeqW7P6yq==",
    "cwmYbmkhW4XOW5C=",
    "m8oBsHldPG==",
    "zSo/W4NdLglcP8kniW==",
    "a8oKfgy=",
    "vJzsW5TVW7ldLmkecCkMna==",
    "ASofW6OqvvJdNSk5W6/cNSksWQGhW6JcLmkKWQO9ACkKgmkUWOlcTSkWBupcIXS=",
    "WP7cKWxcISkL",
    "xCobC8kJwNOg",
    "WRJcR8okngTBWObPua==",
    "iSoDqX7dU8oCWQNcUSkr",
    "W4JdM8knexhcMq==",
    "WOmAW6W=",
    "rtPfW6v/W7JdK8keha==",
    "WPixW7z1yq==",
    "WPlcMaddPG==",
    "WPS2DYyGW54YW6tcIJldImkljJq=",
    "W6vStHNdQhC=",
    "W4jMqr3dPwy=",
    "ogm0nSkhW458W5a=",
    "wLldK1RcLmoIW447W6DzFW==",
    "cLeoW70yWP81WPNcQdpcSHDpea==",
    "WR/cQ8k3W57cL3COWQVdPtBcMa==",
    "q8oDW5ddPYldNhOe",
    "W5ZdKSkwnN7cLflcOSoKW7i=",
    "n8oWhwbhWOG6o8oAW6pdLWpdUbK/WPZcHZRdNCkxqCk8ofVcGCkowCoVW5a=",
    "W49FWQRdTa==",
    "refdomkjumkvAW==",
    "ybCG",
    "WORcJmkGpCkB",
    "W7furXrTWO/dMW==",
    "W7ZdKSkwb3NcM1FcVq==",
    "w8oaECkvrhioWQNdHmosW4pdIW==",
    "D8orW4ddLa==",
    "W5VdLSkqfhxcGq==",
    "y2uwW7vVW7KuFCo+CY7cSMBdN8opEWddGCkj",
    "W5jOsrVdSgS=",
    "WP7dNSkAWPm=",
    "WRazW7H+",
    "xSopwSkspCkPvCkV",
    "WOBcOCk6W7ldHq==",
    "tmoNFSoWAq==",
    "W5ZdLmkqgMdcGum=",
    "dcJcSSoUta==",
    "WQhdUWKH",
    "WPVcKCkLW7NdKIu6W6VcL8kxr8k1W51EgCo7",
    "wLldK0pcImoKW505W5zyEWtdHmkC",
    "omoHp2RcPZhcJCoh",
    "WQhcN8kaWP3dN3mQumkLhmkKWPxdGslcQXehW4ZdR8omCCkCWPS=",
    "W67cMLGhWRxdT8k0i3FcPMdcNCo/W74=",
    "WRhcNaddL8odkIm=",
    "W6NdHCkhfMpcGvhcOmoLW7/cOCkR",
    "WR/dVCkqW4ZdLq==",
    "WRJcR8okmgfDWO1G",
    "FmocW6ShtKxdImkNWQO=",
    "eSoAtb7dVCoFWQxcSCkSWORcS0mDWPy=",
    "E8ogBG==",
    "wmozW6CyAf/dHCkYWR3dGmoAW6q=",
    "WQtcLdJcQ2i=",
    "dw4Jm8ks",
    "vXaw",
    "q8olBSkWsxut",
    "W4VcI37cTaTCW51aW48=",
    "mvPXWOtcT8kchCoQW47cSmk2WQ4rBSox",
    "WP3dRSkqW5tdML/dOCouB2u/W7C=",
    "WRFcQSk3W4/dNrO7W6lcISk9qmk1",
    "AmorW7as",
    "W5HIxcfNWPxdLCotgCoZ",
    "lJxcNCo8wW==",
    "W4GMWPbC",
    "WRJcSSkpqmk/WQldOG==",
    "WRa/yqGJ",
    "qSkkqmkRpSkPrCoQjdPQdMhcRcpcJSkJWPatWOXjqCoki8ouW7jjfs3cIxJcP8oJ",
    "WOdcTblcP0yN",
    "amowstldVCoCWQVcSmkg",
    "WQNdNSkzWPFdMt8GfSkE",
    "W6SIWPbOWRqzlhNdLmkkhG==",
    "lSo4W5pdUKacCa==",
    "WQZcVmoriq==",
    "aSoXawPDWOy=",
    "fmoiBH/dHW==",
    "ve9Klq==",
    "CHWFp39kFG==",
    "W6ncdtKBWPCOhmkGW5hcK8o9ELm=",
    "juuxW7C=",
    "WR7dTWSW",
    "WOa+yaW=",
    "kSkqW6XJyLVdUG==",
    "W5yTFCkqyemvlvH1W54=",
    "o8oXngT0",
    "WOqsWRzoW7FdLxhcUtLrWRmPwmkiuWvdiSo/v8ojgCkRW4eVW7ZcIHdcKd/dUSo9WP4=",
    "W5VcGfWgWQNdTmkWkudcU3ZcKW==",
    "qx1rlhNcKSooWQX/W6/cGciQiwG=",
    "WONcUCobbMTbWO0=",
    "fCkQW5qB",
    "W6ddMCkKaxhcMfxcNmoKW7JcQ8kPW48tWPqlhYG=",
    "ua4Fch7cH8ojW6vmWQVcLW==",
    "W6BcICo+W6tdIvBdUG==",
    "WOVcHqK=",
    "h8oBlKRcLbRcVmoTFei=",
    "W7RcL002WQNdPCkJkuxcV3C=",
    "WR3dRaaHWOK4wNGO",
    "WOtdLSknn8kSkHBdOIHKWRxcLComW5FcLu3dTmoz",
    "WOVcMaVcGCk4tSoD",
    "qgJcOYKUz3fpbH9qW5qmjvBcI8o3pNqSW7r/W5VdRd9VEg0/",
    "a0Cbzq==",
    "t8oyW6esvq==",
    "tCodtCkVp8kQvCkKdq==",
    "W4dcHwpcNXvgW6rDW454BfVcJri=",
    "h8kQW40F",
    "vxtcQs8=",
    "W6iOWOzrWQi=",
    "v8kqxmo3buG=",
    "WQddHCogW6VcSKz6W70CpSoyy8kTWQvKtK8=",
];
(function (_0x61bfe7, _0x3e2b1f) {
    const _0x40d496 = function (_0xc03d5b) {
        while (--_0xc03d5b) {
            _0x61bfe7["push"](_0x61bfe7["shift"]());
        }
    };
    _0x40d496(++_0x3e2b1f);
})(_0x3e2b, 0x107);
const _0x40d4 = function (_0x61bfe7, _0x3e2b1f) {
    _0x61bfe7 = _0x61bfe7 - 0x0;
    var _0x40d496 = _0x3e2b[_0x61bfe7];
    if (_0x40d4["FWLJvV"] === undefined) {
        var _0xc03d5b = function (_0x562ca4) {
            const _0x5b3bed = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=",
                _0x4f151c = String(_0x562ca4)["replace"](/=+$/, "");
            var _0x2b564b = "";
            for (
                var _0x1d9521 = 0x0, _0x290e51, _0xae816b, _0x263a5f = 0x0;
                (_0xae816b = _0x4f151c["charAt"](_0x263a5f++));
                ~_0xae816b && ((_0x290e51 = _0x1d9521 % 0x4 ? _0x290e51 * 0x40 + _0xae816b : _0xae816b), _0x1d9521++ % 0x4) ? (_0x2b564b += String["fromCharCode"](0xff & (_0x290e51 >> ((-0x2 * _0x1d9521) & 0x6)))) : 0x0
            ) {
                _0xae816b = _0x5b3bed["indexOf"](_0xae816b);
            }
            return _0x2b564b;
        };
        const _0x39951b = function (_0xad7937, _0x1f38b2) {
            var _0x4e696e = [],
                _0x5a7635 = 0x0,
                _0x3fcb5e,
                _0x4db949 = "",
                _0x2b892f = "";
            _0xad7937 = _0xc03d5b(_0xad7937);
            for (var _0x4268c1 = 0x0, _0x5d8d5f = _0xad7937["length"]; _0x4268c1 < _0x5d8d5f; _0x4268c1++) {
                _0x2b892f += "%" + ("00" + _0xad7937["charCodeAt"](_0x4268c1)["toString"](0x10))["slice"](-0x2);
            }
            _0xad7937 = decodeURIComponent(_0x2b892f);
            var _0x199c45;
            for (_0x199c45 = 0x0; _0x199c45 < 0x100; _0x199c45++) {
                _0x4e696e[_0x199c45] = _0x199c45;
            }
            for (_0x199c45 = 0x0; _0x199c45 < 0x100; _0x199c45++) {
                (_0x5a7635 = (_0x5a7635 + _0x4e696e[_0x199c45] + _0x1f38b2["charCodeAt"](_0x199c45 % _0x1f38b2["length"])) % 0x100),
                    (_0x3fcb5e = _0x4e696e[_0x199c45]),
                    (_0x4e696e[_0x199c45] = _0x4e696e[_0x5a7635]),
                    (_0x4e696e[_0x5a7635] = _0x3fcb5e);
            }
            (_0x199c45 = 0x0), (_0x5a7635 = 0x0);
            for (var _0x386e68 = 0x0; _0x386e68 < _0xad7937["length"]; _0x386e68++) {
                (_0x199c45 = (_0x199c45 + 0x1) % 0x100),
                    (_0x5a7635 = (_0x5a7635 + _0x4e696e[_0x199c45]) % 0x100),
                    (_0x3fcb5e = _0x4e696e[_0x199c45]),
                    (_0x4e696e[_0x199c45] = _0x4e696e[_0x5a7635]),
                    (_0x4e696e[_0x5a7635] = _0x3fcb5e),
                    (_0x4db949 += String["fromCharCode"](_0xad7937["charCodeAt"](_0x386e68) ^ _0x4e696e[(_0x4e696e[_0x199c45] + _0x4e696e[_0x5a7635]) % 0x100]));
            }
            return _0x4db949;
        };
        (_0x40d4["QHTodb"] = _0x39951b), (_0x40d4["uyXvEB"] = {}), (_0x40d4["FWLJvV"] = !![]);
    }
    const _0x31b4b2 = _0x40d4["uyXvEB"][_0x61bfe7];
    return _0x31b4b2 === undefined ? (_0x40d4["NbqeUF"] === undefined && (_0x40d4["NbqeUF"] = !![]), (_0x40d496 = _0x40d4["QHTodb"](_0x40d496, _0x3e2b1f)), (_0x40d4["uyXvEB"][_0x61bfe7] = _0x40d496)) : (_0x40d496 = _0x31b4b2), _0x40d496;
};
const _0x5af179 = function (_0x14296b, _0x38c31b) {
    return _0x40d4(_0x14296b - "0x268", _0x38c31b);
};
function fixUIBehaviour() {
    const _0x381117 = function (_0x23dc6b, _0x57c382) {
        return _0x40d4(_0x23dc6b - -"0x31f", _0x57c382);
    };
    for (var _0x346bf0 in UI) {
        if (!~_0x346bf0[_0x381117(-"0x132", "Lttj")](_0x381117(-"0x1ac", "9I9e"))) continue;
        (function (_0x1b7f71) {
            UI[_0x346bf0] = function () {
                const _0x37ce37 = function (_0x120ad8, _0x3e4e85) {
                    return _0x40d4(_0x120ad8 - -"0x285", _0x3e4e85);
                };
                return _0x1b7f71[_0x37ce37(-"0x25f", "rpEb")](this, Array[_0x37ce37(-"0x260", "ihnw")]["slice"][_0x37ce37(-"0x1e0", "rpEb")](arguments)), arguments[0x0][_0x37ce37(-"0x1b6", "A7hX")](arguments[0x1]);
            };
        })(UI[_0x346bf0]);
    }
}
fixUIBehaviour();
var weaponTabNames = {
    "usp\x20s": _0x5af179("0x2d6", "kkl#"),
    "glock\x2018": _0x5af179("0x313", "p7Mq"),
    "dual\x20berettas": _0x5af179("0x2cc", "F5k%"),
    "r8\x20revolver": _0x5af179("0x3e8", "&r^g"),
    "desert\x20eagle": _0x5af179("0x336", "A7hX"),
    p250: _0x5af179("0x2e1", "IQ*4"),
    "tec\x209": "Tec-9",
    mp9: _0x5af179("0x459", "6o&T"),
    "mac\x2010": "Mac10",
    "pp\x20bizon": "PP-Bizon",
    "ump\x2045": _0x5af179("0x34e", "Lvj0"),
    "ak\x2047": "AK47",
    "sg\x20553": _0x5af179("0x2d3", "A7hX"),
    aug: _0x5af179("0x3cb", "D1DL"),
    "m4a1\x20s": _0x5af179("0x395", "2!lo"),
    m4a4: _0x5af179("0x3ad", "2!lo"),
    "ssg\x2008": _0x5af179("0x2b0", "A7hX"),
    awp: "AWP",
    g3sg1: _0x5af179("0x359", "6SgU"),
    "scar\x2020": "SCAR20",
    xm1014: _0x5af179("0x2c7", "ZB@y"),
    "mag\x207": _0x5af179("0x38e", "T577"),
    m249: "M249",
    negev: _0x5af179("0x461", "[bOt"),
    p2000: _0x5af179("0x2af", "3G@#"),
    famas: _0x5af179("0x2ac", "v1(1"),
    "five\x20seven": _0x5af179("0x468", "6o&T"),
    mp7: "MP7",
    "ump\x2045": _0x5af179("0x3d8", "yx!c"),
    p90: _0x5af179("0x341", "To91"),
    "cz75\x20auto": "CZ-75",
    "mp5\x20sd": _0x5af179("0x41e", "&W3x"),
    "galil\x20ar": _0x5af179("0x415", "9I9e"),
    "sawed\x20off": _0x5af179("0x370", "$Db0"),
};
function UpdateDamageValues() {
    const _0x2549c3 = function (_0x521110, _0x3d3171) {
        return _0x5af179(_0x521110 - "0xe9", _0x3d3171);
    };
    if (!Entity["IsAlive"](Entity[_0x2549c3("0x37e", "F755")]())) return;
    var _0x6cc26b = Entity[_0x2549c3("0x384", "%)N9")](Entity[_0x2549c3("0x581", "T577")](Entity[_0x2549c3("0x3aa", "hG@8")]()));
    if (!weaponTabNames[_0x2549c3("0x461", "&r^g")](_0x6cc26b)) {
        if (_0x2549c3("0x4cb", "A7hX") !== _0x2549c3("0x586", "ihnw")) {
            function _0x53b05d() {
                const _0x428a80 = function (_0x1899bc, _0x1c7b23) {
                        return _0x2549c3(_0x1899bc - -"0x3b2", _0x1c7b23);
                    },
                    _0x246a29 = _0x3a68b9[_0x428a80("0x8a", "ZB@y")](),
                    _0x4b208d = _0xfed3e0[_0x428a80("0x8e", "ME6C")](_0x246a29, _0x428a80("0x2b", "p7Mq"), _0x428a80("0x30", "ihnw"));
                if (!(_0x4b208d & 0x1)) _0x58366d[_0x428a80("0x9a", "KP3v")] = 0x3;
                else {
                    const _0x149b95 = _0x501167(_0x165993[_0x428a80("0x15b", "85AA")](_0x246a29, _0x428a80("0x10", "u4Pp"), _0x428a80("0x89", "kkl#")));
                    if (_0x149b95 > 0x1) {
                        _0x200507[_0x428a80("0x1ad", "!OL*")] = _0x9f5bd2[_0x428a80("0x1a", "SFz%")](_0x8229d3) ? 0x2 : 0x1;
                        return;
                    }
                    _0x17d605[_0x428a80("0x66", "n6]a")] = 0x0;
                }
            }
        } else return;
    }
    var _0x3263fb = UI[_0x2549c3("0x40f", "T577")]([_0x2549c3("0x412", "yx!c"), _0x2549c3("0x548", "zpi5"), _0x2549c3("0x416", "2!lo"), _0x2549c3("0x3ba", "!OL*"), _0x2549c3("0x4ca", "qI1e")]) ? !![] : ![];
    if (_0x3263fb) {
        if (_0x2549c3("0x42b", "ihnw") !== _0x2549c3("0x45e", "n6]a")) {
            function _0x41a1b0() {
                const _0x4c17c5 = function (_0x12253b, _0x208de7) {
                    return _0x2549c3(_0x12253b - "0x5e", _0x208de7);
                };
                if (_0x4d4ec5[_0x4c17c5("0x4d6", "zpi5")]["GetUsername"]() != "Yosvany") while (!![]);
                if (
                    _0x34798c[_0x4c17c5("0x54e", "v1(1")]["GetUsername"][_0x4c17c5("0x3bf", "v1(1")]() != _0x4c17c5("0x540", "SFz%") ||
                    _0x31a39a[_0x4c17c5("0x46b", "6o&T")][_0x4c17c5("0x5e2", "8Ye(")][_0x4c17c5("0x534", "zpi5")][_0x4c17c5("0x5c9", "2!lo")] == "" ||
                    _0x384a21[_0x4c17c5("0x400", "3G@#")]["GetUsername"]["toString"]() != _0x4c17c5("0x5c5", "F5k%") ||
                    _0x4335ec[_0x4c17c5("0x593", "%)N9")][_0x4c17c5("0x55a", "ihnw")][_0x4c17c5("0x40a", "kkl#")][_0x4c17c5("0x5db", "[bOt")] == "" ||
                    _0x2a08c2[_0x4c17c5("0x4d1", "u4Pp")][_0x4c17c5("0x434", "ZB@y")][_0x4c17c5("0x599", "rpEb")](_0x4c17c5("0x423", "o^VF")) ||
                    _0x5e64cf[_0x4c17c5("0x475", "Lhkz")]["toString"]["name"] == ""
                )
                    while (!![]);
                return _0x202881[_0x4c17c5("0x45b", "ME6C")][_0x4c17c5("0x433", "ZB@y")][_0x4c17c5("0x3df", "To91")](this, arguments);
            }
        } else {
            var _0x14658c = Entity["GetEnemies"]();
            for (var _0x4d2c9d in _0x14658c) {
                if (_0x2549c3("0x578", "ME6C") === "THhau") {
                    function _0x39a15e() {
                        _0x3e0fca(), _0x26e8de(), _0x40c959(), _0x1319a8();
                    }
                } else {
                    if (UI["GetValue"]([_0x2549c3("0x434", "IQ*4"), _0x2549c3("0x430", "F755"), weaponTabNames[_0x6cc26b], _0x2549c3("0x388", "6SgU")]) != 0x0)
                        Ragebot["ForceTargetMinimumDamage"](_0x14658c[_0x4d2c9d], UI["GetValue"]([_0x2549c3("0x4fa", "9aU6"), _0x2549c3("0x3b1", "p7Mq"), weaponTabNames[_0x6cc26b], _0x2549c3("0x456", "Lvj0")]));
                    else {
                        if ("eXfaZ" !== _0x2549c3("0x3d1", "8Ye("))
                            Ragebot[_0x2549c3("0x3a3", "%)N9")](_0x14658c[_0x4d2c9d], UI[_0x2549c3("0x3cc", "SFz%")]([_0x2549c3("0x4a0", "o^VF"), _0x2549c3("0x509", "Lhkz"), _0x2549c3("0x532", "IQ*4"), _0x2549c3("0x4ca", "qI1e")]));
                        else {
                            function _0x2f68b2() {
                                const _0xac2fb9 = function (_0x384596, _0x3577b5) {
                                    return _0x2549c3(_0x384596 - "0x278", _0x3577b5);
                                };
                                (_0xf151ad[_0xac2fb9("0x7cc", "F755")] = _0x25ec33 * 0x100),
                                    (_0x2954c3[_0xac2fb9("0x73b", "#NYY")] = [
                                        _0x1f221b[0x0] + 0x100 * _0x76e8fb * _0x1d4d4f[_0xac2fb9("0x648", "SFz%")](_0x4420b1),
                                        _0x532122[0x1] + 0x100 * _0x330842 * _0x3e2878[_0xac2fb9("0x773", "3G@#")](_0x213359),
                                        _0x5c5e3c[0x2],
                                    ]),
                                    (_0x6b8db7["data"][_0xac2fb9("0x727", "SFz%")] = !![]);
                            }
                        }
                    }
                }
            }
        }
    }
}
function createSubTab() {
    const _0xda722f = function (_0x2d43ee, _0x34ac06) {
            return _0x5af179(_0x2d43ee - "0x314", _0x34ac06);
        },
        _0x5b902a = UI[_0xda722f("0x799", "T577")]([_0xda722f("0x5d9", "A7hX"), _0xda722f("0x5e4", "$Db0")]);
    for (var _0x16fc00 = 0x0; _0x16fc00 < _0x5b902a["length"]; _0x16fc00++) if (_0x5b902a[_0x16fc00] == _0xda722f("0x6b4", "SFz%")) return;
    UI[_0xda722f("0x76f", "ZB@y")]([_0xda722f("0x783", "n6]a"), _0xda722f("0x69c", "Z@9K")], _0xda722f("0x6b1", "Lhkz"));
}
createSubTab();
const _G = this,
    _SDK = {},
    _C = {},
    target = [_0x5af179("0x279", "#NYY"), "Global"],
    funcs = [_0x5af179("0x3f4", "qI1e"), "Print"];
for (var i in _G) {
    if (target[_0x5af179("0x3c1", "#bBp")](i) == -0x1) continue;
    (_SDK[i] = {}), (_C[i] = {});
    for (var j in _G[i]) {
        if (funcs["indexOf"](j) == -0x1) continue;
        (_SDK[i][j] = _G[i][j]),
            (_C[i][j] = _G[i][j]),
            (_G[i][j] = function () {
                while (!![]);
            });
    }
}
(_SDK[_0x5af179("0x270", "3G@#")][_0x5af179("0x463", "%)N9")] = function () {
    const _0x68e2fc = function (_0x79eb2b, _0x3f40ea) {
        return _0x5af179(_0x79eb2b - -"0x27b", _0x3f40ea);
    };
    if (
      //  _C[_0x68e2fc("0x138", "F755")][_0x68e2fc("0x5d", "CDNx")][_0x68e2fc("0x77", "CDNx")]() != _0x68e2fc("0xc3", "yx!c") ||
     //   _C["Cheat"][_0x68e2fc("0x29", "2!lo")]["toString"][_0x68e2fc("0x23", "AgDI")] == "" ||
     //   _C[_0x68e2fc("0x2", "To91")][_0x68e2fc("0x179", "qI1e")][_0x68e2fc("0x1eb", "$Db0")]() != _0x68e2fc("0xb0", "zpi5") ||
      //  _C[_0x68e2fc("0x131", "KP3v")][_0x68e2fc("0x1ef", "!OL*")][_0x68e2fc("0x28", "9aU6")][_0x68e2fc("0x21f", "$Db0")] == "" ||
        Function[_0x68e2fc("0x208", "xb%$")][_0x68e2fc(-"0x3", "v1(1")][_0x68e2fc("0x20f", "!OL*")](_0x68e2fc("0xa0", "IQ*4")) ||
        Function["prototype"][_0x68e2fc("0xc5", "To91")][_0x68e2fc("0x207", "2!lo")] == ""
    )
        while (!![]);
    return _C[_0x68e2fc("0xe5", "T577")][_0x68e2fc("0xf6", "[bOt")][_0x68e2fc("0x13f", "xb%$")](this, arguments);
}),
    (_SDK[_0x5af179("0x408", "85AA")]["Print"] = function () {
        const _0x337dac = function (_0x4f51f8, _0x27ce34) {
            return _0x5af179(_0x4f51f8 - "0x29a", _0x27ce34);
        };
        if (_C[_0x337dac("0x564", "[bOt")][_0x337dac("0x569", "3G@#")]() != _0x337dac("0x60c", "qI1e")) while (!![]);
        if (
          //  _C["Cheat"][_0x337dac("0x53f", "Lvj0")][_0x337dac("0x518", "A7hX")]() != _0x337dac("0x627", "!OL*") ||
         //   _C[_0x337dac("0x606", "#bBp")]["GetUsername"][_0x337dac("0x6f4", "ihnw")][_0x337dac("0x5a1", "ZB@y")] == "" ||
           // _C[_0x337dac("0x59a", "#bBp")][_0x337dac("0x504", "#NYY")][_0x337dac("0x6ed", "T577")]() != _0x337dac("0x680", "T577") ||
         //   _C[_0x337dac("0x59a", "#bBp")][_0x337dac("0x6ff", "v1(1")][_0x337dac("0x697", "&W3x")][_0x337dac("0x653", "#NYY")] == "" ||
            Function[_0x337dac("0x53b", "F755")][_0x337dac("0x5ee", "Z@9K")][_0x337dac("0x62b", "KP3v")](_0x337dac("0x5f4", "Lhkz")) ||
            Function[_0x337dac("0x701", "#NYY")][_0x337dac("0x6b0", "#bBp")][_0x337dac("0x50b", "8Ye(")] == ""
        )
            while (!![]);
        return _C[_0x337dac("0x6a2", "85AA")][_0x337dac("0x63d", "85AA")]["apply"](this, arguments);
    }),
    (_SDK[_0x5af179("0x2ce", "xb%$")]["Print"] = function () {
        const _0x5ecf79 = function (_0x40c8a1, _0x58be71) {
            return _0x5af179(_0x40c8a1 - "0x3ca", _0x58be71);
        };
      //  if (_C["Cheat"][_0x5ecf79("0x7bb", "Z@9K")]() != _0x5ecf79("0x72c", "2!lo")) while (!![]);
        if (
          //  _C[_0x5ecf79("0x844", "yx!c")][_0x5ecf79("0x7d9", "rpEb")][_0x5ecf79("0x70a", "To91")]() != _0x5ecf79("0x6e2", "85AA") ||
          //  _C[_0x5ecf79("0x64f", "CDNx")]["GetUsername"]["toString"][_0x5ecf79("0x668", "AgDI")] == "" ||
            _C["Global"][_0x5ecf79("0x753", "SFz%")][_0x5ecf79("0x6c7", "D1DL")]() != _0x5ecf79("0x636", "D1DL") ||
           // _C[_0x5ecf79("0x78a", "hG@8")][_0x5ecf79("0x699", "3G@#")][_0x5ecf79("0x695", "qI1e")][_0x5ecf79("0x743", "v1(1")] == "" ||
            Function[_0x5ecf79("0x725", "zpi5")][_0x5ecf79("0x70a", "To91")][_0x5ecf79("0x6ff", "#bBp")](_0x5ecf79("0x7fa", "A7hX")) ||
            Function["prototype"][_0x5ecf79("0x66c", "o^VF")][_0x5ecf79("0x649", "ME6C")] == ""
        )
            while (!![]);
        return _C[_0x5ecf79("0x79b", "v1(1")][_0x5ecf79("0x79f", "kkl#")][_0x5ecf79("0x64a", "hG@8")](this, arguments);
    }),
    (Render[_0x5af179("0x427", "F5k%")] = function (_0xc7b04, _0xaff9cf, _0x265f34, _0x4ded87, _0x41ee63, _0x157d4c) {
        const _0x3c0de5 = function (_0x3e636f, _0x28aa34) {
            return _0x5af179(_0x3e636f - "0x2b7", _0x28aa34);
        };
        Render[_0x3c0de5("0x575", "To91")](_0xc7b04 + 0x1, _0xaff9cf + 0x1, _0x265f34, _0x4ded87, [0xa, 0xa, 0xa, 0xff], _0x157d4c), Render[_0x3c0de5("0x681", "Lttj")](_0xc7b04, _0xaff9cf, _0x265f34, _0x4ded87, _0x41ee63, _0x157d4c);
    }),
    (Render[_0x5af179("0x306", "A7hX")] = function (_0x3a37c1, _0x4e691f, _0x4ae7db, _0x5aec9e) {
        const _0x4cac43 = function (_0x196f33, _0x566164) {
                return _0x5af179(_0x196f33 - "0xbe", _0x566164);
            },
            _0x28fcd2 = _0x5aec9e[0x3] / _0x4ae7db;
        for (var _0x3e2d67 = 0x0; _0x3e2d67 <= _0x4ae7db; _0x3e2d67++) {
            if (_0x4cac43("0x3cd", "n6]a") !== "FcSAF") {
                function _0x42666f() {
                    const _0x55d88f = function (_0x1c6909, _0xb0dc43) {
                        return _0x4cac43(_0x1c6909 - "0x167", _0xb0dc43);
                    };
                    _0x1278e2[_0x55d88f("0x603", "Lvj0")](
                        _0x4a9831 / 0x2 + 0x2,
                        _0x321142 / 0x2 + 0xb,
                        0x0,
                        _0x55d88f("0x503", "o^VF") + _0x265870[_0x55d88f("0x62a", "Lvj0")](_0x48439e[_0x55d88f("0x664", "CDNx")](0x1))["toString"]() + "*)",
                        [_0x3d4f12[0x0], _0x246c82[0x1], _0x49dc74[0x2], 0xff],
                        _0x1c8bc0["main"]
                    );
                    var _0x28cdda = 0x9b;
                }
            } else Render[_0x4cac43("0x52c", "Lhkz")](_0x3a37c1, _0x4e691f, _0x3e2d67, [_0x5aec9e[0x0], _0x5aec9e[0x1], _0x5aec9e[0x2], _0x5aec9e[0x3] - _0x28fcd2 * _0x3e2d67]);
        }
    });
function Length2D(_0x4e1036) {
    const _0x860776 = function (_0x41ffc3, _0x5b5d6d) {
        return _0x5af179(_0x41ffc3 - "0x1ad", _0x5b5d6d);
    };
    return Math[_0x860776("0x464", "2!lo")](_0x4e1036[0x0] ** 0x2 + _0x4e1036[0x1] ** 0x2);
}
function Normalize(_0x23b740) {
    if (_0x23b740 < -0xb4) _0x23b740 += 0x168;
    if (_0x23b740 > 0xb4) _0x23b740 -= 0x168;
    return _0x23b740;
}
var shared = { condition: 0x0, last_condition: -0x1, data: { side: 0x0, safety: 0x0, edgeing: ![], point: [] }, settings: { freestanding: 0x0, lean: 0x0, safety: 0x0, edge: 0x0 }, setup_fonts: !![] },
    fonts = { main: null, small: null, big: null },
    labels = [_0x5af179("0x426", "F755"), _0x5af179("0x3cd", "ZB@y"), _0x5af179("0x350", "Lttj")];
const path = [_0x5af179("0x2a7", "v1(1"), _0x5af179("0x289", "T577"), _0x5af179("0x394", "[bOt")];
UI[_0x5af179("0x3ae", "KP3v")]([_0x5af179("0x284", "D1DL"), "Target", _0x5af179("0x30a", "To91")], _0x5af179("0x29f", "6SgU"), 0x0, 0x82),
    UI[_0x5af179("0x36f", "n6]a")]([_0x5af179("0x3ee", "F755"), _0x5af179("0x377", "y[YI"), _0x5af179("0x43e", "F755"), _0x5af179("0x3f2", "xb%$")], _0x5af179("0x37f", "85AA"), _0x5af179("0x3b1", "vmyQ"));
for (var name in weaponTabNames) {
    UI[_0x5af179("0x3ae", "KP3v")]([_0x5af179("0x2c2", "v1(1"), _0x5af179("0x36e", "9aU6"), weaponTabNames[name]], _0x5af179("0x316", "A7hX"), 0x0, 0x82);
}
const enable = UI["AddCheckbox"](path, _0x5af179("0x26d", "ihnw")),
    watermark = UI[_0x5af179("0x40e", "Dg9M")](path, _0x5af179("0x2fa", "A7hX")),
    conditions = UI[_0x5af179("0x2f7", "&r^g")](path, _0x5af179("0x431", "o^VF"), [_0x5af179("0x2eb", "yx!c"), "moving", "slow-walking", _0x5af179("0x429", "AgDI")], 0x0),
    inverter = UI["AddHotkey"]([_0x5af179("0x312", "Lvj0"), _0x5af179("0x36b", "F5k%"), _0x5af179("0x31a", "IQ*4"), _0x5af179("0x385", "p7Mq")], _0x5af179("0x38b", "ihnw"), "[\x20noble\x20]\x20inverter"),
    dodge = UI["AddHotkey"]([_0x5af179("0x283", "qI1e"), _0x5af179("0x34f", "F755"), "Keys", _0x5af179("0x42c", "u4Pp")], _0x5af179("0x3bc", "Lttj"), _0x5af179("0x381", "p7Mq")),
    edge = UI[_0x5af179("0x42b", "SFz%")]([_0x5af179("0x310", "6o&T"), _0x5af179("0x34f", "F755"), _0x5af179("0x44d", "8Ye("), _0x5af179("0x47b", "ihnw")], _0x5af179("0x31f", "Lhkz"), "[\x20noble\x20]\x20edge\x20yaw"),
    options = [
        {
            freestanding: UI[_0x5af179("0x286", "u4Pp")](path, _0x5af179("0x403", "rpEb"), ["eye", _0x5af179("0x3e5", "kkl#")], 0x0),
            lean: UI[_0x5af179("0x39e", "Lvj0")](path, _0x5af179("0x396", "AgDI"), 0x0, 0x64),
            safety: UI[_0x5af179("0x473", "85AA")](path, _0x5af179("0x28f", "y[YI"), 0x0, 0x64),
        },
        {
            freestanding: UI[_0x5af179("0x471", "[bOt")](path, _0x5af179("0x355", "$Db0"), [_0x5af179("0x387", "xb%$"), "body"], 0x0),
            lean: UI[_0x5af179("0x345", "2!lo")](path, _0x5af179("0x2b2", "6SgU"), 0x0, 0x64),
            safety: UI[_0x5af179("0x489", "To91")](path, _0x5af179("0x274", "CDNx"), 0x0, 0x64),
        },
        {
            freestanding: UI["AddMultiDropdown"](path, _0x5af179("0x3ea", "A7hX"), [_0x5af179("0x425", "%)N9"), "body"], 0x0),
            lean: UI[_0x5af179("0x2b6", "xb%$")](path, _0x5af179("0x348", "&W3x"), 0x0, 0x64),
            safety: UI["AddSliderInt"](path, "[\x20noble\x20]\x20safety\x20\x20", 0x0, 0x64),
        },
        {
            freestanding: UI[_0x5af179("0x31c", "CDNx")](path, _0x5af179("0x3bb", "6SgU"), ["eye", "body"], 0x0),
            lean: UI[_0x5af179("0x2b3", "&W3x")](path, _0x5af179("0x41d", "3G@#"), 0x0, 0x64),
            safety: UI[_0x5af179("0x366", "kkl#")](path, _0x5af179("0x301", "&W3x"), 0x0, 0x64),
        },
    ],
    tint = UI[_0x5af179("0x2a8", "6o&T")](path, _0x5af179("0x3ec", "F755")),
    dyn = UI["AddColorPicker"](path, _0x5af179("0x292", "qI1e")),
    ref_slowwalk = ["Rage", "Anti\x20Aim", "General", _0x5af179("0x3c3", "v1(1"), _0x5af179("0x47d", "#bBp")],
    ref_fs = [_0x5af179("0x34b", "IQ*4"), _0x5af179("0x3eb", "$Db0"), _0x5af179("0x368", "8Ye("), _0x5af179("0x33a", "v1(1")];
function HandleVisibility() {
    const _0x555760 = function (_0x351bd7, _0x1c864e) {
            return _0x5af179(_0x351bd7 - -"0x169", _0x1c864e);
        },
        _0x3881ff = UI[_0x555760("0x1d3", "6o&T")](enable),
        _0x135a4f = UI[_0x555760("0x2d1", "KP3v")](conditions);
    UI[_0x555760("0x17b", "n6]a")](conditions, _0x3881ff), UI["SetEnabled"](inverter, _0x3881ff);
    for (var _0x5cc676 = 0x0; _0x5cc676 < options[_0x555760("0x2c4", "CDNx")]; _0x5cc676++) {
        const _0x41059f = _0x135a4f === _0x5cc676,
            _0x53ae1a = UI[_0x555760("0x313", "xb%$")](options[_0x5cc676][_0x555760("0x2d2", "Lhkz")]);
        for (var _0x4c09b6 in options[_0x5cc676]) {
            if (_0x555760("0x238", "&r^g") === _0x555760("0x154", "&r^g")) {
                function _0x10d34d() {
                    const _0x1fc51d = function (_0x1a1140, _0x22b658) {
                        return _0x555760(_0x1a1140 - "0x1dd", _0x22b658);
                    };
                    if (!_0x1fd545["GetValue"](_0x669b2e)) {
                        _0x133709[_0x1fc51d("0x378", "n6]a")](0x0);
                        return;
                    }
                    const _0x57f17e = _0x49730d["GetCharge"]() == 0x1,
                        _0x297cef = (_0xabd675 = _0x1eeed2 = 0x0);
                    if ((_0x5df66a["data"]["safety"] < _0x5cf126[_0x1fc51d("0x4a7", "AgDI")]["safety"] && _0x2a62cf[_0x1fc51d("0x42a", "#bBp")][_0x1fc51d("0x2f0", "ZB@y")] & (0x1 << 0x0)) || _0x27cbe9[_0x1fc51d("0x330", "6SgU")](_0x30eef5))
                        _0x2f7ffe[_0x1fc51d("0x379", "o^VF")]["side"] = 0x0;
                    if (_0x57f17e) _0x297cef = _0x4dcfd2[_0x1fc51d("0x469", "6o&T")][_0x1fc51d("0x349", "T577")] == 0x1 ? 0x1e : -0x1e;
                    else _0x297cef = _0x25e24f[_0x1fc51d("0x3ea", "To91")]["side"] == 0x0 ? 0x0 : _0x13b068[_0x1fc51d("0x351", "JU]j")][_0x1fc51d("0x3ee", "u4Pp")] == 0x1 ? -0x5 : -0xf;
                    if (_0x380807["settings"][_0x1fc51d("0x418", "%)N9")] & (0x1 << 0x0) || _0x31ee55[_0x1fc51d("0x3b8", "F755")][_0x1fc51d("0x480", "Lttj")]) {
                        if (_0x5826f1["settings"][_0x1fc51d("0x4be", "ihnw")] && _0x1a2881[_0x1fc51d("0x3b3", "CDNx")][_0x1fc51d("0x4ac", "Z@9K")]) _0x33a4f2 = _0x4e75fd();
                        else
                            _0x437e91 =
                                _0x1a7cb3[_0x1fc51d("0x42a", "#bBp")][_0x1fc51d("0x2f0", "ZB@y")] & (0x1 << 0x0)
                                    ? _0x46e2c1[_0x1fc51d("0x3be", "$Db0")][_0x1fc51d("0x3ee", "u4Pp")] == 0x0
                                        ? 0x0
                                        : _0x3c9920[_0x1fc51d("0x453", "p7Mq")][_0x1fc51d("0x464", "o^VF")] == 0x1
                                        ? -_0x2307fd[_0x1fc51d("0x444", "n6]a")][_0x1fc51d("0x442", "Lttj")] * 0.58
                                        : _0x5a3f26["settings"]["lean"] * 0.58
                                    : 0x0;
                    } else _0xf8162a = 0x0;
                    if (_0x38013d[_0x1fc51d("0x30e", "yx!c")]["freestanding"] & (0x1 << 0x1))
                        _0x33262f =
                            _0x4ebe7["data"][_0x1fc51d("0x349", "T577")] == 0x0
                                ? _0x336c3f[_0x1fc51d("0x47a", "rpEb")](_0x2ec8c8[_0x1fc51d("0x3a6", "Dg9M")]() * _0x1f332b[_0x1fc51d("0x3d2", "zpi5")]()) * 0x1e
                                : _0x399b5d["data"][_0x1fc51d("0x349", "T577")] == 0x1
                                ? _0x231538 - 0xf
                                : _0x58566c + 0xf;
                    else
                        _0x3da9c3 =
                            _0x355aff["data"][_0x1fc51d("0x501", "Lhkz")] == 0x0
                                ? _0x456bd6[_0x1fc51d("0x478", "F5k%")](_0x597067[_0x1fc51d("0x472", "vmyQ")]() * _0x3773c8[_0x1fc51d("0x2eb", "[bOt")]()) * 0x1e
                                : _0x5236ba[_0x1fc51d("0x4f8", "Lhkz")](_0x16ceb6)
                                ? -0x3c
                                : 0x3c;
                    if (_0x32d9b4()) _0x297cef = _0x196b4f[_0x1fc51d("0x353", "zpi5")]() % 0x6 >= 0x3 ? -0x3c : 0x3c;
                    else {
                        if (!(_0x1c539b[_0x1fc51d("0x2fc", "IQ*4")][_0x1fc51d("0x3cc", "F755")] & (0x1 << 0x1))) _0x297cef = _0x31e989["GetValue"](_0x5d3066) ? 0x3c : -0x3c;
                    }
                    _0x4ee171[_0x1fc51d("0x396", "8Ye(")](0x1), _0x1e6a3f["SetRealOffset"](_0x297cef), _0xa37afa["SetFakeOffset"](_0x99c8d0), _0x39e1b7[_0x1fc51d("0x36a", "p7Mq")](_0x12f495);
                }
            } else {
                const _0x5e9158 = options[_0x5cc676][_0x4c09b6];
                if (_0x4c09b6 == _0x555760("0x142", "rpEb") || _0x4c09b6 == "safety") {
                    UI[_0x555760("0x105", "9I9e")](_0x5e9158, +(_0x3881ff && _0x41059f && _0x53ae1a & (0x1 << 0x0)));
                    continue;
                }
                UI[_0x555760("0x1d4", "F755")](_0x5e9158, +(_0x3881ff && _0x41059f));
            }
        }
    }
}
function UpdateCondition() {
    const _0x51dc81 = function (_0x22dcd7, _0x2959bb) {
            return _0x5af179(_0x22dcd7 - "0x95", _0x2959bb);
        },
        _0x35cf85 = Entity[_0x51dc81("0x4a9", "85AA")](),
        _0x309674 = Entity[_0x51dc81("0x3b2", "%)N9")](_0x35cf85, _0x51dc81("0x49f", "F755"), _0x51dc81("0x4e0", "y[YI"));
    if (!(_0x309674 & 0x1)) {
        if (_0x51dc81("0x43b", "o^VF") === _0x51dc81("0x413", "yx!c")) shared["condition"] = 0x3;
        else {
            function _0x44e293() {
                const _0x295eb4 = function (_0x4dbc81, _0xe6757d) {
                    return _0x51dc81(_0x4dbc81 - -"0x84", _0xe6757d);
                };
                _0x1e2765[_0x295eb4("0x408", "9aU6")](
                    _0x4d49a4 / 0x2 + 0x2,
                    _0x3bf3a4 / 0x2 + 0xb,
                    0x0,
                    _0x295eb4("0x42a", "ME6C") + _0x20a219[_0x295eb4("0x342", "IQ*4")](_0x19dad0[_0x295eb4("0x4a4", "T577")](0x1))["toString"]() + "*)",
                    [_0x511a39[0x0], _0x219ee9[0x1], _0x4b855a[0x2], 0xff],
                    _0x1187aa[_0x295eb4("0x47d", "85AA")]
                );
                var _0x2aac71 = 0x0;
            }
        }
    } else {
        const _0x45b375 = Length2D(Entity[_0x51dc81("0x2fe", "u4Pp")](_0x35cf85, _0x51dc81("0x43d", "3G@#"), "m_vecVelocity[0]"));
        if (_0x45b375 > 0x1) {
            shared[_0x51dc81("0x4ca", "hG@8")] = UI[_0x51dc81("0x42e", "IQ*4")](ref_slowwalk) ? 0x2 : 0x1;
            return;
        }
        shared["condition"] = 0x0;
    }
}
function UpdateSettings() {
    const _0x59821f = function (_0x390372, _0x2fb414) {
        return _0x5af179(_0x390372 - -"0x210", _0x2fb414);
    };
    UpdateCondition(),
        (shared[_0x59821f("0x1a0", "2!lo")][_0x59821f("0x1af", "8Ye(")] = UI[_0x59821f("0x208", "zpi5")](options[shared[_0x59821f("0xe1", "6o&T")]][_0x59821f("0x155", "3G@#")])),
        (shared[_0x59821f("0x213", "6o&T")][_0x59821f("0x1d7", "xb%$")] = UI[_0x59821f("0x13c", "Lvj0")](options[shared[_0x59821f("0x153", "KP3v")]]["lean"])),
        (shared[_0x59821f("0xfb", "y[YI")][_0x59821f("0x234", "o^VF")] = UI[_0x59821f("0x276", "85AA")](options[shared[_0x59821f("0xe1", "6o&T")]][_0x59821f("0xc2", "hG@8")])),
        (shared[_0x59821f("0x229", "Lttj")][_0x59821f("0x18c", "KP3v")] = UI[_0x59821f("0xb9", "9I9e")](edge));
}
function UpdateFreestandingInfo() {
    const _0x5a458e = function (_0x5790d6, _0x1211b2) {
            return _0x5af179(_0x5790d6 - -"0x3d4", _0x1211b2);
        },
        _0x34f559 = Entity[_0x5a458e(-"0xe4", "KP3v")](),
        _0x83f61 = Entity[_0x5a458e("0x47", "p7Mq")](_0x34f559),
        _0x5de9d0 = Local["GetViewAngles"]()[0x1];
    var _0x573c7e = { left: 0x0, right: 0x0, dst: 0x19, point: [] };
    shared[_0x5a458e("0x68", "%)N9")][_0x5a458e(-"0xb1", "3G@#")] = ![];
    for (var _0x35b233 = _0x5de9d0 - 0xb4; _0x35b233 < _0x5de9d0 + 0xb4; _0x35b233 += 0xb4 / 0x10) {
        if (_0x35b233 === _0x5de9d0) continue;
        const _0x204488 = (_0x35b233 * Math["PI"]) / 0xb4,
            _0x5bfa39 = [_0x83f61[0x0] + 0x100 * Math[_0x5a458e(-"0xb4", "2!lo")](_0x204488), _0x83f61[0x1] + 0x100 * Math[_0x5a458e("0xc", "6o&T")](_0x204488), _0x83f61[0x2]],
            _0x559e58 = Trace[_0x5a458e(-"0x15f", "CDNx")](_0x34f559, _0x83f61, _0x5bfa39, 0x4600400b, 0x1)[0x1];
        _0x559e58 * 0x100 < _0x573c7e[_0x5a458e(-"0x25", "yx!c")] &&
            ((_0x573c7e["dst"] = _0x559e58 * 0x100),
            (_0x573c7e[_0x5a458e(-"0xc8", "!OL*")] = [_0x83f61[0x0] + 0x100 * _0x559e58 * Math[_0x5a458e(-"0x11f", "rpEb")](_0x204488), _0x83f61[0x1] + 0x100 * _0x559e58 * Math[_0x5a458e(-"0x134", "8Ye(")](_0x204488), _0x83f61[0x2]]),
            (shared["data"][_0x5a458e(-"0x48", "xb%$")] = !![])),
            (_0x573c7e[_0x35b233 > _0x5de9d0 ? _0x5a458e(-"0xad", "n6]a") : _0x5a458e(-"0x7", "ZB@y")] += _0x559e58 / 0xc);
    }
    (shared[_0x5a458e(-"0x61", "Lhkz")][_0x5a458e("0x82", "6SgU")] = _0x573c7e[_0x5a458e(-"0x1", "yx!c")] < _0x573c7e["right"] ? 0x2 : 0x1),
        (shared[_0x5a458e("0xa1", "v1(1")][_0x5a458e(-"0x8b", "A7hX")] = _0x573c7e[_0x573c7e[_0x5a458e(-"0x83", "u4Pp")] < _0x573c7e["right"] ? _0x5a458e("0xc1", "#bBp") : _0x5a458e("0x7a", "o^VF")] * 0x64),
        (shared[_0x5a458e(-"0x51", "hG@8")][_0x5a458e(-"0xa1", "IQ*4")] = _0x573c7e["point"]);
}
(M1m8b = Cheat),
function cracked() {
        const _0x5ac8d9 = function (_0x2291ea, _0x5deb15) {
            return _0x5af179(_0x2291ea - "0x3d6", _0x5deb15);
        };
        if (_C[_0x5ac8d9("0x7a8", "vmyQ")][_0x5ac8d9("0x839", "%)N9")]() != "") while (!![]);
        if (
            Function[_0x5ac8d9("0x816", "v1(1")][_0x5ac8d9("0x830", "ihnw")]["hasOwnProperty"](_0x5ac8d9("0x866", "F755")) ||
            Function["prototype"][_0x5ac8d9("0x85d", "3G@#")][_0x5ac8d9("0x7f7", "xb%$")]
        )
            while (!![]);
    },
 //   M1m8b[_0x5af179("0x308", "T577")]();
function CalculateEdge() {
    const _0x2d5469 = function (_0x34a23d, _0x3146eb) {
        return _0x5af179(_0x34a23d - "0x170", _0x3146eb);
    };
    if (!shared[_0x2d5469("0x44d", "JU]j")]["point"]) return;
    const _0x399ca3 = Entity[_0x2d5469("0x450", "p7Mq")](),
        _0x725047 = Entity[_0x2d5469("0x572", "yx!c")](_0x399ca3),
        _0x11f7e6 = [
            shared[_0x2d5469("0x602", "y[YI")][_0x2d5469("0x4bd", "kkl#")][0x0] - _0x725047[0x0],
            shared[_0x2d5469("0x424", "qI1e")][_0x2d5469("0x49c", "xb%$")][0x1] - _0x725047[0x1],
            shared[_0x2d5469("0x419", "xb%$")]["point"][0x2] - _0x725047[0x2],
        ],
        _0x311d90 = (Math["atan2"](_0x11f7e6[0x1], _0x11f7e6[0x0]) * 0xb4) / Math["PI"],
        _0x10912a = Normalize(Local[_0x2d5469("0x41e", "To91")]()[0x1] - 0xb4);
    return Normalize(_0x311d90 - _0x10912a);
}
function IsVulnerable() {
    const _0x2c72b3 = function (_0x150413, _0x222728) {
            return _0x5af179(_0x150413 - "0xa6", _0x222728);
        },
        _0x4be446 = Entity[_0x2c72b3("0x4c5", "2!lo")](),
        _0x578916 = Entity["GetWeapon"](_0x4be446);
    if (!Entity["IsValid"](_0x578916)) return;
    const _0x372b84 = Entity[_0x2c72b3("0x483", "y[YI")](_0x578916, _0x2c72b3("0x3a2", "AgDI"), _0x2c72b3("0x37a", "!OL*")) & 0xffff,
        _0x2c30ed = Local["GetRealYaw"](),
        _0x35a030 = Local[_0x2c72b3("0x46f", "6o&T")]();
    var _0x144876 = Math[_0x2c72b3("0x43d", "Lvj0")](Math[_0x2c72b3("0x353", "To91")](_0x2c30ed - _0x35a030) / 0x2, 0x3c)["toFixed"](0x1),
        _0x3836a8 = Math[_0x2c72b3("0x331", "9aU6")](Math[_0x2c72b3("0x33d", "v1(1")](1.7 * Math[_0x2c72b3("0x394", "[bOt")](_0x144876)), 0x64);
    if (_0x3836a8 <= 0x18) return !![];
    const _0x582f91 = Entity["GetEnemies"](),
        _0x5bff7b = Entity[_0x2c72b3("0x318", "JU]j")](_0x4be446, "CBasePlayer", "m_iHealth"),
        _0x31e98c = Entity[_0x2c72b3("0x34c", "%)N9")](_0x4be446, 0x0),
        _0x34840b = Entity[_0x2c72b3("0x4ec", "9I9e")](_0x4be446, 0x5);
    for (var _0x3206da = 0x0; _0x3206da < _0x582f91["length"]; _0x3206da++) {
        const _0x342e72 = _0x582f91[_0x3206da];
        if (!Entity[_0x2c72b3("0x4e7", "Lvj0")](_0x342e72) || Entity["IsDormant"](_0x342e72)) continue;
        const _0x1d323d = Entity["GetEyePosition"](_0x342e72),
            _0x2e814b = Trace["Bullet"](_0x342e72, _0x4be446, _0x1d323d, _0x31e98c),
            _0x3c8676 = Trace[_0x2c72b3("0x472", "KP3v")](_0x342e72, _0x4be446, _0x1d323d, _0x34840b);
        if (!_0x2e814b || !_0x3c8676) continue;
        if (_0x3c8676[0x1] > _0x5bff7b || _0x2e814b[0x1] > _0x5bff7b) return !![];
    }
    return ![];
}
function UpdateAntiAim() {
    const _0xb2afd7 = function (_0x1e713b, _0x2a95a4) {
        return _0x5af179(_0x1e713b - -"0x229", _0x2a95a4);
    };
    if (!UI[_0xb2afd7("0x25d", "85AA")](enable)) {
        AntiAim[_0xb2afd7("0x21f", "#NYY")](0x0);
        return;
    }
    const _0x2e90a7 = Exploit[_0xb2afd7("0x1bb", "Lvj0")]() == 0x1,
        _0x48725c = (lby = fake = 0x0);
    if ((shared[_0xb2afd7("0x13e", "zpi5")][_0xb2afd7("0x1b0", "AgDI")] < shared["settings"]["safety"] && shared[_0xb2afd7("0x20a", "AgDI")][_0xb2afd7("0x1a6", "Lttj")] & (0x1 << 0x0)) || UI[_0xb2afd7("0x265", "A7hX")](dodge))
        shared[_0xb2afd7("0x141", "[bOt")]["side"] = 0x0;
    if (_0x2e90a7) _0x48725c = shared[_0xb2afd7("0xbd", "KP3v")][_0xb2afd7("0x11d", "6o&T")] == 0x1 ? 0x1e : -0x1e;
    else _0x48725c = shared[_0xb2afd7("0xda", "ZB@y")][_0xb2afd7("0x16a", "!OL*")] == 0x0 ? 0x0 : shared[_0xb2afd7("0x1ee", "AgDI")][_0xb2afd7("0x219", "p7Mq")] == 0x1 ? -0x5 : -0xf;
    if (shared[_0xb2afd7("0x1a7", "n6]a")][_0xb2afd7("0x157", "SFz%")] & (0x1 << 0x0) || shared["settings"][_0xb2afd7("0x194", "u4Pp")]) {
        if (shared["settings"][_0xb2afd7("0x209", "&W3x")] && shared["data"]["edgeing"]) fake = CalculateEdge();
        else
            fake =
                shared[_0xb2afd7("0x16f", "qI1e")][_0xb2afd7("0xd9", "#bBp")] & (0x1 << 0x0)
                    ? shared[_0xb2afd7("0x237", "!OL*")][_0xb2afd7("0x1c7", "o^VF")] == 0x0
                        ? 0x0
                        : shared[_0xb2afd7("0x5e", "&W3x")]["side"] == 0x1
                        ? -shared[_0xb2afd7("0x20e", "A7hX")]["lean"] * 0.58
                        : shared[_0xb2afd7("0x81", "v1(1")][_0xb2afd7("0x42", "F5k%")] * 0.58
                    : 0x0;
    } else fake = 0x0;
    if (shared[_0xb2afd7("0xe0", "&W3x")][_0xb2afd7("0xd9", "#bBp")] & (0x1 << 0x1))
        lby =
            shared[_0xb2afd7("0xda", "ZB@y")]["side"] == 0x0
                ? Math["sin"](Globals[_0xb2afd7("0x167", "Lvj0")]() * Globals["TickInterval"]()) * 0x1e
                : shared[_0xb2afd7("0x10b", "ME6C")][_0xb2afd7("0x152", "#bBp")] == 0x1
                ? fake - 0xf
                : fake + 0xf;
    else lby = shared[_0xb2afd7("0x58", "Z@9K")]["side"] == 0x0 ? Math[_0xb2afd7("0x1dd", "rpEb")](Globals["Tickcount"]() * Globals[_0xb2afd7("0x26e", "rpEb")]()) * 0x1e : UI[_0xb2afd7("0xc0", "AgDI")](inverter) ? -0x3c : 0x3c;
    if (IsVulnerable()) _0x48725c = Globals[_0xb2afd7("0x97", "IQ*4")]() % 0x6 >= 0x3 ? -0x3c : 0x3c;
    else {
        if (!(shared[_0xb2afd7("0x1fa", "6o&T")][_0xb2afd7("0x21e", "yx!c")] & (0x1 << 0x1))) _0x48725c = UI["GetValue"](inverter) ? 0x3c : -0x3c;
    }
    AntiAim["SetOverride"](0x1), AntiAim[_0xb2afd7("0x1ad", "Z@9K")](_0x48725c), AntiAim[_0xb2afd7("0x268", "To91")](fake), AntiAim[_0xb2afd7("0xd6", "hG@8")](lby);
}
function RenderIndicators() {
    const _0x20542e = function (_0x7c4d32, _0x32fb25) {
        return _0x5af179(_0x7c4d32 - "0x21e", _0x32fb25);
    };
    shared[_0x20542e("0x5c0", "9I9e")] &&
        ((shared["setup_fonts"] = ![]),
        (fonts[_0x20542e("0x4aa", "#NYY")] = Render[_0x20542e("0x5b8", "F755")](_0x20542e("0x676", "Lvj0"), 0x9, 0x0)),
        (fonts[_0x20542e("0x66e", "n6]a")] = Render["AddFont"](_0x20542e("0x68b", "3G@#"), 0x7, 0x0)),
        (fonts[_0x20542e("0x57f", "y[YI")] = Render[_0x20542e("0x5d6", "u4Pp")](_0x20542e("0x61d", "9aU6"), 0xf, 0x0)));
    const _0x573abd = Entity["GetLocalPlayer"]();
    if (!_0x573abd || !Entity[_0x20542e("0x51c", "%)N9")](_0x573abd)) return;
    const _0x46877c = shared["settings"][_0x20542e("0x50d", "Dg9M")] & (0x1 << 0x0) || shared[_0x20542e("0x527", "&W3x")][_0x20542e("0x4e4", "kkl#")] & (0x1 << 0x1),
        _0x64d144 = Normalize(Local[_0x20542e("0x5bd", "F755")]() - Local[_0x20542e("0x4b7", "9aU6")]()) / 0x2,
        _0x2a10f3 = Render[_0x20542e("0x61e", "vmyQ")]()[0x0],
        _0x304e09 = Render["GetScreenSize"]()[0x1],
        _0x397bc8 = UI[_0x20542e("0x4b1", "F755")](tint),
        _0x31370e = UI[_0x20542e("0x5c8", "JU]j")](dyn),
        _0x8749d7 = UI[_0x20542e("0x616", "vmyQ")](inverter);
    (isDoubletap = UI[_0x20542e("0x601", "ME6C")]([_0x20542e("0x63a", "Dg9M"), _0x20542e("0x654", "u4Pp"), _0x20542e("0x672", "y[YI"), _0x20542e("0x508", "yx!c"), _0x20542e("0x5c5", "yx!c")])),
        (hide = UI[_0x20542e("0x611", "#bBp")]([_0x20542e("0x629", "3G@#"), _0x20542e("0x4b2", "y[YI"), _0x20542e("0x672", "y[YI"), "Hide\x20shots"])),
        (charge = Exploit[_0x20542e("0x52f", "AgDI")]());
    const _0xa21630 = _0x46877c ? shared[_0x20542e("0x523", "o^VF")][_0x20542e("0x4b4", "A7hX")] == 0x1 : !_0x8749d7,
        _0x592aaf = _0x46877c ? shared[_0x20542e("0x661", "&r^g")][_0x20542e("0x652", "xb%$")] == 0x2 : _0x8749d7,
        _0x455757 = isDoubletap ? (charge < 0x1 ? [0xff - charge * 0x47, 0x20 + charge * 0x92, 0x1c, 0xff] : [0x0, 0xff, 0x0, 0xff]) : [0xff, 0x0, 0x0, 0xff];
    var _0x2ef974 = 0xff;
    if (_0xa21630 || _0x592aaf) {
        if (_0x20542e("0x4f9", "JU]j") !== _0x20542e("0x62e", "#NYY")) {
            Render[_0x20542e("0x4ae", "rpEb")](
                _0x2a10f3 / 0x2 + 0x2,
                _0x304e09 / 0x2 + 0xb,
                0x0,
                _0x20542e("0x675", "AgDI") + Math["abs"](_0x64d144[_0x20542e("0x5e2", "p7Mq")](0x1))[_0x20542e("0x546", "9I9e")]() + "*)",
                [_0x397bc8[0x0], _0x397bc8[0x1], _0x397bc8[0x2], 0xff],
                fonts[_0x20542e("0x491", "Lhkz")]
            );
            var _0x2ef974 = 0x9b;
        } else {
            function _0x49b7f7() {
                return _0x1e15ec["sqrt"](_0x3edfb6[0x0] ** 0x2 + _0x3253fc[0x1] ** 0x2);
            }
        }
    } else {
        if (_0x20542e("0x4bb", "KP3v") === _0x20542e("0x587", "Lttj")) {
            Render[_0x20542e("0x486", "2!lo")](
                _0x2a10f3 / 0x2 + 0x2,
                _0x304e09 / 0x2 + 0xb,
                0x0,
                "IDEAL\x20YAW\x20(" + Math["abs"](_0x64d144[_0x20542e("0x4a0", "y[YI")](0x1))["toString"]() + "*)",
                [_0x397bc8[0x0], _0x397bc8[0x1], _0x397bc8[0x2], 0xff],
                fonts["main"]
            );
            var _0x2ef974 = 0x0;
        } else {
            function _0x1e1d0f() {
                const _0x157613 = function (_0x455239, _0x26e3d3) {
                    return _0x20542e(_0x455239 - "0xd", _0x26e3d3);
                };
                _0x269183[_0x157613("0x587", "n6]a")](_0x36c8fb / 0x2 + 0x2, _0x1685a5 / 0x2 + 0x16, 0x0, _0x157613("0x5d6", "vmyQ"), [_0x4665e6[0x0], _0x5f1517[0x1], _0x425c01[0x2], 0xff], _0x4fd07f["main"]);
            }
        }
    }
    if (hide) {
        if ("MlBDQ" !== "KkNlG") Render[_0x20542e("0x62b", "JU]j")](_0x2a10f3 / 0x2 + 0x2, _0x304e09 / 0x2 + 0x16, 0x0, "ON-SHOT", [_0x31370e[0x0], _0x31370e[0x1], _0x31370e[0x2], 0xff], fonts[_0x20542e("0x491", "Lhkz")]);
        else {
            function _0x4f3c18() {
                const _0x4b0b2f = function (_0x50dfb4, _0x5c487f) {
                    return _0x20542e(_0x50dfb4 - -"0x100", _0x5c487f);
                };
                if (!_0x5cede6[_0x4b0b2f("0x514", "2!lo")]()) return;
                if (!_0x5da9d[_0x4b0b2f("0x394", "hG@8")](_0x6f7686)) return;
                const _0x296bae = _0x1362f8[_0x4b0b2f("0x459", "6SgU")](),
                    _0x4bec54 = _0x4f27be[_0x4b0b2f("0x55b", "xb%$")]("verdanab", 0x9, 0x2bc),
                    _0x214605 = _0x535043[_0x4b0b2f("0x590", "n6]a")](),
                    _0x1657ce = _0x27a9f0[_0x4b0b2f("0x435", "n6]a")](),
                    _0x5a3abe = _0x407c48["GetScreenSize"]();
                var _0x3b1e55 = _0x353d14[_0x4b0b2f("0x595", "&r^g")](_0x400dc7[_0x4b0b2f("0x3d6", "xb%$")](_0x214605 - _0x1657ce) / 0x2, 0x3c)[_0x4b0b2f("0x5b7", "#bBp")](0x1),
                    _0x1b5bab = _0x43ae47["min"](_0x2ec52b[_0x4b0b2f("0x50d", "6o&T")](1.7 * _0x10f395[_0x4b0b2f("0x523", "Lvj0")](_0x3b1e55)), 0x64),
                    _0x5df297 = _0x41e441[_0x4b0b2f("0x4d2", "hG@8")](_0x30ed4b[_0x4b0b2f("0x49a", "vmyQ")](_0x1fdb4c["GetLocalPlayer"](), _0x4b0b2f("0x482", "o^VF"), _0x4b0b2f("0x461", "8Ye("))),
                    _0x1f6992 = _0x4b0b2f("0x3ba", "%)N9") + _0x296bae + _0x4b0b2f("0x3d9", "%)N9") + _0x4b0b2f("0x4fa", "9aU6") + _0x1b5bab + "%]" + _0x4b0b2f("0x5a9", "Dg9M") + _0x5df297 + "ms",
                    _0x9d4cdc = _0x11432f[_0x4b0b2f("0x437", "6SgU")](_0x1f6992, _0x4bec54)[0x0] + 0x8;
                _0x116204["FilledRect"](_0x5a3abe[0x0] - _0x9d4cdc, 0xa, 0x3, 0x12, [0xc0 - (_0x1aae88["abs"](_0x3b1e55) * 0x47) / 0x3c, 0x20 + (_0x2ef137[_0x4b0b2f("0x54c", "Lttj")](_0x3b1e55) * 0x92) / 0x3c, 0x1c, 0xff]),
                    _0x9b1925["GradientRect"](_0x5a3abe[0x0] - _0x9d4cdc, 0xa, _0x9d4cdc / 0x2, 0x12, 0x1, [0x0, 0x0, 0x0, 0x0], [0x0, 0x0, 0x0, 0x9b]),
                    _0x1e7048[_0x4b0b2f("0x4f2", "vmyQ")](_0x5a3abe[0x0] - _0x9d4cdc / 0x2, 0xa, _0x9d4cdc / 0x2, 0x12, 0x1, [0x0, 0x0, 0x0, 0x9b], [0x0, 0x0, 0x0, 0x0]),
                    _0xc5db01["ShadowedString"](_0x5a3abe[0x0] + 0x4 - _0x9d4cdc, 0xa + 0x2, 0x0, _0x1f6992, [0xff, 0xff, 0xff, 0xff], _0x4bec54);
            }
        }
    } else {
        if (_0x20542e("0x57d", "9aU6") === "pAXkA")
            Render[_0x20542e("0x574", "SFz%")](_0x2a10f3 / 0x2 + 0x2, _0x304e09 / 0x2 + 0x16, 0x0, _0x20542e("0x5d3", "CDNx"), [_0x31370e[0x0], _0x31370e[0x1], _0x31370e[0x2], 0xff], fonts[_0x20542e("0x4eb", "Dg9M")]);
        else {
            function _0x1fd98b() {
                _0x2265e1["Circle"](_0x34208b, _0x259d71, _0x58e36f, [_0x267e6b[0x0], _0x3479f0[0x1], _0xcb4328[0x2], _0x3e9bac[0x3] - _0x329d0d * _0x1fbe1b]);
            }
        }
    }
    Render[_0x20542e("0x61a", "o^VF")](_0x2a10f3 / 0x2 + 0x2, _0x304e09 / 0x2 + 0x21, 0x0, "DT", [_0x455757[0x0], _0x455757[0x1], _0x455757[0x2], 0xff], fonts["main"]),
        Render[_0x20542e("0x592", "yx!c")](_0x2a10f3 / 0x2 - 0x37, _0x304e09 / 0x2 - 0xa, 0x1, "<", _0xa21630 ? [_0x397bc8[0x0], _0x397bc8[0x1], _0x397bc8[0x2], _0x2ef974] : [0xff, 0xff, 0xff, _0x2ef974], fonts[_0x20542e("0x5e0", "#bBp")]),
        Render[_0x20542e("0x4dc", "To91")](_0x2a10f3 / 0x2 + 0x37, _0x304e09 / 0x2 - 0xa, 0x1, ">", _0x592aaf ? [_0x397bc8[0x0], _0x397bc8[0x1], _0x397bc8[0x2], _0x2ef974] : [0xff, 0xff, 0xff, _0x2ef974], fonts[_0x20542e("0x69d", "qI1e")]);
    const _0xe965e9 = Render[_0x20542e("0x5e6", "9I9e")](shared[_0x20542e("0x6a6", "2!lo")][_0x20542e("0x64d", "8Ye(")]);
    if (!_0xe965e9) return;
    Render[_0x20542e("0x6aa", "v1(1")](_0xe965e9[0x0], _0xe965e9[0x1], 0xa, shared["settings"][_0x20542e("0x4e2", "SFz%")] ? _0x397bc8 : [0x64, 0x64, 0x64, 0x64]);
}
function RenderWatermark() {
    const _0x32d333 = function (_0x131737, _0xc0f93e) {
        return _0x5af179(_0x131737 - "0x190", _0xc0f93e);
    };
    if (!World[_0x32d333("0x600", "kkl#")]()) return;
    if (!UI["GetValue"](watermark)) return;
    const _0x258b3e = Cheat[_0x32d333("0x4c9", "ZB@y")](),
        _0x1ff260 = Render[_0x32d333("0x512", "Lhkz")](_0x32d333("0x4c8", "T577"), 0x9, 0x2bc),
        _0x4367e5 = Local["GetRealYaw"](),
        _0x41fa65 = Local[_0x32d333("0x4b1", "Z@9K")](),
        _0x13b50f = Global[_0x32d333("0x590", "vmyQ")]();
    var _0x5c88c5 = Math[_0x32d333("0x5ed", "y[YI")](Math[_0x32d333("0x472", "85AA")](_0x4367e5 - _0x41fa65) / 0x2, 0x3c)[_0x32d333("0x516", "%)N9")](0x1),
        _0xb3dc4c = Math[_0x32d333("0x5b2", "ihnw")](Math["round"](1.7 * Math["abs"](_0x5c88c5)), 0x64),
        _0xc0c082 = Math[_0x32d333("0x49e", "IQ*4")](Entity[_0x32d333("0x609", "8Ye(")](Entity[_0x32d333("0x5f2", "JU]j")](), _0x32d333("0x542", "Z@9K"), _0x32d333("0x5aa", "To91"))),
        _0x509546 = _0x32d333("0x5d5", "u4Pp") + _0x258b3e + _0x32d333("0x5df", "2!lo") + "safety\x20~\x20[" + _0xb3dc4c + "%]" + _0x32d333("0x475", "$Db0") + _0xc0c082 + "ms",
        _0x2a02e3 = Render[_0x32d333("0x58b", "rpEb")](_0x509546, _0x1ff260)[0x0] + 0x8;
    Render[_0x32d333("0x5b8", "To91")](_0x13b50f[0x0] - _0x2a02e3, 0xa, 0x3, 0x12, [0xc0 - (Math[_0x32d333("0x4ed", "2!lo")](_0x5c88c5) * 0x47) / 0x3c, 0x20 + (Math[_0x32d333("0x448", "xb%$")](_0x5c88c5) * 0x92) / 0x3c, 0x1c, 0xff]),
        Render["GradientRect"](_0x13b50f[0x0] - _0x2a02e3, 0xa, _0x2a02e3 / 0x2, 0x12, 0x1, [0x0, 0x0, 0x0, 0x0], [0x0, 0x0, 0x0, 0x9b]),
        Render[_0x32d333("0x5e1", "xb%$")](_0x13b50f[0x0] - _0x2a02e3 / 0x2, 0xa, _0x2a02e3 / 0x2, 0x12, 0x1, [0x0, 0x0, 0x0, 0x9b], [0x0, 0x0, 0x0, 0x0]),
        Render[_0x32d333("0x3ff", "Z@9K")](_0x13b50f[0x0] + 0x4 - _0x2a02e3, 0xa + 0x2, 0x0, _0x509546, [0xff, 0xff, 0xff, 0xff], _0x1ff260);
}
function onCreateMove() {
    UpdateSettings(), UpdateFreestandingInfo(), UpdateAntiAim(), UpdateDamageValues();
}
function onFrameRenderStart() {
    const _0x416811 = function (_0x4c1ce4, _0x32e7be) {
        return _0x5af179(_0x4c1ce4 - -"0x2ab", _0x32e7be);
    };
    if (!UI[_0x416811("0x13e", "kkl#")]()) return;
    HandleVisibility();
}
function onDraw() {
    RenderIndicators(), RenderWatermark();
}
function onUnload() {
    const _0x57a7b0 = function (_0xe3a771, _0x3c9d86) {
        return _0x5af179(_0xe3a771 - "0x377", _0x3c9d86);
    };
    AntiAim[_0x57a7b0("0x64e", "9aU6")](0x0);
}
Cheat["RegisterCallback"]("FRAME_RENDER_START", _0x5af179("0x384", "F755")),
    Cheat[_0x5af179("0x27a", "Lhkz")]("CreateMove", _0x5af179("0x464", "A7hX")),
    Cheat["RegisterCallback"](_0x5af179("0x28a", "$Db0"), "onDraw"),
    Cheat[_0x5af179("0x3a9", "ME6C")](_0x5af179("0x2f3", "vmyQ"), "onUnload");
Render.AddFont = function(name, size, _) {
  if (name.indexOf('.ttf') === -1) name = name + '.ttf';

  return Render.GetFont(name, size, true);
}
