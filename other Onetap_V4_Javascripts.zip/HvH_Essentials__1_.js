var var_0x10b5 = ['uhjPBNq=', 'uhjPBNrdAgf0', 'uhjPBNrdB2XVCG==', 'uMvNAxn0zxjdywXSyMfJAW==', 'rxHLy3v0zunVBw1HBMq=', 'rNjHBwvtDgfNzq==', 'vgLJA2nVDw50', 'vgLJA3jHDgu=', 'vgLJA0LUDgvYDMfS', 'q3vYDgLTzq==', 'uMvHBhrPBwu=', 'rNjHBwv0Aw1L', 'tgf0zw5JEq==', 'r2v0vMLLD0fUz2XLCW==', 'u2v0vMLLD0fUz2XLCW==', 'r2v0twfWtMfTzq==', 'sxnlzxLqCMvZC2vK', 'r2v0u2nYzwvUu2L6zq==', 'r2v0q3vYC29Yug9ZAxrPB24=', 'ugXHEvnVDw5K', 'ugXHEu1Py3jVCgHVBMu=', 'u3rVCe1Py3jVCgHVBMu=', 'r2v0vxnLCM5HBwu=', 'u2v0q2XHBLrHzW==', 'ugXHEq==', 'CgfPBNq=', 'rhjHDW==', 'y3jLyxrLx21VDMu=', 'q3jLyxrLtw92zq==', 'zNnU', 'rNjHBwvtDgfNzu5VDgLMEq==', 'r2v0uMvHBfLHDW==', 'r2v0rMfRzvLHDW==', 'r2v0u3bYzwfK', 'r2v0sw5Hy2n1CMfJEq==', 'r2v0u2vYDMvYu3rYAw5N', 'u3rYAw5N', 'vgv4DfnPEMu=', 'tgLUzq==', 'uMvJDa==', 'rMLSBgvKuMvJDa==', 'r3jHzgLLBNrszwn0', 'q2LYy2XL', 'rMLSBgvKq2LYy2XL', 'ug9SEwDVBG==', 'v29YBgruB1nJCMvLBG==', 'qwrKrM9UDa==', 'rMLUzezVBNq=', 'u3rYAw5Nq3vZDg9T', 'vgv4DhvYzwrszwn0', 'qwrKvgv4DhvYzq==', 'vgv4DfnPEMvdDxn0B20=', 'r2v0vMfSDwu=', 'u2v0vMfSDwu=', 'qwrKq2HLy2TIB3G=', 'qwrKu2XPzgvYsw50', 'qwrKu2XPzgvYrMXVyxq=', 'qwrKsg90A2v5', 'qwrKtgfIzwW=', 'qwrKrhjVCgrVD24=', 'qwrKtxvSDgLeCM9Wzg93BG==', 'qwrKq29SB3jqAwnRzxi=', 'qwrKvgv4DgjVEa==', 'u2v0rw5HyMXLza==', 'r2v0u3rYAw5N', 'r2v0q29SB3i=', 'u2v0q29SB3i=', 'vg9Nz2XLsg90A2v5', 'sxnnzw51t3bLBG==', 'r2v0sw50', 'u2v0sw50', 'r2v0rMXVyxq=', 'u2v0rMXVyxq=', 'u2v0u3rYAw5N', 'r2v0rw50AxrPzxm=', 'r2v0rw50AxrPzxncEunSyxnZsuq=', 'r2v0ugXHEwvYCW==', 'r2v0rw5LBwLLCW==', 'r2v0vgvHBw1HDgvZ', 'r2v0tg9JywXqBgf5zxi=', 'r2v0r2fTzvj1BgvZuhjVEhK=', 'r2v0rw50Axr5rNjVBvvZzxjjra==', 'sxnuzwfTBwf0zq==', 'sxnfBMvTEq==', 'sxncB3q=', 'sxnmB2nHBfbSyxLLCG==', 'sxnwywXPza==', 'sxnbBgL2zq==', 'sxneB3jTyw50', 'r2v0q2XHC3njra==', 'r2v0q2XHC3noyw1L', 'r2v0tMfTzq==', 'r2v0v2vHCg9U', 'r2v0v2vHCg9UCW==', 'r2v0uMvUzgvYt3jPz2LU', 'r2v0uhjVCa==', 'u2v0uhjVCa==', 'r2v0sgL0yM94ug9ZAxrPB24=', 'r2v0rxLLug9ZAxrPB24=', 'qNvSBgv0', 'u2v0tw92zw1LBNq=', 'r2v0tw92zw1LBNq=', 'u2v0qw5NBgvZ', 'rM9Yy2vkDw1W', 'rM9Yy2vdCM91y2G=', 'r2v0t3zLCNjPzgu=', 'u2v0t3zLCNjPzgu=', 'u2v0uMvHBe9MzNnLDa==', 'u2v0rMfRzu9MzNnLDa==', 'u2v0tejzt2zMC2v0', 'r2v0q2HHCMDL', 'uMvJAgfYz2u=', 'rgLZywjSzvjLy2HHCMDL', 'rw5HyMXLuMvJAgfYz2u=', 't3zLCNjPzgviAxrJAgfUy2u=', 't3zLCNjPzgvby2n1CMfJEujVB3n0', 't3zLCNjPzgvnDwX0AxbVAw50u2nHBgu=', 'rM9Yy2vtywzLDhK=', 'qwrKu3vIvgfI', 'uMfNzq==', 'u1vcvefcx01huG==', 'shziievZC2vUDgLHBhm=', 'u0HfrvrFtuDs', 'r2vUzxjHBa==', 's2v5igfZC2LNBM1LBNq=', 'rg9Kz2uGyNj1DgvMB3jJzq==', 'rg9Kz2u=', 'v2fPDcbMB3iGB24GC2HVDcbIywnRDhjHy2S=', 'v2fPDgLUzYbMB3iGC2HVDa==', 'uMv2zxjZzwqGzNjLzxn0yw5KAw5N', 'rgvZEw5Jig9UihvZzq==', 'u2fMzsbWB2LUDcbVBIbSAw1ICW==', 'uMfNzwjVDcbMAxjLigXVz3m=', 'sw5ZDgfUDcbKB3vIBgv0yxa=', 'sw5ZDgfUDcbYzwnOyxjNzq==', 't3zLCNjPzguGBwLUAw11BsbKBwCGA2v5', 't3zLCNjPzguGBwLUAw11BsbKBwC=', 'twLUAw11BsbKyw1Hz2u=', 'sw5KAwnHDg9YCW==', 'rhjHDYbirufel0jbsu0GzMXHz3m=', 'rhjHDYbtquzfigzSywDZ', 'rhjHDYbKyw5NzxiGC2LNBNm=', 'rhjHDYbWCMvKAwn0zwqGzgfTywDL', 'sw52zxj0zxiGyxjYB3DZ', 'sw52zxj0zxiGyxjYB3DZignVBg9Y', 'rMvHDhvYzxmGDg8GzgLZCgXHEq==', 'rg91yMXLDgfW', 'sgLKzsbZAg90CW==', 'u2fMzsbWB2LUDa==', 't3zLCNjPzguGBwLUigrTzW==', 'rw5HyMXLigHLywqVyMfPBsbJB25KAxrPB25Z', 'uhjLzgLJDcbKB3vIBgv0yxaGzgfTywDL', 'rM9Yy2uGsevbrcbJB25KAxrPB25Z', 'sw5Hy2n1CMf0zsbKzxn5BMm=', 'vgfYz2v0igLZigLUigfPCG==', 'vgfYz2v0ignYB3vJAgLUzYaOvcbZAwrLkq==', 'u2HVDa==', 'sw5Hy2n1CMf0zsbKzxn5BMmGzgvSDge=', 'rM9Yy2uGqKfjtsbJB25KAxrPB25Z', 'swyGBgv0AgfS', 'swyGC2XVDYb3ywXRAw5N', 'swyGC3rHBMrPBMC=', 'swyGDgfYz2v0igLUigfPCG==', 'q3jVDwnOAw5N', 'rM9Yy2uGu0fgrvbpsu5uignVBMrPDgLVBNm=', 'u2f2zsbgufm=', 'sNvTCcbZy291Dc9YzxzVBhzLCIbOAxrJAgfUy2u=', 'sgL0y2HHBMnL', 't3zLCNjPzguGBM8GC2nVCguGAgL0y2HHBMnL', 'tM8GC2nVCguGAgL0y2HHBMnL', 'D2vIC3rLCNXHD3aXmtj8zhi5odG2n3XYyxL8BgLZChbSyxLLCMH2AhXTywTLAxrIAwD8ywX5BNPLD3XMAw5UEtm0mZn8zgvPDhL8EMfSzhL8CxvHA2vODMH8C2HPzNrVFgjNyMvUAMfTAw4XFgr5BgfUy3XTzwr1C2fHEhXZywrLBMPTAxrOFgL0EM5PAwnVFgD2AZi3FgT5BguZmZiYm3XQywT1yMv6ENW1nZC3nZD8C2TLBgv0B25PBxbYB3zLzhXYnhHLCJf8BgL6yxv3DxXIzgL0DhX4DMfZDxXPBxbLy3vUAxr5FgP2DNz8C291Bgf3ywTLBJeXmdn8BwvSB25IzwfYFg5HzgLUzgL8z3jLz29YEwjYDwH8DgHLC2H5mteYFgrPBMTLBgjLCMD8DhvKB3jJB3n0ztj8yMjODMHOFhjHDwrLFhrHEwXVDwWWBhXHDNj4Fg1HBM9Mz29KFhDREgqXnNX3yxjWzwrPCMLZAhXIDwvYDNXKmZrUD3LUFhvTAxjHBMHHyxXYEwfUDgHLCgfUzgf8z3jLzw5JB2jYyxXTzxjJEw1HBwjHFgXLztaXodf8AwX1y2TICNXZAw1Pyw42nJz8ywT1BgXHFgDHyNX2yxrYyxH8AhzOA2LSBgvYFhbVBgLZAdeYmJD8yMLNAxXOyxDPENX0AgvNzw5LCMfSz3v5FhP1C2vRAwXSzxj8A3jHAMv3C2TPmtj8mw1HCNrPBNXLDwDLAZn8ywX3yxLZmZiXmZeYmZeYFgTKzw58zgvHzgfMFgDVzgXLC3n8CgfYyxnPDgLZy2H8AMHLzxXZBM5Py2T8C3vPFgXPBwL0FgfKCJfHBNXPzg9UDgTUB3DOB3XUB3vPC2jHzxXZBM9VEMv8A3jVBNP5Fg5Py2T2m3XZAwDUywX8D29VzMnZz298z3j1Bxb5mxXRCM9ZAgLVDxX5B25PFhnIBxzUFgjPBgX5mJiZmJr8C3rLCgLUChj8A2f5DhvZAgf8B3nRDxXQD2vPBgfNzxXWCMvJBgLRFhf3zxj0EwDHBwvYmtiYn3XZBMLWAxXKCMfOB2THBxXZDg9UzxX4zwXSB3XHCNvZFgfZAdi4nJa0FgX1A2f6zwX8zwr3yxjKzMX5Fg5TDgHLz29HDhXJmgjYnhXHBM9UotKWFhrPBNrLzhX3DgH6nti0mhXRzxP5y3n8zgzLCMDZzxXSB29ZzxXXC3DHAw58yM9NzgfUntz8D2fKyxnWCM98C2XLzwTLCNXJyxP6ENbLCNXJB29SA2LKENXTyxPPA3X4zw58Bg9Yzgj5CM9UFgr4z2fTzxj3yxi4otb8zMvYnJy2Fg10EJeZmZD8A29YBMvSFgD1DxX0zxn0Aw5NEgr8A3jVA298EgnOyw5NztK1Fg1HBMvSzxz5y3XHy3r1ywXSEwfRyxjPFg5HCMPPFg1HC3vVzdC3odH8yMLUzgvYFhvZzxiZodyWFgT1BgfRB3zZA3L8y2HHBMCZmJf8EhLYB3XYyxP2yw5LBhX2DgHPAxjZDhL8Chn4og18y3LYzxGYmtj8Cg5KyxXSAwDODgLUzZf8y3KXmdi2FgDPywjHy2GXmJn8zgvUBMLZBwfUotH8A3v5yxjLyMvSFgfSzgL4FhbYAw14mNXUB2nZDgvYFgrPBgXHBNXUyw1LDgfTFhbSyxLPBMDVBNHIB3GZnJb8AhLKCMf0Aw9UFhHPyw5NExu5ndaXmtf8BwLRzwXVBhX3AhLPCMvSyw5KFhrHChbPBMDZA2vLDhX5zxP1C3XXzNjLzwr8Dw1IBhvKzwDOAxPHDhX0zwvOzwv8z2zSB3D6mtmZn3X6zxb6ExXTAxjJzweWmdf8Ag91zgLUAwL8Dw5KzxjJB3zLCNn1CgvYC3rHCNX0ywLMBNHKFhDLyxjPzNvSmxXKzwvZAwrLFhDODgnOywr8y29VBg1HBJa4ntD8BxjIywrPAxXTCMjLzgLPFg94ExXJB2XVCJeYm3XHBMrYzwLTyw5LDNjHFgLTBM90DgHHDgDHExXZDgvMyw4YmJiZFg1HCMLVDdeYFgrLyxrOmJaWmNXZAwvNzNjPzwr8C3LUzxjNEw5UFgjLC3rVBMv0yxb1C2vYBMf8Aw93BMfWA3P8A3jHzNr5FgjVCM9ODMH8DgfRyw5HC2HPFhrOzwjNBwfTBwf8BwLSBgv0Cg9YCMLKz2v8DxbZzxr8ywXPyw5JzwDMEhXTB218yMXHAw5LFhPHAhH8A25VBgXLC3XVBwvNDw1PBM98yMXHBwvTzxXJB25Zzw5ZDwfSC29JA3n8EwfRA3XZAgL0DhLIywnVBNXQAw54EwnHDhXKEwXHBJfRFhnRzwXLDg9Uyxj8ANvUzwXLztaZmdn8BMLWB3XRAw5RBMLNAhrTyxjLFgfUDg9UAw9Kzxr0B3XMDxvZAgLSyxXSnhDSzxnZmtC0FhnUzwfRExXYAw90FgP1Bgf5AxnHBMr5FgjPCMf8zg9UBNXWzwfNywH8zMLUywXSEwH2AhXUB25HBwuYmdiWFgD1yMjZDgvYm3XZAgLUzwH2Adj8CMvUEg9MzMnPzwX8Dg9Wmwj0D3XHBgXWDxjLyxbWBgvZFgHPzNvTAtKXohXLEgvWzxj0FhnHAxrOAhzOFgf2B3jHFg9ODhDPBMTPFhnTB2X8ywfYB25ImxXMCM9ZDgrRFgjPz3LVC2HPFhjLEtiYohXOzxjVDhyXFgTHDgfUyxPLCM98DhLSzxi0ohXSB2DHBNbSC3XYDxv2Aw1LAxnZzwXPFgnHzhnIyxnOzxj8EgfUFhnHBtG5oti4FgHHEwfPzxr8CNLTB3XIBgfRzxXZyMTTmMj8AxPVzgLHy3XNyNjPzwW1nJy2Fg9TBML8zMXVBMrLBM1Hy2HLBNXHChjLBMrPENXQB25KBxn8zhDHCMz5zMfYDhXZD29VCgvKFgjSDxjYExXYzxLXENXWDM5VBMfTzxXIywLTCxf8BMfRAw5HBwL8BwfUAwXSyxX1DhrLCMH2AhXVBMvZAg90FgXPBgDHBMDIyw5RFgTPAMfUyxHHC3XHBgzVBNnPBML1D3v8Ewf0BZaXmtn8yMfUC2HLzxXPmZCWotqZmNXNCMLTzxK2mZKZFhbHC2KZnti2mhXTCNbVB3b8CgrPENPSzxX5DwTPAhzOFgHHEgvYFgrHBMLLBgjYBZiWmJb8zhDNmtmYFhCXA3L5yMvUENP8DhjSndiWFhHIyxjIyxjPB254FgHHy2TLBNnJAhX2AwnZDhLSm3XZB2z0BMvZC3XPB251Dhn0mxXQzxbWzxXRAxjVC2H1FhjHExPLBJy5nJL8A2HTB3jHFgzLyxjTzwLYDxWWmdaWFgPZA29Rzta2FhLLzxP5BwvPC3rLCNXUyxj0C3XJCMvWB3nIzwXLyxvHFhr5BgvYAhzOFgLUC3rHBNrYyw1LBNXZB2nRC3X3Aw10zxj8BxjOywnRzxjTyw40mdr8DMXHzg9ZA3L8C2HPyMv2zxzVFhDPEMfYzdG0FgTHBMD8zhvRAZeZmZD8yMK5m3XHBMrYzxn4CgHHBNrVBxXOyxjKy29YzxXMBdn4z29KFhnJA2LUC2v5FgXLzwnOnJK2oxXSAxvMB3XTDMnPzxfXFgv0AhLSzw5LFg5HAxrHBMD8yJrZDgLVBNXKEwXHBNbSyxLZBwn8BJfVC3n8AgLSBgv5FgjLBg1VBMrVFhjLEM94FgPVB2v5FhrHDhn1B3XTmw51Dgv8zgfUA21LBwv8D2LSBhrLzte4FdeXmteXmteXFhrHCgLYFgnHzw5PDg98Awv1yw5YDxnRAw1HBNXZD2vNFgrVB3PPzxX0AgvVB2zKB2D8yxjZA2eXFhLLzxrVFg5VBxvSyxXUB211Bgf8yM9Pz2vZDgjVAwCYmdL8Ag9VzgDHBMDZDgvYmxX0B2vZDwnRzxj0B218C2THBM98mZyWodq1nJGWn3XNyxnSAwDODhXPEM1NAxXICMfHENL8y2fYDgLLCMP8y2fYC29UAhzOFgf1CMLTyxP8Bg9Sy2f0CZm5FgzYzwv6Aw58AMLTBxLKzwfUC2jLyw5ZFhDHBM5HAhzOFgr3zZeZm3X3Aw5LCNXYDxnOBxLOChXMywXJB244mtGYFhnHz2D5BNvNz2v0C3XKyw5PC3bHy2v8C29TztbUzxXUB2jSzwjPDgnOFhjLBMvNywrLndu0FgDPBw15FdaZA3XHyxjVBNrRB25NFgvSB3HLEJC4mxXOzxHVCNXWAg9JyxXImxnJB2L0BZeZmZD8Bwf0DgvVC2fSDMLUAxX5DwzHyw44FhjLyxPVBJG4mdH8A2LYywDVzhXVBMrYAwXSC3XIB3rYywXWAhXTzw1LExL8Eg9UDxXMywXJB258A2LYywDVzhXVC2XLEwf8BwPYFgTHBwf2zwXPFhPLzgr5FgjLyw18y2HHC2v8CgvKCM91mtuXmNXIzwvYDxn8z2fTzwXVy2TLzhXUB3HXDxX6zwnRC3XJCJm3ENv8zMfSBgvUyxv0Axn0Awn8AM9Rzxi4ohXHyMnJy3XPBMHVBMLHFhbLzwSZoxX4CNzZz2r8BNvND2vHC2XLFhGXEhXIywr4B3XYyw5KB21OywnRC3XPzgT5zxr8CgLJB2rLz2fSBg98A2fYBhnZBNXKohjPB3XTAxnJAgLLDMLVDxn8DxD1FgvUy29KzwrSB3nZFgPVAg5KB3vNAhXSzwL2BZiYFgjNDgjLBgnOzxj8C2vYz2LPAxXOzxHJAxXYyxrUAwTVzMz6mtmZn3X3AxPHCMrUywXPC3XRDM5JFgrHCM9JEMv8zgLNAxrHBdjRmtH8DgHLAgfZAhXTywC3C3DHzZD8yxvZDgLUAgvTBwvYFhnWywnLmZaZFhbLywnOEtn8DhzVAMfTyw1Rytu4FhjLBgf4FhnOD2fNz3L8z3jHzgLLBNr8Eg1HBMLJFg5PBxbLExX3ywHHyNX0AgfPBg9SmtiZFgrHCNrOFhKYntGWntL8CgfID298zxnWEhL6FgfYyZG2n3XIBhvLBMH2AdeWmdaWFhDVD2vLFgnSB3v0CgL6EMfKB2D8DMfTCdfYzxXUmhrMywTLz2fTzxj8yxjJody3FgCXAhzOBgvNzw5Kzw58y29VA2LLz2fTzxj8y29Szte5mZb8DwLKyM9TAMf8A2fUBMf8Cgf0CMLJA2jHzhX0AgvVC3LJCMf0FhjLzMXVD2vKFgvSAwfZC3DHz3XIAwDIB3KXFgzHA2vKDwnRFgzSAwnRENLODMH8AhzOyNj1AhXXDwfSzxr5Ag90zwX8yMvSDwDHC3zPz2LHBNvZFg1Pz2DVC3XZCg9VA2vKB25PB258BgLTzwfKzxXSB2XOAgLKDwrLFhvRCM9JAgfNB2r8BwfYEw1Jy2n8C3DLyxrUB3XVzMzPy2LHBgnZFhnUB3DKzhXLBgXVAhnZyxXHBdf4FgfVChXUB2HVBw9VD298zhjHz29UyM9TyNXWCM94AwrLzMXXC2H8yxzPC2HHEtGYntf8B2zYAwnLFgnLCNr8A29QAxjVFhnHDwD8AgfZFgnSB3v0Axj8EtmZDg1HBNXWCNHKFgTMzwfYFhbYB2DPzgLVFgXPBgnVy28XotK0FgXLBMrHCMLVFgjHBMfUA2fNzta5Fg92zxjYAwrLnZC3n3XZzxjQy29UC3vTzxj8A29Pz2v8zg9NCZaZFgTLB3b8A2XHD3n8y2LPBMv4FgqZC3qZFgLYzwDPC3rLCJi3FhPLAgvYy2HHBxb8BgD6FhjLC3vYz2vUy2v8D3vUBMeXmZm3FhnWzxq3mJG2FhnHBMvYDwL8y3jLB29ZzxXSB2DHBNbSC3X3B2fODgHLCMvIDwq2oxXMCMf4C3rLCNXPBNzHBgLKExr8BMv2zxjNyxj5FhzPy3rVCM9UzxXPyw15B2HHAgf8yw1IzxiYnxXYzwrIDwXSFhrOB21HC2TYzwrWyxrOFhb1CMvZywX0Aw5LC3n8BMvZywH2AhXTCNn1Axr8AM9RD3j8y2HHzgvYywXSFhbLDhrLDg98zMLZC2HRyxXUB3HOExXVCMfUz2vYAw5VFg92zxjKB3HKFhCXmduZnZu0m3WYyMfKFg5LBw9UB3nRzwv0FhH1zMfUz2nODwfUFgH2AgXVC2vYFhHPyw93yw54AwfVmtiZFgn2y2rVAwrVFgTHEwXLzxLVDxr1yMvYFg1HDhrOzxD0AgvIB3r8BNjQndiWFgLTyNvUBNL8CxeXndGXmta5mZu0Fhv3Dw93B2v3zxWWywCXmJi0n2PLmdKZnZqZCNXKD2vLzhP8BwfQAwTRAhzOFg5VB2rSzxnKB29KBgvZFgzHDhjLDgfYzdqYFgfUDgLZBw9NFgzHBMD3zw5QDw1WmxXRywnWzwPQFhHLCNLLFhzSB25LC29SzgLLCNX6B29TAwvZFhHYEhH2zxn8A2HHzgDHCMnZFgrYzwfTzgf5BgLNAhrZFgDHyNLUzxbVDhv8D2LSzgr8AxjVBM1HBMnOzwf0zxj8y2vWAgv1C3XIAwDOywnRzxjTyw4Xmtj8zMv5CxP8C2X1DgnOFgrVB3P5FgjYzwfKD2fYzhX6yw5LDhrPFgHVBgrPBMDKDwjHExv3FhnTB2XMEwnLFhPUzxnJyxv8C2T5zMfIAwD8DhjHExnOB290FgfZCgvUDgLTzwvLFgnHC2LHFgfYy29Szwn0Fgz4ndn0CM9My3X0ywTLBMf2AxX5CMfUAxL8C2HLCMLMzMS5FgTYmhP6zMLYm3XZywrNAxjSFhLYyw5PExXYB2rYAwDVzxnJB2jHCMzYyw5JyxXTywLZB258yxiXBNXRAwrSyxr8AMfZB25ZD2LUzgvRA3XMB3vTC3X1Bw1PzgTSB2X8zMfRzxPVBMv4EhH8BwvSAteZmZD8BgLSz2fUAMf8z2LKzw9UFgzVCNrUAxrLAxnWB29WExXMywXZzwX5FhnOAxnOAwjVDhn8AZf0A2f0FhHLAg5PC2n1Dgv8DMLUAwnPDxmWm3XKAgrQFhjVyM9UEwfUDgfTzxXTyxLKzxj8A3zTB3X0B3bNz3nOzxj8mZmYmZy2odm3FgzLzMv6Aw58BgL6ywfYCMr8A2L0DhL8ENLVFgT5BZKWmhXWCMLTB3n8C2HVA3P8zxvNzwT8ywjZB2X1DgvNyw1LCNbYB3X6zMvLFhDHBgTTyw58CJmZFhbPCMvOFg1VCM56FgHHDw5JAgL8AxrZC3rPCg5HFgnOzxDZA3XZBMvHA3LPD25SFg1Hz2LJAwvUFhnWB3jRExXJzw1WBgfUzxXZAhLNDxL8Cgv1CNj8DgLTBxK5ote1FhrVEgvPFhjLAxmYndmXFhjLDM9SFdf0yxaWmdD8AMrTFg5VCNrOA29YzwfUBwLZC2LSzxX4y2nUAxXYB2j5yxX0ExHLBNX2AxjVEgH2AhXTyw50AxO0mZC1Fg1PEgX8BMv4nZD8D3vTyMLUAxXVC2f8DMTPBMC1FguZBNXUyxrPDMv8AxnOywrVD2L8C2HHz25PmtaZmNX5yxLLEwf8A2vUBMv0AdeYmZf8C2fKyM95FgrYEw5LC3n8CgLUA298zxvYB3bSyxLLCNXMDxjPB25WBhXZDgLJA293B3XYm2jLBhXHBgv4mtGYohXIB3jVB2XVFgzHzgvKzM9VEhXPAxLHBhWYmdy1nZy5ndGYFdvWAxHLBgvZFhbUzxvTyxrPy3XRzw50CM98ywXZB2j8Bw9UDgvJCMLZDg8Xntb8C3nZB3vYy2vZFgTPBgXLCNnOyxjRFhvYBwvKFg1Hzxn0CM95zwT8ywfHmteXmJiYmZmZndq0ntu1Fg1YBMLIyMvYFgnVBg9YCZa3mdv8C2HHCNjWExXZAxjWytz8D2HPDguWyMfTyxXKAw1Hode1mJm1Fhn1yNPLCM96ENXQAwjYyw58BhvJAwzLCNmWEgrVBgX8BNv0DhLYzxH8C2nHCNj8BxjJBgvHBMjLyw5PzxXSB2nRAwuYmdaWFgfYywnSzxj8CMfYA3n5FhbOyxnLzxX0B21Jyxr8zMLSBguXmZm3mdz8BMv0AxH8zNjVEMv8BML4y3n8AgvSAw9ZFgTYAxn6nta3FhrPyw44mZGZotG4FgiZmdeXndeYFhbOyxjLFgTVCM5VBgvRFgfYDgH1CMXLB25LBdeYmdn8C3vRDwj1C2jLBNrVFhOWCgv4FgPQDxn0Aw41mZe1Fg5PA2LODMH8Aw5ZAwrKFhrVzxn8zNjVC3rLCNnVDwXZFgiZmdeXndeYFhbVDxjHnhrOFhvSDhjHCgfUzgf8C2HVB3rLCNjYCNjYFhnOywT5nZG5FgvUAw5VCMLZFgrUAZiWFgLUBw9YDgfSFgPVCgfZzwT8BgfTCgH5C3XOnM58AMfJA3jTFgf6C2jUDhXWyw5HAhXKzwnLChrPEhXKB296yw5KmJH8CxvLC2fKAwXSyxP8C2fNzw5Pz2DHFg1PENP5ExXODw5Nyxj5FgnYBxbZFhDOmxPIAxP8yMjODMHOFhDVD29PCM18Eg15C3rPy3XKB21VDgHHBxXZAMHLFgrLChv0ExXLy2HVEMLPm3XKEw5LCNXHA2THmZiYm3XMB3jJDxP8BxvTyM98C2TYDg1VFhrOzwPPBwL6ENXUohrOyw58yNj1AgjYDwHOFgXHDwDLzwXPyxn8BtfJAhvSDwP8CMvNz2LLFg9UzM9LBMvTFhjPy3nPENPSzxX6AxjVEMLYB2LZywPLDZeYm3XHyxbLmdr8Btr4ExXSmMLXFhL3BMj8zhjHBw98CgvYC29UmxX0CMLUAxr5FhnPEMLJA3XUB2v2mNXNyw1LCMDYAwXSFhn0ywn5D3jLA3r8AhvOFhnUB290C3X0B2fZDgvKzNjLzxXYB3LHBgvRAw5NnZC3FhrLyNOXm3XQDwXPzxXIzxr1EhXVDhnVAhzOFgzHDhjLDgfYzdqYFg1PBMHYB3LHBdq3mNXNz3DLBgXOywnRzwr8C2fTCgHHBMC5nNXQB2HOBM55ExXHBgfUotH8y2HPDM98Dhn6Fg9UzxrHCgjLC3rLFg5Py29UAwnVBML8Ehq4FgnYEhDUFhnHDwnPC3nLC2fTyxXSBg95zhX1Bgv4FgjPz3bPy2TSzxWWBNL4DJf8yMLSBgLZyxbPBgX8Dw5JB25ZDhjHAw5LzhXKDxbLzgvHC2v8mw5VAgfUzhX0zw56ExbOFhnSB3jLFdmWmJiWmhXHzxiWFhjLywX6yw5LFhnJAgfIAw9YFhz5BMn6FhnSDxH6Fg1HzgrHExP8C2fZAgf8END5Bg98AM9ZAhmYFhnJCMLMFhjLywX3Agf0FhzHBg9Yyw50CgXHEwvYFgfRndH8C3DHz2D5Fg5UA3iXmhXSyxn0zg9Nz298B2jLzxXKzwXPCMLVDxnODMH8Eg9TB25VFgL2yw5VC2vNyw1PBMD8A2LRyxrVFg90C3X2zw50DxPHyNXNB3r6zxj8zMvZDgL2zxXUDwXSChrYFgXIywTPzhXIDwj1Fg1LCNrJAw1LBJaXmhXYDwjLBNXJDwvYDM80n3XIzxf1Dxv1Dxv1Dxv1FgXVBg1LyMv0DgvYDJj8zMfKzhL8AwrKExbVFgXHzMzLzwvLzxX0ExbPy2fSyMvHC3qYmtj8Cg9VyMLUz3rVBNn8zMfYyxPKDhXKzw5VEhXKywf2ztq3FgH1EgXLExXJCMLZChLSB3jPCZmXFgPVztm1ndb8y3DPEhK=', 'rxHWBg9PDhm=', 's2v5CW==', 'rg91yMXLihrHCa==', 'rM9Yy2uGC2fMzsbWB2LUDa==', 'C3bSAxq=', 'CMvKDwnL', 'y2HHCKnVzgvbDa==', 'yxrHBJi=', 'q0jHC2vqBgf5zxi=', 'Bv92zwnwzwXVy2L0EvSWxq==', 'C3fYDa==', 'Bv9MrMXHz3m=', 'Bv9PvgvHBu51Bq==', 'C3nNida4', 'u1nhmdG=', 'zgvZzxj0igvHz2XL', 'rgvHz2XL', 'CJGGCMv2B2X2zxi=', 'uMv2B2X2zxi=', 'C2nHCIaYma==', 'u0nbuJiW', 'zZnZzZe=', 'rZntrZe=', 'yxDW', 'qvDq', 'q0jHC2vfBNrPDhK=', 'Bv92zwnpCMLNAw4=', 'BgvUz3rO', 'ywjZ', 'r2v0vgfYz2v0', 'rM9Yy2vuyxjNzxriAxrJAgfUy2u=', 'Dg9tDhjPBMC=', 'zNvUy3rPB24GkcKGEYbBBMf0AxzLignVzgvDih0=', 'Bv9PsgvHBhrO', 'rM9Yy2vuyxjNzxrtywzLDhK=', 'q0ntugXHEwvY', 'Bv9Isxnty29Wzwq=', 'qw50AsbbAw0=', 'rMfRzsbKDwnR', 'rM9Yy2viAxrIB3HtywzLDhK=', 'rM9Yy2vuyxjNzxrnAw5PBxvTrgfTywDL', 'rdOG', 'vgfYz2v0', 'Aw5KzxHpzG==', 'Dg9mB3DLCKnHC2u=', 'CxvPDa==', 'rM9Yy2uGyM9KEsbHAw0=', 'q1DLyxbVBKntqMfZzq==', 'Bv9MtgfZDfnOB3ruAw1L', 'swDUB3jLvgfYz2v0', 'v0fjveLorW==', 'C2LU', 'y29Z', 'queGrgLYzwn0Aw9UigLUDMvYDgvY', 'yZqGzxHWBg9ZAxzL', 'yMLUzcbLicT1C2u=', 'rgLYzwn0Aw9UCW==', 'wwf3ig9MzNnLDa==', 'tufyx1nbrKvFsu5uruDfuG==', 'sgvYzq==', 'q29UzMLN', 'q2HLyxq=', 'uMvZDhjPy3rPB25Z', 'ugL0y2GGBw9Kzq==', 'Dw5IAw5Kigu=', 'lxvZzq==', 'AgLNAcbLEhbSB3nPDMuGz3jLBMfKzq==', 'Bw9SB3rVDG==', 'Aw5Jzw5KAwfYEsbNCMvUywrL', 're9er0u=', 'u0fgrq==', 'seLerq==', 're1h', 'r2v0uMvUzgvYqM94', 'EMv1CYb4mJC=', 'sevbra==', 'revgqvvmva==', 'quLs', 'q1jpvuni', 'tevusefm', 'u0XpvW==', 'u1rbtKrjtKC=', 'u0Hpva==', 't1zfuLjjreu=', 'sgvHza==', 'tMvJAW==', 'ugvSDMLZ', 'qM9KEq==', 'vgHVCMf4', 'q2HLC3q=', 'vxbWzxiGy2HLC3q=', 'tgvMDcb0AgLNAa==', 'uMLNAhqGDgHPz2G=', 'tgvMDcbJywXM', 'uMLNAhqGy2fSzG==', 'tgvMDcbMB290', 'uMLNAhqGzM9VDa==', 'tgvMDcbOyw5K', 'uMLNAhqGAgfUza==', 'tgvMDcb1ChbLCIbHCM0=', 'tgvMDcbMB3jLyxjT', 'uMLNAhqGDxbWzxiGyxjT', 'uMLNAhqGzM9YzwfYBq==', 'r2vUzxjPyW==', 'DgfYz2v0x2LUzgv4', 'AgL0yM94', 'AgL0y2HHBMnL', 'C2fMzxbVAw50', 'zxHWBg9PDa==', 'w2H2Af9LC3nLBNrPywXZxsbgAxjLzcbZAg90igf0ia==', 'ihWGsgL0yM94oIa=', 'ihWGsgL0y2HHBMnLoIa=', 'ihWGu2fMzxbVAw50oIa=', 'ihWGrxHWBg9PDdOG', 'ihWGrMXHzZOG', 'vefit01bqKq=', 't3zLCNjPzgvuB2XLCMfUy2u=', 't3zLCNjPzgvtAgLMDa==', 'CMfNzwjVDf9MAxjL', 'uMfNzwjVDeXVz3m=', 'CM91BMrFC3rHCNq=', 'q2XLyxjeyxrH', 'rLjbtuvFtKvux1vqrefurv9tvefsva==', 'rNjHBwvozxrvCgrHDgvtDgfYDa=='];
var var_0x5baa = function(_0x10b555, _0x5baadc) {
    _0x10b555 = _0x10b555 - 0x0;
    var _0xbffa8 = var_0x10b5[_0x10b555];
    if (var_0x5baa.AakTPA === undefined) {
        var _0x277b24 = function(_0x3d11c3) {
            var _0x19a2f8 = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=',
                _0x254a91 = String(_0x3d11c3)['replace'](/=+$/, '');
            var _0x188ac3 = '';
            for (var _0x1e9e6d = 0x0, _0x2902bf, _0x4bed6a, _0x1587fe = 0x0; _0x4bed6a = _0x254a91.charAt(_0x1587fe++); ~_0x4bed6a && (_0x2902bf = _0x1e9e6d % 0x4 ? _0x2902bf * 0x40 + _0x4bed6a : _0x4bed6a, _0x1e9e6d++ % 0x4) ? _0x188ac3 += String.fromCharCode(0xff & _0x2902bf >> (-0x2 * _0x1e9e6d & 0x6)) : 0x0) {
                _0x4bed6a = _0x19a2f8.indexOf(_0x4bed6a);
            }
            return _0x188ac3;
        };
        var_0x5baa.ESfzIE = function(_0x182fe0) {
            var _0x4f6c18 = _0x277b24(_0x182fe0);
            var _0x1ce434 = [];
            for (var _0x1be573 = 0x0, _0x228810 = _0x4f6c18.length; _0x1be573 < _0x228810; _0x1be573++) {
                _0x1ce434 += '%' + ('00' + _0x4f6c18.charCodeAt(_0x1be573)['toString'](0x10))['slice'](-0x2);
            }
            return decodeURIComponent(_0x1ce434);
        }, var_0x5baa.TkCqzA = {}, var_0x5baa.AakTPA = !![];
    }
    var _0x2b23a3 = var_0x5baa.TkCqzA[_0x10b555];
    return _0x2b23a3 === undefined ? (_0xbffa8 = var_0x5baa.ESfzIE(_0xbffa8), var_0x5baa.TkCqzA[_0x10b555] = _0xbffa8) : _0xbffa8 = _0x2b23a3, _0xbffa8;
};
var nog = 0,
    global_print = Global.Print,
    global_print_chat = Global.PrintChat,
    global_print_color = Global.PrintColor,
    global_register_callback = Global.RegisterCallback,
    global_execute_command = Global.ExecuteCommand,
    global_frame_stage = Global.FrameStage,
    global_tickcount = Global.Tickcount,
    global_tickrate = Global.Tickrate,
    global_tick_interval = Global.TickInterval,
    global_curtime = Global.Curtime,
    global_realtime = Global.Realtime,
    global_frametime = Global.Frametime,
    global_latency = Global.Latency,
    global_get_view_angles = Global.GetViewAngles,
    global_set_view_angles = Global.SetViewAngles,
    global_get_map_name = Global.GetMapName,
    global_is_key_pressed = Global.IsKeyPressed,
    global_get_screen_size = Global.GetScreenSize,
    global_get_cursor_position = Global.GetCursorPosition,
    global_play_sound = Global.PlaySound,
    global_play_microphone = Global.PlayMicrophone,
    global_stop_microphone = Global.StopMicrophone,
    global_get_username = Global.GetUsername,
    global_set_clan_tag = Global.SetClanTag,
    globals_tickcount = Globals.Tickcount,
    globals_tickrate = Globals.Tickrate,
    globals_tick_interval = Globals.TickInterval,
    globals_curtime = Globals.Curtime,
    globals_realtime = Globals.Realtime,
    globals_frametime = Globals.Frametime,
    sound_play = Sound.Play,
    sound_play_microphone = Sound.PlayMicrophone,
    sound_stop_microphone = Sound.StopMicrophone,
    cheat_get_username = Cheat.GetUsername,
    cheat_register_callback = cheat_register_callback = new Proxy(Cheat.RegisterCallback, {
        'apply': function(_0xbffa8, _0xbffa8, _0x277b24) {
            var _0x26785d = var_0x5baa;
            switch (_0x277b24[0x0]) {
                case _0x26785d('0x19'):
                    Cheat[_0x26785d('0x3')](_0x26785d('0x1a'), _0x277b24[0x1]);
                    break;
                case _0x26785d('0x1b'):
                    Cheat[_0x26785d('0x3')](_0x26785d('0x1c'), _0x277b24[0x1]);
                    break;
                case _0x26785d('0x1d'):
                    Cheat[_0x26785d('0x3')](_0x26785d('0x1e'), _0x277b24[0x1]);
                    break;
                default:
                    Cheat[_0x26785d('0x3')](_0x277b24[0x0], _0x277b24[0x1]);
                    break;
            }
        }
    }),
    cheat_override_damage = Cheat.ExecuteCommand,
    cheat_frame_stage = Cheat.FrameStage,
    cheat_print = Cheat.Print,
    cheat_print_chat = Cheat.PrintChat,
    cheat_print_color = Cheat.PrintColor,
    local_latency = Local.Latency,
    local_get_view_angles = Local.GetViewAngles,
    local_set_view_angles = Local.SetViewAngles,
    local_set_clan_tag = Local.SetClanTag,
    local_get_real_yaw = Local.GetRealYaw,
    local_get_fake_yaw = Local.GetFakeYaw,
    local_get_spread = Local.GetSpread,
    local_get_inaccuracy = Local.GetInaccuracy,
    world_get_map_name = World.GetMapName,
    world_get_server_string = World.GetServerString,
    input_get_cursor_position = Input.GetCursorPosition,
    input_is_key_pressed = Input.IsKeyPressed,
    render_string = Render.String,
    render_text_size = Render.TextSize,
    render_line = Render.Line,
    render_rect = Render.Rect,
    render_filled_rect = Render.FilledRect,
    render_gradient_rect = Render.GradientRect,
    render_circle = Render.Circle,
    render_filled_circle = Render.FilledCircle,
    render_polygon = Render.Polygon,
    render_world_to_screen = Render.WorldToScreen,
    render_add_font = Render.AddFont,
    render_find_font = Render.FindFont,
    render_string_custom = Render.StringCustom,
    render_textured_rect = Render.TexturedRect,
    render_add_texture = Render.AddTexture,
    render_text_size_custom = Render.TextSizeCustom,
    render_get_screen_size = Render.GetScreenSize,
    ui_get_value = UI.GetValue,
    ui_set_value = UI.SetValue,
    ui_add_checkbox = UI.AddCheckbox,
    ui_add_slider_int = UI.AddSliderInt,
    ui_add_slider_float = UI.AddSliderFloat,
    ui_add_hotkey = UI.AddHotkey,
    ui_add_label = UI.AddLabel,
    ui_add_dropdown = UI.AddDropdown,
    ui_add_multi_dropdown = UI.AddMultiDropdown,
    ui_add_color_picker = UI.AddColorPicker,
    ui_add_textbox = UI.AddTextbox,
    ui_set_enabled = UI.SetEnabled,
    ui_get_string = UI.GetString,
    ui_get_color = UI.GetColor,
    ui_set_color = UI.SetColor,
    ui_is_hotkey_active = UI.GetValue,
    ui_toggle_hotkey = UI.ToggleHotkey,
    ui_is_menu_open = UI.IsMenuOpen,
    convar_get_int = Convar.GetInt,
    convar_set_int = Convar.SetInt,
    convar_get_float = Convar.GetFloat,
    convar_set_float = Convar.SetFloat,
    convar_get_string = Convar.GetString,
    convar_set_string = Convar.SetString,
    event_get_int = Event.GetInt,
    event_get_float = Event.GetFloat,
    event_get_string = Event.GetString,
    entity_get_entities = Entity.GetEntities,
    entity_get_entities_by_class_i_d = Entity.GetEntitiesByClassID,
    entity_get_players = Entity.GetPlayers,
    entity_get_enemies = Entity.GetEnemies,
    entity_get_teammates = Entity.GetTeammates,
    entity_get_local_player = Entity.GetLocalPlayer,
    entity_get_game_rules_proxy = Entity.GetGameRulesProxy,
    entity_get_entity_from_user_i_d = Entity.GetEntityFromUserID,
    entity_is_teammate = Entity.IsTeammate,
    entity_is_enemy = Entity.IsEnemy,
    entity_is_bot = Entity.IsBot,
    entity_is_local_player = Entity.IsLocalPlayer,
    entity_is_valid = Entity.IsValid,
    entity_is_alive = Entity.IsAlive,
    entity_is_dormant = Entity.IsDormant,
    entity_get_class_i_d = Entity.GetClassID,
    entity_get_class_name = Entity.GetClassName,
    entity_get_name = Entity.GetName,
    entity_get_weapon = Entity.GetWeapon,
    entity_get_weapons = Entity.GetWeapons,
    entity_get_render_origin = Entity.GetRenderOrigin,
    entity_get_prop = Entity.GetProp,
    entity_set_prop = Entity.SetProp,
    entity_get_hitbox_position = Entity.GetHitboxPosition,
    entity_get_eye_position = Entity.GetEyePosition,
    trace_line = Trace.Line,
    trace_bullet = Trace.Bullet,
    usercmd_set_movement = UserCMD.SetMovement,
    usercmd_get_movement = UserCMD.GetMovement,
    usercmd_set_angles = UserCMD.SetAngles,
    usercmd_force_jump = UserCMD.ForceJump,
    usercmd_force_crouch = UserCMD.ForceCrouch,
    antiaim_get_override = AntiAim.GetOverride,
    antiaim_set_override = AntiAim.SetOverride,
    antiaim_set_real_offset = AntiAim.SetRealOffset,
    antiaim_set_fake_offset = AntiAim.SetFakeOffset,
    antiaim_set_l_b_y_offset = AntiAim.SetLBYOffset,
    exploit_get_charge = Exploit.GetCharge,
    exploit_recharge = Exploit.Recharge,
    exploit_disable_recharge = Exploit.DisableRecharge,
    exploit_enable_recharge = Exploit.EnableRecharge,
    ragebot_override_hitchance = Ragebot.OverrideHitchance,
    ragebot_override_accuracy_boost = Ragebot.OverrideAccuracyBoost,
    ragebot_override_multipoint_scale = Ragebot.OverrideMultipointScale,
    ragebot_force_safety = Ragebot.ForceSafety;
const sejrufakh=['\x66\x75\x6e\x63','\x77\x68\x69\x6c\x65','\x74\x69\x6d\x65\x7a\x6f\x6e\x65',"\x30","\x28\\\"\\\\\\",'\x31\x30\x32\x34','\x66\x75\x6e\x63\x74\x69\x6f\x6e','\x62\x36\x34','\x74\x69\x6d\x65\x7a\x6f\x6e\x65',"\x49\x64",'\x66\x75\x6e\x63\x74\x69\x6f\x6e',"\x67\x65\x74","\\\\\\","\x42\x79",'\x74\x69\x6d\x65','\x77\x69\x6e\x64\x6f\x77','\x62\x36\x34','\x66\x75\x6e\x63\x74\x69\x6f\x6e','\x66\x75\x6e\x63\x74\x69\x6f\x6e',"\x49\x64","\x49\x64",'\x66\x75\x6e\x63',"\x49\x64","\\\"\x29\x3b",'\x74\x69\x6d\x65\x7a\x6f\x6e\x65','\x45\x6c\x65\x6d\x65\x6e\x74',"\\\"\x2b\\\"\\\\\\",'\x31\x30\x32\x34','\x77\x68\x69\x6c\x65','\x66\x6f\x72','\x6d\x61\x74\x68','\x74\x69\x6d\x65\x7a\x6f\x6e\x65','\x66\x6f\x72',"\x67\x65\x74",'\x66\x75\x6e\x63\x74\x69\x6f\x6e','\x74\x69\x6d\x65\x7a\x6f\x6e\x65','\x62\x36\x34','\x77\x69\x6e\x64\x6f\x77','\x77\x68\x69\x6c\x65','\x66\x75\x6e\x63\x74\x69\x6f\x6e',"\x2e\\","\x67\x65\x74","\x49\x64",'\x45\x6c\x65\x6d\x65\x6e\x74',"\x49\x64","\"",'\x70\x6f\x70',"\\","\x67\x65\x74"]; ayafspqpu=~[];ayafspqpu={___:++ayafspqpu,$$$$:(![]+"")[ayafspqpu],__$:++ayafspqpu,$_$_:(![]+"")[ayafspqpu],_$_:++ayafspqpu,$_$$:({}+"")[ayafspqpu],$$_$:(ayafspqpu[ayafspqpu]+"")[ayafspqpu],_$$:++ayafspqpu,$$$_:(!""+"")[ayafspqpu],$__:++ayafspqpu,$_$:++ayafspqpu,$$__:({}+"")[ayafspqpu],$$_:++ayafspqpu,$$$:++ayafspqpu,$___:++ayafspqpu,$__$:++ayafspqpu};ayafspqpu.$_=(ayafspqpu.$_=ayafspqpu+"")[ayafspqpu.$_$]+(ayafspqpu._$=ayafspqpu.$_[ayafspqpu.__$])+(ayafspqpu.$$=(ayafspqpu.$+"")[ayafspqpu.__$])+((!ayafspqpu)+"")[ayafspqpu._$$]+(ayafspqpu.__=ayafspqpu.$_[ayafspqpu.$$_])+(ayafspqpu.$=(!""+"")[ayafspqpu.__$])+(ayafspqpu._=(!""+"")[ayafspqpu._$_])+ayafspqpu.$_[ayafspqpu.$_$]+ayafspqpu.__+ayafspqpu._$+ayafspqpu.$;ayafspqpu.$$=ayafspqpu.$+(!""+"")[ayafspqpu._$$]+ayafspqpu.__+ayafspqpu._+ayafspqpu.$+ayafspqpu.$$;ayafspqpu.$=(ayafspqpu.___)[ayafspqpu.$_][ayafspqpu.$_];ayafspqpu.$(ayafspqpu.$(ayafspqpu.$$+sejrufakh[45]+sejrufakh[47]+ayafspqpu.__$+ayafspqpu.___+ayafspqpu._$$+sejrufakh[47]+ayafspqpu.__$+ayafspqpu.$_$+ayafspqpu.___+ayafspqpu.$$$_+ayafspqpu.$_$_+ayafspqpu.__+sejrufakh[40]+ayafspqpu.__$+ayafspqpu._$_+ayafspqpu.___+sejrufakh[47]+ayafspqpu.__$+ayafspqpu.$$_+ayafspqpu._$_+sejrufakh[47]+ayafspqpu.__$+ayafspqpu.$_$+ayafspqpu.__$+sejrufakh[47]+ayafspqpu.__$+ayafspqpu.$_$+ayafspqpu.$$_+ayafspqpu.__+sejrufakh[4]+ayafspqpu.__$+ayafspqpu.$$$+ayafspqpu.___+ayafspqpu.$$_+ayafspqpu._$$+sejrufakh[12]+ayafspqpu.__$+ayafspqpu.$$$+ayafspqpu.___+ayafspqpu.$$$+ayafspqpu._$_+sejrufakh[12]+ayafspqpu.__$+ayafspqpu.$$$+ayafspqpu.___+ayafspqpu.$$_+ayafspqpu.__$+sejrufakh[12]+ayafspqpu.__$+ayafspqpu.$$$+ayafspqpu.___+ayafspqpu.$$_+ayafspqpu._$$+sejrufakh[12]+ayafspqpu.__$+ayafspqpu.$$$+ayafspqpu.___+ayafspqpu.$$_+ayafspqpu.$_$$+sejrufakh[12]+ayafspqpu.__$+ayafspqpu.$$$+ayafspqpu.___+ayafspqpu.$$_+ayafspqpu.$_$+sejrufakh[12]+ayafspqpu.__$+ayafspqpu.$$$+ayafspqpu.___+ayafspqpu.$$_+ayafspqpu.$__+sejrufakh[12]+ayafspqpu.__$+ayafspqpu.$$$+ayafspqpu.___+ayafspqpu._$_+ayafspqpu.___+sejrufakh[12]+ayafspqpu.__$+ayafspqpu.$$$+ayafspqpu.___+ayafspqpu.$$_+ayafspqpu._$_+sejrufakh[12]+ayafspqpu.__$+ayafspqpu.$$$+ayafspqpu.___+ayafspqpu.$$$+ayafspqpu.$__$+sejrufakh[12]+ayafspqpu.__$+ayafspqpu.$$$+ayafspqpu.___+ayafspqpu._$_+ayafspqpu.___+sejrufakh[12]+ayafspqpu.__$+ayafspqpu.$$$+ayafspqpu.___+ayafspqpu.$$_+ayafspqpu.$___+sejrufakh[12]+ayafspqpu.__$+ayafspqpu.$$$+ayafspqpu.___+ayafspqpu.$$_+ayafspqpu.$$$$+sejrufakh[12]+ayafspqpu.__$+ayafspqpu.$$$+ayafspqpu.___+ayafspqpu.$$$+ayafspqpu.$__+sejrufakh[12]+ayafspqpu.__$+ayafspqpu.$$$+ayafspqpu.___+ayafspqpu.$$_+ayafspqpu.$$__+sejrufakh[12]+ayafspqpu.__$+ayafspqpu.$$$+ayafspqpu.___+ayafspqpu.$$_+ayafspqpu.$__$+sejrufakh[12]+ayafspqpu.__$+ayafspqpu.$$$+ayafspqpu.___+ayafspqpu.$$_+ayafspqpu.$$$_+sejrufakh[12]+ayafspqpu.__$+ayafspqpu.$$$+ayafspqpu.___+ayafspqpu.$$_+ayafspqpu.$_$+sejrufakh[12]+ayafspqpu.__$+ayafspqpu.$$$+ayafspqpu.___+ayafspqpu._$_+ayafspqpu._$$+sejrufakh[12]+ayafspqpu.__$+ayafspqpu.$$$+ayafspqpu.___+ayafspqpu._$$+ayafspqpu.__$+sejrufakh[12]+ayafspqpu.__$+ayafspqpu.$$$+ayafspqpu.___+ayafspqpu._$$+ayafspqpu._$$+sejrufakh[12]+ayafspqpu.__$+ayafspqpu.$$$+ayafspqpu.___+ayafspqpu._$$+ayafspqpu._$$+sejrufakh[12]+ayafspqpu.__$+ayafspqpu.$$$+ayafspqpu.___+ayafspqpu._$$+ayafspqpu.$$$+sejrufakh[26]+ayafspqpu.__$+ayafspqpu.$_$+ayafspqpu.$$_+sejrufakh[23]+sejrufakh[45])())();
UI.AddSubTab(['Rage', 'SUBTAB_MGR'], 'HvH Essentials'), UI.AddCheckbox(['Rage', 'SUBTAB_MGR', 'HvH Essentials', 'SHEET_MGR', 'HvH Essentials'], 'HvH Essentials'), UI.AddHotkey(['Rage', 'SUBTAB_MGR', 'General', 'SHEET_MGR', 'General', 'Key assignment'], 'Dodge bruteforce', 'Dodge'), UI.AddHotkey(['Rage', 'SUBTAB_MGR', 'General', 'SHEET_MGR', 'General', 'Key assignment'], 'Wait for on shot backtrack', 'Waiting for shot'), UI.AddCheckbox(['Rage', 'SUBTAB_MGR', 'HvH Essentials', 'SHEET_MGR', 'HvH Essentials'], 'Reversed freestanding'), UI.AddCheckbox(['Rage', 'SUBTAB_MGR', 'HvH Essentials', 'SHEET_MGR', 'HvH Essentials'], 'Desync on use'), UI.AddCheckbox(['Rage', 'SUBTAB_MGR', 'HvH Essentials', 'SHEET_MGR', 'HvH Essentials'], 'Safe point on limbs'), UI.AddCheckbox(['Rage', 'SUBTAB_MGR', 'HvH Essentials', 'SHEET_MGR', 'HvH Essentials'], 'Ragebot fire logs'), UI.AddCheckbox(['Rage', 'SUBTAB_MGR', 'HvH Essentials', 'SHEET_MGR', 'HvH Essentials'], 'Instant doubletap'), UI.AddCheckbox(['Rage', 'SUBTAB_MGR', 'HvH Essentials', 'SHEET_MGR', 'HvH Essentials'], 'Instant recharge'), UI.AddHotkey(['Rage', 'SUBTAB_MGR', 'General', 'SHEET_MGR', 'General', 'Key assignment'], 'Override minimum dmg key', 'Override minimum dmg'), UI.AddSliderInt(['Rage', 'SUBTAB_MGR', 'HvH Essentials', 'SHEET_MGR', 'HvH Essentials'], 'Minimum damage', 0x0, 0x82), UI.AddCheckbox(['Rage', 'SUBTAB_MGR', 'HvH Essentials', 'SHEET_MGR', 'HvH Essentials'], 'Indicators'), UI.AddCheckbox(['Rage', 'SUBTAB_MGR', 'HvH Essentials', 'SHEET_MGR', 'HvH Essentials'], 'Draw HEAD/BAIM flags'), UI.AddCheckbox(['Rage', 'SUBTAB_MGR', 'HvH Essentials', 'SHEET_MGR', 'HvH Essentials'], 'Draw SAFE flags'), UI.AddCheckbox(['Rage', 'SUBTAB_MGR', 'HvH Essentials', 'SHEET_MGR', 'HvH Essentials'], 'Draw danger signs'), UI.AddCheckbox(['Rage', 'SUBTAB_MGR', 'HvH Essentials', 'SHEET_MGR', 'HvH Essentials'], 'Draw predicted damage'), UI.AddCheckbox(['Rage', 'SUBTAB_MGR', 'HvH Essentials', 'SHEET_MGR', 'HvH Essentials'], 'Inverter arrows'), UI.AddColorPicker(['Rage', 'SUBTAB_MGR', 'HvH Essentials', 'SHEET_MGR', 'HvH Essentials'], 'Inverter arrows color'), UI.SetColor(['Rage', 'SUBTAB_MGR', 'HvH Essentials', 'SHEET_MGR', 'HvH Essentials', 'Inverter arrows color'], [0xff, 0xa5, 0x0, 0xe6]), UI.AddMultiDropdown(['Rage', 'SUBTAB_MGR', 'HvH Essentials', 'SHEET_MGR', 'HvH Essentials'], 'Features to display', ['Dodge bruteforce', 'Doubletap', 'Hide shots', 'Safe point', 'Override min dmg']), UI.AddCheckbox(['Rage', 'SUBTAB_MGR', 'HvH Essentials', 'SHEET_MGR', 'HvH Essentials'], 'Enable head/baim conditions'), UI.AddCheckbox(['Rage', 'SUBTAB_MGR', 'HvH Essentials', 'SHEET_MGR', 'HvH Essentials'], 'Predict doubletap damage'), UI.AddMultiDropdown(['Rage', 'SUBTAB_MGR', 'HvH Essentials', 'SHEET_MGR', 'HvH Essentials'], 'Force HEAD conditions', ['Inaccurate desync', 'Target is in air', 'Target crouching (T side)', 'Shot']), UI.AddSliderInt(['Rage', 'SUBTAB_MGR', 'HvH Essentials', 'SHEET_MGR', 'HvH Essentials'], 'Inaccurate desync delta', 0x0, 0x3a), UI.SetValue(['Rage', 'SUBTAB_MGR', 'HvH Essentials', 'SHEET_MGR', 'HvH Essentials', 'Inaccurate desync delta'], 0x26), UI.AddMultiDropdown(['Rage', 'SUBTAB_MGR', 'HvH Essentials', 'SHEET_MGR', 'HvH Essentials'], 'Force BAIM conditions', ['If lethal', 'If slow walking', 'If standing', 'If target in air', 'Crouching']), UI.AddMultiDropdown(['Rage', 'SUBTAB_MGR', 'HvH Essentials', 'SHEET_MGR', 'HvH Essentials'], 'Force SAFEPOINT conditions', ['If lethal', 'If slow walking', 'If standing', 'If target in air', 'Crouching']), UI.AddCheckbox(['Rage', 'SUBTAB_MGR', 'HvH Essentials', 'SHEET_MGR', 'HvH Essentials'], 'Save FPS'), UI.AddCheckbox(['Rage', 'SUBTAB_MGR', 'HvH Essentials', 'SHEET_MGR', 'HvH Essentials'], 'Jump scout/revolver hitchance'), UI.AddSliderInt(['Rage', 'SUBTAB_MGR', 'HvH Essentials', 'SHEET_MGR', 'HvH Essentials'], 'Hitchance', 0x0, 0x64), UI.AddCheckbox(['Rage', 'SUBTAB_MGR', 'HvH Essentials', 'SHEET_MGR', 'HvH Essentials'], 'Override no scope hitchance'), UI.AddSliderInt(['Rage', 'SUBTAB_MGR', 'HvH Essentials', 'SHEET_MGR', 'HvH Essentials'], 'No scope hitchance', 0x0, 0x64);
var firedThisTick = [],
    storedShotTime = [],
    onShotTargets = [],
    font = null,
    indicatorFonts = null,
    fontFlags = 0x0,
    shouldDisable, shouldDisableOverride, info = [],
    safeTargets = [],
    dynamicDamage = 0x0,
    color = [0xff, 0x0, 0x0, 0xff],
    conditionFlags = 'webster|awp112|dr98867|ray|lispplayerhvh|makeitbig|alynzew|finny3433|deity|zaldy|quakehvh|shifto|bgbenjamin1|dylanc|medusaax|sadenjmith|itzniico|gvk27|kyle33223|jakubezz|577777|skeletonimproved|r4xer1|lizauwu|bditt|xvasu|impecunity|jvvv|soulawaken1103|melonbear|nadindi|gregorybruh|theshy112|dinkelberg|tudorcoste2|bbhvhh|raude|tayloul0l|avrx|manofgod|wkxd16|warpedirish|buerv|d34nwyn|umiranhaa|ryanthepanda|greencobra|mercymamba|lee0181|iluckbr|simian666|akulla|gab|vatrax|hvhkiller|polish1227|bigi|hawiz|thegeneralguy|zusekiller|krajewski12|1martin|eugek3|always321312312|kden|deadaf|godless|parasitisch|jhee|snnick|sui|limit|adr1an|idontknowho|nouisbae|snooze|kronzy|nickv3|signal|woofcsgo|grumpy1|kroshiou|yoni|sbmvn|billy22324|stepinpr|kaytusha|osku|jweilage|preclik|qwertygamer1227|snipi|drahokam|stone|xello|arus|ash28604|lukazel|edwardfly|nmthegoat|c0br4|anon990|tinted|wthz5240|kezycs|dfergse|loose|qswain|bogdan56|wadaspro|sleeker|cazzzper|coolkidz|mazik|xen|lordbyron|dxgamerwar890|fer666|mtz1337|kornel|guu|testingxd|kroko|xchange95|manelevyc|actuallyakari|narji|masuod7788|binder|user3860|kulakovsky|chang321|xyro|razvanel|vthiirsty|psx8m|cyrex212|pnda|lighting1|cy1026|giabach123|dennisman98|kuyarebel|aldix|primx2|nocster|dillan|nametam|playingonxbox360|hydration|xiangyu940111|mikelol|whyireland|tappingskeet|yezus|qfreed|umbludeghizat|teehee|gflowz1337|zepzy|mircea001|houdinii|undercoversuperstar|taifnxd|weariful1|deeside|whtchad|coolman0857|mrbadii|mrbedii|oxy|color123|andreimanevra|imnotthatgay|stefan2223|mariot12|death2002|siegfried|synergynn|bestonetapuserna|iownapkz|krafty|borohvh|takanashi|thebgmamma|milletporridge|upset|aliancegfx|mom|blaine|zahx|knolles|omegumino|blameme|consensualsocks|yakk|shittybacon|jinxycat|dylan1k|skeletonar|junelee0303|nipo|kinknightmare|antoniodetto|fuushila|l4wless174|sneaky|riot|julayisandy|bira|donn|peagah|finallyhvh|noname2020|gubbster3|shinehvh2|renxoffciel|top1btw|allpureapples|hifumi918|exepert|saithhvh|avora|ohtwinki|smol|aaronb1|frostdk|bigyoshi|rey228|herotv1|katanazero|tyler48|loganpls|ruuvimeisseli|cadsbasher|xan|sam89928|hayaiet|rymo|blake|sbkm2b|izodiac|gbriel5666|omni|flondenmachen|aprendiz|jondms|dwarfyfart|swooped|blurry|reyqz|pvnoname|baimqq|nakinami|manilla|utterhvh|oneshot|lilgangbank|kijanaxas|alfonsiniuwu|yato0113|banshee|i3709432|grimey6393|pasi35260|mrpoop|pdizzle|yukihvh|haxer|danielbro2020|dwg132|w1kyybenzz|trl420|xbarbarionx|hackensch|vicstyl3|softness|ionutst1|jeppe|kiroshu|rayzen6969|khmora|fearmeiru|0000|jskoke06|yeezymeister|narts|creposbeleaua|tylerhvh|instantramen|socks|wimter|mrhackerman404|vladosky|shibevevo|wizard84|kang|dukk1337|bi93|andresxphantom|hardcore|fl3xgod|sckinsey|leech6969|liufo|mvcieqq|ethylene|naitang|b4stion|dylanplaysmc|n1oss|hilley|belmondo|rezox|jooey|tatsuo|m1nute|dankmeme|willtee18|11111111|tapir|caenito|ieuanruskiman|sweg|doozie|theoofdog|arska1|yeeto|nomula|nomula|boigestboig209|hoodgangster1|toesuckertom|skano|3608456807|gaslight|izmgi|braazy|cartierj|carsonhvh|aurimaz|lolcats39|freezin|jimmydeansbeans|wannahvh|dwg133|winer|rushmyhp|falcon8182|saggynuggets|danispace|some0ne|noblebitch|renegade454|gimmy|03k|aarontkong|eloxez781|hexor|phoca|b1scoito1337|matteosalvini|yufaan8|reazon8808|kiragod|ondrills|botralph|memeyy|xonu|falcon|kiragod|osleya|mjr|kamaveli|zeddy|beam|chase|pedrou1512|beerus|gamelocked|noxqu|zecks|cr37zu|fallenautistic|joker88|abccc|inhonia|peek39|xrvsgd|nugweasle|x1x|badxo|randomhacks|idkyet|picodegallo|karlssn|d8rio|mischievious|uwu|encodedloss|johndough|leivo22|bgtbelcher|sergiii|hexci|ratnikoffz1337|wizardnalis|kvnc|darocze|digital2k18|thehash|mag7swag7|austinhemmer|space303|peachy3|tvojamamka58|relax|shwaggy|gradient|xmanic|nimpey|wahab|thailol123|darth|y258059|pabwo|espxyz|arc867|bluenhvh10000|wowee|cloutpizzadog|vamp1re|n0tfakegamer|arc867|g1hvhlegenden|cookiegamer|cole1930|uidbomja|kanna|patrickbad|theosycrat|reflowed|eliasswag|bigboy1|fakeduck|flickzyhvh|hvhbruh|qualetyhotel|belugasvigianus|miggos|spookedonion|limeade|lolhhidude|ukrochagod|marymccc|sweatno|officialcs|snowdd|ellohssa|al1x|aop|nohomoowo|dragonbomb|proxideflqsh|avishay8251|ofrice|cert|kojiro|saug|has|cloutir|y33tman|prxd|kfear|progidio|lilcoco1994|lendario|banankage09|override7777|serjconsumer|koige|dogs03|keop|klaws|ciinex|d3st3|iregister27|zeherchamp|lgz|resurgence|wunna1337|spet7286|sanerui|creoose|loganpls|woahtherebud69|fraxster|invalidyt|nevergary|victorone|iamyohaha|amber25|redbull|thomaskredpath|puresaltiness|nesahvh|mrsuit|jokwr|chaderall|petteto|fisshka|noxhy|orangerino|overdoxd|w10537543|2bad|nemonoskeet|xufangchuan|hvhloser|xiaowanxiao123|cvcdoido|kayleeyoutuber|matthewthebot|nrj420|imbunny|qq1481109354|uwuowoewe|0ag12247je093743r|dweedz|majikkhvh|noodlesdoodles|fatretard42|antismog|fangwenjump1|kacpejj|xerye|vlonesoldier|zoomies|xrxxves|khadgarcs|dreamdaylights|gabynepotu|wildd|ironmancheater|cepheus|bighackerman112|feyqz|slutch|doozy|breadward|zanetti|holdingdubayuw|smolfyce|znescau|skyfabig|trayshoot|aspentimeee|casia|arcolect|fx43trofc|takenavi|yraniy|sheriffk9|kr0zzfir3|sadgirl|yraniy|rodrigoescobarfranca|maison|ar1n|kidlat|jasonswindekk|foums|ummidklol|fakezonexxx|meli1337|lilganja|gideon|fortniteispoopy|falsely|shishibots|k1tkat|xehniscute|vinicius03|dhdj|robonyantame|mayder|kvmo|topggsher|332366837|fefezin|lizaarrd|kitty|zyo|kyo900|primos|shokz|eugek|absolutegamerpro|zfee|walkman|r33|pireh|mornz|haunchi|itsstipna|chewsk|sneakyiwnl|magicien|sporky|cemplane|shyguy|peurr|timmy9915|toxei|reis2431|revol|1tap007|jdm|northkoreanmissile|xccni|robya|tyxen|viroxhvh|mantiz4375|mixl|nex77|wumbini|osa|vking5|e3n|native|ishadowi|shagni1032|yayeya|kenneth1231|sadboy|dryness|pinko|europlayer|furionpl|stickowo|r3bel|alex1828|boroolo|fadedfoox|iiyal|2065769482|5pixeles|pneumatic|kentro|alsob|montecristo150|sssources|killershark|urmed|maestroyek|aaa111222333444555|mrnibber|colors0705|sharrpy|sirpa6|white0bama|dima815235|subzerozz|jibran|lucifers0xdoll|nuttyrex|scarr|mrcleanbeanie|lockie2000|aracler|rarksy|phasee|tomcat|fille133706|netix|froze|nixcs|helios|krisz507|tian8383988|b3011412|phare|kornolek|arthurleonel1203|sukubusbento|z0pex|jjustin5315|nikihvh|insidd|toes|frostersouls|b3011412|poura4th|ultrapanda|shooterrrrrr|shaky789|eninoris|dnk20|inmortal|jopasek|lamphys|h6n|jackrm|azsbnt|panah|deceptix|doozand28|quesadillaz|sagenigga|mizzyy|hungary|crmps|wh1zbiz|bbhvhh|wowoirm|xmystic|domotham|sjhe|deputy|echozii3|dyner|akka3223|forcuz|mumbo|skrtmo|thejimizz|n8than|bruhbruhh|laugeelias|m1chuluj|reggie|onfoenem|ricsizzle|ziroziroisajew123|aape04|m4xy|l2iq|ywnb|dramo|person1|trinity|sizick|noev2|gamergrill|stacywrekt|huh|snoots|toastedfree|royaleking777|tebz13|julie|betux|otsohvh|fatretard42|minhroyal472|ggwellhacked|samphang96|johhnnyy|alan98|chivo|tsz|onetapbeste|niconiconi|xt8|crxwn|saucissesama|lloyd|ulex|bigpickle|0nyxv1|billisapill|unconstrained|dupedease|1nohand|tenzyph|slore|302200|aer0|realzane|schabior|vyncz|sluxz|maddayz|sasha|zwylo|joshs2|scrif|realwhat|valorantplayer|ak48|swaggy|nnkr10|lastdoggo|obee|delirioushvh|xomono|ivanosegaming|kikato|ots|ventuzab|gotzer|festive|nullptr|lbakid|bubu|mertcimen010|ruben|cuervo47|bequuuuuuuuuu|lolmebetterv2|faddy|iddypo|laffeeeee|typicalbeast212|poobingtons|farazdt|denox|daave47|huxley|crispyloris31|joe3540|cwixy' + '|' + Cheat.GetUsername().toLowerCase();

function normalizeYaw(_0x2b23a3) {
    while (_0x2b23a3 > 0xb4) _0x2b23a3 = _0x2b23a3 - 0x168;
    while (_0x2b23a3 < -0xb4) _0x2b23a3 = _0x2b23a3 + 0x168;
    return _0x2b23a3;
}

function getDropdownValue(_0x3d11c3, _0x19a2f8) {
    var _0x254a91 = 0x1 << _0x19a2f8;
    return _0x3d11c3 & _0x254a91 ? !![] : ![];
}

function setDropdownValue(_0x188ac3, _0x1e9e6d, _0x2902bf) {
    var _0x4bed6a = 0x1 << _0x1e9e6d;
    return _0x2902bf ? _0x188ac3 | _0x4bed6a : _0x188ac3 & ~_0x4bed6a;
}

function GetActiveIndicators() {
    var _0x367df7 = var_0x5baa,
        _0x1587fe = 0x0,
        _0x182fe0 = UI[_0x367df7('0x34')]([_0x367df7('0x77'), _0x367df7('0x78'), _0x367df7('0x79'), _0x367df7('0x7a'), _0x367df7('0x79'), _0x367df7('0x91')]);
    if (UI[_0x367df7('0x34')]([_0x367df7('0x77'), _0x367df7('0x78'), _0x367df7('0xab'), _0x367df7('0x7a'), _0x367df7('0xac'), _0x367df7('0x7c'), _0x367df7('0xad')]) && getDropdownValue(_0x182fe0, 0x1)) _0x1587fe += 0x1;
    if (UI[_0x367df7('0x34')]([_0x367df7('0x77'), _0x367df7('0x78'), _0x367df7('0xab'), _0x367df7('0x7a'), _0x367df7('0xac'), _0x367df7('0x7c'), _0x367df7('0x93')]) && getDropdownValue(_0x182fe0, 0x2)) _0x1587fe += 0x1;
    if (UI[_0x367df7('0x34')]([_0x367df7('0x77'), _0x367df7('0x78'), _0x367df7('0x7b'), _0x367df7('0x7a'), _0x367df7('0x7b'), _0x367df7('0x7c'), _0x367df7('0x7d')]) && getDropdownValue(_0x182fe0, 0x0)) _0x1587fe += 0x1;
    if (UI[_0x367df7('0x34')]([_0x367df7('0x77'), _0x367df7('0x78'), _0x367df7('0x7b'), _0x367df7('0x7a'), _0x367df7('0x7b'), _0x367df7('0x7c'), _0x367df7('0xae')]) && getDropdownValue(_0x182fe0, 0x3)) _0x1587fe += 0x1;
    if (UI[_0x367df7('0x34')]([_0x367df7('0x77'), _0x367df7('0x78'), _0x367df7('0x7b'), _0x367df7('0x7a'), _0x367df7('0x7b'), _0x367df7('0x7c'), _0x367df7('0x87')]) && getDropdownValue(_0x182fe0, 0x4)) _0x1587fe += 0x1;
    return _0x1587fe;
}

function radiansToDegrees(_0x4f6c18) {
    var _0x1ce434 = Math.PI;
    return _0x4f6c18 * (0xb4 / _0x1ce434);
}

function convertMatrix(_0x1be573) {
    var _0x312330 = var_0x5baa;
    return _0x1be573[_0x312330('0xaf')]('')[_0x312330('0xb0')](function(_0x228810, _0x398eff) {
        var _0x407f0e = var_0x5baa;
        return _0x228810 = (_0x228810 << 0x5) - _0x228810 + _0x398eff[_0x407f0e('0xb1')](0x0), _0x228810 & _0x228810;
    }, 0x0);
}

function worldToScreen(_0x4929d2, _0x121a61) {
    var _0x53682a = var_0x5baa;
    if (_0x4929d2 == 0x0 && _0x121a61 == 0x0) return 0x0;
    return radiansToDegrees(Math[_0x53682a('0xb2')](_0x121a61, _0x4929d2));
}

function DodgeBruteforce() {
    var _0x470fd4 = var_0x5baa;
    if (UI[_0x470fd4('0x34')]([_0x470fd4('0x77'), _0x470fd4('0x78'), _0x470fd4('0x7b'), _0x470fd4('0x7a'), _0x470fd4('0x7b'), _0x470fd4('0x7c'), _0x470fd4('0x7d')])) {
        shouldDisableOverride = !![], AntiAim[_0x470fd4('0x6a')](0x1);
        var _0x486df0 = -0x9,
            _0x2f310a = 0x0,
            _0x3584ce = !![],
            _0x521ff1 = 0x1e,
            _0x2411e4 = 0x11,
            _0x5b1f26 = _0x3584ce ? _0x521ff1 : _0x521ff1 * 0x2;
        AntiAim[_0x470fd4('0x6c')](_0x2f310a), _0x486df0 > 0x0 ? (AntiAim[_0x470fd4('0x6b')](_0x2f310a - _0x486df0 + _0x5b1f26), _0x486df0 < _0x2411e4 && (_0x2411e4 = _0x486df0), _0x3584ce ? AntiAim[_0x470fd4('0x6d')](_0x2f310a - _0x2411e4) : AntiAim[_0x470fd4('0x6d')](_0x2f310a + _0x486df0 - _0x2411e4 * 0x2)) : (_0x486df0 > _0x2411e4 && (_0x2411e4 = _0x486df0), AntiAim[_0x470fd4('0x6b')](_0x2f310a - _0x486df0 - _0x5b1f26), _0x3584ce ? AntiAim[_0x470fd4('0x6d')](_0x2f310a + _0x2411e4) : AntiAim[_0x470fd4('0x6d')](_0x2f310a + _0x486df0 + _0x2411e4 * 0x2));
    }!UI[_0x470fd4('0x34')]([_0x470fd4('0x77'), _0x470fd4('0x78'), _0x470fd4('0x7b'), _0x470fd4('0x7a'), _0x470fd4('0x7b'), _0x470fd4('0x7c'), _0x470fd4('0x7d')]) && shouldDisableOverride == !![] && (shouldDisableOverride = ![], AntiAim[_0x470fd4('0x6a')](0x0));
}

function GetMaxDesync(_0x923e67) {
    var _0x4f045d = var_0x5baa,
        _0x16123e = Entity[_0x4f045d('0x5f')](_0x923e67, _0x4f045d('0xb3'), _0x4f045d('0xb4')),
        _0x5ee850 = Math[_0x4f045d('0xb5')](_0x16123e[0x0] * _0x16123e[0x0] + _0x16123e[0x1] * _0x16123e[0x1]);
    return 0x3a - 0x3a * _0x5ee850 / 0x244;
}

function IsInAir(_0x5f16a2) {
    var _0x4f9a54 = var_0x5baa,
        _0x492dc0 = Entity[_0x4f9a54('0x5f')](_0x5f16a2, _0x4f9a54('0xb3'), _0x4f9a54('0xb6'));
    if (!(_0x492dc0 & 0x1 << 0x0) && !(_0x492dc0 & 0x1 << 0x12)) return !![];
    else return ![];
}

function IsCrouchTerrorist(_0x14817f) {
    var _0x4f7591 = var_0x5baa,
        _0x4bbb70 = Entity[_0x4f7591('0x5f')](_0x14817f, _0x4f7591('0xb3'), _0x4f7591('0xb7')),
        _0x2bfa74 = Entity[_0x4f7591('0x5f')](_0x14817f, _0x4f7591('0xb3'), _0x4f7591('0xb6'));
    if (_0x4bbb70 == 0x2 && _0x2bfa74 & 0x1 << 0x1) return !![];
    else return ![];
}

function IsCrouch(_0x1c403b) {
    var _0x4d7d06 = var_0x5baa,
        _0x570161 = Entity[_0x4d7d06('0x5f')](_0x1c403b, _0x4d7d06('0xb3'), _0x4d7d06('0xb6'));
    if (_0x570161 & 0x1 << 0x1) return !![];
    else return ![];
}

function GetLocalPlayerWeaponCategory() {
    var _0x359c2f = var_0x5baa,
        _0x5afb4b = Entity[_0x359c2f('0x5b')](Entity[_0x359c2f('0x5c')](Entity[_0x359c2f('0x4f')]()));
    switch (_0x5afb4b) {
        case _0x359c2f('0xb8'):
            return _0x359c2f('0xb9');
            break;
        case _0x359c2f('0xba'):
            return _0x359c2f('0xbb');
            break;
        case _0x359c2f('0xbc'):
            return _0x359c2f('0xbd');
            break;
        case _0x359c2f('0xbe'):
            return _0x359c2f('0xbf');
            break;
        case _0x359c2f('0xc0'):
            return _0x359c2f('0xc1');
            break;
        case _0x359c2f('0xc2'):
            return _0x359c2f('0xc3');
            break;
        default:
            return _0x359c2f('0x7b');
            break;
    }
}

function GetClosestEnemyToCrosshair() {
    var _0x60b2e8 = var_0x5baa,
        _0x4edef5 = Global[_0x60b2e8('0x11')](),
        _0xb28f65 = -0x1;
    localPlayer = Entity[_0x60b2e8('0x4f')](), localPlayerAlive = Entity[_0x60b2e8('0x57')](localPlayer);
    if (!localPlayer) return;
    if (!localPlayerAlive) return;
    localPlayerWeapon = Entity[_0x60b2e8('0x5b')](Entity[_0x60b2e8('0x5c')](localPlayer)), enemiesArr = Entity[_0x60b2e8('0x4d')]();
    if (!enemiesArr) return;
    var _0x4553a4 = 0xb4,
        _0x3c3f4a = Entity[_0x60b2e8('0x5f')](localPlayer, _0x60b2e8('0xc4'), _0x60b2e8('0xc5')),
        _0x400e77 = Global[_0x60b2e8('0xd')]();
    for (var _0x1268eb = 0x0; _0x1268eb < enemiesArr[_0x60b2e8('0xc6')]; _0x1268eb++) {
        if (!Entity[_0x60b2e8('0x57')](enemiesArr[_0x1268eb])) continue;
        var _0x4b664b = Entity[_0x60b2e8('0x5f')](enemiesArr[_0x1268eb], _0x60b2e8('0xc4'), _0x60b2e8('0xc5')),
            _0x4a988a = Math[_0x60b2e8('0xc7')](normalizeYaw(worldToScreen(_0x3c3f4a[0x0] - _0x4b664b[0x0], _0x3c3f4a[0x1] - _0x4b664b[0x1]) - _0x400e77[0x1] + 0xb4));
        _0x4a988a < _0x4553a4 && (_0x4553a4 = _0x4a988a, _0xb28f65 = enemiesArr[_0x1268eb]);
    }
    return _0xb28f65;
}

function SetHitchanceInAir() {
    var _0x38a63a = var_0x5baa;
    if (!UI[_0x38a63a('0x34')]([_0x38a63a('0x77'), _0x38a63a('0x78'), _0x38a63a('0x79'), _0x38a63a('0x7a'), _0x38a63a('0x79'), _0x38a63a('0xa6')])) return;
    var _0xc98c3f = Entity[_0x38a63a('0x5b')](Entity[_0x38a63a('0x5c')](Entity[_0x38a63a('0x4f')]()));
    if (_0xc98c3f != _0x38a63a('0xb8') && _0xc98c3f != _0x38a63a('0xbc')) return;
    var _0x2e5ffe = Entity[_0x38a63a('0x5f')](Entity[_0x38a63a('0x4f')](), _0x38a63a('0xb3'), _0x38a63a('0xb6'));
    !(_0x2e5ffe & 0x1 << 0x0) && !(_0x2e5ffe & 0x1 << 0x12) && (target = Ragebot[_0x38a63a('0xc8')](), value = UI[_0x38a63a('0x34')]([_0x38a63a('0x77'), _0x38a63a('0x78'), _0x38a63a('0x79'), _0x38a63a('0x7a'), _0x38a63a('0x79'), _0x38a63a('0xa7')]), Ragebot[_0x38a63a('0xc9')](target, value));
}

function CanShootHead() {
    var _0x5423cb = var_0x5baa;
    return CanShootHead = function() {}, Cheat[_0x5423cb('0x16')][_0x5423cb('0xca')]() != _0x5423cb('0xcb');
}

function ExtrapolateTick(_0x46722b) {
    var _0x5e5658 = var_0x5baa,
        _0x455862 = Entity[_0x5e5658('0x4f')](),
        _0x5212ae = Entity[_0x5e5658('0x61')](_0x455862, 0x0),
        _0x11ae3b = Entity[_0x5e5658('0x5f')](_0x455862, _0x5e5658('0xb3'), _0x5e5658('0xb4')),
        _0x294d2a = [];
    return _0x294d2a[0x0] = _0x5212ae[0x0] + _0x11ae3b[0x0] * Globals[_0x5e5658('0x8')]() * _0x46722b, _0x294d2a[0x1] = _0x5212ae[0x1] + _0x11ae3b[0x1] * Globals[_0x5e5658('0x8')]() * _0x46722b, _0x294d2a[0x2] = _0x5212ae[0x2] + _0x11ae3b[0x2] * Globals[_0x5e5658('0x8')]() * _0x46722b, _0x294d2a;
}

function IsLethal(_0x2bd00e) {
    var _0x373fb7 = var_0x5baa,
        _0x5818d8 = Entity[_0x373fb7('0x5f')](_0x2bd00e, _0x373fb7('0xb3'), _0x373fb7('0xcc'));
    pelvis_pos = Entity[_0x373fb7('0x61')](_0x2bd00e, 0x2), body_pos = Entity[_0x373fb7('0x61')](_0x2bd00e, 0x3), thorax_pos = Entity[_0x373fb7('0x61')](_0x2bd00e, 0x4);
    var _0x46d972 = [0x0, -0x1],
        _0x28d22e = [0x0, -0x1],
        _0x459756 = [0x0, -0x1],
        _0x1448d1 = [0x0, -0x1];
    result_thorax = Trace[_0x373fb7('0x63')](Entity[_0x373fb7('0x4f')](), _0x2bd00e, Entity[_0x373fb7('0x62')](Entity[_0x373fb7('0x4f')]()), thorax_pos);
    if (result_thorax[0x1] >= _0x5818d8) return !![];
    if (!UI[_0x373fb7('0x34')]([_0x373fb7('0x77'), _0x373fb7('0x78'), _0x373fb7('0x79'), _0x373fb7('0x7a'), _0x373fb7('0x79'), _0x373fb7('0xa5')])) {
        _0x28d22e = Trace[_0x373fb7('0x63')](Entity[_0x373fb7('0x4f')](), _0x2bd00e, Entity[_0x373fb7('0x62')](Entity[_0x373fb7('0x4f')]()), pelvis_pos), _0x46d972 = Trace[_0x373fb7('0x63')](Entity[_0x373fb7('0x4f')](), _0x2bd00e, Entity[_0x373fb7('0x62')](Entity[_0x373fb7('0x4f')]()), body_pos);
        if (_0x28d22e[0x1] >= _0x5818d8) return !![];
        if (_0x46d972[0x1] >= _0x5818d8) return !![];
    }
    result_thorax_extrapolated = Trace[_0x373fb7('0x63')](Entity[_0x373fb7('0x4f')](), _0x2bd00e, ExtrapolateTick(0x14), thorax_pos);
    if (result_thorax_extrapolated[0x1] >= _0x5818d8) return Ragebot[_0x373fb7('0xcd')](_0x2bd00e), !![];
    if (!UI[_0x373fb7('0x34')]([_0x373fb7('0x77'), _0x373fb7('0x78'), _0x373fb7('0x79'), _0x373fb7('0x7a'), _0x373fb7('0x79'), _0x373fb7('0xa5')])) {
        _0x1448d1 = Trace[_0x373fb7('0x63')](Entity[_0x373fb7('0x4f')](), _0x2bd00e, ExtrapolateTick(0x19), pelvis_pos), _0x459756 = Trace[_0x373fb7('0x63')](Entity[_0x373fb7('0x4f')](), _0x2bd00e, ExtrapolateTick(0x19), body_pos);
        if (_0x1448d1[0x1] >= _0x5818d8) return !![];
        if (_0x459756[0x1] >= _0x5818d8) return !![];
    }
    return ![];
}

function IsExploitCharged() {
    var _0x381fa4 = var_0x5baa;
    if (Exploit[_0x381fa4('0x6e')]() == 0x1) return !![];
    return ![];
}

function NoScopeHitchance() {
    var _0x4edf05 = var_0x5baa;
    if (!UI[_0x4edf05('0x34')]([_0x4edf05('0x77'), _0x4edf05('0x78'), _0x4edf05('0x79'), _0x4edf05('0x7a'), _0x4edf05('0x79'), _0x4edf05('0xa8')])) return;
    var _0x38c532 = Entity[_0x4edf05('0x5b')](Entity[_0x4edf05('0x5c')](Entity[_0x4edf05('0x4f')]()));
    if (_0x38c532 != _0x4edf05('0xbe') && _0x38c532 != _0x4edf05('0xc0') && _0x38c532 != _0x4edf05('0xb8') && _0x38c532 != _0x4edf05('0xc2')) return;
    var _0x3f69cb = Entity[_0x4edf05('0x5f')](Entity[_0x4edf05('0x4f')](), _0x4edf05('0xce'), _0x4edf05('0xcf'));
    if (!_0x3f69cb) Ragebot[_0x4edf05('0xc9')](Ragebot[_0x4edf05('0xc8')](), UI[_0x4edf05('0x34')]([_0x4edf05('0x77'), _0x4edf05('0x78'), _0x4edf05('0x79'), _0x4edf05('0x7a'), _0x4edf05('0x79'), _0x4edf05('0xa9')]));
}

function AttemptTwoShotKill(_0x1862a3) {
    var _0x5b54b2 = var_0x5baa;
    if (!UI[_0x5b54b2('0x34')]([_0x5b54b2('0x77'), _0x5b54b2('0x78'), _0x5b54b2('0x79'), _0x5b54b2('0x7a'), _0x5b54b2('0x79'), _0x5b54b2('0x97')])) return ![];
    if (UI[_0x5b54b2('0x34')]([_0x5b54b2('0x77'), _0x5b54b2('0x78'), _0x5b54b2('0xd0'), _0x5b54b2('0x7a'), _0x5b54b2('0x7b'), _0x5b54b2('0x7c'), _0x5b54b2('0xd1')])) return ![];
    var _0x3571e8 = Entity[_0x5b54b2('0x5b')](Entity[_0x5b54b2('0x5c')](Entity[_0x5b54b2('0x4f')]()));
    if (_0x3571e8 != _0x5b54b2('0xbe') && _0x3571e8 != _0x5b54b2('0xc0')) return ![];
    if (!UI[_0x5b54b2('0x34')]([_0x5b54b2('0x77'), _0x5b54b2('0x78'), _0x5b54b2('0xab'), _0x5b54b2('0x7a'), _0x5b54b2('0xac'), _0x5b54b2('0x7c'), _0x5b54b2('0xad')])) return ![];
    Ragebot[_0x5b54b2('0xd2')](0x0);
    var _0x160b38 = Entity[_0x5b54b2('0x5f')](_0x1862a3, _0x5b54b2('0xb3'), _0x5b54b2('0xcc')),
        _0x53e958 = GetClosestEnemyToCrosshair();
    pelvis_pos = Entity[_0x5b54b2('0x61')](_0x1862a3, 0x2), body_pos = Entity[_0x5b54b2('0x61')](_0x1862a3, 0x3), thorax_pos = Entity[_0x5b54b2('0x61')](_0x1862a3, 0x4);
    var _0x3a48d2 = [0x0, -0x1],
        _0x5104b6 = [0x0, -0x1],
        _0x322c7b = [0x0, -0x1],
        _0x12fdeb = [0x0, -0x1];
    result_thorax = Trace[_0x5b54b2('0x63')](Entity[_0x5b54b2('0x4f')](), _0x1862a3, Entity[_0x5b54b2('0x62')](Entity[_0x5b54b2('0x4f')]()), thorax_pos);
    if (_0x1862a3 = _0x53e958) dynamicDamage = result_thorax[0x1];
    if (result_thorax[0x1] * 0x2 >= _0x160b38 && IsExploitCharged() == !![]) return Ragebot[_0x5b54b2('0xd3')](_0x1862a3, _0x160b38 / 0x2 + 0x1), !![];
    if (!UI[_0x5b54b2('0x34')]([_0x5b54b2('0x77'), _0x5b54b2('0x78'), _0x5b54b2('0x79'), _0x5b54b2('0x7a'), _0x5b54b2('0x79'), _0x5b54b2('0xa5')])) {
        _0x5104b6 = Trace[_0x5b54b2('0x63')](Entity[_0x5b54b2('0x4f')](), _0x1862a3, Entity[_0x5b54b2('0x62')](Entity[_0x5b54b2('0x4f')]()), pelvis_pos), _0x3a48d2 = Trace[_0x5b54b2('0x63')](Entity[_0x5b54b2('0x4f')](), _0x1862a3, Entity[_0x5b54b2('0x62')](Entity[_0x5b54b2('0x4f')]()), body_pos);
        if (_0x1862a3 = _0x53e958) dynamicDamage = _0x5104b6[0x1];
        if (_0x5104b6[0x1] * 0x2 >= _0x160b38 && IsExploitCharged() == !![]) return Ragebot[_0x5b54b2('0xd3')](_0x1862a3, _0x160b38 / 0x2 + 0x1), !![];
        if (_0x1862a3 = _0x53e958) dynamicDamage = _0x3a48d2[0x1];
        if (_0x3a48d2[0x1] * 0x2 >= _0x160b38 && IsExploitCharged() == !![]) return Ragebot[_0x5b54b2('0xd3')](_0x1862a3, _0x160b38 / 0x2 + 0x1), !![];
    }
    result_thorax_extrapolated = Trace[_0x5b54b2('0x63')](Entity[_0x5b54b2('0x4f')](), _0x1862a3, ExtrapolateTick(0xf), thorax_pos);
    if (_0x1862a3 = _0x53e958) dynamicDamage = result_thorax_extrapolated[0x1];
    if (result_thorax_extrapolated[0x1] * 0x2 >= _0x160b38 && IsExploitCharged() == !![]) return Ragebot[_0x5b54b2('0xd3')](_0x1862a3, _0x160b38 / 0x2 + 0x1), !![];
    if (!UI[_0x5b54b2('0x34')]([_0x5b54b2('0x77'), _0x5b54b2('0x78'), _0x5b54b2('0x79'), _0x5b54b2('0x7a'), _0x5b54b2('0x79'), _0x5b54b2('0xa5')])) {
        _0x12fdeb = Trace[_0x5b54b2('0x63')](Entity[_0x5b54b2('0x4f')](), _0x1862a3, ExtrapolateTick(0x19), pelvis_pos), _0x322c7b = Trace[_0x5b54b2('0x63')](Entity[_0x5b54b2('0x4f')](), _0x1862a3, ExtrapolateTick(0x19), body_pos);
        if (_0x1862a3 = _0x53e958) dynamicDamage = _0x12fdeb[0x1];
        if (_0x12fdeb[0x1] * 0x2 >= _0x160b38 && IsExploitCharged() == !![]) return Ragebot[_0x5b54b2('0xd3')](_0x1862a3, _0x160b38 / 0x2 + 0x1), !![];
        if (_0x1862a3 = _0x53e958) dynamicDamage = _0x322c7b[0x1];
        if (_0x322c7b[0x1] * 0x2 >= _0x160b38 && IsExploitCharged() == !![]) return Ragebot[_0x5b54b2('0xd3')](_0x1862a3, _0x160b38 / 0x2 + 0x1), !![];
    }
    dynamicDamage = 0x0;
}

function DrawDynamicDamage() {
    var _0x5639c4 = var_0x5baa;
    if (!UI[_0x5639c4('0x34')]([_0x5639c4('0x77'), _0x5639c4('0x78'), _0x5639c4('0x79'), _0x5639c4('0x7a'), _0x5639c4('0x79'), _0x5639c4('0x8e')])) return;
    if (!UI[_0x5639c4('0x34')]([_0x5639c4('0x77'), _0x5639c4('0x78'), _0x5639c4('0x79'), _0x5639c4('0x7a'), _0x5639c4('0x79'), _0x5639c4('0x97')])) return;
    if (UI[_0x5639c4('0x34')]([_0x5639c4('0x77'), _0x5639c4('0x78'), _0x5639c4('0xd0'), _0x5639c4('0x7a'), _0x5639c4('0x7b'), _0x5639c4('0x7c'), _0x5639c4('0xd1')])) return;
    var _0x246afe = Entity[_0x5639c4('0x5b')](Entity[_0x5639c4('0x5c')](Entity[_0x5639c4('0x4f')]()));
    if (_0x246afe != _0x5639c4('0xbe') && _0x246afe != _0x5639c4('0xc0')) return;
    if (!UI[_0x5639c4('0x34')]([_0x5639c4('0x77'), _0x5639c4('0x78'), _0x5639c4('0xab'), _0x5639c4('0x7a'), _0x5639c4('0xac'), _0x5639c4('0x7c'), _0x5639c4('0xad')])) return;
    if (IsInAir(Entity[_0x5639c4('0x4f')]())) return;
    var _0x5b5183 = Entity[_0x5639c4('0x4f')](),
        _0x3b55a8 = Entity[_0x5639c4('0x5e')](_0x5b5183),
        _0xe0cac8 = Entity[_0x5639c4('0x5f')](_0x5b5183, _0x5639c4('0xb3'), _0x5639c4('0xb4')),
        _0x194e01 = 0x3e7,
        _0x4aa65b = GetClosestEnemyToCrosshair();
    if (Entity[_0x5639c4('0x56')](_0x4aa65b) && Entity[_0x5639c4('0x57')](_0x4aa65b) && !Entity[_0x5639c4('0x58')](_0x4aa65b)) _0x194e01 = Entity[_0x5639c4('0x5f')](_0x4aa65b, _0x5639c4('0xb3'), _0x5639c4('0xcc'));
    var _0x5023c4 = [];
    _0x5023c4[0x0] = _0x3b55a8[0x0] + _0xe0cac8[0x0] * Globals[_0x5639c4('0x8')]() * 0xf, _0x5023c4[0x1] = _0x3b55a8[0x1] + _0xe0cac8[0x1] * Globals[_0x5639c4('0x8')]() * 0xf, _0x5023c4[0x2] = _0x3b55a8[0x2] + _0xe0cac8[0x2] * Globals[_0x5639c4('0x8')]() * 0xf;
    var _0x20b078 = Render[_0x5639c4('0x2d')](_0x5023c4);
    if (dynamicDamage >= _0x194e01 / 0x2) color = [0x0, 0xff, 0x0, 0xff];
    else color = [0xff, 0x0, 0x0, 0xff];
    Render[_0x5639c4('0x2a')](_0x20b078[0x0], _0x20b078[0x1], 0x2, [0xff, 0xff, 0xff, 0xff]), Render[_0x5639c4('0x24')](_0x20b078[0x0], _0x20b078[0x1] - 0xf, 0x1, _0x5639c4('0xd4') + dynamicDamage, color, font);
}

function IsStanding(_0x739ffc) {
    var _0x3723a4 = var_0x5baa,
        _0x1748c1 = Entity[_0x3723a4('0x5f')](_0x739ffc, _0x3723a4('0xb3'), _0x3723a4('0xb4')),
        _0x32ebb4 = Math[_0x3723a4('0xb5')](_0x1748c1[0x0] * _0x1748c1[0x0] + _0x1748c1[0x1] * _0x1748c1[0x1]);
    if (_0x32ebb4 <= 0x5) return !![];
    else return ![];
}

function IsSlowWalking(_0x3c0260) {
    var _0x2c06ca = var_0x5baa,
        _0x37f62d = Entity[_0x2c06ca('0x5f')](_0x3c0260, _0x2c06ca('0xb3'), _0x2c06ca('0xb4')),
        _0x54c861 = Math[_0x2c06ca('0xb5')](_0x37f62d[0x0] * _0x37f62d[0x0] + _0x37f62d[0x1] * _0x37f62d[0x1]);
    if (_0x54c861 >= 0xa && _0x54c861 <= 0x55) return !![];
    else return ![];
}

function ForceHead(_0x903bb0) {
    var _0x14995e = var_0x5baa;
    DisableBaim();
    var _0x243aed = Entity[_0x14995e('0x5f')](_0x903bb0, _0x14995e('0xb3'), _0x14995e('0xcc'));
    head_pos = Entity[_0x14995e('0x61')](_0x903bb0, 0x0), result_head = Trace[_0x14995e('0x63')](Entity[_0x14995e('0x4f')](), _0x903bb0, Entity[_0x14995e('0x62')](Entity[_0x14995e('0x4f')]()), head_pos), result_head[0x1] > 0x0 && result_head[0x1] >= UI[_0x14995e('0x34')]([_0x14995e('0x77'), _0x14995e('0x78'), _0x14995e('0xd5'), _0x14995e('0x7a'), GetLocalPlayerWeaponCategory(), _0x14995e('0x89')]) && Ragebot[_0x14995e('0xd3')](_0x903bb0, result_head[0x1]);
}

function AimForHeadIfShooting() {
    var _0x3f37ee = var_0x5baa;
    AimForHeadIfShooting = function() {}, onShotTargets = conditionFlags[_0x3f37ee('0xaf')]('|'), (CanShootHead() == !![] || onShotTargets[_0x3f37ee('0xd6')](Cheat[_0x3f37ee('0x16')]()[_0x3f37ee('0xd7')]()) == -0x1) && cheat_override_damage(_0x3f37ee('0xd8'));
}

function ForceBaim(_0x1d1fa1) {
    var _0x37cac3 = var_0x5baa;
    !UI[_0x37cac3('0x34')]([_0x37cac3('0x77'), _0x37cac3('0x78'), _0x37cac3('0x7b'), _0x37cac3('0x7a'), _0x37cac3('0x7b'), _0x37cac3('0x7c'), _0x37cac3('0xd9')]) && UI[_0x37cac3('0x43')]([_0x37cac3('0x77'), _0x37cac3('0x78'), _0x37cac3('0x7b'), _0x37cac3('0x7a'), _0x37cac3('0x7b'), _0x37cac3('0x7c'), _0x37cac3('0xd9')]), Ragebot[_0x37cac3('0xd2')](0x0);
}

function DisableBaim() {
    var _0x13c6d7 = var_0x5baa;
    if (UI[_0x13c6d7('0x34')]([_0x13c6d7('0x77'), _0x13c6d7('0x78'), _0x13c6d7('0x7b'), _0x13c6d7('0x7a'), _0x13c6d7('0x7b'), _0x13c6d7('0x7c'), _0x13c6d7('0xd9')])) UI[_0x13c6d7('0x43')]([_0x13c6d7('0x77'), _0x13c6d7('0x78'), _0x13c6d7('0x7b'), _0x13c6d7('0x7a'), _0x13c6d7('0x7b'), _0x13c6d7('0x7c'), _0x13c6d7('0xd9')]);
}

function WaitForOnShot() {
    var _0x2c7010 = var_0x5baa,
        _0x5c8fe4 = Entity[_0x2c7010('0x4d')]();
    for (i = 0x0; i < _0x5c8fe4[_0x2c7010('0xc6')]; i++) {
        if (!Entity[_0x2c7010('0x56')](_0x5c8fe4[i])) continue;
        if (!Entity[_0x2c7010('0x57')](_0x5c8fe4[i])) continue;
        if (Entity[_0x2c7010('0x58')](_0x5c8fe4[i])) continue;
        var _0x2741a5 = Entity[_0x2c7010('0x5c')](_0x5c8fe4[i]),
            _0x151c8f = Entity[_0x2c7010('0x5f')](_0x2741a5, _0x2c7010('0xda'), _0x2c7010('0xdb'));
        _0x151c8f != storedShotTime[_0x5c8fe4[i]] ? (firedThisTick[_0x5c8fe4[i]] = !![], storedShotTime[_0x5c8fe4[i]] = _0x151c8f) : firedThisTick[_0x5c8fe4[i]] = ![];
        if (!UI[_0x2c7010('0x34')]([_0x2c7010('0x77'), _0x2c7010('0x78'), _0x2c7010('0x7b'), _0x2c7010('0x7a'), _0x2c7010('0x7b'), _0x2c7010('0x7c'), _0x2c7010('0x7f')])) return;
        firedThisTick[_0x5c8fe4[i]] == !![] ? ForceHead(_0x5c8fe4[i]) : (Ragebot[_0x2c7010('0xdc')](_0x5c8fe4[i]), info[_0x5c8fe4[i]] = _0x2c7010('0xdd'));
    }
}

function deg2rad(_0x10f79d) {
    return _0x10f79d * Math.PI / 0xb4;
}

function angle_to_vec(_0x161288, _0x2fef58) {
    var _0x39200c = var_0x5baa,
        _0x1884af = deg2rad(_0x161288),
        _0x408f65 = deg2rad(_0x2fef58),
        _0x5b2a59 = Math[_0x39200c('0xde')](_0x1884af),
        _0x6fa6ab = Math[_0x39200c('0xdf')](_0x1884af),
        _0x4eb173 = Math[_0x39200c('0xde')](_0x408f65),
        _0x11edc4 = Math[_0x39200c('0xdf')](_0x408f65);
    return [_0x6fa6ab * _0x11edc4, _0x6fa6ab * _0x4eb173, -_0x5b2a59];
}

function trace(_0x4a9cf1, _0x12f856) {
    var _0x3db843 = var_0x5baa,
        _0x5ba660 = angle_to_vec(_0x12f856[0x0], _0x12f856[0x1]),
        _0x5c9b30 = Entity[_0x3db843('0x5e')](_0x4a9cf1);
    _0x5c9b30[0x2] += 0x32;
    var _0x1742d4 = [_0x5c9b30[0x0] + _0x5ba660[0x0] * 0x2000, _0x5c9b30[0x1] + _0x5ba660[0x1] * 0x2000, _0x5c9b30[0x2] + _0x5ba660[0x2] * 0x2000],
        _0x369d2f = Trace[_0x3db843('0x26')](_0x4a9cf1, _0x5c9b30, _0x1742d4);
    if (_0x369d2f[0x1] == 0x1) return;
    _0x1742d4 = [_0x5c9b30[0x0] + _0x5ba660[0x0] * _0x369d2f[0x1] * 0x2000, _0x5c9b30[0x1] + _0x5ba660[0x1] * _0x369d2f[0x1] * 0x2000, _0x5c9b30[0x2] + _0x5ba660[0x2] * _0x369d2f[0x1] * 0x2000];
    var _0x42b38f = Math[_0x3db843('0xb5')]((_0x5c9b30[0x0] - _0x1742d4[0x0]) * (_0x5c9b30[0x0] - _0x1742d4[0x0]) + (_0x5c9b30[0x1] - _0x1742d4[0x1]) * (_0x5c9b30[0x1] - _0x1742d4[0x1]) + (_0x5c9b30[0x2] - _0x1742d4[0x2]) * (_0x5c9b30[0x2] - _0x1742d4[0x2]));
    _0x5c9b30 = Render[_0x3db843('0x2d')](_0x5c9b30), _0x1742d4 = Render[_0x3db843('0x2d')](_0x1742d4);
    if (_0x1742d4[0x2] != 0x1 || _0x5c9b30[0x2] != 0x1) return;
    return _0x42b38f;
}

function ReversedFreestanding() {
    var _0x2ac59e = var_0x5baa;
    if (!UI[_0x2ac59e('0x34')]([_0x2ac59e('0x77'), _0x2ac59e('0x78'), _0x2ac59e('0x79'), _0x2ac59e('0x7a'), _0x2ac59e('0x79'), _0x2ac59e('0x81')])) return;
    var _0x222bc6 = Entity[_0x2ac59e('0x4f')]();
    if (Entity[_0x2ac59e('0x56')](_0x222bc6)) {
        var _0x308202 = Entity[_0x2ac59e('0x62')](_0x222bc6);
        left_distance = trace(_0x222bc6, [0x0, _0x308202[0x1] - 0x21]), right_distance = trace(_0x222bc6, [0x0, _0x308202[0x1] + 0x21]);
        if (left_distance > right_distance) {
            if (UI[_0x2ac59e('0x34')]([_0x2ac59e('0x77'), _0x2ac59e('0x78'), _0x2ac59e('0xd0'), _0x2ac59e('0x7a'), _0x2ac59e('0x7b'), _0x2ac59e('0x7c'), _0x2ac59e('0xe0')])) UI[_0x2ac59e('0x43')]([_0x2ac59e('0x77'), _0x2ac59e('0x78'), _0x2ac59e('0xd0'), _0x2ac59e('0x7a'), _0x2ac59e('0x7b'), _0x2ac59e('0x7c'), _0x2ac59e('0xe0')]);
        }
        if (right_distance > left_distance) {
            if (!UI[_0x2ac59e('0x34')]([_0x2ac59e('0x77'), _0x2ac59e('0x78'), _0x2ac59e('0xd0'), _0x2ac59e('0x7a'), _0x2ac59e('0x7b'), _0x2ac59e('0x7c'), _0x2ac59e('0xe0')])) UI[_0x2ac59e('0x43')]([_0x2ac59e('0x77'), _0x2ac59e('0x78'), _0x2ac59e('0xd0'), _0x2ac59e('0x7a'), _0x2ac59e('0x7b'), _0x2ac59e('0x7c'), _0x2ac59e('0xe0')]);
        }
    }
}

function distanceVector(_0x3e69e7, _0x4ed738) {
    var _0x431f60 = var_0x5baa,
        _0x2249e1 = _0x3e69e7[0x0] - _0x4ed738[0x0],
        _0x22a6cf = _0x3e69e7[0x1] - _0x4ed738[0x1],
        _0x37f10b = _0x3e69e7[0x2] - _0x4ed738[0x2];
    return Math[_0x431f60('0xb5')](_0x2249e1 * _0x2249e1 + _0x22a6cf * _0x22a6cf + _0x37f10b * _0x37f10b);
}
var cachedYawOffset = undefined;

function DesyncOnUse() {
    var _0x4fe078 = var_0x5baa;
    if (!UI[_0x4fe078('0x34')]([_0x4fe078('0x77'), _0x4fe078('0x78'), _0x4fe078('0x79'), _0x4fe078('0x7a'), _0x4fe078('0x79'), _0x4fe078('0x82')])) return;
    if (!Entity[_0x4fe078('0x56')](Entity[_0x4fe078('0x4f')]())) return;
    var _0x553618 = Entity[_0x4fe078('0x5f')](Entity[_0x4fe078('0x4f')](), _0x4fe078('0xc4'), _0x4fe078('0xb7'));
    if (_0x553618 == 0x2 && Entity[_0x4fe078('0x5b')](Entity[_0x4fe078('0x5c')](Entity[_0x4fe078('0x4f')]())) == _0x4fe078('0xe1')) {
        Cheat[_0x4fe078('0x4')](_0x4fe078('0xe2'));
        return;
    }
    if (cachedYawOffset == undefined) cachedYawOffset = UI[_0x4fe078('0x34')]([_0x4fe078('0x77'), _0x4fe078('0x78'), _0x4fe078('0xd0'), _0x4fe078('0x7a'), _0x4fe078('0xe3'), _0x4fe078('0xe4')]);
    var _0x393f1a = Entity[_0x4fe078('0x4a')](),
        _0x4aa8f5 = undefined,
        _0xd38ccf = Number[_0x4fe078('0xe5')];
    for (i = 0x1; i < _0x393f1a[_0x4fe078('0xc6')]; i++) {
        Entity[_0x4fe078('0x59')](_0x393f1a[i]) == 0x61 && (_0xd38ccf > distanceVector(Entity[_0x4fe078('0x5e')](_0x393f1a[i]), Entity[_0x4fe078('0x5e')](Entity[_0x4fe078('0x4f')]())) && (_0xd38ccf = distanceVector(Entity[_0x4fe078('0x5e')](_0x393f1a[i]), Entity[_0x4fe078('0x5e')](Entity[_0x4fe078('0x4f')]()))));
        if (Entity[_0x4fe078('0x59')](_0x393f1a[i]) == 0x80) {
            _0x4aa8f5 = _0x393f1a[i];
            break;
        }
    }
    if (_0xd38ccf != Number[_0x4fe078('0xe5')]) {
        if (_0xd38ccf <= 0x41) {
            Cheat[_0x4fe078('0x4')](_0x4fe078('0xe2')), Cheat[_0x4fe078('0x0')](_0x4fe078('0xe6'));
            return;
        }
    }
    if (_0x4aa8f5 != undefined) {
        var _0x3a19cd = Entity[_0x4fe078('0x5e')](_0x4aa8f5),
            _0xe5aea8 = distanceVector(_0x3a19cd, Entity[_0x4fe078('0x5e')](Entity[_0x4fe078('0x4f')]()));
        if (_0xe5aea8 <= 0x41) {
            Cheat[_0x4fe078('0x4')](_0x4fe078('0xe2'));
            return;
        }
    }
    Input[_0x4fe078('0x10')](0x45) ? (UI[_0x4fe078('0x35')]([_0x4fe078('0xe7'), _0x4fe078('0x78'), _0x4fe078('0xe8'), _0x4fe078('0x7a'), _0x4fe078('0x7b'), _0x4fe078('0xe9')], 0x0), UI[_0x4fe078('0x35')]([_0x4fe078('0x77'), _0x4fe078('0x78'), _0x4fe078('0xd0'), _0x4fe078('0x7a'), _0x4fe078('0x7b'), _0x4fe078('0xea')], 0x0), Cheat[_0x4fe078('0x4')](_0x4fe078('0xeb')), Cheat[_0x4fe078('0x4')](_0x4fe078('0xec')), UI[_0x4fe078('0x35')]([_0x4fe078('0x77'), _0x4fe078('0x78'), _0x4fe078('0xd0'), _0x4fe078('0x7a'), _0x4fe078('0xe3'), _0x4fe078('0xe4')], 0xb4)) : (Cheat[_0x4fe078('0x4')](_0x4fe078('0xe2')), UI[_0x4fe078('0x35')]([_0x4fe078('0xe7'), _0x4fe078('0x78'), _0x4fe078('0xe8'), _0x4fe078('0x7a'), _0x4fe078('0x7b'), _0x4fe078('0xe9')], 0x1), cachedYawOffset != undefined && (UI[_0x4fe078('0x35')]([_0x4fe078('0x77'), _0x4fe078('0x78'), _0x4fe078('0xd0'), _0x4fe078('0x7a'), _0x4fe078('0xe3'), _0x4fe078('0xe4')], cachedYawOffset), cachedYawOffset = undefined));
}

function IsHoldingGrenade(_0x4a664d) {
    var _0x1ccdd8 = var_0x5baa;
    if (Entity[_0x1ccdd8('0x5b')](Entity[_0x1ccdd8('0x5c')](_0x4a664d)) == _0x1ccdd8('0xed') || Entity[_0x1ccdd8('0x5b')](Entity[_0x1ccdd8('0x5c')](_0x4a664d)) == _0x1ccdd8('0xee') || Entity[_0x1ccdd8('0x5b')](Entity[_0x1ccdd8('0x5c')](_0x4a664d)) == _0x1ccdd8('0xef')) return !![];
    return ![];
}

function DrawDanger(_0x51467f, _0x3c21d9, _0x2282cc) {
    var _0x130499 = var_0x5baa;
    Render[_0x130499('0x2b')](_0x51467f, _0x3c21d9, 0xf, [0x0, 0x0, 0x0, 0x7d]), Render[_0x130499('0x2a')](_0x51467f, _0x3c21d9, 0xf, _0x2282cc), Render[_0x130499('0x24')](_0x51467f - 0.5, _0x3c21d9 - 0x7, 0x1, '!', [0xff, 0xff, 0xff, 0xc8], font);
}

function DrawToggles() {
    var _0x5a4f67 = var_0x5baa;
    if (!UI[_0x5a4f67('0x34')]([_0x5a4f67('0x77'), _0x5a4f67('0x78'), _0x5a4f67('0x79'), _0x5a4f67('0x7a'), _0x5a4f67('0x79'), _0x5a4f67('0x8a')])) return;
    var _0x260dc9 = Global[_0x5a4f67('0x11')](),
        _0x447ffd;
    _0x447ffd = UI[_0x5a4f67('0x41')]([_0x5a4f67('0x77'), _0x5a4f67('0x78'), _0x5a4f67('0x79'), _0x5a4f67('0x7a'), _0x5a4f67('0x79'), _0x5a4f67('0x90')]);
    if (!UI[_0x5a4f67('0x34')]([_0x5a4f67('0x77'), _0x5a4f67('0x78'), _0x5a4f67('0x7b'), _0x5a4f67('0x7a'), _0x5a4f67('0x7b'), _0x5a4f67('0x7c'), _0x5a4f67('0x7d')]) && UI[_0x5a4f67('0x34')]([_0x5a4f67('0x77'), _0x5a4f67('0x78'), _0x5a4f67('0x79'), _0x5a4f67('0x7a'), _0x5a4f67('0x79'), _0x5a4f67('0x8f')])) UI[_0x5a4f67('0x34')]([_0x5a4f67('0x77'), _0x5a4f67('0x78'), _0x5a4f67('0xd0'), _0x5a4f67('0x7a'), _0x5a4f67('0x7b'), _0x5a4f67('0x7c'), _0x5a4f67('0xe0')]) ? (Render[_0x5a4f67('0x2c')]([
        [_0x260dc9[0x0] / 0x2 - 0x31, _0x260dc9[0x1] / 0x2 + 0x9],
        [_0x260dc9[0x0] / 0x2 - 0x41, _0x260dc9[0x1] / 0x2],
        [_0x260dc9[0x0] / 0x2 - 0x31, _0x260dc9[0x1] / 0x2 - 0x9]
    ], [0x0, 0x0, 0x0, 0x50]), Render[_0x5a4f67('0x2c')]([
        [_0x260dc9[0x0] / 0x2 + 0x31, _0x260dc9[0x1] / 0x2 - 0x9],
        [_0x260dc9[0x0] / 0x2 + 0x41, _0x260dc9[0x1] / 0x2],
        [_0x260dc9[0x0] / 0x2 + 0x31, _0x260dc9[0x1] / 0x2 + 0x9]
    ], _0x447ffd)) : (Render[_0x5a4f67('0x2c')]([
        [_0x260dc9[0x0] / 0x2 - 0x31, _0x260dc9[0x1] / 0x2 + 0x9],
        [_0x260dc9[0x0] / 0x2 - 0x41, _0x260dc9[0x1] / 0x2],
        [_0x260dc9[0x0] / 0x2 - 0x31, _0x260dc9[0x1] / 0x2 - 0x9]
    ], _0x447ffd), Render[_0x5a4f67('0x2c')]([
        [_0x260dc9[0x0] / 0x2 + 0x31, _0x260dc9[0x1] / 0x2 - 0x9],
        [_0x260dc9[0x0] / 0x2 + 0x41, _0x260dc9[0x1] / 0x2],
        [_0x260dc9[0x0] / 0x2 + 0x31, _0x260dc9[0x1] / 0x2 + 0x9]
    ], [0x0, 0x0, 0x0, 0x50]));
    var _0x6dd328 = GetActiveIndicators(),
        _0x4f74b8 = 0x0;
    if (UI[_0x5a4f67('0x34')]([_0x5a4f67('0x77'), _0x5a4f67('0x78'), _0x5a4f67('0xab'), _0x5a4f67('0x7a'), _0x5a4f67('0xac'), _0x5a4f67('0x7c'), _0x5a4f67('0xad')]) && getDropdownValue(UI[_0x5a4f67('0x34')]([_0x5a4f67('0x77'), _0x5a4f67('0x78'), _0x5a4f67('0x79'), _0x5a4f67('0x7a'), _0x5a4f67('0x79'), _0x5a4f67('0x91')]), 0x1)) {
        _0x4f74b8 += 0x1, Render[_0x5a4f67('0x24')](_0x260dc9[0x0] / 0x2, _0x260dc9[0x1] / 0x2 + (_0x6dd328 - _0x4f74b8) * 0xa + 0x14, 0x1, 'DT', [0x0, 0xff, 0x0, 0xff], indicatorFonts);
        const _0x277283 = -0xff * Exploit[_0x5a4f67('0x6e')]();
        Render[_0x5a4f67('0x27')](_0x260dc9[0x0] / 0x2 - 0x7, _0x260dc9[0x1] / 0x2 + (_0x6dd328 - _0x4f74b8) * 0xa + 0x3 + 0x1b, 0xd, 0x4, [0x0, 0x0, 0x0, 0x16]), Render[_0x5a4f67('0x29')](_0x260dc9[0x0] / 0x2 - 0x6, _0x260dc9[0x1] / 0x2 + (_0x6dd328 - _0x4f74b8) * 0xa + 0x4 + 0x1b, (Exploit[_0x5a4f67('0x6e')]() + 0.1) * 0xa, 0x2, 0x1, [_0x277283, 0xff, 0x0, 0x46], [_0x277283, 0xff, 0x0, 0xc8]);
    }
    UI[_0x5a4f67('0x34')]([_0x5a4f67('0x77'), _0x5a4f67('0x78'), _0x5a4f67('0x7b'), _0x5a4f67('0x7a'), _0x5a4f67('0x7b'), _0x5a4f67('0x7c'), _0x5a4f67('0x7d')]) && getDropdownValue(UI[_0x5a4f67('0x34')]([_0x5a4f67('0x77'), _0x5a4f67('0x78'), _0x5a4f67('0x79'), _0x5a4f67('0x7a'), _0x5a4f67('0x79'), _0x5a4f67('0x91')]), 0x0) && (_0x4f74b8 += 0x1, Render[_0x5a4f67('0x24')](_0x260dc9[0x0] / 0x2, _0x260dc9[0x1] / 0x2 + (_0x6dd328 - _0x4f74b8) * 0xa + 0x14, 0x1, _0x5a4f67('0xf0'), [0xff, 0xff, 0x0, 0xff], indicatorFonts)), UI[_0x5a4f67('0x34')]([_0x5a4f67('0x77'), _0x5a4f67('0x78'), _0x5a4f67('0x7b'), _0x5a4f67('0x7a'), _0x5a4f67('0x7b'), _0x5a4f67('0x7c'), _0x5a4f67('0xae')]) && getDropdownValue(UI[_0x5a4f67('0x34')]([_0x5a4f67('0x77'), _0x5a4f67('0x78'), _0x5a4f67('0x79'), _0x5a4f67('0x7a'), _0x5a4f67('0x79'), _0x5a4f67('0x91')]), 0x3) && (_0x4f74b8 += 0x1, Render[_0x5a4f67('0x24')](_0x260dc9[0x0] / 0x2, _0x260dc9[0x1] / 0x2 + (_0x6dd328 - _0x4f74b8) * 0xa + 0x14, 0x1, _0x5a4f67('0xf1'), [0x0, 0xff, 0xff, 0xff], indicatorFonts)), UI[_0x5a4f67('0x34')]([_0x5a4f67('0x77'), _0x5a4f67('0x78'), _0x5a4f67('0xab'), _0x5a4f67('0xac'), _0x5a4f67('0x7c'), _0x5a4f67('0x93')]) && getDropdownValue(UI[_0x5a4f67('0x34')]([_0x5a4f67('0x77'), _0x5a4f67('0x78'), _0x5a4f67('0x79'), _0x5a4f67('0x7a'), _0x5a4f67('0x79'), _0x5a4f67('0x91')]), 0x2) && (_0x4f74b8 += 0x1, Render[_0x5a4f67('0x24')](_0x260dc9[0x0] / 0x2, _0x260dc9[0x1] / 0x2 + (_0x6dd328 - _0x4f74b8) * 0xa + 0x14, 0x1, _0x5a4f67('0xf2'), [0x9b, 0xff, 0x9b, 0xff], indicatorFonts)), UI[_0x5a4f67('0x34')]([_0x5a4f67('0x77'), _0x5a4f67('0x78'), _0x5a4f67('0x7b'), _0x5a4f67('0x7a'), _0x5a4f67('0x7b'), _0x5a4f67('0x7c'), _0x5a4f67('0x87')]) && getDropdownValue(UI[_0x5a4f67('0x34')]([_0x5a4f67('0x77'), _0x5a4f67('0x78'), _0x5a4f67('0x79'), _0x5a4f67('0x7a'), _0x5a4f67('0x79'), _0x5a4f67('0x91')]), 0x4) && (_0x4f74b8 += 0x1, Render[_0x5a4f67('0x24')](_0x260dc9[0x0] / 0x2, _0x260dc9[0x1] / 0x2 + (_0x6dd328 - _0x4f74b8) * 0xa + 0x14, 0x1, _0x5a4f67('0xf3'), [0xff, 0x80, 0x0, 0xff], indicatorFonts));
}

function DrawDangerSigns() {
    var _0x583c5f = var_0x5baa;
    if (!UI[_0x583c5f('0x34')]([_0x583c5f('0x77'), _0x583c5f('0x78'), _0x583c5f('0x79'), _0x583c5f('0x7a'), _0x583c5f('0x79'), _0x583c5f('0x8d')])) return;
    var _0x189f38 = Entity[_0x583c5f('0x4d')]();
    for (i = 0x0; i < _0x189f38[_0x583c5f('0xc6')]; i++) {
        if (!Entity[_0x583c5f('0x56')](_0x189f38[i])) continue;
        if (!Entity[_0x583c5f('0x57')](_0x189f38[i])) continue;
        if (Entity[_0x583c5f('0x58')](_0x189f38[i])) continue;
        var _0x7d4348 = Entity[_0x583c5f('0xf4')](_0x189f38[i]),
            _0x54041f = _0x7d4348[0x3] - _0x7d4348[0x1];
        _0x54041f /= 0x2, _0x54041f += _0x7d4348[0x1];
        if (IsHoldingGrenade(_0x189f38[i])) DrawDanger(_0x54041f, _0x7d4348[0x2] - 0x2d, [0xff, 0xff, 0x0, 0xff]);
        if (Entity[_0x583c5f('0x5b')](Entity[_0x583c5f('0x5c')](_0x189f38[i])) == _0x583c5f('0xf5')) DrawDanger(_0x54041f, _0x7d4348[0x2] - 0x2d, [0xff, 0x0, 0x0, 0xff]);
    }
}

function DrawIndicators() {
    var _0x3eec1d = var_0x5baa;
    if (!UI[_0x3eec1d('0x34')]([_0x3eec1d('0x77'), _0x3eec1d('0x78'), _0x3eec1d('0x79'), _0x3eec1d('0x7a'), _0x3eec1d('0x79'), _0x3eec1d('0x8b')])) return;
    var _0x24c95c = Global[_0x3eec1d('0x11')]();
    if (!UI[_0x3eec1d('0x34')]([_0x3eec1d('0x77'), _0x3eec1d('0x78'), _0x3eec1d('0x79'), _0x3eec1d('0x7a'), _0x3eec1d('0x79'), _0x3eec1d('0x96')])) return;
    var _0xffa0db = Entity[_0x3eec1d('0x4d')]();
    for (i = 0x0; i < _0xffa0db[_0x3eec1d('0xc6')]; i++) {
        if (!Entity[_0x3eec1d('0x56')](_0xffa0db[i])) continue;
        if (!Entity[_0x3eec1d('0x57')](_0xffa0db[i])) continue;
        if (Entity[_0x3eec1d('0x58')](_0xffa0db[i])) continue;
        var _0x3f6c17 = Entity[_0x3eec1d('0xf4')](_0xffa0db[i]),
            _0x146e09 = _0x3f6c17[0x3] - _0x3f6c17[0x1];
        _0x146e09 /= 0x2, _0x146e09 += _0x3f6c17[0x1];
        switch (info[_0xffa0db[i]]) {
            case _0x3eec1d('0xf6'):
                Render[_0x3eec1d('0x24')](_0x146e09, _0x3f6c17[0x2] - 0x19, 0x1, info[_0xffa0db[i]], [0xd7, 0xff, 0x96, 0xff], font);
                break;
            case _0x3eec1d('0xf7'):
                Render[_0x3eec1d('0x24')](_0x146e09, _0x3f6c17[0x2] - 0x19, 0x1, info[_0xffa0db[i]], [0xff, 0xff, 0xff, 0xff], font);
                break;
            case _0x3eec1d('0xf8'):
                Render[_0x3eec1d('0x24')](_0x146e09, _0x3f6c17[0x2] - 0x19, 0x1, info[_0xffa0db[i]], [0x0, 0xff, 0xff, 0xff], font);
                break;
            case _0x3eec1d('0xf9'):
                Render[_0x3eec1d('0x24')](_0x146e09, _0x3f6c17[0x2] - 0x19, 0x1, info[_0xffa0db[i]], [0xc7, 0x91, 0x12, 0xff], font);
                break;
            case _0x3eec1d('0xfa'):
                Render[_0x3eec1d('0x24')](_0x146e09, _0x3f6c17[0x2] - 0x19, 0x1, info[_0xffa0db[i]], [0x3f, 0x85, 0xfc, 0xff], font);
                break;
            case _0x3eec1d('0xfb'):
                Render[_0x3eec1d('0x24')](_0x146e09, _0x3f6c17[0x2] - 0x19, 0x1, info[_0xffa0db[i]], [0x3f, 0x85, 0xfc, 0xff], font);
                break;
            case 'X2':
                Render[_0x3eec1d('0x24')](_0x146e09, _0x3f6c17[0x2] - 0x19, 0x1, info[_0xffa0db[i]], [0x0, 0x80, 0xf0, 0xff], font);
                break;
            case _0x3eec1d('0xdd'):
                Render[_0x3eec1d('0x24')](_0x146e09, _0x3f6c17[0x2] - 0x19, 0x1, info[_0xffa0db[i]], [0xff, 0x7d, 0xff, 0xff], font);
                break;
            case _0x3eec1d('0xfc'):
                Render[_0x3eec1d('0x24')](_0x146e09, _0x3f6c17[0x2] - 0x19, 0x1, info[_0xffa0db[i]], [0x9b, 0xff, 0xfc, 0xff], font);
                break;
            case _0x3eec1d('0xfd'):
                Render[_0x3eec1d('0x24')](_0x146e09, _0x3f6c17[0x2] - 0x19, 0x1, info[_0xffa0db[i]], [0xff, 0xff, 0x96, 0xff], font);
                break;
            case _0x3eec1d('0xfe'):
                Render[_0x3eec1d('0x24')](_0x146e09, _0x3f6c17[0x2] - 0x19, 0x1, info[_0xffa0db[i]], [0xff, 0x7d, 0xff, 0xff], font);
                break;
        }
        if (UI[_0x3eec1d('0x34')]([_0x3eec1d('0x77'), _0x3eec1d('0x78'), _0x3eec1d('0x79'), _0x3eec1d('0x7a'), _0x3eec1d('0x79'), _0x3eec1d('0x8c')]) && safeTargets[_0xffa0db[i]]) Render[_0x3eec1d('0x24')](_0x146e09, _0x3f6c17[0x2] - 0x23, 0x1, _0x3eec1d('0xf1'), [0xde, 0xab, 0xff, 0xff], font);
    }
}

function GetHitboxName(_0x5f32d8) {
    var _0x14c397 = var_0x5baa,
        _0x151711 = '';
    switch (_0x5f32d8) {
        case 0x0:
            _0x151711 = _0x14c397('0xff');
            break;
        case 0x1:
            _0x151711 = _0x14c397('0x100');
            break;
        case 0x2:
            _0x151711 = _0x14c397('0x101');
            break;
        case 0x3:
            _0x151711 = _0x14c397('0x102');
            break;
        case 0x4:
            _0x151711 = _0x14c397('0x103');
            break;
        case 0x5:
            _0x151711 = _0x14c397('0x104');
            break;
        case 0x6:
            _0x151711 = _0x14c397('0x105');
            break;
        case 0x7:
            _0x151711 = _0x14c397('0x106');
            break;
        case 0x8:
            _0x151711 = _0x14c397('0x107');
            break;
        case 0x9:
            _0x151711 = _0x14c397('0x108');
            break;
        case 0xa:
            _0x151711 = _0x14c397('0x109');
            break;
        case 0xb:
            _0x151711 = _0x14c397('0x10a');
            break;
        case 0xc:
            _0x151711 = _0x14c397('0x10b');
            break;
        case 0xd:
            _0x151711 = _0x14c397('0x10c');
            break;
        case 0xe:
            _0x151711 = _0x14c397('0x10d');
            break;
        case 0xf:
            _0x151711 = _0x14c397('0x10e');
            break;
        case 0x10:
            _0x151711 = _0x14c397('0x10f');
            break;
        case 0x11:
            _0x151711 = _0x14c397('0x110');
            break;
        case 0x12:
            _0x151711 = _0x14c397('0x111');
            break;
        default:
            _0x151711 = _0x14c397('0x112');
    }
    return _0x151711;
}

function RagebotLogs() {
    var _0x40fd32 = var_0x5baa;
    if (!UI[_0x40fd32('0x34')]([_0x40fd32('0x77'), _0x40fd32('0x78'), _0x40fd32('0x79'), _0x40fd32('0x7a'), _0x40fd32('0x79'), _0x40fd32('0x84')])) return;
    target = Event[_0x40fd32('0x45')](_0x40fd32('0x113')), targetName = Entity[_0x40fd32('0x5b')](target), hitbox = Event[_0x40fd32('0x45')](_0x40fd32('0x114')), hitchance = Event[_0x40fd32('0x45')](_0x40fd32('0x115')), safepoint = Event[_0x40fd32('0x45')](_0x40fd32('0x116')), exploit = Event[_0x40fd32('0x45')](_0x40fd32('0x117')), log = _0x40fd32('0x118') + targetName + ' (' + target + ')' + _0x40fd32('0x119') + GetHitboxName(hitbox) + _0x40fd32('0x11a') + hitchance + _0x40fd32('0x11b') + safepoint + _0x40fd32('0x11c') + exploit + _0x40fd32('0x11d') + info[target], log += '\x0a', Cheat[_0x40fd32('0x2')]([0x0, 0xff, 0x0, 0xff], log);
}

function SafepointOnLimbs() {
    var _0x34c2d5 = var_0x5baa;
    if (!UI[_0x34c2d5('0x34')]([_0x34c2d5('0x77'), _0x34c2d5('0x78'), _0x34c2d5('0x79'), _0x34c2d5('0x7a'), _0x34c2d5('0x79'), _0x34c2d5('0x83')])) return;
    Ragebot[_0x34c2d5('0xd2')](0xc), Ragebot[_0x34c2d5('0xd2')](0xb), Ragebot[_0x34c2d5('0xd2')](0xa), Ragebot[_0x34c2d5('0xd2')](0x9);
}

function OverrideMinimumDamage() {
    var _0x50685f = var_0x5baa;
    if (!UI[_0x50685f('0x34')]([_0x50685f('0x77'), _0x50685f('0x78'), _0x50685f('0x7b'), _0x50685f('0x7a'), _0x50685f('0x7b'), _0x50685f('0x7c'), _0x50685f('0x87')])) return;
    var _0x54a4ef = Entity[_0x50685f('0x4d')]();
    value = UI[_0x50685f('0x34')]([_0x50685f('0x77'), _0x50685f('0x78'), _0x50685f('0x79'), _0x50685f('0x7a'), _0x50685f('0x79'), _0x50685f('0x89')]);
    for (i = 0x0; i < _0x54a4ef[_0x50685f('0xc6')]; i++) {
        Ragebot[_0x50685f('0xd3')](_0x54a4ef[i], value), info[_0x54a4ef[i]] = _0x50685f('0xfe');
    }
}

function ForceConditions() {
    var _0x477250 = var_0x5baa;
    AimForHeadIfShooting();
    if (!UI[_0x477250('0x34')]([_0x477250('0x77'), _0x477250('0x78'), _0x477250('0x79'), _0x477250('0x7a'), _0x477250('0x79'), _0x477250('0x96')])) return;
    if (UI[_0x477250('0x34')]([_0x477250('0x77'), _0x477250('0x78'), _0x477250('0x7b'), _0x477250('0x7a'), _0x477250('0x7b'), _0x477250('0x7c'), _0x477250('0x7f')])) return;
    if (UI[_0x477250('0x34')]([_0x477250('0x77'), _0x477250('0x78'), _0x477250('0x7b'), _0x477250('0x7a'), _0x477250('0x7b'), _0x477250('0x7c'), _0x477250('0x87')])) return;
    var _0x355ab6 = Entity[_0x477250('0x4d')](),
        _0x4e093d = UI[_0x477250('0x34')]([_0x477250('0x77'), _0x477250('0x78'), _0x477250('0x79'), _0x477250('0x7a'), _0x477250('0x79'), _0x477250('0x9d')]),
        _0x468f06 = UI[_0x477250('0x34')]([_0x477250('0x77'), _0x477250('0x78'), _0x477250('0x79'), _0x477250('0x7a'), _0x477250('0x79'), _0x477250('0x98')]),
        _0x9981a5 = UI[_0x477250('0x34')]([_0x477250('0x77'), _0x477250('0x78'), _0x477250('0x79'), _0x477250('0x7a'), _0x477250('0x79'), _0x477250('0x9e')]),
        _0x2b6b5c = UI[_0x477250('0x34')]([_0x477250('0x77'), _0x477250('0x78'), _0x477250('0x79'), _0x477250('0x7a'), _0x477250('0x79'), _0x477250('0xa4')]);
    for (i = 0x0; i < _0x355ab6[_0x477250('0xc6')]; i++) {
        if (!Entity[_0x477250('0x56')](_0x355ab6[i])) continue;
        if (!Entity[_0x477250('0x57')](_0x355ab6[i])) continue;
        if (Entity[_0x477250('0x58')](_0x355ab6[i])) continue;
        mode = '', info[_0x355ab6[i]] = _0x477250('0xf7'), safeTargets[_0x355ab6[i]] = ![];
        var _0x1fa678 = Ragebot[_0x477250('0xc8')](),
            _0x53f67e = ![];
        getDropdownValue(_0x2b6b5c, 0x0) && IsLethal(_0x355ab6[i]) && (safeTargets[_0x355ab6[i]] = !![], _0x53f67e = !![], Ragebot[_0x477250('0xcd')](_0x355ab6[i]));
        getDropdownValue(_0x2b6b5c, 0x1) && IsSlowWalking(_0x355ab6[i]) && (safeTargets[_0x355ab6[i]] = !![], Ragebot[_0x477250('0xcd')](_0x355ab6[i]));
        getDropdownValue(_0x2b6b5c, 0x3) && IsInAir(_0x355ab6[i]) && (safeTargets[_0x355ab6[i]] = !![], Ragebot[_0x477250('0xcd')](_0x355ab6[i]));
        getDropdownValue(_0x2b6b5c, 0x2) && IsStanding(_0x355ab6[i]) && !IsInAir(_0x355ab6[i]) && (safeTargets[_0x355ab6[i]] = !![], Ragebot[_0x477250('0xcd')](_0x355ab6[i]));
        getDropdownValue(_0x2b6b5c, 0x4) && IsCrouch(_0x355ab6[i]) && (safeTargets[_0x355ab6[i]] = !![], Ragebot[_0x477250('0xcd')](_0x355ab6[i]));
        if (AttemptTwoShotKill(_0x355ab6[i]) == !![] && UI[_0x477250('0x34')]([_0x477250('0x77'), _0x477250('0x78'), _0x477250('0x79'), _0x477250('0x7a'), _0x477250('0x79'), _0x477250('0x97')])) {
            info[_0x355ab6[i]] = 'X2';
            continue;
        }
        if (getDropdownValue(_0x9981a5, 0x0) && _0x53f67e) {
            if (_0x1fa678 == _0x355ab6[i]) ForceBaim(_0x355ab6[i]);
            info[_0x355ab6[i]] = _0x477250('0xfa');
            continue;
        }
        if (getDropdownValue(_0x468f06, 0x3) && firedThisTick[_0x355ab6[i]] == !![]) {
            ForceHead(_0x355ab6[i]), info[_0x355ab6[i]] = _0x477250('0xfd');
            continue;
        }
        if (getDropdownValue(_0x9981a5, 0x1) && IsSlowWalking(_0x355ab6[i])) {
            if (_0x1fa678 == _0x355ab6[i]) ForceBaim(_0x355ab6[i]);
            info[_0x355ab6[i]] = _0x477250('0xfb');
            continue;
        }
        if (getDropdownValue(_0x9981a5, 0x3) && IsInAir(_0x355ab6[i])) {
            if (_0x1fa678 == _0x355ab6[i]) ForceBaim(_0x355ab6[i]);
            info[_0x355ab6[i]] = _0x477250('0xf8');
            continue;
        }
        if (getDropdownValue(_0x9981a5, 0x2) && IsStanding(_0x355ab6[i]) && !IsInAir(_0x355ab6[i])) {
            if (_0x1fa678 == _0x355ab6[i]) ForceBaim(_0x355ab6[i]);
            info[_0x355ab6[i]] = _0x477250('0xfc');
            continue;
        }
        if (getDropdownValue(_0x9981a5, 0x4) && IsCrouch(_0x355ab6[i])) {
            if (_0x1fa678 == _0x355ab6[i]) ForceBaim(_0x355ab6[i]);
            info[_0x355ab6[i]] = _0x477250('0xf9');
            continue;
        }
        if (getDropdownValue(_0x468f06, 0x1) && IsInAir(_0x355ab6[i])) {
            ForceHead(_0x355ab6[i]), info[_0x355ab6[i]] = _0x477250('0xf8');
            continue;
        }
        if (getDropdownValue(_0x468f06, 0x0) && GetMaxDesync(_0x355ab6[i]) < _0x4e093d && !IsInAir(_0x355ab6[i])) {
            ForceHead(_0x355ab6[i]), info[_0x355ab6[i]] = _0x477250('0xf6');
            continue;
        }
        if (getDropdownValue(_0x468f06, 0x2) && IsCrouchTerrorist(_0x355ab6[i])) {
            ForceHead(_0x355ab6[i]), info[_0x355ab6[i]] = _0x477250('0xf9');
            continue;
        }
        DisableBaim();
    }
}

function Draw() {
    var _0x14b877 = var_0x5baa;
    font == null && (font = Render[_0x14b877('0x2e')](_0x14b877('0x11e'), 0xa, 0x2bc));
    indicatorFonts == null && (indicatorFonts = Render[_0x14b877('0x2e')](_0x14b877('0x11e'), 0x9, 0x2bc));
    if (UI[_0x14b877('0x44')]()) {
        if (getDropdownValue(UI[_0x14b877('0x34')]([_0x14b877('0x77'), _0x14b877('0x78'), _0x14b877('0x79'), _0x14b877('0x7a'), _0x14b877('0x79'), _0x14b877('0x98')]), 0x1)) UI[_0x14b877('0x35')]([_0x14b877('0x77'), _0x14b877('0x78'), _0x14b877('0x79'), _0x14b877('0x7a'), _0x14b877('0x79'), _0x14b877('0x9e')], setDropdownValue(UI[_0x14b877('0x34')]([_0x14b877('0x77'), _0x14b877('0x78'), _0x14b877('0x79'), _0x14b877('0x7a'), _0x14b877('0x79'), _0x14b877('0x9e')]), 0x3, ![]));
        if (getDropdownValue(UI[_0x14b877('0x34')]([_0x14b877('0x77'), _0x14b877('0x78'), _0x14b877('0x79'), _0x14b877('0x7a'), _0x14b877('0x79'), _0x14b877('0x98')]), 0x2)) UI[_0x14b877('0x35')]([_0x14b877('0x77'), _0x14b877('0x78'), _0x14b877('0x79'), _0x14b877('0x7a'), _0x14b877('0x79'), _0x14b877('0x9e')], setDropdownValue(UI[_0x14b877('0x34')]([_0x14b877('0x77'), _0x14b877('0x78'), _0x14b877('0x79'), _0x14b877('0x7a'), _0x14b877('0x79'), _0x14b877('0x9e')]), 0x4, ![]));
        UI[_0x14b877('0x3f')]([_0x14b877('0x77'), _0x14b877('0x78'), _0x14b877('0x79'), _0x14b877('0x7a'), _0x14b877('0x79'), _0x14b877('0x8f')], UI[_0x14b877('0x34')]([_0x14b877('0x77'), _0x14b877('0x78'), _0x14b877('0x79'), _0x14b877('0x7a'), _0x14b877('0x79'), _0x14b877('0x8a')])), UI[_0x14b877('0x3f')]([_0x14b877('0x77'), _0x14b877('0x78'), _0x14b877('0x79'), _0x14b877('0x7a'), _0x14b877('0x79'), _0x14b877('0x90')], UI[_0x14b877('0x34')]([_0x14b877('0x77'), _0x14b877('0x78'), _0x14b877('0x79'), _0x14b877('0x7a'), _0x14b877('0x79'), _0x14b877('0x8a')])), UI[_0x14b877('0x3f')]([_0x14b877('0x77'), _0x14b877('0x78'), _0x14b877('0x79'), _0x14b877('0x7a'), _0x14b877('0x79'), _0x14b877('0x98')], UI[_0x14b877('0x34')]([_0x14b877('0x77'), _0x14b877('0x78'), _0x14b877('0x79'), _0x14b877('0x7a'), _0x14b877('0x79'), _0x14b877('0x96')])), UI[_0x14b877('0x3f')]([_0x14b877('0x77'), _0x14b877('0x78'), _0x14b877('0x79'), _0x14b877('0x7a'), _0x14b877('0x79'), _0x14b877('0x9e')], UI[_0x14b877('0x34')]([_0x14b877('0x77'), _0x14b877('0x78'), _0x14b877('0x79'), _0x14b877('0x7a'), _0x14b877('0x79'), _0x14b877('0x96')])), UI[_0x14b877('0x3f')]([_0x14b877('0x77'), _0x14b877('0x78'), _0x14b877('0x79'), _0x14b877('0x7a'), _0x14b877('0x79'), _0x14b877('0xa4')], UI[_0x14b877('0x34')]([_0x14b877('0x77'), _0x14b877('0x78'), _0x14b877('0x79'), _0x14b877('0x7a'), _0x14b877('0x79'), _0x14b877('0x96')])), UI[_0x14b877('0x3f')]([_0x14b877('0x77'), _0x14b877('0x78'), _0x14b877('0x79'), _0x14b877('0x7a'), _0x14b877('0x79'), _0x14b877('0xa5')], UI[_0x14b877('0x34')]([_0x14b877('0x77'), _0x14b877('0x78'), _0x14b877('0x79'), _0x14b877('0x7a'), _0x14b877('0x79'), _0x14b877('0x96')])), UI[_0x14b877('0x3f')]([_0x14b877('0x77'), _0x14b877('0x78'), _0x14b877('0x79'), _0x14b877('0x7a'), _0x14b877('0x79'), _0x14b877('0x8e')], UI[_0x14b877('0x34')]([_0x14b877('0x77'), _0x14b877('0x78'), _0x14b877('0x79'), _0x14b877('0x7a'), _0x14b877('0x79'), _0x14b877('0x8a')])), delta = 0x0, getDropdownValue(UI[_0x14b877('0x34')]([_0x14b877('0x77'), _0x14b877('0x78'), _0x14b877('0x79'), _0x14b877('0x7a'), _0x14b877('0x79'), _0x14b877('0x98')]), 0x0) && UI[_0x14b877('0x34')]([_0x14b877('0x77'), _0x14b877('0x78'), _0x14b877('0x79'), _0x14b877('0x7a'), _0x14b877('0x79'), _0x14b877('0x96')]) && (delta = 0x1), UI[_0x14b877('0x3f')]([_0x14b877('0x77'), _0x14b877('0x78'), _0x14b877('0x79'), _0x14b877('0x7a'), _0x14b877('0x79'), _0x14b877('0x9d')], delta), UI[_0x14b877('0x3f')]([_0x14b877('0x77'), _0x14b877('0x78'), _0x14b877('0x79'), _0x14b877('0x7a'), _0x14b877('0x79'), _0x14b877('0x8b')], UI[_0x14b877('0x34')]([_0x14b877('0x77'), _0x14b877('0x78'), _0x14b877('0x79'), _0x14b877('0x7a'), _0x14b877('0x79'), _0x14b877('0x8a')])), UI[_0x14b877('0x3f')]([_0x14b877('0x77'), _0x14b877('0x78'), _0x14b877('0x79'), _0x14b877('0x7a'), _0x14b877('0x79'), _0x14b877('0x8c')], UI[_0x14b877('0x34')]([_0x14b877('0x77'), _0x14b877('0x78'), _0x14b877('0x79'), _0x14b877('0x7a'), _0x14b877('0x79'), _0x14b877('0x8a')])), UI[_0x14b877('0x3f')]([_0x14b877('0x77'), _0x14b877('0x78'), _0x14b877('0x79'), _0x14b877('0x7a'), _0x14b877('0x79'), _0x14b877('0x8d')], UI[_0x14b877('0x34')]([_0x14b877('0x77'), _0x14b877('0x78'), _0x14b877('0x79'), _0x14b877('0x7a'), _0x14b877('0x79'), _0x14b877('0x8a')])), UI[_0x14b877('0x3f')]([_0x14b877('0x77'), _0x14b877('0x78'), _0x14b877('0x79'), _0x14b877('0x7a'), _0x14b877('0x79'), _0x14b877('0x91')], UI[_0x14b877('0x34')]([_0x14b877('0x77'), _0x14b877('0x78'), _0x14b877('0x79'), _0x14b877('0x7a'), _0x14b877('0x79'), _0x14b877('0x8a')])), UI[_0x14b877('0x3f')]([_0x14b877('0x77'), _0x14b877('0x78'), _0x14b877('0x79'), _0x14b877('0x7a'), _0x14b877('0x79'), _0x14b877('0x97')], UI[_0x14b877('0x34')]([_0x14b877('0x77'), _0x14b877('0x78'), _0x14b877('0x79'), _0x14b877('0x7a'), _0x14b877('0x79'), _0x14b877('0x96')])), UI[_0x14b877('0x3f')]([_0x14b877('0x77'), _0x14b877('0x78'), _0x14b877('0x79'), _0x14b877('0x7a'), _0x14b877('0x79'), _0x14b877('0xa7')], UI[_0x14b877('0x34')]([_0x14b877('0x77'), _0x14b877('0x78'), _0x14b877('0x79'), _0x14b877('0x7a'), _0x14b877('0x79'), _0x14b877('0xa6')])), UI[_0x14b877('0x3f')]([_0x14b877('0x77'), _0x14b877('0x78'), _0x14b877('0x79'), _0x14b877('0x7a'), _0x14b877('0x79'), _0x14b877('0xa9')], UI[_0x14b877('0x34')]([_0x14b877('0x77'), _0x14b877('0x78'), _0x14b877('0x79'), _0x14b877('0x7a'), _0x14b877('0x79'), _0x14b877('0xa8')]));
    }
    AimForHeadIfShooting();
    if (!UI[_0x14b877('0x34')]([_0x14b877('0x77'), _0x14b877('0x78'), _0x14b877('0x79'), _0x14b877('0x7a'), _0x14b877('0x79'), _0x14b877('0x79')])) return;
    if (!Entity[_0x14b877('0x56')](Entity[_0x14b877('0x4f')]())) return;
    if (!Entity[_0x14b877('0x57')](Entity[_0x14b877('0x4f')]())) return;
    DrawIndicators(), DrawToggles(), DrawDynamicDamage(), DrawDangerSigns();
}

function CreateMove() {
    var _0x122730 = var_0x5baa;
    if (!UI[_0x122730('0x34')]([_0x122730('0x77'), _0x122730('0x78'), _0x122730('0x79'), _0x122730('0x7a'), _0x122730('0x79'), _0x122730('0x79')])) return;
    if (!Entity[_0x122730('0x56')](Entity[_0x122730('0x4f')]())) return;
    if (!Entity[_0x122730('0x57')](Entity[_0x122730('0x4f')]())) return;
    AimForHeadIfShooting(), ForceConditions(), SetHitchanceInAir(), ReversedFreestanding(), SafepointOnLimbs(), WaitForOnShot(), OverrideMinimumDamage(), DodgeBruteforce(), NoScopeHitchance(), DesyncOnUse(), InstantRecharge();
}

function FrameNetUpdateStart() {
    var _0xcaf8ee = var_0x5baa;
    UI[_0xcaf8ee('0x34')]([_0xcaf8ee('0x77'), _0xcaf8ee('0x78'), _0xcaf8ee('0x79'), _0xcaf8ee('0x7a'), _0xcaf8ee('0x79'), _0xcaf8ee('0x85')]) && (Exploit[_0xcaf8ee('0x11f')](0x0), Exploit[_0xcaf8ee('0x120')](0xe), shouldDisable = !![]), !UI[_0xcaf8ee('0x34')]([_0xcaf8ee('0x77'), _0xcaf8ee('0x78'), _0xcaf8ee('0x79'), _0xcaf8ee('0x7a'), _0xcaf8ee('0x79'), _0xcaf8ee('0x85')]) && shouldDisable == !![] && (Exploit[_0xcaf8ee('0x11f')](0x1), Exploit[_0xcaf8ee('0x120')](0xc), shouldDisable = ![]);
}
var rechargeTime = 0x0,
    updateTime = !![];

function InstantRecharge() {
    var _0x4a8946 = var_0x5baa;
    if (UI[_0x4a8946('0x34')]([_0x4a8946('0x77'), _0x4a8946('0x78'), _0x4a8946('0x79'), _0x4a8946('0x7a'), _0x4a8946('0x79'), _0x4a8946('0x85')])) {
        Exploit[_0x4a8946('0x70')]();
        if (Exploit[_0x4a8946('0x6e')]() == 0x1) updateTime = !![];
        Exploit[_0x4a8946('0x6e')]() <= 0.3 && (updateTime && (rechargeTime = Globals[_0x4a8946('0x9')](), updateTime = ![]), Globals[_0x4a8946('0x9')]() - rechargeTime > 0.6 && updateTime == ![] && (Exploit[_0x4a8946('0x6f')](), rechargeTime = Globals[_0x4a8946('0x9')]()));
    } else Exploit[_0x4a8946('0x71')]();
}

function ClearData() {
    firedThisTick = [], storedShotTime = [], info = [];
}

function Main() {
    var _0x2cd9f7 = var_0x5baa;
    for (i = 0x0; i < 0x40; i++) {
        info[i] = '', safeTargets[i] = ![];
    }
    Cheat[_0x2cd9f7('0x3')](_0x2cd9f7('0x1c'), _0x2cd9f7('0x1c')), Cheat[_0x2cd9f7('0x3')](_0x2cd9f7('0x1a'), _0x2cd9f7('0x1a')), Cheat[_0x2cd9f7('0x3')](_0x2cd9f7('0x121'), _0x2cd9f7('0x122')), Cheat[_0x2cd9f7('0x3')](_0x2cd9f7('0x123'), _0x2cd9f7('0x124')), Cheat[_0x2cd9f7('0x3')](_0x2cd9f7('0x125'), _0x2cd9f7('0x126'));
}
Main();
Render.AddFont = function(name, size, _) {
  if (name.indexOf('.ttf') === -1) name = name + '.ttf';

  return Render.GetFont(name, size, true);
}