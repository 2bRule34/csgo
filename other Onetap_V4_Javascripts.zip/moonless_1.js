UI.AddSubTab( ["Misc.", "SUBTAB_MGR"], "clantags");
UI.AddDropdown( ["Misc.", "clantags", "SHEET_MGR", "clantags"], "clantags",["Blank","FlowerPower"],1);

var lasttime = 0;
function onRender( )
{
    if (!World.GetServerString()) return;
    var tag = UI.GetValue( ["Misc.","clantags","clantags", "clantags"] );
    var speed = 2
    var time = parseInt((Globals.Curtime() * speed))
    if (time != lasttime)
    {
        if(tag == 0) { Local.SetClanTag(""); }
        if(tag == 1)
            {
            switch((time) % 22)
            {
            case 0:{ Local.SetClanTag("|\/| "); break; }
            case 1:{ Local.SetClanTag("M0 "); break; }
            case 2:{ Local.SetClanTag("Mo0 "); break; }
            case 3:{ Local.SetClanTag("Moo|\| "); break; }
            case 4:{ Local.SetClanTag("Moon "); break; }
            case 5:{ Local.SetClanTag("Moon|_ "); break; }
            case 6:{ Local.SetClanTag("MoonL "); break; }
            case 7:{ Local.SetClanTag("MoonL3 "); break; }
            case 8:{ Local.SetClanTag("MoonLe$ "); break; }
            case 9:{ Local.SetClanTag("MoonLes$ "); break; }
            case 10:{ Local.SetClanTag("MoonLess"); break; }
            case 11:{ Local.SetClanTag("Moo|\||_ess"); break; }
            case 12:{ Local.SetClanTag("Moo..ess"); break; }
            case 13:{ Local.SetClanTag("Mo0..3ss"); break; }
            case 14:{ Local.SetClanTag("Mo....ss"); break; }
            case 15:{ Local.SetClanTag("M0....$s"); break; }
            case 16:{ Local.SetClanTag("M......s"); break; }
            case 17:{ Local.SetClanTag("|\/|...$"); break; }
            case 18:{ Local.SetClanTag("........"); break; }
            case 19:{ Local.SetClanTag("........"); break; }
            case 20:{ Local.SetClanTag("........"); break; }

            }
        }


    }
    lasttime = time;
}
Cheat.RegisterCallback("FrameStageNotify", "onRender");