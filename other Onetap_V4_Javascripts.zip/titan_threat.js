UI.AddSubTab(["Config", "SUBTAB_MGR"], "TITAN");
const path = [ "Config", "TITAN", "TITAN" ];
const path_hk = [ "Config", "Scripts", "Keys", "JS Keybinds" ];
const aa = UI.AddCheckbox(path, "Override anti-aim");
const doubletap_adjustments = UI.AddMultiDropdown(path, "AA Mode", [ "Safe", "Adaptive" ], 1)
const lowdeltaslowwalk = UI.AddCheckbox(path, "Anti-Bruteforce");
const legmovement = UI.AddCheckbox(path, "Leg movement");
const lowdeltaslowwalk = UI.AddCheckbox(path, "Improved Freestanding");
const lowdeltaslowwalk = UI.AddCheckbox(path, "Titan Walk");
const lowdeltaslowwalk = UI.AddCheckbox(path, "Low delta on Slowawalk");
const doubletap_adjustments = UI.AddMultiDropdown(path, "Doubletap adjustments", [ "Faster firing", "Faster recharge" ], 0);
const lowdeltaslowwalk = UI.AddCheckbox(path, "Better DT Accuracy");
const lowdeltaslowwalk = UI.AddCheckbox(path, "Refine Shot");
const lowdeltaslowwalk = UI.AddCheckbox(path, "HP/2 on DT");
const lowdeltaslowwalk = UI.AddCheckbox(path, "Force BAIM if Lethal");
const safepoint = UI.AddMultiDropdown(path, "Safepoint Adjustments", [ "Head", "Body", "Legs", "Arms", "Feet" ], 0);
const arrow_accent = UI.AddColorPicker(path, "Anti-aim arrow accent");
const antiaim_accent = UI.AddColorPicker(path, "Anti-aim name accent");
const left_hk = UI.AddHotkey(path_hk, "Left override", "Left");
const right_hk = UI.AddHotkey(path_hk, "Right override", "Right");
var username = Cheat.GetUsername()

var original_aa = true
var input = {state: 0, left: false, right: false};


function fixUIBehaviour() {
    for(var i in UI) {
        if(!~i.indexOf("Add"))
            continue;

        (function(cur) {
            UI[i] = function() {
                cur.apply(this, Array.prototype.slice.call(arguments));
                return arguments[0].concat(arguments[1]);
            }
        }(UI[i]));
    }
}

fixUIBehaviour();

Render.ShadowString = function(x, y, a, s, c, f) {
    Render.String(x, y + 1, a, s, [10, 10, 10, Math.min(c[3], 200)], f);
    Render.String(x, y, a, s, c, f);
} 

function updateManual() {
    const left = UI.GetValue(left_hk), right = UI.GetValue(right_hk);

    if (input.left === left &&
        input.right === right)
        return;

    input.left = left;
    input.right = right;

    if ((input.left && input.state == 1) || (input.right && input.state == 2)) {
        input.state = 0;

        UI.SetValue([ "Rage", "Anti Aim", "Directions", "Yaw offset" ], 0);
        return;
    }

    if (input.left && input.state != 1) {
        input.state = 1;

        UI.SetValue([ "Rage", "Anti Aim", "Directions", "Yaw offset" ], -90);
    }

    if (input.right && input.state != 2) {
        input.state = 2;

        UI.SetValue([ "Rage", "Anti Aim", "Directions", "Yaw offset" ], 90);
    }
}

function updateAntiAim() {
    if (!UI.GetValue(aa)) {
        AntiAim.SetOverride(0);
        return;
    }

    const flip = Globals.Tickcount() % 4 >= 2 ? 38 : -38;

    AntiAim.SetOverride(1);
    AntiAim.SetRealOffset(flip);
    AntiAim.SetFakeOffset(0);
    AntiAim.SetLBYOffset(-flip);
}

var disabled = false;

function canShift(ticks) {
    const me = Entity.GetLocalPlayer();
	const weapon = Entity.GetWeapon(me);

	if (!Entity.IsValid(weapon))
		return false;

	const tickbase = Entity.GetProp(me, "CCSPlayer", "m_nTickBase");
	const now = (tickbase - ticks) * Globals.TickInterval();

	return now >= Entity.GetProp(weapon, "CBaseCombatWeapon", "m_flNextPrimaryAttack");
}

function adjustDoubletap() {
    const value = UI.GetValue(doubletap_adjustments);

    if (UI.GetValue(["Rage", "Anti Aim", "General", "Key assignment", "Fake duck"]) || (UI.GetValue(["Rage", "Exploits", "General", "Hide shots"]) && UI.GetValue(["Rage", "Exploits", "Keys", "Key assignment", "Hide shots"]))) {
        Exploit.OverrideMaxProcessTicks(16);
        Exploit.EnableRecharge();
        return;
    }

    const ticks = value & (1 << 0) ? 15 : 14;

    Exploit.OverrideMaxProcessTicks(17);
    Exploit.OverrideShift(ticks);
    Exploit.OverrideTolerance(0);

    if (value & (1 << 1)) {
        if (!disabled) {
            disabled = true;

            Exploit.DisableRecharge();
        }

        if (canShift(ticks) && Exploit.GetCharge() < 1) {
            Exploit.Recharge();
        }
    } else {
        if (disabled) {
            disabled = false;

            Exploit.EnableRecharge();
        }
    }
}

function renderIndicators() {
    const arrow_font = Render.AddFont("tahomabd.ttf", 14, 0);
    const text_font = Render.AddFont("tahomabd.ttf", 10, 0);

    const arrow_color = UI.GetColor(arrow_accent);
    const text_color = UI.GetColor(antiaim_accent);

    const x = Render.GetScreenSize()[0] / 2, y = Render.GetScreenSize()[1] / 2;

    const charge = Exploit.GetCharge();

    Render.ShadowString(x - 35, y - 10, 1, "<", input.state === 1 ? arrow_color : [235, 235, 235, 255], arrow_font);
    Render.ShadowString(x + 35, y - 10, 1, ">", input.state === 2 ? arrow_color : [235, 235, 235, 255], arrow_font);

    Render.ShadowString(x, y + 25, 0, "TITAN YAW", text_color, text_font);
    Render.ShadowString(x, y + 35, 0, "DANGEROUS", [209, 139, 230, 255], text_font);
    Render.ShadowString(x, y + 45, 0, "DT", [235 - 235 * charge, 235 * charge, 55, 255], text_font);
}


UI.AddHotkey(["Rage", "Anti Aim", "General", "Key assignment"], "{ TITAN } Legit AA on Key", "{ titan } Legit AA on Key");

function legit_aa()
{
    if (UI.GetValue(["Rage", "Anti Aim", "General", "Key assignment", "{ TITAN } Legit AA on Key"]) == true)
    {
        if (original_aa)
        {
            restrictions_cache = UI.GetValue(["Config", "Cheat", "General", "Restrictions"]);
            yaw_offset_cache = UI.GetValue(["Rage", "Anti Aim", "Directions", "Yaw offset"]);
            jitter_offset_cache = UI.GetValue(["Rage", "Anti Aim", "Directions", "Jitter offset"]);
            pitch_cache = UI.GetValue(["Rage", "Anti Aim", "General", "Pitch mode"]);
            original_aa = false;
        }
        UI.SetValue(["Config", "Cheat", "General", "Restrictions"], 0);
        UI.SetValue(["Rage", "Anti Aim", "Directions", "Yaw offset"], 180);
        UI.SetValue(["Rage", "Anti Aim", "Directions", "Jitter offset"], 0);
        UI.SetValue(["Rage", "Anti Aim", "General", "Pitch mode"], 0);
    }
    else
    {
        if (!original_aa)
        {
            UI.SetValue(["Config", "Cheat", "General", "Restrictions"], restrictions_cache);
            UI.SetValue(["Rage", "Anti Aim", "Directions", "Yaw offset"], yaw_offset_cache);
            UI.SetValue(["Rage", "Anti Aim", "Directions", "Jitter offset"], jitter_offset_cache);
            UI.SetValue(["Rage", "Anti Aim", "General", "Pitch mode"], pitch_cache);
            original_aa = true;
        }
    }
}

function legbreaker() {
    if(UI.GetValue(["TITAN", "TITAN", "Leg movement"])==1) {
        trufalse = 10 * Math.abs(Math.sin(64 * Globals.Realtime())), trufalse > 5 && UI.SetValue(["Misc.", "Movement", "Leg movement"], 0), trufalse < 5 && UI.SetValue(["Misc.", "Movement", "Leg movement"], 1)
    }
}

function onCreateMove() {
    updateManual();
    updateAntiAim();
    legit_aa();
    legbreaker();
    adjustDoubletap();
}

function onDraw() {
    const me = Entity.GetLocalPlayer();

    if (!Entity.IsValid(me) || !Entity.IsAlive(me))
        return;
        
    renderIndicators();
}

function includes(arr,obj) {
    return (arr.indexOf(obj) != -1)
}



Cheat.RegisterCallback("CreateMove", "onCreateMove")
Cheat.RegisterCallback("Draw", "onDraw")