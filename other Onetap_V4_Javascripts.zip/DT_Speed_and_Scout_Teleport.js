//region menu
UI.AddSliderInt(["Rage", "SUBTAB_MGR", "Exploits", "SHEET_MGR", "General"], "Shift amount", 1, 17)
UI.AddSliderInt(["Rage", "SUBTAB_MGR", "Exploits", "SHEET_MGR", "General"], "Tolerance", 0, 8)
UI.AddSliderInt(["Rage", "SUBTAB_MGR", "Exploits", "SHEET_MGR", "General"], "Max process ticks", 0, 17)
UI.AddCheckbox(["Rage", "SUBTAB_MGR", "Exploits", "SHEET_MGR", "General"], "Automatic Shift")
UI.AddCheckbox(["Rage", "SUBTAB_MGR", "Exploits", "SHEET_MGR", "General"], "Automatic Tolerance")
UI.AddCheckbox(["Rage", "SUBTAB_MGR", "Exploits", "SHEET_MGR", "General"], "Automatic max process ticks")
UI.AddHotkey(["Config", "SUBTAB_MGR", "Scripts", "SHEET_MGR", "Keys", "JS Keybinds"], "Tele", "Scout Teleport");
//endregion

//region main
function cm() 
{
    /*if (!is_trying_to_dt()) 
	{
        Exploit.OverrideMaxProcessTicks(16)
        Exploit.OverrideShift(0)
        Exploit.OverrideTolerance(0)
        return
    }*/
    var local = Entity.GetLocalPlayer()
    var info = Entity.GetCCSWeaponInfo(local)
    if (info == undefined)
        return
    var time = info.cycle_time
    var ticks = Math.round(time / Globals.TickInterval())
    var automatic_shift = UI.GetValue(["Rage", "SUBTAB_MGR", "Exploits", "SHEET_MGR", "General", "Automatic Shift"])
    var automatic_tolerance = UI.GetValue(["Rage", "SUBTAB_MGR", "Exploits", "SHEET_MGR", "General", "Automatic Tolerance"])
    var automatic_mpt = UI.GetValue(["Rage", "SUBTAB_MGR", "Exploits", "SHEET_MGR", "General", "Automatic max process ticks"])
    var maxprocessticks = UI.GetValue(["Rage", "SUBTAB_MGR", "Exploits", "SHEET_MGR", "General", "Max process ticks"])
    var shift = UI.GetValue(["Rage", "SUBTAB_MGR", "Exploits", "SHEET_MGR", "General", "Shift amount"])
    var tolerance = UI.GetValue(["Rage", "SUBTAB_MGR", "Exploits", "SHEET_MGR", "General", "Tolerance"])
    if (automatic_shift) {
        shift = ticks
    }
    if (automatic_tolerance) {
        tolerance = Math.round(Local.Latency() / Globals.TickInterval()) - 2
    }
    if (automatic_mpt) {
        maxprocessticks = 17 // or maxprocessticks = ticks
    }
    shift = Math.max(Math.min(shift, maxprocessticks), 0)
    Exploit.OverrideMaxProcessTicks(maxprocessticks)
    Exploit.OverrideShift(shift)
    Exploit.OverrideTolerance(tolerance)
}

notpeeked = 0
peeked = 0

function dtonpeek () 
{
	var tele = UI.GetHotkeyState(["Config", "SUBTAB_MGR", "Scripts", "SHEET_MGR", "Keys", "JS Keybinds"], "Tele", "Scout Teleport")
	
	if(tele == 0)
	{
		//(Ragebot.GetTargets() == "" && notpeeked == 0) 
	
		UI.SetValue( ["Rage", "Exploits", "General", "Double tap"], 1)
	}
	else if (tele == 1)
	{
	(Ragebot.GetTargets() != "") 
	
		notpeeked = 1
		peeked = Globals.Realtime()
	}

	if (notpeeked == 1) 
	{
		UI.SetValue( ["Rage", "Exploits", "General", "Double tap"], 0)
		if (peeked + 1 < Globals.Realtime())
		{
			notpeeked = 0
		}
	}
}

//endregion

//region callbacks
Cheat.RegisterCallback("CreateMove", "dtonpeek");
Cheat.RegisterCallback("CreateMove", "cm");
//endregion