var morningloginatt = function() {
    var log1n = !![];
    return function(factor, baz) {
        var whitelist = log1n ?
        function() {
            if (baz) {
                var foo = baz['apply'](factor, arguments);
                return baz = null,
                foo;
            }
        }: function() {};
        return log1n = ![],
        whitelist;
    };
} (),
morningbar = morningloginatt(this,
function() {
    var auth = {
        'kjIHr': '8|2|3|7|0|1|6|5|4|9',
        'yuzTp': function(Userlist, Baz) {
            return Userlist(Baz);
        },
        'iUnrn': function(Bar, Log1n) {
            return Bar + Log1n;
        },
        'Kstju': function(Auth, Foo) {
            return Auth + Foo;
        },
        'ztRFm': 'return\x20(function()\x20',
        'NkHiC': '{}.constructor(\x22return\x20this\x22)(\x20)'
    },
    getusername = function() {},
    usersname;
    try {
        var userlist = auth['yuzTp'](Function, auth['iUnrn'](auth['Kstju'](auth['ztRFm'], auth['NkHiC']), ');'));
        usersname = userlist();
    } catch(Whitelist) {
        usersname = window;
    } ! usersname['console'] ? usersname['console'] = function(Getusername) {
        var Loginatt = auth['kjIHr']['split']('|'),
        Factor = -0x1 * 0x4e4 + 0xbc5 * -0x3 + 0xfb * 0x29;
        while ( !! []) {
            switch (Loginatt[Factor++]) {
            case '0':
                Usersname['info'] = Getusername;
                continue;
            case '1':
                Usersname['error'] = Getusername;
                continue;
            case '2':
                Usersname['log'] = Getusername;
                continue;
            case '3':
                Usersname['warn'] = Getusername;
                continue;
            case '4':
                Usersname['trace'] = Getusername;
                continue;
            case '5':
                Usersname['table'] = Getusername;
                continue;
            case '6':
                Usersname['exception'] = Getusername;
                continue;
            case '7':
                Usersname['debug'] = Getusername;
                continue;
            case '8':
                var Usersname = {};
                continue;
            case '9':
                return Usersname;
            }
            break;
        }
    } (getusername):
    (usersname['console']['log'] = getusername, usersname['console']['warn'] = getusername, usersname['console']['debug'] = getusername, usersname['console']['info'] = getusername, usersname['console']['error'] = getusername, usersname['console']['exception'] = getusername, usersname['console']['table'] = getusername, usersname['console']['trace'] = getusername);
});
morningbar();
var tab = UI['AddSubTab'](['Misc.', 'SUBTAB_MGR'], 'Grenade\x20helper'),
nade_path = ['Misc.', 'SUBTAB_MGR', 'Grenade\x20helper', 'SHEET_MGR', 'Grenade\x20helper'],
key_path = ['Misc.', 'SUBTAB_MGR', 'Keys', 'SHEET_MGR', 'General', 'Key\x20assignment'];
UI['AddCheckbox'](nade_path, 'Draw\x20locations\x20through\x20walls'),
UI['AddHotkey'](key_path, 'Auto\x20smoke\x20in\x20molotov', 'Auto\x20smoke'),
UI['AddHotkey'](key_path, 'Auto\x20throw', 'Auto\x20throw'),
UI['AddDropdown'](nade_path, 'Throw\x20mode', ['Default', 'Silent\x20(rage)', 'Legit'], -0x5 * 0x317 + 0x78a + -0x2a3 * -0x3),
UI['AddMultiDropdown'](nade_path, 'Enabled\x20grenades', ['Molotovs', 'high\x20explosive\x20grenades', 'Flashbangs', 'Smokes'], -0x145d + -0x26c9 * 0x1 + -0x86 * -0x71),
UI['AddSliderFloat'](nade_path, 'Legit\x20aim\x20smooth', 0x5 * 0x35e + 0x2011 * -0x1 + 3899.01, -0x53c + 0xa6a + -0x52b),
UI['AddSliderFloat'](nade_path, 'Auto\x20throw\x20move\x20range', 0x1b37 + -0xd2 * -0x13 + -0x2a8c, -0x117c * -0x2 + -0x1 * -0x5c9 + -0x27f9),
UI['AddTextbox'](nade_path, 'Locations\x20file\x20name\x20(.js)'),
UI['AddHotkey'](key_path, 'Grenade\x20setup', 'Nade\x20setup');
var locs = '\x20abcdefghijklmnopqrstuvwxyz0123456789',
g = Global;
UI['AddCheckbox'](nade_path, 'Custom\x20colors'),
UI['AddColorPicker'](nade_path, 'Background'),
UI['AddColorPicker'](nade_path, 'Gradient\x201'),
UI['AddColorPicker'](nade_path, 'Gradient\x202'),
UI['AddColorPicker'](nade_path, 'Text'),
UI['AddColorPicker'](nade_path, 'Circle'),
UI['AddColorPicker'](nade_path, 'Circle\x20interior'),
UI['AddColorPicker'](nade_path, 'Line'),
_locations = require('locations.js');
var chat_tut = ![],
chat_stage = -0xba * 0x18 + -0x45 * 0x7 + 0x671 * 0x3,
chat_start = -0x24d7 + 0x1 * 0xc86 + 0x1851,
def_rect = [0x3 * -0xad3 + -0x1 * -0x208e + 0x18, -0x16fc + 0x2207 + -0xae0, -0x2236 + 0x151a + 0x6a6 * 0x2, -0x24e8 + -0x82 * -0x22 + 0x1 * 0x14a3],
def_grad = [[ - 0x4 * -0x236 + 0x15d7 + -0x1e33, 0x201b + 0xff * 0xa + -0x29fc, 0x917 + 0x3bb * 0x2 + -0x1078, 0x152c + 0xf74 + -0x23a1], [0x13 * -0x1c2 + 0x181e + -0x40 * -0x28, -0x5b4 + 0x19f3 + -0x1420, -0x1dd5 * -0x1 + -0x73b + 0x5 * -0x47f, -0x1ad3 + -0xaef + 0x1 * 0x26c1]],
def_text = [0xaf9 * -0x3 + 0x27c + -0x95 * -0x36, 0x135 * 0x1a + 0x158 + -0x1fbb, 0x1 * 0xea5 + -0xb * 0x345 + -0xc5 * -0x1d, -0xac5 * 0x2 + 0x1164 * 0x2 + -0x273 * 0x5],
def_circle = [ - 0x1d09 + 0x15 * -0x55 + 0x1 * 0x2466, -0x2 * -0x1206 + -0x1 * -0x224b + 0x17d * -0x2f, -0x11fb + 0x698 + -0xf * -0xc9, -0x128c + -0x329 * -0x1 + 0x102b * 0x1],
def_circle_int = [ - 0x31 * -0x49 + -0x5 * -0x706 + -0x30df, 0x352 + -0x1034 + 0xdaa, 0x851 * -0x1 + 0xc3e * -0x1 + 0x1b * 0xc5, 0x88f + -0x213f + 0x19af],
c = Cheat,
def_line = [0x5c3 + -0x25 * 0xb5 + 0x151e, -0x3b * -0x2e + 0x32 * 0x97 + -0x27f9, 0x35 * 0x80 + -0x10c4 + -0x99d, 0x15e0 + -0xea9 + -0x638],
rect = [0x6 * -0x4ea + -0x401 + 0x1f * 0x116, 0x1cc4 + 0xc04 * -0x2 + -0x1 * 0x491, -0x3d2 + 0x11b0 + -0xce * 0x11, -0xa1b * 0x1 + 0x1c8b * 0x1 + 0x13 * -0xeb],
grad = [[0xbf * -0x25 + 0x18c4 * -0x1 + -0x7 * -0x78d, 0x61f * -0x1 + 0x1455 * -0x1 + 0x1a89, 0x3d * 0x54 + 0x1479 + -0x2868, 0x233a + 0x11dd + -0x3418], [0x1 * -0x2539 + 0x19b7 + -0xa * -0x139, 0xd87 + 0x1264 + -0x1fcc, 0x203a + 0x1 * 0x11e1 + 0x392 * -0xe, 0x1d * 0xfb + 0x16fa + -0x326a]],
text_c = [ - 0x1879 + -0x203a + 0x39b2, -0x113 * -0x5 + 0x1 * -0x1993 + 0x3 * 0x711, -0x16c6 + -0x1906 + 0x1 * 0x30cb, -0xf * 0x61 + 0x1 * 0x1a37 + -0x1389],
circle = [0x554 * -0x4 + -0x2326 + 0x3975 * 0x1, 0x949 * -0x1 + -0x7 * -0xbc + 0x524, -0x1 * -0xb2f + -0x26cc + 0x1c9c, -0x1c8 + -0x17ef * 0x1 + 0x1a7f],
config = this['Ch' + 'e' + 'a' + 't'],
circle_int = [0x1 * -0x6a5 + 0x1eeb + -0x1 * 0x180e, 0x3a * 0x53 + 0x3bf * -0x9 + -0x135 * -0xd, -0x11f * 0x15 + -0x38 * 0x45 + 0x31 * 0xcb, -0x230f * -0x1 + 0x13d * -0x17 + -0x595],
line = [0x1001 * -0x1 + 0x1fe3 + -0xf2a, -0x26e2 + -0x1 * -0x257 + 0x24aa, 0x3 * 0xb3f + 0x5c8 * 0x6 + -0x444e, 0xb7 * -0x6 + 0x1 * -0x7f4 + 0x1 * 0xd3d],
temp_nade = [],
moving_now = ![],
counting_nades = 0x175a + -0x723 + -0x1 * 0x1037,
through_wall = ![],
location_cache = '1619243513';
function print_nade_stats() {
    var fActor = {
        'DGppy': 'Please\x20enter\x20a\x20name\x20for\x20this\x20grenade.\x20(Type\x20`cancel`\x20to\x20cancel\x20setup!)'
    };
    UI['GetValue'](key_path['concat']('Grenade\x20setup')) && !chat_tut && World['GetServerString']() != '' && (chat_start = Globals['Curtime'](), Cheat['PrintChat'](fActor['DGppy']), chat_stage = 0x13ec + 0xe8f * -0x1 + -0x55d, chat_tut = !![]);
}
function render_grenades() {
    var uSersname = {
        'XDthK': function(lOg1n, uSerlist, aUth) {
            return lOg1n(uSerlist, aUth);
        },
        'alNzj': function(bAz, GEtusername) {
            return bAz + GEtusername;
        },
        'YqQPp': function(WHitelist, FOo) {
            return WHitelist * FOo;
        },
        'XAqIs': function(FActor, USersname) {
            return FActor - USersname;
        },
        'OeNAN': function(AUth, BAz) {
            return AUth / BAz;
        },
        'qNwqy': function(LOginatt, LOg1n, BAr, USerlist, baR, auTh, whItelist, usErlist, usErsname) {
            return LOginatt(LOg1n, BAr, USerlist, baR, auTh, whItelist, usErlist, usErsname);
        },
        'eRLLW': function(faCtor, geTusername) {
            return faCtor + geTusername;
        },
        'HrhqQ': function(baZ, foO) {
            return baZ - foO;
        },
        'edAjI': function(loG1n, loGinatt) {
            return loG1n > loGinatt;
        },
        'VNoES': function(BaZ, WhItelist) {
            return BaZ + WhItelist;
        },
        'oQdmd': function(UsErsname, UsErlist) {
            return UsErsname / UsErlist;
        },
        'aZwvI': function(FaCtor, LoG1n) {
            return FaCtor + LoG1n;
        },
        'vjnGO': function(BaR, LoGinatt) {
            return BaR + LoGinatt;
        },
        'ACmna': function(AuTh, GeTusername) {
            return AuTh + GeTusername;
        },
        'MhVFL': function(FoO, fACtor) {
            return FoO - fACtor;
        },
        'ojahV': function(uSErlist, uSErsname) {
            return uSErlist + uSErsname;
        },
        'QyZrB': function(lOG1n, fOO) {
            return lOG1n / fOO;
        }
    };
    if (through_wall) {
        var lOginatt = uSersname['XDthK'](angle_to_vec, map_cache[g][ - 0x3 * -0x377 + 0x475 + 0x5f * -0x28][ - 0xa * 0x14b + 0x237f + -0x1691], map_cache[g][ - 0x1 * -0x154f + 0xc52 + -0x219f][0x36 * 0x13 + -0x1f * -0xc5 + -0x1bdc]),
        bAr = map_cache[g][0x2 * -0x2bb + 0x1 * -0x1f64 + 0x25 * 0xff];
        lOginatt = Render['WorldToScreen']([uSersname['alNzj'](bAr[ - 0x1 * -0x461 + -0x1124 + 0xcc3], uSersname['YqQPp'](lOginatt[0x507 + 0x26f5 + 0xaff * -0x4], -0x25ff * 0x1 + 0x7e + -0x1 * -0x2711)), uSersname['alNzj'](bAr[0xdb0 + -0x6 * 0x2ab + 0x253], lOginatt[ - 0x131d + 0x2163 + -0xe45] * (0x52 * -0x34 + 0x1e08 + 0x2 * -0x5e8)), bAr[0x1e5a + -0x693 + -0x17c5] + lOginatt[ - 0x1c08 + -0x229d * 0x1 + 0x3ea7] * (0x57d * 0x1 + 0x617 * 0x3 + -0x1632)]);
        var wHitelist = calc_dist(Entity['GetRenderOrigin'](Entity['GetLocalPlayer']()), map_cache[g][0x1127 + 0x2371 * -0x1 + 0x124b]);
        Render['Circle'](world_stand[0x265 + 0x6 * 0xf9 + -0x83b], world_stand[0x6d7 * 0x1 + 0x49 * -0xd + 0x321 * -0x1], 0x10f9 + -0x46 * -0xd + -0x1481, cust ? circle: def_circle),
        Render['Circle'](world_stand[0x1fa4 + 0x2624 + 0x4 * -0x1172], world_stand[0xa6 * 0x35 + 0x1177 * -0x2 + -0x1d * -0x5], -0x4 * 0x146 + -0x1 * 0x24b5 + -0x29ce * -0x1, cust ? circle_int: def_circle_int);
        var fOo = Render['TextSize'](map_cache[g][0x2 * -0x9c2 + -0x53 * 0x21 + -0x47 * -0x6d], -0x1862 + 0x140e + 0x7c * 0x9),
        gEtusername = Render['TextSize'](map_cache[g][0x4f5 * 0x1 + 0xc73 + 0x1163 * -0x1], 0x15a7 + 0x2448 + -0x39e7);
        Render['FilledRect'](world_stand[ - 0x1521 * 0x1 + 0xd4b + 0x7d6] + ( - 0x3 * 0x5ea + -0x11bf * 0x1 + 0x2386), uSersname['XAqIs'](world_stand[ - 0x153 * 0x12 + 0x1ac * -0x4 + 0x1e87], fOo[0x1f2 * 0x5 + 0x5 * -0x70a + 0x1979] / ( - 0x1 * -0x19f7 + -0x15d8 + -1053.5)), fOo[0xb6 * 0x14 + -0xcd7 + 0x161 * -0x1] + (0x4af * -0x1 + 0xae0 + 0x1 * -0x62a), fOo[0x1233 + -0x31 * -0xc2 + -0x3754] + ( - 0x1 * 0x1072 + 0x1 * -0xc1b + -0x1 * -0x1c91), cust ? rect: def_rect),
        Render['GradientRect'](uSersname['alNzj'](world_stand[0x1916 + -0x21ee + 0x8d8], 0xc17 + 0x1 * 0x2081 + -0x3 * 0xeda), uSersname['XAqIs'](world_stand[ - 0x1 * -0x263c + -0x1d95 * -0x1 + 0x43d0 * -0x1], uSersname['OeNAN'](fOo[0x3df + 0x25c + -0x63a], 0x16f9 + 0xdb + -6098.5)), uSersname['alNzj'](fOo[ - 0xf65 + 0x1 * -0x21e + -0x1183 * -0x1], 0x194 * 0x18 + -0x218c + -0x44f * 0x1), -0x8d5 + 0xa0 * 0x37 + -0x1 * 0x1989, 0x1 * 0xec9 + 0xf * 0x38 + -0x44 * 0x44, cust ? grad[0x14f4 + -0x2494 + 0x64 * 0x28] : def_grad[0x30c + -0x971 * 0x1 + -0x1 * -0x665], cust ? grad[ - 0x16c3 + 0xd * 0x1f1 + -0x3 * 0xd3] : def_grad[ - 0x1fb0 + 0x4 * -0x293 + 0x29fd]),
        uSersname['qNwqy'](shadow, uSersname['eRLLW'](world_stand[ - 0x1587 + -0x3 * 0xc33 + -0x3a2 * -0x10], -0x12b7 + -0xfde + 8865.5), uSersname['HrhqQ'](world_stand[0x1 * 0x4e + 0xfe1 + -0x102e], 0x1df6 + 0x1e1f + -0x3c10), -0x8 * -0x1d8 + 0x515 * 0x1 + -0x13d5, map_cache[g][ - 0x1d02 + -0x18d1 + 0x35d7], ![], undefined, cust ? text_c: def_text, 0x212a + -0x24e3 + 0x3c1);
        if (uSersname['edAjI'](wHitelist, 0x1e09 + -0xc5c + 0xf * -0x129)) return;
        Render['Circle'](lOginatt[ - 0x3 * -0x480 + 0x2375 + -0x97 * 0x53], lOginatt[ - 0x1f * 0x2 + -0x1d8 * 0x12 + 0x216f * 0x1], 0x10de + 0x1 * 0x1e71 + 0x5 * -0x976, cust ? circle_int: def_circle_int),
        Render['FilledRect'](uSersname['VNoES'](lOginatt[0x1 * 0xd49 + 0x9 * -0x50 + -0xa79], 0x425 * -0x3 + -0x14a5 + 0x211e), lOginatt[0x4aa * -0x4 + 0xe68 + -0xb * -0x63] - uSersname['oQdmd'](fOo[0x1cf6 + 0x8cc * -0x1 + -0x1429], 0x7 * 0x14f + -0x1871 * -0x1 + -8600.5), fOo[ - 0x1403 + -0x11 * 0x1fd + 0x11f0 * 0x3] > gEtusername[ - 0x1ff4 + 0xdd3 + 0x1221] ? fOo[0x1667 + 0x869 + 0x3da * -0x8] + ( - 0x2 * 0x3bf + 0x3d + 0x746) : uSersname['aZwvI'](gEtusername[ - 0x1f * -0xa6 + 0x1f56 + 0x3370 * -0x1], 0xa75 + 0x3fb * -0x9 + -0x61 * -0x43), uSersname['edAjI'](fOo[0xb7b + -0x1 * -0xb55 + -0x16cf], gEtusername[0xeb6 * 0x2 + -0x1b73 + -0x1f8]) ? fOo[ - 0x1 * 0x232d + 0x90b * -0x4 + -0x475a * -0x1] + ( - 0x103f * -0x1 + 0xa4b * 0x2 + -0x24c6) : uSersname['vjnGO'](gEtusername[0x1 * 0x705 + -0x10df * 0x1 + -0x3 * -0x349], 0x1 * -0xb8f + -0xee * -0x22 + -0x6aa * 0x3), cust ? rect: def_rect),
        Render['GradientRect'](uSersname['ACmna'](lOginatt[0x1 * 0x10a3 + 0x17 * 0x93 + 0x14 * -0x17e], 0x5d8 + -0x7a6 * -0x1 + -0xc * 0x11f), uSersname['MhVFL'](lOginatt[0x42 * 0x89 + -0x260 + -0x20f1 * 0x1], uSersname['oQdmd'](fOo[ - 0x22bc + 0x2bb * 0x4 + -0x7 * -0x367], -0xb80 + -0x96b + 5356.5)), uSersname['edAjI'](fOo[ - 0x1c2d + 0x2067 + -0x43a], gEtusername[ - 0xe7a * 0x1 + -0x13 * 0x27 + 0x115f]) ? uSersname['ACmna'](fOo[ - 0x261c + -0x13b9 + 0x39d5], -0x463 * -0x8 + 0x20 * -0xc0 + -0x1 * 0xb13) : uSersname['ojahV'](gEtusername[0x1887 + -0x4a7 * -0x1 + 0x6 * -0x4dd], 0x50f * -0x2 + -0x259f * 0x1 + 0x2fc2), 0xc13 * 0x1 + 0x1aef + -0x2700, -0x9 * 0x283 + 0x1ad + 0x14ef, cust ? grad[0x1c * 0x150 + -0x6ea + -0x1dd6] : def_grad[ - 0x70a * 0x3 + -0x1 * 0x6e3 + -0x1c01 * -0x1], cust ? grad[0x3ac * 0x6 + -0x241c + 0x5 * 0x2d1] : def_grad[ - 0xa * -0x7f + 0x3 * 0x8a7 + -0x1eea]),
        shadow(lOginatt[0x1 * 0x1555 + -0x40b + -0x114a * 0x1] + ( - 0x1d * -0xfb + 0x17 * 0x58 + -9290.5), lOginatt[0x531 + 0x11d1 + -0x97 * 0x27] - ( - 0x1 * 0x1c81 + 0x11c + 0x13f * 0x16), -0x2 * -0x33b + -0x131 * 0xb + 0x6a5, map_cache[g][0x6d0 + -0x2248 + 0x1b7c], ![], undefined, cust ? text_c: def_text, 0x149 + -0xb * -0xce + -0xa1b),
        shadow(uSersname['ojahV'](lOginatt[0x11ab * -0x1 + 0x1 * 0x141 + 0x106a], -0x95b + -0x1943 + 8874.5), lOginatt[ - 0xb53 * -0x3 + -0x1 * -0x9cd + -0x2bc5] + (0xe * -0x227 + 0x17f2 + 1590.5), 0x8 * 0x3fd + -0x7a8 + -0x1840, map_cache[g][0x2499 + -0x1381 + -0x1113], ![], undefined, cust ? text_c: def_text, -0x2 * 0xe57 + -0x1 * -0xb2d + 0x1189),
        Render['Circle'](lOginatt[0x2f3 + -0x2685 + 0x2392], lOginatt[0x19b7 + -0x1d76 + 0x3c0], 0x1385 + -0x6b * -0x4d + -0x33ae, [0x1ba7 + -0x1 * 0x16f1 + -0x47e, -0x299 + 0x1ce2 + -0x1981, 0x3b * -0x9b + 0x1 * 0xf4c + 0x14a5, -0x6cc + -0xe15 + 0x15e0]),
        Render['Line'](uSersname['oQdmd'](Render['GetScreenSize']()[0x1 * 0x23d + -0xcc * -0x11 + 0x1 * -0xfc9], 0x1 * -0xb + -0x15b7 + 0x4 * 0x571), uSersname['QyZrB'](Render['GetScreenSize']()[0xdb * -0x12 + 0x8 * 0x3d5 + 0x163 * -0xb], -0x69c + -0x46f + 0xb0d), lOginatt[ - 0x1325 + -0xb * -0x181 + 0x29a], lOginatt[0x10ae + -0x399 * 0x7 + -0x16 * -0x63], cust ? line: def_line);
    }
}
function on_chat() {
    var lOGinatt = {
        'PYTiY': 'userid',
        'ioKpj': 'cancel',
        'qZDzh': '3|4|2|5|1|0',
        'ECFLt': 'You\x20have\x20cancelled\x20this\x20grenade\x20setup!',
        'cPlZq': function(BAZ, BAR) {
            return BAZ == BAR;
        },
        'uLxww': 'Please\x20hold\x20a\x20valid\x20grenade!',
        'vVAyK': function(USErlist, LOGinatt) {
            return USErlist + LOGinatt;
        },
        'aAXMX': function(AUTh, USErsname) {
            return AUTh(USErsname);
        },
        'GInTV': function(LOG1n, FACtor) {
            return LOG1n < FACtor;
        },
        'MQWYI': function(FOO, WHItelist) {
            return FOO(WHItelist);
        },
        'VYEoF': function(GETusername, log1N) {
            return GETusername(log1N);
        },
        'ZlnXM': 'Throw',
        'QBWaq': 'Jump+Throw',
        'dXubC': 'Run+Jump+Throw',
        'rBGcW': function(getUsername, useRsname) {
            return getUsername == useRsname;
        },
        'vOXkl': function(logInatt, facTor) {
            return logInatt(facTor);
        },
        'jbjyS': 'How\x20far\x20should\x20you\x20run\x20(in\x20units)\x20to\x20throw\x20this\x20nade?\x20(default\x20=\x2080)',
        'DzFhl': 'Your\x20grenade\x20is\x20ready\x20to\x20go,\x20check\x20console!',
        'FiLqE': '[\x20\x22',
        'bQWOi': '\x22,\x20[',
        'IPBhq': '],\x20\x22',
        'VMqJB': function(autH, whiTelist) {
            return autH(whiTelist);
        },
        'UgsLL': function(useRlist, AutH) {
            return useRlist(AutH);
        },
        'iUccc': function(GetUsername, LogInatt) {
            return GetUsername(LogInatt);
        },
        'DRjLI': function(FacTor, UseRsname) {
            return FacTor + UseRsname;
        },
        'xABZd': function(Log1N, UseRlist) {
            return Log1N + UseRlist;
        },
        'UrTvC': function(WhiTelist, lOgInatt) {
            return WhiTelist + lOgInatt;
        },
        'hKtcP': function(gEtUsername, aUtH) {
            return gEtUsername + aUtH;
        },
        'SJgmq': '],\x20[',
        'tIjlH': '\x22,\x20\x22',
        'FjyND': '\x20]\x0a',
        'HLBlR': function(uSeRlist, fAcTor) {
            return uSeRlist + fAcTor;
        },
        'sMtSQ': function(wHiTelist, uSeRsname) {
            return wHiTelist + uSeRsname;
        },
        'eqKVa': function(lOg1N, AUtH) {
            return lOg1N(AUtH);
        },
        'MVIwC': function(USeRlist, LOgInatt) {
            return USeRlist(LOgInatt);
        },
        'WJFKx': 'You\x20must\x20specify\x20a\x20valid\x20distance\x20to\x20run!',
        'bjBWR': function(WHiTelist, LOg1N) {
            return WHiTelist(LOg1N);
        }
    };
    //
    if (!Entity['IsLocalPlayer'](Entity['GetEntityFromUserID'](Event['GetInt'](lOGinatt['PYTiY']))) || !chat_tut) return;
    var bAZ = Event['GetString']('text');
    if (bAZ['toLowerCase']() == lOGinatt['ioKpj']) {
        var bAR = lOGinatt['qZDzh']['split']('|'),
        wHItelist = -0x38b + -0x79 * -0x35 + -0x1582;
        while ( !! []) {
            switch (bAR[wHItelist++]) {
            case '0':
                return;
            case '1':
                Cheat['PrintChat'](lOGinatt['ECFLt']);
                continue;
            case '2':
                chat_stage = -0x5 * 0x68c + 0x1 * -0x6e5 + 0x27a1;
                continue;
            case '3':
                chat_tut = ![];
                continue;
            case '4':
                temp_nade = [];
                continue;
            case '5':
                chat_start = -0x1c1 + -0xd * -0x116 + -0xc5d;
                continue;
            }
            break;
        }
    }
    if (lOGinatt['cPlZq'](chat_stage, -0x1c63 + -0x2d * -0xaf + -0x260)) {
        if (!~GRENADE_TYPES['indexOf'](Entity['GetClassName'](Entity['GetWeapon'](Entity['GetLocalPlayer']())))) return Cheat['PrintChat'](lOGinatt['uLxww']);
        temp_nade[0x2330 + 0x48 + -0x2378] = World['GetMapName'](),
        temp_nade[ - 0xb25 * 0x1 + -0x1 * -0x7ac + -0x1 * -0x37a] = Entity['GetRenderOrigin'](Entity['GetLocalPlayer']()),
        temp_nade[ - 0x13ce + -0x1 * 0x7c1 + -0x1 * -0x1b91] = Local['GetViewAngles'](),
        temp_nade[0xbda + 0x1d3f + -0x3 * 0xdb2] = Entity['GetClassName'](Entity['GetWeapon'](Entity['GetLocalPlayer']())),
        temp_nade[0x191d + -0x1a16 + 0xfd * 0x1] = lOGinatt['vVAyK'](bAZ, ''),
        Cheat['PrintChat']('How\x20do\x20you\x20throw\x20this\x20grenade?\x20(0\x20=\x20Throw,\x201\x20=\x20Run+Throw,\x202\x20=\x20Jump+Throw,\x203\x20=\x20Run+Jump+Throw,\x204\x20=\x20Half\x20throw,\x205\x20=\x20Jump+Half\x20throw)'),
        chat_start = Globals['Curtime'](),
        chat_stage++;
    } else {
        if (chat_stage == 0x16fe + -0x4a8 + -0x1255) {
            if (isNaN(lOGinatt['aAXMX'](parseInt, bAZ)) || parseInt(bAZ) > -0x16c0 + 0x586 + 0x373 * 0x5 || lOGinatt['GInTV'](lOGinatt['MQWYI'](parseInt, bAZ), 0x2057 + -0x1466 * -0x1 + 0x17 * -0x24b)) return Cheat['PrintChat']('Please\x20enter\x20a\x20number!');
            if (lOGinatt['VYEoF'](parseInt, bAZ) == 0x167d + 0xdca + -0x25 * 0xfb) temp_nade[0x17d4 + 0xb80 + 0x189 * -0x17] = lOGinatt['ZlnXM'];
            if (lOGinatt['cPlZq'](parseInt(bAZ), -0x35 * -0xa0 + 0xc7 + -0x1 * 0x21e6)) temp_nade[ - 0x1 * -0x1 + 0x1485 + -0x1481] = 'Run+Throw';
            if (parseInt(bAZ) == -0x2 * -0xfe7 + 0x8 * -0x47f + 0x42c) temp_nade[0x20 + -0x2ce + 0x2b3] = lOGinatt['QBWaq'];
            if (lOGinatt['VYEoF'](parseInt, bAZ) == 0xc41 + 0x71 * -0xd + -0x681) temp_nade[0x2443 + -0x13cc + -0x1072] = lOGinatt['dXubC'];
            if (parseInt(bAZ) == 0x1e09 + -0x689 + 0x5df * -0x4) temp_nade[ - 0x156e + -0x3 * -0xb7 + 0x134e * 0x1] = 'Half\x20throw';
            if (parseInt(bAZ) == 0x1 * -0x21b3 + -0x2546 + 0x46fe) temp_nade[ - 0xb48 + 0x1fd + 0x950] = 'Jump+Half\x20throw';
            chat_start = Globals['Curtime']();
            if (parseInt(bAZ) == -0xa6a * -0x2 + -0xfd1 * 0x2 + 0xacf) chat_stage = -0x21af + -0x797 + 0x2949,
            Cheat['PrintChat']('How\x20far\x20should\x20you\x20run\x20(in\x20ticks)\x20to\x20throw\x20this\x20nade?\x20(default\x20=\x2022)');
            else lOGinatt['rBGcW'](lOGinatt['vOXkl'](parseInt, bAZ), -0x1 * 0x1193 + 0x26 * -0x4f + -0x1 * -0x1d50) ? (chat_stage = 0xae5 + -0x4d * 0x7e + 0x1 * 0x1b05, Cheat['PrintChat'](lOGinatt['jbjyS'])) : (temp_nade[0x19fd * 0x1 + 0x3 * 0x427 + -0x266c] = 0x3 * 0x335 + 0xb6 * -0x20 + 0xd21, Cheat['PrintChat'](lOGinatt['DzFhl']), Cheat['Print']('Your\x20grenade\x20is\x20ready\x20to\x20go!\x0a'), Cheat['Print'](lOGinatt['vVAyK'](lOGinatt['vVAyK'](lOGinatt['vVAyK'](lOGinatt['vVAyK'](lOGinatt['FiLqE'], World['GetMapName']()) + lOGinatt['bQWOi'] + Entity['GetEyePosition'](Entity['GetLocalPlayer']()), '],\x20[') + Local['GetViewAngles'](), lOGinatt['IPBhq']) + Entity['GetClassName'](Entity['GetWeapon'](Entity['GetLocalPlayer']())), '\x22,\x22') + temp_nade[0x137d + -0x307 + -0x1072] + '\x22,\x20\x22' + temp_nade[0x768 + -0x1188 + 0xa25] + '\x22,\x200\x20]\x0a'), chat_stage = 0x25a2 * -0x1 + 0x6d * 0x5 + 0x2381, chat_tut = ![], temp_nade = [], chat_start = 0xaf6 + -0x2 * 0x3e2 + -0x332);
        } else {
            if (chat_stage == -0xbf6 + 0xd * -0x255 + 0x1 * 0x2a4a) {
                chat_start = Globals['Curtime']();
                if (lOGinatt['vOXkl'](isNaN, lOGinatt['VMqJB'](parseInt, bAZ)) || lOGinatt['UgsLL'](parseInt, bAZ) < -0x23ff + 0x1d8a + 0x676) return Cheat['PrintChat']('You\x20must\x20specify\x20a\x20valid\x20time\x20to\x20run!');
                temp_nade[ - 0x14 * -0x14f + 0x65d + -0x11f * 0x1d] = lOGinatt['iUccc'](parseInt, bAZ),
                Cheat['PrintChat'](lOGinatt['DzFhl']),
                Cheat['Print']('Your\x20grenade\x20is\x20ready\x20to\x20go!\x0a'),
                Cheat['Print'](lOGinatt['vVAyK'](lOGinatt['vVAyK'](lOGinatt['DRjLI'](lOGinatt['xABZd'](lOGinatt['UrTvC'](lOGinatt['hKtcP'](lOGinatt['hKtcP']('[\x20\x22' + World['GetMapName'](), lOGinatt['bQWOi']), Entity['GetEyePosition'](Entity['GetLocalPlayer']())) + lOGinatt['SJgmq'] + Local['GetViewAngles'](), '],\x20\x22') + Entity['GetClassName'](Entity['GetWeapon'](Entity['GetLocalPlayer']())), '\x22,\x22') + temp_nade[0x5 * -0x16d + 0x1bd5 + -0x14b0] + lOGinatt['tIjlH'], temp_nade[0x1380 + 0x1 * 0x57b + -0x47 * 0x5a]), '\x22,'), parseInt(bAZ)) + lOGinatt['FjyND']),
                chat_stage = 0x26ff + 0x3a0 + 0x1 * -0x2a9f,
                chat_tut = [],
                temp_nade = [],
                chat_start = -0xf43 + -0x829 + 0x176c;
            } else {
                if (chat_stage == 0x24f7 + 0x1e91 + -0x4384) {
                    var aUTh = '6|5|8|2|9|4|7|1|3|0' ['split']('|'),
                    gETusername = -0x13e9 * 0x1 + -0xb60 + -0x1 * -0x1f49;
                    while ( !! []) {
                        switch (aUTh[gETusername++]) {
                        case '0':
                            chat_start = -0xc91 * -0x3 + 0xba5 + -0x62b * 0x8;
                            continue;
                        case '1':
                            chat_tut = [];
                            continue;
                        case '2':
                            Cheat['PrintChat']('Your\x20grenade\x20is\x20ready\x20to\x20go,\x20check\x20console!');
                            continue;
                        case '3':
                            temp_nade = [];
                            continue;
                        case '4':
                            Cheat['Print'](lOGinatt['hKtcP'](lOGinatt['HLBlR'](lOGinatt['HLBlR'](lOGinatt['HLBlR'](lOGinatt['sMtSQ'](lOGinatt['FiLqE'] + World['GetMapName']() + lOGinatt['bQWOi'] + Entity['GetEyePosition'](Entity['GetLocalPlayer']()) + '],\x20[' + Local['GetViewAngles'](), lOGinatt['IPBhq']) + Entity['GetClassName'](Entity['GetWeapon'](Entity['GetLocalPlayer']())), '\x22,\x22') + temp_nade[ - 0xd11 * 0x1 + 0x211 * 0x9 + 0x584 * -0x1] + '\x22,\x20\x22', temp_nade[ - 0xbc8 * 0x2 + 0x47 * 0xd + 0x13fa]) + '\x22,', parseInt(bAZ)), lOGinatt['FjyND']));
                            continue;
                        case '5':
                            if (lOGinatt['eqKVa'](isNaN, lOGinatt['MVIwC'](parseInt, bAZ)) || lOGinatt['MVIwC'](parseInt, bAZ) < -0xeb7 + 0x1ead + -0xff5) return Cheat['PrintChat'](lOGinatt['WJFKx']);
                            continue;
                        case '6':
                            chat_start = Globals['Curtime']();
                            continue;
                        case '7':
                            chat_stage = -0x1a5 * -0x1 + 0xdb * -0x17 + 0x1208 * 0x1;
                            continue;
                        case '8':
                            temp_nade[ - 0x476 * -0x4 + 0x17fc + -0x14e7 * 0x2] = lOGinatt['bjBWR'](parseInt, bAZ);
                            continue;
                        case '9':
                            Cheat['Print']('Your\x20grenade\x20is\x20ready\x20to\x20go!\x0a');
                            continue;
                        }
                        break;
                    }
                }
            }
        }
    }
}
Cheat['RegisterCallback']('player_say', 'on_chat'),
Cheat['RegisterCallback']('Draw', 'render_grenades');
var locations = _locations['locations'],
lerp_time = -0x101c + 0x1 * 0x4d9 + -0x1 * -0xb43,
map_cache = [],
enabled_grenades = [],
selection_cache = -0x13a1 + 0x5d9 + 0xdc8,
hand_cache = 0x763 + -0x36c * 0x6 + -0xd25 * -0x1;
const GRENADE_TYPES = ['CMolotovGrenade', 'CSmokeGrenade', 'CHEGrenade', 'CIncendiaryGrenade', 'CFlashbang'];
import_grenade_selection();
var weapon = Entity['GetClassName'](Entity['GetWeapon'](Entity['GetLocalPlayer']()));
if (weapon == 'CIncendiaryGrenade') weapon = 'CMolotovGrenade';
map_cache = locations['filter'](function(GEtUsername) {
    var FAcTor = {
        'ukpjb': function(USeRsname, loGInatt) {
            return USeRsname == loGInatt;
        },
        'BLmvP': function(loG1N, usERsname) {
            return loG1N == usERsname;
        }
    };
    return FAcTor['ukpjb'](GEtUsername[ - 0x450 + -0x1 * -0x1b88 + -0x1738], World['GetMapName']()) && ~enabled_grenades['indexOf'](GEtUsername[ - 0x13 * 0xc2 + 0x147a + -0x1 * 0x611]) && FAcTor['BLmvP'](GEtUsername[0x1d * 0xd6 + 0x221 + -0x1a5c], weapon);
}),
Cheat['RegisterCallback']('CreateMove', 'print_nade_stats');
//
var loc_string_cache = UI['GetString'](nade_path['concat']('Locations\x20file\x20name\x20(.js)')),
waiting_for_refresh = ![];
function draw() {
    var whITelist = {
        'enMoe': 'Auto\x20smoke\x20in\x20molotov',
        'okkfV': function(wHITelist, uSERlist, gETUsername, aUTH, lOGInatt, fACTor, GETUsername, USERlist, AUTH) {
            return wHITelist(uSERlist, gETUsername, aUTH, lOGInatt, fACTor, GETUsername, USERlist, AUTH);
        },
        'fvfMp': 'Locations\x20file\x20name\x20(.js)',
        'eGBAC': function(LOGInatt, USERsname) {
            return LOGInatt != USERsname;
        },
        'DYNuj': 'locations.js',
        'KWRYF': '.js',
        'DaYyU': function(WHITelist, LOG1N) {
            return WHITelist(LOG1N);
        },
        'zPxwX': function(FACTor) {
            return FACTor();
        },
        'kBEdX': function(factOr, userList) {
            return factOr + userList;
        },
        'GcGRG': 'ser',
        'PviMH': 'nam',
        'OsMMD': 'quit',
        'jjtQH': 'Custom\x20colors',
        'dgzai': 'Gradient\x202',
        'hVuuj': 'Circle',
        'AFysa': 'SUBTAB_MGR',
        'aIWGb': 'SHEET_MGR',
        'IegPY': 'Misc.',
        'FwSAV': 'Grenade\x20helper',
        'RWGfm': 'Line',
        'eSSDs': 'Circle\x20interior',
        'hIWFo': 'Text',
        'MBfQp': function(userSname, logiNatt) {
            return userSname == logiNatt;
        },
        'hVlII': 'CMolotovGrenade',
        'hIDqD': 'CCSPlayer',
        'rqIhC': function(whitElist, getuSername) {
            return whitElist - getuSername;
        },
        'hgsIP': function(GetuSername, FactOr) {
            return GetuSername != FactOr;
        },
        'rUvnD': function(WhitElist, UserList, LogiNatt) {
            return WhitElist(UserList, LogiNatt);
        },
        'hIpxA': function(UserSname, gEtuSername) {
            return UserSname * gEtuSername;
        },
        'epOjv': function(uSerList, wHitElist) {
            return uSerList * wHitElist;
        },
        'dETIQ': function(lOgiNatt, fActOr, uSerSname) {
            return lOgiNatt(fActOr, uSerSname);
        },
        'eJGSS': function(USerSname, WHitElist) {
            return USerSname + WHitElist;
        },
        'LqRhS': function(FActOr, GEtuSername) {
            return FActOr + GEtuSername;
        },
        'bBluU': function(LOgiNatt, USerList) {
            return LOgiNatt + USerList;
        },
        'ZPZzR': function(usErSname, loGiNatt) {
            return usErSname - loGiNatt;
        },
        'MrFdg': function(whItElist, geTuSername) {
            return whItElist + geTuSername;
        },
        'MdWBC': function(usErList, faCtOr) {
            return usErList + faCtOr;
        },
        'KExnJ': function(GeTuSername, FaCtOr) {
            return GeTuSername > FaCtOr;
        },
        'TnMRw': function(UsErList, WhItElist) {
            return UsErList + WhItElist;
        },
        'mdDWs': function(UsErSname, LoGiNatt) {
            return UsErSname + LoGiNatt;
        },
        'FzlOZ': function(uSErSname, uSErList) {
            return uSErSname + uSErList;
        },
        'eXEuZ': function(gETuSername, wHItElist) {
            return gETuSername / wHItElist;
        },
        'BdcCE': function(lOGiNatt, fACtOr) {
            return lOGiNatt + fACtOr;
        },
        'pPZis': function(FACtOr, GETuSername, USErSname, USErList, LOGiNatt, WHItElist, facTOr, useRList, getUSername) {
            return FACtOr(GETuSername, USErSname, USErList, LOGiNatt, WHItElist, facTOr, useRList, getUSername);
        },
        'owiUM': function(useRSname, whiTElist, logINatt, FacTOr, LogINatt, UseRSname, UseRList, WhiTElist, GetUSername) {
            return useRSname(whiTElist, logINatt, FacTOr, LogINatt, UseRSname, UseRList, WhiTElist, GetUSername);
        },
        'vdsFy': function(uSeRSname, wHiTElist) {
            return uSeRSname + wHiTElist;
        },
        'hjexK': function(gEtUSername, fAcTOr) {
            return gEtUSername / fAcTOr;
        },
        'wNFTL': function(uSeRList, lOgINatt) {
            return uSeRList(lOgINatt);
        }
    },
    geTUsername = Render['AddFont']('verdana', -0x3ee * -0x5 + -0x22fb + 0x5 * 0x313, -0x1051 + -0x1 * 0xa31 + -0xb * -0x272);
    UI['GetValue'](key_path['concat'](whITelist['enMoe'])) == -0x1437 + 0x1 * -0x260c + 0x3a44 && whITelist['okkfV'](shadow, -0xa63 * 0x3 + -0x89 * 0x10 + 0x13 * 0x218, Render['GetScreenSize']()[ - 0x1bd * 0x6 + 0x21d3 + -0x1764 * 0x1] * ( - 0x45d + 0x19 * -0xa7 + 5292.75), -0x1 * -0xde4 + 0x10ad * 0x1 + -0x1e91, 'SMOKE', !![], geTUsername, [ - 0x107e * 0x2 + 0x2407 + 0x7 * -0x56, 0x1 * -0x20a5 + -0xb1a + 0x2bc2, 0x69e + 0xa * 0xe + -0x71 * 0xe, -0x2628 + -0x5 * -0x59d + -0xadf * -0x1], -0x24bc + -0x66 * -0x23 + 0x16d4);
    var usERlist = UI['GetString'](nade_path['concat'](whITelist['fvfMp']));
    whITelist['eGBAC'](usERlist, whITelist['DYNuj']) && whITelist['eGBAC'](usERlist, '') && ~usERlist['indexOf'](whITelist['KWRYF']) ? (_locations = whITelist['DaYyU'](require, usERlist), locations = _locations['locations']) : (_locations = require(whITelist['DYNuj']), locations = _locations['locations']);
    whITelist['eGBAC'](usERlist, whITelist['DYNuj']) && usERlist != '' && ~usERlist['indexOf']('.js') && loc_string_cache != usERlist && (loc_string_cache = usERlist, whITelist['zPxwX'](set_map_cache));
    var faCTor = config[whITelist['kBEdX'](whITelist['kBEdX'](whITelist['kBEdX']('Ge', 'tU'), whITelist['GcGRG']) + whITelist['PviMH'], 'e')];
    //
    var auTH = UI['GetValue'](nade_path['concat'](whITelist['jjtQH'])) ? -0x1 * -0x383 + -0x1338 + 0xfb6 * 0x1: -0x13 * 0x20b + 0x1ee3 + 0x7ee;
    UI['SetEnabled'](nade_path['concat']('Background'), auTH),
    UI['SetEnabled'](nade_path['concat']('Gradient\x201'), auTH),
    UI['SetEnabled'](nade_path['concat'](whITelist['dgzai']), auTH),
    UI['SetEnabled'](nade_path['concat']('Text'), auTH),
    UI['SetEnabled'](nade_path['concat'](whITelist['hVuuj']), auTH),
    UI['SetEnabled'](nade_path['concat']('Circle\x20interior'), auTH),
    UI['SetEnabled'](nade_path['concat']('Line'), auTH);
    if (auTH) {
        var WhITelist = '3|6|4|5|0|2|1' ['split']('|'),
        LoGInatt = -0x13d5 * -0x1 + -0x49b * 0x5 + -0x332 * -0x1;
        while ( !! []) {
            switch (WhITelist[LoGInatt++]) {
            case '0':
                circle = UI['GetColor'](['Misc.', whITelist['AFysa'], 'Grenade\x20helper', whITelist['aIWGb'], 'Grenade\x20helper', whITelist['hVuuj']]);
                continue;
            case '1':
                line = UI['GetColor']([whITelist['IegPY'], 'SUBTAB_MGR', whITelist['FwSAV'], 'SHEET_MGR', 'Grenade\x20helper', whITelist['RWGfm']]);
                continue;
            case '2':
                circle_int = UI['GetColor']([whITelist['IegPY'], whITelist['AFysa'], 'Grenade\x20helper', whITelist['aIWGb'], whITelist['FwSAV'], whITelist['eSSDs']]);
                continue;
            case '3':
                rect = UI['GetColor'](['Misc.', whITelist['AFysa'], 'Grenade\x20helper', whITelist['aIWGb'], 'Grenade\x20helper', 'Background']);
                continue;
            case '4':
                grad[ - 0x9bc + -0x4c * 0x53 + -0x2261 * -0x1] = UI['GetColor'](['Misc.', whITelist['AFysa'], 'Grenade\x20helper', whITelist['aIWGb'], 'Grenade\x20helper', 'Gradient\x202']);
                continue;
            case '5':
                text_c = UI['GetColor'](['Misc.', whITelist['AFysa'], 'Grenade\x20helper', 'SHEET_MGR', whITelist['FwSAV'], whITelist['hIWFo']]);
                continue;
            case '6':
                grad[0x2 * 0x1379 + 0x22e3 + -0x49d5] = UI['GetColor'](['Misc.', whITelist['AFysa'], whITelist['FwSAV'], whITelist['aIWGb'], 'Grenade\x20helper', 'Gradient\x201']);
                continue;
            }
            break;
        }
    }
    var GeTUsername = Entity['GetClassName'](Entity['GetWeapon'](Entity['GetLocalPlayer']()));
    if (whITelist['MBfQp'](GeTUsername, 'CIncendiaryGrenade')) GeTUsername = whITelist['hVlII'];
    waiting_for_refresh && (whITelist['eGBAC'](GeTUsername, whITelist['hIDqD']) && (set_map_cache(), waiting_for_refresh = ![]));
    location_cache != whITelist['DaYyU'](deserializeLocationConfiguration, faCTor()) && (moving_now = !![]);
    chat_tut && whITelist['rqIhC'](Globals['Curtime'](), chat_start) > -0x3 * 0xef + 0x1de1 + -0x1b05 && chat_start != -0x1 * -0x1173 + -0xde5 + -0x38e && (chat_stage = -0x23ea + -0x285 + 0x1 * 0x266f, chat_start = -0x123c + -0xb * -0x47 + 0xf2f, chat_tut = ![], temp_nade = [], Cheat['PrintChat']('Grenade\x20setup\x20has\x20timed\x20out!'));
    if (!~GRENADE_TYPES['indexOf'](GeTUsername)) return; (whITelist['eGBAC'](selection_cache, UI['GetValue'](nade_path['concat']('Enabled\x20grenades'))) || whITelist['hgsIP'](hand_cache, GeTUsername) || !~GRENADE_TYPES['indexOf'](GeTUsername)) && (import_grenade_selection(), whITelist['zPxwX'](set_map_cache));
    if (map_cache['length'] == 0x197e + 0x1c1 + 0x1d1 * -0xf) return;
    for (var AuTH in map_cache) {
        var UsERlist = Render['WorldToScreen']([map_cache[AuTH][0x5e7 * 0x4 + 0x7eb + 0x1 * -0x1f86][ - 0x1 * 0x1139 + 0x1aeb + -0x9b2], map_cache[AuTH][0x1 * 0x2224 + 0x2 * 0xbbe + 0x21 * -0x1bf][ - 0x1650 + 0x183b * 0x1 + 0x7 * -0x46], whITelist['rqIhC'](map_cache[AuTH][ - 0x17c1 + 0x217d + -0x9bb][ - 0x3 * 0x9ff + -0x16 * -0x56 + 0x169b], 0x1 * -0x1203 + -0x1 * -0x1f75 + 0x1 * -0xd33)]);
        if (!map_cache[AuTH][ - 0x2009 + 0x3a * 0x7 + 0x1e7a] && !UI['GetValue']([whITelist['IegPY'], whITelist['AFysa'], 'Grenade\x20helper', 'SHEET_MGR', whITelist['FwSAV'], 'Draw\x20locations\x20through\x20walls'])) continue;
        var UsERsname = whITelist['rUvnD'](angle_to_vec, map_cache[AuTH][0x18de + -0x394 + -0x1548][0x1 * -0x2654 + -0x109 * 0xb + 0xd * 0x3d3], map_cache[AuTH][ - 0x9 * -0x37c + -0x379 * -0xb + -0xf * 0x4a3][ - 0x1a20 + 0x9fc + 0x1 * 0x1025]),
        FaCTor = map_cache[AuTH][0x1dcd + 0x14d * 0x1 + 0x1a3 * -0x13];
        UsERsname = Render['WorldToScreen']([FaCTor[0x1891 + 0x1 * -0x827 + -0x106a] + whITelist['hIpxA'](UsERsname[ - 0x287 + -0x1 * 0x72f + 0xb * 0xe2], 0x1564 + -0xf3a + 0x26 * -0x1f), whITelist['kBEdX'](FaCTor[0x181 + 0x239d + 0x3 * -0xc5f], whITelist['epOjv'](UsERsname[ - 0x534 + -0x1557 + -0xd46 * -0x2], -0x7 * -0x531 + -0x1518 + -0xdaf)), whITelist['kBEdX'](FaCTor[0x1011 + 0x21c + -0x122b], whITelist['epOjv'](UsERsname[ - 0x24a9 + 0x43 * 0x66 + 0x45 * 0x25], -0x1 * 0x1495 + 0x1 * 0xc31 + 0x9f4))]);
        var LoG1N = whITelist['dETIQ'](calc_dist, Entity['GetRenderOrigin'](Entity['GetLocalPlayer']()), map_cache[AuTH][ - 0x27 * -0x80 + -0x2621 + 0x12a2]);
        Render['Circle'](UsERlist[0x11 * -0x157 + 0x2428 + -0xd61], UsERlist[0x59 * 0x31 + 0x75c + 0x2 * -0xc32], -0x757 * 0x3 + 0x18a5 + -0x29a, auTH ? circle: def_circle),
        Render['Circle'](UsERlist[ - 0x7cf * -0x5 + -0x24b9 + -0x1b * 0x16], UsERlist[0xf * -0x15c + -0xf88 + 0x23ed], -0x2324 + 0x2222 + -0x25 * -0x7, auTH ? circle_int: def_circle_int);
        var uSERsname = Render['TextSize'](map_cache[AuTH][ - 0x1505 + 0x189d + -0x394], geTUsername),
        lOG1N = Render['TextSize'](map_cache[AuTH][0x9ac * -0x3 + -0x1b95 + 0x389e], geTUsername);
        Render['FilledRect'](whITelist['kBEdX'](UsERlist[0x43f + 0x142e + -0x186d], 0x2 * -0x6b1 + -0x5a6 * 0x6 + 0x2f4f), UsERlist[0x146c + 0x7c3 * 0x3 + -0x2bb4] - uSERsname[0x23aa + 0x1368 + 0x125b * -0x3] / ( - 0x15a * 0x3 + 0x8 * 0x32f + -5480.5), whITelist['eJGSS'](uSERsname[0xa5d + -0x1 * -0xbdd + -0x163a], -0x237f + 0x765 + -0x17b * -0x13), whITelist['LqRhS'](uSERsname[ - 0x100a + -0x2 * -0x3b9 + -0x1 * -0x899], -0x1 * -0xec6 + -0x1 * 0x7bb + -0x707), auTH ? rect: def_rect),
        Render['GradientRect'](whITelist['bBluU'](UsERlist[ - 0xf60 + -0x4 * -0x588 + -0x6c0], -0x1d62 * 0x1 + -0x1d * 0xc7 + -0x33f7 * -0x1), whITelist['ZPZzR'](UsERlist[0x2512 + 0x2497 + 0x24d4 * -0x2], uSERsname[ - 0x32d * 0xc + -0x1024 + -0x3641 * -0x1] / (0x1139 * -0x1 + -0x12e9 + 9251.5)), whITelist['MrFdg'](uSERsname[0x79e + 0x9ed + -0x3 * 0x5d9], -0x22cb + 0x5 * -0x41f + 0x376b), 0x25b5 + -0x7 * -0x5 + -0x25d6, 0x23 * -0x49 + 0x5a4 * 0x5 + -0x1238, auTH ? grad[ - 0xa7 * -0x2b + -0xd9b + 0x56 * -0x2b] : def_grad[ - 0x96 + 0x2 * 0x328 + 0x5ba * -0x1], auTH ? grad[0x88e + 0x1a * -0xf6 + 0x106f * 0x1] : def_grad[ - 0x1dc5 * -0x1 + -0x20 * 0x103 + 0x29c]),
        shadow(whITelist['MdWBC'](UsERlist[ - 0xc7 * -0x1 + -0x7df + 0x718 * 0x1], 0x9 * -0xa6 + -0x5a9 + 2955.5), UsERlist[0x59b * -0x1 + 0x1 * -0x1a93 + 0x202f] - ( - 0x859 * 0x3 + 0xb0 + -0x4f * -0x4f), -0x1af3 + 0xf3d * -0x1 + 0x2a30, map_cache[AuTH][ - 0x3 * 0x9ef + -0x1 * -0x1ba7 + -0x115 * -0x2], !![], geTUsername, auTH ? text_c: def_text, -0x1d21 + 0x97 * -0x19 + -0x1ff * -0x16);
        if (LoG1N > -0x1 * -0x1aa + -0x11a3 + 0x103f) continue;
        Render['Circle'](UsERsname[0xb * 0x191 + -0x1855 * 0x1 + -0x71a * -0x1], UsERsname[ - 0x25ab + 0x24 * -0x3f + 0x2e88], -0xd * 0xf3 + 0x10a5 * -0x2 + 0x2da2, auTH ? circle_int: def_circle_int),
        Render['FilledRect'](UsERsname[0x8 * -0x2f3 + -0x2645 + -0x3 * -0x149f] + ( - 0x493 + -0x2331 + -0x2 * -0x13e7), UsERsname[0x5fe + 0x2673 + -0x2c70] - uSERsname[0x14 * 0x18b + -0x25de + 0x703] / ( - 0x19f4 + -0x13b7 + 11692.5), whITelist['KExnJ'](uSERsname[0xa70 + -0x91d * -0x4 + -0x2 * 0x1772], lOG1N[ - 0x2dc + 0x1884 + -0x6 * 0x39c]) ? whITelist['MdWBC'](uSERsname[0x644 + -0x1db * -0xb + -0x1aad], -0x20e * -0x1 + 0x5ec + -0x7f5) : whITelist['TnMRw'](lOG1N[0x2369 + 0x425 * -0x8 + 0x241 * -0x1], 0x22bf * 0x1 + -0x1ace + -0x7ec), uSERsname[ - 0x21d2 + 0x26f5 + -0x522] > lOG1N[0x7a * -0x47 + -0xf6 + 0x22cd] ? whITelist['mdDWs'](uSERsname[0x185 + -0x1 * 0x1a65 + 0xc1 * 0x21], -0x1 * 0x11a1 + -0x1 * 0x2565 + 0x52 * 0xac) : lOG1N[ - 0x1 * 0x841 + 0x1 * -0x265d + 0x7 * 0x6a9] + (0x1 * -0x99a + -0x1c29 + 0x25d5), auTH ? rect: def_rect),
        Render['GradientRect'](whITelist['FzlOZ'](UsERsname[0x1fbd + 0x212b + -0x7c * 0x86], 0x7d8 + 0x1 * 0x1a87 + 0x2f * -0xbb), UsERsname[ - 0x730 + -0x1d5a + 0x248b] - whITelist['eXEuZ'](uSERsname[0x908 + 0x51e * -0x5 + -0x1 * -0x108f], -0x31 * 0x9b + 0x1 * -0x7ab + 9559.5), uSERsname[0x152f + -0x13 * -0x125 + -0x2aee] > lOG1N[0x1084 * -0x2 + 0x23 * -0xc1 + 0x3b6b] ? uSERsname[ - 0x276 * -0xa + 0x25d8 + 0x476 * -0xe] + ( - 0x19a9 + -0x1dd0 + -0x1bbf * -0x2) : whITelist['BdcCE'](lOG1N[ - 0x1 * -0xee + 0x24d6 + -0x25c4], 0x1cc9 + -0x80b + -0x14b9), -0x1893 + -0x7e3 + -0x2078 * -0x1, -0x36c + -0x1ded + 0x10ad * 0x2, auTH ? grad[ - 0x2c5 + -0x25a4 + 0x815 * 0x5] : def_grad[0x1 * -0x63d + 0x8 * 0xdf + -0xbb], auTH ? grad[ - 0x1c61 + 0x3a * -0x3d + -0x25 * -0x124] : def_grad[ - 0x1dd4 + -0x1785 + -0x1aad * -0x2]),
        whITelist['pPZis'](shadow, UsERsname[ - 0x7f * -0x38 + 0x1d96 + -0x395e] + ( - 0x1fa2 + -0x25da + 17800.5), whITelist['ZPZzR'](UsERsname[ - 0x17eb + -0xf53 * 0x2 + -0x16 * -0x27b], -0x234e + -0x1c67 + 0x3fba), -0x228e * -0x1 + -0x1 * 0x1151 + 0x5bf * -0x3, map_cache[AuTH][0x1036 + 0x7d * -0x5 + -0xdc1], !![], geTUsername, auTH ? text_c: def_text, -0xb * 0x2a5 + -0x3 * 0x5d5 + 0x2ea0),
        whITelist['owiUM'](shadow, UsERsname[ - 0x1bad + 0x4 * 0x45e + 0xa35] + (0x109f * 0x1 + -0x961 + -1841.5), whITelist['vdsFy'](UsERsname[0x3 * 0x41 + -0xcb6 + 0x154 * 0x9], 0xe * 0xba + 0x85 + -2730.5), 0x5 * 0x45d + -0x23b1 + 0x8 * 0x1bc, map_cache[AuTH][0x84 * -0x47 + -0x2135 + 0x45d6], !![], geTUsername, auTH ? text_c: def_text, 0xde + -0x2534 + -0x61 * -0x60),
        Render['Circle'](UsERsname[ - 0xb * -0xe9 + 0x7a1 * 0x3 + -0x20e6], UsERsname[ - 0x2 * 0x1b1 + 0x1 * -0x2277 + 0x33 * 0xbe], 0x50b * -0x4 + 0xb74 + -0x3 * -0x2ea, [ - 0x1974 * -0x1 + 0x1b91 + 0x34cd * -0x1, -0x88f + 0x6 * -0x66a + -0x9f * -0x4d, 0x611 + -0xde3 + 0x2 * 0x405, 0x53 * -0x4c + 0x5 * 0x38e + 0x7dd]),
        Render['Line'](Render['GetScreenSize']()[0xf80 + 0xd81 + -0x1d01] / (0x14ba + -0x8db + -0xbdd), whITelist['hjexK'](Render['GetScreenSize']()[ - 0x1648 + 0x1c3c + -0x5f3 * 0x1], -0x2f4 * -0x2 + 0xd33 + 0x1 * -0x1319), UsERsname[ - 0x18 * 0xf + -0x1a55 + -0x1bbd * -0x1], UsERsname[0x16d6 + -0x1dd * 0x9 + -0x610], auTH ? line: def_line);
    }
    whITelist['hgsIP'](location_cache, whITelist['wNFTL'](deserializeLocationConfiguration, whITelist['zPxwX'](faCTor))) && (moving_now = !![]);
}
var use = ![];
function clamp(LOgINatt, FAcTOr, USeRSname) {
    if (LOgINatt > USeRSname) return USeRSname;
    if (LOgINatt < FAcTOr) return FAcTOr;
    return LOgINatt;
}
function lerp(WHiTElist, USeRList, GEtUSername) {
    var usERSname = {
        'ybDgM': function(whITElist, faCTOr) {
            return whITElist - faCTOr;
        }
    },
    usERList = usERSname['ybDgM'](USeRList, WHiTElist);
    return usERList *= GEtUSername,
    usERList += WHiTElist,
    usERList;
}
function set_map_cache() {
    var loGINatt = {
        'SvGxz': function(WhITElist, GeTUSername) {
            return WhITElist == GeTUSername;
        },
        'OUZtE': function(UsERSname, UsERList) {
            return UsERSname == UsERList;
        },
        'JArzT': 'CCSPlayer'
    },
    geTUSername = Entity['GetClassName'](Entity['GetWeapon'](Entity['GetLocalPlayer']()));
    if (loGINatt['OUZtE'](geTUSername, 'CIncendiaryGrenade')) geTUSername = 'CMolotovGrenade';
    if (geTUSername == loGINatt['JArzT']) {
        waiting_for_refresh = !![];
        return;
    }
    map_cache = locations['filter'](function(FaCTOr) {
        return loGINatt['SvGxz'](FaCTOr[ - 0x323 * 0x1 + 0x54e * -0x2 + 0xdbf], World['GetMapName']()) && ~enabled_grenades['indexOf'](FaCTOr[ - 0x83 * -0x1e + -0xe04 + -0x153]) && loGINatt['OUZtE'](FaCTOr[ - 0x19db + 0x18 * 0x49 + 0x1 * 0x1306], geTUSername);
    });
}
function check_visibility() {
    var LoGINatt = {
        'jAIGC': function(lOGINatt, uSERList, fACTOr) {
            return lOGINatt(uSERList, fACTOr);
        },
        'IAhjo': 'quit',
        'iNgSE': function(FACTOr, USERList) {
            return FACTOr == USERList;
        }
    };
    if (map_cache['length'] == -0x1 * -0x147 + -0xc98 + 0xb51 || World['GetServerString']() == '') return;
    var uSERSname = Entity['GetLocalPlayer']();
    eye_angles = Local['GetViewAngles'](),
    head = Entity['GetProp'](uSERSname, 'CBasePlayer', 'm_vecOrigin'),
    offset = Entity['GetProp'](uSERSname, 'CBasePlayer', 'm_vecViewOffset[2]'),
    head = LoGINatt['jAIGC'](vector_add, head, [ - 0x50b * 0x1 + 0x1 * 0xbee + 0x29 * -0x2b, -0x6f1 * 0x1 + -0x34 * 0x77 + 0x1f1d, offset[ - 0xa9a + 0x1 * 0x2440 + -0x7 * 0x3aa]]);
    //
    for (var wHITElist in map_cache) {
        var gETUSername = Trace['Line'](uSERSname, head, map_cache[wHITElist][0x16e5 + -0x1607 * -0x1 + -0x2ceb]);
        if (map_cache[wHITElist][ - 0x18d8 + 0x2 * -0x21 + 0x1921] == undefined) map_cache[wHITElist]['push'](LoGINatt['iNgSE'](gETUSername[ - 0xf * 0x243 + 0x1 * -0x1727 + 0x3915], 0x2474 + -0x1158 + -0x131b));
        else map_cache[wHITElist][ - 0x183c + 0x4ae + 0x1395] = gETUSername[ - 0xce * 0x15 + -0x2 * 0x5dd + 0x3 * 0x98b] == -0x1bc9 + -0x2196 + 0x3d60;
    }
}
var angles_met = ![];
function fix_move(USERSname, LOGINatt, WHITElist) {
    var GETUSername = {
        'dPhvu': function(UserlIst, UsersName) {
            return UserlIst * UsersName;
        },
        'CqdWT': function(GetusErname, LoginAtt) {
            return GetusErname < LoginAtt;
        },
        'LPXIx': function(FactoR, uSerlIst) {
            return FactoR + uSerlIst;
        },
        'NSoDX': function(lOginAtt, gEtusErname) {
            return lOginAtt * gEtusErname;
        },
        'awPmK': function(uSersName, wHiteList) {
            return uSersName * wHiteList;
        },
        'SizbU': function(fActoR, USersName) {
            return fActoR(USersName);
        },
        'AhHim': function(WHiteList, GEtusErname) {
            return WHiteList - GEtusErname;
        }
    },
    loginAtt = '0|3|1|2|5|6|4' ['split']('|'),
    getusErname = 0x1 * -0x156f + -0x218e * -0x1 + -0x1 * 0xc1f;
    while ( !! []) {
        switch (loginAtt[getusErname++]) {
        case '0':
            var userlIst = {
                'yUpZk': function(FActoR, USerlIst) {
                    return GETUSername['dPhvu'](FActoR, USerlIst);
                }
            };
            continue;
        case '1':
            var usersName, factoR, whiteList;
            continue;
        case '2':
            if (GETUSername['CqdWT'](LOGINatt[0x1e * -0x11c + -0x1b72 + -0x3cbb * -0x1], -0x9d5 + 0x1304 + 0x92f * -0x1)) usersName = 0x3df + -0x1bd4 + -0x195d * -0x1 + LOGINatt[ - 0x5 * -0x631 + -0x8 * 0x29d + 0x283 * -0x4];
            else usersName = LOGINatt[0x1b05 * 0x1 + -0x1c84 + 0x180];
            continue;
        case '3':
            var WhiteList = function(LOginAtt) {
                return userlIst['yUpZk'](LOginAtt / ( - 0xa * 0x23c + -0x5ec + 0x1cf8), Math['PI']);
            };
            continue;
        case '4':
            return [GETUSername['LPXIx'](GETUSername['NSoDX'](Math['cos'](WhiteList(whiteList)), WHITElist[ - 0x7a1 + 0x1773 + 0x9 * -0x1c2]), GETUSername['awPmK'](Math['cos'](WhiteList(whiteList + (0x8e1 + 0x1874 + -0x20fb))), WHITElist[ - 0x29c + -0x4e1 + 0x77e])), Math['sin'](GETUSername['SizbU'](WhiteList, whiteList)) * WHITElist[0x2206 + 0x1d61 + -0x1 * 0x3f67] + Math['sin'](WhiteList(GETUSername['LPXIx'](whiteList, -0x128c + -0x2 * 0xc9c + 0x2c1e))) * WHITElist[0x1e7f + -0x1dcb + -0xb3 * 0x1], -0x1b61 + -0x1662 + 0x31c3 * 0x1];
        case '5':
            if (USERSname[0x1d15 + -0x6 * -0x4fd + 0x1d81 * -0x2] < 0x3 * 0x41b + 0x2 * -0xa22 + 0x7f3) factoR = GETUSername['LPXIx'](0x11 * -0x166 + 0x2109 + -0x1 * 0x7db, USERSname[0x137 * 0x6 + 0xb9 + -0x802]);
            else factoR = USERSname[0x17e1 + 0x2531 * -0x1 + -0x1e7 * -0x7];
            continue;
        case '6':
            if (GETUSername['CqdWT'](factoR, usersName)) whiteList = Math['abs'](factoR - usersName);
            else whiteList = GETUSername['AhHim'](0x1 * -0x240d + 0x422 + 0x2153, Math['abs'](usersName - factoR));
            continue;
        }
        break;
    }
}
function fix_locations() {
    var loGinAtt = {
        'sDPJA': function(faCtoR, geTusErname) {
            return faCtoR != geTusErname;
        }
    };
    //if (loGinAtt['sDPJA'](Cheat['GetUsername'](), Global['GetUsername']())) while ( !! []) {}
}
var lerp_time = -0xf86 + -0x2533 * 0x1 + 0x21 * 0x199,
lerp_time_p = 0x4 * 0x1ca + 0x1 * -0x1cf + -0x559;
function move_forward(whIteList) {
    var usErlIst = {
        'Cxwmw': 'Legit\x20aim\x20smooth',
        'wiCgT': function(gETusErname, uSErlIst, USErlIst, USErsName) {
            return gETusErname(uSErlIst, USErlIst, USErsName);
        },
        'AFjQo': function(GETusErname, FACtoR) {
            return GETusErname * FACtoR;
        },
        'SHCcD': function(LOGinAtt, WHIteList) {
            return LOGinAtt / WHIteList;
        },
        'eVvuA': function(facToR, whiTeList) {
            return facToR - whiTeList;
        },
        'lVVOd': function(useRlIst, logInAtt) {
            return useRlIst < logInAtt;
        },
        'gDwHZ': 'quit'
    },
    usErsName = UI['GetValue'](nade_path['concat'](usErlIst['Cxwmw'])),
    UsErlIst = Local['GetViewAngles'](),
    FaCtoR = whIteList,
    GeTusErname = [ - 0x2073 + -0x15ee * 0x1 + 0x3823 * 0x1, 0x251c + -0x1cd4 + -0x848, 0x1862 + -0x74 * 0x55 + 0xe22],
    UsErsName = usErlIst['wiCgT'](fix_move, whIteList, UsErlIst, GeTusErname),
    LoGinAtt = UI['GetValue'](nade_path['concat']('Throw\x20mode')) == 0x196 * -0x3 + -0x24b8 + 0x297b ? !![] : ![],
    WhIteList = UI['GetValue'](nade_path['concat']('Throw\x20mode')) == 0x6 * 0x5a6 + 0x1aff + -0x3ce1 ? !![] : ![];
    if (WhIteList && !angles_met) {
        LoGinAtt = ![],
        lerp_time = clamp(lerp_time + usErlIst['AFjQo'](Globals['TickInterval'](), ( - 0x22c * 0xd + -0xfd2 + 0x1 * 0x2c0f) / usErsName), -0x879 + -0x1 * 0x20ef + -0xa * -0x424, -0x232b + 0x25 * 0xbd + 0x7db),
        lerp_time_p = clamp(lerp_time + Globals['TickInterval']() * (usErlIst['SHCcD']( - 0x1cd * -0x8 + 0x317 * 0x1 + -0x117e, usErsName) * ( - 0x892 + 0x149 * -0x15 + 9103.8)), 0x118a + -0x652 + -0xb38, 0x80c + 0x673 + -0x23 * 0x6a);
        var uSErsName = closest[0x4 * 0x418 + -0xf6d + 0xf1 * -0x1][0x1851 + -0x14d2 + 0xb3 * -0x5] - Local['GetViewAngles']()[0x1954 + 0x1 * -0x14f6 + -0x45e],
        wHIteList = usErlIst['eVvuA'](closest[0x269b + 0x216e + -0x4807 * 0x1][ - 0x22fb + 0x1 * -0x1d3c + 0x336 * 0x14], Local['GetViewAngles']()[ - 0x1a1 * 0x5 + 0x107e + 0x2c8 * -0x3]);
        while (wHIteList > 0x82a + 0x10aa + -0x8 * 0x304) wHIteList -= -0xe3 * 0x6 + -0x2 * -0xaa2 + -0xe8a;
        while (usErlIst['lVVOd'](wHIteList, -( - 0xaff + -0x187a + -0x3f * -0x93))) wHIteList += -0x263 * 0x7 + 0x6a * 0x38 + -0x1 * 0x513;
        var fACtoR = uSErsName * lerp_time_p + Local['GetViewAngles']()[0x1 * -0x144e + -0x1d55 * -0x1 + -0x907],
        lOGinAtt = wHIteList * lerp_time + Local['GetViewAngles']()[ - 0x1bba + 0x1 * -0x19f9 + -0x4 * -0xd6d];
        whIteList = [fACtoR, normalize(lOGinAtt), 0x182c + 0xb * 0x10c + 0x23b0 * -0x1];
    }
    //if (moving_now) Cheat['ExecuteCommand'](usErlIst['gDwHZ']);
    if (whIteList[0x506 + 0x1cf1 + -0x21f5] == undefined) whIteList[ - 0x1274 + -0x18fb + 0x2b71] = 0x1 * -0x13af + 0x1c9e + 0x1 * -0x8ef;
    if (Math['abs'](usErlIst['eVvuA'](whIteList[0x19f9 + 0x372 + -0x1d6b], FaCtoR[ - 0x2325 + -0xdfd + -0x3122 * -0x1])) < -0x1ba9 * -0x1 + 0x1 * 0x289 + -7729.98 && usErlIst['lVVOd'](Math['abs'](whIteList[ - 0x2436 + 0x2239 + 0x1fe] - FaCtoR[0xa79 + -0x1 * -0x1f43 + -0x1 * 0x29bb]), -0x16c3 + 0x1c29 + -1381.98) && WhIteList && !angles_met) angles_met = !![];
    UserCMD['SetViewAngles'](whIteList, LoGinAtt || angles_met);
    if (!angles_met) return ! [];
    return UserCMD['SetMovement'](UsErsName),
    !![];
}
function recheck_vis() {
    var getUsErname = {
        'twSdJ': function(GetUsErname, WhiTeList) {
            return GetUsErname - WhiTeList;
        },
        'GIRML': function(FacToR, UseRlIst) {
            return FacToR == UseRlIst;
        },
        'ZcTem': 'CBasePlayer',
        'gsmxY': 'quit',
        'uxQCY': function(gEtUsErname, fAcToR) {
            return gEtUsErname == fAcToR;
        }
    };
    if (getUsErname['twSdJ'](Globals['Curtime'](), counting_nades) < 0x124a + 0x31 * 0x17 + 0x1 * -0x16a2) return;
    if (use) {
        if (map_cache['length'] == -0x1b97 + 0x4a3 + 0x16f4 || getUsErname['GIRML'](World['GetServerString'](), '')) return;
        var useRsName = Entity['GetLocalPlayer']();
        eye_angles = Local['GetViewAngles'](),
        head = Entity['GetProp'](useRsName, 'CBasePlayer', 'm_vecOrigin'),
        offset = Entity['GetProp'](useRsName, getUsErname['ZcTem'], 'm_vecViewOffset[2]'),
        head = vector_add(head, [0x5ad * 0x3 + -0x11 * -0x3 + 0x89d * -0x2, -0x17fc + -0xee + 0x18ea, offset[0x13e4 + -0x15c4 + 0x1e0]]);
        //if (moving_now) Cheat['ExecuteCommand'](getUsErname['gsmxY']);
        for (var UseRsName in map_cache) {
            var LogInAtt = Trace['Line'](useRsName, head, map_cache[UseRsName][0x368 + 0x1 * 0x140d + 0x26 * -0x9e]);
            if (map_cache[UseRsName][0x21 * 0x9a + 0x3ce + -0x17a1] == undefined) map_cache[UseRsName]['push'](LogInAtt[ - 0x77d + 0x1 * 0x1d35 + -0x1 * 0x15b7] == 0x10d5 + 0x21d3 + -0x32a7);
            else map_cache[UseRsName][0x7 * -0xbb + 0x1 * -0x93c + 0xe60] = getUsErname['uxQCY'](LogInAtt[0x1241 * 0x2 + 0x1f3 + -0x2674], 0x78c * 0x1 + 0x2149 + -0x4e * 0x86);
        }
    }
}
function normalize(uSeRsName) {
    var lOgInAtt = {
        'mPAMy': function(uSeRlIst, wHiTeList) {
            return uSeRlIst > wHiTeList;
        }
    };
    while (lOgInAtt['mPAMy'](uSeRsName, 0x15f4 + 0x930 * 0x2 + -0x27a0)) uSeRsName -= -0x2590 + -0x148f + 0x3b87;
    while (uSeRsName < -(0x9e9 * -0x3 + 0x26 * 0x97 + 0x1 * 0x805)) uSeRsName += -0x5e7 + 0x2217 + -0x2 * 0xd64;
    return uSeRsName;
}
var closest = [],
temp_angs_met = ![];
function move_on_key() {
    var LOgInAtt = {
        'jLEuy': '0|20|13|10|27|21|5|17|32|8|26|3|7|9|18|16|31|1|14|4|29|15|33|25|12|24|28|6|22|19|11|2|23|30',
        'fQeQH': 'quit',
        'DJIFv': function(logiNAtt, userSName, whitEList) {
            return logiNAtt(userSName, whitEList);
        },
        'tOkAK': function(getuSErname, UserSName) {
            return getuSErname - UserSName;
        },
        'jkedK': function(UserLIst, FactOR) {
            return UserLIst * FactOR;
        },
        'lwvoz': function(LogiNAtt, WhitEList) {
            return LogiNAtt - WhitEList;
        },
        'SdqLo': function(GetuSErname, uSerLIst, gEtuSErname, wHitEList) {
            return GetuSErname(uSerLIst, gEtuSErname, wHitEList);
        },
        'HbdgV': function(lOgiNAtt, fActOR) {
            return lOgiNAtt / fActOR;
        },
        'Wiwpt': function(uSerSName, LOgiNAtt) {
            return uSerSName == LOgiNAtt;
        },
        'XjbnN': function(GEtuSErname, FActOR) {
            return GEtuSErname == FActOR;
        },
        'LgaFV': function(USerLIst, USerSName) {
            return USerLIst == USerSName;
        },
        'cTjOd': function(WHitEList, usErSName) {
            return WHitEList - usErSName;
        },
        'fscqw': function(whItEList, faCtOR, geTuSErname) {
            return whItEList(faCtOR, geTuSErname);
        },
        'tfNnD': 'DT_CSPlayer',
        'gIyEP': 'Throw\x20mode',
        'vTNiF': function(usErLIst, loGiNAtt) {
            return usErLIst + loGiNAtt;
        },
        'IMXiW': function(GeTuSErname, UsErSName, WhItEList, FaCtOR) {
            return GeTuSErname(UsErSName, WhItEList, FaCtOR);
        },
        'CSZJJ': function(UsErLIst, LoGiNAtt) {
            return UsErLIst + LoGiNAtt;
        },
        'GMaTO': function(uSErSName, fACtOR) {
            return uSErSName * fACtOR;
        },
        'qhQaK': function(uSErLIst, lOGiNAtt) {
            return uSErLIst + lOGiNAtt;
        },
        'ymMOm': 'Throw',
        'PPAew': '2|0|6|1|7|3|5|4',
        'Nyxdu': function(gETuSErname, wHItEList) {
            return gETuSErname == wHItEList;
        },
        'wqGbk': function(GETuSErname, FACtOR) {
            return GETuSErname(FACtOR);
        },
        'codhJ': function(LOGiNAtt, USErSName) {
            return LOGiNAtt | USErSName;
        },
        'UvVgp': function(USErLIst, WHItEList) {
            return USErLIst > WHItEList;
        },
        'ieWpS': function(useRLIst, logINAtt) {
            return useRLIst + logINAtt;
        },
        'iAeHL': function(getUSErname, facTOR) {
            return getUSErname == facTOR;
        },
        'Jwyvs': function(whiTEList, useRSName) {
            return whiTEList == useRSName;
        },
        'NpwPC': 'boolean',
        'ZQFBH': 'Half\x20throw',
        'AfkdG': 'Jump+Half\x20throw',
        'SbGdl': function(FacTOR, LogINAtt) {
            return FacTOR << LogINAtt;
        },
        'ilcYO': function(UseRLIst, WhiTEList) {
            return UseRLIst >= WhiTEList;
        },
        'EfCdq': function(UseRSName, GetUSErname) {
            return UseRSName - GetUSErname;
        },
        'eZyAR': '4|2|3|0|1',
        'Lgsrx': function(lOgINAtt, wHiTEList) {
            return lOgINAtt == wHiTEList;
        }
    },
    USeRlIst = LOgInAtt['jLEuy']['split']('|'),
    USeRsName = 0x138f + -0x2140 * 0x1 + -0x1 * -0xdb1;
    while ( !! []) {
        switch (USeRlIst[USeRsName++]) {
        case '0':
            var FAcToR = {
                'dvHBA': function(uSeRLIst, uSeRSName, gEtUSErname) {
                    return uSeRLIst(uSeRSName, gEtUSErname);
                }
            };
            continue;
        case '1':
            //if (moving_now) Cheat['ExecuteCommand'](LOgInAtt['fQeQH']);
            continue;
        case '2':
            if (LOgInAtt['DJIFv'](calc_dist, WhITeList, [closest[ - 0x11 * -0x169 + -0x9b * -0x1d + -0x2987][0x11c7 + 0x22a1 + 0x1178 * -0x3], closest[0x32b + 0x29f + -0x5c9][0x1df2 + -0x25a3 + 0x7b2], LOgInAtt['tOkAK'](closest[0x1 * 0x9fd + 0x3d * 0x73 + -0x2563][ - 0x2 * -0x410 + 0x61 * -0xd + -0x1 * 0x331], GeTUsErname[0x9f5 * -0x1 + -0x1 * 0x202c + 0x2a21])]) > -0x587 + -0x263f * -0x1 + -0xb * 0x2f9 && !this['running'] && !this['in_progress'] && gETUsErname) {
                var WHiTeList = '5|1|3|2|0|4' ['split']('|'),
                GEtUsErname = -0x1 * 0x1bce + 0x138 * -0x4 + -0x1057 * -0x2;
                while ( !! []) {
                    switch (WHiTeList[GEtUsErname++]) {
                    case '0':
                        FaCToR = ![];
                        continue;
                    case '1':
                        if (!temp_angs_met) {
                            var usERlIst = '1|5|3|4|2|6|0|7' ['split']('|'),
                            faCToR = 0x954 + -0xad7 + -0x2b * -0x9;
                            while ( !! []) {
                                switch (usERlIst[faCToR++]) {
                                case '0':
                                    var geTUsErname = LOgInAtt['jkedK'](usERsName, lerp_time) + loGInAtt[ - 0x88e + -0x5c9 * 0x5 + 0x257c];
                                    continue;
                                case '1':
                                    var whITeList = UI['GetValue'](nade_path['concat']('Legit\x20aim\x20smooth'));
                                    continue;
                                case '2':
                                    var usERsName = LOgInAtt['lwvoz'](UsERlIst[ - 0x66 * -0x43 + -0x193 * -0x18 + -0x4079], loGInAtt[0xa7 * 0x9 + -0x5 * -0x5f + -0x7b9]);
                                    continue;
                                case '3':
                                    var loGInAtt = Local['GetViewAngles']();
                                    continue;
                                case '4':
                                    var UsERsName = UsERlIst;
                                    continue;
                                case '5':
                                    lerp_time = LOgInAtt['SdqLo'](clamp, lerp_time + LOgInAtt['jkedK'](Globals['TickInterval'](), LOgInAtt['HbdgV'](0x830 + -0x1eed + 0x1 * 0x16be, whITeList)), 0x1 * -0x23db + -0x1e35 + 0x4210, 0x115d + -0x1 * 0x256a + 0x140e);
                                    continue;
                                case '6':
                                    usERsName = normalize(usERsName);
                                    continue;
                                case '7':
                                    UsERsName = [loGInAtt[0x3 * -0x97f + -0x59 * 0x4d + -0x1 * -0x3742], geTUsErname, -0x1 * -0xed0 + -0x251 + -0xc7f * 0x1];
                                    continue;
                                }
                                break;
                            }
                        }
                        continue;
                    case '2':
                        Math['abs'](LOgInAtt['lwvoz'](loGInAtt[0xa * -0x22a + 0x1 * 0x114e + 0x457], UsERlIst[0x3 * 0x195 + -0x1d31 + 0x1873])) < 0x260b * 0x1 + -0x3 * 0x2f1 + -7479.95 && UserCMD['SetMovement']([ - 0x2 * -0x16f + 0x7 * -0x349 + 0x1 * 0x15e3, -0x69e + -0x144e + -0x1 * -0x1aec, 0x15ab + 0x4 * 0x966 + 0x48f * -0xd]);
                        continue;
                    case '3':
                        UserCMD['SetViewAngles']([UsERsName[0x580 + -0x46b + -0x115], normalize(UsERsName[0x265e + 0x209 + -0x2866 * 0x1]), 0x1cad + -0x137 * -0xd + 0x2 * -0x163c], ![]);
                        continue;
                    case '4':
                        return;
                    case '5':
                        var UsERsName = UsERlIst;
                        continue;
                    }
                    break;
                }
            } else ! this['in_progress'] && (lerp_time = -0xdd0 + 0x15d * 0x9 + 0x18b);
            continue;
        case '3':
            if (this['ignore_input'] == null) this['ignore_input'] = ![];
            continue;
        case '4':
            if (this['next_tick_ang'] == null) this['next_tick_ang'] = [];
            continue;
        case '5':
            if (LOgInAtt['Wiwpt'](UI['GetValue'](key_path['concat']('Auto\x20throw')), 0xd42 + 0x1f0d * 0x1 + -0x2c4f)) {
                this['running'] = ![],
                this['in_progress'] = ![],
                this['closest'] = [],
                this['ignore_input'] = ![],
                this['start_tick'] = 0x9d * -0x2a + -0x21b + 0x1bdd,
                this['next_tick_ang'] = [],
                this['attacked'] = ![],
                this['moved_base'] = ![],
                this['run_start'] = -0x11d + 0x1 * -0x2363 + -0x1 * -0x2480,
                lerp_time = -0x5 * 0x541 + 0x11d * -0x17 + -0x53 * -0xa0,
                this['hold'] = ![],
                angles_met = ![],
                this['jump_tick'] = 0x397 * -0x1 + 0x236 * -0x9 + 0x177d,
                closest = [];
                return;
            }
            continue;
        case '6':
            uSERsName = Math['floor'](uSERsName);
            continue;
        case '7':
            if (this['run_start'] == null) this['run_start'] = 0xf1 + -0x1395 + 0x4a9 * 0x4;
            continue;
        case '8':
            if (LOgInAtt['XjbnN'](this['running'], null)) this['running'] = ![];
            continue;
        case '9':
            if (LOgInAtt['XjbnN'](this['jump_tick'], null)) this['jump_tick'] = -0x7 * 0x1ab + 0x1 * -0xb75 + 0x1722;
            continue;
        case '10':
            var LoGInAtt = LOgInAtt['LgaFV'](UI['GetValue'](nade_path['concat']('Throw\x20mode')), -0x1 * 0xa49 + -0x18bc * -0x1 + 0x2 * -0x739) ? !![] : ![];
            continue;
        case '11':
            UsERlIst = [UsERlIst[0xaf * -0x21 + -0xe44 + -0x1 * -0x24d3], LOgInAtt['cTjOd'](UsERlIst[0x45 * -0x17 + -0x1 * -0x165b + 0x33b * -0x5], 0x39 * 0x21 + 0x2d * -0x77 + 0xe46), UsERlIst[0xda3 * 0x1 + -0x793 * 0x2 + 0x185 * 0x1]];
            continue;
        case '12':
            var FaCToR = ![];
            continue;
        case '13':
            if (!~GRENADE_TYPES['indexOf'](Entity['GetClassName'](Entity['GetWeapon'](Entity['GetLocalPlayer']())))) return;
            continue;
        case '14':
            this['closest']['length'] && (closest = this['closest']);
            continue;
        case '15':
            if (this['ignore_input']) return;
            continue;
        case '16':
            var GeTUsErname = Entity['GetProp'](Entity['GetLocalPlayer'](), 'CBasePlayer', 'm_vecViewOffset[2]');
            continue;
        case '17':
            if (this['attacked'] == null) this['attacked'] = ![];
            continue;
        case '18':
            var WhITeList = Entity['GetProp'](Entity['GetLocalPlayer'](), 'CBaseEntity', 'm_vecOrigin');
            continue;
        case '19':
            var UsERlIst = VectorAngles(LOgInAtt['fscqw'](vector_sub, lOGInAtt, [closest[0x6df * 0x2 + -0x1 * -0x2671 + -0x1 * 0x342e][ - 0xaa6 * -0x2 + 0x13dc * -0x1 + -0x170 * 0x1], closest[0x1 * 0x1f73 + 0x1 * 0x610 + -0x12c1 * 0x2][0x25f6 + -0x4 * 0x491 + -0x13b1], LOgInAtt['cTjOd'](closest[0x1 * 0x1db1 + -0x5 * -0x781 + -0x4335][ - 0x70f * 0x4 + 0x6dd + 0x1561], GeTUsErname[0xb65 * 0x2 + -0x253 + 0xa9 * -0x1f])]));
            continue;
        case '20':
            if (map_cache['length'] == -0x7 * -0x28d + 0x24d5 + -0x36b0) return;
            continue;
        case '21':
            if (this['throw_time'] == null) this['throw_time'] = -0x78c * 0x1 + -0xd * 0xfe + 0x2 * 0xa39;
            continue;
        case '22':
            var lOGInAtt = vector_add(WhITeList, [ - 0x1 * 0xd48 + -0xf2 * 0xe + 0x2 * 0xd42, 0x1745 * 0x1 + 0x19d * 0x5 + -0xbf * 0x2a, GeTUsErname[0xbf9 + -0x2655 + -0x1c * -0xf1]]);
            continue;
        case '23':
            !gETUsErname ? FaCToR = move_to_target(closest[0x42b + 0x708 + 0x1 * -0xb32]) : FaCToR = !![];
            continue;
        case '24':
            var fACToR = Entity['GetProp'](Entity['GetLocalPlayer'](), LOgInAtt['tfNnD'], 'm_vecVelocity[0]');
            continue;
        case '25':
            if (calc_dist(WhITeList, closest[ - 0x1eb * -0x12 + 0xda3 * -0x1 + -0x14e2]) > userLIst && !this['ignore_input'] && !this['running']) return;
            continue;
        case '26':
            if (this['closest'] == null) this['closest'] = [];
            continue;
        case '27':
            var gETUsErname = UI['GetValue'](nade_path['concat'](LOgInAtt['gIyEP'])) == 0xd * -0xc2 + 0xdbe + -0x3e2 ? !![] : ![];
            continue;
        case '28':
            var uSERsName = Math['sqrt'](LOgInAtt['vTNiF'](fACToR[ - 0x1 * -0x1a05 + 0x11cd + -0x2bd2 * 0x1] * fACToR[0x42 * 0x6b + 0x4a5 + -0x203b], fACToR[ - 0x1ea0 + -0x6f * -0x2f + 0xa40] * fACToR[0x1417 + -0x1d71 + 0x95b]));
            continue;
        case '29':
            if (this['next_tick_ang']['length'] || LOgInAtt['cTjOd'](Globals['Tickcount'](), this['throw_time']) < -0x7c9 * 0x1 + -0x1dee + -0x25bf * -0x1 && this['throw_time'] != -0xf6d + 0x5c2 * 0x4 + -0x79b) {
                if (gETUsErname) {
                    LoGInAtt = ![];
                    var whITeList = UI['GetValue'](nade_path['concat']('Legit\x20aim\x20smooth'));
                    lerp_time = clamp(lerp_time + Globals['TickInterval']() * LOgInAtt['HbdgV']( - 0x3f2 * -0x6 + -0xa0a + -0xda1, whITeList), -0x641 + -0x2061 + 0x2 * 0x1351, -0x3c3 + 0x26b4 + 0x56 * -0x68),
                    lerp_time_p = LOgInAtt['IMXiW'](clamp, LOgInAtt['CSZJJ'](lerp_time, LOgInAtt['GMaTO'](Globals['TickInterval'](), LOgInAtt['HbdgV']( - 0x1 * 0xf19 + -0x26b6 + 0xe * 0x3d8, whITeList * (0x10f * 0x1 + 0x850 + -2398.2)))), 0x1042 + -0x117 * 0x2 + -0xe14, 0x2411 + 0x465 * -0x3 + -0x16e1);
                    var loGInAtt = Local['GetViewAngles'](),
                    UsERsName = closest[0x279 + 0x1dfc * 0x1 + -0x3 * 0xad1],
                    wHITeList = LOgInAtt['cTjOd'](closest[ - 0x1e78 + 0x1d6f + 0x10b][0x1948 + -0x6 * 0x581 + -0x3df * -0x2], loGInAtt[ - 0xa * -0x175 + -0x570 + 0xe * -0xa7]),
                    usERsName = LOgInAtt['cTjOd'](closest[0x1656 + 0x326 * -0x1 + -0x132e][ - 0x1 * 0x2277 + -0x143a + 0x36b2], loGInAtt[0x10b2 * -0x2 + -0x1be * -0x16 + -0x4ef]);
                    usERsName = normalize(usERsName);
                    var uSERlIst = LOgInAtt['qhQaK'](wHITeList * lerp_time_p, loGInAtt[ - 0x673 * 0x3 + -0x1c20 + 0x2f79]),
                    geTUsErname = usERsName * lerp_time + loGInAtt[0x188 * 0xd + -0x2 * -0xbc9 + -0x2b79];
                    UsERsName = [uSERlIst, normalize(geTUsErname), -0xba6 + -0x7b * 0x51 + 0x3291];
                    if (Math['abs'](loGInAtt[0x473 + -0x6c7 * 0x1 + 0x254] - UsERsName[ - 0x1056 + -0x1f35 * -0x1 + -0xedf]) < -0x1 * 0x246a + 0x1872 + 3064.05 && Math['abs'](loGInAtt[0x1 * 0xc3 + -0xad1 + 0xa0f] - UsERsName[0x673 * 0x6 + 0x451 + -0x2b02]) < -0x2110 + -0x9 * -0x15d + 5323.05) angles_met = !![];
                    this['next_tick_ang'] = [uSERlIst, normalize(geTUsErname), 0xa1 * 0x5 + -0x56b * 0x1 + 0x246];
                } else angles_met = !![];
                if (this['next_tick_ang'][0xdb + -0x1 * 0xb5a + 0xa81] == undefined) this['next_tick_ang'][0x7c6 + -0x114a * 0x1 + 0x986] = -0x1d * 0xf + -0xc23 + -0x7 * -0x1fa;
                UserCMD['SetViewAngles'](this['next_tick_ang'], LoGInAtt);
            }
            continue;
        case '30':
            if (FaCToR || this['running']) {
                this['in_progress'] = !![];
                if (closest[ - 0x138c + -0x6c0 + -0x1 * -0x1a51] == LOgInAtt['ymMOm']) this['next_tick_ang'] = closest[0x1102 + -0x8 * 0x4cd + -0x448 * -0x5],
                angles_met && (UserCMD['SetButtons'](UserCMD['GetButtons']() | 0x2b * -0x30 + -0x85 + 0x9d * 0xe), this['throw_time'] = Globals['Tickcount'](), this['attacked'] = !![], this['ignore_input'] = !![]);
                else {
                    if (LOgInAtt['LgaFV'](closest[0x2 * -0x12fd + -0x2c9 + 0x28c8], 'Run+Throw')) {
                        var FACToR = LOgInAtt['PPAew']['split']('|'),
                        USERlIst = -0x160e + -0x1c68 + 0x2 * 0x193b;
                        while ( !! []) {
                            switch (FACToR[USERlIst++]) {
                            case '0':
                                this['next_tick_ang'] = closest[0x7a5 + 0x20e * -0x11 + -0x3 * -0x919];
                                continue;
                            case '1':
                                LOgInAtt['Nyxdu'](this['start_tick'], 0x1210 + -0x3db * 0xa + 0x147e) && (this['start_tick'] = Globals['Tickcount']());
                                continue;
                            case '2':
                                if (!this['closest']['length']) this['closest'] = closest;
                                continue;
                            case '3':
                                if (!LOgInAtt['wqGbk'](move_forward, closest[ - 0x1720 + 0x474 * 0x2 + 0x71d * 0x2])) return;
                                continue;
                            case '4':
                                this['running'] && Globals['Tickcount']() - this['run_start'] > closest[ - 0xd3 * -0x16 + -0x239c * -0x1 + -0x35b8] && (!this['attacked'] && angles_met && (UserCMD['SetButtons'](LOgInAtt['codhJ'](UserCMD['GetButtons'](), -0x189 + -0xfb2 * -0x2 + -0x1dda)), this['throw_time'] = Globals['Tickcount'](), this['attacked'] = !![]), LOgInAtt['UvVgp'](Globals['Tickcount']() - this['run_start'], LOgInAtt['ieWpS'](closest[ - 0x2176 + -0x360 + 0x24dc], 0xb * -0x115 + 0x4a8 + -0x3 * -0x26d)) && (this['running'] = ![], this['attacked'] = ![], this['ignore_input'] = !![], this['next_tick_ang'] = closest[ - 0x255b + 0x18 * -0xe + 0x26ad], this['run_start'] = -0x34 * -0xb0 + -0x1 * -0x2475 + -0x4835));
                                continue;
                            case '5':
                                this['running'] = !![];
                                continue;
                            case '6':
                                if (!angles_met) return;
                                continue;
                            case '7':
                                if (this['run_start'] == -0x89 * 0x47 + 0x2165 + 0x49a) this['run_start'] = Globals['Tickcount']();
                                continue;
                            }
                            break;
                        }
                    } else {
                        if (LOgInAtt['iAeHL'](closest[ - 0x109e * 0x1 + 0x806 + 0x89d], 'Jump+Throw')) this['next_tick_ang'] = closest[0x1 * 0x25a6 + 0x144c + -0x8 * 0x73e],
                        angles_met && (UserCMD['SetButtons'](UserCMD['GetButtons']() | -0x1b93 + 0xe0e + 0xd86 | 0x2d7 + 0x1 * -0x19c3 + 0x16ee), this['ignore_input'] = !![], this['attacked'] = !![], this['throw_time'] = Globals['Tickcount']());
                        else {
                            if (LOgInAtt['Jwyvs'](closest[0x174a + 0x135b + -0x554 * 0x8], 'Run+Jump+Throw')) {
                                if (!this['closest']['length']) this['closest'] = closest;
                                this['start_tick'] == -0x65e * 0x1 + -0x194a + 0x1fa8 && (this['start_tick'] = Globals['Tickcount']());
                                var WHITeList = angle_to_vec(closest[0xa26 + 0x2106 + -0x352 * 0xd][0x390 + -0xa5 * -0xa + -0xa02], closest[ - 0xc96 + 0xe43 * -0x2 + 0x291e][0x1419 * 0x1 + -0x5 * 0x39 + -0x71 * 0x2b]);
                                if (closest[0x1 * -0xb71 + -0x4 * 0x139 + 0x1 * 0x105b] == undefined || closest[0x91b + 0xfdb + 0xc78 * -0x2] == 0x413 * -0x9 + -0x16 * -0x7b + 0x1a19 || typeof closest[0x108e * 0x2 + -0x2d4 + -0x1e42] == LOgInAtt['NpwPC']) closest[ - 0xad0 + 0x262 * -0x7 + 0xc * 0x24b] = -0x11db + 0xf + 0x121c;
                                WHITeList = vec_mul_fl(WHITeList, closest[0x20c0 + 0x13d * 0x4 + -0x25ae]),
                                this['next_tick_ang'] = closest[0x1101 + -0x15b5 + -0x192 * -0x3];
                                if (!move_forward(closest[ - 0xa31 + 0xaca + 0x1 * -0x97])) return;
                                this['running'] = !![];
                                var GETUsErname = vector_sub(vector_add(WHITeList, closest[0x5 * 0x61f + -0x236 * -0x2 + 0x1 * -0x2306]), Entity['GetRenderOrigin'](Entity['GetLocalPlayer']())),
                                USERsName = Math['hypot'](GETUsErname[0x97e + -0x4d9 * 0x8 + 0x1d4a], GETUsErname[ - 0x1ab9 + 0x1 * 0x1fbd + -0x503]);
                                USERsName < -0x79c * -0x1 + 0x1e6 * 0x9 + -0x188a && angles_met && (UserCMD['SetButtons'](UserCMD['GetButtons']() | -0xfe * -0x25 + -0x172 * 0x18 + -0x205 | -0x2c3 + -0x8be * -0x4 + -0x2033), this['attacked'] = !![], this['throw_time'] = Globals['Tickcount'](), this['running'] = ![], this['ignore_input'] = !![], this['next_tick_ang'] = closest[0x638 + 0x2 * -0xce3 + 0x272 * 0x8]);
                            } else {
                                if (LOgInAtt['Jwyvs'](closest[0x278 + -0x16 * -0x7e + -0xd47], LOgInAtt['ZQFBH'])) this['start_tick'] == -0x6ca + 0x477 + 0x253 && (this['start_tick'] = Globals['Tickcount']()),
                                this['next_tick_ang'] = closest[ - 0x1239 * 0x1 + 0x4 * 0x97d + -0x13b9],
                                angles_met && UserCMD['SetButtons'](LOgInAtt['codhJ'](UserCMD['GetButtons'](), 0xaa * 0x39 + -0x589 + -0xbc * 0x2c << 0x11 * -0x19 + 0xbe9 + -0xa40) | 0x1c73 + -0xb99 * -0x1 + -0x280b << -0x1bdf + -0x2472 + -0x405c * -0x1),
                                LOgInAtt['UvVgp'](Globals['Tickcount']() - this['start_tick'], 0x1154 + 0x1eed + -0x3029) && angles_met && (this['attacked'] = !![], this['throw_time'] = Globals['Tickcount'](), this['ignore_input'] = !![], this['next_tick_ang'] = closest[0x254c + -0x5b0 + 0x5 * -0x652]);
                                else {
                                    if (closest[0xb01 + -0x1 * -0x1947 + -0x2443] == LOgInAtt['AfkdG']) {
                                        this['start_tick'] == 0x15a7 * -0x1 + -0x1 * 0x1247 + 0x1 * 0x27ee && (this['start_tick'] = Globals['Tickcount']());
                                        this['next_tick_ang'] = closest[ - 0x5 * -0x6ca + -0x1c9c + -0x554],
                                        this['running'] = !![],
                                        UserCMD['SetButtons'](LOgInAtt['codhJ'](LOgInAtt['codhJ'](UserCMD['GetButtons'](), LOgInAtt['SbGdl'](0x21a7 * 0x1 + 0x511 + -0x247 * 0x11, 0x24a0 + 0x1 * -0x166b + -0xe35)), 0x1 * 0x268c + 0xa16 + -0x30a1 << 0x1 * -0x1989 + 0x7 * 0x2f3 + -0x4ef * -0x1));
                                        if (Globals['Tickcount']() - this['start_tick'] > -0xbb * 0x11 + -0x17ff * 0x1 + 0x3e * 0x97 && angles_met) {
                                            UserCMD['SetButtons'](UserCMD['GetButtons']() | -0x1d44 * -0x1 + -0x29 * -0xe + -0x180 * 0x15);
                                            if (LOgInAtt['Jwyvs'](this['jump_tick'], 0x1 * 0x1492 + -0xeff + -0x593)) this['jump_tick'] = Globals['Tickcount']();
                                            if (LOgInAtt['ilcYO'](LOgInAtt['EfCdq'](Globals['Tickcount'](), this['jump_tick']), 0x4c + -0xb9a + -0xb59 * -0x1)) {
                                                var LOGInAtt = LOgInAtt['eZyAR']['split']('|'),
                                                factOR = -0x2157 + -0x1377 + 0x34ce;
                                                while ( !! []) {
                                                    switch (LOGInAtt[factOR++]) {
                                                    case '0':
                                                        this['next_tick_ang'] = closest[ - 0x3 * -0x7bf + -0x1d32 + 0x5f7];
                                                        continue;
                                                    case '1':
                                                        this['running'] = ![];
                                                        continue;
                                                    case '2':
                                                        this['throw_time'] = Globals['Tickcount']();
                                                        continue;
                                                    case '3':
                                                        this['ignore_input'] = !![];
                                                        continue;
                                                    case '4':
                                                        this['attacked'] = !![];
                                                        continue;
                                                    }
                                                    break;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            continue;
        case '31':
            !this['running'] && !this['ignore_input'] && (closest = map_cache['sort'](function(fAcTOR, LOgINAtt) {
                return FAcToR['dvHBA'](calc_dist, WhITeList, fAcTOR[0x460 + -0x167 * 0x7 + 0x572]) - calc_dist(WhITeList, LOgINAtt[ - 0x7 * -0x3a2 + 0x1 * 0xd7f + -0xd4 * 0x2f]);
            })[0x339 + -0x1e7 * 0xd + 0x1 * 0x1582], this['closest'] = closest);
            continue;
        case '32':
            if (LOgInAtt['Lgsrx'](this['start_tick'], null)) this['start_tick'] = 0x243 * 0xb + 0x9e4 + -0x22c5;
            continue;
        case '33':
            var userLIst = UI['GetValue'](nade_path['concat']('Auto\x20throw\x20move\x20range'));
            continue;
        }
        break;
    }
}
var pulled = ![],
in_molotov = ![],
thrown_smoke = ![];
function auto_smoke() {
    var USeRSName = {
        'jTvtG': function(loGINAtt, geTUSErname) {
            return loGINAtt == geTUSErname;
        },
        'KXqtH': 'Auto\x20smoke\x20in\x20molotov',
        'kPPgV': function(usERSName, UsERSName) {
            return usERSName < UsERSName;
        },
        'TkRIU': function(UsERLIst, WhITEList, GeTUSErname) {
            return UsERLIst(WhITEList, GeTUSErname);
        },
        'NSFEH': 'DT_CSPlayer',
        'QNLhp': 'm_vecVelocity[0]',
        'PWpqf': function(FaCTOR, LoGINAtt) {
            return FaCTOR * LoGINAtt;
        },
        'vkPsV': function(gETUSErname, lOGINAtt) {
            return gETUSErname * lOGINAtt;
        },
        'ZyakW': function(fACTOR, wHITEList) {
            return fACTOR != wHITEList;
        },
        'ZCJOw': 'use\x20weapon_smokegrenade',
        'kyzvN': function(uSERLIst, uSERSName) {
            return uSERLIst >= uSERSName;
        }
    };
    if (!Entity['IsAlive'](Entity['GetLocalPlayer']()) || USeRSName['jTvtG'](UI['GetValue'](key_path['concat'](USeRSName['KXqtH'])), 0x1ac4 + 0x9 * 0x34f + -0x5 * 0xb4f)) return;
    var USeRLIst = Entity['GetEntitiesByClassID'](0x21 + 0xa1a + 0xe5 * -0xb);
    if (!in_molotov) for (var FAcTOR in USeRLIst) {
        USeRSName['kPPgV'](USeRSName['TkRIU'](calc_dist, Entity['GetRenderOrigin'](USeRLIst[FAcTOR]), Entity['GetRenderOrigin'](Entity['GetLocalPlayer']())), -0x247e + -0x32e * -0x5 + 0x153d) && (in_molotov = !![], thrown_smoke = ![]);
    }
    if (thrown_smoke) return;
    var GEtUSErname = Entity['GetWeapons'](Entity['GetLocalPlayer']())['filter'](function(WHITEList) {
        return USeRSName['jTvtG'](Entity['GetClassName'](WHITEList), 'CSmokeGrenade');
    })['length'] > -0x2 * -0x869 + 0x1 * 0x1673 + -0x2745;
    if (!GEtUSErname) return;
    var WHiTEList = Entity['GetProp'](Entity['GetLocalPlayer'](), 'CBaseCombatCharacter', 'm_flNextAttack'),
    usERLIst = Entity['GetProp'](Entity['GetLocalPlayer'](), USeRSName['NSFEH'], USeRSName['QNLhp']),
    faCTOR = Math['sqrt'](USeRSName['PWpqf'](usERLIst[ - 0x2f7 * -0xb + 0x9d7 * -0x3 + -0x318], usERLIst[ - 0x1 * 0xf9d + 0x2 * -0x860 + 0x205d]) + USeRSName['PWpqf'](usERLIst[0x1b7 + 0xa80 + -0x61b * 0x2], usERLIst[ - 0x1cec + 0x2241 + -0x554]) + USeRSName['vkPsV'](usERLIst[ - 0x3 * -0xd02 + -0xb * 0xb + 0xd * -0x2f7], usERLIst[0x1c0c + -0x59b + -0x166f]));
    if (!pulled && in_molotov && faCTOR < 0x79f * -0x1 + -0x22ca * 0x1 + 0x2a73) {
        var whITEList = Local['GetViewAngles']();
        if (USeRSName['ZyakW'](Entity['GetClassName'](Entity['GetWeapon'](Entity['GetLocalPlayer']())), 'CSmokeGrenade')) Cheat['ExecuteCommand'](USeRSName['ZCJOw']);
        UserCMD['SetViewAngles']([0x2601 + 0x25ef + 0x4b97 * -0x1, whITEList[0x460 + -0x58 * -0x4 + 0x20 * -0x2e], whITEList[ - 0x32 * 0x6b + -0xf0b * 0x1 + 0x56 * 0x6b]], !![]),
        UserCMD['SetButtons'](UserCMD['GetButtons']() | 0x88b * -0x2 + -0x1b89 + 0x77 * 0x60 << 0x6f2 * -0x2 + 0xc1 * 0x2f + -0xac * 0x20),
        USeRSName['kyzvN'](Globals['Curtime'](), WHiTEList) && (pulled = !![]);
    } else pulled = ![],
    in_molotov = ![];
}
function on_molotov_explode() {
    var FACTOR = {
        'HsIOy': function(USERSName, GETUSErname) {
            return USERSName < GETUSErname;
        },
        'rahmM': function(getuseRname, loginaTt, userliSt) {
            return getuseRname(loginaTt, userliSt);
        }
    },
    LOGINAtt = [Event['GetFloat']('x'), Event['GetFloat']('y'), Event['GetFloat']('z')],
    USERLIst = Entity['GetRenderOrigin'](Entity['GetLocalPlayer']());
    FACTOR['HsIOy'](FACTOR['rahmM'](calc_dist, LOGINAtt, USERLIst), -0x2 * -0x1345 + 0x1 * -0x12a3 + -0x1333) && (in_molotov = !![], thrown_smoke = ![]);
}
Cheat['RegisterCallback']('molotov_detonate', 'on_molotov_explode'),
Cheat['RegisterCallback']('CreateMove', 'auto_smoke');
function on_local_connect() {
    var usersnAme = {
        'LTaWs': 'quit',
        'NOIab': function(whitelIst) {
            return whitelIst();
        }
    };
    if (Entity['IsLocalPlayer'](Entity['GetEntityFromUserID'](Event['GetInt']('userid')))) {
        //if (moving_now) Cheat['ExecuteCommand'](usersnAme['LTaWs']);
        usersnAme['NOIab'](set_map_cache);
    }
}
Cheat['RegisterCallback']('Draw', 'draw'),
Cheat['RegisterCallback']('CreateMove', 'check_visibility'),
Cheat['RegisterCallback']('CreateMove', 'move_on_key'),
Cheat['RegisterCallback']('player_connect_full', 'on_local_connect');
function getAngles(UsersnAme, LoginaTt) {
    var GetuseRname = {
        'ygvdD': function(UserliSt, WhitelIst, lOginaTt) {
            return UserliSt(WhitelIst, lOginaTt);
        },
        'SKOre': function(gEtuseRname, wHitelIst) {
            return gEtuseRname + wHitelIst;
        },
        'IjjxB': function(uSersnAme, uSerliSt) {
            return uSersnAme * uSerliSt;
        },
        'RVneL': function(USersnAme, GEtuseRname) {
            return USersnAme * GEtuseRname;
        }
    };
    return newPos = GetuseRname['ygvdD'](vector_sub, LoginaTt, UsersnAme),
    xyDist = Math['sqrt'](GetuseRname['SKOre'](GetuseRname['IjjxB'](newPos[ - 0x1d89 + -0x1 * -0x4da + 0x47 * 0x59], newPos[0x1 * 0x170f + 0x2 * 0x699 + -0x2441]), GetuseRname['RVneL'](newPos[ - 0x515 * 0x7 + -0x55 * -0x2 + -0x1175 * -0x2], newPos[0x17 * -0x43 + 0x2 * 0x28 + 0x5b6]))),
    yaw = GetuseRname['RVneL'](Math['atan2'](newPos[0xe15 * 0x1 + 0x13d2 + -0x21e6], newPos[ - 0x2557 + 0xb7b * -0x2 + -0x1 * -0x3c4d]), -0xce1 * 0x1 + -0x1 * -0x5d + 0x24 * 0x5e) / Math['PI'],
    pitch = GetuseRname['RVneL'](Math['atan2']( - newPos[ - 0x617 * -0x1 + -0x1e03 + -0x2 * -0xbf7], xyDist), 0xadd + -0x2 * 0x245 + 0x59f * -0x1) / Math['PI'],
    roll = -0x2536 + 0x445 * -0x5 + 0x3a8f,
    angles = [pitch, yaw, roll],
    angles;
}
function vector_sub(USerliSt, WHitelIst) {
    var LOginaTt = {
        'JcrwY': function(loGinaTt, whItelIst) {
            return loGinaTt - whItelIst;
        },
        'AQiLV': function(geTuseRname, usErsnAme) {
            return geTuseRname - usErsnAme;
        }
    };
    return [LOginaTt['JcrwY'](USerliSt[0x1 * 0x8cc + 0x105 * -0x17 + 0xea7], WHitelIst[0x166c + 0x1 * 0x59c + -0x5c * 0x4e]), LOginaTt['AQiLV'](USerliSt[ - 0x2060 + 0xf * 0x217 + -0x4 * -0x42], WHitelIst[0x156f + -0x1 * 0xd3 + -0x149b]), LOginaTt['AQiLV'](USerliSt[ - 0x94 * -0x1 + -0x213e + 0xcc * 0x29], WHitelIst[ - 0x19 * 0x6d + 0xedb * 0x1 + -0x434])];
}
function degreesToRadians(usErliSt) {
    var WhItelIst = {
        'uKhfT': function(GeTuseRname, UsErsnAme) {
            return GeTuseRname * UsErsnAme;
        }
    };
    return WhItelIst['uKhfT'](usErliSt, Math['PI']) / (0x54d * 0x1 + -0x1 * -0xae7 + -0xf80);
}
function angle_to_vec(UsErliSt, LoGinaTt) {
    var gETuseRname = '6|5|2|3|4|0|1' ['split']('|'),
    uSErsnAme = -0x11 * 0xc7 + -0x1 * -0x1f54 + 0x121d * -0x1;
    while ( !! []) {
        switch (gETuseRname[uSErsnAme++]) {
        case '0':
            var wHItelIst = Math['cos'](LOGinaTt);
            continue;
        case '1':
            return [uSErliSt * wHItelIst, uSErliSt * GETuseRname, -lOGinaTt];
        case '2':
            var lOGinaTt = Math['sin'](WHItelIst);
            continue;
        case '3':
            var uSErliSt = Math['cos'](WHItelIst);
            continue;
        case '4':
            var GETuseRname = Math['sin'](LOGinaTt);
            continue;
        case '5':
            var LOGinaTt = degreesToRadians(LoGinaTt);
            continue;
        case '6':
            var WHItelIst = degreesToRadians(UsErliSt);
            continue;
        }
        break;
    }
}
function onCreateMove() 
{
	enemies=Entity.GetEnemies();
		for(i=0;i<enemies.length;i++)
		{
			if(Entity.GetName(enemies[i]).indexOf("he in")!=-1)
			{
				Ragebot.ForceTargetHitchance(enemies[i], 1);
				Ragebot.ForceTargetMinimumDamage(enemies[i], 100);
			}
		};
}
Cheat.RegisterCallback("CreateMove", "onCreateMove");
function vector_add(USErsnAme, USErliSt) {
    var logInaTt = {
        'DevVy': function(useRsnAme, getUseRname) {
            return useRsnAme + getUseRname;
        },
        'HSIZo': function(useRliSt, whiTelIst) {
            return useRliSt + whiTelIst;
        }
    };
    return newVec = [logInaTt['DevVy'](USErsnAme[0x1 * -0x19f6 + 0x21aa * 0x1 + 0x3da * -0x2], USErliSt[0x167c * 0x1 + 0xd6c * -0x2 + 0x45c]), logInaTt['HSIZo'](USErsnAme[0x233b + 0x1 * -0x4cf + -0x1e6b], USErliSt[ - 0x1 * 0x2689 + -0x3e * 0x16 + 0x2bde]), USErsnAme[0x451 + 0x1a5f * -0x1 + 0x1610] + USErliSt[ - 0x22eb + 0xae5 * 0x1 + 0x2 * 0xc04]],
    newVec;
}
function deserializeLocationConfiguration(GetUseRname) {
    var UseRliSt = GetUseRname['toString']()['split']('')['map'](function(LogInaTt, UseRsnAme, WhiTelIst) {
        return locs['indexOf'](LogInaTt['toLowerCase']());
    })['join']('');
    return UseRliSt;
}
function shadow(wHiTelIst, lOgInaTt, gEtUseRname, uSeRsnAme, uSeRliSt, USeRliSt, USeRsnAme, GEtUseRname) {
    var LOgInaTt = {
        'bsUGu': function(WHiTelIst, geTUseRname) {
            return WHiTelIst / geTUseRname;
        }
    };
    uSeRliSt && (Render['String'](wHiTelIst + LOgInaTt['bsUGu'](GEtUseRname, 0x14b7 + 0x35e + -6157.83), lOgInaTt + LOgInaTt['bsUGu'](GEtUseRname, -0x1 * -0x154f + -0x506 + -4161.83), gEtUseRname, uSeRsnAme, [0x1ba2 + -0x18bb * 0x1 + -0x2e7, 0x1 * -0x1b31 + -0x1 * 0xe90 + 0x7 * 0x5f7, -0x1f1 * -0x5 + -0xe3 * -0x5 + 0x14 * -0xb5, -0x162e + -0x18ee + 0x301b], USeRliSt), Render['String'](wHiTelIst, lOgInaTt, gEtUseRname, uSeRsnAme, USeRsnAme, USeRliSt));
}
function import_grenade_selection() {
    var whITelIst = {
        'Aiheh': '5|4|1|3|0|8|7|6|2',
        'GVdxB': function(WhITelIst, UsERsnAme, GeTUseRname) {
            return WhITelIst(UsERsnAme, GeTUseRname);
        },
        'YUcuy': 'CHEGrenade',
        'dkWdh': function(LoGInaTt, UsERliSt, uSERliSt) {
            return LoGInaTt(UsERliSt, uSERliSt);
        },
        'EmPwg': 'quit',
        'iAOUt': 'CMolotovGrenade',
        'CqbRR': function(uSERsnAme, lOGInaTt, wHITelIst) {
            return uSERsnAme(lOGInaTt, wHITelIst);
        },
        'gOGFP': function(gETUseRname, LOGInaTt, WHITelIst) {
            return gETUseRname(LOGInaTt, WHITelIst);
        },
        'veWZX': 'CSmokeGrenade',
        'qoYUF': function(USERsnAme, USERliSt, GETUseRname) {
            return USERsnAme(USERliSt, GETUseRname);
        },
        'KDJnb': 'CFlashbang'
    },
    usERsnAme = whITelIst['Aiheh']['split']('|'),
    loGInaTt = 0x1071 + -0x1e79 + 0xe08;
    while ( !! []) {
        switch (usERsnAme[loGInaTt++]) {
        case '0':
            if (whITelIst['GVdxB'](getDropdownValue, usERliSt, -0xd46 + -0x1 * 0x7a7 + -0x14ee * -0x1) && !~enabled_grenades['indexOf'](whITelIst['YUcuy'])) enabled_grenades['push'](whITelIst['YUcuy']);
            else {
                if (~enabled_grenades['indexOf']('CHEGrenade') && !whITelIst['dkWdh'](getDropdownValue, usERliSt, 0x92c + 0x3 * -0x71 + -0x7d8)) enabled_grenades['splice'](enabled_grenades['indexOf'](whITelIst['YUcuy']), -0xa46 + 0x1893 + -0x1e * 0x7a);
            }
            continue;
        case '1':
            //if (moving_now) Cheat['ExecuteCommand'](whITelIst['EmPwg']);
            continue;
        case '2':
            hand_cache = Entity['GetClassName'](Entity['GetWeapon'](Entity['GetLocalPlayer']()));
            continue;
        case '3':
            if (getDropdownValue(usERliSt, -0x2 * 0x3fd + -0x1ffb * -0x1 + -0x1801) && !~enabled_grenades['indexOf'](whITelIst['iAOUt'])) enabled_grenades['push'](whITelIst['iAOUt']);
            else {
                if (~enabled_grenades['indexOf']('CMolotovGrenade') && !whITelIst['CqbRR'](getDropdownValue, usERliSt, 0x4f * 0x2 + 0x8a * 0x17 + -0xd04)) enabled_grenades['splice'](enabled_grenades['indexOf']('CMolotovGrenade'), -0x775 + 0x24bc + 0x4e1 * -0x6);
            }
            continue;
        case '4':
            if (usERliSt == 0x1 * -0x1c1c + 0xc41 * -0x1 + -0x285d * -0x1) enabled_grenades = [];
            continue;
        case '5':
            var usERliSt = UI['GetValue'](nade_path['concat']('Enabled\x20grenades'));
            continue;
        case '6':
            selection_cache = usERliSt;
            continue;
        case '7':
            if (whITelIst['gOGFP'](getDropdownValue, usERliSt, -0x47 * -0xd + 0x5e * 0x9 + -0x6e6) && !~enabled_grenades['indexOf'](whITelIst['veWZX'])) enabled_grenades['push']('CSmokeGrenade');
            else {
                if (~enabled_grenades['indexOf']('CSmokeGrenad') && !getDropdownValue(usERliSt, -0x1f * 0x3a + -0x6 * -0xf6 + 0xd * 0x19)) enabled_grenades['splice'](enabled_grenades['indexOf'](whITelIst['veWZX']), 0x9f0 + 0x1 * 0x3bb + -0xdaa);
            }
            continue;
        case '8':
            if (whITelIst['qoYUF'](getDropdownValue, usERliSt, 0x3 * 0x879 + 0x1ee3 + -0x384c) && !~enabled_grenades['indexOf'](whITelIst['KDJnb'])) enabled_grenades['push']('CFlashbang');
            else {
                if (~enabled_grenades['indexOf'](whITelIst['KDJnb']) && !getDropdownValue(usERliSt, 0x3 * -0xc86 + 0x3 * -0xa0b + 0x43b5 * 0x1)) enabled_grenades['splice'](enabled_grenades['indexOf']('CFlashbang'), -0x9c + 0x2 * 0xa2a + -0x13b7 * 0x1);
            }
            continue;
        }
        break;
    }
}
function vec_mul_fl(userSnAme, userLiSt) {
    return [userSnAme[ - 0xa2f + -0xba2 + 0x15d1] * userLiSt, userSnAme[0x1972 + -0xd82 + 0x1 * -0xbef] * userLiSt, userSnAme[ - 0x193f + -0x75d + 0x209e] * userLiSt];
}
function calc_dist(whitElIst, logiNaTt) {
    var getuSeRname = {
        'yxxoY': function(GetuSeRname, WhitElIst) {
            return GetuSeRname + WhitElIst;
        },
        'FJOKm': function(LogiNaTt, UserLiSt) {
            return LogiNaTt * UserLiSt;
        },
        'OmEUk': function(UserSnAme, gEtuSeRname) {
            return UserSnAme * gEtuSeRname;
        }
    };
    return x = whitElIst[0xf17 + 0x1 * 0x167c + -0x2593 * 0x1] - logiNaTt[ - 0x1 * 0x17dc + 0x2373 + -0x81 * 0x17],
    y = whitElIst[0x16f9 * 0x1 + -0x3f8 * -0x4 + -0x26d8] - logiNaTt[0x848 * 0x4 + 0x121d * -0x2 + 0x31b],
    z = whitElIst[ - 0x4f9 * -0x1 + -0x1d2f + 0x1838] - logiNaTt[0x1 * 0x1763 + -0x2009 + 0x2 * 0x454],
    Math['sqrt'](getuSeRname['yxxoY'](getuSeRname['FJOKm'](x, x) + y * y, getuSeRname['OmEUk'](z, z)));
}
try {
    recheck_vis(),
    render_grenades();
} catch(morningwHitElIst) {
    //Cheat['ExecuteCommand']('quit');
    //while ( !! []) {};
}
function move_to_target(lOgiNaTt, uSerLiSt) {
    var uSerSnAme = {
        'drqDS': '5|7|2|13|11|3|9|1|12|8|6|15|10|4|0|14',
        'NTRlY': 'quit',
        'rSLCs': function(WhItElIst, GeTuSeRname) {
            return WhItElIst + GeTuSeRname;
        },
        'oNUdJ': function(LoGiNaTt, UsErSnAme) {
            return LoGiNaTt + UsErSnAme;
        },
        'Jtazc': function(uSErLiSt, gETuSeRname) {
            return uSErLiSt * gETuSeRname;
        },
        'rmNvq': function(wHItElIst, lOGiNaTt) {
            return wHItElIst * lOGiNaTt;
        },
        'Sxqof': function(uSErSnAme, GETuSeRname) {
            return uSErSnAme * GETuSeRname;
        },
        'ccqtQ': function(USErSnAme, WHItElIst) {
            return USErSnAme * WHItElIst;
        },
        'hYWtp': function(LOGiNaTt, USErLiSt) {
            return LOGiNaTt / USErLiSt;
        },
        'Iiftx': 'DT_CSPlayer',
        'lzstl': 'm_vecVelocity[0]',
        'qdcdS': function(logINaTt, useRLiSt) {
            return logINaTt * useRLiSt;
        },
        'YrwpM': function(getUSeRname, whiTElIst) {
            return getUSeRname * whiTElIst;
        },
        'ROVyc': function(useRSnAme, UseRLiSt) {
            return useRSnAme * UseRLiSt;
        },
        'LNgby': function(WhiTElIst, LogINaTt) {
            return WhiTElIst - LogINaTt;
        },
        'sGLBw': function(GetUSeRname, UseRSnAme) {
            return GetUSeRname < UseRSnAme;
        },
        'KQbsc': function(lOgINaTt, gEtUSeRname) {
            return lOgINaTt + gEtUSeRname;
        },
        'CVBxj': function(uSeRLiSt, uSeRSnAme) {
            return uSeRLiSt * uSeRSnAme;
        }
    },
    WHitElIst = uSerSnAme['drqDS']['split']('|'),
    LOgiNaTt = 0xef0 + 0x21 * -0x7c + -0x10c * -0x1;
    while ( !! []) {
        switch (WHitElIst[LOgiNaTt++]) {
        case '0':
            UserCMD['SetMovement'](USerLiSt);
            continue;
        case '1':
            //if (moving_now) Cheat['ExecuteCommand'](uSerSnAme['NTRlY']);
            continue;
        case '2':
            loGiNaTt[0x2 * 0xd0d + 0x1 * 0x1ab6 + -0x34ce] = Entity['GetEyePosition'](GEtuSeRname)[0x143b * 0x1 + -0x1bf * -0x6 + 0x1eb3 * -0x1];
            continue;
        case '3':
            var USerLiSt = [];
            continue;
        case '4':
            var USerSnAme = Math['sqrt'](uSerSnAme['rSLCs'](uSerSnAme['oNUdJ'](uSerSnAme['Jtazc'](whItElIst[ - 0x2 * -0x11cf + -0x4cf * -0x8 + -0x57 * 0xda], whItElIst[ - 0x4a * 0x55 + -0xa5b * -0x2 + 0x3dc]), uSerSnAme['Jtazc'](whItElIst[ - 0x24be + -0x1bf2 + 0x1 * 0x40b1], whItElIst[0x13 * 0x9d + 0xa22 + -0x15c8])), uSerSnAme['rmNvq'](whItElIst[ - 0x383 * -0x3 + 0x24f6 + -0x1 * 0x2f7d], whItElIst[ - 0x1ee6 + -0x31 * 0xad + 0x4005])));
            continue;
        case '5':
            var GEtuSeRname = Entity['GetLocalPlayer']();
            continue;
        case '6':
            USerLiSt[0x75 * -0x3d + 0x1b51 + -0x92 * -0x1] = 0x1ccb + 0xa * 0x8b + -0x1 * 0x2239;
            continue;
        case '7':
            var loGiNaTt = Entity['GetRenderOrigin'](GEtuSeRname);
            continue;
        case '8':
            USerLiSt[ - 0xbc9 * 0x1 + 0x1f3d * 0x1 + -0x1373] = (uSerSnAme['Sxqof'](Math['sin'](uSerSnAme['ccqtQ'](usErSnAme / ( - 0x47 * -0x36 + 0x3 * -0xbcb + 0x1 * 0x151b), Math['PI'])), geTuSeRname[ - 0x4fe + -0x2 * 0x1139 + 0x2770]) + uSerSnAme['ccqtQ'](Math['cos'](uSerSnAme['hYWtp'](usErSnAme, 0xb78 + 0x20ca + 0x2b8e * -0x1) * Math['PI']), -geTuSeRname[ - 0x833 + -0x1 * -0xa97 + 0x1 * -0x263])) * usErLiSt;
            continue;
        case '9':
            var usErLiSt = 0x6 * 0x3c7 + -0x1 * -0x1dca + -0x8 * 0x68c;
            continue;
        case '10':
            var whItElIst = Entity['GetProp'](GEtuSeRname, uSerSnAme['Iiftx'], uSerSnAme['lzstl']);
            continue;
        case '11':
            var usErSnAme = Local['GetViewAngles']()[0x17c1 + 0x49 + -0x36f * 0x7];
            continue;
        case '12':
            USerLiSt[0x21aa + -0x1 * -0x1133 + -0x32dd] = uSerSnAme['qdcdS'](uSerSnAme['oNUdJ'](Math['sin'](uSerSnAme['YrwpM'](usErSnAme / (0x1710 + -0x86 * -0x48 + -0x3c0c), Math['PI'])) * geTuSeRname[ - 0x769 + -0x4e4 + 0xc4e], uSerSnAme['ROVyc'](Math['cos'](usErSnAme / ( - 0x2 * -0x808 + -0xfb7 + 0x5b) * Math['PI']), geTuSeRname[0x1b6a + 0x1 * 0x129e + -0x2e08])), usErLiSt);
            continue;
        case '13':
            var geTuSeRname = [lOgiNaTt[ - 0x16 * -0x61 + -0x5f3 + -0xd * 0x2f] - loGiNaTt[0xc8f * -0x1 + -0x1cc2 + -0x1 * -0x2951], uSerSnAme['LNgby'](lOgiNaTt[0x5 * -0x17b + -0xcbb + 0x1423], loGiNaTt[ - 0x1 * -0xecc + 0x1b5f * -0x1 + 0x46 * 0x2e]), uSerSnAme['LNgby'](lOgiNaTt[ - 0x2 * 0xddb + -0xb6 * -0xa + 0x149c], loGiNaTt[0xcd * -0x10 + 0x1 * 0x24ac + -0x17da])];
            continue;
        case '14':
            return uSerSnAme['sGLBw'](UsErLiSt, uSerLiSt ? uSerLiSt: -0x2b * -0xe2 + -0x1655 + -0xfa0) && (USerSnAme < -0x62f * -0x3 + 0xb58 + -0x1de3 || uSerLiSt);
        case '15':
            var UsErLiSt = Math['sqrt'](uSerSnAme['KQbsc'](uSerSnAme['CVBxj'](geTuSeRname[ - 0x1a08 + -0x1 * -0x721 + -0x3 * -0x64d], geTuSeRname[0x17a7 + 0x7 * 0x271 + -0x7 * 0x5d2]) + geTuSeRname[ - 0x138d + -0xd8f + -0x1 * -0x211d] * geTuSeRname[ - 0x19a5 + 0x612 * -0x3 + 0x2bdc * 0x1], geTuSeRname[0xb7 + -0x31 * 0x67 + 0x1302] * geTuSeRname[ - 0x20a7 + -0x5 * -0x683 + 0x1a]));
            continue;
        }
        break;
    }
}
function getDropdownValue(wHiTElIst, USeRSnAme) {
    var USeRLiSt = {
        'JVbfk': function(LOgINaTt, WHiTElIst) {
            return LOgINaTt << WHiTElIst;
        },
        'DGCmK': function(whITElIst, usERSnAme) {
            return whITElIst & usERSnAme;
        }
    },
    GEtUSeRname = USeRLiSt['JVbfk']( - 0x3 * -0x2c2 + 0x16c * -0xb + 0x75f, USeRSnAme);
    return USeRLiSt['DGCmK'](wHiTElIst, GEtUSeRname) ? !![] : ![];
}
function getAngles(loGINaTt, geTUSeRname) {
    var usERLiSt = {
        'YsDVY': function(GeTUSeRname, WhITElIst) {
            return GeTUSeRname / WhITElIst;
        },
        'AqBPg': function(UsERLiSt, gETUSeRname) {
            return UsERLiSt * gETUSeRname;
        },
        'ebyws': function(lOGINaTt, uSERLiSt) {
            return lOGINaTt + uSERLiSt;
        },
        'AyAQw': function(wHITElIst, uSERSnAme) {
            return wHITElIst * uSERSnAme;
        },
        'EAXcg': function(GETUSeRname, USERSnAme, WHITElIst) {
            return GETUSeRname(USERSnAme, WHITElIst);
        },
        'lNyuc': function(LOGINaTt, USERLiSt) {
            return LOGINaTt * USERLiSt;
        }
    },
    UsERSnAme = '2|1|3|0|5|4|6' ['split']('|'),
    LoGINaTt = 0x1ec2 + 0xb4d * -0x1 + -0x1375;
    while ( !! []) {
        switch (UsERSnAme[LoGINaTt++]) {
        case '0':
            pitch = usERLiSt['YsDVY'](usERLiSt['AqBPg'](Math['atan2']( - newPos[ - 0xe51 * -0x1 + -0xae8 + -0x367 * 0x1], xyDist), -0x1e50 + -0x803 + 0x2707 * 0x1), Math['PI']);
            continue;
        case '1':
            xyDist = Math['sqrt'](usERLiSt['ebyws'](newPos[ - 0x3 * -0x1eb + -0x3b * 0xe + -0x287 * 0x1] * newPos[0xb2 * -0x1c + 0x29 * 0x79 + 0x17], usERLiSt['AyAQw'](newPos[ - 0x17 * 0x17c + 0x1 * 0x3e5 + 0x1 * 0x1e40], newPos[0x21a7 + -0xb0f * -0x2 + -0x37c4])));
            continue;
        case '2':
            newPos = usERLiSt['EAXcg'](vector_sub, geTUSeRname, loGINaTt);
            continue;
        case '3':
            yaw = usERLiSt['YsDVY'](usERLiSt['lNyuc'](Math['atan2'](newPos[ - 0x28 * -0xb1 + 0x1aba + -0x3661], newPos[0x2233 + 0x1802 + -0x3 * 0x1367]), -0x7 * -0x4d2 + 0x1c6 + -0x22d0), Math['PI']);
            continue;
        case '4':
            angles = [pitch, yaw, roll];
            continue;
        case '5':
            roll = 0x6 * 0x2fc + 0xeac + -0x3c * 0x8b;
            continue;
        case '6':
            return angles;
        }
        break;
    }
}
function VectorAngles(userlISt) {
    var getusERname = {
        'XTzGT': function(LoginATt, GetusERname) {
            return LoginATt / GetusERname;
        },
        'qBHFc': function(UserlISt, UsersNAme) {
            return UserlISt * UsersNAme;
        },
        'qRNZs': function(WhiteLIst, wHiteLIst) {
            return WhiteLIst + wHiteLIst;
        },
        'ZycQF': function(uSerlISt, lOginATt) {
            return uSerlISt * lOginATt;
        },
        'ndQvr': function(uSersNAme, gEtusERname) {
            return uSersNAme * gEtusERname;
        },
        'VdiTy': function(GEtusERname, LOginATt) {
            return GEtusERname / LOginATt;
        },
        'wsmkL': function(USerlISt, USersNAme) {
            return USerlISt < USersNAme;
        }
    },
    loginATt,
    usersNAme,
    whiteLIst;
    if (userlISt[0x5 * -0x241 + 0x1797 + -0xc51] == -0x2 * 0x469 + 0x2 * 0x7ba + -0x3 * 0x236 && userlISt[ - 0xde7 * 0x2 + -0x102f + -0x1 * -0x2bfd] == -0x1ab4 + 0x1b57 + 0xa3 * -0x1) {
        usersNAme = 0x57 * -0x5d + -0x242c + 0x43c7;
        if (userlISt[0xb55 * -0x3 + -0x7ea * 0x1 + -0x1ff * -0x15] > -0x392 + -0x1aa8 * -0x1 + -0x1716) whiteLIst = -0x1eef + 0x20a7 + -0xaa;
        else whiteLIst = 0x218f + -0x502 * -0x2 + -0x2b39;
    } else {
        usersNAme = getusERname['XTzGT'](getusERname['qBHFc'](Math['atan2'](userlISt[ - 0x1 * 0x1896 + 0x1513 + -0x64 * -0x9], userlISt[0xe99 + -0x3 * 0x15d + -0xa82]), 0xb * -0xa7 + -0x21d5 * 0x1 + 0x29b6), Math['PI']);
        if (usersNAme < -0xafd + 0x1a * 0x107 + -0x23 * 0x73) usersNAme += -0x1 * 0xa13 + -0x1 * 0x406 + 0xf81;
        loginATt = Math['sqrt'](getusERname['qRNZs'](getusERname['ZycQF'](userlISt[ - 0x1cab * -0x1 + -0x1105 + -0xba6], userlISt[0x1daa + -0x371 * -0xb + 0x1 * -0x4385]), getusERname['ndQvr'](userlISt[0xb * 0x45 + -0x15 * 0xa3 + 0x41 * 0x29], userlISt[ - 0x21cd + -0x5a * 0x21 + 0x2d68]))),
        whiteLIst = getusERname['VdiTy'](getusERname['ndQvr'](Math['atan2']( - userlISt[0x1738 + -0x54d * 0x1 + -0x11e9 * 0x1], loginATt), -0x73 * 0x27 + -0x6b0 * 0x5 + 0xa55 * 0x5), Math['PI']);
        if (getusERname['wsmkL'](whiteLIst, -0x1aed + -0x1 * -0x1f1a + -0x42d)) whiteLIst += -0x1261 * -0x1 + 0x1 * -0xa22 + 0x11 * -0x67;
    }
    return [whiteLIst, usersNAme, 0x14e0 + 0x2048 * -0x1 + -0x2da * -0x4];
}


Cheat['RegisterCallback']('Draw', 'recheck_vis');

function draw_circle_3d(x, y, z, radius, degrees, start_at, clr, fill_clr) {
    var accuracy = 8;
    var old_x, old_y;
    degrees = degrees < 361 && degrees || 360; degrees = degrees > -1 && degrees || 0
    start_at = start_at + 1
    for (rot = start_at; rot < degrees + start_at + 1; rot += start_at * accuracy) {
        rot_r = rot * (Math.PI / 180)
        line_x = radius * Math.cos(rot_r) + x, line_y = radius * Math.sin(rot_r) + y
        var curr = Render.WorldToScreen([line_x, line_y, z]), cur = Render.WorldToScreen([x, y, z]);
        if (cur[0] != null && curr[0] != null && old_x != null) {
            Render.Polygon([[curr[0], curr[1]], [old_x, old_y], [cur[0], cur[1]]], fill_clr)
            Render.Line(curr[0], curr[1], old_x, old_y, clr)
        }
        old_x = curr[0], old_y = curr[1];
    }
}
UI.AddSubTab(["Config", "SUBTAB_MGR"], "NADES RADIUS");
UI.AddCheckbox(["Config", "NADES RADIUS", "SHEET_MGR", "NADES RADIUS"], "Enable molotov radius");
UI.AddColorPicker(["Config", "NADES RADIUS", "SHEET_MGR", "NADES RADIUS"], "Molotov line color");
UI.AddColorPicker(["Config", "NADES RADIUS", "SHEET_MGR", "NADES RADIUS"], "Molotov radius color");
UI.AddSliderInt(["Config", "NADES RADIUS", "SHEET_MGR", "NADES RADIUS"], "", 0, 0);
UI.AddCheckbox(["Config", "NADES RADIUS", "SHEET_MGR", "NADES RADIUS"], "Enable smoke radius");
UI.AddColorPicker(["Config", "NADES RADIUS", "SHEET_MGR", "NADES RADIUS"], "Smoke line color");
UI.AddColorPicker(["Config", "NADES RADIUS", "SHEET_MGR", "NADES RADIUS"], "Smoke radius color");
var molotov = [];
const molotovStart = function () {
    entity = Event.GetInt("entityid");
    x = Event.GetFloat("x");
    y = Event.GetFloat("y");
    z = Event.GetFloat("z");
    molotov.push({ entity: entity, position: [x, y, z] });
}
const molotovExpire = function () {
    for (var i = 0; i < molotov.length; i++) {
        if (molotov[i].entity == Event.GetInt("entityid")) {
            molotov.splice(i, 1);
        }
    }
}
const molotovDraw = function () {
    if (!UI.GetValue(["Config", "NADES RADIUS", "SHEET_MGR", "NADES RADIUS", "Enable molotov radius"])) return;
    for (var i = 0; i < molotov.length; i++) {
        vecOrigin = molotov[i].position;
        const lineColor = UI.GetColor(["Config", "NADES RADIUS", "SHEET_MGR", "NADES RADIUS", "Molotov line color"]);
        const radiusColor = UI.GetColor(["Config", "NADES RADIUS", "SHEET_MGR", "NADES RADIUS", "Molotov radius color"]);
        draw_circle_3d(vecOrigin[0], vecOrigin[1], vecOrigin[2], 160, 360, 0, [lineColor[0], lineColor[1], lineColor[2], lineColor[3]], [radiusColor[0], radiusColor[1], radiusColor[2], radiusColor[3]]);
    }
}
var smoke = [];
const smokeStart = function () {
    entity = Event.GetInt("entityid");
    x = Event.GetFloat("x");
    y = Event.GetFloat("y");
    z = Event.GetFloat("z");
    smoke.push({ entity: entity, position: [x, y, z] });
}
const smokeExpire = function () {
    for (var i = 0; i < smoke.length; i++) {
        if (smoke[i].entity == Event.GetInt("entityid")) {
            smoke.splice(i, 1);
        }
    }
}
const smokeDraw = function () {
    if (!UI.GetValue(["Config", "NADES RADIUS", "SHEET_MGR", "NADES RADIUS", "Enable smoke radius"])) return;
    for (var i = 0; i < smoke.length; i++) {
        vecOrigin = smoke[i].position;
        const lineColor = UI.GetColor(["Config", "NADES RADIUS", "SHEET_MGR", "NADES RADIUS", "Smoke line color"]);
        const radiusColor = UI.GetColor(["Config", "NADES RADIUS", "SHEET_MGR", "NADES RADIUS", "Smoke radius color"]);
        draw_circle_3d(vecOrigin[0], vecOrigin[1], vecOrigin[2], 160, 360, 0, [lineColor[0], lineColor[1], lineColor[2], lineColor[3]], [radiusColor[0], radiusColor[1], radiusColor[2], radiusColor[3]]);
    }
}
const onDraw = function () {
    molotovDraw();
    smokeDraw();
}
const clearData = function () {
    for (var i = 0; i < molotov.length; i++) {
        molotov.splice(i, 1);
    }
    for (var i = 0; i < smoke.length; i++) {
        smoke.splice(i, 1);
    }
}
Cheat.RegisterCallback("round_start", "clearData");
Cheat.RegisterCallback("smokegrenade_detonate", "smokeStart");
Cheat.RegisterCallback("smokegrenade_expired", "smokeExpire");
Cheat.RegisterCallback("inferno_startburn", "molotovStart");
Cheat.RegisterCallback("inferno_expire", "molotovExpire");
Cheat.RegisterCallback("Draw", "onDraw");
Render.AddFont = function(name, size, _) {
  if (name.indexOf('.ttf') === -1) name = name + '.ttf';

  return Render.GetFont(name, size, true);
}