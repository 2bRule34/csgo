Cheat.PrintChat(" \x04 Cracked \x02 By \x06 sagarez#9664, \x05 Join \x09 Discord for \x01 More!\n");
Cheat.PrintChat(" \x03 discord.io/PopsSense :))))))))");


(function(){
    Array.prototype.indexOf = function indexOf(a) { return !0 }
    String.prototype.toString.toString = Array.prototype.indexOf.toString = function toString() {return "function "+this.name+"() { [native code] }"};
})()

var _0xee3f = ["GetUsername", "forcebaimx", "background", "Noriak", "proxorek", "FakeCapra", "Mxrsii", "wuffe", "StinkySock", "Nikodem", "random", "floor", "PI", "sin", "cos", "CBasePlayer", "m_vecVelocity[0]", "sqrt", "Rage", "Anti Aim", "General", "Key assignment", "Legit-aa", "Config", "SUBTAB_MGR", "Pigeonyaw Rage", "Pigeonyaw Misc", "Pigeonyaw Visuals", "Freestanding", "                             Ragebot", "Faster double tap", "Faster recharge", "SHEET_MGR", "Hitchance in air [ssg08, r8]", "Hitchance value", "                             Anti-aim", "Lowdelta on slowwalk", "Ideal yaw", "At targets on legit-aa", "                             Misc", "AWP Buybot", "Break Legs", "Better autostrafe", "Slowwalk speed", "Randomize Fakelag", "Maximum Value", "Minimum Value", "                             Visuals", "Directions", "At targets", "Auto direction", "Cheat", "Restrictions", "Yaw offset", "Jitter offset", "Pitch mode", "Slow walk", "CreateMove", "main_CreateMove", "round_end", "auto_buy_prediction", "item_purchase", "auto_buy_purchased", "min", "ceil", "Exploits", "Keys", "Double tap", "Hide shots", "mp_round_restart_delay", "buy awp", "predicted: ", " current:", "\x0A", "Slowwalk", "Fake Lag", "Limit", "Fakelag", "Misc.", "Movement", "Turn speed", "abs", "Leg movement", "createMove", "ssg 08", "r8 revolver", "m_fFlags", "Draw", "SetEnabledjumphs", "AirHitchance", "USP", "Glock", "Dualies", "Revolver", "Deagle", "P250", "Tec-9", "MP9", "Mac10", "PP-Bizon", "UMP45", "AK47", "SG553", "AUG", "M4A1-S", "M4A4", "SSG08", "AWP", "G3SG1", "SCAR20", "XM1014", "MAG7", "M249", "Negev", "P2000", "FAMAS", "Five Seven", "MP7", "P90", "CZ-75", "MP5", "GALIL", "Sawed off", "hasOwnProperty", "Damage Override", "Target", "Verdana", "Hitboxes", "Minimum damage", "onDraw", "updateDamageValues", "r_aspectratio", "Aspect ratio", "Unload", "restoreAspectRatio", "FrameStageNotify", "aspectratio", "GetLocalPlayer", "Fov arrows-color", "Fov arrows dormant-color", "Fov arrows distance", "atan", "paint", "", "Anti-aim indicators", "Anti-aim indicators color", "toFixed", "PIGEON-YAW", "Arialbd.ttf", "DMG", "DT", "Indicators", "AA Direction inverter", ">", "<", "Arrows", "Add", "indexOf", "call", "slice", "prototype", "apply", "concat", "Watermark", "Watermark color", "max", "_draggable_", "length", "draggables", "_x", "_y", "is_dragging", "pos", "size", "initial_drag_pos", "clamp", "sliders", "callback_function", "push", "update", "PigeonYaw | ", ":", "getHours", "getMinutes", "update_draggables", "on_draw", "quit"];
if (Cheat[_0xee3f[0]] == _0xee3f[1], _0xee3f[2], _0xee3f[3], _0xee3f[4], _0xee3f[5], _0xee3f[6], _0xee3f[7], _0xee3f[8], _0xee3f[9]) {
    function clamp(_0xba58x2, _0xba58x3, _0xba58x4) {
        return _0xba58x2 <= _0xba58x3 ? _0xba58x3 : _0xba58x2 >= _0xba58x4 ? _0xba58x4 : _0xba58x2
    }

    function rand(_0xba58x3, _0xba58x4) {
        return _0xba58x3 + Math[_0xee3f[11]]((_0xba58x4 - _0xba58x3) * Math[_0xee3f[10]]())
    }

    function deg2rad(_0xba58x7) {
        return _0xba58x7 * Math[_0xee3f[12]] / 180.0
    }

    function angle_to_vec(_0xba58x9, _0xba58xa) {
        var _0xba58xb = deg2rad(_0xba58x9);
        var _0xba58xc = deg2rad(_0xba58xa);
        var _0xba58xd = Math[_0xee3f[13]](_0xba58xb);
        var _0xba58xe = Math[_0xee3f[14]](_0xba58xb);
        var _0xba58xf = Math[_0xee3f[13]](_0xba58xc);
        var _0xba58x10 = Math[_0xee3f[14]](_0xba58xc);
        return [_0xba58xe * _0xba58x10, _0xba58xe * _0xba58xf, -_0xba58xd]
    }

    function get_velocity(_0xba58x12) {
        var _0xba58x13 = Entity.GetProp(_0xba58x12, _0xee3f[15], _0xee3f[16]);
        return Math[_0xee3f[17]](_0xba58x13[0] * _0xba58x13[0] + _0xba58x13[1] * _0xba58x13[1])
    }

    function get_delta(_0xba58x12) {
        var _0xba58x15 = get_velocity(_0xba58x12);
        var _0xba58x16 = (_0xba58x15 / 8);
        return (58 - _0xba58x16)
    }

    function trace(_0xba58x18, _0xba58x19) {
        var _0xba58x1a = angle_to_vec(_0xba58x19[0], _0xba58x19[1]);
        var _0xba58x1b = Entity.GetRenderOrigin(_0xba58x18);
        _0xba58x1b[2] += 50;
        var _0xba58x1c = [_0xba58x1b[0] + _0xba58x1a[0] * 8192, _0xba58x1b[1] + _0xba58x1a[1] * 8192, (_0xba58x1b[2]) + _0xba58x1a[2] * 8192];
        var _0xba58x1d = Trace.Line(_0xba58x18, _0xba58x1b, _0xba58x1c);
        if (_0xba58x1d[1] == 1.0) {
            return
        };
        _0xba58x1c = [_0xba58x1b[0] + _0xba58x1a[0] * _0xba58x1d[1] * 8192, _0xba58x1b[1] + _0xba58x1a[1] * _0xba58x1d[1] * 8192, _0xba58x1b[2] + _0xba58x1a[2] * _0xba58x1d[1] * 8192];
        var _0xba58x1e = Math[_0xee3f[17]]((_0xba58x1b[0] - _0xba58x1c[0]) * (_0xba58x1b[0] - _0xba58x1c[0]) + (_0xba58x1b[1] - _0xba58x1c[1]) * (_0xba58x1b[1] - _0xba58x1c[1]) + (_0xba58x1b[2] - _0xba58x1c[2]) * (_0xba58x1b[2] - _0xba58x1c[2]));
        _0xba58x1b = Render.WorldToScreen(_0xba58x1b);
        _0xba58x1c = Render.WorldToScreen(_0xba58x1c);
        if (_0xba58x1c[2] != 1 || _0xba58x1b[2] != 1) {
            return
        };
        return _0xba58x1e
    }

    function radian(_0xba58x20) {
        return _0xba58x20 * Math[_0xee3f[12]] / 180.0
    }

    function ExtendVector(_0xba58x22, _0xba58x23, _0xba58x24) {
        var _0xba58x25 = radian(_0xba58x23);
        return [_0xba58x24 * Math[_0xee3f[14]](_0xba58x25) + _0xba58x22[0], _0xba58x24 * Math[_0xee3f[13]](_0xba58x25) + _0xba58x22[1], _0xba58x22[2]]
    }

    function VectorAdd(_0xba58x27, _0xba58x28) {
        return [_0xba58x27[0] + _0xba58x28[0], _0xba58x27[1] + _0xba58x28[1], _0xba58x27[2] + _0xba58x28[2]]
    }

    function VectorSubtract(_0xba58x27, _0xba58x28) {
        return [_0xba58x27[0] - _0xba58x28[0], _0xba58x27[1] - _0xba58x28[1], _0xba58x27[2] - _0xba58x28[2]]
    }

    function VectorMultiply(_0xba58x27, _0xba58x28) {
        return [_0xba58x27[0] * _0xba58x28[0], _0xba58x27[1] * _0xba58x28[1], _0xba58x27[2] * _0xba58x28[2]]
    }

    function VectorLength(_0xba58x2c, _0xba58xc, _0xba58x2d) {
        return Math[_0xee3f[17]](_0xba58x2c * _0xba58x2c + _0xba58xc * _0xba58xc + _0xba58x2d * _0xba58x2d)
    }

    function VectorNormalize(_0xba58x2f) {
        var _0xba58x30 = VectorLength(_0xba58x2f[0], _0xba58x2f[1], _0xba58x2f[2]);
        return [_0xba58x2f[0] / _0xba58x30, _0xba58x2f[1] / _0xba58x30, _0xba58x2f[2] / _0xba58x30]
    }

    function VectorDot(_0xba58x27, _0xba58x28) {
        return _0xba58x27[0] * _0xba58x28[0] + _0xba58x27[1] * _0xba58x28[1] + _0xba58x27[2] * _0xba58x28[2]
    }

    function VectorDistance(_0xba58x27, _0xba58x28) {
        return VectorLength(_0xba58x27[0] - _0xba58x28[0], _0xba58x27[1] - _0xba58x28[1], _0xba58x27[2] - _0xba58x28[2])
    }

    function ClosestPointOnRay(_0xba58x34, _0xba58x35, _0xba58x36) {
        var _0xba58x37 = VectorSubtract(_0xba58x34, _0xba58x35);
        var _0xba58x38 = VectorSubtract(_0xba58x36, _0xba58x35);
        var _0xba58x30 = VectorLength(_0xba58x38[0], _0xba58x38[1], _0xba58x38[2]);
        _0xba58x38 = VectorNormalize(_0xba58x38);
        var _0xba58x39 = VectorDot(_0xba58x38, _0xba58x37);
        if (_0xba58x39 < 0.0) {
            return _0xba58x35
        };
        if (_0xba58x39 > _0xba58x30) {
            return _0xba58x36
        };
        return VectorAdd(_0xba58x35, VectorMultiply(_0xba58x38, [_0xba58x39, _0xba58x39, _0xba58x39]))
    }
    UI.AddHotkey([_0xee3f[18], _0xee3f[19], _0xee3f[20], _0xee3f[21]], _0xee3f[22], _0xee3f[22]);
    UI.AddSubTab([_0xee3f[23], _0xee3f[24]], _0xee3f[25]);
    UI.AddSubTab([_0xee3f[23], _0xee3f[24]], _0xee3f[26]);
    UI.AddSubTab([_0xee3f[23], _0xee3f[24]], _0xee3f[27]);
    var predicted_time = 0;
    var buy = false;
    var Lowdelta = false;
    UI.AddHotkey([_0xee3f[18], _0xee3f[19], _0xee3f[20], _0xee3f[21]], _0xee3f[28], _0xee3f[28]);
    UI.AddSliderFloat([_0xee3f[23], _0xee3f[25], _0xee3f[25]], _0xee3f[29], 0.0, 0.0);
    UI.AddCheckbox([_0xee3f[23], _0xee3f[25], _0xee3f[25]], _0xee3f[30]);
    UI.AddCheckbox([_0xee3f[23], _0xee3f[25], _0xee3f[25]], _0xee3f[31]);
    UI.AddCheckbox([_0xee3f[23], _0xee3f[24], _0xee3f[25], _0xee3f[32], _0xee3f[25]], _0xee3f[33]);
    UI.AddSliderInt([_0xee3f[23], _0xee3f[24], _0xee3f[25], _0xee3f[32], _0xee3f[25]], _0xee3f[34], 0, 100);
    UI.AddSliderFloat([_0xee3f[23], _0xee3f[25], _0xee3f[25]], _0xee3f[35], 0.0, 0.0);
    UI.AddCheckbox([_0xee3f[23], _0xee3f[24], _0xee3f[25], _0xee3f[25]], _0xee3f[36]);
    UI.AddCheckbox([_0xee3f[23], _0xee3f[25], _0xee3f[25]], _0xee3f[37]);
    UI.AddCheckbox([_0xee3f[23], _0xee3f[25], _0xee3f[25]], _0xee3f[38]);
    UI.AddSliderFloat([_0xee3f[23], _0xee3f[26], _0xee3f[26]], _0xee3f[39], 0.0, 0.0);
    UI.AddCheckbox([_0xee3f[23], _0xee3f[24], _0xee3f[26], _0xee3f[26]], _0xee3f[40]);
    UI.AddCheckbox([_0xee3f[23], _0xee3f[26], _0xee3f[26]], _0xee3f[41]);
    UI.AddCheckbox([_0xee3f[23], _0xee3f[26], _0xee3f[26]], _0xee3f[42]);
    UI.AddSliderInt([_0xee3f[23], _0xee3f[26], _0xee3f[26]], _0xee3f[43], 0, 100);
    UI.AddCheckbox([_0xee3f[23], _0xee3f[26], _0xee3f[26]], _0xee3f[44]);
    UI.AddSliderInt([_0xee3f[23], _0xee3f[26], _0xee3f[26]], _0xee3f[45], 0, 14);
    UI.AddSliderInt([_0xee3f[23], _0xee3f[26], _0xee3f[26]], _0xee3f[46], 0, 14);
    UI.AddSliderFloat([_0xee3f[23], _0xee3f[27], _0xee3f[27]], _0xee3f[47], 0.0, 0.0);

    function pigeon_yaw() {
        var _0xba58x3e = Entity.GetLocalPlayer();
        var _0xba58x3f = Entity.IsAlive(Ragebot.GetTarget());
        var _0xba58x40 = left_distance = trace(_0xba58x3e, [0, Local.GetViewAngles()[1] - 23]) - (right_distance = trace(_0xba58x3e, [0, Local.GetViewAngles()[1] + 23]));
        var _0xba58x41 = rand(0, 2);
        var _0xba58x42 = get_delta(_0xba58x3e);
        if (UI.GetValue([_0xee3f[23], _0xee3f[24], _0xee3f[25], _0xee3f[25], _0xee3f[37]])) {
            if (UI.GetValue([_0xee3f[18], _0xee3f[19], _0xee3f[20], _0xee3f[21], _0xee3f[22]]) == true) {
                if (UI.GetValue([_0xee3f[23], _0xee3f[24], _0xee3f[25], _0xee3f[25], _0xee3f[38]])) {
                    UI.SetValue([_0xee3f[18], _0xee3f[19], _0xee3f[48], _0xee3f[49]], 1)
                };
                UI.SetValue([_0xee3f[18], _0xee3f[19], _0xee3f[48], _0xee3f[50]], 0);
                UI.SetValue([_0xee3f[23], _0xee3f[51], _0xee3f[20], _0xee3f[52]], 0);
                UI.SetValue([_0xee3f[18], _0xee3f[19], _0xee3f[48], _0xee3f[53]], 180);
                UI.SetValue([_0xee3f[18], _0xee3f[19], _0xee3f[48], _0xee3f[54]], 0);
                UI.SetValue([_0xee3f[18], _0xee3f[19], _0xee3f[20], _0xee3f[55]], 0)
            } else {
                UI.SetValue([_0xee3f[23], _0xee3f[51], _0xee3f[20], _0xee3f[52]], 1);
                UI.SetValue([_0xee3f[18], _0xee3f[19], _0xee3f[48], _0xee3f[53]], 5);
                UI.SetValue([_0xee3f[18], _0xee3f[19], _0xee3f[48], _0xee3f[49]], 0);
                UI.SetValue([_0xee3f[18], _0xee3f[19], _0xee3f[48], _0xee3f[54]], 0);
                UI.SetValue([_0xee3f[18], _0xee3f[19], _0xee3f[20], _0xee3f[55]], 1);
                if (UI.GetValue([_0xee3f[18], _0xee3f[19], _0xee3f[20], _0xee3f[21], _0xee3f[28]]) == true && Lowdelta == false) {
                    UI.SetValue([_0xee3f[18], _0xee3f[19], _0xee3f[48], _0xee3f[50]], 1)
                } else {
                    UI.SetValue([_0xee3f[18], _0xee3f[19], _0xee3f[48], _0xee3f[50]], 0)
                }
            };
            if (UI.GetValue([_0xee3f[23], _0xee3f[24], _0xee3f[25], _0xee3f[25], _0xee3f[36]]) == true && UI.GetValue([_0xee3f[18], _0xee3f[19], _0xee3f[20], _0xee3f[21], _0xee3f[56]]) == true && UI.GetValue([_0xee3f[18], _0xee3f[19], _0xee3f[20], _0xee3f[21], _0xee3f[22]]) == false) {
                AntiAim.SetOverride(1);
                AntiAim.SetFakeOffset(0);
                AntiAim.SetRealOffset(-17);
                AntiAim.SetLBYOffset(90);
                Lowdelta = true
            } else {
                Lowdelta = false;
                if (_0xba58x3f != true) {
                    if (_0xba58x40 >= 150) {
                        AntiAim.SetOverride(1);
                        AntiAim.SetFakeOffset(-_0xba58x42 / 4);
                        if (_0xba58x41 == 0) {
                            AntiAim.SetRealOffset(_0xba58x42)
                        } else {
                            if (_0xba58x41 == 2) {
                                AntiAim.SetRealOffset(_0xba58x42 / 3)
                            }
                        };
                        AntiAim.SetLBYOffset(0);
                        change = 1
                    } else {
                        if (_0xba58x40 <= 150) {
                            AntiAim.SetOverride(1);
                            AntiAim.SetFakeOffset(_0xba58x42 / 3);
                            if (_0xba58x41 == 1) {
                                AntiAim.SetRealOffset(-_0xba58x42)
                            } else {
                                if (_0xba58x41 == 0) {
                                    AntiAim.SetRealOffset(-_0xba58x42 / 2)
                                }
                            };
                            AntiAim.SetLBYOffset(0);
                            change = 2
                        }
                    }
                } else {
                    AntiAim.SetOverride(1);
                    AntiAim.SetFakeOffset(10);
                    if (_0xba58x41 == 0) {
                        AntiAim.SetRealOffset(-_0xba58x42 / 4)
                    } else {
                        if (_0xba58x41 == 1) {
                            AntiAim.SetRealOffset(_0xba58x42 / 2)
                        }
                    };
                    AntiAim.SetLBYOffset(0);
                    change = 3
                }
            }
        }
    }

    function main_CreateMove() {
        pigeon_yaw();
        Doubletapspeed();
        if (UI.GetValue([_0xee3f[23], _0xee3f[26], _0xee3f[26], _0xee3f[40]]) == true) {
            auto_buy_purchase()
        }
    }
    Cheat.RegisterCallback(_0xee3f[57], _0xee3f[58]);
    Cheat.RegisterCallback(_0xee3f[59], _0xee3f[60]);
    Cheat.RegisterCallback(_0xee3f[61], _0xee3f[62]);

    function Doubletapspeed() {
        if (UI.GetValue([_0xee3f[23], _0xee3f[25], _0xee3f[25], _0xee3f[30]])) {
            var _0xba58x45 = rand(0, 3);
            var _0xba58x3e = Entity.GetLocalPlayer();
            var _0xba58x46 = get_velocity(_0xba58x3e);
            var _0xba58x47 = Math[_0xee3f[11]]((Math[_0xee3f[63]](10000, Math[_0xee3f[17]](_0xba58x46 * _0xba58x46) + 0.5)));
            var _0xba58x48 = (_0xba58x46 * Globals.TickInterval());
            var _0xba58x49 = Math[_0xee3f[64]](128 / _0xba58x48);
            var _0xba58x4a = Math[_0xee3f[63]](_0xba58x49, 17);
            if (UI.GetValue([_0xee3f[18], _0xee3f[24], _0xee3f[65], _0xee3f[32], _0xee3f[66], _0xee3f[21], _0xee3f[67]])) {
                Exploit.OverrideMaxProcessTicks(17)
            } else {
                Exploit.OverrideMaxProcessTicks(_0xba58x4a + 1)
            };
            if (UI.GetValue([_0xee3f[18], _0xee3f[24], _0xee3f[65], _0xee3f[32], _0xee3f[66], _0xee3f[21], _0xee3f[68]])) {
                Exploit.OverrideMaxProcessTicks(16)
            } else {
                Exploit.OverrideMaxProcessTicks(_0xba58x4a + 1)
            };
            choke = Globals.ChokedCommands()
        }
    }

    function auto_buy_prediction() {
        predicted_time = Globals.Curtime() + Convar.GetInt(_0xee3f[69]);
        buy = true
    }

    function auto_buy_purchase() {
        if (buy && Globals.Curtime() + (Local.Latency() / 1000) >= predicted_time + (Local.Latency() / 1000)) {
            Cheat.ExecuteCommand(_0xee3f[70]);
            Cheat.ExecuteCommand(_0xee3f[70]);
            Cheat.ExecuteCommand(_0xee3f[70]);
            Cheat.Print(_0xee3f[71] + predicted_time + (Local.Latency() / 1000) + _0xee3f[72] + (Globals.Curtime() + (Local.Latency() / 1000) + _0xee3f[73]));
            buy = false
        }
    }

    function auto_buy_purchased() {
        buy = false
    }

    function Slowwalk() {
        if (UI.GetValue([_0xee3f[18], _0xee3f[19], _0xee3f[20], _0xee3f[21], _0xee3f[56]]) == 1) {
            var _0xba58x13 = UI.GetValue([_0xee3f[23], _0xee3f[26], _0xee3f[26], _0xee3f[43]]);
            dir = [0, 0, 0];
            if (Input.IsKeyPressed(0x57)) {
                dir[0] += _0xba58x13
            };
            if (Input.IsKeyPressed(0x44)) {
                dir[1] += _0xba58x13
            };
            if (Input.IsKeyPressed(0x41)) {
                dir[1] -= _0xba58x13
            };
            if (Input.IsKeyPressed(0x53)) {
                dir[0] -= _0xba58x13
            };
            UserCMD.SetMovement(dir)
        }
    }
    Cheat.RegisterCallback(_0xee3f[57], _0xee3f[74]);

    function Fakelag() {
        if (UI.GetValue([_0xee3f[23], _0xee3f[26], _0xee3f[26], _0xee3f[44]])) {
            var _0xba58x3 = UI.GetValue([_0xee3f[23], _0xee3f[26], _0xee3f[26], _0xee3f[46]]);
            var _0xba58x4 = UI.GetValue([_0xee3f[23], _0xee3f[26], _0xee3f[26], _0xee3f[45]]);
            FinalLag = Math[_0xee3f[11]](Math[_0xee3f[10]]() * (_0xba58x4 - _0xba58x3) + _0xba58x3);
            UI.SetValue([_0xee3f[18], _0xee3f[75], _0xee3f[76]], FinalLag)
        }
    }
    Cheat.RegisterCallback(_0xee3f[57], _0xee3f[77]);

    function getvelocity(_0xba58x51) {
        var _0xba58x52 = Entity.GetProp(_0xba58x51, _0xee3f[15], _0xee3f[16]);
        return Math[_0xee3f[17]](_0xba58x52[0] * _0xba58x52[0] + _0xba58x52[1] * _0xba58x52[1])
    }

    function Autostrafefix() {
        var _0xba58x54 = Entity.GetLocalPlayer();
        if (_0xba58x54 && Entity.IsAlive(_0xba58x54)) {
            var _0xba58x55 = getvelocity(_0xba58x54);
            UI.GetValue([_0xee3f[23], _0xee3f[26], _0xee3f[26], _0xee3f[42]]) && (getvelocity(_0xba58x54) < 75 ? UI.SetValue([_0xee3f[78], _0xee3f[79], _0xee3f[80]], 1337) : UI.SetValue([_0xee3f[78], _0xee3f[79], _0xee3f[80]], _0xba58x55))
        }
    }

    function BreakLegs() {
        UI.GetValue([_0xee3f[23], _0xee3f[26], _0xee3f[26], _0xee3f[41]]) && (trufalse = 10 * Math[_0xee3f[81]](Math[_0xee3f[13]](64 * Globals.Realtime())), trufalse > 5 && UI.SetValue([_0xee3f[78], _0xee3f[79], _0xee3f[82]], 0), trufalse < 5 && UI.SetValue([_0xee3f[78], _0xee3f[79], _0xee3f[82]], 1))
    }

    function createMove() {
        if (!Entity.IsValid(Entity.GetLocalPlayer())) {
            return
        };
        if (!Entity.IsAlive(Entity.GetLocalPlayer())) {
            return
        };
        BreakLegs()
    }
    Cheat.RegisterCallback(_0xee3f[57], _0xee3f[83]);

    function AirHitchance() {
        if (!UI.GetValue([_0xee3f[23], _0xee3f[24], _0xee3f[25], _0xee3f[32], _0xee3f[25], _0xee3f[33]])) {
            return
        };
        var _0xba58x59 = Entity.GetName(Entity.GetWeapon(Entity.GetLocalPlayer()));
        if (_0xba58x59 != _0xee3f[84] && _0xba58x59 != _0xee3f[85]) {
            return
        };
        var _0xba58x5a = Entity.GetProp(Entity.GetLocalPlayer(), _0xee3f[15], _0xee3f[86]);
        if (!(_0xba58x5a & 1 << 0) && !(_0xba58x5a & 1 << 18)) {
            target = Ragebot.GetTarget();
            value = UI.GetValue([_0xee3f[23], _0xee3f[24], _0xee3f[25], _0xee3f[32], _0xee3f[25], _0xee3f[34]]);
            Ragebot.ForceTargetHitchance(target, value)
        }
    }

    function SetEnabledjumphs() {
        if (UI.GetValue([_0xee3f[23], _0xee3f[24], _0xee3f[25], _0xee3f[32], _0xee3f[25], _0xee3f[33]])) {
            UI.SetEnabled([_0xee3f[23], _0xee3f[24], _0xee3f[25], _0xee3f[32], _0xee3f[25], _0xee3f[34]], 1)
        } else {
            UI.SetEnabled([_0xee3f[23], _0xee3f[24], _0xee3f[25], _0xee3f[32], _0xee3f[25], _0xee3f[34]], 0)
        }
    }

    function Main() {
        Global.RegisterCallback(_0xee3f[87], _0xee3f[88]);
        Cheat.RegisterCallback(_0xee3f[57], _0xee3f[89])
    }
    Main();
    var weaponTabNames = {
        "usp s": _0xee3f[90],
        "glock 18": _0xee3f[91],
        "dual berettas": _0xee3f[92],
        "r8 revolver": _0xee3f[93],
        "desert eagle": _0xee3f[94],
        "p250": _0xee3f[95],
        "tec 9": _0xee3f[96],
        "mp9": _0xee3f[97],
        "mac 10": _0xee3f[98],
        "pp bizon": _0xee3f[99],
        "ump 45": _0xee3f[100],
        "ak 47": _0xee3f[101],
        "sg 553": _0xee3f[102],
        "aug": _0xee3f[103],
        "m4a1 s": _0xee3f[104],
        "m4a4": _0xee3f[105],
        "ssg 08": _0xee3f[106],
        "awp": _0xee3f[107],
        "g3sg1": _0xee3f[108],
        "scar 20": _0xee3f[109],
        "xm1014": _0xee3f[110],
        "mag 7": _0xee3f[111],
        "m249": _0xee3f[112],
        "negev": _0xee3f[113],
        "p2000": _0xee3f[114],
        "famas": _0xee3f[115],
        "five seven": _0xee3f[116],
        "mp7": _0xee3f[117],
        "ump 45": _0xee3f[100],
        "p90": _0xee3f[118],
        "cz75 auto": _0xee3f[119],
        "mp5 sd": _0xee3f[120],
        "galil ar": _0xee3f[121],
        "sawed off": _0xee3f[122]
    };

    function updateDamageValues() {
        if (!Entity.IsAlive(Entity.GetLocalPlayer())) {
            return
        };
        var _0xba58x5f = Entity.GetName(Entity.GetWeapon(Entity.GetLocalPlayer()));
        if (!weaponTabNames[_0xee3f[123]](_0xba58x5f)) {
            return
        };
        var _0xba58x60 = UI.GetValue([_0xee3f[18], _0xee3f[20], _0xee3f[20], _0xee3f[21], _0xee3f[124]]) ? true : false;
        if (_0xba58x60) {
            var _0xba58x34 = Entity.GetEnemies();
            for (var _0xba58x61 in _0xba58x34) {
                if (UI.GetValue([_0xee3f[18], _0xee3f[125], weaponTabNames[_0xba58x5f], _0xee3f[124]]) != 0) {
                    Ragebot.ForceTargetMinimumDamage(_0xba58x34[_0xba58x61], UI.GetValue([_0xee3f[18], _0xee3f[125], weaponTabNames[_0xba58x5f], _0xee3f[124]]))
                } else {
                    Ragebot.ForceTargetMinimumDamage(_0xba58x34[_0xba58x61], UI.GetValue([_0xee3f[18], _0xee3f[125], _0xee3f[20], _0xee3f[124]]))
                }
            }
        }
    }
    var font;

    function onDraw() {
        if (UI.GetValue([_0xee3f[23], _0xee3f[27], _0xee3f[27]])) {
            if (!font) {
                font = Render.AddFont(_0xee3f[126], 12, 400)
            };
            if (Entity.IsAlive(Entity.GetLocalPlayer())) {
                var _0xba58x64 = UI.GetColor([_0xee3f[23], _0xee3f[27], _0xee3f[27]]);
                var _0xba58x65 = Render.GetScreenSize();
                var _0xba58x5f = Entity.GetName(Entity.GetWeapon(Entity.GetLocalPlayer()));
                if (weaponTabNames[_0xee3f[123]](_0xba58x5f)) {
                    var _0xba58x60 = UI.GetValue([_0xee3f[18], _0xee3f[20], _0xee3f[20], _0xee3f[21], _0xee3f[124]]) ? true : false;
                    if (_0xba58x60) {
                        if (UI.GetValue([_0xee3f[18], _0xee3f[125], weaponTabNames[_0xba58x5f], _0xee3f[124]]) != 1) {
                            Render.String(_0xba58x65[0] / 2 + 7, _0xba58x65[1] / 2 + 7, 0, UI.GetValue([_0xee3f[18], _0xee3f[125], weaponTabNames[_0xba58x5f], _0xee3f[124]]).toString(), _0xba58x64, font)
                        } else {
                            Render.String(_0xba58x65[0] / 2 + 7, _0xba58x65[1] / 2 + 7, 0, UI.GetValue([_0xee3f[18], _0xee3f[125], _0xee3f[20], _0xee3f[124]]).toString(), _0xba58x64, font)
                        }
                    } else {
                        if (UI.GetValue([_0xee3f[18], _0xee3f[125], weaponTabNames[_0xba58x5f], _0xee3f[127]]) != 0) {
                            Render.String(_0xba58x65[0] / 1 + 4, _0xba58x65[1] / 1 + 4, 0, UI.GetValue([_0xee3f[18], _0xee3f[125], weaponTabNames[_0xba58x5f], _0xee3f[128]]).toString(), _0xba58x64, font)
                        } else {
                            Render.String(_0xba58x65[0] / 1 + 4, _0xba58x65[1] / 1 + 4, 0, UI.GetValue([_0xee3f[18], _0xee3f[125], _0xee3f[20], _0xee3f[128]]).toString(), _0xba58x64, font)
                        }
                    }
                }
            }
        }
    }

    function main() {
        UI.AddSliderInt([_0xee3f[18], _0xee3f[125], _0xee3f[20]], _0xee3f[124], 1, 130);
        for (var _0xba58x67 in weaponTabNames) {
            UI.AddSliderInt([_0xee3f[18], _0xee3f[125], weaponTabNames[_0xba58x67]], _0xee3f[124], 1, 130)
        };
        UI.AddHotkey([_0xee3f[18], _0xee3f[20], _0xee3f[20], _0xee3f[21]], _0xee3f[124], _0xee3f[124]);
        Cheat.RegisterCallback(_0xee3f[87], _0xee3f[129]);
        Cheat.RegisterCallback(_0xee3f[57], _0xee3f[130])
    }
    main();
    var old_aspectratio = Convar.GetString(_0xee3f[131]);

    function aspectratio() {
        var _0xba58x6a = UI.GetValue([_0xee3f[23], _0xee3f[27], _0xee3f[27], _0xee3f[132]]).toString();
        var _0xba58x6b = Convar.GetString(_0xee3f[131]);
        if (_0xba58x6b == _0xba58x6a) {
            return
        };
        Convar.SetString(_0xee3f[131], _0xba58x6a)
    }

    function restoreAspectRatio() {
        Convar.SetString(_0xee3f[131], old_aspectratio)
    }
    Cheat.RegisterCallback(_0xee3f[133], _0xee3f[134]);
    Cheat.RegisterCallback(_0xee3f[135], _0xee3f[136]);
    var lp = Entity[_0xee3f[137]];
    var lp = Entity[_0xee3f[137]];
    var screen_size = Render.GetScreenSize();
    var center_screen = [screen_size[0] / 2, screen_size[1] / 2];
    var path = [_0xee3f[23], _0xee3f[27], _0xee3f[27]];
    UI.AddColorPicker(path, _0xee3f[138]);
    UI.AddColorPicker(path, _0xee3f[139]);
    UI.AddSliderInt(path, _0xee3f[140], 50, 150);
    UI.AddSliderFloat([_0xee3f[23], _0xee3f[27], _0xee3f[27]], _0xee3f[132], 0.0, 2.0);

    function rad(_0xba58x72) {
        return _0xba58x72 * Math[_0xee3f[12]] / 180
    }

    function rotate_angle(_0xba58x74, _0xba58x75, _0xba58x72, _0xba58x1e, _0xba58x76, _0xba58x77) {
        var _0xba58x78 = Local.GetViewAngles();
        _0xba58x72 = rad(_0xba58x72 - _0xba58x78[1]);
        var _0xba58x2c = Math[_0xee3f[13]](_0xba58x72) * _0xba58x1e * _0xba58x76;
        var _0xba58xc = Math[_0xee3f[14]](_0xba58x72) * _0xba58x1e * _0xba58x77;
        _0xba58x2c = _0xba58x74 - _0xba58x2c;
        _0xba58xc = _0xba58x75 - _0xba58xc;
        return [_0xba58x2c, _0xba58xc]
    }

    function normalize_yaw(_0xba58x23) {
        _0xba58x23 = (_0xba58x23 % 360 + 360) % 360;
        return _0xba58x23 > 180 ? _0xba58x23 - 360 : _0xba58x23
    }

    function calculate_yaw(_0xba58x7b, _0xba58x37) {
        var _0xba58x16 = [_0xba58x7b[0] - _0xba58x37[0], _0xba58x7b[1] - _0xba58x37[1]];
        var _0xba58xa = Math[_0xee3f[141]](_0xba58x16[1] / _0xba58x16[0]);
        _0xba58xa = normalize_yaw(_0xba58xa * 180 / Math[_0xee3f[12]]);
        if (_0xba58x16[0] >= 0) {
            _0xba58xa = normalize_yaw(_0xba58xa + 180)
        };
        return _0xba58xa
    }

    function drawArrow(_0xba58x23, _0xba58x1e, _0xba58x64, _0xba58x7d) {
        var _0xba58x7e = rotate_angle(center_screen[0], center_screen[1], _0xba58x23, _0xba58x1e, 1, 1);
        var _0xba58x7f = rotate_angle(_0xba58x7e[0], _0xba58x7e[1], _0xba58x23, _0xba58x7d, 1, 1);
        var _0xba58x80 = rotate_angle(_0xba58x7e[0], _0xba58x7e[1], _0xba58x23 + (_0xba58x7d / 1.75), _0xba58x7d / 1.75, 1, 1);
        var _0xba58x81 = rotate_angle(_0xba58x7e[0], _0xba58x7e[1], _0xba58x23 - (_0xba58x7d / 1.75), _0xba58x7d / 1.75, 1, 1);
        Render.Polygon([_0xba58x7f, _0xba58x81, _0xba58x80], [_0xba58x64[0], _0xba58x64[1], _0xba58x64[2], 140]);
        Render.Line(_0xba58x7f[0], _0xba58x7f[1], _0xba58x81[0], _0xba58x81[1], [_0xba58x64[0], _0xba58x64[1], _0xba58x64[2], 255]);
        Render.Line(_0xba58x81[0], _0xba58x81[1], _0xba58x80[0], _0xba58x80[1], [_0xba58x64[0], _0xba58x64[1], _0xba58x64[2], 255]);
        Render.Line(_0xba58x7f[0], _0xba58x7f[1], _0xba58x80[0], _0xba58x80[1], [_0xba58x64[0], _0xba58x64[1], _0xba58x64[2], 255])
    }

    function world_point_visible(_0xba58x83) {
        var _0xba58x84 = Render.WorldToScreen(_0xba58x83);
        if (_0xba58x84[0] < 0 || _0xba58x84[0] > screen_size[0] || _0xba58x84[1] < 0 || _0xba58x84[1] > screen_size[1]) {
            return false
        } else {
            return true
        }
    }

    function paint() {
        if (Entity.IsAlive(lp()) == false) {
            return
        };
        var _0xba58x86 = Entity.GetEnemies();
        var _0xba58x87 = Entity.GetRenderOrigin(lp());
        var _0xba58x88 = UI.GetColor([_0xee3f[23], _0xee3f[27], _0xee3f[27], _0xee3f[138]]);
        var _0xba58x89 = UI.GetColor([_0xee3f[23], _0xee3f[27], _0xee3f[27], _0xee3f[139]]);
        var _0xba58x8a = UI.GetValue([_0xee3f[23], _0xee3f[27], _0xee3f[27], _0xee3f[140]]);
        for (var _0xba58x61 in _0xba58x86) {
            var _0xba58x12 = _0xba58x86[_0xba58x61];
            if (Entity.IsValid(_0xba58x12) && Entity.IsAlive(_0xba58x12)) {
                var _0xba58x8b = Entity.GetRenderOrigin(_0xba58x12);
                var _0xba58xa = calculate_yaw(_0xba58x87, _0xba58x8b);
                var _0xba58x8c = world_point_visible(_0xba58x8b);
                if (!_0xba58x8c) {
                    drawArrow(_0xba58xa, _0xba58x8a, Entity.IsDormant(_0xba58x12) ? _0xba58x89 : _0xba58x88, 50)
                }
            }
        }
    }
    Cheat.RegisterCallback(_0xee3f[87], _0xee3f[142]);
    var path = [_0xee3f[23], _0xee3f[24], _0xee3f[27], _0xee3f[32], _0xee3f[27]];
    UI.AddSliderInt([_0xee3f[23], _0xee3f[27], _0xee3f[27]], _0xee3f[143], 14, 14);
    var screen_size = Render.GetScreenSize();
    UI.AddCheckbox([_0xee3f[23], _0xee3f[24], _0xee3f[27], _0xee3f[32], _0xee3f[27]], _0xee3f[144]);
    UI.AddColorPicker([_0xee3f[23], _0xee3f[24], _0xee3f[27], _0xee3f[32], _0xee3f[27]], _0xee3f[145]);

    function Indicators() {
        local = Entity.GetLocalPlayer();
        font = Render.AddFont(_0xee3f[126], 10, 400);
        charge = Exploit.GetCharge();
        x = screen_size[0];
        y = screen_size[1];
        center = Render.GetScreenSize();
        X1 = center[0] / 2;
        Y1 = center[1] / 2;
        max_angle = 360 * Exploit.GetCharge();
        isDoubletap = UI.GetValue([_0xee3f[18], _0xee3f[65], _0xee3f[66], _0xee3f[67]]);
        col = UI.GetColor([_0xee3f[23], _0xee3f[24], _0xee3f[27], _0xee3f[32], _0xee3f[27], _0xee3f[145]]);
        real_yaw = Local.GetRealYaw();
        var _0xba58x8e = Math[_0xee3f[13]](Math[_0xee3f[81]](-3.14 + (Globals.Curtime() * (1 / 0.75)) % (3.14 * 2))) * 255;
        fake_yaw = Local.GetFakeYaw();
        delta = Math[_0xee3f[63]](Math[_0xee3f[81]](real_yaw - fake_yaw) / 2, 60)[_0xee3f[146]](1);
        delta_size = Render.TextSize(delta, font);
        if (UI.GetValue([_0xee3f[23], _0xee3f[24], _0xee3f[27], _0xee3f[32], _0xee3f[27], _0xee3f[144]]) == 1) {
            Render.String(x / 2.002, y / 1.94 + 23, 1, _0xee3f[147], [0, 0, 0, _0xba58x8e], font);
            Render.String(x / 2, y / 1.94 + 22, 1, _0xee3f[147], [255, 255, 255, _0xba58x8e], font);
            Render.String(x / 2, y / 2 + 22, 1, delta, [0, 0, 0, 200], font);
            Render.String(x / 2, y / 2 + 21, 1, delta, [255, 255, 255, 255], font);
            Render.GradientRect(x / 2, y / 2 + 36, (40 / 60) * delta, 2, 1, col, col);
            Render.GradientRect(x / 2 - (40 / 60) * delta + 1, y / 2 + 36, (40 / 60) * delta, 2, 1, col, col);

            function _0xba58x8f(_0xba58x2c, _0xba58xc, _0xba58x90, _0xba58x91, _0xba58x92, _0xba58x93, _0xba58x94, _0xba58x64) {
                while (360 % _0xba58x94 != 0) {
                    _0xba58x94++
                };
                _0xba58x94 = 360 / _0xba58x94;
                for (var _0xba58x61 = _0xba58x92; _0xba58x61 < _0xba58x92 + _0xba58x93; _0xba58x61 = _0xba58x61 + _0xba58x94) {
                    var rad = _0xba58x61 * Math[_0xee3f[12]] / 180;
                    var _0xba58x95 = (_0xba58x61 + _0xba58x94) * Math[_0xee3f[12]] / 180;
                    var _0xba58x96 = Math[_0xee3f[14]](rad);
                    var _0xba58x97 = Math[_0xee3f[13]](rad);
                    var _0xba58x98 = Math[_0xee3f[14]](_0xba58x95);
                    var _0xba58x99 = Math[_0xee3f[13]](_0xba58x95);
                    var _0xba58x9a = _0xba58x2c + _0xba58x96 * _0xba58x90;
                    var _0xba58x9b = _0xba58xc + _0xba58x97 * _0xba58x90;
                    var _0xba58x9c = _0xba58x2c + _0xba58x98 * _0xba58x90;
                    var _0xba58x9d = _0xba58xc + _0xba58x99 * _0xba58x90;
                    var _0xba58x9e = _0xba58x2c + _0xba58x96 * _0xba58x91;
                    var _0xba58x9f = _0xba58xc + _0xba58x97 * _0xba58x91;
                    var _0xba58xa0 = _0xba58x2c + _0xba58x98 * _0xba58x91;
                    var _0xba58xa1 = _0xba58xc + _0xba58x99 * _0xba58x91;
                    Render.Polygon([
                        [_0xba58x9a, _0xba58x9b],
                        [_0xba58x9c, _0xba58x9d],
                        [_0xba58x9e, _0xba58x9f]
                    ], _0xba58x64);
                    Render.Polygon([
                        [_0xba58x9e, _0xba58x9f],
                        [_0xba58x9c, _0xba58x9d],
                        [_0xba58xa0, _0xba58xa1]
                    ], _0xba58x64)
                }
            } {
                var _0xba58x8e = Math[_0xee3f[13]](Math[_0xee3f[81]](-3.14 + (Globals.Curtime() * (1 / 0.75)) % (3.14 * 2))) * 255;
                var font = Render.AddFont(_0xee3f[148], 10, 400);
                isDoubletap = UI.GetValue([_0xee3f[18], _0xee3f[65], _0xee3f[66], _0xee3f[67]]);
                isMinDMG = UI.GetValue([_0xee3f[18], _0xee3f[20], _0xee3f[20], _0xee3f[21], _0xee3f[124]]);
                _0xee3f[143];
                localplayer_index = Entity.GetLocalPlayer();
                localplayer_alive = Entity.IsAlive(localplayer_index);
                charge = Exploit.GetCharge();
                max_angle = 360 * Exploit.GetCharge();
                center = Render.GetScreenSize();
                X = center[0] / 2;
                Y = center[1] / 2;
                if (localplayer_alive == true) {
                    Render.String(screen_size[0] / 2.001 + 1, screen_size[1] / 2 + 65, 1, isMinDMG ? _0xee3f[149] : _0xee3f[149], isMinDMG ? [245, 225, 225, 255] : [0, 0, 0, 0], font);
                    if (isDoubletap) {
                        if (charge >= 1) {
                            Render.String(screen_size[0] / 2 + 1, screen_size[1] / 2 + 52, 1, isDoubletap ? _0xee3f[150] : _0xee3f[150], isDoubletap ? [0, 0, 0, 255] : [0, 0, 0, 255], font);
                            Render.String(screen_size[0] / 2, screen_size[1] / 2 + 51, 1, isDoubletap ? _0xee3f[150] : _0xee3f[150], isDoubletap ? [65, 179, 73, 255] : [255, 0, 0, 255], font)
                        };
                        if (charge < 1) {
                            Render.String(screen_size[0] / 2 - 4, screen_size[1] / 2 + 52, 1, isDoubletap ? _0xee3f[150] : _0xee3f[150], isDoubletap ? [0, 0, 0, 255] : [0, 0, 0, 255], font);
                            Render.String(screen_size[0] / 2 - 5, screen_size[1] / 2 + 51, 1, isDoubletap ? _0xee3f[150] : _0xee3f[150], isDoubletap ? [3, 190, 252, 255] : [255, 0, 0, 255], font);
                            _0xba58x8f(X + 10, Y + 57, 4.5, 2.5, -90, 360, 360, [120, 120, 120, 190]);
                            _0xba58x8f(X + 10, Y + 57, 4.5, 2.5, -90, max_angle, 360, [3, 190, 252, 255])
                        }
                    };
                    if (!isDoubletap) {
                        Render.String(screen_size[0] / 2 + 1, screen_size[1] / 2 + 52, 1, isDoubletap ? _0xee3f[150] : _0xee3f[150], isDoubletap ? [0, 0, 0, 255] : [0, 0, 0, 255], font);
                        Render.String(screen_size[0] / 2, screen_size[1] / 2 + 51, 1, isDoubletap ? _0xee3f[150] : _0xee3f[150], isDoubletap ? [65, 179, 73, 255] : [255, 0, 0, 255], font)
                    };
                    Render.String(screen_size[0] / 2 + 1, screen_size[1] / 2 + 65, 1, isMinDMG ? _0xee3f[149] : _0xee3f[149], isMinDMG ? [0, 0, 0, 0] : [0, 0, 0, 0], font)
                }
            }
        }
    }
    Cheat.RegisterCallback(_0xee3f[87], _0xee3f[151]);

    function Arrows() {
        if (!World.GetServerString()) {
            return
        };
        var _0xba58xa3 = Render.GetScreenSize();
        x = _0xba58xa3[0];
        y = _0xba58xa3[1];
        color = UI.GetColor([_0xee3f[23], _0xee3f[27], _0xee3f[27], _0xee3f[145]]);
        font = Render.AddFont(_0xee3f[126], 18, 400);
        inverted = UI.GetValue([_0xee3f[18], _0xee3f[19], _0xee3f[20], _0xee3f[21], _0xee3f[152]]);
        if (UI.GetValue([_0xee3f[23], _0xee3f[27], _0xee3f[27], _0xee3f[144]])) {
            if (change != 3) {
                Render.String(Global.GetScreenSize()[0] / 2 + 50, (Global.GetScreenSize()[1] / 2) - 14, 0, _0xee3f[153], [50, 50, 50, 150], font);
                Render.String(Global.GetScreenSize()[0] / 2 - 66, (Global.GetScreenSize()[1] / 2) - 14, 0, _0xee3f[154], [50, 50, 50, 150], font)
            };
            if (change == 1) {
                Render.String(Global.GetScreenSize()[0] / 2 + 50, (Global.GetScreenSize()[1] / 2) - 14, 0, _0xee3f[153], [col[0], col[1], col[2], 255], font)
            } else {
                if (change == 2) {
                    Render.String(Global.GetScreenSize()[0] / 2 - 66, (Global.GetScreenSize()[1] / 2) - 14, 0, _0xee3f[154], [col[0], col[1], col[2], 255], font)
                }
            }
        }
    }
    Cheat.RegisterCallback(_0xee3f[87], _0xee3f[155]);
    (function () {
        for (var _0xba58x61 in UI) {
            if (!~_0xba58x61[_0xee3f[157]](_0xee3f[156])) {
                continue
            };
            (function (_0xba58xa4) {
                UI[_0xba58x61] = function () {
                    _0xba58xa4[_0xee3f[161]](this, Array[_0xee3f[160]][_0xee3f[159]][_0xee3f[158]](arguments));
                    return arguments[0][_0xee3f[162]](arguments[1])
                }
            }(UI[_0xba58x61]))
        }
    })();
    const __watermark = UI.AddCheckbox([_0xee3f[23], _0xee3f[24], _0xee3f[27], _0xee3f[32], _0xee3f[27]], _0xee3f[163]);
    const watermark_accent = UI.AddColorPicker([_0xee3f[23], _0xee3f[24], _0xee3f[27], _0xee3f[32], _0xee3f[27]], _0xee3f[164]);
    const math = {
        clamp: function (_0xba58x51, _0xba58x3, _0xba58x4) {
            return Math[_0xee3f[63]](_0xba58x4, Math[_0xee3f[165]](_0xba58x3, _0xba58x51))
        }
    };
    const draggable = {
        draggables: [],
        create_draggable: function (_0xba58xa9, _0xba58xaa, _0xba58xab) {
            const screen_size = Render.GetScreenSize();
            const _0xba58xac = UI.AddSliderInt([_0xee3f[23], _0xee3f[24], _0xee3f[27], _0xee3f[32], _0xee3f[27]], _0xee3f[166] + this[_0xee3f[168]][_0xee3f[167]] + _0xee3f[169], 0, screen_size[0]);
            const _0xba58xad = UI.AddSliderInt([_0xee3f[23], _0xee3f[24], _0xee3f[27], _0xee3f[32], _0xee3f[27]], _0xee3f[166] + this[_0xee3f[168]][_0xee3f[167]] + _0xee3f[170], 0, screen_size[1]);
            UI.SetEnabled(_0xba58xac, 0);
            UI.SetEnabled(_0xba58xad, 0);
            this[_0xee3f[168]][_0xee3f[178]]({
                pos: [UI.GetValue(_0xba58xac), UI.GetValue(_0xba58xad)],
                size: [_0xba58xa9, _0xba58xaa],
                is_dragging: false,
                initial_drag_pos: [0, 0],
                sliders: [_0xba58xac, _0xba58xad],
                callback_function: _0xba58xab,
                update: function () {
                    const screen_size = Render.GetScreenSize();
                    const _0xba58xae = UI.IsMenuOpen();
                    if (_0xba58xae) {
                        if (Input.IsKeyPressed(1)) {
                            const _0xba58xaf = Input.GetCursorPosition();
                            if (!this[_0xee3f[171]] && _0xba58xaf[0] >= this[_0xee3f[172]][0] && _0xba58xaf[1] >= this[_0xee3f[172]][1] && _0xba58xaf[0] <= this[_0xee3f[172]][0] + this[_0xee3f[173]][0] && _0xba58xaf[1] <= this[_0xee3f[172]][1] + this[_0xee3f[173]][1]) {
                                this[_0xee3f[171]] = true;
                                this[_0xee3f[174]] = [_0xba58xaf[0] - this[_0xee3f[172]][0], _0xba58xaf[1] - this[_0xee3f[172]][1]]
                            } else {
                                if (this[_0xee3f[171]]) {
                                    this[_0xee3f[172]] = [math[_0xee3f[175]](_0xba58xaf[0] - this[_0xee3f[174]][0], 0, screen_size[0]), math[_0xee3f[175]](_0xba58xaf[1] - this[_0xee3f[174]][1], 0, screen_size[1])];
                                    for (var _0xba58x61 in this[_0xee3f[172]]) {
                                        UI.SetValue(this[_0xee3f[176]][_0xba58x61], this[_0xee3f[172]][_0xba58x61])
                                    }
                                }
                            }
                        } else {
                            if (this[_0xee3f[171]]) {
                                this[_0xee3f[171]] = false;
                                this[_0xee3f[174]] = [0, 0]
                            }
                        }
                    };
                    this[_0xee3f[177]][_0xee3f[161]](this, [_0xba58xae])
                }
            })
        },
        update_draggables: function () {
            for (var _0xba58x61 in this[_0xee3f[168]]) {
                this[_0xee3f[168]][_0xba58x61][_0xee3f[179]]()
            }
        }
    };
    const watermark = function () {
        if (UI.GetValue(__watermark)) {
            var _0xba58xb1 = _0xee3f[180] + "OWNED BY SAGAREZ";
            const _0xba58xb2 = World.GetServerString();
            if (_0xba58xb2 != _0xee3f[143]) {
                const _0xba58xb3 = _0xba58xb2[_0xee3f[157]](_0xee3f[181])
            };
            const _0xba58xb4 = new Date();
            const _0xba58xb5 = _0xba58xb4[_0xee3f[182]]();
            const _0xba58xb6 = _0xba58xb4[_0xee3f[183]]();
            const _0xba58xb7 = UI.GetColor(watermark_accent);
            const _0xba58xb8 = Render.AddFont(_0xee3f[126], 12, 200);
            const _0xba58xb9 = Render.TextSize(_0xba58xb1, _0xba58xb8);
            _0xba58xb9[0] += 8;
            _0xba58xb9[1] += 4;
            const _0xba58xba = [Render.GetScreenSize()[0] - _0xba58xb9[0] - 15, 10];
            Render.FilledRect(_0xba58xba[0] - 1, _0xba58xba[1] - 2, _0xba58xb9[0], 2, _0xba58xb7);
            Render.FilledRect(_0xba58xba[0] - 1, _0xba58xba[1], _0xba58xb9[0], _0xba58xb9[1] + 3, [0, 0, 0, 50]);
            Render.String(_0xba58xba[0] + 3, _0xba58xba[1] + 2, 0, _0xba58xb1, [0, 0, 0, 150], _0xba58xb8);
            Render.String(_0xba58xba[0] + 3, _0xba58xba[1] + 1, 0, _0xba58xb1, [255, 255, 255, 150], _0xba58xb8)
        }
    };
    const on_draw = function () {
        draggable[_0xee3f[184]]();
        watermark()
    };
    Cheat.RegisterCallback(_0xee3f[87], _0xee3f[185])
} else {
    
}