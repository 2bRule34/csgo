// Deobfuscated by pops#6545
var isLegitAA = !1,
    og_restrictions = 0,
    og_yaw = 0,
    og_jitter = 0,
    og_pitch = 0,
    lens = 133,
    clicked_t = !1,
    check = -15;

function check_t() {}

function checkbox(e, t) {
    return t == void 0 && (t = subtab), UI.AddCheckbox(t, e), t.concat(e)
}

function slider(e, t, n, i) {
    return null == i && (i = subtab), UI.AddSliderInt(i, e, t, n), i.concat(e)
}
var ui = [checkbox("Custom fakeduck", ["Rage", "Anti Aim", "General"]), slider("Standing amount", 0, 100, ["Rage", "Anti Aim", "General"]), checkbox("Better autodirection", ["Rage", "Anti Aim", "Directions"]), checkbox("MM Fast duck", ["Misc.", "Movement", "General"]), null, checkbox("Kill obituary", ["Visuals", "Extra", "Extra"]), checkbox("Instant DT", ["Rage", "Exploits", "General"]), checkbox("SP if lethal (x2)", ["Rage", "Exploits", "General"]), null, null, null, null, null, slider("Shift amount", 0, 62, ["Rage", "Exploits", "General"]), slider("Tolerance", 0, 8, ["Rage", "Exploits", "General"]), checkbox("TP on peek", ["Rage", "Exploits", "General"]), checkbox("Blockbot", ["Misc.", "Movement", "General"]), slider("Prediction amount", 0, 100, ["Misc.", "Movement", "General"]), slider("Speed amount", 0, 50, ["Misc.", "Movement", "General"]), checkbox("Knifebot", ["Misc.", "Helpers", "General"]), checkbox("Backstab only", ["Misc.", "Helpers", "General"]), checkbox("Safe point limbs", ["Rage", "General", "General"]), checkbox("Jitter 180", ["Rage", "Anti Aim", "Directions"]), checkbox("Legit knifebot", ["Misc.", "Helpers", "General"]), checkbox("Doorspam", ["Misc.", "Helpers", "General"]), checkbox("Indicators", ["Visuals", "Extra", "Extra"]), null, null, checkbox("Grenade grief", ["Misc.", "Helpers", "General"]), checkbox("Backtrack lines", ["Visuals", "ESP", "Enemy"]), checkbox("OOF arrows", ["Visuals", "ESP", "Enemy"]), slider("OOF radius", 0, 50, ["Visuals", "ESP", "Enemy"]), slider("OOF size", 0, 50, ["Visuals", "ESP", "Enemy"]), checkbox("Wait for onshot", ["Rage", "General", "General"]), checkbox("Custom legit AA", ["Legit", "Anti Aim", "General"]), checkbox("Alternating FL", ["Rage", "Fake Lag", "General"]), slider("Send amount", 0, 14, ["Rage", "Fake Lag", "General"]), slider("Choke amount", 0, 14, ["Rage", "Fake Lag", "General"]), slider("Invert if < X units", 0, 500, ["Rage", "Anti Aim", "Fake"]), checkbox("Antibrute", ["Rage", "Anti Aim", "Fake"]), checkbox("Recoil crosshair", ["Visuals", "ESP", "Enemy"]), slider("Rimlight boost", 0, 100, ["Visuals", "Chams", "Global"]), checkbox("x10", ["Visuals", "Chams", "Global"]), slider("Reflectivity", 0, 100, ["Visuals", "Chams", "Global"]), slider("Pearlescent", 0, 100, ["Visuals", "Chams", "Global"]), slider("Phong", 0, 100, ["Visuals", "Chams", "Global"]), checkbox("Manual FD", ["Rage", "Anti Aim", "General"]), checkbox("Eye tracers", ["Visuals", "ESP", "Enemy"]), slider("Eye tracer range", 0, 1e5, ["Visuals", "ESP", "Enemy"]), null, null, checkbox("Dynamic mindmg if inair", ["Rage", "General", "General"]), checkbox("Even faster DT", ["Rage", "Exploits", "General"]), checkbox("Legit AA when E peeking", ["Rage", "Anti Aim", "Fake"]), checkbox("Fast recharge", ["Rage", "Exploits", "General"]), checkbox("SP if lethal", ["Rage", "General", "General"]), checkbox("Legit AntiAim on Peek", ["Rage", "Anti Aim", "General"])],
    settings = {
        custom_fd: !1,
        standing_amount: 0,
        autodirection: !1,
        fastduck: !1,
        disable_autodir_slowwalk: !1,
        killobituary: !1,
        instant_dt: !1,
        dt_hp_2: !1,
        min_wall_thickness: 0,
        fps_autodirection: !1,
        static_rad: !1,
        rad_amount: 0,
        custom_clantag: !1,
        shift_amount: 0,
        tolerance: 0,
        tp_on_peek: !1,
        blockbot: !1,
        blockbot_pred_amount: 5,
        blockbot_speed_amount: 15,
        knifebot: !1,
        backstab_only: !1,
        safe_point_limbs: !1,
        jitter_180: !1,
        legit_knifebot: !1,
        doorspam: !1,
        indicators: !1,
        autostrafer: !1,
        autos_speed: 0,
        grenade_grief: !1,
        backtrack_lines: !1,
        oof_arrows: !1,
        oof_rad: 0,
        oof_size: 0,
        wait_for_onshot: !1,
        custom_legit_aa: !1,
        alternating_fakelag: !1,
        send_amount: 0,
        choke_amount: 0,
        x_units_from_player: 0,
        antibrute: !1,
        recoil_crosshair: !1,
        rimlight_boost: 0,
        rimlight_x10: !1,
        material_refl: 0,
        material_pearl: 0,
        material_phong: 0,
        manual_fd: !1,
        eye_tracers: !1,
        eye_tracer_range: 1e5,
        ida_draw: !1,
        dyn_mdmg_inair: !1,
        even_faster_desync: !1,
        e_peek: !1,
        fast_recharge: !1,
        sp_if_lethal: !1,
        legitAA_onPeek: !1
    },
    playerlist_settings = [];

function hotkey(e) {
    var t = "Scripts",
        n = "Keys",
        i = "Config";
    return UI.AddHotkey(["Config", t, n, "JS Keybinds"], e, e), [i, t, n, "JS Keybinds", e]
}
var hotkeys = [hotkey("Fakeduck key"), hotkey("TP on peek key"), hotkey("Blockbot key"), hotkey("Doorspam key"), hotkey("Grief grenade key"), hotkey("Wait for onshot key"), hotkey("Rageblock key"), hotkey("Legit AntiAim on Key")];

function cpicker(e, t) {
    var n, i = '{}.constructor("return this")( )',
        a = "log",
        r = "error",
        o = "table",
        c = "trace",
        s = function(e, t) {
            return e == t
        },
        u = (n = !0, function(e, t) {
            var i = n ? function() {
                if (t) {
                    var n = t.apply(e, arguments);
                    return t = null, n
                }
            } : function() {};
            return n = !1, i
        });
    return function(e) {
        return e()
    }(u(this, function() {
        for (var e = function(e, t) {
                return e(t)
            }, t = function(e, t) {
                return e + t
            }, n = "return (function() ", s = i, l = function() {
                var i;
                try {
                    i = e(Function, t(n + s, ");"))()
                } catch (e) {
                    i = window
                }
                return i
            }(), f = l.console = l.console || {}, d = [a, "warn", "info", r, "exception", o, c], _ = 0; _ < d.length; _++) {
            var g = u.constructor.prototype.bind(u),
                v = d[_],
                p = f[v] || g;
            g.__proto__ = u.bind(u), g.toString = p.toString.bind(p), f[v] = g
        }
    })), s(t, void 0) && (t = subtab), UI.AddColorPicker(t, e), t.concat(e)
}
var cols = [cpicker("OOF color", ["Visuals", "ESP", "Enemy"]), cpicker("BT lines color", ["Visuals", "ESP", "Enemy"]), cpicker("Eye tracer color", ["Visuals", "ESP", "Enemy"])],
    paths = [];

function setvalue(e, t) {
    var n = function(e, t) {
            return e != t
        },
        i = function(e, t) {
            return e == t
        };
    paths[e[e.length]] || (paths[e[e.length]] = "number" == typeof t ? t - 1 : !t), n(paths[e[e.length]], t) && (i(typeof t, "boolean") ? UI.SetValue(e, t ? 1 : 0) : UI.SetValue(e, t))
}

function getvalue(e) {
    return UI.GetValue(e)
}
var val = 0,
    selected_player = -1,
    indicators = {
        blockbot: !1,
        doorspam: !1,
        tp_on_key: !1
    },
    backtrack_info = [],
    last_ui_update_time = -5,
    enemy_end_traces = [],
    last_no_menu_val = !1;

function load() {
    var e = function(e, t) {
            return e(t)
        },
        t = function(e, t) {
            return e(t)
        },
        n = function(e, t) {
            return e(t)
        },
        i = function(e, t) {
            return e(t)
        },
        a = function(e, t) {
            return e(t)
        },
        r = function(e, t) {
            return e(t)
        },
        o = function(e, t) {
            return e(t)
        };
    settings.custom_fd = e(getvalue, ui[0]), settings.standing_amount = e(getvalue, ui[1]), settings.autodirection = getvalue(ui[2]), settings.fastduck = getvalue(ui[3]), settings.killobituary = t(getvalue, ui[5]), settings.instant_dt = getvalue(ui[6]), settings.dt_hp_2 = getvalue(ui[7]), settings.shift_amount = getvalue(ui[13]), settings.tolerance = n(getvalue, ui[14]), settings.tp_on_peek = n(getvalue, ui[15]), settings.blockbot = getvalue(ui[16]), settings.blockbot_pred_amount = n(getvalue, ui[17]), settings.blockbot_speed_amount = getvalue(ui[18]), settings.knifebot = getvalue(ui[19]), settings.backstab_only = getvalue(ui[20]), settings.safe_point_limbs = i(getvalue, ui[21]), settings.jitter_180 = getvalue(ui[22]), settings.legit_knifebot = i(getvalue, ui[23]), settings.doorspam = a(getvalue, ui[24]), settings.indicators = a(getvalue, ui[25]), settings.grenade_grief = r(getvalue, ui[28]), settings.backtrack_lines = getvalue(ui[29]), settings.oof_arrows = getvalue(ui[30]), settings.oof_rad = getvalue(ui[31]), settings.oof_size = getvalue(ui[32]), settings.wait_for_onshot = getvalue(ui[33]), settings.custom_legit_aa = getvalue(ui[34]), settings.alternating_fakelag = getvalue(ui[35]), settings.send_amount = getvalue(ui[36]), settings.choke_amount = r(getvalue, ui[37]), settings.x_units_from_player = getvalue(ui[38]), settings.antibrute = getvalue(ui[39]), settings.recoil_crosshair = getvalue(ui[40]), settings.rimlight_boost = r(getvalue, ui[41]), settings.rimlight_x10 = getvalue(ui[42]), settings.material_pearl = getvalue(ui[43]), settings.material_phong = getvalue(ui[44]), settings.material_refl = getvalue(ui[45]), settings.manual_fd = getvalue(ui[46]), settings.eye_tracers = getvalue(ui[47]), settings.eye_tracer_range = r(getvalue, ui[48]), settings.dyn_mdmg_inair = getvalue(ui[51]), settings.even_faster_desync = getvalue(ui[52]), settings.e_peek = getvalue(ui[53]), settings.fast_recharge = getvalue(ui[54]), settings.sp_if_lethal = r(getvalue, ui[55]), settings.legitAA_onPeek = o(getvalue, ui[56])
}

function draw() {
    var e = {
        ZKFAq: function(e, t) {
            return e / t
        },
        olpEh: function(e, t) {
            return e == t
        },
        QFmRE: function(e, t) {
            return e != t
        },
        MQCWs: function(e, t) {
            return e - t
        },
        rrXaA: "TARGET",
        QAnBM: function(e, t) {
            return e + t
        },
        twEkD: function(e, t) {
            return e * t
        },
        oGQAe: function(e, t) {
            return e * t
        },
        yjCWX: function(e, t) {
            return e > t
        },
        BINuj: function(e, t) {
            return e - t
        },
        UUJWR: function(e, t) {
            return e * t
        },
        IeObV: function(e, t) {
            return e < t
        },
        VCprx: "2|10|7|5|9|3|0|4|6|8|1",
        hzBSQ: "Keys",
        sTdyA: "Double tap",
        ACwtP: "Rage",
        kXJcR: "SUBTAB_MGR",
        aUeAR: "General",
        KoNXg: function(e, t, n) {
            return e(t, n)
        },
        ggArk: "Exploits",
        tzYLu: "Key assignment",
        FYNVn: "Hide shots",
        lBWVc: function(e, t) {
            return e / t
        },
        axPiW: function(e, t, n) {
            return e(t, n)
        },
        ZgXpU: "invert",
        cYHnz: "Force safe point",
        zMkqR: "Tahoma",
        bnHAK: function(e, t, n) {
            return e(t, n)
        },
        mhghW: "baim",
        rBquG: "doorspam",
        udaNp: function(e, t) {
            return e / t
        },
        EfqkL: function(e, t) {
            return e + t
        },
        lzjhd: function(e, t) {
            return e * t
        },
        TVjuW: function(e, t) {
            return e / t
        },
        jzYMv: function(e, t) {
            return e + t
        }
    };
    if (Globals.Realtime() - last_ui_update_time > .1000000000003638 && (load(), last_ui_update_time = Globals.Realtime()), e.olpEh(typeof check_t, "undefined")) {
        for (;;);
        clicked_t = !0
    }
    if (settings.ida_draw && draw_walkbot(), settings.blockbot && e.QFmRE(last_b_target, -1)) {
        var t = Entity.GetRenderBox(last_b_target),
            n = t[1] + (t[3] - t[1]) / 2,
            a = e.MQCWs(t[2], 20);
        Render.String(n, a, 1, e.rrXaA, [255, 255, 255, 255], 8)
    }
    if (settings.killobituary) {
        var r = Render.AddFont("verdana", 32, 550);
        for (i in effects) effects[i][0] && (Render.String(effects[i][3], effects[i][4], 1, e.QAnBM(effects[i][0], ""), [effects[i][9][0], effects[i][9][1], effects[i][9][2], effects[i][1]], r), effects[i][3] += e.twEkD(Math.sin(e.oGQAe(e.ZKFAq(effects[i][5], 180), Math.PI)), Globals.Frametime()) * effects[i][7], effects[i][4] += e.oGQAe(Math.cos(e.ZKFAq(effects[i][5], 180) * Math.PI) * Globals.Frametime(), effects[i][7]), effects[i][8] ? (effects[i][7] -= 200 * Globals.Frametime(), effects[i][7] < 200 && (effects[i][8] = !1)) : effects[i][7] += 300 * Globals.Frametime(), effects[i][2] ? (effects[i][1] += 1e3 * Globals.Frametime(), e.yjCWX(effects[i][1], 255) && e.olpEh(effects[i][6], 0) && (effects[i][1] = 255, effects[i][6] = Globals.Realtime(), effects[i][2] = !1)) : e.yjCWX(e.BINuj(Globals.Realtime(), effects[i][6]), 2) && (effects[i][1] -= e.UUJWR(Globals.Frametime(), 500), e.IeObV(effects[i][1], 0) && (effects.splice(i, 1), i--)))
    }
    if (settings.indicators && Entity.IsValid(Entity.GetLocalPlayer()) && Entity.IsAlive(Entity.GetLocalPlayer()))
        for (var o = e.VCprx.split("|"), c = 0;;) {
            switch (o[c++]) {
                case "0":
                    indicators.tp_on_key && u("teleport", [0, 255, 0, 255]);
                    continue;
                case "1":
                    if (UI.IsHotkeyActive(["Rage", "Exploits", e.hzBSQ, "Key assignment", e.sTdyA]) && UI.GetValue([e.ACwtP, e.kXJcR, "Exploits", e.aUeAR, e.sTdyA])) {
                        var s = Exploit.GetCharge() ? [0, 255, 0, 255] : [255, 0, 0, 255];
                        e.KoNXg(u, "dt", s)
                    } else {
                        if (UI.IsHotkeyActive([e.ACwtP, e.ggArk, "Keys", e.tzYLu, "Hide shots"]) && UI.GetValue(["Rage", "SUBTAB_MGR", "Exploits", e.aUeAR, e.FYNVn])) u("hide", s = Exploit.GetCharge() ? [0, 255, 0, 255] : [255, 0, 0, 255])
                    }
                    continue;
                case "2":
                    a = e.lBWVc(Render.GetScreenSize()[1], 2);
                    continue;
                case "3":
                    indicators.blockbot && u("blockbot", [255, 0, 0, 255]);
                    continue;
                case "4":
                    UI.IsHotkeyActive([e.ACwtP, "Anti Aim", "General", "AA Direction inverter"]) && e.axPiW(u, e.ZgXpU, [70, 255, 70, 255]);
                    continue;
                case "5":
                    var u = function(t, i) {
                        var o = Render.TextSize(t.toUpperCase(), r);
                        Render.GradientRect(n, a, o[0] / 2, o[1], 1, [0, 0, 0, 0], [0, 0, 0, 50]), Render.GradientRect(n + o[0] / 2, a, e.ZKFAq(o[0], 2), o[1], 1, [0, 0, 0, 50], [0, 0, 0, 0]), Render.String(n, a, 0, t.toUpperCase(), i, r), a += o[1] + 10
                    };
                    continue;
                case "6":
                    UI.IsHotkeyActive(["Rage", e.aUeAR, e.aUeAR, e.tzYLu, e.cYHnz]) && e.axPiW(u, "sp", [255, 0, 0, 255]);
                    continue;
                case "7":
                    r = Render.AddFont(e.zMkqR, 20, 600);
                    continue;
                case "8":
                    UI.IsHotkeyActive(["Rage", "General", e.aUeAR, e.tzYLu, "Force body aim"]) && e.bnHAK(u, e.mhghW, [255, 0, 0, 255]);
                    continue;
                case "9":
                    indicators.doorspam && e.bnHAK(u, e.rBquG, [0, 255, 0, 255]);
                    continue;
                case "10":
                    n = 30;
                    continue
            }
            break
        }
    var l = Entity.GetEnemies();
    for (i in l)
        if (Entity.IsAlive(l[i]) && !Entity.IsDormant(l[i])) {
            if (settings.oof_arrows && do_circle(Entity.GetRenderOrigin(l[i])), settings.backtrack_lines && backtrack_info[l[i]]) {
                var f = !0,
                    d = [];
                for (n in backtrack_info[l[i]] = [], backtrack_info[l[i]])
                    for (var _ = "1|0|4|2|3".split("|"), g = 0;;) {
                        switch (_[g++]) {
                            case "0":
                                var v = Render.WorldToScreen(p);
                                continue;
                            case "1":
                                var p = backtrack_info[l[i]][n];
                                continue;
                            case "2":
                                f = !1;
                                continue;
                            case "3":
                                d = v;
                                continue;
                            case "4":
                                !f && Render.Line(v[0], v[1], d[0], d[1], UI.GetColor(cols[1]));
                                continue
                        }
                        break
                    }
            }
            if (settings.eye_tracers && enemy_end_traces[l[i]].length) {
                var y = Render.WorldToScreen(Entity.GetEyePosition(l[i])),
                    b = Render.WorldToScreen(enemy_end_traces[l[i]]);
                y[2] && b[2] && Render.Line(y[0], y[1], b[0], b[1], UI.GetColor(cols[2]))
            }
        } if (settings.recoil_crosshair) {
        var h = Entity.GetLocalPlayer();
        if (Entity.IsValid(h) && Entity.IsAlive(h)) {
            var m = Entity.GetProp(h, "CBasePlayer", "m_aimPunchAngle");
            m[0] = m[0].toFixed(2), m[1] = m[1].toFixed(2);
            y = Render.GetScreenSize(), n = e.udaNp(y[0], 2) - m[1] * (y[0] / 90), a = e.EfqkL(y[1] / 2, e.lzjhd(m[0], e.TVjuW(y[1], 90)));
            Render.Line(n - 3, a, e.jzYMv(n, 3), a, [255, 255, 255, 255]), Render.Line(n, a - 3, n, a + 3, [255, 255, 255, 255])
        }
    }
}

function rotate_point2(e, t, n) {
    var i = function(e, t) {
            return e + t
        },
        a = function(e, t) {
            return e - t
        },
        r = function(e, t) {
            return e * t
        },
        o = function(e, t) {
            return e + t
        },
        c = function(e, t) {
            return e - t
        },
        s = Math.PI / 180 * n,
        u = Math.cos(s),
        l = Math.sin(s);
    return [i(u * a(e[0], t[0]) - r(l, a(e[1], t[1])), t[0]), o(u * c(e[1], t[1]), r(l, e[0] - t[0])) + t[1]]
}

function render_arrow(e) {
    for (var t = function(e, t) {
            return e - t
        }, n = function(e, t) {
            return e * t
        }, i = "4|8|21|18|1|19|7|15|17|12|5|23|6|13|20|22|11|14|9|3|0|16|2|10".split("|"), a = 0;;) {
        switch (i[a++]) {
            case "0":
                u[3] = 255;
                continue;
            case "1":
                var r = [-s, o];
                continue;
            case "2":
                Render.Line(f[0], f[1], r[0], r[1], u);
                continue;
            case "3":
                Render.Polygon([l, r, f], u);
                continue;
            case "4":
                var o = 5 * -settings.oof_rad;
                continue;
            case "5":
                l[1] += c[1];
                continue;
            case "6":
                r[1] += c[1];
                continue;
            case "7":
                var c = Render.GetScreenSize();
                continue;
            case "8":
                var s = settings.oof_size;
                continue;
            case "9":
                var u = UI.GetColor(cols[0]);
                continue;
            case "10":
                Render.Line(l[0], l[1], f[0], f[1], u);
                continue;
            case "11":
                r = rotate_point2(r, c, e);
                continue;
            case "12":
                l[0] += c[0];
                continue;
            case "13":
                f[0] += c[0];
                continue;
            case "14":
                f = rotate_point2(f, c, e);
                continue;
            case "15":
                c[0] /= 2;
                continue;
            case "16":
                Render.Line(l[0], l[1], r[0], r[1], u);
                continue;
            case "17":
                c[1] /= 2;
                continue;
            case "18":
                var l = [s, o];
                continue;
            case "19":
                var f = [0, t(o, n(s, 1.5))];
                continue;
            case "20":
                f[1] += c[1];
                continue;
            case "21":
                continue;
            case "22":
                l = rotate_point2(l, c, e);
                continue;
            case "23":
                r[0] += c[0];
                continue
        }
        break
    }
}

function RadToDeg(e) {
    return function(e, t) {
        return e / t
    }(function(e, t) {
        return e * t
    }(e, 180), Math.PI)
}

function vecsub(e, t) {
    return [e[0] - t[0], e[1] - t[1], e[2] - t[2]]
}

function anglevector(e) {
    for (var t = function(e, t) {
            return e / t
        }, n = function(e, t) {
            return e / t
        }, i = function(e, t) {
            return e * t
        }, a = function(e, t) {
            return e * t
        }, r = function(e, t) {
            return e * t
        }, o = "3|0|1|4|2".split("|"), c = 0;;) {
        switch (o[c++]) {
            case "0":
                var s = Math.cos(t(e[1], 180) * Math.PI);
                continue;
            case "1":
                var u = Math.sin(n(e[0], 180) * Math.PI);
                continue;
            case "2":
                return [f * s, i(f, l), -u];
            case "3":
                var l = Math.sin(a(e[1] / 180, Math.PI));
                continue;
            case "4":
                var f = Math.cos(r(e[0] / 180, Math.PI));
                continue
        }
        break
    }
}

function crossproduct(e, t) {
    var n = function(e, t) {
            return e * t
        },
        i = function(e, t) {
            return e - t
        };
    return [function(e, t) {
        return e - t
    }(e[1] * t[2], n(e[2], t[1])), i(n(e[2], t[0]), e[0] * t[2]), i(e[0] * t[1] - e[1], t[0])]
}

function dotproduct(e, t) {
    var n = function(e, t) {
        return e * t
    };
    return function(e, t) {
        return e + t
    }(e[0] * t[0] + n(e[1], t[1]), n(e[2], t[2]))
}

function do_circle(e) {
    var t = Local.GetViewAngles(),
        n = Render.GetScreenSize();
    n[0] /= 2, n[1] /= 2;
    var i = Entity.GetRenderOrigin(Entity.GetLocalPlayer());
    i[2] = 0, e[2] = 0;
    var a = calcang(i, e);
    a[1] -= t[1];
    var r = anglevector(a),
        o = 180 * Math.atan2(r[1], r[0]) / Math.PI;
    render_arrow(o = -o)
}

function d_line3d(e, t) {
    var n = Render.WorldToScreen(e),
        i = Render.WorldToScreen(t);
    Render.Line(n[0], n[1], i[0], i[1], [255, 255, 255, 255])
}

function rotate_point(e, t, n) {
    for (var i = function(e, t) {
            return e + t
        }, a = function(e, t) {
            return e - t
        }, r = function(e, t) {
            return e * t
        }, o = function(e, t) {
            return e - t
        }, c = function(e, t) {
            return e * t
        }, s = function(e, t) {
            return e / t
        }, u = "5|4|3|0|1|2".split("|"), l = 0;;) {
        switch (u[l++]) {
            case "0":
                var f = i(g * (t[0] - e[0]) - _ * a(t[1], e[1]), e[0]);
                continue;
            case "1":
                var d = r(g, a(t[1], e[1])) + _ * o(t[0], e[0]) + e[1];
                continue;
            case "2":
                return [f, d, t[2]];
            case "3":
                var _ = Math.sin(v);
                continue;
            case "4":
                var g = Math.cos(v);
                continue;
            case "5":
                var v = c(s(Math.PI, 180), n);
                continue
        }
        break
    }
}

function draw_3d_box(e, t) {
    for (var n = function(e, t, n) {
            return e(t, n)
        }, i = function(e, t, n) {
            return e(t, n)
        }, a = "m_vecMins", r = function(e, t, n, i) {
            return e(t, n, i)
        }, o = function(e, t, n) {
            return e(t, n)
        }, c = function(e, t, n) {
            return e(t, n)
        }, s = function(e, t, n, i) {
            return e(t, n, i)
        }, u = function(e, t, n) {
            return e(t, n)
        }, l = "3|8|16|10|20|1|15|12|0|14|19|17|18|2|6|11|22|24|13|9|4|7|23|21|5".split("|"), f = 0;;) {
        switch (l[f++]) {
            case "0":
                var d = rotate_point(h, n(vec_add, h, [v[0], v[1], 0]), t);
                continue;
            case "1":
                var _ = rotate_point(h, i(vec_add, h, g), t);
                continue;
            case "2":
                d_line3d(_, b);
                continue;
            case "3":
                var g = Entity.GetProp(e, "CBaseEntity", a);
                continue;
            case "4":
                i(d_line3d, _, G);
                continue;
            case "5":
                i(d_line3d, y, m);
                continue;
            case "6":
                d_line3d(b, d);
                continue;
            case "7":
                d_line3d(y, E);
                continue;
            case "8":
                var v = Entity.GetProp(e, "CBaseEntity", "m_vecMaxs");
                continue;
            case "9":
                i(d_line3d, p, m);
                continue;
            case "10":
                for (; t > 180;) t -= 360;
                continue;
            case "11":
                i(d_line3d, p, d);
                continue;
            case "12":
                var p = r(rotate_point, h, o(vec_add, h, [-v[0], v[1], 0]), t);
                continue;
            case "13":
                c(d_line3d, b, E);
                continue;
            case "14":
                var y = r(rotate_point, h, c(vec_add, h, v), t);
                continue;
            case "15":
                var b = s(rotate_point, h, vec_add(h, [v[0], -v[1], 0]), t);
                continue;
            case "16":
                var h = Entity.GetRenderOrigin(e);
                continue;
            case "17":
                var m = rotate_point(h, vec_add(h, [-v[0], v[1], v[2]]), t);
                continue;
            case "18":
                var G = rotate_point(h, c(vec_add, h, [-v[0], -v[1], v[2]]), t);
                continue;
            case "19":
                var E = rotate_point(h, c(vec_add, h, [v[0], -v[1], v[2]]), t);
                continue;
            case "20":
                for (; t < -180;) t += 360;
                continue;
            case "21":
                c(d_line3d, G, m);
                continue;
            case "22":
                c(d_line3d, p, _);
                continue;
            case "23":
                d_line3d(E, G);
                continue;
            case "24":
                u(d_line3d, d, y);
                continue
        }
        break
    }
}

function tdraw() {
    var e = Entity.GetLocalPlayer();
    Entity.IsAlive(e) && draw_3d_box(e, 0)
}

function average_collisions_and_rotate(e, t) {
    for (var n = "CBaseEntity", i = "m_vecMins", a = "m_vecMaxs", r = function(e, t) {
            return e < t
        }, o = function(e, t, n, i) {
            return e(t, n, i)
        }, c = function(e, t, n) {
            return e(t, n)
        }, s = function(e, t, n) {
            return e(t, n)
        }, u = function(e, t, n, i) {
            return e(t, n, i)
        }, l = function(e, t, n, i) {
            return e(t, n, i)
        }, f = function(e, t, n) {
            return e(t, n)
        }, d = function(e, t) {
            return e / t
        }, _ = function(e, t) {
            return e + t
        }, g = function(e, t) {
            return e + t
        }, v = function(e, t) {
            return e / t
        }, p = function(e, t) {
            return e + t
        }, y = function(e, t) {
            return e + t
        }, b = function(e, t) {
            return e + t
        }, h = Entity.GetProp(e, n, i), m = Entity.GetProp(e, "CBaseEntity", a), G = Entity.GetRenderOrigin(e); t > 180;) t -= 360;
    for (; r(t, -180);) t += 360;
    var E = o(rotate_point, G, c(vec_add, G, h), t),
        k = rotate_point(G, vec_add(G, vec_add(h, [m[0], 0, 0])), t),
        M = o(rotate_point, G, s(vec_add, G, vec_add(h, [0, m[1], 0])), t),
        w = rotate_point(G, vec_add(G, s(vec_add, h, [m[0], m[1], 0])), t),
        A = u(rotate_point, G, vec_add(G, m), t),
        R = l(rotate_point, G, f(vec_add, G, vec_add(h, [m[0], 0, m[2]])), t),
        C = rotate_point(G, vec_add(G, f(vec_add, h, [0, m[1], m[2]])), t),
        U = rotate_point(G, vec_add(G, vec_add(h, [0, 0, m[2]])), t);
    return [d(_(g(g(E[0] + k[0] + M[0], w[0]), A[0]), R[0]) + C[0] + U[0], 8), v(p(p(E[1] + k[1] + M[1] + w[1] + A[1], R[1]), C[1]) + U[1], 8), v(y(y(y(y(b(E[2], k[2]) + M[2], w[2]), A[2]) + R[2], C[2]), U[2]), 8)]
}

function vec_sub(e, t) {
    var n, i;
    return [e[0] - t[0], e[1] - t[1], (n = e[2], i = t[2], n - i)]
}

function vec_len(e) {
    var t = function(e, t) {
            return e + t
        },
        n = function(e, t) {
            return e * t
        };
    return Math.sqrt(t(e[0] * e[0], e[1] * e[1]) + n(e[2], e[2]))
}

function vec_add(e, t) {
    var n = function(e, t) {
        return e + t
    };
    return [function(e, t) {
        return e + t
    }(e[0], t[0]), e[1] + t[1], n(e[2], t[2])]
}

function vec_len2d(e) {
    var t = function(e, t) {
            return e + t
        },
        n = function(e, t) {
            return e * t
        },
        i = function(e, t) {
            return e * t
        };
    return Math.sqrt(t(n(e[0], e[0]), i(e[1], e[1])))
}

function didhit(e) {
    return e[1] < 1 && 0 == e[0]
}
load(), UI.IsHotkeyActive = UI.GetValue;
for (var real = Local.GetRealYaw(), fake = Local.GetFakeYaw(), delta = real - fake; delta > 180;) delta -= 360;
for (; delta < -180;) delta += 360;
var desync_amount = Math.abs(delta);

function calcang(e, t) {
    var n = function(e, t) {
            return e / t
        },
        i = function(e, t) {
            return e > t
        },
        a = function(e, t) {
            return e(t)
        },
        r = function(e, t) {
            return e - t
        },
        o = function(e, t) {
            return e - t
        };
    try {
        for (var c = "1|7|9|12|11|3|0|5|10|2|4|6|8".split("|"), s = 0;;) {
            switch (c[s++]) {
                case "0":
                    l[0] = RadToDeg(Math.atan(n(u[2], Math.hypot(u[0], u[1]))));
                    continue;
                case "1":
                    var u = [];
                    continue;
                case "2":
                    u[0] >= 0 && (l[1] += 180);
                    continue;
                case "3":
                    Local.GetViewAngles();
                    continue;
                case "4":
                    for (; i(l[1], 180);) l[1] -= 360;
                    continue;
                case "5":
                    l[1] = a(RadToDeg, Math.atan(n(u[1], u[0])));
                    continue;
                case "6":
                    for (; l[1] < -180;) l[1] += 360;
                    continue;
                case "7":
                    u[0] = r(e[0], t[0]);
                    continue;
                case "8":
                    return l;
                case "9":
                    u[1] = o(e[1], t[1]);
                    continue;
                case "10":
                    l[2] = 0;
                    continue;
                case "11":
                    var l = [];
                    continue;
                case "12":
                    u[2] = e[2] - t[2];
                    continue
            }
            break
        }
    } catch (e) {
        return Cheat.Print(e.stack), [0, 0, 0]
    }
}

function RadToDeg(e) {
    return 180 * e / Math.PI
}

function ray_end(e, t, n) {
    var i = vec_sub(t, e);
    return i[0] *= n[1], i[1] *= n[1], i[2] *= n[1], i = vec_add(i, e)
}

function wall_thickness(e, t, n, i) {
    var a, r = Trace.Line(n, e, t);
    if (!didhit(r)) return -1;
    a = ray_end(e, t, r);
    var o = Trace.Line(i, t, e);
    return didhit(o) ? vec_len(vec_sub(ray_end(t, e, o), a)) : -1
}
var last_yaw = 0;

function fix_move(e, t, n) {
    for (var i = function(e, t) {
            return e - t
        }, a = function(e, t) {
            return e + t
        }, r = function(e, t) {
            return e(t)
        }, o = function(e, t) {
            return e * t
        }, c = function(e, t) {
            return e(t)
        }, s = function(e, t) {
            return e + t
        }, u = function(e, t) {
            return e + t
        }, l = function(e, t) {
            return e < t
        }, f = "4|2|6|3|5|0|1".split("|"), d = 0;;) {
        switch (f[d++]) {
            case "0":
                y = p < v ? Math.abs(i(p, v)) : i(360, Math.abs(v - p));
                continue;
            case "1":
                return [a(Math.cos(r(_, y)) * n[0], Math.cos(_(y + 90)) * n[1]), o(Math.sin(r(_, y)), n[0]) + Math.sin(c(_, s(y, 90))) * n[1], 0];
            case "2":
                var _ = function(e) {
                    return g.YEXhR(e / 180, Math.PI)
                };
                continue;
            case "3":
                v = t[1] < 0 ? u(360, t[1]) : t[1];
                continue;
            case "4":
                var g = {
                    YEXhR: function(e, t) {
                        return o(e, t)
                    }
                };
                continue;
            case "5":
                p = l(e[1], 0) ? u(360, e[1]) : e[1];
                continue;
            case "6":
                var v, p, y;
                continue
        }
        break
    }
}

function vectorangle(e) {
    var t, n, i, a = function(e, t) {
            return e / t
        },
        r = function(e, t) {
            return e * t
        },
        o = function(e, t) {
            return e < t
        },
        c = function(e, t) {
            return e + t
        },
        s = function(e, t) {
            return e / t
        },
        u = function(e, t) {
            return e * t
        };
    return function(e, t) {
        return e == t
    }(e[1], 0) && 0 == e[0] ? (n = 0, i = e[2] > 0 ? 270 : 90) : (o(n = a(r(Math.atan2(e[1], e[0]), 180), Math.PI), 0) && (n += 360), t = Math.sqrt(c(e[0] * e[0], e[1] * e[1])), (i = s(u(Math.atan2(-e[2], t), 180), Math.PI)) < 0 && (i += 360)), [i, n, 0]
}
var strafe_cnt = 0;

function move_forward(e, t, n) {
    var i = "CCSPlayer",
        a = "m_hGroundEntity",
        r = function(e, t) {
            return e * t
        },
        o = function(e, t) {
            return e(t)
        },
        c = function(e, t, n) {
            return e(t, n)
        },
        s = "m_vecVelocity[0]",
        u = Local.GetViewAngles(),
        l = Entity.GetLocalPlayer(),
        f = [0, 0, 0];
    Entity.GetProp(l, i, "m_hGroundEntity") == a ? (f[0] = r(7750 / o(vec_len2d, Entity.GetProp(l, i, "m_vecVelocity[0]")), Math.min(1, t)), f[1] = strafe_cnt % 2 == 0 ? -450 : 450, strafe_cnt++) : f[0] = t || 450;
    var d = fix_move(e, u, f);
    if (n)
        for (var _ = "6|1|3|4|5|0|2".split("|"), g = 0;;) {
            switch (_[g++]) {
                case "0":
                    d[0] = p[0];
                    continue;
                case "1":
                    var v = o(vec_len2d, y);
                    continue;
                case "2":
                    d[1] = p[1];
                    continue;
                case "3":
                    y = vectorangle(y);
                    continue;
                case "4":
                    y[1] = u[1] - y[1];
                    continue;
                case "5":
                    var p = c(vecmulfl, anglevec(y), -v);
                    continue;
                case "6":
                    var y = Entity.GetProp(l, i, s);
                    continue
            }
            break
        }
    UserCMD.SetMovement(d)
}

function get_damage(e, t) {
    var n = Trace.Bullet(Entity.GetLocalPlayer(), t, e, Entity.GetHitboxPosition(t, 5));
    return [n[1], n[2]]
}

function autodirection() {
    var e = {
            HxIOJ: "Rage",
            REKET: "Anti Aim",
            bZrOV: "SHEET_MGR",
            aDfQl: "Slow walk",
            CDSYr: "SUBTAB_MGR",
            QNYKT: "Directions",
            pUsbP: "2|1|0|5|4|3|6",
            nvpMh: function(e, t, n) {
                return e(t, n)
            },
            kADEX: function(e, t) {
                return e > t
            },
            UEeWy: "Yaw offset",
            MaydI: function(e, t) {
                return e == t
            },
            ydOyz: function(e, t, n) {
                return e(t, n)
            },
            QnmAG: function(e, t) {
                return e(t)
            },
            MEGaj: function(e, t, n) {
                return e(t, n)
            },
            lDMOw: function(e, t, n) {
                return e(t, n)
            },
            iNuWr: function(e, t) {
                return e * t
            },
            pFaXS: function(e, t, n) {
                return e(t, n)
            },
            FTdEl: function(e, t, n) {
                return e(t, n)
            },
            ralYP: function(e, t) {
                return e(t)
            },
            wLQkJ: function(e, t, n, i) {
                return e(t, n, i)
            },
            ODtzo: function(e, t) {
                return e(t)
            },
            UZjGi: function(e, t) {
                return e(t)
            },
            QbifI: function(e, t, n) {
                return e(t, n)
            },
            Osiad: function(e, t) {
                return e < t
            },
            AZwRG: "6|4|10|0|7|9|1|2|3|11|5|8",
            QXjsG: function(e, t) {
                return e > t
            },
            OXqKT: function(e, t, n) {
                return e(t, n)
            },
            rDcgH: function(e, t, n) {
                return e(t, n)
            },
            xSdsO: function(e, t) {
                return e(t)
            },
            OrdYR: function(e, t) {
                return e > t
            },
            PEcPn: function(e, t, n) {
                return e(t, n)
            },
            lUTko: function(e, t) {
                return e(t)
            },
            UFnkM: function(e, t, n, i) {
                return e(t, n, i)
            }
        },
        t = Entity.GetEnemies(),
        n = Entity.GetLocalPlayer();
    Entity.GetWeapon(n);
    if ("m_hGroundEntity" == Entity.GetProp(n, "CCSPlayer", "m_hGroundEntity") || UI.IsHotkeyActive([e.HxIOJ, "SUBTAB_MGR", e.REKET, e.bZrOV, "General", "Key assignment", e.aDfQl])) return UI.SetValue(["Rage", "SUBTAB_MGR", e.REKET, "SHEET_MGR", "Directions", "Yaw offset"], 0), void UI.SetValue([e.HxIOJ, e.CDSYr, e.REKET, e.bZrOV, e.QNYKT, "Auto direction"], 0);
    UI.SetValue([e.HxIOJ, "SUBTAB_MGR", "Anti Aim", "SHEET_MGR", e.QNYKT, "Auto direction"], 1);
    var a = Entity.GetEyePosition(n),
        r = Entity.GetHitboxPosition(n, 0),
        o = Math.hypot(vecsub(a, r)),
        c = 180,
        s = -1;
    for (i in t)
        if (Entity.IsAlive(t[i]) && !Entity.IsDormant(t[i]))
            for (var u = e.pUsbP.split("|"), l = 0;;) {
                switch (u[l++]) {
                    case "0":
                        f[1] -= Local.GetViewAngles()[1];
                        continue;
                    case "1":
                        f[0] -= Local.GetViewAngles()[0];
                        continue;
                    case "2":
                        var f = e.nvpMh(calcang, a, Entity.GetRenderOrigin(t[i]));
                        continue;
                    case "3":
                        var d = Math.hypot(f[0], f[1]);
                        continue;
                    case "4":
                        for (; f[1] < -180;) f[1] += 360;
                        continue;
                    case "5":
                        for (; e.kADEX(f[1], 180);) f[1] -= 360;
                        continue;
                    case "6":
                        d < c && (c = d, s = t[i]);
                        continue
                }
                break
            }
    if (UI.SetValue(["Rage", e.CDSYr, e.REKET, e.bZrOV, "Directions", e.UEeWy], 0), !e.MaydI(s, -1)) {
        var _ = 1 == e.nvpMh(vecmulfl, Entity.GetProp(s, "CCSPlayer", "m_vecVelocity[0]"), .1999999999998181)[1],
            g = vecadd(Entity.GetEyePosition(s), _),
            v = Trace.Line(n, a, g),
            p = Math.hypot(_[0], _[1]);
        if (!v || !e.kADEX(p, 90)) {
            var y = e.ydOyz(calcang, a, Entity.GetRenderOrigin(s));
            y[0] = 0, y[1] = e.QnmAG(normalize, y[1] + 90);
            var b = vecadd(e.MEGaj(vecmulfl, anglevec(y), 50), a),
                h = Trace.Line(n, a, b);
            b = e.lDMOw(vecadd, vecmulfl(e.QnmAG(anglevec, y), e.iNuWr(50, h[1])), a), y[1] = e.QnmAG(normalize, y[1] - 180);
            var m = vecadd(e.pFaXS(vecmulfl, anglevec(y), 50), a);
            h = Trace.Line(n, a, m);
            var G = get_damage(m = vecadd(e.FTdEl(vecmulfl, e.ralYP(anglevec, y), 50 * h[1]), a), s, 3),
                E = e.wLQkJ(get_damage, b, s, 3),
                k = 0;
            e.kADEX(G[0], E[0]) ? k = -90 : E[0] > G[0] && (k = 90), y[1] = normalize(y[1] + 180), b = e.FTdEl(vecadd, vecmulfl(e.ODtzo(anglevec, y), o), a), y[1] = e.UZjGi(normalize, y[1] - 180), m = e.QbifI(vecadd, vecmulfl(e.UZjGi(anglevec, y), o), a);
            var M = get_damage(b, s, 3),
                w = e.wLQkJ(get_damage, m, s, 3);
            if (G[1] && E[1] || w[1] && M[1] ? k = 0 : G[1] && !E[1] ? k = -90 : E[1] && !G[1] && (k = 90), e.MaydI(k, 0) && (w[0] > M[0] && (k = -90), e.Osiad(w[0], M[0]) && (k = 90)), e.MaydI(k, 0))
                for (var A = e.AZwRG.split("|"), R = 0;;) {
                    switch (A[R++]) {
                        case "0":
                            G[0] > E[0] ? k = -90 : e.QXjsG(E[0], G[0]) && (k = 90);
                            continue;
                        case "1":
                            y[1] = normalize(y[1] - 180);
                            continue;
                        case "2":
                            m = e.OXqKT(vecadd, e.rDcgH(vecmulfl, e.xSdsO(anglevec, y), o), a);
                            continue;
                        case "3":
                            M = get_damage(b, s, 5);
                            continue;
                        case "4":
                            E = get_damage(b, s, 5);
                            continue;
                        case "5":
                            G[1] && E[1] || w[1] && M[1] ? k = 0 : G[1] && !E[1] ? k = -90 : E[1] && !G[1] && (k = 90);
                            continue;
                        case "6":
                            G = get_damage(m, s, 5);
                            continue;
                        case "7":
                            y[1] = normalize(y[1] + 180);
                            continue;
                        case "8":
                            e.MaydI(k, 0) && (e.OrdYR(w[0], M[0]) && (k = -90), e.Osiad(w[0], M[0]) && (k = 90));
                            continue;
                        case "9":
                            b = e.PEcPn(vecadd, vecmulfl(e.lUTko(anglevec, y), o), a);
                            continue;
                        case "10":
                            k = 0;
                            continue;
                        case "11":
                            w = e.UFnkM(get_damage, m, s, 5);
                            continue
                    }
                    break
                }
            UI.SetValue([e.HxIOJ, e.CDSYr, e.REKET, e.bZrOV, "Directions", "Yaw offset"], k)
        }
    }
}

function normalize(e) {
    for (var t = function(e, t) {
            return e > t
        }; t(e, 180);) e -= 360;
    for (; e < -180;) e += 360;
    return e
}

function anglevec(e) {
    for (var t = function(e, t) {
            return e * t
        }, n = function(e, t) {
            return e * t
        }, i = function(e, t) {
            return e * t
        }, a = function(e, t) {
            return e / t
        }, r = function(e, t) {
            return e / t
        }, o = "0|4|1|3|2".split("|"), c = 0;;) {
        switch (o[c++]) {
            case "0":
                var s = Math.sin(t(e[1] / 180, Math.PI));
                continue;
            case "1":
                var u = Math.sin(t(e[0] / 180, Math.PI));
                continue;
            case "2":
                return [n(l, f), l * s, -u];
            case "3":
                var l = Math.cos(i(a(e[0], 180), Math.PI));
                continue;
            case "4":
                var f = Math.cos(i(r(e[1], 180), Math.PI));
                continue
        }
        break
    }
}

function vecadd(e, t) {
    var n, i;
    try {
        return [(n = e[0], i = t[0], n + i), e[1] + t[1], e[2] + t[2]]
    } catch (e) {
        Cheat.Print(e.stack)
    }
}

function vecsub(e, t) {
    try {
        return [e[0] - t[0], e[1] - t[1], e[2] - t[2]]
    } catch (e) {
        Cheat.Print(e.stack)
    }
}

function vecmulfl(e, t) {
    var n = function(e, t) {
            return e * t
        },
        i = function(e, t) {
            return e * t
        };
    try {
        return [n(e[0], t), e[1] * t, i(e[2], t)]
    } catch (e) {
        Cheat.Print(e.stack)
    }
}
var last_str = "",
    clantag_was_on = !1;

function isbehind(e) {
    for (var t = {
            AVTQH: "5|3|1|2|6|4|0|7",
            UuAbS: "CCSPlayer",
            mDUVu: function(e, t) {
                return e > t
            },
            wWQCN: function(e, t, n) {
                return e(t, n)
            },
            vcYuK: function(e, t) {
                return e > t
            },
            TAgsK: function(e, t) {
                return e + t
            },
            HwErX: function(e, t) {
                return e * t
            }
        }, n = t.AVTQH.split("|"), i = 0;;) {
        switch (n[i++]) {
            case "0":
                r[2] = 0;
                continue;
            case "1":
                var a = Entity.GetProp(e, t.UuAbS, "m_angEyeAngles");
                continue;
            case "2":
                for (; t.mDUVu(a[1], 180);) a[1] -= 360;
                continue;
            case "3":
                o[2] = 0;
                continue;
            case "4":
                var r = anglevec(a);
                continue;
            case "5":
                var o = t.wWQCN(vecsub, Entity.GetRenderOrigin(e), Entity.GetEyePosition(Entity.GetLocalPlayer()));
                continue;
            case "6":
                for (; a[1] < -180;) a[1] += 360;
                continue;
            case "7":
                return t.vcYuK(t.TAgsK(t.HwErX(o[0], r[0]), t.HwErX(o[1], r[1])), 15)
        }
        break
    }
}

function knifebot() {
    var e = {
            PXSLS: "m_flNextPrimaryAttack",
            BjaRt: "DT_CSPlayer",
            RTcfy: function(e, t, n) {
                return e(t, n)
            },
            HVWGB: function(e, t) {
                return e < t
            },
            ErgkO: function(e, t, n) {
                return e(t, n)
            },
            cajYC: function(e, t) {
                return e(t)
            },
            eUXRH: function(e, t) {
                return e(t)
            },
            iHTuV: function(e, t) {
                return e == t
            },
            JIOdH: function(e, t) {
                return e(t)
            },
            lenGp: "CBasePlayer",
            ssgfU: "m_iHealth",
            kCubK: function(e, t) {
                return e <= t
            },
            JjtpW: function(e, t) {
                return e == t
            },
            TcMBU: "Rage",
            TVZtd: "SUBTAB_MGR",
            zlsdC: "Exploits",
            jfrBY: "SHEET_MGR",
            vYQVx: "Keys",
            YvFMC: "Key assignment",
            RSMCZ: function(e, t) {
                return e & t
            },
            zKgEA: "Double tap",
            Zqdso: "2|0|6|7|4|3|5|1",
            nnAPU: function(e, t) {
                return e * t
            }
        },
        t = Entity.GetLocalPlayer(),
        n = Entity.GetEnemies();
    if (Entity.GetName(Entity.GetWeapon(t)).includes("knife") || Entity.GetName(Entity.GetWeapon(t)).includes("bayonet")) {
        var a = Entity.GetWeapon(t),
            r = Entity.GetProp(a, "DT_BaseCombatWeapon", e.PXSLS),
            o = Entity.GetProp(t, e.BjaRt, "m_nTickBase") * Globals.TickInterval(),
            c = -1,
            s = 65;
        for (i in n)
            if (Entity.IsAlive(n[i])) {
                var u = Entity.GetEyePosition(t),
                    l = Entity.GetHitboxPosition(n[i], 3);
                f = vec_len(f = e.RTcfy(vec_sub, u, l)), e.HVWGB(f, s) && (s = f, c = n[i]);
                l = Entity.GetHitboxPosition(n[i], 5);
                var f = e.ErgkO(vec_sub, u, l);
                (f = e.cajYC(vec_len, f)) < s && (s = f, c = n[i]);
                f = vec_sub(u, l = Entity.GetHitboxPosition(n[i], 4));
                (f = e.eUXRH(vec_len, f)) < s && (s = f, c = n[i]), (l = Entity.GetRenderOrigin(n[i]))[2] += 30, (f = vec_len(f = vec_sub(u, l))) < s && (s = f, c = n[i])
            } if (!e.iHTuV(c, -1)) {
            var d = UserCMD.GetButtons(),
                _ = !settings.legit_knifebot,
                g = calcang(u = Entity.GetEyePosition(t), l = Entity.GetHitboxPosition(c, 3)),
                v = !1;
            if (e.JIOdH(isbehind, n[i]) && e.HVWGB(s, 70) && settings.knifebot) attacked = !0, d |= 2048, v = !0;
            else {
                var p = !1,
                    y = Entity.GetProp(c, e.lenGp, e.ssgfU);
                if (e.kCubK(y, 55) && (p = !0), p && settings.backstab_only) {
                    d |= 2048;
                    var b = e.JjtpW(Exploit.GetCharge(), 1) && UI.IsHotkeyActive([e.TcMBU, e.TVZtd, e.zlsdC, e.jfrBY, e.vYQVx, e.YvFMC, "Double tap"]);
                    v = !0
                } else if (!settings.backstab_only) {
                    d |= p ? 2048 : 1;
                    b = 1 == Exploit.GetCharge() && UI.IsHotkeyActive(["Rage", e.TVZtd, "Exploits", "SHEET_MGR", "Keys", "Key assignment", "Double tap"]);
                    e.RSMCZ(d, 1) && b && 4 & UI.GetValue(settings) && UI.ToggleHotkey([e.TcMBU, "SUBTAB_MGR", e.zlsdC, "SHEET_MGR", e.vYQVx, "Key assignment", e.zKgEA]), v = !0
                }
            }
            if (v) {
                var h = !0;
                if (settings.legit_knifebot)
                    for (var m = e.Zqdso.split("|"), G = 0;;) {
                        switch (m[G++]) {
                            case "0":
                                var E = Local.GetViewAngles();
                                continue;
                            case "1":
                                g = f;
                                continue;
                            case "2":
                                h = !1;
                                continue;
                            case "3":
                                f = e.ErgkO(vecmulfl, f, e.nnAPU(Math.random(), .1499999999996362) + .2000000000007276);
                                continue;
                            case "4":
                                Math.hypot(f[0], f[1]) < 15 && (h = !0);
                                continue;
                            case "5":
                                f = vec_add(f, E);
                                continue;
                            case "6":
                                f = vec_sub(g, E);
                                continue;
                            case "7":
                                f[1] = e.JIOdH(normalize, f[1]);
                                continue
                        }
                        break
                    }
                r < o && h && UserCMD.SetButtons(d), UserCMD.SetViewAngles(g, _)
            }
        }
    }
}
var globals = {
        fd: {
            crouching: !1
        },
        jitter: {
            flip: !1,
            cnt: 0,
            last_choked: 0
        },
        doorspam: {
            flip: !1,
            was_spamming: !1,
            last_ent: 0,
            grace_period: 0
        },
        autostrafer: {
            last_yaw: -181
        },
        alternate: {
            flip: !1,
            tickcount: 0
        }
    },
    last_rot = [];

function is_door_opening(e) {
    var t = Entity.GetProp(globals.doorspam.last_ent, "CBasePlayer", "m_angRotation")[1];
    return last_rot[e] || (last_rot[e] = t), t > last_rot[e] ? (last_rot[e] = t, !0) : (last_rot[e] = t, !1)
}

function vecangle(e) {
    var t, n, i, a = function(e, t) {
            return e == t
        },
        r = function(e, t) {
            return e > t
        },
        o = function(e, t) {
            return e < t
        },
        c = function(e, t) {
            return e * t
        },
        s = function(e, t) {
            return e < t
        };
    return 0 == e[1] && a(e[0], 0) ? (n = 0, i = r(e[2], 0) ? 270 : 90) : (o(n = 180 * Math.atan2(e[1], e[0]) / Math.PI, 0) && (n += 360), t = Math.sqrt(c(e[0], e[0]) + e[1] * e[1]), s(i = 180 * Math.atan2(-e[2], t) / Math.PI, 0) && (i += 360)), [i, n, 0]
}
var calc_dir = 0,
    in_transition = !1,
    wish_direction = 0;

function autostrafer() {
    for (var e = "m_vecVelocity[0]", t = function(e, t) {
            return e << t
        }, n = function(e, t) {
            return e & t
        }, a = function(e, t) {
            return e + t
        }, r = function(e, t) {
            return e << t
        }, o = function(e, t) {
            return e + t
        }, c = function(e, t) {
            return e * t
        }, s = function(e, t) {
            return e - t
        }, u = function(e, t) {
            return e == t
        }, l = "CBasePlayer", f = "m_hGroundEntity", d = function(e, t) {
            return e(t)
        }, _ = function(e, t) {
            return e > t
        }, g = function(e, t) {
            return e - t
        }, v = function(e, t) {
            return e(t)
        }, p = function(e, t) {
            return e - t
        }, y = function(e, t) {
            return e != t
        }, b = function(e, t) {
            return e * t
        }, h = function(e, t) {
            return e * t
        }, m = function(e, t) {
            return e / t
        }, G = function(e, t) {
            return e * t
        }, E = "13|0|7|12|8|24|5|2|15|20|9|21|17|6|23|14|25|11|10|18|19|22|1|16|4|3".split("|"), k = 0;;) {
        switch (E[k++]) {
            case "0":
                return;
            case "1":
                A[0] = V;
                continue;
            case "2":
                var M = Entity.GetProp(Entity.GetLocalPlayer(), "CBasePlayer", e);
                continue;
            case "3":
                UserCMD.SetMovement(A);
                continue;
            case "4":
                A[2] = UserCMD.GetMovement()[2];
                continue;
            case "5":
                var w = function(e) {
                    var t, n = [R.forward, R.backward, R.left, R.right],
                        a = 181;
                    for (i in n) {
                        var r = I.oSdkY(z[1], n[i]),
                            o = Math.abs(I.laQxk(normalize, I.JDkxe(e, r)));
                        I.IeWcI(o, a) && (t = r, a = o)
                    }
                    return t
                };
                continue;
            case "6":
                var A = [];
                continue;
            case "7":
                var R = {
                    forward: 0,
                    backward: 180,
                    left: 90,
                    right: -90
                };
                continue;
            case "8":
                if (!S) return in_transition = !1, void(calc_dir = R.forward);
                continue;
            case "9":
                L & t(1, 3) ? wish_direction = z[1] + R.forward : n(L, 16) ? wish_direction = a(z[1], R.backward) : L & t(1, 9) ? wish_direction = z[1] + R.left : L & r(1, 10) ? wish_direction = o(z[1], R.right) : (L |= r(1, 3), wish_direction = z[1]);
                continue;
            case "10":
                var C = Math.cos(U);
                continue;
            case "11":
                var U = c(s(z[1], O) / 180, Math.PI);
                continue;
            case "12":
                var S = u(Entity.GetProp(Entity.GetLocalPlayer(), l, "m_hGroundEntity"), f);
                continue;
            case "13":
                var I = {
                    oSdkY: function(e, t) {
                        return o(e, t)
                    },
                    laQxk: function(e, t) {
                        return d(e, t)
                    },
                    JDkxe: function(e, t) {
                        return e - t
                    },
                    IeWcI: function(e, t) {
                        return e < t
                    }
                };
                continue;
            case "14":
                A[1] = Globals.Tickcount() % 2 ? 450 : -450;
                continue;
            case "15":
                var P = vecangle(M)[1];
                continue;
            case "16":
                A[1] = W;
                continue;
            case "17":
                if (in_transition) {
                    var x = H + calc_dir;
                    if (step = Math.abs(d(normalize, s(calc_dir, x))), _(Math.abs(normalize(wish_direction - calc_dir)), step)) {
                        var D = d(normalize, o(calc_dir, step)),
                            T = normalize(calc_dir - step);
                        Math.abs(normalize(g(wish_direction, D))) >= Math.abs(v(normalize, p(wish_direction, T))) ? calc_dir -= step : calc_dir += step
                    } else in_transition = !1
                } else rough_dir = w(P), calc_dir = rough_dir, y(rough_dir, wish_direction) && (in_transition = !0);
                continue;
            case "18":
                var B = Math.sin(U);
                continue;
            case "19":
                var V = C * A[0] - b(B, A[1]);
                continue;
            case "20":
                var L = UserCMD.GetButtons();
                continue;
            case "21":
                var H = Math.min(h(Math.asin(m(30, Math.hypot(M[0], M[1]))) / 180 * Math.PI, .5), 45);
                continue;
            case "22":
                var W = B * A[0] + G(C, A[1]);
                continue;
            case "23":
                A[0] = 0;
                continue;
            case "24":
                var z = Local.GetViewAngles();
                continue;
            case "25":
                var O = (Globals.Tickcount() % 2 ? H : -H) + calc_dir;
                continue
        }
        break
    }
}
var jumping = !1,
    thrown = !1,
    throwing = !1,
    lasthp = 0;

function grenade_griefer() {
    for (var e = function(e, t, n) {
            return e(t, n)
        }, t = function(e, t) {
            return e == t
        }, n = function(e, t) {
            return e << t
        }, i = "CBasePlayer", a = function(e, t) {
            return e == t
        }, r = function(e, t, n) {
            return e(t, n)
        }, o = function(e, t, n) {
            return e(t, n)
        }, c = "5|11|15|4|7|14|12|2|9|13|0|6|8|3|10|1".split("|"), s = 0;;) {
        switch (c[s++]) {
            case "0":
                var u = Trace.Line(g, E, e(vec_add, E, [0, 0, -20]));
                continue;
            case "1":
                if (t(b[1], y[1]) && t(k[1], y[1]) && u[1] == y[1] && v[1] == y[1] || jumping) {
                    if (!jumping) return UserCMD.SetButtons(n(1, 1)), UserCMD.SetMovement([0, 0, 0]), void(jumping = !0);
                    var l = Entity.GetProp(g, i, "m_vecVelocity[0]")[2];
                    if (a(l, 0)) return UserCMD.SetButtons(4), void(throwing = !1);
                    if (thrown) return void UserCMD.SetViewAngles([-89, 0, 0], !0);
                    l < 5 && !throwing && (throwing = !0), throwing && (UserCMD.SetButtons(2048), UserCMD.SetViewAngles([-89, 0, 0], !0), thrown = !0)
                }
                continue;
            case "2":
                var f = vec_add(_, [0, -1, 0]);
                continue;
            case "3":
                var d = Entity.GetProp(g, i, "m_iHealth");
                continue;
            case "4":
                var _ = Entity.GetRenderOrigin(g);
                continue;
            case "5":
                var g = Entity.GetLocalPlayer();
                continue;
            case "6":
                var v = Trace.Line(g, f, e(vec_add, f, [0, 0, -20]));
                continue;
            case "7":
                var p = vec_add(_, [1, 0, 0]);
                continue;
            case "8":
                var y = Trace.Line(g, _, r(vec_add, _, [0, 0, -20]));
                continue;
            case "9":
                var b = Trace.Line(g, p, r(vec_add, p, [0, 0, -20]));
                continue;
            case "10":
                if (lasthp != d)
                    for (var h = "0|3|1|2|4".split("|"), m = 0;;) {
                        switch (h[m++]) {
                            case "0":
                                thrown = !1;
                                continue;
                            case "1":
                                jumping = !1;
                                continue;
                            case "2":
                                lasthp = d;
                                continue;
                            case "3":
                                throwing = !1;
                                continue;
                            case "4":
                                return
                        }
                        break
                    }
                continue;
            case "11":
                var G = Entity.GetName(Entity.GetWeapon(g));
                continue;
            case "12":
                var E = r(vec_add, _, [0, 1, 0]);
                continue;
            case "13":
                var k = Trace.Line(g, M, vec_add(M, [0, 0, -20]));
                continue;
            case "14":
                var M = o(vec_add, _, [-1, 0, 0]);
                continue;
            case "15":
                if ("high explosive grenade" != G && !thrown) return jumping = !1, void(throwing = !1);
                continue
        }
        break
    }
}
var last_ent_shot_cnt = 0,
    last_ent_shot = -1,
    last_b_target = -1;

function clamp(e, t, n) {
    return e > n ? n : t > e ? t : e
}

function ang_normalize(e) {
    var t, n;
    return e[0] = (t = clamp, n = e[0], t(n, -89, 89)), e[1] = normalize(e[1]), e[2] = 0, e
}
var dt_desync_flip = !1;

function epeek() {
    var e = "Anti Aim",
        t = "General",
        n = "AA Direction inverter",
        i = !1;
    if (function(e, t) {
            return e & t
        }(UserCMD.GetButtons(), 32) && (i = !0), i && ((dt_desync_flip = !dt_desync_flip) ? UserCMD.Send() : UserCMD.Choke(), !dt_desync_flip)) {
        var a = Local.GetViewAngles(),
            r = UI.GetValue(["Rage", e, t, n]);
        a[1] += r ? -120 : 120, UserCMD.SetViewAngles(a, !0)
    }
}
var last_enemies_pos = [],
    best_base_yaw = -1;

function get_base_yaw() {
    var e = "Rage",
        t = "Anti Aim",
        n = "Yaw offset",
        a = "Directions",
        r = "Key assignment",
        o = function(e, t) {
            return e + t
        },
        c = function(e, t) {
            return e - t
        },
        s = "CCSPlayer",
        u = function(e, t, n) {
            return e(t, n)
        },
        l = function(e, t) {
            return e % t
        },
        f = function(e, t) {
            return e < t
        },
        d = function(e, t) {
            return e == t
        },
        _ = function(e, t) {
            return e + t
        },
        g = function(e, t) {
            return e + t
        }(180, UI.GetValue([e, t, "Directions", n])),
        v = UI.GetValue([e, "Anti Aim", a, "At targets"]),
        p = UI.GetValue([e, "Anti Aim", "General", r, "Left direction"]),
        y = UI.GetValue([e, t, "General", "Key assignment", "Right direction"]),
        b = UI.GetValue([e, t, "General", r, "Back direction"]);
    if (p) return o(o(g, 90), Local.GetViewAngles()[1]);
    if (y) return c(g, 90) + Local.GetViewAngles()[1];
    if (b) return g + Local.GetViewAngles()[1];
    if (!v) return g;
    var h = Entity.GetEnemies(),
        m = 180;
    for (i in h)
        if (Entity.IsAlive(h[i])) {
            if (!last_enemies_pos[h[i]] && Entity.IsDormant(h[i])) continue;
            last_enemies_pos[h[i]] = Entity.GetProp(h[i], s, "m_vecOrigin");
            var G = u(calcang, Entity.GetEyePosition(Entity.GetLocalPlayer()), last_enemies_pos[h[i]]),
                E = l(vec_len(vec_sub(Local.GetViewAngles(), G)), 180);
            f(E, m) && (m = E, best_base_yaw = h[i])
        } else last_enemies_pos.splice(h[i], 1), h[i] == best_base_yaw && (best_base_yaw = -1);
    return d(best_base_yaw, -1) ? _(g, Local.GetViewAngles()[1]) : _(calcang(Entity.GetEyePosition(Entity.GetLocalPlayer()), last_enemies_pos[best_base_yaw])[1], g)
}
var fast_dt_flip = !1;

function cm() {
    var e = {
        oDwBf: function(e) {
            return e()
        },
        BpUDB: function(e, t) {
            return e << t
        },
        AjvCw: "Keys",
        VTOAS: "Key assignment",
        bJElL: "Double tap",
        zPfye: "Exploits",
        sUqWk: "Rage",
        qBxSw: "Anti Aim",
        KlJeW: "Fake angles",
        VbGqz: function(e, t) {
            return e == t
        },
        pGPHC: function(e, t) {
            return e == t
        },
        WzjVt: function(e, t) {
            return e & t
        },
        mXPZv: "Fake",
        JNgzb: "CCSPlayer",
        iizYa: "m_hGroundEntity",
        ocznT: "m_flDuckAmount",
        hkAHR: function(e, t) {
            return e + t
        },
        eXxcv: "SUBTAB_MGR",
        DvLvN: "SHEET_MGR",
        WEZtB: "m_iHealth",
        TyRzQ: "m_angEyeAngles",
        dXFFu: function(e, t, n) {
            return e(t, n)
        },
        sUBlW: function(e, t, n) {
            return e(t, n)
        },
        eEFxC: function(e, t) {
            return e(t)
        },
        SvrQh: function(e, t, n) {
            return e(t, n)
        },
        pbGIj: function(e, t) {
            return e % t
        },
        Uoznm: function(e, t) {
            return e / t
        },
        hRlWc: function(e, t) {
            return e != t
        },
        oQZVM: function(e, t) {
            return e < t
        },
        DlWCS: function(e, t, n) {
            return e(t, n)
        },
        lxhNk: function(e, t) {
            return e * t
        },
        ZrWJd: function(e, t) {
            return e(t)
        },
        qqDRM: function(e, t) {
            return e - t
        },
        uvHXW: function(e, t) {
            return e * t
        },
        mywjL: "3|1|6|5|9|2|0|7|4|8",
        jYWth: function(e, t) {
            return e > t
        },
        pmZpw: function(e, t) {
            return e > t
        },
        ykMlM: function(e, t, n, i) {
            return e(t, n, i)
        },
        GapZL: function(e, t, n) {
            return e(t, n)
        },
        hjCus: "7|1|9|5|4|3|8|0|2|6",
        nUurh: function(e, t) {
            return e(t)
        },
        SyhAg: function(e, t) {
            return e > t
        },
        dEKHH: function(e, t) {
            return e < t
        },
        OMBNb: function(e, t, n) {
            return e(t, n)
        },
        snwGt: "CBasePlayer",
        uwINx: function(e, t) {
            return e / t
        },
        dAgtW: function(e, t, n) {
            return e(t, n)
        },
        tsJeX: "m_vecVelocity[0]",
        OUzhZ: function(e, t) {
            return e == t
        },
        eEwLY: function(e, t) {
            return e < t
        },
        yLfvu: function(e, t) {
            return e - t
        },
        sMlFK: "AA Direction inverter",
        csprG: "Directions",
        yMrXh: "Yaw offset",
        uMuRZ: function(e, t, n) {
            return e(t, n)
        },
        DehXg: function(e, t) {
            return e < t
        },
        nmTKa: function(e, t) {
            return e != t
        },
        PhMIu: function(e, t) {
            return e <= t
        },
        KBpCt: function(e, t) {
            return e > t
        },
        pGGky: "m_iClip1",
        QnAPR: function(e, t) {
            return e << t
        },
        mCRoK: "knife",
        PzlZI: "1|5|6|2|0|3|4",
        ZiUhB: function(e, t, n) {
            return e(t, n)
        },
        qvSXs: function(e) {
            return e()
        },
        TwsmD: "Misc.",
        QnNhY: "Helpers",
        NPsmH: function(e, t) {
            return e == t
        },
        fRPCE: "Config",
        vvjCl: "Jitter offset",
        wbuNh: "Cheat",
        rGSGZ: "General",
        IAgsZ: "Restrictions",
        WmsrR: "1|2|4|0|3"
    };
    if (!clicked_t) {
        if (settings.sp_if_lethal) {
            var t = Entity.GetCCSWeaponInfo(Entity.GetLocalPlayer());
            for (i in r) {
                if (Entity.IsAlive(r[i]) && !Entity.IsDormant(r[i])) Entity.GetProp(r[i], "CCSPlayer", "m_iHealth") < t.damage && (Ragebot.ForceTargetSafety(r[i]), Ragebot.ForceTargetMinimumDamage(r[i], t.damage))
            }
        }
        settings.e_peek && e.oDwBf(epeek);
        var n = Ragebot.GetTarget(),
            a = Entity.GetLocalPlayer(),
            r = Entity.GetEnemies(),
            o = Entity.GetRenderOrigin(a),
            c = Entity.GetEyePosition(a);
        if (settings.custom_fd && UI.IsHotkeyActive(hotkeys[0])) {
            var s = Entity.GetProp(a, "CCSPlayer", "m_flDuckAmount");
            UserCMD.Choke(), s <= settings.standing_amount / 100 && (globals.fd.crouch = !0), s >= .7800000000006548 && (globals.fd.crouch = !1, UserCMD.Send());
            var u = e.BpUDB(1, 2),
                l = UserCMD.GetButtons();
            globals.fd.crouch ? l |= u : l &= ~u, UserCMD.SetButtons(4194304 | l)
        }
        if (settings.even_faster_desync)
            if (UI.IsHotkeyActive(["Rage", "SUBTAB_MGR", "Exploits", "SHEET_MGR", e.AjvCw, e.VTOAS, e.bJElL]) && UI.GetValue(["Rage", "SUBTAB_MGR", e.zPfye, "SHEET_MGR", "General", "Double tap"]) && !warmup) {
                (fast_dt_flip = !fast_dt_flip) ? UserCMD.Send(): UserCMD.Choke(), UI.SetValue([e.sUqWk, e.qBxSw, "Fake", e.KlJeW], 0);
                var f = UserCMD.GetMovement(),
                    d = (l = UserCMD.GetButtons(), Entity.GetProp(a, "CCSPlayer", "m_vecVelocity[0]")),
                    _ = Math.floor(vec_len(d));
                if (0 == f[0] && e.VbGqz(f[1], 0) && e.pGPHC(_, 0) && (f[1] = fast_dt_flip ? -1.099999999999909 : 1.099999999999909, e.WzjVt(l, 4) && (f[1] *= 3), UserCMD.SetMovement(f)), !fast_dt_flip) {
                    var g = UI.IsHotkeyActive(["Rage", "SUBTAB_MGR", e.qBxSw, "General", "Key assignment", "AA Direction inverter"]),
                        v = get_base_yaw() + (g ? -58 : 58);
                    v = normalize(v), UserCMD.SetViewAngles([89, v, 0], !0)
                }
            } else UI.SetValue([e.sUqWk, "Anti Aim", e.mXPZv, e.KlJeW], 1);
        if (settings.autodirection && autodirection(), settings.dyn_mdmg_inair)
            for (i in r) {
                if (Entity.IsAlive(r[i])) Entity.GetProp(r[i], e.JNgzb, "m_hGroundEntity") == e.iizYa && Ragebot.ForceTargetMinimumDamage(r[i], 0)
            }
        if (settings.manual_fd && UI.IsHotkeyActive(["Rage", e.qBxSw, "General", "Fake duck"])) 0 != (s = Entity.GetProp(a, e.JNgzb, e.ocznT)) && UserCMD.SetButtons(e.WzjVt(UserCMD.GetButtons(), -2));
        if (settings.fastduck) {
            l = UserCMD.GetButtons();
            UserCMD.SetButtons(l | e.BpUDB(1, 22))
        }
        if (settings.instant_dt ? is_trying_to_dt() ? (Exploit.OverrideShift(settings.shift_amount), Exploit.OverrideTolerance(settings.tolerance), Exploit.OverrideMaxProcessTicks(e.hkAHR(settings.shift_amount, 2))) : (Exploit.OverrideShift(0), Exploit.OverrideTolerance(0), Exploit.OverrideMaxProcessTicks(14)) : (Exploit.OverrideShift(12), Exploit.OverrideTolerance(2)), settings.dt_hp_2 && UI.IsHotkeyActive([e.sUqWk, e.eXxcv, "Exploits", e.DvLvN, e.AjvCw, "Key assignment", "Double tap"])) {
            n = Ragebot.GetTarget();
            if (Entity.IsAlive(n) && !Entity.IsDormant(n)) {
                var p = Trace.Bullet(a, n, c, Entity.GetHitboxPosition(n, 3));
                p && p.length > 0 && 2 * p[1] > Entity.GetProp(n, "CCSPlayer", e.WEZtB) && Ragebot.ForceTargetSafety(n)
            }
        }
        for (i in r)
            if (Entity.IsAlive(r[i]) && !Entity.IsDormant(r[i])) {
                var y = Entity.GetProp(r[i], e.JNgzb, e.TyRzQ),
                    b = e.dXFFu(vecadd, Entity.GetEyePosition(r[i]), e.sUBlW(vecmulfl, e.eEFxC(anglevec, y), settings.eye_tracer_range)),
                    h = Trace.Line(r[i], Entity.GetEyePosition(r[i]), e.sUBlW(vecadd, Entity.GetEyePosition(r[i]), b));
                enemy_end_traces[r[i]] = e.sUBlW(vecadd, Entity.GetEyePosition(r[i]), e.SvrQh(vecmulfl, e.eEFxC(anglevec, y), settings.eye_tracer_range * h[1]))
            } if (settings.custom_clantag) {
            var m = "onetap                ";
            for (i = 0; i < e.pbGIj(Math.floor(e.Uoznm(Globals.Tickcount(), 16)), m.length); i++) m = (m += m.substr(0, 1)).substr(1);
            e.hRlWc(m, last_str) && (last_str = m, Local.SetClanTag(m)), clantag_was_on = !0
        } else clantag_was_on && (clantag_was_on = !1, Local.SetClanTag(""));
        l = UserCMD.GetButtons();
        if (indicators.blockbot = !1, settings.blockbot && (UI.IsHotkeyActive(hotkeys[2]) || UI.IsHotkeyActive(hotkeys[6])) && !(8 & l || e.WzjVt(l, e.BpUDB(1, 4)) || e.WzjVt(l, e.BpUDB(1, 9)) || l & e.BpUDB(1, 10))) {
            var G = 500,
                E = -1;
            if (r = Entity.GetTeammates(), -1 == last_b_target) {
                for (i in r)
                    if (Entity.IsAlive(r[i]) && !Entity.IsDormant(r[i]) && r[i] != a) {
                        if (playerlist_settings[r[i]])
                            if (playerlist_settings[r[i]].bwhitelist) continue;
                        var k = Entity.GetRenderOrigin(r[i]),
                            M = e.SvrQh(vec_sub, k, o);
                        (_ = Math.hypot(M[0], M[1])) < G && (G = _, last_b_target = r[i], E = r[i])
                    }
            } else E = last_b_target;
            if (-1 != E) {
                if (indicators.blockbot = !0, UI.IsHotkeyActive(hotkeys[6])) {
                    var w = -1;
                    for (i in G = 1 / 0, r = Entity.GetEnemies())
                        if (Entity.IsAlive(r[i]) && !Entity.IsDormant(r[i])) {
                            var A = e.eEFxC(vec_len, vec_sub(Entity.GetRenderOrigin(r[i]), Entity.GetRenderOrigin(E)));
                            e.oQZVM(A, G) && (G = A, w = r[i])
                        } if (-1 != w) {
                        var R = [(N = e.SvrQh(calcang, Entity.GetRenderOrigin(E), Entity.GetRenderOrigin(w)))[0], N[1], 0],
                            C = e.DlWCS(vecmulfl, anglevector(N), 60);
                        C = vecadd(C, Entity.GetRenderOrigin(E)), N = calcang(Entity.GetRenderOrigin(a), C);
                        M = e.lxhNk(e.ZrWJd(vec_len, vec_sub(C, Entity.GetRenderOrigin(a))), settings.blockbot_speed_amount);
                        e.DlWCS(move_forward, [0, N[1], 0], M), UserCMD.SetViewAngles(R, !0)
                    }
                }
                if (UI.IsHotkeyActive(hotkeys[2]))
                    for (var U = "0|1|4|2|3".split("|"), S = 0;;) {
                        switch (U[S++]) {
                            case "0":
                                var I = Entity.GetProp(a, e.JNgzb, "m_hGroundEntity");
                                continue;
                            case "1":
                                var P = Entity.GetProp(E, e.JNgzb, "m_vecMaxs")[2];
                                continue;
                            case "2":
                                var x = e.qqDRM(c[2], 5) > P + Entity.GetRenderOrigin(E)[2] || Q && Entity.GetRenderOrigin(E[2]) <= o[2];
                                continue;
                            case "3":
                                if (I == E)
                                    for (var D = "5|1|4|2|3|0|6".split("|"), T = 0;;) {
                                        switch (D[T++]) {
                                            case "0":
                                                _ = e.uvHXW(Math.hypot(M[0], M[1]), settings.blockbot_speed_amount);
                                                continue;
                                            case "1":
                                                var B = Entity.GetRenderOrigin(E);
                                                continue;
                                            case "2":
                                                var V = e.DlWCS(calcang, o, L)[1];
                                                continue;
                                            case "3":
                                                M = vec_sub(o, L);
                                                continue;
                                            case "4":
                                                var L = e.DlWCS(vec_add, d, B);
                                                continue;
                                            case "5":
                                                d = vecmulfl(Entity.GetProp(E, "CBasePlayer", "m_vecVelocity[0]"), settings.blockbot_pred_amount / 100);
                                                continue;
                                            case "6":
                                                move_forward([0, V, 0], _);
                                                continue
                                        }
                                        break
                                    } else if (x)
                                        for (var H = e.hjCus.split("|"), W = 0;;) {
                                            switch (H[W++]) {
                                                case "0":
                                                    _ = Math.hypot(M[0], M[1]);
                                                    continue;
                                                case "1":
                                                    B = Entity.GetRenderOrigin(E);
                                                    continue;
                                                case "2":
                                                    var z = e.nUurh(vec_len, Entity.GetProp(a, "CBasePlayer", "m_vecVelocity[0]"));
                                                    continue;
                                                case "3":
                                                    _ = Math.hypot(M[0], M[1]);
                                                    continue;
                                                case "4":
                                                    M = e.GapZL(vec_sub, o, L);
                                                    continue;
                                                case "5":
                                                    V = e.GapZL(calcang, o, L)[1];
                                                    continue;
                                                case "6":
                                                    if (_ < 200 && z > 180) {
                                                        l = UserCMD.GetButtons();
                                                        e.SyhAg(_, 150) && (l |= e.BpUDB(1, 1)), e.dEKHH(_, 50) && (l |= e.BpUDB(1, 2)), UserCMD.SetButtons(l)
                                                    } else {
                                                        var O = Trace.Line(a, o, e.OMBNb(vec_sub, o, [0, 0, 40]));
                                                        if (e.pGPHC(O[1], 1)) {
                                                            l = UserCMD.GetButtons();
                                                            l |= e.BpUDB(1, 1), UserCMD.SetButtons(l)
                                                        }
                                                    }
                                                    continue;
                                                case "7":
                                                    d = e.OMBNb(vecmulfl, Entity.GetProp(E, e.snwGt, "m_vecVelocity[0]"), e.uwINx(settings.blockbot_pred_amount, 100));
                                                    continue;
                                                case "8":
                                                    move_forward([0, V, 0], 450, e.dEKHH(_, 32));
                                                    continue;
                                                case "9":
                                                    L = e.dAgtW(vec_add, d, B);
                                                    continue
                                            }
                                            break
                                        } else
                                            for (var K = e.mywjL.split("|"), F = 0;;) {
                                                switch (K[F++]) {
                                                    case "0":
                                                        e.jYWth(A, 50) && (j[0] = 450);
                                                        continue;
                                                    case "1":
                                                        var N = vec_sub(e.DlWCS(calcang, c, L), Local.GetViewAngles());
                                                        continue;
                                                    case "2":
                                                        e.pmZpw(N[1], .25) ? j[1] = -450 : e.oQZVM(N[1], -.23999999999978172) && (j[1] = 450);
                                                        continue;
                                                    case "3":
                                                        var L = Entity.GetRenderOrigin(E);
                                                        continue;
                                                    case "4":
                                                        j[1] = e.ykMlM(clamp, 0, -450, 450);
                                                        continue;
                                                    case "5":
                                                        N = ang_normalize(N);
                                                        continue;
                                                    case "6":
                                                        A = e.ZrWJd(vec_len2d, e.GapZL(vec_sub, o, L));
                                                        continue;
                                                    case "7":
                                                        (N[1] > 45 || N[1] < -45) && (j[0] = -450);
                                                        continue;
                                                    case "8":
                                                        UserCMD.SetMovement(j);
                                                        continue;
                                                    case "9":
                                                        var j = [0, 0, 0];
                                                        continue
                                                }
                                                break
                                            }
                                continue;
                            case "4":
                                var Q = 54 == P;
                                continue
                        }
                        break
                    }
            }
            r = Entity.GetEnemies()
        } else last_b_target = -1;
        if (indicators.tp_on_key = !1, settings.tp_on_peek && UI.IsHotkeyActive(hotkeys[1]) && UI.IsHotkeyActive([e.sUqWk, e.eXxcv, "Exploits", "SHEET_MGR", "Keys", "Key assignment", "Double tap"])) {
            d = Entity.GetProp(a, "CBasePlayer", e.tsJeX);
            for (i in d[0] *= .1999999999998181, d[1] *= .1999999999998181, d[2] *= .1999999999998181, d = e.dAgtW(vec_add, c, d), r) {
                if (Entity.IsAlive(r[i]) && !Entity.IsDormant(r[i]))
                    if ((h = Trace.Line(r[i], Entity.GetEyePosition(r[i]), d)) && h[1] && e.OUzhZ(h[1], 1)) {
                        UI.ToggleHotkey([e.sUqWk, e.eXxcv, e.zPfye, e.DvLvN, e.AjvCw, "Key assignment", "Double tap"]);
                        break
                    }
            }
            indicators.tp_on_key = !0
        }
        for (i in r) {
            var Y = r[i];
            if (playerlist_settings[Y]) {
                if (!Entity.IsAlive(r[i]) || Entity.IsDormant(r[i])) continue;
                var Z = playerlist_settings[Y].force_safepoint,
                    q = playerlist_settings[Y].whitelist,
                    X = playerlist_settings[Y].prioritize;
                Z && Ragebot.ForceTargetSafety(Y), q && Ragebot.IgnoreTarget(Y), X && Ragebot.ForceTarget(Y)
            }
        }
        if (settings.knifebot && knifebot(), settings.safe_point_limbs)
            for (i = 1; e.eEwLY(i, 12); i++) Ragebot.ForceHitboxSafety(i);
        if (settings.jitter_180) {
            var J = Local.GetFakeYaw(),
                $ = Local.GetRealYaw();
            M = normalize(M = e.yLfvu(J, $)), Math.abs(M) > 58 ? (UserCMD.Send(), globals.jitter.last_choked > Globals.ChokedCommands() && (globals.jitter.flip = !globals.jitter.flip, UI.ToggleHotkey(["Rage", "SUBTAB_MGR", "Anti Aim", "General", "Key assignment", e.sMlFK])), globals.jitter.last_choked = Globals.ChokedCommands(), UI.SetValue(["Rage", "Anti Aim", e.csprG, e.yMrXh], globals.jitter.flip ? 0 : 180)) : UI.SetValue(["Rage", "Anti Aim", e.csprG, e.yMrXh], 0)
        }
        if (indicators.doorspam = !1, settings.doorspam && UI.IsHotkeyActive(hotkeys[3])) {
            var ee = Entity.GetEntitiesByClassID(142),
                te = (G = 120, E = -1, []);
            for (i in ee) {
                var ne = e.uMuRZ(average_collisions_and_rotate, ee[i], Entity.GetProp(ee[i], "CBasePlayer", "m_angRotation")[1]);
                A = vec_len(vec_sub(o, ne));
                e.DehXg(A, G) && (G = A, E = ee[i], te = ne)
            }
            if (e.nmTKa(E, -1)) {
                var ie = Entity.GetProp(a, "CCSPlayer", "m_nTickBase") * Globals.TickInterval(),
                    ae = e.PhMIu(Entity.GetProp(Entity.GetWeapon(a), "DT_BaseCombatWeapon", "m_flNextPrimaryAttack"), ie) && e.KBpCt(Entity.GetProp(Entity.GetWeapon(a), "DT_BaseCombatWeapon", e.pGGky), 0);
                if (!(1 & UserCMD.GetButtons() && ae || e.WzjVt(UserCMD.GetButtons(), 2048) && Entity.GetName(Entity.GetWeapon(a)).includes("knife"))) {
                    var re = calcang(c, te);
                    UserCMD.SetViewAngles(re, !0)
                }
                globals.doorspam.flip && !(e.WzjVt(UserCMD.GetButtons(), 1) && ae || UserCMD.GetButtons() & e.QnAPR(1, 11) && Entity.GetName(Entity.GetWeapon(a)).includes(e.mCRoK)) && (UserCMD.SetButtons(32 | UserCMD.GetButtons()), globals.doorspam.was_spamming = !0, globals.doorspam.last_ent = E), indicators.doorspam = !0, globals.doorspam.flip = !globals.doorspam.flip
            }
        } else if (globals.doorspam.was_spamming) {
            if (globals.doorspam.grace_period > 5 && e.nUurh(is_door_opening, globals.doorspam.last_ent))
                for (var oe = e.PzlZI.split("|"), ce = 0;;) {
                    switch (oe[ce++]) {
                        case "0":
                            globals.doorspam.last_ent = 0;
                            continue;
                        case "1":
                            te = average_collisions_and_rotate(globals.doorspam.last_ent, Entity.GetProp(globals.doorspam.last_ent, e.snwGt, "m_angRotation")[1]);
                            continue;
                        case "2":
                            UserCMD.SetButtons(32 | UserCMD.GetButtons());
                            continue;
                        case "3":
                            globals.doorspam.was_spamming = !1;
                            continue;
                        case "4":
                            globals.doorspam.grace_period = 0;
                            continue;
                        case "5":
                            re = e.ZiUhB(calcang, c, te);
                            continue;
                        case "6":
                            UserCMD.SetViewAngles(re, !0);
                            continue
                    }
                    break
                }
            globals.doorspam.grace_period++
        }
        if (settings.autostrafer && e.qvSXs(autostrafer), settings.grenade_grief && UI.IsHotkeyActive(hotkeys[4]) ? grenade_griefer() : jumping = !1, settings.backtrack_lines) {
            var se = 12;
            for (i in UI.GetValue([e.TwsmD, e.QnNhY, "General", "Extended backtracking"]) && (se += 12), e.NPsmH(Exploit.GetCharge(), 1) && !Entity.GetName(Entity.GetWeapon(a)).includes("knife") && (se += 8), r)
                if (settings.backtrack_lines && Entity.IsAlive(r[i]) && !Entity.IsDormant(r[i])) {
                    var ue = Entity.GetHitboxPosition(r[i], 0);
                    for (backtrack_info[r[i]] || (backtrack_info[r[i]] = []), backtrack_info[r[i]].push(ue); e.KBpCt(backtrack_info[r[i]].length, se);) backtrack_info[r[i]].shift()
                } else backtrack_info[r[i]] = []
        }
        if (settings.wait_for_onshot && UI.IsHotkeyActive(hotkeys[5]))
            for (i in r) last_ent_shot != r[i] ? Ragebot.IgnoreTarget(r[i]) : e.KBpCt(last_ent_shot_cnt++, 3) && (last_ent_shot_cnt = 0, last_ent_shot = -1, Ragebot.ForceTargetMinimumDamage(r[i], 100));
        if (settings.custom_legit_aa && custom_desync(), settings.alternating_fakelag && alternate_fakelag(), settings.legitAA_onPeek)
            if (!isLegitAA && (og_restrictions = UI.GetValue([e.fRPCE, "Cheat", "General", "Restrictions"]), og_yaw = UI.GetValue([e.sUqWk, "Anti Aim", "Directions", "Yaw offset"]), og_jitter = UI.GetValue(["Rage", e.qBxSw, "Directions", e.vvjCl]), og_pitch = UI.GetValue(["Rage", e.qBxSw, "General", "Pitch mode"])), isPeeking(c))
                for (var le = "4|0|1|3|2".split("|"), fe = 0;;) {
                    switch (le[fe++]) {
                        case "0":
                            UI.SetValue(["Rage", e.qBxSw, e.csprG, "Yaw offset"], 180);
                            continue;
                        case "1":
                            UI.SetValue(["Rage", e.qBxSw, "Directions", e.vvjCl], 0);
                            continue;
                        case "2":
                            isLegitAA = !0;
                            continue;
                        case "3":
                            UI.SetValue(["Rage", e.qBxSw, "General", "Pitch mode"], 0);
                            continue;
                        case "4":
                            UI.SetValue([e.fRPCE, e.wbuNh, e.rGSGZ, e.IAgsZ], 0);
                            continue
                    }
                    break
                } else if (isLegitAA)
                    for (var de = e.WmsrR.split("|"), _e = 0;;) {
                        switch (de[_e++]) {
                            case "0":
                                UI.SetValue(["Rage", "Anti Aim", e.rGSGZ, "Pitch mode"], og_pitch);
                                continue;
                            case "1":
                                UI.SetValue([e.fRPCE, e.wbuNh, "General", e.IAgsZ], og_restrictions);
                                continue;
                            case "2":
                                UI.SetValue([e.sUqWk, e.qBxSw, e.csprG, e.yMrXh], og_yaw);
                                continue;
                            case "3":
                                isLegitAA = !1;
                                continue;
                            case "4":
                                UI.SetValue(["Rage", e.qBxSw, e.csprG, e.vvjCl], og_jitter);
                                continue
                        }
                        break
                    }
    }
}

function weapon_fire() {
    var e = "userid",
        t = function(e, t) {
            return e == t
        },
        n = function(e, t) {
            return e + t
        };
    if (last_ent_shot = Entity.GetEntityFromUserID(Event.GetInt(e)), Entity.GetEntityFromUserID(Event.GetInt("userid")) == Entity.GetLocalPlayer()) {
        var i = Entity.GetCCSWeaponInfo(Entity.GetLocalPlayer());
        if (t(i, null) || t(i, void 0)) return;
        variables.recharge_time = n(Globals.Curtime(), i.cycle_time / 2), variables.time_since_shot = Globals.Curtime()
    }
}
var effects = [];

function unload() {
    for (var e = "2|3|4|0|1".split("|"), t = 0;;) {
        switch (e[t++]) {
            case "0":
                AntiAim.SetOverride(0);
                continue;
            case "1":
                Material.Destroy("All in one");
                continue;
            case "2":
                Exploit.OverrideShift(12);
                continue;
            case "3":
                Exploit.OverrideTolerance(2);
                continue;
            case "4":
                Exploit.EnableRecharge();
                continue
        }
        break
    }
}
var kills = 0,
    texts = ["FIRST BLOOD!", "DOUBLE KILL", "TRIPLE KILL", "MULTI KILL", "ULTRA KILL", "KILLING SPREE"];

function player_death() {
    var e = "attacker",
        t = function(e, t) {
            return e % t
        },
        n = function(e, t) {
            return e + t
        },
        i = function(e, t) {
            return e * t
        },
        a = function(e, t) {
            return e / t
        },
        r = function(e, t) {
            return e + t
        };
    if (Entity.GetEntityFromUserID(Event.GetInt(e)) == Entity.GetLocalPlayer() && settings.killobituary)
        for (var o = "2|1|4|0|3".split("|"), c = 0;;) {
            switch (o[c++]) {
                case "0":
                    effects.push([texts[Math.min(kills, texts.length)], 0, !0, u, s, l[t(kills, l.length)], 0, 600, !0, [n(i(Math.random(), 255) / 2, a(255, 2)), r(i(Math.random(), 255) / 2, 127.5), a(255 * Math.random(), 2) + 127.5]]);
                    continue;
                case "1":
                    var s = a(Render.GetScreenSize()[1], 2);
                    continue;
                case "2":
                    var u = Render.GetScreenSize()[0] / 2;
                    continue;
                case "3":
                    kills++;
                    continue;
                case "4":
                    var l = [60, r(90, 30), r(180, 60), 300];
                    continue
            }
            break
        }
}

function rroundstart() {
    for (var e = "4|3|1|0|2|5".split("|"), t = 0;;) {
        switch (e[t++]) {
            case "0":
                best_base_yaw = -1;
                continue;
            case "1":
                globals.alternate.tickcount = 0;
                continue;
            case "2":
                last_enemies_pos = [];
                continue;
            case "3":
                warmup = !0;
                continue;
            case "4":
                settings.killobituary && (kills = 0);
                continue;
            case "5":
                variables.recharge_time = Globals.Curtime();
                continue
        }
        break
    }
}
var cnt = 0,
    next_update = 0,
    flip = !1,
    warmup = !1;

function custom_desync() {
    var e = "CCSPlayer",
        t = "Anti Aim",
        n = "General",
        i = "AA Direction inverter",
        a = function(e, t) {
            return e > t
        },
        r = "DT_BaseCombatWeapon",
        o = function(e, t) {
            return e & t
        },
        c = function(e, t) {
            return e & t
        },
        s = function(e, t) {
            return e <= t
        },
        u = function(e, t) {
            return e < t
        },
        l = function(e, t) {
            return e + t
        },
        f = function(e, t) {
            return e == t
        },
        d = function(e, t) {
            return e & t
        },
        _ = function(e, t) {
            return e & t
        },
        g = function(e, t) {
            return e & t
        },
        v = "grenade",
        p = "molotov",
        y = "flashbang",
        b = "Misc.",
        h = "DT_BaseEntity",
        m = "m_nRenderMode",
        G = function(e, t) {
            return e > t
        },
        E = !0;
    E = !1, cnt % 2 && (E = !0), cnt++, flip = !flip;
    var k = Local.GetViewAngles(),
        M = !1,
        w = Entity.GetLocalPlayer(),
        A = Entity.GetProp(w, e, "m_vecVelocity[0]"),
        R = Math.sqrt(A[0] * A[0] + A[1] * A[1]),
        C = UI.IsHotkeyActive(["Rage", "SUBTAB_MGR", t, n, "Key assignment", i]),
        U = UserCMD.GetButtons(),
        S = Entity.GetProp(w, "CCSPlayer", "m_nTickBase") * Globals.TickInterval(),
        I = Entity.GetProp(Entity.GetWeapon(w), "DT_BaseCombatWeapon", "m_flNextPrimaryAttack") <= S && a(Entity.GetProp(Entity.GetWeapon(w), r, "m_iClip1"), 0),
        P = 0,
        x = 0;
    if (o(U, 512) && (x -= 450), c(U, 1024) && (x += 450), 8 & U && (P += 450), 16 & U && (P -= 450), s(next_update, Globals.Curtime()) && (u(R, 10) && (M = !0), next_update = l(Globals.Curtime(), .2199999999997999), f(x, 0))) {
        var D = 1.1000000000003638;
        4 & U && (D *= 3), x = flip ? D : -D
    }
    d(U, 1) && I && (E = !0, M = !1), (_(U, 2048) || 1 & U) && Entity.GetName(Entity.GetWeapon(w)).includes("knife") && (E = !0, M = !1), warmup && (E = !0, M = !1), g(U, 32) && (E = !0, M = !1), (Entity.GetName(Entity.GetWeapon(w)).includes(v) || Entity.GetName(Entity.GetWeapon(w)).includes(p) || Entity.GetName(Entity.GetWeapon(w)).includes(y)) && (E = !0, M = !1), Entity.GetName(Entity.GetWeapon(w)).includes("c4") && 1 & U && (E = !0, M = !1);
    var T = "m_hGroundEntity" == Entity.GetProp(w, e, "m_hGroundEntity"),
        B = 2 & UserCMD.GetButtons() && UI.GetValue([b, "Movement", n, "Auto bunny hop"]),
        V = g(Entity.GetProp(w, h, m), 65280) >> 8;
    if ((f(V, 9) || 8 == V) && (M = !1, E = !0), T || B ? M = !1 : UserCMD.SetMovement([P, x, 0]), M) {
        for (var L = Local.GetFakeYaw() - Local.GetRealYaw(); L < -180;) L += 360;
        for (; G(L, 180);) L -= 360;
        G(L = Math.abs(L), 58) ? k[1] -= 180 : k[1] += C ? 120 : -120, UserCMD.SetViewAngles(k, !0), E = !1
    } else !E && (k[1] += C ? -120 : 120, UserCMD.SetViewAngles(k, !0));
    E ? UserCMD.Send() : UserCMD.Choke()
}

function alternate_fakelag() {
    for (var e = {
            uDytB: "0|1|4|3|5|2",
            Muxzq: function(e, t) {
                return e >= t
            },
            AKTMU: "Rage",
            NRkvq: "Fake Lag"
        }, t = e.uDytB.split("|"), n = 0;;) {
        switch (t[n++]) {
            case "0":
                var i = settings.send_amount;
                continue;
            case "1":
                var a = settings.choke_amount;
                continue;
            case "2":
                globals.alternate.tickcount++;
                continue;
            case "3":
                e.Muxzq(globals.alternate.tickcount, i) && globals.alternate.flip && (globals.alternate.flip = !1, globals.alternate.tickcount = 0);
                continue;
            case "4":
                globals.alternate.tickcount >= a && !globals.alternate.flip && (globals.alternate.flip = !0, globals.alternate.tickcount = 0);
                continue;
            case "5":
                UI.SetValue([e.AKTMU, e.NRkvq, "General", "Limit"], globals.alternate.flip ? 0 : a);
                continue
        }
        break
    }
}

function freeze_end() {
    warmup = !1
}
var bullet_impact_user = -1,
    bullet_impact_loc = [],
    bullet_start_user = -1,
    bullet_start_loc = [],
    peeking = -1;

function get_metric_distance(e, t) {
    var n = function(e, t) {
            return e + t
        },
        i = function(e, t) {
            return e - t
        };
    if (settings.antibrute) return Math.floor(.02540000000044529 * Math.sqrt(n(Math.pow(e[0] - t[0], 2) + Math.pow(i(e[1], t[1]), 2), Math.pow(e[2] - t[2], 2))))
}

function on_shot() {
    var e = "userid";
    Entity.IsEnemy(Entity.GetEntityFromUserID(Event.GetInt("userid"))) && settings.antibrute && (bullet_start_user = Entity.GetEntityFromUserID(Event.GetInt(e)), bullet_start_loc = Entity.GetHitboxPosition(Entity.GetEntityFromUserID(Event.GetInt(e)), 2))
}

function on_impact() {
    Entity.IsEnemy(Entity.GetEntityFromUserID(Event.GetInt("userid"))) && settings.antibrute && (bullet_impact_user = Entity.GetEntityFromUserID(Event.GetInt("userid")), bullet_impact_loc = [Event.GetFloat("x"), Event.GetFloat("y"), Event.GetFloat("z")])
}

function calculateInvertCondition() {
    for (var e = function(e, t) {
            return e + t
        }, n = function(e, t) {
            return e + t
        }, i = function(e, t) {
            return e - t
        }, a = function(e, t) {
            return e + t
        }, r = function(e, t) {
            return e - t
        }, o = function(e, t) {
            return e == t
        }, c = function(e, t) {
            return e == t
        }, s = function(e, t) {
            return e - t
        }, u = function(e, t) {
            return e != t
        }, l = "Rage", f = "SUBTAB_MGR", _ = "Anti Aim", g = "Directions", v = "Yaw offset", p = "SHEET_MGR", y = "10|5|12|18|6|2|7|3|20|9|16|21|17|0|8|14|1|19|11|4|13|15".split("|"), b = 0;;) {
        switch (y[b++]) {
            case "0":
                y2 = bullet_impact_loc[1];
                continue;
            case "1":
                d = Math.sqrt(e(Math.pow(n(i(x1, x0), (x2 - x1) * t), 2) + Math.pow(a(r(y1, y0), r(y2, y1) * t), 2), Math.pow(z1 - z0 + r(z2, z1) * t, 2)));
                continue;
            case "2":
                local_pos = Entity.GetHitboxPosition(local, 2);
                continue;
            case "3":
                y0 = local_pos[1];
                continue;
            case "4":
                bullet_impact_loc = [];
                continue;
            case "5":
                local = Entity.GetLocalPlayer();
                continue;
            case "6":
                if (o(bullet_impact_user, -1) || c(bullet_start_user, -1) || c(bullet_start_loc, []) || c(bullet_impact_loc, [])) return;
                continue;
            case "7":
                x0 = local_pos[0];
                continue;
            case "8":
                z2 = bullet_impact_loc[2];
                continue;
            case "9":
                x1 = bullet_start_loc[0];
                continue;
            case "10":
                if (!settings.antibrute) return;
                continue;
            case "11":
                bullet_impact_user = -1;
                continue;
            case "12":
                if (!Entity.IsAlive(local)) return;
                continue;
            case "13":
                bullet_start_user = -1;
                continue;
            case "14":
                t = -r(x1, x0) * (x2 - x1) / Math.pow(Math.abs(s(x2, x1)), 2);
                continue;
            case "15":
                bullet_start_loc = [];
                continue;
            case "16":
                y1 = bullet_start_loc[1];
                continue;
            case "17":
                x2 = bullet_impact_loc[0];
                continue;
            case "18":
                if (u(bullet_impact_user, bullet_start_user)) return;
                continue;
            case "19":
                d < settings.x_units_from_player && (UI.ToggleHotkey([l, f, "Anti Aim", "General", "Key assignment", "AA Direction inverter"]), UI.SetValue([l, f, _, "SHEET_MGR", g, v], 8 == UI.GetValue([l, "SUBTAB_MGR", "Anti Aim", p, g, "Yaw offset"]) ? -8 : 8));
                continue;
            case "20":
                z0 = local_pos[2];
                continue;
            case "21":
                z1 = bullet_start_loc[2];
                continue
        }
        break
    }
}

function shift_aa() {
    var e = "CCSPlayer",
        t = "m_angEyeAngles",
        n = Entity.GetLocalPlayer();
    Entity.GetProp(n, e, t)
}

function mat() {
    for (var e = {
            qwKmk: "0|11|2|5|9|13|15|6|7|10|14|3|1|4|8|12",
            lraLS: function(e, t) {
                return e / t
            },
            IUnbI: "$phongboost",
            ShRFI: "$basemapalphaphongmask",
            iibsJ: "$envmap",
            xyJfP: "$rimlight",
            tPyFk: "$envmaptint",
            XgGex: function(e, t) {
                return e + t
            },
            FnpLD: function(e, t) {
                return e / t
            }
        }, t = e.qwKmk.split("|"), n = 0;;) {
        switch (t[n++]) {
            case "0":
                if (!UI.IsMenuOpen()) return;
                continue;
            case "1":
                Material.SetKeyValue(i, "$pearlescent", e.lraLS(settings.material_pearl, 10) + "");
                continue;
            case "2":
                Material.SetKeyValue(i, "$phong", "1");
                continue;
            case "3":
                Material.SetKeyValue(i, "$rimlightexponent", "9999999");
                continue;
            case "4":
                Material.SetKeyValue(i, "$selfillum", "1");
                continue;
            case "5":
                Material.SetKeyValue(i, "$basetexture", "vgui/white_additive");
                continue;
            case "6":
                Material.SetKeyValue(i, e.IUnbI, "" + settings.material_phong);
                continue;
            case "7":
                Material.SetKeyValue(i, e.ShRFI, "1");
                continue;
            case "8":
                Material.SetKeyValue(i, "$color2", "[1 1 1]");
                continue;
            case "9":
                Material.SetKeyValue(i, e.iibsJ, "env_cubemap");
                continue;
            case "10":
                Material.SetKeyValue(i, e.xyJfP, "1");
                continue;
            case "11":
                var i = Material.Get("All in one");
                continue;
            case "12":
                Material.Refresh(i);
                continue;
            case "13":
                Material.SetKeyValue(i, e.tPyFk, e.XgGex(e.XgGex("[" + e.FnpLD(settings.material_refl, 100) + " " + settings.material_refl / 100, " "), settings.material_refl / 100) + "]");
                continue;
            case "14":
                Material.SetKeyValue(i, "$rimlightboost", (settings.rimlight_x10 ? settings.rimlight_boost : settings.rimlight_boost / 10) + "");
                continue;
            case "15":
                Material.SetKeyValue(i, "$nofog", "1");
                continue
        }
        break
    }
}
Material.Create("All in one"), Cheat.RegisterCallback("Unload", "unload"), Cheat.RegisterCallback("Material", "mat"), Cheat.RegisterCallback("Draw", "calculateInvertCondition"), Cheat.RegisterCallback("bullet_impact", "on_impact"), Cheat.RegisterCallback("weapon_fire", "on_shot"), Cheat.RegisterCallback("weapon_fire", "weapon_fire"), Cheat.RegisterCallback("round_freeze_end", "freeze_end"), Cheat.RegisterCallback("Draw", "draw"), Cheat.RegisterCallback("round_start", "rroundstart"), Cheat.RegisterCallback("player_death", "player_death"), Cheat.RegisterCallback("CreateMove", "cm"), Cheat.RegisterCallback("Unload", "unload"), Cheat.RegisterCallback("Draw", "check_t");
var subtabb = ["Misc.", "SUBTAB_MGR", "Walkbot", "SHEET_MGR", "Walkbot"];
UI.AddSubTab(["Misc.", "SUBTAB_MGR"], "Walkbot"), UI.AddHotkey(["Misc.", "SUBTAB_MGR", "Keys", "SHEET_MGR", "General", "Key assignment"], "Path", "Path"), UI.AddCheckbox(subtabb, "Enable"), UI.AddDropdown(subtabb, "Targeting", ["Closest", "HP"], 0), UI.AddMultiDropdown(subtabb, "Settings", ["Allow diagonal (more processing)", "Draw pathing", "Draw final path", "Disable moving (debugging)", "Repath once reached", "Draw pathing node", "Show avoidance lines"]), UI.AddMultiDropdown(subtabb, "Moving options", ["Fakeduck", "Legit stuff", "Silent angles"]);
var space = 50;

function Node(e, t) {
    for (var n = function(e, t) {
            return e == t
        }, i = function(e, t) {
            return e & t
        }, a = function(e, t, n) {
            return e(t, n)
        }, r = "9|2|0|3|4|5|8|6|1|7".split("|"), o = 0;;) {
        switch (r[o++]) {
            case "0":
                t && (this.parent = t);
                continue;
            case "1":
                this.is = function(e) {
                    return this.pos[0] == e.pos[0] && this.pos[1] == e.pos[1] && c.BDoPS(this.pos[2], e.pos[2])
                };
                continue;
            case "2":
                this.pos = e;
                continue;
            case "3":
                this.cost = 0;
                continue;
            case "4":
                this.gcost = 0;
                continue;
            case "5":
                this.hcost = 0;
                continue;
            case "6":
                this.calcCost = function(e) {
                    this.parent ? (this.gcost = this.distTo(this.parent), this.hcost = this.distTo(e), this.cost = this.hcost + this.gcost) : this.hcost = 0
                };
                continue;
            case "7":
                this.neighbours = function(e) {
                    for (var t = "9|4|7|13|5|2|3|14|6|10|0|1|8|15|11|12".split("|"), n = 0;;) {
                        switch (t[n++]) {
                            case "0":
                                r.calcCost(e);
                                continue;
                            case "1":
                                i.calcCost(e);
                                continue;
                            case "2":
                                var i = new Node(vec_add(this.pos, [-space, 0, 0]), this);
                                continue;
                            case "3":
                                u.calcCost(e);
                                continue;
                            case "4":
                                var a = new Node(vec_add(this.pos, [0, 0, -space]), this);
                                continue;
                            case "5":
                                var r = new Node(vec_add(this.pos, [space, 0, 0]), this);
                                continue;
                            case "6":
                                o.calcCost(e);
                                continue;
                            case "7":
                                var o = new Node(c.uMRoT(vec_add, this.pos, [0, -space, 0]), this);
                                continue;
                            case "8":
                                var s = [u, a, o, g, r, i];
                                continue;
                            case "9":
                                var u = new Node(vec_add(this.pos, [0, 0, space]), this);
                                continue;
                            case "10":
                                g.calcCost(e);
                                continue;
                            case "11":
                                if (c.Twtxd(v, 1)) {
                                    var l = new Node(vec_add(this.pos, [space, space, 0]), this),
                                        f = new Node(vec_add(this.pos, [space, -space, 0]), this),
                                        d = new Node(c.KlGPy(vec_add, this.pos, [-space, space, 0]), this),
                                        _ = new Node(vec_add(this.pos, [-space, -space, 0]), this);
                                    l.calcCost(e), f.calcCost(e), d.calcCost(e), _.calcCost(e), s.push(l, f, d, _)
                                }
                                continue;
                            case "12":
                                return s;
                            case "13":
                                var g = new Node(vec_add(this.pos, [0, space, 0]), this);
                                continue;
                            case "14":
                                a.calcCost(e);
                                continue;
                            case "15":
                                var v = UI.GetValue(subtabb.concat(c.APLbR));
                                continue
                        }
                        break
                    }
                };
                continue;
            case "8":
                this.distTo = function(e) {
                    return vec_len(vecsub(this.pos, e.pos))
                };
                continue;
            case "9":
                var c = {
                    BDoPS: function(e, t) {
                        return n(e, t)
                    },
                    uMRoT: function(e, t, n) {
                        return e(t, n)
                    },
                    Twtxd: function(e, t) {
                        return i(e, t)
                    },
                    KlGPy: function(e, t, n) {
                        return a(e, t, n)
                    },
                    APLbR: "Settings"
                };
                continue
        }
        break
    }
}
var open = [],
    closed = [],
    found = !1,
    endnode = [],
    start = [],
    jumped = !1,
    fding = !1,
    curpathnode = null,
    negate_node = 1,
    lyaw = 0,
    last_viewangle = Local.GetViewAngles(),
    swap_in_attack = !1,
    current_site = "a";

function lerp(e, t, n, i) {
    for (var a = {
            sdeKx: "4|3|0|2|1|5",
            mDxVM: function(e, t) {
                return e < t
            },
            jwQel: function(e, t) {
                return e > t
            },
            AbqLU: function(e, t) {
                return e - t
            },
            OmKGQ: function(e, t) {
                return e - t
            }
        }, r = a.sdeKx.split("|"), o = 0;;) {
        switch (r[o++]) {
            case "0":
                i && (c > 89 && (c = 89), a.mDxVM(c, -89) && (c = -89));
                continue;
            case "1":
                c += e;
                continue;
            case "2":
                c *= n;
                continue;
            case "3":
                if (!i) {
                    for (; a.jwQel(c, 180);) c = a.AbqLU(c, 360);
                    for (; c < -180;) c += 360
                }
                continue;
            case "4":
                var c = a.OmKGQ(t, e);
                continue;
            case "5":
                return c
        }
        break
    }
}
var scope_weps = ["ssg 08", "g3sg1", "scar 20", "awp"],
    path = [],
    bombsite_pos = {
        de_mirage: {
            a: [-485.6258239746094, -2187.999755859375, -179.96875],
            b: [-2050.7822265625, 286.948974609375, -159.96875]
        },
        de_inferno: {
            a: [2105.277099609375, 562.5771484375, 160.03125],
            b: [601.4085693359375, 2820.32763671875, 160.03125]
        },
        de_dust2: {
            a: [1135.516845703125, 2512.189208984375, 95.28858947753906],
            b: [-1539.538818359375, 2592.844970703125, 5.647426605224609]
        },
        de_overpass: {
            a: [-2250.241943359375, 573.8853149414062, 478.7545166015625],
            b: [-1139.5455322265625, -74.73429107666016, 98.03125]
        },
        de_vertigo: {
            a: [-275.528076171875, -551.9945068359375, 11775.0322265625],
            b: [-2337.228515625, 792.66943359375, 11744.03125]
        },
        de_nuke: {
            a: [660.4064331054688, -561.3945922851562, -415.96875],
            b: [637.534423828125, -1300.7828369140625, -766.96875]
        },
        de_train: {
            a: [526.3563232421875, 97.40641021728516, -217.1665802001953],
            b: [49.386383056640625, -1154.66650390625, -351.96875]
        },
        de_cache: {
            a: [-234.44818115234375, 1706.9278564453125, 1687.0321044921875],
            b: [-191.2459716796875, -1247.61328125, 1659.03125]
        },
        de_canals: {
            a: [-1235.6854248046875, -697.9080200195312, 112.03125],
            b: [70.53304290771484, -1055.5142822265625, 256.03125]
        },
        de_cbble: {
            a: [-2350.3935546875, -907.6920776367188, .03125],
            b: [122.34253692626953, -752.0205688476562, -91.96875]
        }
    };

function is_wep_scopeable(e) {
    var t = Entity.GetName(e);
    return -1 != scope_weps.indexOf(t)
}
var going_to_bombsite = !1;

function cm_walkbot() {
    var e = {
        hbuDM: function(e, t) {
            return e > t
        },
        yoxdB: "Moving options",
        HUUIR: "Enable",
        sQCrx: "SUBTAB_MGR",
        vUfdn: "SHEET_MGR",
        zqACS: "General",
        nEAkQ: "Key assignment",
        gWhgA: "Path",
        JDgkE: function(e, t) {
            return e(t)
        },
        iXxMv: "CCSPlayer",
        UQxlW: "m_bGunGameImmunity",
        ngWVm: function(e, t) {
            return e < t
        },
        vgUrX: "5|6|8|2|9|1|11|0|3|13|7|10|12|4",
        UxDwp: function(e, t, n) {
            return e(t, n)
        },
        CiiTw: "CBasePlayer",
        jzadE: "m_aimPunchAngle",
        xYRgN: function(e, t) {
            return e * t
        },
        VzEok: function(e, t) {
            return e <= t
        },
        NYUJQ: function(e, t) {
            return e | t
        },
        AgBsM: function(e, t) {
            return e << t
        },
        ZOrws: function(e, t) {
            return e > t
        },
        jVbRO: function(e, t) {
            return e / t
        },
        HHNMS: function(e, t) {
            return e == t
        },
        GxAyQ: function(e, t) {
            return e == t
        },
        JiWdR: function(e, t) {
            return e * t
        },
        bytyZ: function(e, t) {
            return e < t
        },
        fbGkk: function(e, t) {
            return e * t
        },
        MbKMQ: function(e, t) {
            return e == t
        },
        rjSiU: function(e, t) {
            return e == t
        },
        umvzp: "8|7|4|6|3|5|1|9|2|11|10|0",
        qwRHp: function(e, t) {
            return e & t
        },
        Zvgsr: "Rage",
        adQRr: "Fake duck",
        oNnKH: "Anti Aim",
        VdjaH: function(e, t) {
            return e << t
        },
        EACOz: function(e, t, n, i, a) {
            return e(t, n, i, a)
        },
        THPtl: function(e, t) {
            return e == t
        },
        qqyXt: function(e, t) {
            return e * t
        },
        wgrJf: function(e, t) {
            return e | t
        },
        vlQuy: function(e, t, n) {
            return e(t, n)
        },
        SOTXb: function(e, t) {
            return e - t
        },
        zwwYL: function(e, t, n) {
            return e(t, n)
        },
        YOzTd: function(e, t, n) {
            return e(t, n)
        },
        HdGnW: function(e, t) {
            return e + t
        },
        rMRzk: function(e, t, n) {
            return e(t, n)
        },
        ZAtBz: function(e, t, n) {
            return e(t, n)
        },
        bQCZK: function(e, t) {
            return e | t
        },
        GOKNm: function(e, t) {
            return e << t
        },
        MngkA: function(e, t) {
            return e - t
        },
        LTsfp: function(e, t) {
            return e - t
        },
        IqbdX: function(e, t) {
            return e == t
        },
        ivYEP: "m_hGroundEntity",
        ebGrv: function(e, t) {
            return e == t
        },
        LOAty: function(e, t) {
            return e - t
        }
    };
    e.hbuDM(Globals.Frametime(), .015625) && (open = [], closed = [], found = !1, endnode = [], start = [], curpathnode = null, path = [], jumped = !1, last_viewangle = Local.GetViewAngles(), going_to_bombsite && (current_site = "a" == current_site ? "b" : "a"));
    var t = UI.GetValue(subtabb.concat(e.yoxdB)),
        n = !1,
        a = [],
        r = UI.GetValue(subtabb.concat("Settings"));
    if (!(UI.GetValue(subtabb.concat(e.HUUIR)) && UI.GetValue(["Misc.", e.sQCrx, "Keys", e.vUfdn, e.zqACS, e.nEAkQ, e.gWhgA]))) return open = [], closed = [], found = !1, endnode = [], start = [], curpathnode = null, path = [], fding && (UI.ToggleHotkey(["Rage", "SUBTAB_MGR", "Anti Aim", e.vUfdn, e.zqACS, "Key assignment", "Fake duck"]), fding = !1), jumped = !1, void(last_viewangle = Local.GetViewAngles());
    var o = Entity.GetLocalPlayer(),
        c = Entity.GetRenderOrigin(o),
        s = Entity.GetEnemies(),
        u = -1,
        l = 1 / 0,
        f = [],
        d = UI.GetValue(subtabb.concat("Targeting"));
    for (i in s)
        if (Entity.IsAlive(s[i]) && !Entity.IsDormant(s[i])) {
            var _ = Entity.GetRenderOrigin(s[i]),
                g = vecsub(_, c),
                v = e.JDgkE(vec_len, g),
                p = Entity.GetProp(s[i], e.iXxMv, e.UQxlW),
                y = Trace.Line(o, Entity.GetEyePosition(o), Entity.GetHitboxPosition(s[i], 5)),
                b = Render.WorldToScreen(Entity.GetHitboxPosition(s[i], 5));
            switch (y && y.length > 0 && y[0] == s[i] && !p && b[2] && f.push(s[i]), d) {
                case 0:
                    e.ngWVm(v, l) && !p && (l = v, u = s[i]);
                    break;
                case 1:
                    if (!p) {
                        var h = Entity.GetProp(s[i], e.iXxMv, "m_iHealth");
                        e.ngWVm(h, l) && !p && (l = h, u = s[i])
                    }
            }
        } if (e.hbuDM(f.length, 0)) {
        var m = -1,
            G = 180;
        for (i in f) {
            var E = calcang(Entity.GetEyePosition(o), Entity.GetHitboxPosition(f[i], 5));
            g = vec_sub(last_viewangle, E);
            (v = Math.hypot(g[0], g[1])) % 180 < G && (G = v, m = f[i])
        }
        if (-1 != m)
            for (var k = e.vgUrX.split("|"), M = 0;;) {
                switch (k[M++]) {
                    case "0":
                        UserCMD.SetViewAngles(U, !!(4 & t));
                        continue;
                    case "1":
                        last_viewangle[1] = lerp(last_viewangle[1], a[1], A, !1);
                        continue;
                    case "2":
                        a = e.UxDwp(calcang, Entity.GetEyePosition(o), C);
                        continue;
                    case "3":
                        var w = Entity.GetName(Entity.GetWeapon(o));
                        continue;
                    case "4":
                        return;
                    case "5":
                        u = m;
                        continue;
                    case "6":
                        var A = .1999999999998181;
                        continue;
                    case "7":
                        var R = vec_add(vecmulfl(anglevector(last_viewangle), 1e3), Entity.GetEyePosition(o));
                        continue;
                    case "8":
                        var C = Entity.GetHitboxPosition(u, Entity.GetCCSWeaponInfo(o).damage >= 100 ? 3 : 0);
                        continue;
                    case "9":
                        last_viewangle[0] = lerp(last_viewangle[0], a[0], A, !0);
                        continue;
                    case "10":
                        K = Trace.Line(o, Entity.GetEyePosition(o), R);
                        continue;
                    case "11":
                        var U = vecsub(last_viewangle, e.UxDwp(vecmulfl, Entity.GetProp(o, e.CiiTw, e.jzadE), Convar.GetFloat("weapon_recoil_scale")));
                        continue;
                    case "12":
                        if (K[0] == u) {
                            var S = Local.GetSpread(),
                                I = Local.GetInaccuracy(),
                                P = 150 * e.xYRgN(S, I);
                            e.VzEok(P, Local.GetSpread()) && (swap_in_attack = !swap_in_attack) && UserCMD.SetButtons(e.NYUJQ(UserCMD.GetButtons(), 1))
                        }
                        continue;
                    case "13":
                        if (-1 != scope_weps.indexOf(w)) !Entity.GetProp(o, e.iXxMv, "m_bIsScoped") && UserCMD.SetButtons(UserCMD.GetButtons() | e.AgBsM(1, 11));
                        continue
                }
                break
            }
    }
    var D = !1; - 1 == u && e.ZOrws(path.length, 0) && (D = !0), c[0] = Math.floor(e.jVbRO(c[0], space)) * space, c[1] = e.xYRgN(Math.floor(c[1] / space), space), c[2] = Math.floor(c[2] / space) * space, c[2] += space, e.HHNMS(start.length, 0) && (start = c);
    _ = Entity.GetRenderOrigin(u);
    if (e.GxAyQ(u, -1)) {
        var T = current_site,
            B = World.GetMapName();
        if (bombsite_pos[B])(_ = bombsite_pos[B][T])[2] -= space, going_to_bombsite = !0;
        else {
            var V = 500,
                L = Entity.GetTeammates();
            for (i in L)
                if (Entity.IsAlive(L[i])) {
                    var H = Entity.GetRenderOrigin(L[i]),
                        W = e.UxDwp(vec_sub, Entity.GetRenderOrigin(o), H);
                    e.ngWVm(W, V) && (V = W, _ = H)
                }
        }
    } else going_to_bombsite = !1;
    if (_[0] = e.xYRgN(Math.floor(_[0] / space), space), _[1] = Math.floor(_[1] / space) * space, _[2] = e.JiWdR(Math.floor(_[2] / space), space), _[2] += space, e.GxAyQ(open.length, 0) && open.push(new Node(start)), found) {
        if (!(8 & r))
            for (var z = e.umvzp.split("|"), O = 0;;) {
                switch (z[O++]) {
                    case "0":
                        if (e.qwRHp(t, 1) && e.ZOrws(le[1], 0) && fe[1] <= 0) !fding && (UI.ToggleHotkey([e.Zvgsr, "SUBTAB_MGR", "Anti Aim", e.vUfdn, e.zqACS, "Key assignment", e.adQRr]), fding = !0);
                        else {
                            if (fding && (UI.ToggleHotkey([e.Zvgsr, "SUBTAB_MGR", e.oNnKH, "SHEET_MGR", e.zqACS, e.nEAkQ, e.adQRr]), fding = !1), !D) {
                                C = Entity.GetHitboxPosition(u, Entity.GetCCSWeaponInfo(o).damage >= 100 ? 3 : 0);
                                var K = Trace.Line(o, Entity.GetEyePosition(o), C);
                                b = Render.WorldToScreen(C);
                                if (path[oe - 2].is(endnode)) 16 & UI.GetValue(subtabb.concat("Settings")) && (open = [], closed = [], found = !1, endnode = [], start = [], curpathnode = null, path = [], jumped = !1, last_viewangle = Local.GetViewAngles(), going_to_bombsite && (current_site = e.rjSiU(current_site, "a") ? "b" : "a"));
                                else if (e.rjSiU(K[0], u) && b[2] && 2 & t)
                                    for (var F = "5|0|1|8|9|4|2|6|11|7|10|3".split("|"), N = 0;;) {
                                        switch (F[N++]) {
                                            case "0":
                                                a = calcang(Entity.GetEyePosition(o), C);
                                                continue;
                                            case "1":
                                                last_viewangle[0] = lerp(last_viewangle[0], a[0], A, !0);
                                                continue;
                                            case "2":
                                                w = Entity.GetName(Entity.GetWeapon(o));
                                                continue;
                                            case "3":
                                                return;
                                            case "4":
                                                UserCMD.SetViewAngles(U, !!e.qwRHp(t, 4));
                                                continue;
                                            case "5":
                                                A = .20000000000004547;
                                                continue;
                                            case "6":
                                                if (-1 != scope_weps.indexOf(w)) !Entity.GetProp(o, "CCSPlayer", "m_bIsScoped") && UserCMD.SetButtons(e.NYUJQ(UserCMD.GetButtons(), e.VdjaH(1, 11)));
                                                continue;
                                            case "7":
                                                K = Trace.Line(o, Entity.GetEyePosition(o), R);
                                                continue;
                                            case "8":
                                                last_viewangle[1] = e.EACOz(lerp, last_viewangle[1], a[1], A, !1);
                                                continue;
                                            case "9":
                                                U = vecsub(last_viewangle, e.UxDwp(vecmulfl, Entity.GetProp(o, "CBasePlayer", e.jzadE), Convar.GetFloat("weapon_recoil_scale")));
                                                continue;
                                            case "10":
                                                if (e.THPtl(K[0], u)) {
                                                    S = Local.GetSpread(), I = Local.GetInaccuracy();
                                                    (P = e.qqyXt(S * I, 150)) <= Local.GetSpread() && (swap_in_attack = !swap_in_attack) && UserCMD.SetButtons(e.wgrJf(UserCMD.GetButtons(), 1))
                                                }
                                                continue;
                                            case "11":
                                                R = e.UxDwp(vec_add, vecmulfl(anglevector(last_viewangle), 1e3), Entity.GetEyePosition(o));
                                                continue
                                        }
                                        break
                                    }
                            }
                            if (path[oe - 2]) {
                                var j = calcang(e.vlQuy(vec_add, Entity.GetRenderOrigin(o), [0, 0, space]), path[e.SOTXb(oe, 2)].pos)[1],
                                    Q = e.vlQuy(vec_add, Entity.GetRenderOrigin(o), [0, 0, 30]),
                                    Y = e.zwwYL(vec_add, e.zwwYL(vecmulfl, anglevector([0, e.SOTXb(j, 45), 0]), 40), Q),
                                    Z = vec_add(e.YOzTd(vecmulfl, anglevector([0, e.HdGnW(j, 45), 0]), 40), Q),
                                    q = Trace.Line(o, Q, Y),
                                    X = Trace.Line(o, Q, Z);
                                lyaw = j, 1 != q[1] && (j += 45), 1 != X[1] && (j -= 45);
                                R = e.rMRzk(vecmulfl, e.JDgkE(anglevector, [0, j, 0]), 50);
                                var J = j - 0;
                                j = e.ZAtBz(calcang, vec_add(Entity.GetRenderOrigin(o), [0, 0, space]), path[oe - 2].pos)[1];
                                var $ = vec_add(Entity.GetRenderOrigin(o), [0, 0, 30]),
                                    ee = vec_add($, R),
                                    te = vec_add(Entity.GetRenderOrigin(o), [0, 0, 72]),
                                    ne = vec_add(te, R),
                                    ie = Trace.Line(o, $, ee);
                                if (1 != Trace.Line(o, te, ne)[1] && 1 == ie[1] && UserCMD.SetButtons(e.bQCZK(UserCMD.GetButtons(), e.GOKNm(1, 2))), j = J, e.ZAtBz(move_forward, [0, j, 0], 450), curpathnode = path[e.MngkA(oe, 2)], n = !0, a = calcang(e.ZAtBz(vec_add, Entity.GetRenderOrigin(o), [0, 0, space]), path[oe - 2].pos), e.ZOrws(a[0], 10) && (a[0] = 10), a[0] < -10 && (a[0] = -10), e.ZOrws(path[e.LTsfp(oe, 2)].pos[2], path[oe].pos[2]))
                                    if (jumped) UserCMD.SetButtons(4 | UserCMD.GetButtons()), !e.IqbdX(Entity.GetProp(o, e.iXxMv, e.ivYEP), e.ivYEP) && (jumped = !1);
                                    else UserCMD.SetButtons(2 | UserCMD.GetButtons()), jumped = !0;
                                is_wep_scopeable(Entity.GetWeapon(o)) && Entity.GetProp(o, e.iXxMv, "m_bIsScoped") && UserCMD.SetButtons(e.bQCZK(UserCMD.GetButtons(), 2048))
                            } else path = []
                        }
                        continue;
                    case "1":
                        if (e.ebGrv(oe, -1)) return;
                        continue;
                    case "2":
                        var ae = vec_add(Entity.GetRenderOrigin(o), [0, 0, 50]);
                        continue;
                    case "3":
                        ge = 1 / 0;
                        continue;
                    case "4":
                        for (;;) {
                            _e = ce;
                            if (path.push(_e), _e.is(new Node(start))) break;
                            ce = _e.parent
                        }
                        continue;
                    case "5":
                        for (i in path) {
                            var re = path[i].distTo(new Node(c));
                            y = Trace.Line(o, path[i].pos, vec_add(Entity.GetRenderOrigin(o), [0, 0, 30]));
                            re < ge && 1 == y[1] && (ge = re, oe = i)
                        }
                        continue;
                    case "6":
                        var oe = -1;
                        continue;
                    case "7":
                        path = [];
                        continue;
                    case "8":
                        var ce = endnode;
                        continue;
                    case "9":
                        if (e.bytyZ(e.LOAty(oe, 1), 0))
                            for (var se = "3|7|2|4|0|5|1|6".split("|"), ue = 0;;) {
                                switch (se[ue++]) {
                                    case "0":
                                        start = [];
                                        continue;
                                    case "1":
                                        jumped = !1;
                                        continue;
                                    case "2":
                                        found = !1;
                                        continue;
                                    case "3":
                                        open = [];
                                        continue;
                                    case "4":
                                        endnode = [];
                                        continue;
                                    case "5":
                                        fding && (UI.ToggleHotkey([e.Zvgsr, e.sQCrx, "Anti Aim", e.vUfdn, e.zqACS, e.nEAkQ, "Fake duck"]), fding = !1);
                                        continue;
                                    case "6":
                                        return;
                                    case "7":
                                        closed = [];
                                        continue
                                }
                                break
                            }
                        continue;
                    case "10":
                        if (!D) var le = Trace.Bullet(o, u, de, Entity.GetHitboxPosition(u, 0)),
                            fe = Trace.Bullet(o, u, ae, Entity.GetHitboxPosition(u, 0));
                        continue;
                    case "11":
                        var de = e.ZAtBz(vec_add, Entity.GetRenderOrigin(o), [0, 0, 72]);
                        continue
                }
                break
            }
    } else {
        var _e = null,
            ge = 1 / 0;
        for (i in open)
            if (e.bytyZ(open[i].cost, ge)) {
                var ve = !1;
                for (x in closed)
                    if (closed[x].is(open[i])) {
                        ve = !0;
                        break
                    }! ve && (ge = open[i].cost, _e = open[i])
            } if (null == _e) return;
        if (!_e.is(new Node(c)) && _e.distTo(new Node(_)) < e.fbGkk(space, 2)) return found = !0, void(endnode = _e);
        open.splice(open.indexOf(_e), 1), closed.push(_e);
        var pe = _e.neighbours(new Node(_));
        if (1 == (y = Trace.Line(o, _e.pos, pe[1].pos))[1]) {
            ve = !1;
            for (i in closed)
                if (closed[i].is(pe[1])) {
                    ve = !0;
                    break
                } if (!ve) return void open.push(pe[1])
        }
        for (i in pe) {
            ve = !1;
            var ye = null;
            for (x in closed)
                if (closed[x].is(pe[i])) {
                    ve = !0, ye = closed[x];
                    break
                } if (ve) e.ZOrws(ye.cost, pe[i].cost) && (ye = pe[i]);
            else if (!(1 != (y = Trace.Line(o, _e.pos, pe[i].pos))[1])) {
                if (e.MbKMQ(i, 0) && (y = Trace.Line(o, _e.pos, vec_add(_e.pos, [0, 0, -30])), e.rjSiU(y[1], 1))) continue;
                open.push(pe[i])
            }
        }
    }
    if (n) {
        A = .1999999999998181;
        last_viewangle[0] = lerp(last_viewangle[0], a[0], A, !0), last_viewangle[1] = e.EACOz(lerp, last_viewangle[1], a[1], A, !1), UserCMD.SetViewAngles(last_viewangle, !!(4 & t))
    }
}

function draw_walkbot() {
    for (var e = "SUBTAB_MGR", t = "Anti Aim", n = "SHEET_MGR", a = "General", r = function(e, t) {
            return e & t
        }, o = function(e, t, n) {
            return e(t, n)
        }, c = function(e, t, n) {
            return e(t, n)
        }, s = function(e, t) {
            return e - t
        }, u = function(e, t) {
            return e != t
        }, l = "2|5|3|4|0|1|6".split("|"), f = 0;;) {
        switch (l[f++]) {
            case "0":
                if (2 & G) {
                    var d = [],
                        _ = !0;
                    for (i in open)
                        for (var g = "1|0|2|3|4".split("|"), v = 0;;) {
                            switch (g[v++]) {
                                case "0":
                                    var p = Render.WorldToScreen(y.pos);
                                    continue;
                                case "1":
                                    var y = open[i];
                                    continue;
                                case "2":
                                    !_ && Render.Line(p[0], p[1], d[0], d[1], [255, 255, 255, 255]);
                                    continue;
                                case "3":
                                    d = p;
                                    continue;
                                case "4":
                                    _ = !1;
                                    continue
                            }
                            break
                        }
                }
                continue;
            case "1":
                if (4 & G && found) {
                    var b = !1,
                        h = endnode;
                    for (d = [], _ = !0; !b;) {
                        var m = (y = h).pos;
                        p = Render.WorldToScreen(m);
                        if (!_ && Render.Line(p[0], p[1], d[0], d[1], [0, 255, 0, 255]), y.is(new Node(start))) {
                            b = !0;
                            break
                        }
                        d = p, _ = !1, h = y.parent
                    }
                }
                continue;
            case "2":
                var G = UI.GetValue(subtabb.concat("Settings"));
                continue;
            case "3":
                if (!Entity.IsAlive(R))
                    for (var E = "6|8|9|7|4|2|0|3|1|5|10".split("|"), k = 0;;) {
                        switch (E[k++]) {
                            case "0":
                                path = [];
                                continue;
                            case "1":
                                jumped = !1;
                                continue;
                            case "2":
                                curpathnode = null;
                                continue;
                            case "3":
                                fding && (UI.ToggleHotkey(["Rage", e, t, n, a, "Key assignment", "Fake duck"]), fding = !1);
                                continue;
                            case "4":
                                start = [];
                                continue;
                            case "5":
                                last_viewangle = Local.GetViewAngles();
                                continue;
                            case "6":
                                open = [];
                                continue;
                            case "7":
                                endnode = [];
                                continue;
                            case "8":
                                closed = [];
                                continue;
                            case "9":
                                found = !1;
                                continue;
                            case "10":
                                return
                        }
                        break
                    }
                continue;
            case "4":
                if (r(G, 64)) {
                    var M = vec_add(Entity.GetRenderOrigin(R), [0, 0, 30]),
                        w = Render.WorldToScreen(o(vec_add, c(vecmulfl, anglevector([0, s(lyaw, 45), 0]), 50), M)),
                        A = Render.WorldToScreen(c(vec_add, c(vecmulfl, anglevector([0, lyaw + 45, 0]), 50), M));
                    M = Render.WorldToScreen(M), Render.Line(M[0], M[1], w[0], w[1], [255, 0, 0, 255]), Render.Line(M[0], M[1], A[0], A[1], [0, 0, 255, 255])
                }
                continue;
            case "5":
                var R = Entity.GetLocalPlayer();
                continue;
            case "6":
                if (r(G, 16) && u(curpathnode, null)) {
                    p = Render.WorldToScreen(Entity.GetRenderOrigin(Entity.GetLocalPlayer()));
                    var C = Render.WorldToScreen(curpathnode.pos);
                    Render.Line(p[0], p[1], C[0], C[1], [0, 0, 255, 255])
                }
                continue
        }
        break
    }
}
var points = [],
    _draw = !1;

function HSVtoRGB(e, t, n) {
    var i, a, r, o, c, s, u, l, f = function(e, t) {
            return e - t
        },
        d = function(e, t) {
            return e - t
        },
        _ = function(e, t) {
            return e * t
        },
        g = function(e, t) {
            return e - t
        },
        v = function(e, t) {
            return e - t
        },
        p = function(e, t) {
            return e % t
        },
        y = function(e, t) {
            return e * t
        };
    switch (1 === arguments.length && (t = e.s, n = e.v, e = e.h), c = f(6 * e, o = Math.floor(6 * e)), s = n * f(1, t), u = n * d(1, c * t), l = _(n, g(1, _(v(1, c), t))), p(o, 6)) {
        case 0:
            i = n, a = l, r = s;
            break;
        case 1:
            i = u, a = n, r = s;
            break;
        case 2:
            i = s, a = n, r = l;
            break;
        case 3:
            i = s, a = u, r = n;
            break;
        case 4:
            i = l, a = s, r = n;
            break;
        case 5:
            i = n, a = s, r = u
    }
    return [Math.round(y(i, 255)), Math.round(255 * a), Math.round(255 * r), 255]
}

function zeus_cm() {
    for (var e = "Visuals", t = "Extra", n = "Impacts", a = "Better knife range", r = function(e, t) {
            return e * t
        }, o = function(e, t) {
            return e * t
        }, c = function(e, t) {
            return e / t
        }, s = function(e, t, n) {
            return e(t, n)
        }, u = "6|4|10|11|8|7|1|3|2|0|9|5".split("|"), l = 0;;) {
        switch (u[l++]) {
            case "0":
                var f = UI.GetValue([e, t, "Impacts", "Step amnt"]);
                continue;
            case "1":
                if (h.includes("zeus")) {
                    var d = G;
                    UI.GetValue([e, t, n, "Better zeus range"]) && (_draw = !0)
                } else if (h.includes("knife")) {
                    d = m;
                    UI.GetValue([e, t, n, a]) && (_draw = !0)
                }
                continue;
            case "2":
                points = [];
                continue;
            case "3":
                if (!_draw) return;
                continue;
            case "4":
                var _ = vec_sub(Entity.GetEyePosition(b), [0, 0, 10]);
                continue;
            case "5":
                for (i = 0; i <= 360; i += f) {
                    var g = r(Math.sin(o(i / 180, Math.PI)), d),
                        v = Math.cos(c(i, 180) * Math.PI) * d,
                        p = s(vec_add, _, [g, v, 0]),
                        y = Trace.Line(b, _, p);
                    p = [g *= y[1], v *= y[1], 0], points.push(p)
                }
                continue;
            case "6":
                var b = Entity.GetLocalPlayer();
                continue;
            case "7":
                var h = Entity.GetName(Entity.GetWeapon(b));
                continue;
            case "8":
                _draw = !1;
                continue;
            case "9":
                0 == f && (f = 5);
                continue;
            case "10":
                var m = 64;
                continue;
            case "11":
                var G = 150;
                continue
        }
        break
    }
}

function zeus_draw() {
    for (var e = "Impacts", t = function(e, t) {
            return e % t
        }, n = function(e, t) {
            return e / t
        }, a = "Visuals", r = "Extra", o = "Rainbow range", c = "0|2|8|6|3|7|1|9|4|5".split("|"), s = 0;;) {
        switch (c[s++]) {
            case "0":
                if (!_draw) return;
                continue;
            case "1":
                var u = UI.GetColor(["Visuals", "Extra", e, "Range col"]);
                continue;
            case "2":
                var l = Entity.GetLocalPlayer();
                continue;
            case "3":
                var f = !0;
                continue;
            case "4":
                var d = u[3];
                continue;
            case "5":
                for (i in points) {
                    y && ((u = HSVtoRGB(t(n(i, points.length) + Globals.Realtime() / 2, 1), 1, 1))[3] = d);
                    var _ = vec_add(points[i], v),
                        g = Render.WorldToScreen(_);
                    UI.GetValue([a, r, e, "Dotted"]) ? Render.FilledCircle(g[0], g[1], 1, u) : (!f && g[2] && Render.Line(p[0], p[1], g[0], g[1], u), f = !1, p = g)
                }
                continue;
            case "6":
                var v = vec_sub(Entity.GetEyePosition(l), [0, 0, 10]);
                continue;
            case "7":
                var p = [];
                continue;
            case "8":
                if (!Entity.IsAlive(l)) return;
                continue;
            case "9":
                var y = UI.GetValue([a, "Extra", e, o]);
                continue
        }
        break
    }
}
UI.AddCheckbox(["Visuals", "Extra", "Impacts"], "Better knife range"), UI.AddCheckbox(["Visuals", "Extra", "Impacts"], "Better zeus range"), UI.AddCheckbox(["Visuals", "Extra", "Impacts"], "Rainbow range"), UI.AddColorPicker(["Visuals", "Extra", "Impacts"], "Range col"), UI.AddSliderInt(["Visuals", "Extra", "Impacts"], "Step amnt", 0, 360), UI.AddCheckbox(["Visuals", "Extra", "Impacts"], "Dotted"), Cheat.RegisterCallback("Draw", "zeus_draw"), Cheat.RegisterCallback("CreateMove", "zeus_cm"), Cheat.RegisterCallback("Draw", "draw_walkbot"), Cheat.RegisterCallback("CreateMove", "cm_walkbot");
var variables = {
    recharge_time: Globals.Curtime() + 1,
    rage_target: -1,
    time_since_shot: -1,
    wasnt_dting: !1
};

function is_trying_to_dt() {
    var e = "Rage",
        t = "SUBTAB_MGR",
        n = "SHEET_MGR",
        i = "Keys",
        a = "Double tap",
        r = "Anti Aim",
        o = "General";
    return UI.GetValue([e, t, "Exploits", n, i, "Key assignment", a]) && UI.GetValue([e, t, "Exploits", n, "General", a]) && !UI.GetValue(["Rage", r, o, "Key assignment", "Fake duck"])
}

function is_trying_to_hs() {
    var e = "SUBTAB_MGR",
        t = "Exploits",
        n = "Keys",
        i = "SHEET_MGR",
        a = "Hide shots",
        r = "Rage",
        o = "Anti Aim",
        c = "General";
    return UI.GetValue(["Rage", e, t, "SHEET_MGR", n, "Key assignment", "Hide shots"]) && UI.GetValue(["Rage", e, t, i, "General", a]) && !UI.GetValue([r, o, c, "Key assignment", "Fake duck"])
}

function rage_fire() {
    is_trying_to_dt() && (variables.rage_target = Event.GetInt("target_index"))
}

function fastdt_cm() {
    var e = {
        yCfYa: "1|5|0|3|4|2",
        McdwS: function(e, t) {
            return e != t
        },
        UhiRk: function(e, t) {
            return e > t
        },
        wyueS: function(e, t) {
            return e - t
        }
    };
    if (settings.fast_recharge) {
        if (!is_trying_to_dt())
            for (var t = e.yCfYa.split("|"), n = 0;;) {
                switch (t[n++]) {
                    case "0":
                        Exploit.OverrideMaxProcessTicks(14);
                        continue;
                    case "1":
                        variables.wasnt_dting = !0;
                        continue;
                    case "2":
                        return;
                    case "3":
                        Exploit.OverrideShift(0);
                        continue;
                    case "4":
                        Exploit.OverrideTolerance(0);
                        continue;
                    case "5":
                        Exploit.EnableRecharge();
                        continue
                }
                break
            }
        variables.wasnt_dting && (variables.wasnt_dting = !1, variables.recharge_time = Globals.Curtime()), Exploit.DisableRecharge();
        var i = Exploit.GetCharge(),
            a = Globals.Curtime(),
            r = [];
        if (e.McdwS(variables.rage_target, -1)) {
            var o = Entity.GetHitboxPosition(variables.rage_target, 3);
            if ((r = Trace.Bullet(Entity.GetLocalPlayer(), variables.rage_target, Entity.GetEyePosition(Entity.GetLocalPlayer()), o)) && r.length > 0)
                if (r[1] > 0) return
        }
        e.UhiRk(a, variables.recharge_time) && (-1 == variables.rage_target || !Entity.IsAlive(variables.rage_target) || Entity.IsDormant(variables.rage_target) || e.wyueS(Globals.Curtime(), variables.time_since_shot) > 1) && (variables.time_since_shot = 1 / 0, variables.rage_target = -1, Exploit.Recharge(), 1 == i && (variables.recharge_time = 1 / 0))
    } else Exploit.EnableRecharge()
}

function isPeeking(e) {
    var t = function(e, t) {
            return e * t
        },
        n = "m_vecVelocity[0]",
        i = function(e, t, n) {
            return e(t, n)
        },
        a = Entity.GetProp(Entity.GetLocalPlayer(), "CBasePlayer", n);
    a = i(vec_add, e, a = a.map(function(e) {
        return t(e, .1999999999998181)
    }));
    var r = Entity.GetEnemies();
    for (var o in r.filter(function(e) {
            return !Entity.IsDormant(e) && Entity.IsValid(e)
        })) {
        var c = Trace.Line(r[o], Entity.GetEyePosition(r[o]), a);
        if (c && c[1] && 1 == c[1]) return !0
    }
    return !1
}
Cheat.RegisterCallback("CreateMove", "fastdt_cm"), Cheat.RegisterCallback("ragebot_fire", "rage_fire");