const global_get_screen_size = Global.GetScreenSize, global_choked_commands = Globals.ChokedCommands, global_realtime = Globals.Realtime, global_frametime = Globals.Frametime, global_curtime = Globals.Curtime, global_tick_interval = Globals.TickInterval, global_tickrate = Globals.Tickrate, global_tickcount = Globals.Tickcount, global_frame_stage = Globals.FrameStage, ui_get_menu_position = UI.GetMenuPosition, ui_update_list = UI.UpdateList, ui_remove_item = UI.RemoveItem, ui_get_hotkey = UI.GetHotkey, ui_set_hotkey_state = UI.SetHotkeyState, ui_get_hotkey_state = UI.GetHotkeyState, ui_toggle_hotkey = UI.ToggleHotkey, ui_set_color = UI.SetColor, ui_add_sub_tab = UI.AddSubTab, ui_add_textbox = UI.AddTextbox, ui_add_color_picker = UI.AddColorPicker, ui_add_multi_dropdown = UI.AddMultiDropdown, ui_add_dropdown = UI.AddDropdown, ui_add_hotkey = UI.AddHotkey, ui_add_slider_float = UI.AddSliderFloat, ui_add_slider_int = UI.AddSliderInt, ui_add_checkbox = UI.AddCheckbox, ui_set_value = UI.SetValue, ui_get_children = UI.GetChildren, ui_get_value = UI.GetValue, ui_get_string = UI.GetString, ui_get_color = UI.GetColor, ui_is_menu_open = UI.IsMenuOpen, ui_set_enabled = UI.SetEnabled, entity_draw_flag = Entity.DrawFlag, entity_get_ccs_weapon_info = Entity.GetCCSWeaponInfo, entity_get_render_box = Entity.GetRenderBox, entity_get_weapons = Entity.GetWeapons, entity_get_entities_by_class_id = Entity.GetEntitiesByClassID, entity_get_hitbox_position = Entity.GetHitboxPosition, entity_get_eye_position = Entity.GeteyePosition, entity_get_game_rules_proxy = Entity.GetGameRulesProxy, entity_is_bot = Entity.IsBot, entity_get_weapon = Entity.GetWeapon, entity_set_prop = Entity.SetProp, entity_get_prop = Entity.GetProp, entity_get_render_origin = Entity.GetRenderOrigin, entity_get_name = Entity.GetName, entity_get_class_name = Entity.GetClassName, entity_get_class_id = Entity.GetClassID, entity_is_dormant = Entity.IsDormant, entity_is_alive = Entity.IsAlive, entity_is_valid = Entity.IsValid, entity_is_local_player = Entity.IsLocalPlayer, entity_is_enemy = Entity.IsEnemy, entity_is_teammate = Entity.IsTeammate, entity_get_entity_from_user_id = Entity.GetEntityFromUserID, entity_get_local_player = Entity.GetLocalPlayer, entity_get_teammates = Entity.GetTeammates, entity_get_enemies = Entity.GetEnemies, entity_get_players = Entity.GetPlayers, entity_get_entities = Entity.GetEntities, render_text_size = Render.TextSize, render_string = Render.String, render_filled_circle = Render.FilledCircle, render_textured_rect = Render.TexturedRect, render_add_texture = Render.AddTexture, render_find_font = Render.FindFont, render_add_font = Render.AddFont, render_polygon = Render.Polygon, render_gradient_rect = Render.GradientRect, render_get_screen_size = Render.GetScreenSize, render_world_to_screen = Render.WorldToScreen, render_circle = Render.Circle, render_filled_rect = Render.FilledRect, render_rect = Render.Rect, render_line = Render.Line, convar_set_string = Convar.SetString, convar_get_string = Convar.GetString, convar_set_float = Convar.SetFloat, convar_get_float = Convar.GetFloat, convar_set_int = Convar.SetInt, convar_get_int = Convar.GetInt, event_get_string = Event.GetString, event_get_float = Event.GetFloat, event_get_int = Event.GetInt, trace_raw_line = Trace.RawLine, trace_smoke = Trace.Smoke, trace_bullet = Trace.Bullet, trace_line = Trace.Line, usercmd_get_movement = UserCMD.GetMovement, usercmd_set_view_angles = UserCMD.SetViewAngles, usercmd_send = UserCMD.Send, usercmd_choke = UserCMD.Choke, usercmd_set_buttons = UserCMD.SetButtons, usercmd_get_buttons = UserCMD.GetButtons, usercmd_set_movement = UserCMD.SetMovement, sound_stop_microphone = Sound.StopMicrophone, sound_play_microphone = Sound.PlayMicrophone, sound_play = Sound.Play, local_get_inaccuracy = Local.GetInaccuracy, local_get_spread = Local.GetSpread, local_get_fake_yaw = Local.GetFakeYaw, local_get_real_yaw = Local.GetRealYaw, local_set_clan_tag = Local.SetClanTag, local_set_view_angles = Local.SetViewAngles, local_get_view_angles = Local.GetViewAngles, local_latency = Local.Latency, cheat_is_legit_config_active = Cheat.IsLegitConfigActive, cheat_is_rage_config_active = Cheat.IsRageConfigActive, cheat_get_username = Cheat.GetUsername, cheat_print_chat = Cheat.PrintChat, cheat_register_callback = Cheat.RegisterCallback, cheat_execute_command = Cheat.ExecuteCommand, cheat_print_color = Cheat.PrintColor, cheat_print = Cheat.Print, input_force_cursor = Input.ForceCursor, input_get_cursor_position = Input.GetCursorPosition, input_is_key_pressed = Input.IsKeyPressed, world_get_server_string = World.GetServerString, world_get_map_name = World.GetMapName, antiaim_set_lby_offset = AntiAim.SetLBYOffset, antiaim_set_real_offset = AntiAim.SetRealOffset, antiaim_set_fake_offset = AntiAim.SetFakeOffset, antiaim_get_override = AntiAim.GetOverride, antiaim_set_override = AntiAim.SetOverride, exploit_override_tolerance = Exploit.OverrideTolerance, exploit_override_shift = Exploit.OverrideShift, exploit_override_ticks = Exploit.OverrideMaxProcessTicks, exploit_enable_recharge = Exploit.EnableRecharge, exploit_disable_recharge = Exploit.DisableRecharge, exploit_recharge = Exploit.Recharge, exploit_get_charge = Exploit.GetCharge, ragebot_get_targets = Ragebot.GetTargets, ragebot_ignore_target = Ragebot.IgnoreTarget, ragebot_force_hitbox_safety = Ragebot.ForceHitboxSafety, ragebot_force_target_minimum_damage = Ragebot.ForceTargetMinimumDamage, ragebot_force_target_hitchance = Ragebot.ForceTargetHitchance, ragebot_force_target_safety = Ragebot.ForceTargetSafety, ragebot_force_target = Ragebot.ForceTarget, ragebot_get_target = Ragebot.GetTarget, material_refresh = Material.Refresh, material_set_key_value = Material.SetKeyValue, material_get = Material.Get, material_destroy = Material.Destroy, material_create = Material.Create, global_lul = Global.GetUsername;

ui_add_hotkey(["Rage", "Anti Aim", "General", "Key assignment"], "Legit AA", "Legit AA")
// AA Tab -- Start

// General Sheet -- Start
const setvalaa1 = function(name, value){
    return ui_set_value(["Rage", "Anti Aim", "General", name], value);
}

const getvalaa1 = function(name){
    return ui_get_value(["Rage", "Anti Aim", "General", name]);
}
const getvalaa1key = function(name){
    return ui_get_value(["Rage", "Anti Aim", "General", "Key assignment", name]);
}
// General Sheet -- End

// Direction Sheet -- Start
const setvalaa2 = function(name, value){
    return ui_set_value(["Rage", "Anti Aim", "Directions", name], value);
}
const getvalaa2 = function(name){
    return ui_get_value(["Rage", "Anti Aim", "Directions", name]);
}
// Direction Sheet -- End

// Fake Sheet -- Start
const setvalaa3 = function(name, value){
    return ui_set_value(["Rage", "Anti Aim", "Directions", name], value);
}
const getvalaa3 = function(name){
    return ui_get_value(["Rage", "Anti Aim", "Directions", name]);
}
// Fake Sheet -- End

// AA Tab -- End

const time = global_realtime();
var is_defusing = false;
var original_aa = true;
var E = false;

function onDraw( ) {
    var defusing = entity_get_prop(entity_get_local_player(), "CCSPlayer", "m_bIsDefusing")
    var holding = entity_get_weapon(entity_get_local_player()) == 116;
    var planted = entity_get_entities_by_class_id(128);
    //var buttons = UserCMD.GetButtons();
    if(!planted) {
        onReset()
    }
    var buttons = usercmd_get_buttons();
    if(!is_defusing && getvalaa1key("Legit AA"))
    {
        if (original_aa)
        {
            restrictions_cache = ui_get_value(["Config", "Cheat", "General", "Restrictions"]);
            yaw_offset_cache = getvalaa2("Yaw offset");
            jitter_offset_cache = getvalaa2("Jitter offset");
            pitch_cache = getvalaa1("Pitch mode");
            at_tar = getvalaa2("At targets");
            original_aa = false;
        }
        ui_set_value(["Config", "Cheat", "General", "Restrictions"], 0);
        setvalaa2("Yaw offset", 180);
        setvalaa2("Jitter offset", 0);
        setvalaa1("Pitch mode", 0);
        setvalaa2("At targets", 0);
      
        E = false;
        if(Globals.Realtime() >= time + 0.2){
            if(E == false){
                Cheat.ExecuteCommand("+use");
                E = true;
            }
            if(E == true){
                Cheat.ExecuteCommand("-use");
            }
        }else{
            if(E == true){
                Cheat.ExecuteCommand("-use");
                E = false;
            }
        }
        time = Globals.Realtime();
    }
    else
    {
        if (!original_aa)
        {
            ui_set_value(["Config", "Cheat", "General", "Restrictions"], restrictions_cache);
            setvalaa2("Yaw offset", yaw_offset_cache);
            setvalaa2("Jitter offset", jitter_offset_cache);
            setvalaa1("Pitch mode", pitch_cache);
            setvalaa2("At targets", at_tar)
            original_aa = true;
            is_defusing = false;
        }
    }
    //cheat_print(entity_get_prop(entity_get_local_player(), "CCSPlayer", "m_bIsDefusing") + "\n")
    //cheat_print(im_tired_of_trying_so_many_different_things_so_this_will_be_disabled_when_bomb_is_planted + "\n")
    //Cheat.Print(distance +"\n");
}

function onDefuse( ) {
    const userid = entity_get_entities_by_class_id( event_get_int( "userid" ) );

    if ( Entity.IsLocalPlayer( userid ) )
        is_defusing = true;
}

function onReset( ) {
    is_defusing = false;
}

Cheat.RegisterCallback( "CreateMove", "onDraw" );
Cheat.RegisterCallback( "bomb_begindefuse", "onDefuse" );
Cheat.RegisterCallback( "bomb_abortdefuse", "onReset" );
Cheat.RegisterCallback( "round_start", "onReset" );
Cheat.RegisterCallback( "player_connect_full", "onReset" );