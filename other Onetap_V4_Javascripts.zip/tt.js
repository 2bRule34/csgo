UI.AddCheckbox(["Misc.", "Helpers", "Sound"], "Kill Spam")

var sayWhat =
[
    "eins du kek",
        "setz dich hin",
        "braver hund",
        "überrollt du noname",
        "gib bitte deine mogelsoftware zurück",
        "gefickt du hurensohn",
        "dein kopierte software wird dir nicht viel helfen",
        "warum versuchst du es überhaupt noch?",
        "gutes mogelmodul hast du da",
        "kann man deine konfiguration kaufen?",
        "warum so schlecht?",
        "leider überrannt",
        "noname",
        "überfahreNN",
        "machst aber fein sitz",
        "du bist ein hund",
        "warum so ein kek?",
        "wo hast du spielen gelernt?",
        "benutzt du novo.lose oder was?",
        "unity user i guess",
        "uff ya hdf",
        "halt die fresse",
        "hdf",
        "hartz4 gleich weider ziehen",
		"ich hasse neger",
		"du schwuchtel",
		"übergewicht",
		"nutte",
        "1",
        "eins",
        "hahaha",
        "hahahhaaah",
        "hahahaahahahhaha",
        "brich jetzt nicht in wut aus",
        "weini weini",
		"Tritt doch unserem Konfigurations-Discord bei für gute Konfigurationen! - discord.io/cfgleaks",
		"piss dich du hs",
		"guter kopfschuss!",
		"trash bot",
		"das ist viel zu einfach",
		"geh in die küche du frau",
		"neue friseur habe ich dir verpasst",
		"Gefällr dir das?",
		"Guter schuss!",
		"da zuckt nix!",
		"Man kann in CSGO nicht cheaten!",
		"Ich würde niemals cheaten...",
		"Wasserkopf wurde getroffen!",
        "kräftig auf den arm genommen habe ich dich",
        "erhitz jetzt nicht dein Gemüt",
        "krieg es nicht in den falschen Hals",
        "was ist deine UID",
	"Aus dem Weg du Geringverdiener!",
	
];

function getRandomArrayElement(arr){
    var min = 0;
    var max = (arr.length - 1);
    var randIndex = Math.floor(Math.random() * (max - min)) + min;
    return arr[randIndex];
}

function onPlayerDeath() {
    if (!UI.GetValue(["Misc.","Helpers","Sound","Kill Spam"])) return;

    attacker = Event.GetInt("attacker");
    attacker_index = Entity.GetEntityFromUserID(attacker);
    attacker_name = Entity.GetName(attacker_index);
    attacker_me = Entity.IsLocalPlayer(attacker_index);

    if (attacker_me) {
        Global.ExecuteCommand("say " + getRandomArrayElement(sayWhat));
    }
}


Global.RegisterCallback("player_death", "onPlayerDeath");