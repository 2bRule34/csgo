UI.AddSubTab(['Config', 'SUBTAB_MGR'], 'Burberry');
UI.AddSubTab(['Config', 'SUBTAB_MGR'], 'Indicators');

function create_move() {
    if (UI.GetValue(['Rage', 'Anti Aim', 'General', 'Key assignment', 'Fake duck'])) {
        Exploit.OverrideMaxProcessTicks(16);
        Exploit.OverrideTolerance(0);
        Exploit.OverrideShift(14)
    } else {
        Exploit.OverrideMaxProcessTicks(17);
        Exploit.OverrideTolerance(0);
        Exploit.OverrideShift(15)
    }
}
Cheat.RegisterCallback('CreateMove', 'create_move');
const path = ['Config', 'Burberry', 'Burberry'];
UI.AddHotkey(['Config', 'Scripts', 'Keys', 'JS Keybinds'], 'Minimum damage override', 'Minimum damage');
var wep2tab = {
    "usp s": 'USP',
    "glock 18": 'Glock',
    "dual berettas": 'Dualies',
    "r8 revolver": 'Revolver',
    "desert eagle": 'Deagle',
    "p250": 'P250',
    "tec 9": 'Tec-9',
    "mp9": 'MP9',
    "mac 10": 'Mac10',
    "pp bizon": 'PP-Bizon',
    "ump 45": 'UMP45',
    "ak 47": 'AK47',
    "sg 553": 'SG553',
    "aug": 'AUG',
    "m4a1 s": 'M4A1-S',
    "m4a4": 'M4A4',
    "ssg 08": 'SSG08',
    "awp": 'AWP',
    "g3sg1": 'G3SG1',
    "scar 20": 'SCAR20',
    "xm1014": 'XM1014',
    "mag 7": 'MAG7',
    "m249": 'M249',
    "negev": 'Negev',
    "p2000": 'General',
    "famas": 'FAMAS',
    "five seven": 'Five Seven',
    "mp7": 'MP7',
    "ump 45": 'UMP45',
    "p90": 'P90',
    "cz75 auto": 'CZ-75',
    "mp5 sd": 'MP5',
    "galil ar": 'GALIL',
    "sawed off": 'Sawed off'
};
var tab_names = ['General', 'USP', 'Glock', 'Five Seven', 'Tec-9', 'Deagle', 'Revolver', 'Dualies', 'P250', 'CZ-75', 'Mac10', 'P90', 'MP5', 'MP7', 'MP9', 'UMP45', 'PP-Bizon', 'M4A1-S', 'M4A4', 'AK47', 'AUG', 'SG553', 'FAMAS', 'GALIL', 'AWP', 'SSG08', 'SCAR20', 'G3SG1', 'M249', 'XM1014', 'MAG7', 'Negev', 'Sawed off'];

function setup_menu() {
    for (k in tab_names) {
        UI.AddSliderInt(['Rage', 'Target', tab_names[k]], 'Minimum damage override', 0, 100)
    }
}
setup_menu();

function pew() {
    if (UI.GetValue(['Config', 'Scripts', 'Keys', 'JS Keybinds', 'Minimum damage override'])) {
        var _0x96CB = wep2tab[Entity.GetName(Entity.GetWeapon(Entity.GetLocalPlayer()))];
        if (_0x96CB == undefined) {
            _0x96CB = 'General'
        };
        var _0x9692 = UI.GetValue(['Rage', 'Target', _0x96CB, 'Minimum damage override']);
        if (_0x9692 == 0 && _0x96CB != 'General') {
            _0x9692 = UI.GetValue(['Rage', 'Target', 'General', 'Minimum damage override'])
        };
        var _0x9659 = Entity.GetEnemies();
        for (e in _0x9659) {
            Ragebot.ForceTargetMinimumDamage(_0x9659[e], _0x9692)
        }
    }
}
Cheat.RegisterCallback('CreateMove', 'pew');
const burba = ['min', 'tM9IBgu=', 'tK9cteu=', 'wYbUB2jSzsbDigXLyw5PBMC=', 'GetScreenSize', 'CMLNAhq=', 'r2v0rMfRzvLHDW==', '[ burb ] freestanding  ', 'C2v0DxbFzM9UDhm=', 'GetViewAngles', 'u2v0rw5HyMXLza==', 'Unload', 'safety', 'BgvMDa==', 'r2v0tg9JywXqBgf5zxi=', 'r2v0uhjVCa==', 'GetLocalPlayer', 'ug9SEwDVBG==', 'cos', 'q29UzMLN', 'JS Keybinds', 'RawLine', 'GetCharge', 'y29Z', 'Tickcount', 'right', 'zgf0yq==', 'freestanding', 'Config', 'small', 'SetEnabled', 'qw50AsbbAw0=', 'AddMultiDropdown', 'AddSubTab', 'q3jLyxrLtw92zq==', 'ANvTCgLUzW==', 'r2v0u2nYzwvUu2L6zq==', 'wYbUB2jSzsbDigfUDgKTywLT', 'Bv9MrMXHz3m=', 'length', 'toFixed', 'yxbWBhK=', 'C2LU', 'wYbUB2jSzsbDigzYzwvZDgfUzgLUzYaGia==', 'r3jHzgLLBNrszwn0', 'data', 'r2vUzxjHBa==', 'setup_fonts', 'BwfPBG==', 'u2v0t3zLCNjPzgu=', 'condition', 'r2v0vMfSDwu=', 'onUnload', 'GetValue', 'CBasePlayer', 'zxLL', 'toString', 'GetProp', 'C2XPy2u=', 'Scripts', 's2v5igfZC2LNBM1LBNq=', 'Add', 'OutlineString', 'y29UzgL0Aw9U', 'wYbUB2jSzsbDigzYzwvZDgfUzgLUzW==', 'RegisterCallback', 'BI9H', 'abs', 'wYbUB2jSzsbDihnHzMv0EsaG', 'yxnJvxm=', 'r2v0rxLLug9ZAxrPB24=', 'last_condition', 'qwrKrM9UDa==', '[ burb ] inverter', 'wYbUB2jSzsbDigzYzwvZDgfUzgLUzYa=', 'y29Uy2f0', 'uMvNAxn0zxjdywXSyMfJAW==', 'u3rYAw5N', 'IsMenuOpen', 'vgLJA0LUDgvYDMfS', '[ burb ] condition', 'IsAlive', 'm_vecVelocity[0]', 'GetFakeYaw', 'verdanab', 'ywjZ', 'C2fMzxr5', 'main', '[ burb ] leaning   ', 'rLjbtuvFuKvorevsx1nuqvju', 'qwrKq2HLy2TIB3G=', 'call', 'Bv92zwnwzwXVy2L0EvSWxq==', 'C2v0DgLUz3m=', 'zNjLzxn0yw5KAw5N', 'settings', 'Dodge', 'wYbUB2jSzsbDihnHzMv0EsaGia==', 'wYbUB2jSzsbDihnHzMv0Eq==', 'BgvHBG==', 'qxjJ', 'sxnbBgL2zq==', 'SyaeQ', 'sin', 'eye', 'onFrameRenderStart', 'AddSliderInt', 'C3rHBMrPBMC=', 'lean', 'left', 'side', 'C21HBgW=', 'q0jHC2vqBgf5zxi=', 'slow-walking', 'u2v0rMfRzu9MzNnLDa==', 'wYbUB2jSzsbDigXLyw5PBMCGia==', 'C2LKzq==', 'sLmGs2v5yMLUzhm=', 'Polygon', 'GetRealYaw', 'JumwO', 'qwrKu2XPzgvYsw50', 'Aw5KzxHpzG==', 'onCreateMove', 'prototype', 'AddHotkey', 'HjOxq', 'ascUs', 'uMfNzq==', 'DMvYzgfUywi=', 'qwrKrhjVCgrVD24=', 'body', 'AddFont'];
(function (_0x7B2F, _0x7B68) {
    const _0x7BA1 = function (_0x7BDA) {
        while (--_0x7BDA) {
            _0x7B2F.push(_0x7B2F.shift())
        }
    };
    _0x7BA1(++_0x7B68)
}(burba, 0x86));
const burbb = function (_0x7B2F, _0x7B68) {
    _0x7B2F = _0x7B2F - 0x0;
    var _0x7BA1 = burba[_0x7B2F];
    return _0x7BA1
};
const burbc = function (_0x7B2F, _0x7B68) {
    _0x7B2F = _0x7B2F - 0x0;
    var _0x7BA1 = burba[_0x7B2F];
    if (burbc.BauKND === undefined) {
        var _0x7BDA = function (_0x7C4C) {
            const _0x7C85 = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=';
            const h = String(_0x7C4C).replace(/=+$/, '');
            var _0x7CBE = '';
            for (var _0x7CF7 = 0x0, _0x7D30, _0x7D69, _0x7DA2 = 0x0; _0x7D69 = h.charAt(_0x7DA2++); ~_0x7D69 && (_0x7D30 = _0x7CF7 % 0x4 ? _0x7D30 * 0x40 + _0x7D69 : _0x7D69, _0x7CF7++ % 0x4) ? _0x7CBE += String.fromCharCode(0xff & _0x7D30 >> (-0x2 * _0x7CF7 & 0x6)) : 0x0) {
                _0x7D69 = _0x7C85.indexOf(_0x7D69)
            };
            return _0x7CBE
        };
        burbc.TtICti = function (_0x7C4C) {
            const _0x7C85 = _0x7BDA(_0x7C4C);
            var h = [];
            for (var _0x7CF7 = 0x0, _0x7D30 = _0x7C85.length; _0x7CF7 < _0x7D30; _0x7CF7++) {
                h += '%' + ('00' + _0x7C85.charCodeAt(_0x7CF7).toString(0x10)).slice(-0x2)
            };
            return decodeURIComponent(h)
        };
        burbc.ZJLaSy = {};
        burbc.BauKND = !![]
    };
    const _0x7C13 = burbc.ZJLaSy[_0x7B2F];
    if (_0x7C13 === undefined) {
        _0x7BA1 = burbc.TtICti(_0x7BA1);
        burbc.ZJLaSy[_0x7B2F] = _0x7BA1
    } else {
        _0x7BA1 = _0x7C13
    };
    return _0x7BA1
};
const aV = burbc;
const aS = burbb;
Render[aS('0x3d')] = function (_0x7B68, _0x7BDA, _0x7C13, _0x7C85, h, _0x7CBE) {
    const _0x7E14 = burbc;
    const _0x7DDB = aS;
    const _0x7CF7 = Math[_0x7DDB('0x84')](0x7d, h[0x3]);
    Render[_0x7E14('0x4c')](_0x7B68 - 0x1, _0x7BDA - 0x1, _0x7C13, _0x7C85, [0xa, 0xa, 0xa, _0x7CF7], _0x7CBE);
    Render[_0x7E14('0x4c')](_0x7B68 - 0x1, _0x7BDA + 0x1, _0x7C13, _0x7C85, [0xa, 0xa, 0xa, _0x7CF7], _0x7CBE);
    Render[_0x7E14('0x4c')](_0x7B68 + 0x1, _0x7BDA - 0x1, _0x7C13, _0x7C85, [0xa, 0xa, 0xa, _0x7CF7], _0x7CBE);
    Render[_0x7E14('0x4c')](_0x7B68 + 0x1, _0x7BDA + 0x1, _0x7C13, _0x7C85, [0xa, 0xa, 0xa, _0x7CF7], _0x7CBE);
    Render[_0x7E14('0x4c')](_0x7B68, _0x7BDA, _0x7C13, _0x7C85, h, _0x7CBE)
};

function Normalize(_0x7B2F) {
    if (_0x7B2F < -0xb4) {
        _0x7B2F += 0x168
    };
    if (_0x7B2F > 0xb4) {
        _0x7B2F -= 0x168
    };
    return _0x7B2F
}
const burbaF = {};
burbaF.side = 0x0;
burbaF[aV('0x55')] = 0x0;
const burbaG = {};
burbaG.freestanding = 0x0;
burbaG.lean = 0x0;
burbaG[aV('0x55')] = 0x0;
const burbaH = {};
burbaH[aV('0x3e')] = 0x0;
burbaH[aS('0x46')] = -0x1;
burbaH[aS('0x2c')] = burbaF;
burbaH[aV('0x5c')] = burbaG;
burbaH[aV('0x7')] = !![];
var shared = burbaH;
const burbaI = {};
var fonts = burbaI;
var labels = [aV('0x41'), 'left', aS('0x18')];

function RenderIndicators() {
    const _0x97AF = aV;
    const _0x9776 = aS;
    if (shared.setup_fonts) {
        shared[_0x9776('0x2e')] = ![];
        fonts.main = Render[_0x9776('0x83')](_0x97AF('0x80'), 0x9, 0x0);
        fonts[_0x97AF('0x6e')] = Render[_0x97AF('0x47')]('verdanab', 0x7, 0x0)
    };
    const _0x7B2F = Entity[_0x97AF('0xd')]();
    if (!_0x7B2F || !Entity[_0x9776('0x50')](_0x7B2F)) {
        return
    };
    const _0x7B68 = Render[_0x9776('0x3')]()[0x0],
        _0x7BA1 = Render[_0x97AF('0x23')]()[0x1];
    const _0x7BDA = Normalize(Local[_0x9776('0x76')]() - Local[_0x97AF('0x5')]()) / 0x2;
    const _0x7C13 = [0xc0 - Math[_0x9776('0x42')](_0x7BDA) * 0x47 / 0x3c, 0x20 + Math[_0x9776('0x42')](_0x7BDA) * 0x92 / 0x3f, 0xff, 0xff];
    const _0x7C4C = Math[_0x9776('0x42')](_0x7BDA) * 0x30 / 0x3c;
    Render[_0x9776('0x3d')](_0x7B68 / 0x2, _0x7BA1 / 0x2 + 0x19, 0x1, 'burberry', _0x7C13, fonts[_0x9776('0x56')]);
    Render[_0x97AF('0x2b')](_0x7B68 / 0x2 - _0x7C4C + 0x1, _0x7BA1 / 0x2 + 0x27, _0x7C4C + 0x1, 0x2, 0x1, [_0x7C13[0x0], _0x7C13[0x1], _0x7C13[0x2], 0x0], [_0x7C13[0x0], _0x7C13[0x1], _0x7C13[0x2], 0xff]);
    Render.GradientRect(_0x7B68 / 0x2 + 0x1, _0x7BA1 / 0x2 + 0x27, _0x7C4C, 0x2, 0x1, [_0x7C13[0x0], _0x7C13[0x1], _0x7C13[0x2], 0xff], [_0x7C13[0x0], _0x7C13[0x1], _0x7C13[0x2], 0x0]);
    Render[_0x9776('0x3d')](_0x7B68 / 0x2, _0x7BA1 / 0x2 + 0x2b, 0x1, Math[_0x97AF('0x54')](_0x7BDA[_0x9776('0x27')](0x0)).toString(), [0xeb, 0xeb, 0xeb, 0xc8], fonts[_0x9776('0x1c')])
}

function onDraw() {
    RenderIndicators()
}
Cheat[aS('0x40')]('Draw', 'onDraw');
const x1 = UI.AddSliderInt(['Config', 'Indicators', 'Indicators'], 'Fake indicator X pos', 0, Global.GetScreenSize()[0]);
const y1 = UI.AddSliderInt(['Config', 'Indicators', 'Indicators'], 'Fake indicator Y pos', 0, Global.GetScreenSize()[1]);

function in_bounds(_0x8EC7, _0x8819, _0x8B37, _0x8F00, _0x8F39) {
    return (_0x8EC7[0] > _0x8819) && (_0x8EC7[1] > _0x8B37) && (_0x8EC7[0] < _0x8F00) && (_0x8EC7[1] < _0x8F39)
}

function draw_arc(_0x8819, _0x8B37, _0x8A53, _0x8A8C, _0x89E1, _0x8AFE, color) {
    var _0x8A1A = (2 * Math.PI) / 30;
    var _0x8AC5 = Math.PI / 180;
    var _0x89A8 = _0x8A53 - _0x8AFE;
    var _0x896F = (_0x8A8C + _0x89E1) * _0x8AC5;
    var _0x8A8C = (_0x8A8C * Math.PI) / 180;
    for (; _0x8A53 > _0x89A8; --_0x8A53) {
        for (var _0x8852 = _0x8A8C; _0x8852 < _0x896F; _0x8852 += _0x8A1A) {
            var _0x888B = Math.round(_0x8819 + _0x8A53 * Math.cos(_0x8852));
            var _0x88FD = Math.round(_0x8B37 + _0x8A53 * Math.sin(_0x8852));
            var _0x88C4 = Math.round(_0x8819 + _0x8A53 * Math.cos(_0x8852 + _0x8A1A));
            var _0x8936 = Math.round(_0x8B37 + _0x8A53 * Math.sin(_0x8852 + _0x8A1A));
            Render.Line(_0x888B, _0x88FD, _0x88C4, _0x8936, color)
        }
    }
}

function main_aa() {
    if (!World.GetServerString()) {
        return
    };
    const _0x8819 = UI.GetValue(['Config', 'Indicators', 'Indicators', 'Fake indicator X pos']),
        _0x8B37 = UI.GetValue(['Config', 'Indicators', 'Indicators', 'Fake indicator Y pos']);
    var _0x7F31 = Render.AddFont('Verdana', 10, 50);
    var _0x9056 = Local.GetRealYaw();
    var _0x8FE4 = Local.GetFakeYaw();
    var _0x8FAB = Math.min(Math.abs(_0x9056 - _0x8FE4) / 2, 60).toFixed(1);
    var _0x908F = Math.min(Math.round(1.7 * Math.abs(_0x8FAB)), 100);
    if (UI.GetValue(['Rage', 'Anti Aim', 'Key assignment', 'AA Direction inverter'])) {
        var _0x90C8 = 'L'
    } else {
        var _0x90C8 = 'R'
    };
    var _0x876E = ' FAKE (' + _0x8FAB.toString() + ' ) | safety: ' + _0x908F.toString() + '% | side: ' + _0x90C8;
    var _0x87E0 = Render.TextSize(_0x876E, _0x7F31)[0] + 8;
    Render.FilledRect(_0x8819 - _0x87E0, _0x8B37, _0x87E0, 2, [89, 89 + (_0x8FAB / 2), 89 + (_0x8FAB / 0.4), 255]);
    Render.FilledRect(_0x8819 - _0x87E0, _0x8B37 + 2, _0x87E0, 18, [0, 0, 0, 0]);
    Render.String(_0x8819 + 5 - _0x87E0, _0x8B37 + 5, 0, _0x876E, [0, 0, 0, 180], _0x7F31);
    Render.String(_0x8819 + 4 - _0x87E0, _0x8B37 + 4, 0, _0x876E, [255, 255, 255, 255], _0x7F31);
    Render.Circle(_0x8819 + 11 - _0x87E0 + Render.TextSize('FAKE (' + _0x8FAB.toString(), _0x7F31)[0], _0x8B37 + 9, 1, [255, 255, 255, 255]);
    draw_arc(_0x8819 + 0 - _0x87E0, _0x8B37 + 10, 5, 0, _0x8FAB * 6, 2, [89, 119, 239, 255]);
    if (Global.IsKeyPressed(1) && UI.IsMenuOpen()) {
        const _0x901D = Global.GetCursorPosition();
        if (in_bounds(_0x901D, _0x8819 - _0x87E0, _0x8B37, _0x8819 + _0x87E0, _0x8B37 + 30)) {
            UI.SetValue(['Config', 'Indicators', 'Indicators', 'Fake indicator X pos'], _0x901D[0] - _0x87E0 / 2);
            UI.SetValue(['Config', 'Indicators', 'Indicators', 'Fake indicator X pos'], _0x901D[1] - 20)
        }
    }
}
Global.RegisterCallback('Draw', 'main_aa');
UI.AddSliderInt(['Config', 'Indicators', 'Indicators'], '                                          ', 0, 0);
UI.AddCheckbox(['Config', 'Indicators', 'Indicators'], 'Watermark');
UI.AddColorPicker(['Config', 'Indicators', 'Indicators'], 'Watermark color');
var color = UI.GetColor(['Config', 'Indicators', 'Indicators', 'Watermark color']);
if (color[3] == 0) {
    UI.SetColor(['Config', 'Indicators', 'Indicators', 'Watermark color'], [255, 192, 203, 40])
};

function draw() {
    var _0x87A7 = new Date();
    var _0x8618 = _0x87A7.getHours();
    var _0x868A = _0x87A7.getMinutes();
    var _0x86FC = _0x87A7.getSeconds();
    var _0x85DF = _0x8618 <= 9 ? '0' + _0x8618 + ':' : _0x8618 + ':';
    var _0x8651 = _0x868A <= 9 ? '0' + _0x868A + ':' : _0x868A + ':';
    var _0x86C3 = _0x86FC <= 9 ? '0' + _0x86FC : _0x86FC;
    var _0x8735 = Globals.Tickrate().toString();
    var _0x85A6 = Math.round(Entity.GetProp(Entity.GetLocalPlayer(), 'CPlayerResource', 'm_iPing')).toString();
    color = UI.GetColor(['Config', 'Indicators', 'Indicators', 'Watermark color']);
    var _0x7F31 = Render.AddFont('Verdana', 10, 800);
    var _0x876E = 'burberry yaw v' + [1] + ' | ' + Cheat.GetUsername() + ' | delay: ' + _0x85A6 + 'ms | ' + _0x85DF + _0x8651 + _0x86C3;
    var _0x87E0 = Render.TextSize(_0x876E, _0x7F31)[0] + 8;
    var _0x8819 = Global.GetScreenSize()[0];
    _0x8819 = _0x8819 - _0x87E0 - 10;
    if (UI.GetValue(['Config', 'Indicators', 'Indicators', 'Watermark'])) {
        Render.FilledRect(_0x8819, 10, _0x87E0, 2, [color[0], color[1], color[2], 255]);
        Render.FilledRect(_0x8819, 12, _0x87E0, 16, [17, 17, 17, color[3]]);
        Render.String(_0x8819 + 3, 10 + 2, 0, _0x876E, [255, 255, 255, 255], _0x7F31)
    }
}
Cheat.RegisterCallback('Draw', 'draw');
var path = ['Config', 'Burberry', 'Burberry'];
UI.AddSubTab(['Config', 'Burberry'], 'Burberry');
UI.AddCheckbox(path, 'Fake Yaw');
UI.AddSliderInt(path, 'Fake Yaw Limit', 0, 60);
UI.AddCheckbox(path, 'Anti Bruteforce');

function create_move() {
    if (!UI.GetValue(['Config', 'Burberry', 'Burberry', 'Fake Yaw'])) {
        AntiAim.SetOverride(0);
        return
    };
    var _0x8534 = UI.GetValue(['Config', 'Burberry', 'Burberry', 'Fake Yaw Limit']);
    AntiAim.SetOverride(1);
    if (UI.GetValue(['Rage', 'Anti Aim', 'General', 'Key assignment', 'AA Direction inverter'])) {
        AntiAim.SetRealOffset(_0x8534 * 0.5);
        AntiAim.SetFakeOffset((_0x8534 * (-1) + _0x8534) * 0.5);
        AntiAim.SetLBYOffset((90 / 60) * _0x8534 * (-1))
    } else {
        AntiAim.SetFakeOffset(0);
        AntiAim.SetRealOffset((_0x8534 * (-1) - _0x8534) * 0.5);
        AntiAim.SetLBYOffset((90 / 60) * _0x8534)
    }
}

function unload() {
    AntiAim.SetOverride(0)
}
Cheat.RegisterCallback('CreateMove', 'create_move');
Cheat.RegisterCallback('Unload', 'unload');

function radian(_0x9704) {
    return _0x9704 * Math.PI / 180.0
}

function ExtendVector(_0x8BE2, _0x8852, _0x8B70) {
    var _0x8BA9 = radian(_0x8852);
    return [_0x8B70 * Math.cos(_0x8BA9) + _0x8BE2[0], _0x8B70 * Math.sin(_0x8BA9) + _0x8BE2[1], _0x8BE2[2]]
}

function VectorAdd(_0x7B2F, _0x7B68) {
    return [_0x7B2F[0] + _0x7B68[0], _0x7B2F[1] + _0x7B68[1], _0x7B2F[2] + _0x7B68[2]]
}

function VectorSubtract(_0x7B2F, _0x7B68) {
    return [_0x7B2F[0] - _0x7B68[0], _0x7B2F[1] - _0x7B68[1], _0x7B2F[2] - _0x7B68[2]]
}

function VectorMultiply(_0x7B2F, _0x7B68) {
    return [_0x7B2F[0] * _0x7B68[0], _0x7B2F[1] * _0x7B68[1], _0x7B2F[2] * _0x7B68[2]]
}

function VectorLength(_0x8819, _0x8B37, _0x97E8) {
    return Math.sqrt(_0x8819 * _0x8819 + _0x8B37 * _0x8B37 + _0x97E8 * _0x97E8)
}

function VectorNormalize(_0x8EC7) {
    var _0x81A4 = VectorLength(_0x8EC7[0], _0x8EC7[1], _0x8EC7[2]);
    return [_0x8EC7[0] / _0x81A4, _0x8EC7[1] / _0x81A4, _0x8EC7[2] / _0x81A4]
}

function VectorDot(_0x7B2F, _0x7B68) {
    return _0x7B2F[0] * _0x7B68[0] + _0x7B2F[1] * _0x7B68[1] + _0x7B2F[2] * _0x7B68[2]
}

function VectorDistance(_0x7B2F, _0x7B68) {
    return VectorLength(_0x7B2F[0] - _0x7B68[0], _0x7B2F[1] - _0x7B68[1], _0x7B2F[2] - _0x7B68[2])
}

function ClosestPointOnRay(_0x8288, _0x824F, _0x8216) {
    var _0x82C1 = VectorSubtract(_0x8288, _0x824F);
    var _0x816B = VectorSubtract(_0x8216, _0x824F);
    var _0x81A4 = VectorLength(_0x816B[0], _0x816B[1], _0x816B[2]);
    _0x816B = VectorNormalize(_0x816B);
    var _0x81DD = VectorDot(_0x816B, _0x82C1);
    if (_0x81DD < 0.0) {
        return _0x824F
    };
    if (_0x81DD > _0x81A4) {
        return _0x8216
    };
    return VectorAdd(_0x824F, VectorMultiply(_0x816B, [_0x81DD, _0x81DD, _0x81DD]))
}

function Flip() {
    UI.ToggleHotkey(['Rage', 'Anti Aim', 'General', 'Key assignment', 'AA Direction inverter'])
}
var lastHitTime = 0.0;
var lastImpactTimes = [0.0];
var lastImpacts = [
    [0.0, 0.0, 0.0]
];
var playerList = [];

function OnHurt() {
    if (UI.GetValue(['Config', 'Burberry', 'Burberry', 'Anti Bruteforce']) == 0 || UI.GetValue(['Config', 'Burberry', 'Burberry', 'Fake Yaw']) == 0) {
        return
    };
    if (Entity.GetEntityFromUserID(Event.GetInt('userid')) !== Entity.GetLocalPlayer()) {
        return
    };
    var _0x9620 = Event.GetInt('hitgroup');
    var _0x8E8E = Entity.GetEntityFromUserID(Event.GetInt('attacker'));
    var _0x804E = Global.Curtime();
    if (Math.abs(lastHitTime - _0x804E) > 0.5) {
        lastHitTime = _0x804E;
        Flip();
        var _0x7F6A = UI.GetValue(['Rage', 'Anti Aim', 'General', 'Key assignment', 'AA Direction inverter']);
        var _0x7EBF = false;
        var _0x921E = Entity.GetName(_0x8E8E);
        for (var _0x7CBE = 0; _0x7CBE < playerList.length; _0x7CBE++) {
            if (playerList[_0x7CBE][0] == _0x8E8E) {
                playerList[_0x7CBE][2] = _0x7F6A;
                _0x7EBF = true;
                break
            }
        };
        if (!_0x7EBF) {
            playerList.push([_0x8E8E, _0x921E, _0x7F6A])
        }
    }
}

function OnBulletImpact() {
    if (UI.GetValue(['Config', 'Burberry', 'Burberry', 'Anti Bruteforce']) == 0 || UI.GetValue(['Config', 'Burberry', 'Burberry', 'Fake Yaw']) == 0) {
        return
    };
    var _0x804E = Global.Curtime();
    if (Math.abs(lastHitTime - _0x804E) < 0.5) {
        return
    };
    var _0x8E8E = Entity.GetEntityFromUserID(Event.GetInt('userid'));
    var _0x941F = [Event.GetFloat('x'), Event.GetFloat('y'), Event.GetFloat('z'), _0x804E];
    var _0x95E7;
    if (Entity.IsValid(_0x8E8E) && Entity.IsEnemy(_0x8E8E)) {
        if (!Entity.IsDormant(_0x8E8E)) {
            _0x95E7 = Entity.GetEyePosition(_0x8E8E)
        } else {
            if (Math.abs(lastImpactTimes[_0x8E8E] - _0x804E) < 0.1) {
                _0x95E7 = lastImpacts[_0x8E8E]
            } else {
                lastImpacts[_0x8E8E] = _0x941F;
                lastImpactTimes[_0x8E8E] = _0x804E;
                return
            }
        };
        var _0x8E1C = Entity.GetLocalPlayer();
        var _0x9491 = Entity.GetEyePosition(_0x8E1C);
        var _0x94CA = Entity.GetProp(_0x8E1C, 'CBaseEntity', 'm_vecOrigin');
        var _0x9458 = VectorMultiply(VectorAdd(_0x9491, _0x94CA), [0.5, 0.5, 0.5]);
        var _0x91AC = ClosestPointOnRay(_0x9458, _0x95E7, _0x941F);
        var _0x9173 = VectorDistance(_0x9458, _0x91AC);
        if (_0x9173 < 96.0) {
            var _0x9503 = Local.GetRealYaw();
            var _0x9257 = Local.GetFakeYaw();
            var _0x93E6 = ClosestPointOnRay(_0x9491, _0x95E7, _0x941F);
            var _0x93AD = VectorDistance(_0x9491, _0x93E6);
            var _0x9374 = ClosestPointOnRay(_0x94CA, _0x95E7, _0x941F);
            var _0x933B = VectorDistance(_0x94CA, _0x9374);
            var _0x91E5;
            var _0x953C;
            var _0x9290;
            if (_0x9173 < _0x93AD && _0x9173 < _0x933B) {
                _0x91E5 = _0x91AC;
                _0x953C = ExtendVector(_0x91AC, _0x9503 + 180.0, 10.0);
                _0x9290 = ExtendVector(_0x91AC, _0x9257 + 180.0, 10.0)
            } else {
                if (_0x933B < _0x93AD) {
                    _0x91E5 = _0x9374;
                    var _0x9575 = ExtendVector(_0x91AC, _0x9503 - 30.0 + 90.0, 10.0);
                    var _0x95AE = ExtendVector(_0x91AC, _0x9503 - 30.0 - 90.0, 10.0);
                    var _0x92C9 = ExtendVector(_0x91AC, _0x9257 - 30.0 + 90.0, 10.0);
                    var _0x9302 = ExtendVector(_0x91AC, _0x9257 - 30.0 - 90.0, 10.0);
                    if (VectorDistance(_0x9374, _0x9575) < VectorDistance(_0x9374, _0x95AE)) {
                        _0x953C = _0x9575
                    } else {
                        _0x953C = _0x95AE
                    };
                    if (VectorDistance(_0x9374, _0x92C9) < VectorDistance(_0x9374, _0x9302)) {
                        _0x9290 = _0x92C9
                    } else {
                        _0x9290 = _0x9302
                    }
                } else {
                    _0x91E5 = _0x93E6;
                    _0x953C = ExtendVector(_0x91AC, _0x9503, 10.0);
                    _0x9290 = ExtendVector(_0x91AC, _0x9257, 10.0)
                }
            };
            if (VectorDistance(_0x91E5, _0x9290) > VectorDistance(_0x91E5, _0x953C)) {
                lastHitTime = _0x804E;
                Flip();
                var _0x7F6A = UI.GetValue(['Rage', 'Anti Aim', 'General', 'Key assignment', 'AA Direction inverter']);
                var _0x7EBF = false;
                var _0x921E = Entity.GetName(_0x8E8E);
                for (var _0x7CBE = 0; _0x7CBE < playerList.length; _0x7CBE++) {
                    if (playerList[_0x7CBE][0] == _0x8E8E) {
                        playerList[_0x7CBE][2] = _0x7F6A;
                        _0x7EBF = true;
                        break
                    }
                };
                if (!_0x7EBF) {
                    playerList.push([_0x8E8E, _0x921E, _0x7F6A])
                }
            }
        };
        lastImpacts[_0x8E8E] = _0x941F;
        lastImpactTimes[_0x8E8E] = _0x804E
    }
}

function closestToCrosshair() {
    var _0x7E86 = -1;
    var _0x836C = [100000, 100000];
    var _0x8417 = Render.GetScreenSize();
    var _0x83DE = [(_0x8417[0] / 2), (_0x8417[1] / 2)];
    var _0x7EF8 = Entity.GetEnemies();
    var _0x8333 = 100000;
    for (var _0x7CBE = 0; _0x7CBE < _0x7EF8.length; _0x7CBE++) {
        var _0x83A5 = Entity.GetEyePosition(_0x7EF8[_0x7CBE]);
        var _0x8450 = Render.WorldToScreen(_0x83A5);
        if (_0x8450 == undefined) {
            continue
        };
        var _0x82FA = Math.sqrt(Math.pow(_0x83DE[0] - _0x8450[0], 2) + Math.pow(_0x83DE[1] - _0x8450[1], 2));
        if (_0x82FA < _0x8333) {
            _0x7E86 = _0x7EF8[_0x7CBE];
            _0x836C = _0x8450;
            _0x8333 = _0x82FA
        }
    };
    return _0x7E86
}
var closest = -1;
var oldPlayerList = '';
var was_key_down = false;

function AtTarget() {
    if (UI.GetValue(['Config', 'Burberry', 'Burberry', 'Anti Bruteforce']) == 0 || UI.GetValue(['Config', 'Burberry', 'Burberry', 'Fake Yaw']) == 0) {
        return
    };
    if (closestToCrosshair() == -1) {
        return
    };
    var _0x7E86 = closestToCrosshair();
    var _0x7F31 = Render.AddFont('Arial.ttf', 15, 800);
    Render.String(50, 400, 0, 'Anti-Aim Target: ' + Entity.GetName(_0x7E86), [255, 255, 255, 255], _0x7F31);
    var _0x7F6A = UI.GetValue(['Rage', 'Anti Aim', 'General', 'Key assignment', 'AA Direction inverter']);
    if (!was_key_down) {
        was_key_down = Input.IsKeyPressed(0x43)
    };
    closest = closestToCrosshair();
    var _0x7EF8 = Entity.GetEnemies();
    for (var _0x7CBE = 0; _0x7CBE < playerList.length; _0x7CBE++) {
        var _0x7EBF = false;
        for (var _0x7CF7 = 0; _0x7CF7 < _0x7EF8.length; _0x7CF7++) {
            var _0x7FA3 = Entity.GetName(_0x7EF8[_0x7CF7]);
            if (_0x7FA3 == playerList[_0x7CBE][1]) {
                _0x7EBF = true
            }
        };
        if (!_0x7EBF) {
            playerList.splice(_0x7CBE, 1)
        }
    };
    for (var _0x7CBE = 0; _0x7CBE < playerList.length; _0x7CBE++) {
        if (playerList[_0x7CBE][0] == closest) {
            if (was_key_down && !Input.IsKeyPressed(0x43)) {
                if (playerList[_0x7CBE][2] == 0) {
                    playerList[_0x7CBE][2] = 1
                } else {
                    playerList[_0x7CBE][2] = 0
                };
                Cheat.Print('gay');
                was_key_down = false
            };
            if (playerList[_0x7CBE][2] != _0x7F6A) {
                Flip()
            };
            break
        }
    };
    if (JSON.stringify(playerList) != oldPlayerList) {
        //Cheat.Print(JSON.stringify(playerList) + `\`);
        oldPlayerList = JSON.stringify(playerList)
    }
}
realPos = [0, 0, 0];
fakePos = [0, 0, 0];

function main() {}
Cheat.RegisterCallback('player_hurt', 'OnHurt');
Cheat.RegisterCallback('bullet_impact', 'OnBulletImpact');
Cheat.RegisterCallback('Draw', 'AtTarget');
Cheat.RegisterCallback('Draw', 'main');
UI.AddSubTab(['Config', 'Burberry'], 'Burberry');
UI.AddCheckbox(path, 'Jitter fake');
var InvertSpam = true;
var Loop = 1;
var Loop2 = 1;

function spam() {
    if (UI.GetValue(['Config', 'Burberry', 'Burberry', 'Jitter fake'])) {
        var _0x8F72 = 10 * 0;
        if (InvertSpam == true) {
            if (Loop2 > _0x8F72) {
                UI.ToggleHotkey(['Rage', 'Anti Aim', 'AA Direction inverter'], 4);
                Loop2 = 0;
                InvertSpam = false
            }
        } else {
            if (InvertSpam == false) {
                if (Loop2 > _0x8F72) {
                    UI.ToggleHotkey(['Rage', 'Anti Aim', 'AA Direction inverter']);
                    Loop2 = 0;
                    InvertSpam = true
                }
            }
        };
        Loop2 = Loop2 + 1
    }
}
Cheat.RegisterCallback('Draw', 'spam');
UI.AddCheckbox(['Config', 'Burberry', 'Burberry'], 'Jitter real');

function yawjitter() {
    if (UI.GetValue(['Config', 'Burberry', 'Burberry', 'Jitter real'])) {
        var _0x985A = UI.GetValue(['Rage', 'Anti Aim', 'Directions', 'Yaw offset']);
        UI.SetValue(['Rage', 'Anti Aim', 'Directions', 'Yaw offset'], Globals.Tickcount() % 2 ? _0x985A : -_0x985A)
    }
}
Cheat.RegisterCallback('CreateMove', 'yawjitter');
UI.AddSliderInt(['Config', 'Burberry', 'Burberry'], 'Fake lag limit', 0, 16);

function FL() {
    var _0x8C1B = UI.GetValue(['Config', 'Burberry', 'Burberry', 'Fake lag limit']);
    UI.SetValue(['Rage', 'Fake Lag', 'General', 'Limit'], _0x8C1B);
    Exploit.OverrideMaxProcessTicks(_0x8C1B)
}
Cheat.RegisterCallback('CreateMove', 'FL');
UI.AddSubTab(['Config', 'Burberry'], 'Burberry');
UI.AddCheckbox(path, 'Leg Fucker');
var BreakLeg = true;
var Loop = 1;
var Loop2 = 1;

function legs() {
    if (UI.GetValue(['Config', 'Burberry', 'Burberry', 'Leg Fucker'])) {
        var _0x8F72 = 10 * 0;
        if (BreakLeg == true) {
            if (Loop2 > _0x8F72) {
                UI.SetValue(['Misc.', 'Movement', 'Leg movement'], 1);
                UI.SetValue(['Rage', 'Anti Aim', 'Jitter move'], 1);
                Loop2 = 0;
                BreakLeg = false
            }
        } else {
            if (BreakLeg == false) {
                if (Loop2 > _0x8F72) {
                    UI.SetValue(['Misc.', 'Movement', 'Leg movement'], 2);
                    UI.SetValue(['Rage', 'Anti Aim', 'Jitter move'], 0);
                    Loop2 = 0;
                    BreakLeg = true
                }
            }
        };
        Loop2 = Loop2 + 1
    }
}
Cheat.RegisterCallback('Draw', 'legs');
UI.AddSliderInt(['Config', 'Burberry', 'Burberry'], '                                          ', 0, 0);
var original_aa = true;
UI.AddHotkey(['Config', 'Scripts', 'Keys', 'JS Keybinds'], 'Legit AA on key', 'Legit AA on key');

function legit_aa() {
    if (UI.GetValue(['Config', 'Scripts', 'Keys', 'JS Keybinds', 'Legit AA on key']) == true) {
        if (original_aa) {
            restrictions_cache = UI.GetValue(['Config', 'Cheat', 'General', 'Restrictions']);
            yaw_offset_cache = UI.GetValue(['Rage', 'Anti Aim', 'Directions', 'Yaw offset']);
            jitter_offset_cache = UI.GetValue(['Rage', 'Anti Aim', 'Directions', 'Jitter offset']);
            pitch_cache = UI.GetValue(['Rage', 'Anti Aim', 'General', 'Pitch mode']);
            original_aa = false
        };
        UI.SetValue(['Config', 'Cheat', 'General', 'Restrictions'], 0);
        UI.SetValue(['Rage', 'Anti Aim', 'Directions', 'Yaw offset'], 180);
        UI.SetValue(['Rage', 'Anti Aim', 'Directions', 'Jitter offset'], 0);
        UI.SetValue(['Rage', 'Anti Aim', 'General', 'Pitch mode'], 0)
    } else {
        if (!original_aa) {
            UI.SetValue(['Config', 'Cheat', 'General', 'Restrictions'], restrictions_cache);
            UI.SetValue(['Rage', 'Anti Aim', 'Directions', 'Yaw offset'], yaw_offset_cache);
            UI.SetValue(['Rage', 'Anti Aim', 'Directions', 'Jitter offset'], jitter_offset_cache);
            UI.SetValue(['Rage', 'Anti Aim', 'General', 'Pitch mode'], pitch_cache);
            original_aa = true
        }
    }
}
Cheat.RegisterCallback('CreateMove', 'legit_aa');
UI.AddHotkey(['Config', 'Scripts', 'Keys', 'JS Keybinds'], 'Force on shot', 'Force on shot');
var last_shot_time = [];

function imdumb() {
    if (!UI.GetValue(['Config', 'Scripts', 'Keys', 'JS Keybinds', 'Force on shot'])) {
        return
    };
    var _0x8E1C = Entity.GetLocalPlayer();
    if (!Entity.IsAlive(_0x8E1C)) {
        return
    };
    var _0x7EF8 = Entity.GetEnemies();
    for (var _0x7CBE = 0; _0x7CBE < _0x7EF8.length; _0x7CBE++) {
        var _0x8DAA = _0x7EF8[_0x7CBE];
        var _0x8D71 = Globals.Tickcount() - last_shot_time[_0x8DAA];
        var _0x8DE3 = _0x8D71 >= 0 && _0x8D71 <= 12;
        if (!_0x8DE3) {
            Ragebot.IgnoreTarget(_0x8DAA)
        }
    }
}

function imnigger() {
    var _0x8E55 = Entity.GetEntityFromUserID(Event.GetInt('userid'));
    last_shot_time[_0x8E55] = Globals.Tickcount()
}

function imrealnigger() {
    var _0x8E8E = Entity.GetEntityFromUserID(Event.GetInt('userid'));
    if (_0x8E8E == Entity.GetLocalPlayer()) {
        last_shot_time = []
    }
}
Cheat.RegisterCallback('weapon_fire', 'imnigger');
Cheat.RegisterCallback('player_connect_full', 'imrealnigger');
Cheat.RegisterCallback('CreateMove', 'imdumb');
UI.AddHotkey(['Config', 'Scripts', 'Keys', 'JS Keybinds'], 'Pingspike on key', 'Pingspike');
const Path = {
    ToggleAutoDirection: ['Config', 'Scripts', 'Keys', 'JS Keybinds', 'Pingspike on key'],
    AutoDirection: ['Misc.', 'Helpers', 'Extended backtracking']
};

function CreateMove() {
    UI.SetHotkeyState(Path.ToggleAutoDirection, 'Toggle');
    const _0x856D = UI.GetValue(Path.ToggleAutoDirection);
    if (_0x856D) {
        UI.SetValue(Path.AutoDirection, 1)
    } else {
        UI.SetValue(Path.AutoDirection, 0)
    }
}
UI.AddCheckbox(['Config', 'Burberry', 'Burberry'], 'Killsay');
var sayWhat = ['blasted by burberry', 'die femboy', 'u suck btw tbh ngl asap', 'by uwuware =D'];

function getRandomArrayElement(_0x8C54) {
    var _0x8CC6 = 0;
    var _0x8C8D = (_0x8C54.length - 1);
    var _0x8CFF = Math.floor(Math.random() * (_0x8C8D - _0x8CC6)) + _0x8CC6;
    return _0x8C54[_0x8CFF]
}

function onPlayerDeath() {
    if (!UI.GetValue(['Config', 'Burberry', 'Burberry', 'Killsay'])) {
        return
    };
    attacker = Event.GetInt('attacker');
    attacker_index = Entity.GetEntityFromUserID(attacker);
    attacker_name = Entity.GetName(attacker_index);
    attacker_me = Entity.IsLocalPlayer(attacker_index);
    if (attacker_me) {
        Global.ExecuteCommand('say ' + getRandomArrayElement(sayWhat))
    }
}
Global.RegisterCallback('player_death', 'onPlayerDeath');
UI.AddCheckbox(['Config', 'Burberry', 'Burberry'], 'Ragebot logs');

function hitboxes() {
    var _0x8D38 = '';
    switch (index) {
    case 0:
        _0x8D38 = 'head';
        break;
    case 1:
        _0x8D38 = 'head';
        break;
    case 2:
        _0x8D38 = 'stomach';
        break;
    case 3:
        _0x8D38 = 'stomach';
        break;
    case 4:
        _0x8D38 = 'stomach';
        break;
    case 5:
        _0x8D38 = 'chest';
        break;
    case 6:
        _0x8D38 = 'upper chest';
        break;
    case 7:
        _0x8D38 = 'left thigh';
        break;
    case 8:
        _0x8D38 = 'right thigh';
        break;
    case 9:
        _0x8D38 = 'left leg';
        break;
    case 10:
        _0x8D38 = 'right leg';
        break;
    case 11:
        _0x8D38 = 'left foot';
        break;
    case 12:
        _0x8D38 = 'right foot';
        break;
    case 13:
        _0x8D38 = 'left arm';
        break;
    case 14:
        _0x8D38 = 'right arm';
        break;
    case 15:
        _0x8D38 = 'left arm';
        break;
    case 16:
        _0x8D38 = 'right arm';
        break;
    case 17:
        _0x8D38 = 'left arm';
        break;
    case 18:
        _0x8D38 = 'right arm';
        break;
    default:
        _0x8D38 = 'generic'
    }
}

function ragelogs() {
    target = Event.GetInt('target_index');
    name = Entity.GetName(target);
    hc = Event.GetInt('hitchance');
    hitbox = Event.GetInt('hitbox');
    exploit = Event.GetInt('exploit');
    attacker = Event.GetInt('killer');
    damageDone = Event.GetInt('dmg_health');
    healthRemaining = Event.GetInt('health');
    var _0x973D;
    if (exploit == 0) {
        _0x973D = 'false'
    };
    if (exploit == 1) {
        _0x973D = 'hideshots'
    };
    if (hc == 0) {
        _0x973D = 'doubletap'
    };
    if (hitbox == 0) {
        part = 'Head'
    };
    if (hitbox == 1) {
        part = 'Head'
    };
    if (hitbox == 2) {
        part = 'Stomach'
    };
    if (hitbox == 3) {
        part = 'Stomach'
    };
    if (hitbox == 4) {
        part = 'Stomach'
    };
    if (hitbox == 5) {
        part = 'Chest'
    };
    if (hitbox == 6) {
        part = 'Upper chest'
    };
    if (hitbox == 7) {
        part = 'Left thigh'
    };
    if (hitbox == 8) {
        part = 'Right thigh'
    };
    if (hitbox == 9) {
        part = 'Left thigh'
    };
    if (hitbox == 10) {
        part = 'Right thigh'
    };
    if (hitbox == 11) {
        part = 'Left feet'
    };
    if (hitbox == 12) {
        part = 'Right feet'
    };
    if (hitbox == 13) {
        part = 'Left arm'
    };
    if (hitbox == 14) {
        part = 'Right arm'
    };
    if (hitbox == 15) {
        part = 'Left arm'
    };
    if (hitbox == 16) {
        part = 'Left arm'
    };
    if (hitbox == 17) {
        part = 'Right arm'
    };
    if (hitbox == 18) {
        part = 'Right arm'
    };
    if (UI.GetValue(['Config', 'Burberry', 'Burberry', 'Ragebot logs'])) {
        Cheat.PrintColor([255, 192, 203, 255], '[burberry]');
        Cheat.PrintColor([153, 168, 204, 255], ' Fired shot at: ' + name + ' | Hitbox: ' + part + ' | Hitchance: ' + hc + ' | Predicted Damage: ' + damage)
    }
}
Cheat.RegisterCallback('ragebot_fire', 'ragelogs');

function dmg() {
    damage = Event.GetInt('dmg_health');
    healthremaining = Event.GetInt('health');
    attacker = Entity.GetEntityFromUserID(Event.GetInt('attacker'));
    nameoftarget = Entity.GetName(Entity.GetEntityFromUserID(Event.GetInt('userid')));
    localEntity = Entity.GetLocalPlayer()
}
Cheat.RegisterCallback('player_hurt', 'dmg');
UI.AddCheckbox(['Config', 'Burberry', 'Burberry'], 'Fast DT Recharge');
var variables = {
    recharge_time: Globals.Curtime() + 1,
    rage_target: -1,
    time_since_shot: -1,
    wasnt_dting: false
};

function is_trying_to_dt() {
    return UI.GetValue(['Rage', 'SUBTAB_MGR', 'Exploits', 'SHEET_MGR', 'Keys', 'Key assignment', 'Double tap']) && UI.GetValue(['Rage', 'SUBTAB_MGR', 'Exploits', 'SHEET_MGR', 'General', 'Double tap']) && !UI.GetValue(['Rage', 'Anti Aim', 'General', 'Key assignment', 'Fake duck'])
}

function is_trying_to_hs() {
    return UI.GetValue(['Rage', 'SUBTAB_MGR', 'Exploits', 'SHEET_MGR', 'Keys', 'Key assignment', 'Hide shots']) && UI.GetValue(['Rage', 'SUBTAB_MGR', 'Exploits', 'SHEET_MGR', 'General', 'Hide shots']) && !UI.GetValue(['Rage', 'Anti Aim', 'General', 'Key assignment', 'Fake duck'])
}

function rage_fire() {
    if (!is_trying_to_dt()) {
        return
    };
    variables.rage_target = Event.GetInt('target_index')
}

function weapon_fire() {
    if (Entity.GetEntityFromUserID(Event.GetInt('userid')) != Entity.GetLocalPlayer()) {
        return
    };
    var _0x9821 = Entity.GetCCSWeaponInfo(Entity.GetLocalPlayer());
    variables.recharge_time = Globals.Curtime() + _0x9821.cycle_time / 2;
    variables.time_since_shot = Globals.Curtime()
}

function cm() {
    if (!is_trying_to_dt()) {
        variables.wasnt_dting = true;
        Exploit.EnableRecharge();
        return
    };
    if (variables.wasnt_dting) {
        variables.wasnt_dting = false;
        variables.recharge_time = Globals.Curtime()
    };
    if (UI.GetValue(['Config', 'Burberry', 'Burberry', 'Fast DT Recharge'])) {
        Exploit.DisableRecharge();
        var _0x84C2 = Exploit.GetCharge();
        var time = Globals.Curtime();
        var _0x8489 = [];
        if (variables.rage_target != -1) {
            var _0x84FB = Entity.GetHitboxPosition(variables.rage_target, 3);
            _0x8489 = Trace.Bullet(Entity.GetLocalPlayer(), variables.rage_target, Entity.GetEyePosition(Entity.GetLocalPlayer()), _0x84FB);
            if (_0x8489 && _0x8489.length > 0) {
                var dmg = _0x8489[1];
                if (dmg > 0) {
                    return
                }
            }
        }
    };
    if (time > variables.recharge_time && (variables.rage_target == -1 || !Entity.IsAlive(variables.rage_target) || Entity.IsDormant(variables.rage_target) || Globals.Curtime() - variables.time_since_shot > 1)) {
        variables.time_since_shot = Infinity;
        variables.rage_target = -1;
        Exploit.Recharge();
        if (_0x84C2 == 1) {
            variables.recharge_time = Infinity
        }
    }
}

function round_start() {
    variables.recharge_time = Globals.Curtime()
}

function unload() {
    Exploit.EnableRecharge()
}
Cheat.RegisterCallback('Unload', 'unload');
Cheat.RegisterCallback('round_start', 'round_start');
Cheat.RegisterCallback('CreateMove', 'cm');
Cheat.RegisterCallback('ragebot_fire', 'rage_fire');
Cheat.RegisterCallback('weapon_fire', 'weapon_fire');
UI.AddSliderInt(['Config', 'Indicators', 'Indicators'], '                                          ', 0, 0);
UI.AddCheckbox(['Config', 'Indicators', 'Indicators'], 'Keybind list');
const x1 = UI.AddSliderInt(['Config', 'Indicators', 'Indicators'], 'Keybinds X pos', 0, Global.GetScreenSize()[0]);
const y1 = UI.AddSliderInt(['Config', 'Indicators', 'Indicators'], 'Keybinds Y pos', 0, Global.GetScreenSize()[1]);
UI.AddColorPicker(['Config', 'Indicators', 'Indicators'], 'Keybind list color');
UI.SetColor(['Config', 'Indicators', 'Indicators', 'Keybind list color'], [89, 119, 239, 0]);
var colorhotkeys = UI.GetColor(['Config', 'Indicators', 'Indicators', 'Keybind list color']);
if (colorhotkeys[3] == 0) {};
var alpha = 0;
var maxwidth = 0;
var swalpha = 0;
var mdalpha = 0;
var fdalpha = 0;
var apalpha = 0;
var aialpha = 0;
var spalpha = 0;
var fbalpha = 0;
var dtalpha = 0;
var hsalpha = 0;
var doalpha = 0;
var psalpha = 0;
var fsalpha = 0;
var osalpha = 0;
var laalpha = 0;
var textalpha = 0;
var h = new Array();

function in_bounds(_0x8EC7, _0x8819, _0x8B37, _0x8F00, _0x8F39) {
    return (_0x8EC7[0] > _0x8819) && (_0x8EC7[1] > _0x8B37) && (_0x8EC7[0] < _0x8F00) && (_0x8EC7[1] < _0x8F39)
}

function main_hotkeys() {
    if (!World.GetServerString()) {
        return
    };
    const _0x8819 = UI.GetValue(['Config', 'Indicators', 'Indicators', 'Keybinds X pos']),
        _0x8B37 = UI.GetValue(['Config', 'Indicators', 'Indicators', 'Keybinds Y pos']);
    colorhotkeys = UI.GetColor(['Config', 'Indicators', 'Indicators', 'Keybind list color']);
    var _0x7F31 = Render.AddFont('Verdana', 10, 100);
    var _0x9101 = 8 * Globals.Frametime();
    var _0x913A = 75;
    var maxwidth = 0;
    if (UI.GetValue(['Rage', 'Anti Aim', 'General', 'Key assignment', 'Slow walk'])) {
        swalpha = Math.min(swalpha + _0x9101, 1)
    } else {
        swalpha = swalpha - _0x9101;
        if (swalpha < 0) {
            swalpha = 0
        };
        if (swalpha == 0) {
            h.splice(h.indexOf('Slow walk'))
        }
    };
    if (UI.GetValue(['Rage', 'Anti Aim', 'General', 'Key assignment', 'Fake duck'])) {
        fdalpha = Math.min(fdalpha + _0x9101, 1)
    } else {
        fdalpha = fdalpha - _0x9101;
        if (fdalpha < 0) {
            fdalpha = 0
        };
        if (fdalpha == 0) {
            h.splice(h.indexOf('Duck peek assist'))
        }
    };
    if (UI.GetValue(['Config', 'Scripts', 'Keys', 'JS Keybinds', 'Minimum damage override'])) {
        mdalpha = Math.min(mdalpha + _0x9101, 1)
    } else {
        mdalpha = mdalpha - _0x9101;
        if (mdalpha < 0) {
            mdalpha = 0
        };
        if (mdalpha == 0) {
            h.splice(h.indexOf('Damage override'))
        }
    };
    if (UI.GetValue(['Misc.', 'Keys', 'Key assignment', 'Auto peek'])) {
        apalpha = Math.min(apalpha + _0x9101, 1)
    } else {
        apalpha = apalpha - _0x9101;
        if (apalpha < 0) {
            apalpha = 0
        };
        if (apalpha == 0) {
            h.splice(h.indexOf('Auto peek'))
        }
    };
    if (UI.GetValue(['Rage', 'Anti Aim', 'Key assignment', 'AA Direction inverter'])) {
        aialpha = Math.min(aialpha + _0x9101, 1)
    } else {
        aialpha = aialpha - _0x9101;
        if (aialpha < 0) {
            aialpha = 0
        };
        if (aialpha == 0) {
            h.splice(h.indexOf('Anti-aim inverter'))
        }
    };
    if (UI.GetValue(['Rage', 'Anti Aim', 'Key assignment', 'AA Direction inverter'])) {
        aialpha = Math.min(aialpha + _0x9101, 1)
    } else {
        aialpha = aialpha - _0x9101;
        if (aialpha < 0) {
            aialpha = 0
        };
        if (aialpha == 0) {
            h.splice(h.indexOf('Inverter'))
        }
    };
    if (UI.GetValue(['Rage', 'General', 'General', 'Key assignment', 'Force safe point'])) {
        spalpha = Math.min(spalpha + _0x9101, 1)
    } else {
        spalpha = spalpha - _0x9101;
        if (spalpha < 0) {
            spalpha = 0
        };
        if (spalpha == 0) {
            h.splice(h.indexOf('Safe point override'))
        }
    };
    if (UI.GetValue(['Rage', 'General', 'General', 'Key assignment', 'Force body aim'])) {
        fbalpha = Math.min(fbalpha + _0x9101, 1)
    } else {
        fbalpha = fbalpha - _0x9101;
        if (fbalpha < 0) {
            fbalpha = 0
        };
        if (fbalpha == 0) {
            h.splice(h.indexOf('Force body aim'))
        }
    };
    if (UI.GetValue(['Rage', 'Exploits', 'Key assignment', 'Double tap'])) {
        dtalpha = Math.min(dtalpha + _0x9101, 1)
    } else {
        dtalpha = dtalpha - _0x9101;
        if (dtalpha < 0) {
            dtalpha = 0
        };
        if (dtalpha == 0) {
            h.splice(h.indexOf('Double tap'))
        }
    };
    if (UI.GetValue(['Rage', 'Exploits', 'Key assignment', 'Hide shots'])) {
        hsalpha = Math.min(hsalpha + _0x9101, 1)
    } else {
        hsalpha = hsalpha - _0x9101;
        if (hsalpha < 0) {
            hsalpha = 0
        };
        if (hsalpha == 0) {
            h.splice(h.indexOf('Hide shots'))
        }
    };
    if (UI.GetValue(['Misc.', 'Helpers', 'Extended backtracking'])) {
        psalpha = Math.min(psalpha + _0x9101, 1)
    } else {
        psalpha = psalpha - _0x9101;
        if (psalpha < 0) {
            psalpha = 0
        };
        if (psalpha == 0) {
            h.splice(h.indexOf('Pingspike'))
        }
    };
    if (UI.GetValue(['Config', 'Scripts', 'Keys', 'JS Keybinds', 'Freestand on key'])) {
        fsalpha = Math.min(fsalpha + _0x9101, 1)
    } else {
        fsalpha = fsalpha - _0x9101;
        if (fsalpha < 0) {
            fsalpha = 0
        };
        if (fsalpha == 0) {
            h.splice(h.indexOf('Freestand'))
        }
    };
    if (UI.GetValue(['Config', 'Scripts', 'Keys', 'JS Keybinds', 'Force on shot'])) {
        osalpha = Math.min(osalpha + _0x9101, 1)
    } else {
        osalpha = osalpha - _0x9101;
        if (osalpha < 0) {
            osalpha = 0
        };
        if (osalpha == 0) {
            h.splice(h.indexOf('Force on shot'))
        }
    };
    if (UI.GetValue(['Config', 'Scripts', 'Keys', 'JS Keybinds', 'Legit AA on key'])) {
        laalpha = Math.min(laalpha + _0x9101, 1)
    } else {
        laalpha = laalpha - _0x9101;
        if (laalpha < 0) {
            laalpha = 0
        };
        if (laalpha == 0) {
            h.splice(h.indexOf('Legit AA'))
        }
    };
    if (UI.GetValue(['Rage', 'Anti Aim', 'General', 'Key assignment', 'Slow walk'])) {
        if (h.indexOf('Slow walk') == -1) {
            h.push('Slow walk')
        }
    };
    if (UI.GetValue(['Rage', 'Anti Aim', 'General', 'Key assignment', 'Fake duck'])) {
        if (h.indexOf('Duck peek assist') == -1) {
            h.push('Duck peek assist')
        }
    };
    if (UI.GetValue(['Config', 'Scripts', 'Keys', 'JS Keybinds', 'Minimum damage override'])) {
        if (h.indexOf('Damage override') == -1) {
            h.push('Damage override')
        }
    };
    if (UI.GetValue(['Misc.', 'Keys', 'Key assignment', 'Auto peek'])) {
        if (h.indexOf('Auto peek') == -1) {
            h.push('Auto peek')
        }
    };
    if (UI.GetValue(['Rage', 'General', 'General', 'Key assignment', 'Force safe point'])) {
        if (h.indexOf('Safe point override') == -1) {
            h.push('Safe point override')
        }
    };
    if (UI.GetValue(['Rage', 'General', 'General', 'Key assignment', 'Force body aim'])) {
        if (h.indexOf('Force body aim') == -1) {
            h.push('Force body aim')
        }
    };
    if (UI.GetValue(['Rage', 'Exploits', 'Key assignment', 'Double tap'])) {
        if (h.indexOf('Double tap') == -1) {
            h.push('Double tap')
        }
    };
    if (UI.GetValue(['Rage', 'Exploits', 'Key assignment', 'Hide shots'])) {
        if (h.indexOf('Hide shots') == -1) {
            h.push('Hide shots')
        }
    };
    if (UI.GetValue(['Misc.', 'Helpers', 'Extended backtracking'])) {
        if (h.indexOf('Pingspike') == -1) {
            h.push('Pingspike')
        }
    };
    if (UI.GetValue(['Config', 'Scripts', 'Keys', 'JS Keybinds', 'Freestand on key'])) {
        if (h.indexOf('Freestand') == -1) {
            h.push('Freestand')
        }
    };
    if (UI.GetValue(['Config', 'Scripts', 'Keys', 'JS Keybinds', 'Force on shot'])) {
        if (h.indexOf('Force on shot') == -1) {
            h.push('Force on shot')
        }
    };
    if (UI.GetValue(['Config', 'Scripts', 'Keys', 'JS Keybinds', 'Legit AA on key'])) {
        if (h.indexOf('Legit AA') == -1) {
            h.push('Legit AA')
        }
    };
    if (h.length > 0) {
        alpha = Math.min(alpha + _0x9101, 1)
    } else {
        alpha = alpha - _0x9101;
        if (alpha < 0) {
            alpha = 0
        }
    };
    for (i = 0; i < h.length; i++) {
        if (Render.TextSize(h[i], _0x7F31)[0] > maxwidth) {
            maxwidth = Render.TextSize(h[i], _0x7F31)[0]
        }
    };
    if (maxwidth == 0) {
        maxwidth = 50
    };
    _0x913A = _0x913A + maxwidth;
    if (alpha > 0) {
        if (UI.GetValue(['Config', 'Indicators', 'Indicators', 'Keybind list'])) {
            Render.FilledRect(_0x8819, _0x8B37 + 3, _0x913A, 2, [colorhotkeys[0], colorhotkeys[1], colorhotkeys[2], alpha * 255]);
            Render.FilledRect(_0x8819, _0x8B37 + 5, _0x913A, 18, [17, 17, 17, alpha * 0]);
            Render.String(_0x8819 + _0x913A / 2 - (Render.TextSize('keybinds', _0x7F31)[0] / 2) + 2, _0x8B37 + 9, 0, 'keybinds', [0, 0, 0, alpha * 255 / 1.3], _0x7F31);
            Render.String(_0x8819 + _0x913A / 2 - (Render.TextSize('keybinds', _0x7F31)[0] / 2) + 1, _0x8B37 + 8, 0, 'keybinds', [255, 255, 255, alpha * 255], _0x7F31);
            for (i = 0; i < h.length; i++) {
                switch (h[i]) {
                case 'Slow walk':
                    Render.FilledRect(_0x8819, _0x8B37 + 23 + 18 * i, _0x913A, 18, [17, 17, 17, Math.min(colorhotkeys[3], Math.min(swalpha * 255, colorhotkeys[3]))]);
                    Render.String(_0x8819 + 3, _0x8B37 + 26 + 18 * i, 0, h[i], [0, 0, 0, swalpha * 255 / 1.3], _0x7F31);
                    Render.String(_0x8819 + 2, _0x8B37 + 26 + 18 * i, 0, h[i], [255, 255, 255, swalpha * 255], _0x7F31);
                    Render.String(_0x8819 - 3 + _0x913A - Render.TextSize('[holding]', _0x7F31)[0], _0x8B37 + 26 + 18 * i, 0, '[holding]', [0, 0, 0, swalpha * 255 / 1.3], _0x7F31);
                    Render.String(_0x8819 - 2 + _0x913A - Render.TextSize('[holding]', _0x7F31)[0], _0x8B37 + 26 + 18 * i, 0, '[holding]', [255, 255, 255, swalpha * 255], _0x7F31);
                    break;
                case 'Duck peek assist':
                    Render.FilledRect(_0x8819, _0x8B37 + 23 + 18 * i, _0x913A, 18, [17, 17, 17, Math.min(colorhotkeys[3], Math.min(fdalpha * 255, colorhotkeys[3]))]);
                    Render.String(_0x8819 + 3, _0x8B37 + 26 + 18 * i, 0, h[i], [0, 0, 0, fdalpha * 255 / 1.3], _0x7F31);
                    Render.String(_0x8819 + 2, _0x8B37 + 26 + 18 * i, 0, h[i], [255, 255, 255, fdalpha * 255], _0x7F31);
                    Render.String(_0x8819 - 3 + _0x913A - Render.TextSize('[holding]', _0x7F31)[0], _0x8B37 + 26 + 18 * i, 0, '[holding]', [0, 0, 0, fdalpha * 255 / 1.3], _0x7F31);
                    Render.String(_0x8819 - 2 + _0x913A - Render.TextSize('[holding]', _0x7F31)[0], _0x8B37 + 26 + 18 * i, 0, '[holding]', [255, 255, 255, fdalpha * 255], _0x7F31);
                    break;
                case 'Auto peek':
                    Render.FilledRect(_0x8819, _0x8B37 + 23 + 18 * i, _0x913A, 18, [17, 17, 17, Math.min(colorhotkeys[3], Math.min(apalpha * 255, colorhotkeys[3]))]);
                    Render.String(_0x8819 + 3, _0x8B37 + 26 + 18 * i, 0, h[i], [0, 0, 0, apalpha * 255 / 1.3], _0x7F31);
                    Render.String(_0x8819 + 2, _0x8B37 + 26 + 18 * i, 0, h[i], [255, 255, 255, apalpha * 255], _0x7F31);
                    Render.String(_0x8819 - 3 + _0x913A - Render.TextSize('[toggled]', _0x7F31)[0], _0x8B37 + 26 + 18 * i, 0, '[toggled]', [0, 0, 0, apalpha * 255 / 1.3], _0x7F31);
                    Render.String(_0x8819 - 2 + _0x913A - Render.TextSize('[toggled]', _0x7F31)[0], _0x8B37 + 26 + 18 * i, 0, '[toggled]', [255, 255, 255, apalpha * 255], _0x7F31);
                    break;
                case 'Anti-aim inverter':
                    Render.FilledRect(_0x8819, _0x8B37 + 23 + 18 * i, _0x913A, 18, [17, 17, 17, Math.min(colorhotkeys[3], Math.min(aialpha * 255, colorhotkeys[3]))]);
                    Render.String(_0x8819 + 3, _0x8B37 + 26 + 18 * i, 0, h[i], [0, 0, 0, aialpha * 255 / 1.3], _0x7F31);
                    Render.String(_0x8819 + 2, _0x8B37 + 26 + 18 * i, 0, h[i], [255, 255, 255, aialpha * 255], _0x7F31);
                    Render.String(_0x8819 - 3 + _0x913A - Render.TextSize('[toggled]', _0x7F31)[0], _0x8B37 + 26 + 18 * i, 0, '[toggled]', [0, 0, 0, aialpha * 255 / 1.3], _0x7F31);
                    Render.String(_0x8819 - 2 + _0x913A - Render.TextSize('[toggled]', _0x7F31)[0], _0x8B37 + 26 + 18 * i, 0, '[toggled]', [255, 255, 255, aialpha * 255], _0x7F31);
                    break;
                case 'Safe point override':
                    Render.FilledRect(_0x8819, _0x8B37 + 23 + 18 * i, _0x913A, 18, [17, 17, 17, Math.min(colorhotkeys[3], Math.min(spalpha * 255, colorhotkeys[3]))]);
                    Render.String(_0x8819 + 3, _0x8B37 + 26 + 18 * i, 0, h[i], [0, 0, 0, spalpha * 255 / 1.3], _0x7F31);
                    Render.String(_0x8819 + 2, _0x8B37 + 26 + 18 * i, 0, h[i], [255, 255, 255, spalpha * 255], _0x7F31);
                    Render.String(_0x8819 - 3 + _0x913A - Render.TextSize('[toggled]', _0x7F31)[0], _0x8B37 + 26 + 18 * i, 0, '[toggled]', [0, 0, 0, spalpha * 255 / 1.3], _0x7F31);
                    Render.String(_0x8819 - 2 + _0x913A - Render.TextSize('[toggled]', _0x7F31)[0], _0x8B37 + 26 + 18 * i, 0, '[toggled]', [255, 255, 255, spalpha * 255], _0x7F31);
                    break;
                case 'Force body aim':
                    Render.FilledRect(_0x8819, _0x8B37 + 23 + 18 * i, _0x913A, 18, [17, 17, 17, Math.min(colorhotkeys[3], Math.min(fbalpha * 255, colorhotkeys[3]))]);
                    Render.String(_0x8819 + 3, _0x8B37 + 26 + 18 * i, 0, h[i], [0, 0, 0, fbalpha * 255 / 1.3], _0x7F31);
                    Render.String(_0x8819 + 2, _0x8B37 + 26 + 18 * i, 0, h[i], [255, 255, 255, fbalpha * 255], _0x7F31);
                    Render.String(_0x8819 - 3 + _0x913A - Render.TextSize('[toggled]', _0x7F31)[0], _0x8B37 + 26 + 18 * i, 0, '[toggled]', [0, 0, 0, fbalpha * 255 / 1.3], _0x7F31);
                    Render.String(_0x8819 - 2 + _0x913A - Render.TextSize('[toggled]', _0x7F31)[0], _0x8B37 + 26 + 18 * i, 0, '[toggled]', [255, 255, 255, fbalpha * 255], _0x7F31);
                    break;
                case 'Double tap':
                    Render.FilledRect(_0x8819, _0x8B37 + 23 + 18 * i, _0x913A, 18, [17, 17, 17, Math.min(colorhotkeys[3], Math.min(dtalpha * 255, colorhotkeys[3]))]);
                    Render.String(_0x8819 + 3, _0x8B37 + 26 + 18 * i, 0, h[i], [0, 0, 0, dtalpha * 255 / 1.3], _0x7F31);
                    Render.String(_0x8819 + 2, _0x8B37 + 26 + 18 * i, 0, h[i], [255, 255, 255, dtalpha * 255], _0x7F31);
                    Render.String(_0x8819 - 3 + _0x913A - Render.TextSize('[toggled]', _0x7F31)[0], _0x8B37 + 26 + 18 * i, 0, '[toggled]', [0, 0, 0, dtalpha * 255 / 1.3], _0x7F31);
                    Render.String(_0x8819 - 2 + _0x913A - Render.TextSize('[toggled]', _0x7F31)[0], _0x8B37 + 26 + 18 * i, 0, '[toggled]', [255, 255, 255, dtalpha * 255], _0x7F31);
                    break;
                case 'Hide shots':
                    Render.FilledRect(_0x8819, _0x8B37 + 23 + 18 * i, _0x913A, 18, [17, 17, 17, Math.min(colorhotkeys[3], Math.min(hsalpha * 255, colorhotkeys[3]))]);
                    Render.String(_0x8819 + 3, _0x8B37 + 26 + 18 * i, 0, h[i], [0, 0, 0, hsalpha * 255 / 1.3], _0x7F31);
                    Render.String(_0x8819 + 2, _0x8B37 + 26 + 18 * i, 0, h[i], [255, 255, 255, hsalpha * 255], _0x7F31);
                    Render.String(_0x8819 - 3 + _0x913A - Render.TextSize('[toggled]', _0x7F31)[0], _0x8B37 + 26 + 18 * i, 0, '[toggled]', [0, 0, 0, hsalpha * 255 / 1.3], _0x7F31);
                    Render.String(_0x8819 - 2 + _0x913A - Render.TextSize('[toggled]', _0x7F31)[0], _0x8B37 + 26 + 18 * i, 0, '[toggled]', [255, 255, 255, hsalpha * 255], _0x7F31);
                    break;
                case 'Damage override':
                    Render.FilledRect(_0x8819, _0x8B37 + 23 + 18 * i, _0x913A, 18, [17, 17, 17, Math.min(colorhotkeys[3], Math.min(mdalpha * 255, colorhotkeys[3]))]);
                    Render.String(_0x8819 + 3, _0x8B37 + 26 + 18 * i, 0, h[i], [0, 0, 0, mdalpha * 255 / 1.3], _0x7F31);
                    Render.String(_0x8819 + 2, _0x8B37 + 26 + 18 * i, 0, h[i], [255, 255, 255, mdalpha * 255], _0x7F31);
                    Render.String(_0x8819 - 3 + _0x913A - Render.TextSize('[toggled]', _0x7F31)[0], _0x8B37 + 26 + 18 * i, 0, '[toggled]', [0, 0, 0, mdalpha * 255 / 1.3], _0x7F31);
                    Render.String(_0x8819 - 2 + _0x913A - Render.TextSize('[toggled]', _0x7F31)[0], _0x8B37 + 26 + 18 * i, 0, '[toggled]', [255, 255, 255, mdalpha * 255], _0x7F31);
                    break;
                case 'Pingspike':
                    Render.FilledRect(_0x8819, _0x8B37 + 23 + 18 * i, _0x913A, 18, [17, 17, 17, Math.min(colorhotkeys[3], Math.min(psalpha * 255, colorhotkeys[3]))]);
                    Render.String(_0x8819 + 3, _0x8B37 + 26 + 18 * i, 0, h[i], [0, 0, 0, psalpha * 255 / 1.3], _0x7F31);
                    Render.String(_0x8819 + 2, _0x8B37 + 26 + 18 * i, 0, h[i], [255, 255, 255, psalpha * 255], _0x7F31);
                    Render.String(_0x8819 - 3 + _0x913A - Render.TextSize('[toggled]', _0x7F31)[0], _0x8B37 + 26 + 18 * i, 0, '[toggled]', [0, 0, 0, psalpha * 255 / 1.3], _0x7F31);
                    Render.String(_0x8819 - 2 + _0x913A - Render.TextSize('[toggled]', _0x7F31)[0], _0x8B37 + 26 + 18 * i, 0, '[toggled]', [255, 255, 255, psalpha * 255], _0x7F31);
                    break;
                case 'Freestand':
                    Render.FilledRect(_0x8819, _0x8B37 + 23 + 18 * i, _0x913A, 18, [17, 17, 17, Math.min(colorhotkeys[3], Math.min(fsalpha * 255, colorhotkeys[3]))]);
                    Render.String(_0x8819 + 3, _0x8B37 + 26 + 18 * i, 0, h[i], [0, 0, 0, fsalpha * 255 / 1.3], _0x7F31);
                    Render.String(_0x8819 + 2, _0x8B37 + 26 + 18 * i, 0, h[i], [255, 255, 255, fsalpha * 255], _0x7F31);
                    Render.String(_0x8819 - 3 + _0x913A - Render.TextSize('[toggled]', _0x7F31)[0], _0x8B37 + 26 + 18 * i, 0, '[toggled]', [0, 0, 0, fsalpha * 255 / 1.3], _0x7F31);
                    Render.String(_0x8819 - 2 + _0x913A - Render.TextSize('[toggled]', _0x7F31)[0], _0x8B37 + 26 + 18 * i, 0, '[toggled]', [255, 255, 255, fsalpha * 255], _0x7F31);
                    break;
                case 'Force on shot':
                    Render.FilledRect(_0x8819, _0x8B37 + 23 + 18 * i, _0x913A, 18, [17, 17, 17, Math.min(colorhotkeys[3], Math.min(osalpha * 255, colorhotkeys[3]))]);
                    Render.String(_0x8819 + 3, _0x8B37 + 26 + 18 * i, 0, h[i], [0, 0, 0, osalpha * 255 / 1.3], _0x7F31);
                    Render.String(_0x8819 + 2, _0x8B37 + 26 + 18 * i, 0, h[i], [255, 255, 255, osalpha * 255], _0x7F31);
                    Render.String(_0x8819 - 3 + _0x913A - Render.TextSize('[toggled]', _0x7F31)[0], _0x8B37 + 26 + 18 * i, 0, '[toggled]', [0, 0, 0, osalpha * 255 / 1.3], _0x7F31);
                    Render.String(_0x8819 - 2 + _0x913A - Render.TextSize('[toggled]', _0x7F31)[0], _0x8B37 + 26 + 18 * i, 0, '[toggled]', [255, 255, 255, osalpha * 255], _0x7F31);
                    break;
                case 'Legit AA':
                    Render.FilledRect(_0x8819, _0x8B37 + 23 + 18 * i, _0x913A, 18, [17, 17, 17, Math.min(colorhotkeys[3], Math.min(laalpha * 255, colorhotkeys[3]))]);
                    Render.String(_0x8819 + 3, _0x8B37 + 26 + 18 * i, 0, h[i], [0, 0, 0, laalpha * 255 / 1.3], _0x7F31);
                    Render.String(_0x8819 + 2, _0x8B37 + 26 + 18 * i, 0, h[i], [255, 255, 255, laalpha * 255], _0x7F31);
                    Render.String(_0x8819 - 3 + _0x913A - Render.TextSize('[holding]', _0x7F31)[0], _0x8B37 + 26 + 18 * i, 0, '[holding]', [0, 0, 0, laalpha * 255 / 1.3], _0x7F31);
                    Render.String(_0x8819 - 2 + _0x913A - Render.TextSize('[holding]', _0x7F31)[0], _0x8B37 + 26 + 18 * i, 0, '[holding]', [255, 255, 255, laalpha * 255], _0x7F31);
                    break
                }
            }
        }
    };
    if (Global.IsKeyPressed(1) && UI.IsMenuOpen()) {
        const _0x901D = Global.GetCursorPosition();
        if (in_bounds(_0x901D, _0x8819, _0x8B37, _0x8819 + _0x913A, _0x8B37 + 30)) {
            UI.SetValue(['Config', 'Indicators', 'Indicators', 'Keybinds X pos'], _0x901D[0] - _0x913A / 2);
            UI.SetValue(['Config', 'Indicators', 'Indicators', 'Keybinds Y pos'], _0x901D[1] - 20)
        }
    }
}
Global.RegisterCallback('Draw', 'main_hotkeys');
var time, delay, fillbar, shotsfired;

function can_shift_shot(_0x80F9) {
    var _0x8087 = Entity.GetLocalPlayer();
    var _0x8132 = Entity.GetWeapon(_0x8087);
    if (_0x8087 == null || _0x8132 == null) {
        return false
    };
    var _0x80C0 = Entity.GetProp(_0x8087, 'CCSPlayer', 'm_nTickBase');
    var _0x804E = Globals.TickInterval() * (_0x80C0 - _0x80F9);
    if (_0x804E < Entity.GetProp(_0x8087, 'CCSPlayer', 'm_flNextAttack')) {
        return false
    };
    if (_0x804E < Entity.GetProp(_0x8132, 'CBaseCombatWeapon', 'm_flNextPrimaryAttack')) {
        return false
    };
    return true
}

function _TBC_CREATE_MOVE() {
    var _0x7E4D = Exploit.GetCharge();
    Exploit[(_0x7E4D != 1 ? 'Enable' : 'Disable') + 'Recharge']();
    if (can_shift_shot(17) && _0x7E4D != 1) {
        Exploit.DisableRecharge();
        Exploit.Recharge()
    };
    Exploit.OverrideTolerance(0);
    Exploit.OverrideShift(17)
}

function _TBC_UNLOAD() {
    Exploit.EnableRecharge()
}
Cheat.RegisterCallback('CreateMove', '_TBC_CREATE_MOVE');
Cheat.RegisterCallback('Unload', '_TBC_UNLOAD');
UI.AddHotkey(['Config', 'Scripts', 'Keys', 'JS Keybinds'], 'Freestand on key', 'Freestand');
const Path = {
    ToggleAutoDirection: ['Config', 'Scripts', 'Keys', 'JS Keybinds', 'Freestand on key'],
    AutoDirection: ['Rage', 'Anti Aim', 'Directions', 'Auto direction'],
    AtTargets: ['Rage', 'Anti Aim', 'Directions', 'At targets']
};

function CreateMove() {
    UI.SetHotkeyState(Path.ToggleAutoDirection, 'Toggle');
    const _0x856D = UI.GetValue(Path.ToggleAutoDirection);
    if (_0x856D) {
        UI.SetValue(Path.AutoDirection, 1);
        UI.SetValue(Path.AtTargets, 0)
    } else {
        UI.SetValue(Path.AutoDirection, 0);
        UI.SetValue(Path.AtTargets, 1)
    }
}
Cheat.RegisterCallback('CreateMove', 'CreateMove');
Cheat.PrintColor([159, 161, 159, 255], ' ');
Cheat.PrintColor([159, 161, 159, 255], ' ');
Cheat.PrintColor([255, 192, 203, 255], '+ burberry yaw +');
Cheat.PrintColor([100, 255, 0, 255], 'successfully injected');
Cheat.PrintColor([255, 255, 255, 255], 'welcome back ');
Cheat.PrintColor([255, 192, 203, 255], '' + Cheat.GetUsername());
Cheat.PrintColor([159, 161, 159, 255], ' ');
Cheat.PrintColor([159, 161, 159, 255], ' ');
Cheat.PrintChat('  + burberry yaw +');
Cheat.PrintChat('  successfully injected');
Cheat.PrintChat('  welcome back ' + Cheat.GetUsername() + '');