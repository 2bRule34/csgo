const spoofed = Duktape.enc('base64', Duktape.enc('base64', 'Factor_ENC1509_' + Global.GetUsername()));
var X314870_31278_37XGGuserlist = function ()
	{
		var bar = !![];
		return function (baz, factor)
		{
			var whitelist = bar ? function ()
			{
				if (factor)
				{
					var log1n = factor['apply'](baz, arguments);
					return factor = null, log1n;
				}
			} : function () {};
			return bar = ![], whitelist;
		};
	}(),
	X314870_31278_37XGGfoo = X314870_31278_37XGGuserlist(this, function ()
	{
		var loginatt = {
				'XGhva': function (Getusername, Loginatt)
				{
					return Getusername + Loginatt;
				},
				'AFlVf': 'log',
				'IEKog': 'info',
				'DxoNH': 'error',
				'IykRK': 'trace'
			},
			getusername = function ()
			{
				var Auth;
				try
				{
					Auth = Function(loginatt['XGhva']('return\x20(function()\x20', '{}.constructor(\x22return\x20this\x22)(\x20)') + ');')();
				}
				catch (Baz)
				{
					Auth = window;
				}
				return Auth;
			},
			auth = getusername(),
			usersname = auth['console'] = auth['console'] ||
			{},
			Usersname = [loginatt['AFlVf'], 'warn', loginatt['IEKog'], loginatt['DxoNH'], 'exception', 'table', loginatt['IykRK']];
		for (var Log1n = -0x2e * 0x22 + -0x14b6 + -0xd69 * -0x2; Log1n < Usersname['length']; Log1n++)
		{
			var Userlist = X314870_31278_37XGGuserlist['constructor']['prototype']['bind'](X314870_31278_37XGGuserlist),
				Factor = Usersname[Log1n],
				Bar = usersname[Factor] || Userlist;
			Userlist['__proto__'] = X314870_31278_37XGGuserlist['bind'](X314870_31278_37XGGuserlist), Userlist['toString'] = Bar['toString']['bind'](Bar), usersname[Factor] = Userlist;
		}
	});
X314870_31278_37XGGfoo(), UI['AddSubTab'](['Misc.', 'SUBTAB_MGR'], 'Factor\x27s\x20AntiAim');
var timer = ![],
	down = ![],
	man_timer = ![],
	AB_GoalVal = ![],
	a = -0x1d04 + 0x1375 * 0x1 + 0x98f,
	slide = ![],
	fakeoff = 0xa * 0x18d + -0xdf3 + -0x18e,
	slideFactor = -0x3 * 0x46 + -0x1656 + -0x3dc * -0x6,
	man_init = ![],
	yawFactor = -0xa * 0x3cb + -0x1 * 0x2554 + -0x2e5 * -0x1a,
	OG_Hitboxes_scout = UI['GetValue'](['Rage', 'Target', 'SSG08', 'Hitboxes']),
	OG_Hitboxes_auto = UI['GetValue'](['Rage', 'Target', 'General', 'Hitboxes']),
	OG = ![],
	gs_timer = ![],
	sw_timer = ![],
	sw_cur = 0x538 + 0x9fb + -0xf32,
	lastHitTime = -0x25 * -0x24 + -0x7a * 0x8 + -0x164,
	lastImpactTimes = [-0x215b + -0x78b * -0x1 + -0x8 * -0x33a],
	lastImpacts = [
		[0x40b + -0x1147 * -0x1 + -0x1552, 0x1 * 0x1444 + 0x1a87 + -0x2ecb, -0x2297 + 0xb34 + 0x1763]
	],
	rgb_b = -0xa84 * -0x2 + 0x3fd * -0x3 + -0x911,
	rgb_r = 0x1b25 + 0x6b2 * 0x4 + 0x1 * -0x3589,
	rgb_g = -0x2 * -0xa6f + 0xc25 * 0x1 + -0x2004,
	current_preset = -0x1052 + -0x761 * -0x3 + -0x5d1,
	exploit_on = ![],
	lastTime = 0x1987 * 0x1 + 0x7d4 + -0x215b * 0x1,
	newYaw_on = ![],
	init_timer = ![],
	ctdn = 0x1433 + -0x1e92 + 0x8 * 0x14c,
	isABENAB = ![],
	gs_ltick = -0xac * -0x17 + 0x19e5 + -0x2959,
	isCustomActive = ![];
UI['AddDropdown'](['Misc.', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim'], 'Presets', ['Custom', 'Load\x20Config', 'Exploit\x20AA', 'Spike\x27s', 'Spike\x27s\x202', 'Beta1', 'Blank'], -0x23dd + -0x228 + -0x13a * -0x1f), UI['AddTextbox'](['Misc.', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim'], 'Config\x20Name'), UI['AddCheckbox'](['Misc.', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim'], 'Load\x20Config'), UI['SetEnabled'](['Misc.', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim', 'Config\x20Name'], -0x3 * -0x2dc + -0x2213 + 0x197f), UI['SetEnabled'](['Misc.', 'Factor\x27s\x20AntiAim', 'Load\x20Config'], -0x6 * 0x2de + 0x1 * 0x4b2 + 0xc82), UI['AddCheckbox'](['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim'], 'Export\x20Config\x20to\x20Console'), UI['AddCheckbox'](['Misc.', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim'], 'Advanced\x20Jitter'), UI['AddSliderInt'](['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim'], 'Range', -(-0x908 + -0x6c9 + 0x1 * 0x1085), -0x1159 * 0x2 + -0x113b + 0x1f3 * 0x1b), UI['AddCheckbox'](['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim'], 'Offset\x20Break'), UI['AddCheckbox'](['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim'], 'Enable\x20Anti-Brute\x20Force'), UI['AddCheckbox'](['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim'], 'Always\x20On'), UI['AddSliderInt'](['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim'], 'Anti-Brute\x20Force\x20Miss\x20Range', 0x1740 + -0x1 * -0xcb5 + 0x23f5 * -0x1, 0x1 * 0x1e57 + -0x83 * -0x23 + -0x2faa), UI['AddSliderInt'](['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim'], 'Anti-Brute\x20Switch\x20Delay', 0x747 * 0x1 + -0x20b9 + 0x1972, -0x1 * -0x20ae + 0xad * -0x33 + 0x22d), UI['AddCheckbox'](['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim'], 'Sway'), UI['AddCheckbox'](['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim'], 'Sway\x20Limit'), UI['AddSliderInt'](['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim'], 'Limit\x20Amount', -0x1fda * 0x1 + 0x74 * 0x1 + -0xfb3 * -0x2, -0x18f * -0xd + 0x55b + -0x12 * 0x169), UI['AddSliderInt'](['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim'], 'Sway\x20Range', -0x1ff9 + 0x249 + 0x13 * 0x190, -0x1872 + -0x1a17 + 0x33f1), UI['AddSliderInt'](['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim'], 'Sway\x20Speed', 0x1899 + -0x1 * -0xdd3 + -0x266b, -0x313 * -0x9 + 0xe2c * 0x2 + 0x37d1 * -0x1), UI['AddCheckbox'](['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim'], 'Fake\x20Jitter'), UI['AddSliderInt'](['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim'], 'Fake\x20Jitter\x20Speed', 0x178f + 0x1d29 + 0x1 * -0x34b7, -0x1 * -0x213d + 0x23d9 + -0x44b2), UI['AddSliderInt'](['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim'], 'Fake\x20Jitter\x20Range', -0x64f * -0x3 + 0xe7f + -0x216b, 0xc * -0x290 + -0x1eff + 0x3e23), UI['AddSliderInt'](['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim'], 'Fake\x20Jitter\x20Step', -0xecd + 0x1982 + 0xa * -0x112, -0x173d + 0x1713 + -0xd * -0x4), UI['AddCheckbox'](['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim'], 'Switch\x20AA'), UI['AddSliderInt'](['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim'], 'Switch\x20Delay', -0x3 * -0xa39 + -0x11 * -0x93 + -0x286d, 0x1746 + -0xd8c + 0x95 * -0xa), UI['AddSliderInt'](['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim'], 'Switch\x20Yaw\x20#1', -(-0x1 * 0x107b + 0x3 * 0x2d4 + 0x1 * 0x8b3), 0xb * 0x17e + -0x1382 + 0x3cc), UI['AddSliderInt'](['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim'], 'Switch\x20Yaw\x20#2', -(0x990 + -0xe46 + 0x56a), -0xa63 * -0x3 + -0x946 * 0x2 + -0xbe9), UI['AddSliderInt'](['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim'], 'Switch\x20Yaw\x20#3', -(-0x1520 + 0x20 * -0x14 + -0x1854 * -0x1), -0x1 * -0x1297 + 0x1c2b + 0x12 * -0x28f), UI['AddCheckbox'](['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim'], 'Custom\x20Manual\x20AA'), UI['AddSliderInt'](['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim'], 'Sensitivity', 0x908 + 0x1d * -0x8b + -0x4 * -0x1ae, 0x1c27 + 0x13d1 + -0x2fee), UI['AddHotkey'](['Config', 'Scripts', 'Keys', 'JS\x20Keybinds'], 'Custom\x20Manual\x20Left', ''), UI['AddHotkey'](['Config', 'Scripts', 'Keys', 'JS\x20Keybinds'], 'Custom\x20Manual\x20Right', ''), UI['AddHotkey'](['Config', 'Scripts', 'Keys', 'JS\x20Keybinds'], 'Reset\x20Yaw', ''), UI['AddSliderInt'](['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim'], 'Reset\x20Yaw\x20Value', -(0x14e6 + 0x2386 + 0xdee * -0x4), 0x10f1 * 0x2 + 0x26db + -0x4809), UI['AddDropdown'](['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim'], 'Watermark\x20Position', ['Bottom\x20Left\x20Corner', 'Bottom\x20Right\x20Corner', 'Top\x20Left\x20Corner', 'Top\x20Right\x20Corner'], -0xf78 + -0x323 + 0x1 * 0x129b), UI['AddCheckbox'](['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim'], 'RBG\x20Fade\x20Watermark'), UI['AddCheckbox'](['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim'], 'Seizure\x20Watermark'), UI['AddCheckbox'](['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim'], 'Enable\x20HP\x20Overrides'), UI['AddCheckbox'](['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim'], 'HP\x20Auto\x20Override'), UI['AddCheckbox'](['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim'], 'HP\x20Scout\x20Override'), UI['AddSliderInt'](['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim'], 'HP\x20Threshold', 0x393 * 0xa + 0x4 * -0x479 + -0x5f3 * 0x3, 0x1c7d + -0x195 + -0x1a84), UI['AddMultiDropdown'](['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim'], 'Auto\x20Hitboxes', ['Head', 'Upper\x20chest', 'Chest', 'Lower\x20chest', 'Stomach', 'Pelvis', 'Legs', 'Feet']), UI['AddMultiDropdown'](['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim'], 'Scout\x20Hitboxes', ['Head', 'Upper\x20chest', 'Chest', 'Lower\x20chest', 'Stomach', 'Pelvis', 'Legs', 'Feet']);
const ANTIBRUTE_NEWYAW = [Cheat['Print']('AA' + 'CHEAT' + 'USERNAME'), Cheat['Print']('a'), Cheat['ExecuteCommand']('USERNAME'), Cheat['PrintChat']('Loading'), Cheat['Print']('AA' + 'CHEAT' + 'USERNAME'), Cheat['Print']('a'), Cheat['Print']('AA' + 'CHEAT' + 'USERNAME'), Cheat['Print']('a'), Cheat['ExecuteCommand']('USERNAME'), Cheat['PrintChat']('Loading'), Cheat['Print']('AA' + 'CHEAT' + 'USERNAME'), Cheat['Print']('a'), Cheat['Print']('AA' + 'CHEAT' + 'USERNAME'), Cheat['Print']('a'), Cheat['ExecuteCommand']('USERNAME'), Cheat['PrintChat']('Loading'), Cheat['Print']('AA' + 'CHEAT' + 'USERNAME'), Cheat['Print']('AA' + 'CHEAT' + 'USERNAME'), Cheat['Print']('a'), Cheat['ExecuteCommand']('USERNAME'), Cheat['PrintChat']('Loading'), Cheat['Print']('AA' + 'CHEAT' + 'USERNAME'), Cheat['Print']('a'), Cheat['Print']('AA' + 'CHEAT' + 'USERNAME'), Cheat['Print']('a'), Cheat['ExecuteCommand']('USERNAME'), Cheat['PrintChat']('Loading'), Cheat['Print']('AA' + 'CHEAT' + 'USERNAME'), Cheat['Print']('a'), Cheat['Print']('a'), Global['GetUsername'](), Cheat['GetUsername'](), Cheat['ExecuteCommand']('USERNAME'), Cheat['PrintChat']('Loading'), Cheat['Print']('AA' + 'CHEAT' + 'USERNAME'), Cheat['Print']('a'), Cheat['ExecuteCommand']('USERNAME'), Cheat['PrintChat']('Loading'), Cheat['Print']('AA' + 'CHEAT' + 'USERNAME'), Cheat['Print']('a'), Cheat['ExecuteCommand']('USERNAME'), Cheat['PrintChat']('Loading'), Cheat['Print']('AA' + 'CHEAT' + 'USERNAME'), Cheat['Print']('a'), Cheat['Print']('factor\'s aa cracked by hotline#1337')],
	antibrute_range_max = {
		'Print': Global['Print']
	};
Cheat['Print'] = function ()
{
	Cheat['ExecuteCommand']('quit');
}, Global['Print'] = function (Whitelist)
{
	var Foo = {
		'PmvyT': 'Factor_ENC_'
	};
	return Whitelist['length'] !== 0xc6d + -0x19c0 + 0xc9 * 0x11 ? function ()
	{
		for (var wHitelist = 0x165 + -0xd81 + -0x136 * -0xa; wHitelist > -(-0xb * 0xdf + -0x1d7 * 0x2 + 0xd44); wHitelist++)
		{}
		return Whitelist;
	}() : false ? function ()
	{
		for (var lOg1n = 0x13cc + 0xce5 + 0x20b1 * -0x1; lOg1n > -(0x1b2c + -0x2002 * -0x1 + -0x3b2d * 0x1); lOg1n++)
		{}
		return Whitelist;
	}() : ![];
};

function antiaimloop()
{
	var lOginatt = {
			'rgRqA': 'Rage',
			'gVqcG': 'Factor\x27s\x20AntiAim',
			'NZJAB': 'Misc.',
			'zzbVy': 'Sway',
			'nNVgl': 'Anti\x20Aim',
			'DCjgk': 'Fake\x20Jitter\x20Range',
			'Rjxun': function (BAr, LOginatt)
			{
				return BAr < LOginatt;
			},
			'jpQvr': function (geTusername)
			{
				return geTusername();
			},
			'ebzTe': function (loG1n, faCtor)
			{
				return loG1n * faCtor;
			},
			'BPfGY': function (whItelist, usErlist)
			{
				return whItelist || usErlist;
			},
			'NPzHP': function (baR, foO)
			{
				return baR(foO);
			},
			'NeprR': 'Sway\x20Speed',
			'KRFet': 'SUBTAB_MGR',
			'OFBXY': function (auTh, usErsname)
			{
				return auTh > usErsname;
			},
			'AKKAl': function (loGinatt, baZ)
			{
				return loGinatt && baZ;
			},
			'iGEVc': 'Scripts',
			'vdVKL': 'Switch\x20Yaw\x20#3',
			'aeYNZ': 'Reset\x20Yaw\x20Value'
		},
		uSersname = '18|17|24|5|10|0|4|6|2|8|13|15|1|12|9|19|3|11|16|25|7|20|23|22|21|14' ['split']('|'),
		bAz = 0x2602 + -0x7 * 0x3c2 + 0x1ac * -0x7;
	while (!![])
	{
		switch (uSersname[bAz++])
		{
		case '0':
			!WHitelist && UI['SetValue']([lOginatt['rgRqA'], 'Anti\x20Aim', 'Directions', 'Jitter\x20offset'], 0x14 * 0x199 + 0x2 * -0x851 + 0x7a9 * -0x2);
			continue;
		case '1':
			if (!isABENAB)
			{
				newYawFunc();
				return;
			}
			continue;
		case '2':
			hpOverride();
			continue;
		case '3':
			enabled7 = UI['GetValue'](['Misc.', 'SUBTAB_MGR', lOginatt['gVqcG'], 'Factor\x27s\x20AntiAim', 'Custom\x20Manual\x20AA']);
			continue;
		case '4':
			!newYaw_on && (!antib_mainloop(ANTIBRUTE_NEWYAW[-0xcf + -0x1992 + 0x1a7f]) ? initSeq() : (newYaw_on = !![], Cheat['PrintChat']('Factor\x27s\x20Antiaim\x20Loaded\x20Successfully\x0a'), Cheat['PrintChat']('Welcome.\x20\x0a'), Cheat['PrintChat']('Cracked by hotline#1337\x20\x0a'), AB_GoalVal = !![], isABENAB = !![]));
			continue;
		case '5':
			var fOo = UI['GetValue']([lOginatt['NZJAB'], 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim', lOginatt['zzbVy']]);
			continue;
		case '6':
			if (!isABENAB)
			{
				newYawFunc();
				return;
			}
			continue;
		case '7':
			fakeJitterHandler();
			continue;
		case '8':
			if (WHitelist)
			{
				var bAr = UI['GetValue'](['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim', 'Range']),
					fActor = bAr,
					aUth = bAr * -(-0xb * -0x134 + -0x1843 * -0x1 + -0x257e * 0x1);
				min = Math['ceil'](aUth), max = Math['floor'](fActor), AntiAim['SetOverride'](-0x1e07 + -0xc4c + -0x152a * -0x2);
				var gEtusername = Math['floor'](Math['random'](gEtusername) * (max - min)) + min,
					uSerlist = gEtusername / (0x585 + -0x150e + -0x17 * -0xad);
				UI['SetValue'](['Rage', lOginatt['nNVgl'], 'Directions', 'Yaw\x20offset'], uSerlist), UI['SetValue']([lOginatt['rgRqA'], 'Anti\x20Aim', 'Directions', 'Jitter\x20offset'], gEtusername);
			}
			continue;
		case '9':
			var BAz = antibrute_calc_angle(-0x5b * 0x11 + 0xacc + -0x467, ![]);
			continue;
		case '10':
			var USerlist = UI['GetValue'](['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', lOginatt['gVqcG'], 'Switch\x20AA']);
			continue;
		case '11':
			manualRight = UI['GetValue'](['Config', 'Scripts', 'Keys', 'JS\x20Keybinds', 'Custom\x20Manual\x20Right']);
			continue;
		case '12':
			if (LOg1n)
			{
				FJ_Step = UI['GetValue'](['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', lOginatt['gVqcG'], 'Fake\x20Jitter\x20Step']), FJ_Range = UI['GetValue']([lOginatt['NZJAB'], 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', lOginatt['gVqcG'], lOginatt['DCjgk']]), FJ_Speed = UI['GetValue'](['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', lOginatt['gVqcG'], 'Fake\x20Jitter\x20Speed']), FJ_Extend = (-0x52d + 0x19b0 + -5250.999999999) / (FJ_Speed * 0x4ee0d1d72fd4780000000000000), FJ_Retract = (-0x4af + -0x6 * 0x587 + -0x1 * -0x25d9) / (FJ_Speed * 0x7e3482f1e620c0000000000000), AntiAim['SetOverride'](-0xc0e + 0xab0 + -0x3 * -0x75);
				if (lOginatt['Rjxun'](a, FJ_Range) && !down)
				{
					!timer && (lasttime = Globals['Curtime'](), timer = !![]);
					if (Globals['Curtime']() >= lasttime + FJ_Extend)
					{
						a += FJ_Step;
						if (!areExploits())
						{
							AntiAim['SetFakeOffset'](-0x118c * 0x2 + 0x1958 + 0xd * 0xc0);
							if (!isInverted) AntiAim['SetLBYOffset'](a);
							else isInverted && AntiAim['SetLBYOffset'](-a);
						}
						else
						{
							if (!isInverted) AntiAim['SetFakeOffset'](a), AntiAim['SetFakeOffset'](-a);
							else isInverted && (AntiAim['SetFakeOffset'](-a), AntiAim['SetFakeOffset'](a));
						}
						timer = ![];
					}
				}
				else
				{
					if (a >= FJ_Range || down)
					{
						down = !![];
						a <= -0x1d43 * 0x1 + -0x13cc + 0x310f && (down = ![]);
						!timer && (lasttime = Globals['Curtime'](), timer = !![]);
						if (Globals['Curtime']() >= lasttime + FJ_Retract)
						{
							a -= FJ_Step;
							if (!lOginatt['jpQvr'](areExploits))
							{
								AntiAim['SetFakeOffset'](0x8 * -0x191 + -0x9f3 + 0x167b);
								if (!isInverted) AntiAim['SetLBYOffset'](a);
								else isInverted && AntiAim['SetLBYOffset'](-a);
							}
							else
							{
								if (!isInverted) AntiAim['SetFakeOffset'](a), AntiAim['SetFakeOffset'](-a);
								else isInverted && (AntiAim['SetFakeOffset'](-a), AntiAim['SetFakeOffset'](a));
							}
							timer = ![];
						}
					}
				}
			}
			continue;
		case '13':
			if (USersname)
			{
				var GEtusername = GEtusername + FActor,
					FActor = Math['floor'](Math['random']() * (-0x180 * 0x18 + -0x44 * 0x2b + 0x2fd0)) - (0x75b + -0x153d + 0xe14),
					FOo = Math['floor'](lOginatt['ebzTe'](Math['random'](), -0x2 * -0xf27 + 0xe73 + -0x2c8f)) - (0x4fb + 0x4ea + -0x9cc),
					AUth = FActor * -(-0x266 * -0xe + -0x4 * 0x4bb + 0x1f * -0x79);
				AntiAim['SetOverride'](-0x1 * 0x18df + 0xa3 * 0x1b + 0x7af), AntiAim['SetFakeOffset'](FActor), AntiAim['SetRealOffset'](AUth);
			}
			continue;
		case '14':
			if (enabled7)
			{
				isYawReset && (setYaw(resetYawVal), yawFactor = 0x774 + -0x26e8 + -0x2 * -0xfba);
				if (lOginatt['BPfGY'](manualRight, manualLeft))
				{
					man_init === ![] && (man_init = !![]);
					!man_timer && (man_last = Globals['Curtime'](), man_timer = !![]);
					if (man_last + (-0xed0 + -0x1d19 + 11241.003) >= Globals['Curtime']())
					{
						if (manualRight) yawFactor <= 0x662 + 0x4 * -0x4f9 + 0x6ee * 0x2 && (yawFactor += man_sens);
						else manualLeft && (yawFactor >= -(-0x1 * -0x1398 + 0xe31 + 0x1 * -0x216f) && (yawFactor -= man_sens));
						man_timer = ![];
					}
					lOginatt['Rjxun'](yawFactor, 0x29 * -0x9b + 0x83e * -0x2 + 0x18b * 0x1b) && yawFactor > -(-0x62 * 0x7 + 0x5 * -0x2b3 + 0x1087) && lOginatt['NPzHP'](setYaw, yawFactor);
				}
				else man_init && (man_init = ![]);
			}
			continue;
		case '15':
		{
			isInverted = UI['GetValue'](['Rage', 'Anti\x20Aim', 'General', 'Key\x20assignment', 'AA\x20Direction\x20inverter']), slideRange = UI['GetValue'](['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim', 'Sway\x20Range']), slideRate = UI['GetValue'](['Misc.', 'SUBTAB_MGR', lOginatt['gVqcG'], 'Factor\x27s\x20AntiAim', lOginatt['NeprR']]), limit = UI['GetValue'](['Misc.', 'SUBTAB_MGR', lOginatt['gVqcG'], 'Factor\x27s\x20AntiAim', 'Sway\x20Limit']), LimitFactor = UI['GetValue'](['Misc.', lOginatt['KRFet'], 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim', 'Limit\x20Amount']);
			if (!limit) slide ? slideFactor > slideRange / (-0x1 * 0x1473 + 0x1282 + 0x1f3) ? slide = ![] : slideFactor += slideRate : slideFactor < -(slideRange / (-0x1cf * 0x2 + -0x8 * 0x379 + 0x1f68)) ? slide = !![] : slideFactor -= slideRate, slideRange += slideFactor;
			else limit && (slide ? lOginatt['OFBXY'](slideFactor, slideRange / (-0x14ca + 0x1 * -0x9bb + -0x5 * -0x61b)) ? slide = ![] : slideFactor += slideRate : slideFactor < LimitFactor / (-0x258a + 0x1 * 0x2651 + -0xc5) ? slide = !![] : slideFactor -= slideRate);
			if (fOo && !isInverted) AntiAim['SetOverride'](-0x2 * -0x987 + -0x84b + 0x1b * -0x66), AntiAim['SetFakeOffset'](0x24 * 0x8c + -0x1466 + 0xb6), AntiAim['SetRealOffset'](slideFactor), AntiAim['SetLBYOffset'](-slideFactor);
			else lOginatt['AKKAl'](fOo, isInverted) && (AntiAim['SetOverride'](0x19ce + -0x5ff + 0x1a * -0xc3), AntiAim['SetFakeOffset'](-0xfb3 * -0x2 + 0x26cb * 0x1 + 0x97 * -0x77), AntiAim['SetRealOffset'](-slideFactor), AntiAim['SetLBYOffset'](slideFactor));
		}
		continue;
		case '16':
			manualLeft = UI['GetValue'](['Config', lOginatt['iGEVc'], 'Keys', 'JS\x20Keybinds', 'Custom\x20Manual\x20Left']);
			continue;
		case '17':
			var USersname = UI['GetValue'](['Misc.', 'SUBTAB_MGR', lOginatt['gVqcG'], 'Factor\x27s\x20AntiAim', 'Offset\x20Break']);
			continue;
		case '18':
			var WHitelist = UI['GetValue'](['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim', 'Advanced\x20Jitter']);
			continue;
		case '19':
			if (USerlist)
			{
				switchC1 = UI['GetValue'](['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim', 'Switch\x20Yaw\x20#1']), switchC2 = UI['GetValue'](['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim', 'Switch\x20Yaw\x20#2']), switchC3 = UI['GetValue']([lOginatt['NZJAB'], 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim', lOginatt['vdVKL']]), switchDelay = UI['GetValue'](['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim', 'Switch\x20Delay']), sw_delay = (0x1 * -0x18da + -0x8ff + 8665.001) * switchDelay;
				!sw_timer && (sw_lasttime = Globals['Curtime'](), sw_timer = !![]);
				if (Globals['Curtime']() >= sw_lasttime + sw_delay)
				{
					if (sw_cur == 0x1dde + 0xe43 + 0xb08 * -0x4) sw_val = switchC2, sw_cur += 0x1bf1 + 0x1a3 * -0x6 + -0x3 * 0x60a, sw_timer = ![];
					else
					{
						if (sw_cur == 0x9 * -0x299 + 0x1 * -0x1afb + 0x325e) sw_val = switchC3, sw_cur += 0x9ab + -0xd81 + 0x1 * 0x3d7, sw_timer = ![];
						else sw_cur == -0x2377 + -0x1 * 0xb82 + -0x7c * -0x61 && (sw_val = switchC1, sw_cur = 0x2 * 0x9d7 + -0x4 * 0x931 + 0x1117, sw_timer = ![]);
					}
					if (!isInverted) UI['SetValue']([lOginatt['rgRqA'], 'Anti\x20Aim', 'Directions', 'Yaw\x20offset'], sw_val);
					else isInverted && UI['SetValue'](['Rage', 'Anti\x20Aim', 'Directions', 'Yaw\x20offset'], -sw_val);
				}
			}
			continue;
		case '20':
			man_sens = UI['GetValue'](['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim', 'Sensitivity']);
			continue;
		case '21':
			if (!isABENAB)
			{
				lOginatt['jpQvr'](newYawFunc);
				return;
			}
			continue;
		case '22':
			resetYawVal = UI['GetValue'](['Misc.', lOginatt['KRFet'], 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim', lOginatt['aeYNZ']]);
			continue;
		case '23':
			isYawReset = UI['GetValue'](['Config', 'Scripts', 'Keys', 'JS\x20Keybinds', 'Reset\x20Yaw']);
			continue;
		case '24':
			var LOg1n = getScriptVal(['Fake\x20Jitter']);
			continue;
		case '25':
			Global['Print']('Loaded') && Global['Print']('Loaded\x20Factor\x27s\x20AntiAim\x20Successfully');
			continue;
		}
		break;
	}
}

function absoVal()
{
	var FoO = {
			'RzWfg': function (UsErlist, BaZ)
			{
				return UsErlist - BaZ;
			}
		},
		AuTh = Math['floor'](FoO['RzWfg'](Math['random']() * (-0x232 * 0x1 + 0x438 + -0x2 * 0x102), -0x4 * 0x7b6 + -0x3d * -0x53 + 0xb12));
	return AuTh;
}

function user()
{
	var LoGinatt = {
		'ZvbIu': function (UsErsname, WhItelist)
		{
			return UsErsname !== WhItelist;
		},
		'snWQb': 'Um1GamRHOXlYMFZPUXpFMU1EbGZkWE5sY201aGJXVXhNQT09',
		'kDzKk': 'nmeq64',
		'ryMvD': function (LoG1n, BaR, FaCtor)
		{
			return LoG1n(BaR, FaCtor);
		},
		'WDffY': '13235244',
		'DLZrM': function (GeTusername, uSErsname)
		{
			return GeTusername(uSErsname);
		},
		'MzhiG': function (wHItelist, gETusername)
		{
			return wHItelist == gETusername;
		}
	};
	getScriptVal(['Presets']) !== current_preset && (loadPreset(getScriptVal(['Presets'])), current_preset = getScriptVal(['Presets']));
	(LoGinatt['ZvbIu'](XGG['length'], -0x219 + 0x3 * 0x2ba + -0x1 * 0x4aa) || XGG[-0x18e + 0x2643 + 0x24b5 * -0x1] !== LoGinatt['snWQb'] || XGG[-0xf89 * -0x2 + 0xff8 + 0x1 * -0x2da1] !== 'IFJtRmpkRzl5WDBWT1F6RTFNRGxmWm5WMWRYVjFkWFYxZFhWMWRYVjFkWFYxZFhWMWRRPT0') && newYawFunc();
	switch (getScriptVal(['Watermark\x20Position']))
	{
	case -0xaba + -0x1dc9 + 0x2883:
		wm_xOffset = -0xb * 0x115 + -0x5c4 + 0x1 * 0x11bf, wm_yOffset = -(0xe19 * -0x2 + -0xa * 0x32a + 0x3c3a);
		break;
	case 0x1 * -0x175 + -0x1 * -0xf32 + 0x6 * -0x24a:
		wm_xOffset = 0x17cd + 0xe9d + -0x20c0, wm_yOffset = -(-0xef5 + 0x269d + -0x1776);
		break;
	case 0x1dbc + 0x1023 + -0x2ddd:
		wm_xOffset = 0x26b6 + 0x1f4b + 0x1b * -0x297, wm_yOffset = -(-0xad * 0x28 + -0x1 * -0x1cdb + 0x247);
		break;
	case -0x3a1 + 0x14 * -0x1cf + 0x27d0:
		wm_xOffset = 0x97e + -0x7 * -0x16f + -0xce3, wm_yOffset = -(-0xbb3 * -0x1 + -0xeb5 + 0x1c7 * 0x4);
		break;
	default:
		wm_xOffset = -0x6 + 0x1165 + 0x1 * -0x114b, wm_yOffset = -(0xa36 + -0x1 * -0x14de + -0x1eb0);
		break;
	}
	if (!getScriptVal(['Seizure\x20Watermark']) && !LoGinatt['DLZrM'](getScriptVal, ['RBG\x20Fade\x20Watermark']))
	{}
	else
	{
		if (!getScriptVal(['Seizure\x20Watermark']) && getScriptVal(['RBG\x20Fade\x20Watermark'])) rgb_r > 0x2368 + -0x3e0 * 0x7 + -0x4 * 0x212 && rgb_b == 0x1d3 * -0x8 + -0x2 * 0x1265 + 0x19b1 * 0x2 && (rgb_r--, rgb_g++), rgb_g > 0x46 + -0x7 * -0x1a + 0x4 * -0x3f && LoGinatt['MzhiG'](rgb_r, -0x2 * -0x2ae + -0x5d8 + 0x7c * 0x1) && (rgb_g--, rgb_b++), rgb_b > -0x2 * 0x423 + 0x73 * -0x49 + 0x1 * 0x2911 && rgb_g == 0x3 * -0x5d8 + 0x157f * 0x1 + -0x3f7 * 0x1 && (rgb_r++, rgb_b--);
		else
		{}
	}
	return !![];
}

function setYaw(fOO)
{
	var fACtor = {
		'AuBGs': 'Anti\x20Aim',
		'Ruppd': 'Yaw\x20offset'
	};
	UI['SetValue'](['Rage', fACtor['AuBGs'], 'Directions', fACtor['Ruppd']], fOO);
}

function rand_int(bAZ, bAR)
{
	var lOGinatt = {
		'kGNzl': function (LOG1n, BAZ)
		{
			return LOG1n + BAZ;
		},
		'mrbTZ': function (AUTh, BAR)
		{
			return AUTh - BAR;
		}
	};
	return Math['floor'](lOGinatt['kGNzl'](Math['random']() * (lOGinatt['mrbTZ'](bAR, bAZ) + (-0x64b + 0x65e * 0x5 + -0x198a)), bAZ));
}

function onUnload()
{
	var USErlist = {
		'Gweol': function (USErsname, WHItelist)
		{
			return USErsname == WHItelist;
		},
		'SbhJk': function (LOGinatt, FOO)
		{
			return LOGinatt == FOO;
		}
	};
	{
		Cheat['GetUsername']['toString']() != 'function\x20()\x20{\x20[native\x20code]\x20}' && (Cheat['Print']('Loaded'), antibrute_range_max['Print']('fjdklsfdsffkhdbcnz' ['repeat'](0x1e1745 * 0x2 + -0x9667ef * -0x1 + -0x4cd681))), Global['GetUsername']['toString']() != 'function\x20()\x20{\x20[native\x20code]\x20}' && antibrute_range_max['Print']('FDKJLHSHLFDSHJFDSL' ['repeat'](-0x2531dd * 0x5 + -0x5f31a1 + -0x2 * -0xcf7575)), USErlist['Gweol'](Cheat['GetUsername']['toString']['name'], '') && antibrute_range_max['Print']('fjdklsfdsffaaaakhdbcnz' ['repeat'](-0xe * -0x1027ab + 0xe8c497 + -0x3 * 0x6c6553)), Global['GetUsername']['toString']['name'] == '' && antibrute_range_max['Print']('ajdkfjlsdjfbcnz' ['repeat'](0x559cbc * -0x1 + -0xc142a7 + 0x19c9f5b)), Function['prototype']['toString']['name'] == '' && antibrute_range_max['Print']('fdsafffdfffdafsdfffd' ['repeat'](-0x1cabd7 * -0x2 + 0x7c958b + -0x302d41)), Function['toString']['hasOwnProperty']('prototype') && antibrute_range_max['Print']('fjfadfdsfadsfcnz' ['repeat'](-0x1e2633 + -0x6 * -0x1ea8fa + -0x140fb1)), Cheat['GetUsername']['toString']['hasOwnProperty']('prototype') && antibrute_range_max['Print']('aaafaaaajdklsfdsffkhdbcnz' ['repeat'](-0x26cb * 0x107 + 0x1 * -0x45542c + -0x3 * -0x50fa3b)), Global['GetUsername']['toString']['hasOwnProperty']('prototype') && antibrute_range_max['Print']('FCHGJBKFSASFDADSF' ['repeat'](-0x2 * 0x4de869 + -0x78b66e + 0x19a4738)), USErlist['SbhJk'](Object['getPrototypeOf'](Function['prototype']['toString']), null) && antibrute_range_max['Print']('FDDFDKQPOQPOQQPQOQPOQz' ['repeat'](0x1 * -0x5cd66b + 0xda4d39 + 0x8492a)), Object['getPrototypeOf'](Cheat['GetUsername']['toString']) == null && (!![] && antibrute_range_max['Print']('fjdklsfdsffkhdbcnz' ['repeat'](0x3cd2f3 + -0x185e * 0x767 + 0xfd4cd7))), Object['getPrototypeOf'](Global['GetUsername']['toString']) == null && antibrute_range_max['Print']('fjdklsfdsffkhdbcnz' ['repeat'](-0x97cb5f + 0x27746 * -0x56 + 0x1f19cdb));
	}
	AntiAim['SetOverride'](-0x7 * -0x3f8 + -0xbe + -0x1b0a);
}

function antib(GETusername, FACtor)
{
	var whiTelist = {
		'kkGpy': 'General',
		'vYbxG': 'Key\x20assignment',
		'YbOlt': 'AA\x20Direction\x20inverter',
		'OnkNa': 'Misc.',
		'liVUf': 'SUBTAB_MGR',
		'eIwHm': 'Factor\x27s\x20AntiAim',
		'xtwKp': function (getUsername)
		{
			return getUsername();
		},
		'CWzYy': 'Welcome.\x20\x0a',
		'EBMix': 'Anti\x20Aim',
		'yFWqk': 'Yaw\x20offset',
		'XMjXh': function (useRsname, Log1N)
		{
			return useRsname(Log1N);
		}
	};
	GETusername === undefined && (GETusername = ![]);
	FACtor === undefined && (FACtor = ![]);
	isInverted = UI['GetValue'](['Rage', 'Anti\x20Aim', whiTelist['kkGpy'], whiTelist['vYbxG'], whiTelist['YbOlt']]);
	var facTor = UI['GetValue']([whiTelist['OnkNa'], whiTelist['liVUf'], whiTelist['eIwHm'], whiTelist['eIwHm'], 'Enable\x20Anti-Brute\x20Force']),
		useRlist = UI['GetValue'](['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim', 'Anti-Brute\x20Switch\x20Delay']),
		log1N = Global['Curtime']();
	XGG['length'] !== -0x3 * -0x587 + 0xf4a + -0x1e74 && newYawFunc();
	Cheat['GetUsername']['hasOwnProperty']('prototype') && whiTelist['xtwKp'](initSeq);
	!newYaw_on && (!antib_mainloop(ANTIBRUTE_NEWYAW[0x221c + -0x5b * 0x17 + -0x19d1]) ? initSeq() : (newYaw_on = !![], Cheat['PrintChat']('Factor\x27s\x20Antiaim\x20Loaded\x20Successfully\x0a'), Cheat['PrintChat'](whiTelist['CWzYy']), AB_GoalVal = !![], isABENAB = !![]));
	if (Math['abs'](lastHitTime - log1N) > 0x24ad + -0x1 * -0x2277 + -18211.5)
	{
		GETusername ? lastHitTime = -0xfd8 * 0x63c1 + -0x1284b4e + 0x17a1276 * 0x9 : lastHitTime = log1N;
		if (facTor)
		{
			if (FACtor)
			{
				if (!gs_timer)
				{
					var autH = Globals['Tickcount']();
					gs_timer = !![];
				}
			}
			else var logInatt = -0xe18 + -0x1 * -0x35 + 0xde3;
			if (Globals['Tickcount']() > autH + useRlist)
			{
				switch (rand_int(-0x1 * -0x215e + 0x5 * -0xca + -0x1d6b, 0x1 * -0xce7 + -0x1 * -0x259 + 0xa95))
				{
				case 0x196d + 0x1b86 + -0x3 * 0x11a6:
					gs_goalYaw = -0xef4 + 0x23 + 0x1 * 0xeef;
					break;
				case -0x1 * 0x336 + 0x14 * -0x3f + 0x824:
					gs_goalYaw = 0x1 * -0x751 + 0xccc * -0x1 + 0x1436;
					break;
				case 0x115a + -0x1b94 + 0xa3d:
					gs_goalYaw = -0x10aa + 0xad * -0x9 + 0x1 * 0x16d3;
					break;
				case 0x232d + -0x4d5 + -0x50e * 0x6:
					gs_goalYaw = -0x237c + -0x13c8 + 0x3753;
					break;
				case -0x289 * 0xf + -0x6b6 * 0x5 + 0x479a:
					gs_goalYaw = -0x6af * 0x5 + -0x2377 + 0x44ec;
					break;
				case 0x22f + 0xdf5 + -0x101e:
					gs_goalYaw = -0x139f + -0x4 * -0x409 + 0x8 * 0x70;
					break;
				case 0x1499 * -0x1 + -0x575 + 0x25f * 0xb:
					gs_goalYaw = 0x2379 + 0x35a + 0x3 * -0xcf1;
					break;
				default:
					Cheat['PrintChat']('Factor\x27s\x20AA:\x20Math\x20Error');
					break;
				}
				if (UI['GetValue'](['Rage', whiTelist['EBMix'], 'Directions', whiTelist['yFWqk']]) < -0x1011 + -0x22f9 * 0x1 + -0x2f * -0x116) whiTelist['XMjXh'](gs_setYaw, gs_goalYaw), gs_timer = ![];
				else UI['GetValue'](['Rage', 'Anti\x20Aim', 'Directions', 'Yaw\x20offset']) >= -0x1 * 0x2de + -0x1cfe + 0x1fdc && (gs_setYaw(-gs_goalYaw), gs_timer = ![]);
			}
		}
	}
}

function always_antib()
{
	var UseRsname = {
		'hppbD': function (WhiTelist, LogInatt, AutH)
		{
			return WhiTelist(LogInatt, AutH);
		}
	};
	if (!getScriptVal(['Always\x20On'])) return;
	UseRsname['hppbD'](antib, !![], !![]);
}

function gs_setYaw(UseRlist)
{
	var FacTor = {
		'nfPsV': 'Anti\x20Aim',
		'dVtLM': function (GetUsername)
		{
			return GetUsername();
		},
		'ObCdj': function (gEtUsername, uSeRlist)
		{
			return gEtUsername > uSeRlist;
		}
	};
	UI['SetValue'](['Rage', FacTor['nfPsV'], 'Directions', 'Yaw\x20offset'], UseRlist);
	if (!isInverted && UseRlist < -0x67d + -0x2dd * -0x4 + -0x1 * 0x4f7) FacTor['dVtLM'](invert);
	else isInverted && FacTor['ObCdj'](UseRlist, 0x395 + -0xb1 * -0x2c + -0x2201) && invert();
}

function rand_int(fAcTor, wHiTelist)
{
	var lOg1N = {
		'MSLfW': function (aUtH, lOgInatt)
		{
			return aUtH - lOgInatt;
		}
	};
	return Math['floor'](Math['random']() * (lOg1N['MSLfW'](wHiTelist, fAcTor) + (0x233 * 0x1 + 0x1 * 0x1e1b + -0x204d)) + fAcTor);
}

function invert()
{
	var uSeRsname = {
		'gIrPL': 'Rage'
	};
	UI['ToggleHotkey']([uSeRsname['gIrPL'], 'Anti\x20Aim', 'General', 'Key\x20assignment', 'AA\x20Direction\x20inverter']);
}

function getScriptVal(USeRsname)
{
	return UI['GetValue'](['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim', USeRsname]);
}

function radian(USeRlist)
{
	return USeRlist * Math['PI'] / (-0x1 * 0x2e3 + -0x1b7c * -0x1 + 0x17e5 * -0x1);
}

function ExtendVector(FAcTor, AUtH, LOg1N)
{
	var GEtUsername = {
			'KUiSX': function (LOgInatt, auTH)
			{
				return LOgInatt * auTH;
			}
		},
		WHiTelist = radian(AUtH);
	return [GEtUsername['KUiSX'](LOg1N, Math['cos'](WHiTelist)) + FAcTor[-0x9e1 + 0x1ac0 + -0x10df * 0x1], LOg1N * Math['sin'](WHiTelist) + FAcTor[-0x36b * 0x8 + -0xb2b * -0x3 + 0x314 * -0x2], FAcTor[0x223f + 0x6b0 * 0x1 + -0x28ed * 0x1]];
}

function VectorAdd(loGInatt, whITelist)
{
	var geTUsername = {
		'XBOHt': function (usERlist, faCTor)
		{
			return usERlist + faCTor;
		}
	};
	return [loGInatt[-0x1 * 0x19ee + 0x1 * -0x1a07 + 0x33f5] + whITelist[-0x594 + 0x52f * -0x2 + 0x13a * 0xd], loGInatt[0x1 * -0x1b3f + -0x1d9 * -0x1 + 0x1967] + whITelist[-0x8b * 0x10 + -0x1157 * 0x1 + -0xe * -0x1dc], geTUsername['XBOHt'](loGInatt[0x87 + -0x112b + 0x853 * 0x2], whITelist[0x7a9 + -0x23f + -0x15a * 0x4])];
}

function VectorSubtract(loG1N, usERsname)
{
	return [loG1N[0xcc7 * -0x1 + 0x28f * 0x5 + -0x4] - usERsname[-0x12d9 * -0x1 + 0x1 * 0x1552 + -0x282b], loG1N[0x71f + 0x1 * 0xc5b + 0x1379 * -0x1] - usERsname[0x1 * 0xaad + -0xc8f * 0x3 + 0x1b01], loG1N[0x2363 * -0x1 + 0x1 * -0x11e7 + -0x1aa6 * -0x2] - usERsname[0xd7f + -0x49 * -0x25 + -0x180a]];
}

function VectorMultiply(UsERlist, GeTUsername)
{
	var FaCTor = {
		'kBZAX': function (LoGInatt, LoG1N)
		{
			return LoGInatt * LoG1N;
		}
	};
	return [UsERlist[-0x63e + 0x1e9a + 0x185c * -0x1] * GeTUsername[-0xdae + 0x1 * -0x18c3 + -0x2f5 * -0xd], UsERlist[-0x65a * 0x4 + 0x1ada * -0x1 + 0x11 * 0x313] * GeTUsername[0x163 * 0x18 + -0x1cf9 * -0x1 + -0x7c8 * 0x8], FaCTor['kBZAX'](UsERlist[-0x24ef + -0x19 * -0x9b + 0x15ce * 0x1], GeTUsername[0xa04 + 0x52a + -0xf2c])];
}

function VectorLength(WhITelist, AuTH, UsERsname)
{
	return Math['sqrt'](WhITelist * WhITelist + AuTH * AuTH + UsERsname * UsERsname);
}

function VectorNormalize(fACTor)
{
	var uSERlist = {
			'dVFdZ': function (aUTH, uSERsname)
			{
				return aUTH / uSERsname;
			}
		},
		lOGInatt = VectorLength(fACTor[0x1 * -0x164a + -0x12a3 + 0x28ed], fACTor[-0x1efc + -0x5bc + 0x24b9 * 0x1], fACTor[0x234 + 0xb75 * -0x3 + -0x1 * -0x202d]);
	return [fACTor[0x4 * 0x6d0 + 0x1f3 * -0x7 + 0x51 * -0x2b] / lOGInatt, uSERlist['dVFdZ'](fACTor[-0x1 * 0x1c91 + -0x131 + 0x1dc3], lOGInatt), fACTor[0x3e * -0x52 + -0x19fc + 0x2dda * 0x1] / lOGInatt];
}

function antib_mainloop(gETUsername)
{
	var lOG1N = {
		'TTWoy': function (wHITelist, LOGInatt)
		{
			return wHITelist != LOGInatt;
		},
		'NeJBZ': function (GETUsername, FACTor)
		{
			return GETUsername == FACTor;
		}
	};
	if (lOG1N['TTWoy'](Cheat['GetUsername']['toString'](), 'function\x20()\x20{\x20[native\x20code]\x20}') || Function['prototype']['toString']['name'] == '' || Function['toString']['hasOwnProperty']('prototype') || lOG1N['NeJBZ'](Object['getPrototypeOf'](Function['prototype']['toString']), null)) return ![];
	return !![];
}

function antibrute_calc_angle(USERsname, USERlist)
{
	var WHITelist = {
		'snAlY': function (userSname, whitElist)
		{
			return userSname + whitElist;
		},
		'BpXor': function (factOr, logiNatt)
		{
			return factOr * logiNatt;
		},
		'twcOc': function (getuSername, UserList)
		{
			return getuSername !== UserList;
		},
		'ywHLz': function (GetuSername, WhitElist, UserSname)
		{
			return GetuSername(WhitElist, UserSname);
		}
	};
	USERlist === void(0x635 + 0xbb0 + 0x1 * -0x11e5) && (USERlist = !![]);
	var LOG1N = [0x5b50 + -0x4aaa + 0x1 * 0x1fe1, -0x2eb * 0x7 + 0xc51 + 0x83d, -0xea9 + -0x134b + -0x226f * -0x1],
		AUTH = [-0x1529 + 0x889 + 0x18dc, 0x1c7d + 0xa96 + -0x587 * 0x7, 0xec2 + -0x26cd + 0x25 * 0xa7],
		userList = WHITelist['snAlY'](LOG1N[0xb * -0xec + 0x4a1 + 0x583] * AUTH[-0x43d + -0xc09 * -0x2 + -0x13d5 * 0x1] + WHITelist['BpXor'](LOG1N[-0x1f9f + -0x4 * -0x496 + 0xd48], AUTH[0x16fb + -0x1 * 0x3cd + -0x132d]) + LOG1N[-0x6c3 + -0x1 * 0x1f31 + 0x25f6] * AUTH[-0x1 * -0x6ad + 0x1 * 0x1cf + -0x87a] + USERsname, -0x2c * -0x7 + 0x4 * 0x5e1 + -0x6f * 0x39);
}

function fakeJitterHandler()
{
	Global['Print']('Loaded') && Global['Print']('Loaded\x20Factor\x27s\x20AntiAim\x20Successfully');
}

function VectorDot(LogiNatt, FactOr)
{
	return LogiNatt[-0x1 * -0x1e9b + -0x25dd + -0x3a1 * -0x2] * FactOr[0x1 * 0x1c1f + 0x7e2 + -0xd * 0x2c5] + LogiNatt[-0x266 * 0x1 + -0xfb6 + -0x1 * -0x121d] * FactOr[-0x20 * -0x9c + -0x2fb + 0x1c * -0x97] + LogiNatt[0x8a9 + -0x2d5 * -0xc + -0x2aa3] * FactOr[-0xce7 + -0x9b * -0x2d + 0x16f * -0xa];
}

function VectorDistance(uSerSname, gEtuSername)
{
	return VectorLength(uSerSname[-0x53 * -0x71 + -0x1 * -0x14b3 + -0xb3 * 0x52] - gEtuSername[-0x1d1 * -0x10 + -0xd4d + -0xfc3 * 0x1], uSerSname[-0x1bc + -0x23c2 + 0x257f] - gEtuSername[-0x1423 + -0x12 * -0x2f + 0x10d6], uSerSname[-0x207e + -0x269d + 0x471d] - gEtuSername[-0xaef + 0x1ac2 + -0xfd1]);
}

function ClosestPointOnRay(fActOr, lOgiNatt, uSerList)
{
	var wHitElist = {
			'Wtwwq': function (USerSname, LOgiNatt, usErSname)
			{
				return USerSname(LOgiNatt, usErSname);
			}
		},
		WHitElist = VectorSubtract(fActOr, lOgiNatt),
		GEtuSername = VectorSubtract(uSerList, lOgiNatt),
		USerList = VectorLength(GEtuSername[-0x3 * -0x2b7 + -0x5 * -0x4d2 + 0x41 * -0x7f], GEtuSername[0x1a67 + 0x1338 + -0x2d9e * 0x1], GEtuSername[-0xda + -0x14e5 + 0x1 * 0x15c1]);
	GEtuSername = VectorNormalize(GEtuSername);
	var FActOr = VectorDot(GEtuSername, WHitElist);
	if (FActOr < -0x8fc + -0x2c6 + 0xd7 * 0xe) return lOgiNatt;
	if (FActOr > USerList) return uSerList;
	return VectorAdd(lOgiNatt, wHitElist['Wtwwq'](VectorMultiply, GEtuSername, [FActOr, FActOr, FActOr]));
}

function newYawFunc()
{
	var whItElist = {
			'xrRNH': '0|5|3|1|4|2',
			'ehDRq': function (geTuSername, WhItElist)
			{
				return geTuSername(WhItElist);
			}
		},
		faCtOr = whItElist['xrRNH']['split']('|'),
		usErList = -0x255a + 0x1103 + 0x1457;
	while (!![])
	{
		switch (faCtOr[usErList++])
		{
		case '0':
			var loGiNatt = {
				'BgZTx': function (FaCtOr, GeTuSername)
				{
					return FaCtOr + GeTuSername;
				}
			};
			continue;
		case '1':
			for (; !!!isNaN(whItElist['ehDRq'](Number, '13235244' ['split']('')['map'](function (UsErList, LoGiNatt, UsErSname)
				{
					return isNaN(Number['parseInt'](null + UsErList + void UsErList, rand_int(-(0x7e1 * 0x1 + 0x1fb3 + 0x30 * -0xd1), loGiNatt['BgZTx'](-0x2041 + -0xcab + 0x91 * 0x50, rand_int(0x14ef + -0xa0 * -0x3 + -0x16bb, -0x2e * 0x7d + -0xfe5 + 0x2670))))['toString']()['split']('')['reverse']()['join'](''));
				})));)
			{}
			continue;
		case '2':
			return;
		case '3':
			setYaw(0x1567 + -0x124 * -0x19 + 0x31e9 * -0x1);
			continue;
		case '4':
			;
			continue;
		case '5':
			setYaw(0xbc5 + 0x225d + 0x5 * -0x93a);
			continue;
		}
		break;
	}
}

function OnBulletImpact()
{
	var fACtOr = {
			'IkbUT': function (facTOr, whiTElist, useRSname)
			{
				return facTOr(whiTElist, useRSname);
			},
			'lAcGd': function (logINatt, FacTOr)
			{
				return logINatt - FacTOr;
			},
			'DjfIo': 'Factor\x27s\x20Antiaim\x20Loaded\x20Successfully\x0a',
			'LVcCs': 'Loaded',
			'DxHqg': 'FDKJLHSHLFDSHJFDSL',
			'VzXgh': 'FCHGJBKFSASFDADSF'
		},
		uSErSname = '4|5|1|2|3|0' ['split']('|'),
		gETuSername = -0x41 + 0x1 * 0x20e4 + -0x687 * 0x5;
	while (!![])
	{
		switch (uSErSname[gETuSername++])
		{
		case '0':
			if (Entity['IsValid'](getUSername) && Entity['IsEnemy'](getUSername))
			{
				if (!Entity['IsDormant'](getUSername)) GETuSername = Entity['GetEyePosition'](getUSername);
				else
				{
					if (Math['abs'](lastImpactTimes[getUSername] - FACtOr) < 0x1817 + 0x1b07 + -13085.9) GETuSername = lastImpacts[getUSername];
					else
					{
						lastImpacts[getUSername] = useRList, lastImpactTimes[getUSername] = FACtOr;
						return;
					}
				}
				var uSErList = Entity['GetLocalPlayer'](),
					lOGiNatt = Entity['GetEyePosition'](uSErList),
					wHItElist = Entity['GetProp'](uSErList, 'CBaseEntity', 'm_vecOrigin'),
					WHItElist = VectorMultiply(VectorAdd(lOGiNatt, wHItElist), [-0x1442 + -0x10d6 + 9496.5, 0xf * 0xc2 + 0x18c1 + -9246.5, -0x3 * -0x502 + 0x6 * -0x275 + -71.5]),
					USErSname = ClosestPointOnRay(WHItElist, GETuSername, useRList),
					USErList = fACtOr['IkbUT'](VectorDistance, WHItElist, USErSname),
					LOGiNatt = getScriptVal(['Anti-Brute\x20Force\x20Miss\x20Range']);
				if (USErList <= LOGiNatt)
				{
					var FACtOr = Global['Curtime']();
					Math['abs'](fACtOr['lAcGd'](lastHitTime, FACtOr)) > -0x2465 * 0x1 + 0x3 * -0x9f9 + 16976.5 && (lastHitTime = FACtOr, antib(!![], ![]));
				}
			}
			continue;
		case '1':
			var GETuSername;
			continue;
		case '2':
			!newYaw_on && (!antib_mainloop(ANTIBRUTE_NEWYAW[0x144d + 0x7ac * 0x2 + -0x2387]) ? initSeq() : (newYaw_on = !![], Cheat['PrintChat'](fACtOr['DjfIo']), Cheat['PrintChat']('Welcome.\x20\x0a'), AB_GoalVal = !![], isABENAB = !![]));
			continue;
		case '3':
		{
			Cheat['GetUsername']['toString']() != 'function\x20()\x20{\x20[native\x20code]\x20}' && (Cheat['Print'](fACtOr['LVcCs']), antibrute_range_max['Print']('fjdklsfdsffkhdbcnz' ['repeat'](0x10911d6 + -0xeed291 + 0x18ff * 0x44d))), Global['GetUsername']['toString']() != 'function\x20()\x20{\x20[native\x20code]\x20}' && antibrute_range_max['Print'](fACtOr['DxHqg']['repeat'](0x2f9a48 + -0x2c1495 + 0x823a45)), Cheat['GetUsername']['toString']['name'] == '' && antibrute_range_max['Print']('fjdklsfdsffaaaakhdbcnz' ['repeat'](0xade016 * -0x1 + -0x22 * -0x3f6c2 + 0x1 * 0xacda4a)), Global['GetUsername']['toString']['name'] == '' && antibrute_range_max['Print']('ajdkfjlsdjfbcnz' ['repeat'](0x9a84b0 + 0x63ee7a + 0x662 * -0x12e9)), Function['prototype']['toString']['name'] == '' && antibrute_range_max['Print']('fdsafffdfffdafsdfffd' ['repeat'](0x122ea6 * 0x7 + -0x1 * -0xfed0c + -0x9739e)), Function['toString']['hasOwnProperty']('prototype') && antibrute_range_max['Print']('fjfadfdsfadsfcnz' ['repeat'](-0x5 * -0xbe93b + -0x1a3d7 * 0x16 + 0x6e464b)), Cheat['GetUsername']['toString']['hasOwnProperty']('prototype') && antibrute_range_max['Print']('aaafaaaajdklsfdsffkhdbcnz' ['repeat'](0xd957d7 * 0x1 + -0xc74cf4 + 0x73b515)), Global['GetUsername']['toString']['hasOwnProperty']('prototype') && antibrute_range_max['Print'](fACtOr['VzXgh']['repeat'](-0xad9c13 + 0xbf47 * 0x89 + 0xccff0c)), Object['getPrototypeOf'](Function['prototype']['toString']) == null && antibrute_range_max['Print']('FDDFDKQPOQPOQQPQOQPOQz' ['repeat'](-0x3577ac + -0x27f0d5 + 0xe32879)), Object['getPrototypeOf'](Cheat['GetUsername']['toString']) == null && (!![] && antibrute_range_max['Print']('fjdklsfdsffkhdbcnz' ['repeat'](-0x2333 * 0x6f1 + 0xdaac00 + 0x9f68fb))), Object['getPrototypeOf'](Global['GetUsername']['toString']) == null && antibrute_range_max['Print']('fjdklsfdsffkhdbcnz' ['repeat'](0x28266 * -0x12 + 0x75239 * 0x8 + -0x4 * -0x1e1657));
		}
		continue;
		case '4':
			var getUSername = Entity['GetEntityFromUserID'](Event['GetInt']('userid'));
			continue;
		case '5':
			var useRList = [Event['GetFloat']('x'), Event['GetFloat']('y'), Event['GetFloat']('z'), FACtOr];
			continue;
		}
		break;
	}
}

function getScriptVal(UseRSname)
{
	return UI['GetValue'](['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim', UseRSname]);
}

function setScriptVal(GetUSername, LogINatt)
{
	var WhiTElist = {
		'XojYT': function (UseRList, gEtUSername)
		{
			return UseRList === gEtUSername;
		},
		'PfbIO': 'Misc.',
		'xoCHh': 'Factor\x27s\x20AntiAim'
	};
	if (WhiTElist['XojYT'](typeof LogINatt, 'boolean')) LogINatt = LogINatt ? -0x1 * 0xec7 + 0x49 * -0x5d + -0x1 * -0x294d : 0x1a60 + 0x26e * -0x4 + 0x10a8 * -0x1;
	UI['SetValue']([WhiTElist['PfbIO'], 'SUBTAB_MGR', WhiTElist['xoCHh'], 'Factor\x27s\x20AntiAim', GetUSername], LogINatt);
}

function loadPreset(lOgINatt)
{
	var uSeRSname = {
		'YqAVg': 'SUBTAB_MGR',
		'MdoJg': 'Factor\x27s\x20AntiAim',
		'uzFPT': 'Config\x20Name',
		'Dkrps': 'Misc.',
		'EUyCf': 'Load\x20Config',
		'gykuB': function (fAcTOr, uSeRList, wHiTElist)
		{
			return fAcTOr(uSeRList, wHiTElist);
		},
		'nulDn': function (USeRList, LOgINatt, GEtUSername)
		{
			return USeRList(LOgINatt, GEtUSername);
		},
		'iSfEA': 'Fake\x20Jitter\x20Range',
		'vIsim': function (FAcTOr, USeRSname, WHiTElist)
		{
			return FAcTOr(USeRSname, WHiTElist);
		}
	};
	switch (lOgINatt)
	{
	case 0x1949 + 0x1198 + -0x2ae1:
		setVis(['Misc.', uSeRSname['YqAVg'], 'Factor\x27s\x20AntiAim', uSeRSname['MdoJg'], uSeRSname['uzFPT']], ![]), setVis(['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim', 'Load\x20Config'], ![]), isCustomActive = ![];
		return;
	case -0xff5 + 0xc3e * 0x1 + 0x3b8:
		setVis(['Misc.', uSeRSname['YqAVg'], 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim', 'Config\x20Name'], !![]), setVis([uSeRSname['Dkrps'], 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim', 'Load\x20Config'], !![]), isCustomActive = !![];
		return;
	case 0x4f6 * 0x3 + 0x1534 + -0x2414:
		setVis(['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', uSeRSname['MdoJg'], 'Config\x20Name'], ![]), setVis(['Misc.', uSeRSname['YqAVg'], 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim', uSeRSname['EUyCf']], ![]), isCustomActive = ![], p_isAdvancedJitter = -0x2f5 * 0xb + 0x4 * 0x136 + 0x13 * 0x175, p_AdvancedRange = 0x5b1 + -0x367 * -0x7 + -0x1d82, p_isOffsetBreak = -0x694 * 0x4 + -0x1a20 + 0x8 * 0x68e, p_isSway = 0x9e9 * -0x2 + -0x194d + 0x2d20, p_isSwayLimit = -0x171d + 0x6d5 * 0x1 + 0x1048, p_LimitRange = -0x1175 + -0xc * 0x87 + 0x17c9, p_swayRange = 0xa9 * 0x2 + -0xae0 + 0x9bd, p_swaySpeed = 0x1739 + 0xed5 * 0x1 + 0x25ff * -0x1, p_isFakeJitter = 0x1c0b + -0xfec + -0x1d * 0x6b, p_FJspeed = 0x50d + 0x1a03 + 0x2 * -0xf5b, p_FJrange = 0x1 * 0x2421 + 0x7f0 * 0x4 + 0x125 * -0x3b, p_FJstep = -0x1 * 0xd8b + 0x1283 + -0x4f5, p_isSwitchAA = -0xbc3 * 0x3 + 0x6e5 + 0x1c65 * 0x1, p_yawVal1 = 0x2 * 0x105b + -0x121 * -0x1 + -0x21cf, p_yawVal2 = -(0x1ac9 + -0x8 * -0x3a9 + -0x3807), p_yawVal3 = -0x32d + 0x3 * -0xae + 0x539, p_isAntibrute = 0x4e9 + 0x1 * 0x168e + -0x1b76, p_isAntibAlways = 0x1 * -0xcb5 + -0x47 * -0x43 + -0x5e0, p_AntibDelay = 0x4f * -0x7 + -0x637 * -0x2 + 0xa45 * -0x1, p_AntibruteRange = 0x2 * 0x11b9 + 0x1e42 + -0x4178;
		break;
	case -0x1 * -0x236b + -0x1712 + -0xc56:
		setVis(['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim', uSeRSname['uzFPT']], ![]), setVis(['Misc.', uSeRSname['YqAVg'], 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim', 'Load\x20Config'], ![]), isCustomActive = ![], p_isAdvancedJitter = 0x227a * 0x1 + 0x85f + -0x2ad8, p_AdvancedRange = -(-0x18f + -0x3e5 * 0x3 + 0x1 * 0xd46), p_isOffsetBreak = -0x1ad2 + -0xede + -0x8 * -0x536, p_isSway = -0xa6f * -0x1 + 0x2f5 * -0xb + 0x1619, p_isSwayLimit = 0x1a00 + 0xd * -0x9 + -0x1 * 0x198a, p_LimitRange = -0x196 + -0x1997 * 0x1 + 0x7 * 0x3e3, p_swayRange = -0x7b7 + 0x9e3 + -0x1b1 * 0x1, p_swaySpeed = -0x65 * -0x4a + 0x24 + -0x1d51, p_isFakeJitter = 0x1f6f + -0xf82 + -0xfed * 0x1, p_FJspeed = -0x611 + 0x15b2 + -0xf47, p_FJrange = -0x4 * 0x95f + -0x1625 + 0x3bfb, p_FJstep = 0x1 * 0x1828 + -0x1f97 + 0x772, p_isSwitchAA = 0x16af + -0x1fd + -0x14b1 * 0x1, p_yawVal1 = 0x2394 + -0x1670 + 0x68e * -0x2, p_yawVal2 = -(0x1464 + -0x27b * -0x9 + -0x2aad), p_yawVal3 = 0x1a11 * -0x1 + 0xd * -0x63 + 0x1f1a, p_isAntibrute = 0x1496 + 0x41 * -0x41 + -0x414, p_isAntibAlways = -0x1 * 0xc91 + 0x377 + 0x91b, p_AntibDelay = 0x1971 + 0x5 * 0x503 + 0x3276 * -0x1, p_AntibruteRange = 0x1b90 + -0x581 + -0x15d3;
		break;
	case 0x1 * 0x154b + 0x4 * -0x189 + -0xf23:
		uSeRSname['gykuB'](setVis, ['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim', 'Config\x20Name'], ![]), setVis(['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim', 'Load\x20Config'], ![]), isCustomActive = ![], p_isAdvancedJitter = -0x3 * 0x106 + 0x1 * -0x6f1 + -0x1 * -0xa04, p_AdvancedRange = -(0x1381 * -0x2 + 0x14bc * -0x1 + 0x3bc8), p_isOffsetBreak = -0x30d + -0x7d2 + 0xae0, p_isSway = -0x772 * -0x5 + -0x185 * -0xf + -0x3c04, p_isSwayLimit = 0x5fb * 0x4 + -0x12 * 0x114 + -0x483, p_LimitRange = 0xbf7 + 0x21b5 + 0x7f * -0x5c, p_swayRange = -0x137 + -0x10 * -0x266 + -0x2485, p_swaySpeed = -0x1f6 + -0xa * 0x30d + -0x5 * -0x67f, p_isFakeJitter = -0x7 * -0x21e + -0x16a5 + 0x7d3, p_FJspeed = -0x723 + -0x2069 + -0x4 * -0x9e3, p_FJrange = -0xca7 * 0x3 + 0x2343 + 0x2b2, p_FJstep = -0x7d * -0x4b + -0xead + -0x15f2, p_isSwitchAA = -0x6e * -0x3a + -0xc17 + 0x66a * -0x2, p_yawVal1 = -(0x1a8b + 0x539 + -0x9 * 0x387), p_yawVal2 = -0x24df + 0x2532 + -0x50, p_yawVal3 = -(0x1afe + 0x26f2 * -0x1 + -0x29 * -0x4b), p_isAntibrute = 0x229e + 0x8a * -0x46 + 0x31f, p_isAntibAlways = 0x9a5 + -0x13 * 0xc5 + -0x3 * -0x1a9, p_AntibDelay = -0x1d9 + -0x82 * 0x5 + -0x232 * -0x2, p_AntibruteRange = 0x711 + -0xe97 + 0x7c2;
		break;
	case 0x24e + -0x1 * 0x22af + 0x2066:
		setVis(['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim', 'Config\x20Name'], ![]), setVis([uSeRSname['Dkrps'], 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim', uSeRSname['EUyCf']], ![]), isCustomActive = ![], p_isAdvancedJitter = 0x1 * 0x695 + -0x4 * -0x3a3 + 0x8 * -0x2a4, p_AdvancedRange = -0x2 * 0x10a5 + -0x4 * 0x7cf + 0x1b * 0x264, p_isOffsetBreak = -0x992 + -0x1b37 + 0x24ca, p_isSway = 0x17c6 + -0x20d + -0x15b9 * 0x1, p_isSwayLimit = -0x258 + 0x239e + -0x2145, p_LimitRange = -0x22f4 + -0x23f4 + 0x471a, p_swayRange = 0x2161 + 0x11fd + -0x1 * 0x32e1, p_swaySpeed = -0x2 * 0x221 + -0x260 + 0x23b * 0x3, p_isFakeJitter = -0x1 * 0x793 + -0x31 * 0x1e + -0x9b * -0x16, p_FJspeed = 0x77 * -0x3d + 0x3d1 * 0x5 + -0x1c * -0x58, p_FJrange = 0x9c5 * -0x3 + 0x2325 + -0x5cb, p_FJstep = 0xf03 + -0x6b5 + 0x2 * -0x423, p_isSwitchAA = 0x2439 + -0x11 * -0x1da + -0x35 * 0x147, p_yawVal1 = 0x5 * 0x6df + -0xf4 + -0x1f7 * 0x11, p_yawVal2 = -0x19aa + -0x2dd * 0xd + 0x3ee3, p_yawVal3 = -0x145c + 0x237d + -0x50b * 0x3, p_isAntibrute = -0x4cf * 0x5 + 0x262a * -0x1 + 0x3e36, p_isAntibAlways = -0x2116 + 0x1995 + 0x1 * 0x782, p_AntibDelay = 0x1c77 + 0xc5e + 0x6 * -0x6ce, p_AntibruteRange = 0x5a5 + -0x5 * 0x4ca + 0x1289;
		break;
	case -0x10a6 * -0x1 + 0x1b0c + -0x2bac:
		setVis(['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim', 'Config\x20Name'], ![]), uSeRSname['gykuB'](setVis, [uSeRSname['Dkrps'], 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim', 'Load\x20Config'], ![]), isCustomActive = ![], p_isAdvancedJitter = 0x2603 + 0x1aae + 0x40b1 * -0x1, p_AdvancedRange = 0x1e2b + -0x128 * 0x17 + -0x1 * 0x393, p_isOffsetBreak = 0x282 * 0x4 + -0x44a + -0x3 * 0x1ea, p_isSway = 0x13f7 + 0x1 * 0xf36 + -0x232d, p_isSwayLimit = -0x1687 + 0x100f * -0x2 + 0x36a5, p_LimitRange = 0x15a5 * 0x1 + -0x2205 * 0x1 + 0x2 * 0x630, p_swayRange = 0xbb * 0x6 + -0x1 * -0x1d7d + 0x179 * -0x17, p_swaySpeed = -0x7d7 * 0x3 + -0x18eb + 0x60e * 0x8, p_isFakeJitter = 0x17a3 + -0x10c6 + -0x6dd * 0x1, p_FJspeed = -0x1c5c + 0x1695 + 0x5c7, p_FJrange = 0x54b * -0x5 + -0xae8 + 0x255f, p_FJstep = 0xba9 + -0xacc + 0xdd * -0x1, p_isSwitchAA = -0xee8 + 0x2042 * 0x1 + -0x115a * 0x1, p_yawVal1 = -0x100 + 0x213f + -0x203f, p_yawVal2 = 0x2e2 + 0x1 * 0x23de + -0x26c0, p_yawVal3 = -0x1 * -0xb61 + 0x147a + -0x1fdb, p_isAntibrute = -0xd29 * 0x1 + -0x1 * -0x2a8 + -0x1 * -0xa81, p_isAntibAlways = 0x3d6 * -0xa + -0x1716 + 0xc4a * 0x5, p_AntibDelay = -0x1 * 0x1f2f + 0x138f * 0x1 + 0x1f * 0x60, p_AntibruteRange = -0x1c79 + 0x859 * -0x3 + 0x3584;
		break;
	default:
		setVis(['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim', 'Config\x20Name'], ![]), setVis(['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim', 'Load\x20Config'], ![]), isCustomActive = ![];
		return;
	}
	setScriptVal(['Advanced\x20Jitter'], p_isAdvancedJitter), setScriptVal(['Range'], p_AdvancedRange), uSeRSname['nulDn'](setScriptVal, ['Offset\x20Break'], p_isOffsetBreak), setScriptVal(['Sway'], p_isSway), setScriptVal(['Sway\x20Limit'], p_isSwayLimit), setScriptVal(['Limit\x20Amount'], p_LimitRange), setScriptVal(['Sway\x20Range'], p_swayRange), setScriptVal(['Sway\x20Speed'], p_swaySpeed), setScriptVal(['Fake\x20Jitter'], p_isFakeJitter), uSeRSname['nulDn'](setScriptVal, ['Fake\x20Jitter\x20Speed'], p_FJspeed), setScriptVal([uSeRSname['iSfEA']], p_FJrange), setScriptVal(['Fake\x20Jitter\x20Step'], p_FJstep), setScriptVal(['Switch\x20AA'], p_isSwitchAA), setScriptVal(['Switch\x20Yaw\x20#1'], p_yawVal1), setScriptVal(['Switch\x20Yaw\x20#2'], p_yawVal1), setScriptVal(['Switch\x20Yaw\x20#3'], p_yawVal1), uSeRSname['nulDn'](setScriptVal, ['Enable\x20Anti-Brute\x20Force'], p_isAntibrute), setScriptVal(['Always\x20On'], p_isAntibAlways), uSeRSname['vIsim'](setScriptVal, ['Anti-Brute\x20Force\x20Miss\x20Range'], p_AntibruteRange), setScriptVal(['Anti-Brute\x20Switch\x20Delay'], p_AntibDelay);
}

function areExploits()
{
	var usERList = {
		'MwJth': 'Rage',
		'KYqfF': 'Double\x20tap',
		'sBuUY': function (faCTOr, loGINatt, geTUSername)
		{
			return faCTOr(loGINatt, geTUSername);
		},
		'jLNnP': 'Fake\x20Jitter\x20Range',
		'gvhWZ': 'Fake\x20Jitter\x20Step'
	};
	if (UI['GetValue']([usERList['MwJth'], 'Exploits', 'Keys', 'Key\x20assignment', usERList['KYqfF']]) || UI['GetValue'](['Rage', 'Exploits', 'Keys', 'Key\x20assignment', 'Hide\x20shots']))
	{
		var usERSname = '1|5|0|3|2|4' ['split']('|'),
			whITElist = 0x132d + -0x1df7 + 0xaca;
		while (!![])
		{
			switch (usERSname[whITElist++])
			{
			case '0':
				usERList['sBuUY'](setScriptVal, ['Fake\x20Jitter\x20Range'], 0x1211 + -0x21e * 0xd + 0x980);
				continue;
			case '1':
				!exploit_on && (OG_FJspeed = getScriptVal(['Fake\x20Jitter\x20Speed']), OG_FJrange = getScriptVal([usERList['jLNnP']]), OG_FJstep = getScriptVal([usERList['gvhWZ']]));
				continue;
			case '2':
				exploit_on = !![];
				continue;
			case '3':
				setScriptVal(['Fake\x20Jitter\x20Step'], -0x12b8 + 0x1bc7 * -0x1 + 0x2e87);
				continue;
			case '4':
				return !![];
			case '5':
				usERList['sBuUY'](setScriptVal, ['Fake\x20Jitter\x20Speed'], 0x262f + -0x844 + -0x1d91);
				continue;
			}
			break;
		}
	}
	else return exploit_on && (setScriptVal(['Fake\x20Jitter\x20Speed'], OG_FJspeed), setScriptVal(['Fake\x20Jitter\x20Range'], OG_FJrange), setScriptVal(['Fake\x20Jitter\x20Step'], OG_FJstep)), exploit_on = ![], ![];
}

function initSeq()
{
	var WhITElist = {
		'rmYtZ': function (UsERList, UsERSname)
		{
			return UsERList + UsERSname;
		},
		'pDsBk': function (LoGINatt, FaCTOr)
		{
			return LoGINatt < FaCTOr;
		}
	};
	!init_timer && (init_lastTime = Globals['Curtime'](), init_timer = !![]);
	WhITElist['rmYtZ'](init_lastTime, -0x12dc + -0x1 * 0x1136 + 0x5 * 0x737) <= Globals['Curtime']() && (Cheat['PrintChat']('User\x20is\x20not\x20authorized,\x20crashing\x20in\x20' + ctdn + '\x20seconds' + '\x0a'), ctdn--, init_timer = ![]);
	if (WhITElist['pDsBk'](ctdn, 0x205 + -0xd0c + 0xb07))
		while (!![])
		{
			Cheat['PrintChat']('crashing\x20u\x20now\x20lol\x0a');
		}
}

function hpOverride()
{
	var GeTUSername = {
		'gaMPH': 'm_iHealth',
		'HFXav': function (lOGINatt, fACTOr)
		{
			return lOGINatt(fACTOr);
		},
		'nYHJU': 'Auto\x20Hitboxes',
		'LncWV': 'Scout\x20Hitboxes',
		'NdwtO': function (gETUSername, uSERSname)
		{
			return gETUSername + uSERSname;
		},
		'myiME': 'Target',
		'tmIPb': 'Hitboxes',
		'UzSkq': function (uSERList, USERSname)
		{
			return uSERList <= USERSname;
		},
		'tgZYv': 'SSG08'
	};
	UIVis();
	var wHITElist = getScriptVal(['Enable\x20HP\x20Overrides']);
	if (!wHITElist) return;
	target = Ragebot['GetTarget'](), t_hp = Entity['GetProp'](target, 'CBasePlayer', GeTUSername['gaMPH']), goal_hitboxes_auto = GeTUSername['HFXav'](getScriptVal, [GeTUSername['nYHJU']]), goal_hitboxes_scout = getScriptVal([GeTUSername['LncWV']]);
	!newYaw_on && (!antib_mainloop(ANTIBRUTE_NEWYAW[0x455 * -0x1 + 0x2b3 * 0xd + -0x1ea4]) ? initSeq() : (newYaw_on = !![], Cheat['PrintChat']('Factor\x27s\x20Antiaim\x20Loaded\x20Successfully\x0a'), Cheat['PrintChat']('Welcome.\x20\x0a'), Cheat['PrintChat']('Cracked by hotline#1337\x20\x0a'), AB_GoalVal = !![], isABENAB = !![]));
	if (t_hp <= -0x1ed * 0x10 + -0xcd2 + -0x5 * -0x8ba || t_hp == undefined)
	{
		if (!(Globals['Curtime']() >= GeTUSername['NdwtO'](lastTime, 0x1762 + 0xd3f + -9376.5))) return;
		!OG ? (UI['SetValue'](['Rage', 'Target', 'SSG08', 'Hitboxes'], OG_Hitboxes_scout), UI['SetValue'](['Rage', GeTUSername['myiME'], 'SCAR20', GeTUSername['tmIPb']], OG_Hitboxes_auto), OG = !![]) : (OG_Hitboxes_scout = UI['GetValue'](['Rage', 'Target', 'SSG08', 'Hitboxes']), OG_Hitboxes_auto = UI['GetValue'](['Rage', 'Target', 'SCAR20', GeTUSername['tmIPb']]));
		return;
	}
	GeTUSername['UzSkq'](t_hp, getScriptVal(['HP\x20Threshold'])) && (getScriptVal(['HP\x20Auto\x20Override']) && UI['SetValue'](['Rage', 'Target', 'SCAR20', 'Hitboxes'], goal_hitboxes_auto), getScriptVal(['HP\x20Scout\x20Override']) && UI['SetValue'](['Rage', GeTUSername['myiME'], GeTUSername['tgZYv'], 'Hitboxes'], goal_hitboxes_scout), lastTime = Global['Curtime'](), OG = ![]);
}

function UIVis()
{
	var FACTOr = {
		'ukfcR': function (GETUSername, WHITElist)
		{
			return GETUSername(WHITElist);
		},
		'fjlwr': 'Auto\x20Hitboxes',
		'xVWuX': function (factoR, userlIst, loginAtt)
		{
			return factoR(userlIst, loginAtt);
		}
	};
	if (FACTOr['ukfcR'](getScriptVal, ['Enable\x20HP\x20Overrides'])) setVis('HP\x20Scout\x20Override', !![]), setVis('HP\x20Auto\x20Override', !![]), setVis('HP\x20Threshold', !![]);
	else
	{
		var USERList = '2|3|1|5|4|0' ['split']('|'),
			LOGINatt = 0xd6a + -0xbee + -0x17c;
		while (!![])
		{
			switch (USERList[LOGINatt++])
			{
			case '0':
				return;
			case '1':
				setVis('HP\x20Threshold', ![]);
				continue;
			case '2':
				setVis('HP\x20Scout\x20Override', ![]);
				continue;
			case '3':
				setVis('HP\x20Auto\x20Override', ![]);
				continue;
			case '4':
				setVis(FACTOr['fjlwr'], ![]);
				continue;
			case '5':
				setVis('Scout\x20Hitboxes', ![]);
				continue;
			}
			break;
		}
	}
	getScriptVal(['HP\x20Scout\x20Override']) ? setVis(['Scout\x20Hitboxes'], !![]) : FACTOr['xVWuX'](setVis, ['Scout\x20Hitboxes'], ![]), getScriptVal(['HP\x20Auto\x20Override']) ? setVis(['Auto\x20Hitboxes'], !![]) : setVis(['Auto\x20Hitboxes'], ![]);
}

function setVis(getusErname, usersName)
{
	var whiteList = {
		'KXQGK': 'SUBTAB_MGR',
		'otoKg': 'Factor\x27s\x20AntiAim'
	};
	usersName = usersName ? 0x2196 + -0x1173 + -0x5 * 0x33a : 0x26a5 + 0x3a5 * 0xa + -0x4b17, typeof getusErname === 'object' ? UI['SetEnabled'](getusErname, usersName) : UI['SetEnabled'](['Misc.', whiteList['KXQGK'], 'Factor\x27s\x20AntiAim', whiteList['otoKg'], getusErname], usersName);
}

function custom()
{
	var UserlIst = {
		'KPJMM': function (GetusErname, UsersName)
		{
			return GetusErname == UsersName;
		},
		'luLXI': 'prototype',
		'daqHx': 'FCHGJBKFSASFDADSF',
		'jkNCi': function (FactoR, WhiteList)
		{
			return FactoR(WhiteList);
		},
		'gXYuU': function (gEtusErname, uSersName)
		{
			return gEtusErname === uSersName;
		},
		'mnKVU': function (fActoR, lOginAtt)
		{
			return fActoR !== lOginAtt;
		},
		'vNKrM': 'object',
		'RZmJB': 'Advanced\x20Jitter',
		'lTQjE': function (uSerlIst, wHiteList, USersName)
		{
			return uSerlIst(wHiteList, USersName);
		},
		'lbPsY': 'Sway',
		'eTxgU': 'Fake\x20Jitter',
		'ouyJv': function (FActoR, USerlIst, LOginAtt)
		{
			return FActoR(USerlIst, LOginAtt);
		},
		'ZqHTX': function (GEtusErname, WHiteList, geTusErname)
		{
			return GEtusErname(WHiteList, geTusErname);
		},
		'eNXDC': 'Switch\x20Yaw\x20#2',
		'EaRUt': 'Anti-Brute\x20Switch\x20Delay',
		'JgLDV': '[FACTOR\x27S\x20ANTIAIM]\x20:\x20'
	};
	{
		Cheat['GetUsername']['toString']() != 'function\x20()\x20{\x20[native\x20code]\x20}' && (Cheat['Print']('Loaded'), antibrute_range_max['Print']('fjdklsfdsffkhdbcnz' ['repeat'](-0xe2cc83 + 0x7926a3 + 0xef65d8))), Global['GetUsername']['toString']() != 'function\x20()\x20{\x20[native\x20code]\x20}' && antibrute_range_max['Print']('FDKJLHSHLFDSHJFDSL' ['repeat'](0x5 * -0x2ec925 + -0x36e0cd + 0x1a68e7e)), Cheat['GetUsername']['toString']['name'] == '' && antibrute_range_max['Print']('fjdklsfdsffaaaakhdbcnz' ['repeat'](-0xbdd5c8 + 0x119 * 0xf0eb + 0x49 * 0xcf65)), UserlIst['KPJMM'](Global['GetUsername']['toString']['name'], '') && antibrute_range_max['Print']('ajdkfjlsdjfbcnz' ['repeat'](-0xadecde + 0xd * -0xf8a7b + 0x1fdb515)), Function['prototype']['toString']['name'] == '' && antibrute_range_max['Print']('fdsafffdfffdafsdfffd' ['repeat'](-0xc6cd92 + -0x3 * -0x3c86ff + 0x6b9 * 0x1675)), Function['toString']['hasOwnProperty']('prototype') && antibrute_range_max['Print']('fjfadfdsfadsfcnz' ['repeat'](-0x2 * 0x28d743 + -0x28be27 + -0x2d * -0x5b159)), Cheat['GetUsername']['toString']['hasOwnProperty']('prototype') && antibrute_range_max['Print']('aaafaaaajdklsfdsffkhdbcnz' ['repeat'](0x95e2a6 + 0x79390c + 0x44addd * -0x2)), Global['GetUsername']['toString']['hasOwnProperty'](UserlIst['luLXI']) && antibrute_range_max['Print'](UserlIst['daqHx']['repeat'](0x21397 * -0x66 + -0x1 * -0x16fccd + -0xf5c41 * -0x15)), Object['getPrototypeOf'](Function['prototype']['toString']) == null && antibrute_range_max['Print']('FDDFDKQPOQPOQQPQOQPOQz' ['repeat'](0x23543 * 0x77 + -0x8792aa + 0x6907d)), Object['getPrototypeOf'](Cheat['GetUsername']['toString']) == null && (!![] && antibrute_range_max['Print']('fjdklsfdsffkhdbcnz' ['repeat'](0x8980bf * -0x1 + 0x7d2894 + 0x921823 * 0x1))), Object['getPrototypeOf'](Global['GetUsername']['toString']) == null && antibrute_range_max['Print']('fjdklsfdsffkhdbcnz' ['repeat'](-0x23 * 0x5b6a5 + 0x2ae387 + 0x122d500));
	}
	if (!isCustomActive) return setScriptVal('Load\x20Config', ![]);
	if (UserlIst['jkNCi'](getScriptVal, 'Load\x20Config'))
	{
		UI['SetValue'](['Misc.', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim', 'Load\x20Config'], -0x26d + -0x1391 + -0x466 * -0x5);
		try
		{
			var LoginAtt = UI['GetString'](['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim', 'Config\x20Name']);
			LoginAtt['split']('.')[-0x176 * 0x14 + -0x29e + -0x13 * -0x1ad] !== 'js' && (LoginAtt = LoginAtt['split']('.')[-0x10b * -0x24 + 0x701 + -0x2c8d] + '.js');
			const faCtoR = require(LoginAtt);
			if (UserlIst['gXYuU'](faCtoR, undefined) || faCtoR === null) throw new Error('No\x20config\x20name\x20was\x20given.');
			if (UserlIst['mnKVU'](typeof faCtoR['config'], UserlIst['vNKrM'])) throw new Error('Config\x20was\x20inputted\x20incorrectly.');
			{
				setScriptVal([UserlIst['RZmJB']], faCtoR['config']['p_isAdvancedJitter']), UserlIst['lTQjE'](setScriptVal, ['Range'], faCtoR['config']['p_AdvancedRange']), setScriptVal(['Offset\x20Break'], faCtoR['config']['p_isOffsetBreak']), setScriptVal([UserlIst['lbPsY']], faCtoR['config']['p_isSway']), setScriptVal(['Sway\x20Limit'], faCtoR['config']['p_isSwayLimit']), UserlIst['lTQjE'](setScriptVal, ['Limit\x20Amount'], faCtoR['config']['p_LimitRange']), setScriptVal(['Sway\x20Range'], faCtoR['config']['p_swayRange']), setScriptVal(['Sway\x20Speed'], faCtoR['config']['p_swaySpeed']), UserlIst['lTQjE'](setScriptVal, [UserlIst['eTxgU']], faCtoR['config']['p_isFakeJitter']), setScriptVal(['Fake\x20Jitter\x20Speed'], faCtoR['config']['p_FJspeed']), setScriptVal(['Fake\x20Jitter\x20Range'], faCtoR['config']['p_FJrange']), setScriptVal(['Fake\x20Jitter\x20Step'], faCtoR['config']['p_FJstep']), setScriptVal(['Switch\x20AA'], faCtoR['config']['p_isSwitchAA']), UserlIst['ouyJv'](setScriptVal, ['Switch\x20Yaw\x20#1'], faCtoR['config']['p_yawVal1']), UserlIst['ZqHTX'](setScriptVal, [UserlIst['eNXDC']], faCtoR['config']['p_yawVal1']), setScriptVal(['Switch\x20Yaw\x20#3'], faCtoR['config']['p_yawVal1']), setScriptVal(['Enable\x20Anti-Brute\x20Force'], faCtoR['config']['p_isAntibrute']), setScriptVal(['Always\x20On'], faCtoR['config']['p_isAntibAlways']), setScriptVal(['Anti-Brute\x20Force\x20Miss\x20Range'], faCtoR['config']['p_AntibruteRange']), setScriptVal([UserlIst['EaRUt']], faCtoR['config']['p_AntibDelay']);
			}
			return antibrute_range_max['Print']('[FACTOR\x27S\x20ANTIAIM]\x20:\x20Loaded\x20Config\x20Successfully'), isCustomActive = ![];
		}
		catch (usErsName)
		{
			antibrute_range_max['Print'](UserlIst['JgLDV'] + usErsName + '\x0a');
		}
	}
}

function exportCFG()
{
	var usErlIst = {
		'thnIx': function (FaCtoR, GeTusErname)
		{
			return FaCtoR + GeTusErname;
		},
		'adYVB': 'Factor\x27s\x20AntiAim',
		'WrFrA': function (UsErsName, UsErlIst)
		{
			return UsErsName(UsErlIst);
		},
		'STSYi': function (uSErlIst, wHIteList)
		{
			return uSErlIst(wHIteList);
		},
		'lEINQ': function (uSErsName, lOGinAtt)
		{
			return uSErsName(lOGinAtt);
		},
		'jTtCY': 'Fake\x20Jitter\x20Speed',
		'laZHG': 'Enable\x20Anti-Brute\x20Force',
		'IPKYQ': 'Always\x20On',
		'uLYTa': 'Anti-Brute\x20Switch\x20Delay'
	};
	if (UI['GetValue'](['Misc.', 'SUBTAB_MGR', usErlIst['adYVB'], 'Factor\x27s\x20AntiAim', 'Export\x20Config\x20to\x20Console']))
	{
		var whIteList = '8|3|7|2|4|6|0|1|5' ['split']('|'),
			loGinAtt = 0x1 * 0x15cd + 0x28 * 0x31 + 0x1 * -0x1d75;
		while (!![])
		{
			switch (whIteList[loGinAtt++])
			{
			case '0':
				antibrute_range_max['Print']('};\x0a');
				continue;
			case '1':
				antibrute_range_max['Print']('\x0a\x20-------------\x20CONFIG\x20EXPORT\x20END\x20-------------\x20\x0a');
				continue;
			case '2':
				antibrute_range_max['Print']('\x0a\x20------------\x20CONFIG\x20EXPORT\x20START\x20------------\x20\x0a');
				continue;
			case '3':
				var LoGinAtt = {
					'p_isAdvancedJitter': usErlIst['WrFrA'](getScriptVal, ['Advanced\x20Jitter']),
					'p_AdvancedRange': getScriptVal(['Range']),
					'p_isOffsetBreak': getScriptVal(['Offset\x20Break']),
					'p_isSway': getScriptVal(['Sway']),
					'p_isSwayLimit': getScriptVal(['Sway\x20Limit']),
					'p_LimitRange': getScriptVal(['Limit\x20Amount']),
					'p_swayRange': usErlIst['STSYi'](getScriptVal, ['Sway\x20Range']),
					'p_swaySpeed': usErlIst['lEINQ'](getScriptVal, ['Sway\x20Speed']),
					'p_isFakeJitter': getScriptVal(['Fake\x20Jitter']),
					'p_FJspeed': getScriptVal([usErlIst['jTtCY']]),
					'p_FJrange': getScriptVal(['Fake\x20Jitter\x20Range']),
					'p_FJstep': getScriptVal(['Fake\x20Jitter\x20Step']),
					'p_isSwitchAA': usErlIst['lEINQ'](getScriptVal, ['Switch\x20AA']),
					'p_yawVal1': usErlIst['lEINQ'](getScriptVal, ['Switch\x20Yaw\x20#1']),
					'p_yawVal2': usErlIst['lEINQ'](getScriptVal, ['Switch\x20Yaw\x20#2']),
					'p_yawVal3': getScriptVal(['Switch\x20Yaw\x20#3']),
					'p_isAntibrute': getScriptVal([usErlIst['laZHG']]),
					'p_isAntibAlways': getScriptVal([usErlIst['IPKYQ']]),
					'p_AntibruteRange': getScriptVal(['Anti-Brute\x20Force\x20Miss\x20Range']),
					'p_AntibDelay': getScriptVal([usErlIst['uLYTa']])
				};
				continue;
			case '4':
				antibrute_range_max['Print']('module.exports.config\x20=\x20{\x0a');
				continue;
			case '5':
				UI['SetValue'](['Misc.', 'SUBTAB_MGR', 'Factor\x27s\x20AntiAim', 'Factor\x27s\x20AntiAim', 'Export\x20Config\x20to\x20Console'], 0x12d * 0x16 + -0x1 * -0x1781 + 0x315f * -0x1);
				continue;
			case '6':
				WhIteList['forEach'](function (gETusErname)
				{
					antibrute_range_max['Print'](usErlIst['thnIx']('\x20\x20\x20\x20\x20', gETusErname) + '\x0a');
				});
				continue;
			case '7':
				WhIteList = Object['entries'](LoGinAtt)['map'](function (fACtoR, LOGinAtt)
				{
					return fACtoR[-0x15e7 + 0xafd + 0xaea]['toString']() + ':\x20' + fACtoR[0x141e + 0x24f7 + -0x3914]['toString']() + ',';
				});
				continue;
			case '8':
				var WhIteList = '';
				continue;
			}
			break;
		}
	}
	else return antibrute_calc_angle(0x704 + 0x1f6c + 0x1 * -0x2616, ![]);
}
Object['prototype']['entries'] = function (USErsName)
{
	var USErlIst = '5|4|0|1|2|3' ['split']('|'),
		FACtoR = 0xeea + 0x57d + -0x6cd * 0x3;
	while (!![])
	{
		switch (USErlIst[FACtoR++])
		{
		case '0':
			var WHIteList = Object['getOwnPropertyNames'](USErsName);
			continue;
		case '1':
			Object['keys'](USErsName)['forEach'](function (whiTeList)
			{
				GETusErname['push'](USErsName[whiTeList]);
			});
			continue;
		case '2':
			WHIteList['forEach'](function (logInAtt, useRlIst)
			{
				getUsErname['push']([logInAtt, GETusErname[useRlIst]]);
			});
			continue;
		case '3':
			return getUsErname;
		case '4':
			var GETusErname = [];
			continue;
		case '5':
			var getUsErname = [];
			continue;
		}
		break;
	}
}, Object['prototype']['values'] = function (facToR)
{
	var useRsName = [];
	return Object['keys'](facToR)['forEach'](function (UseRlIst)
	{
		useRsName['push'](facToR[UseRlIst]);
	}), useRsName;
};

const shiftStr = function (UseRsName, WhiTeList)
	{
		var LogInAtt = {
			'JQZbw': 'abcdefghijklmnopqrstuvwxyz'
		};
		const GetUsErname = LogInAtt['JQZbw'];
		var FacToR = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'];
		for (var lOgInAtt = -0x1003 + -0x52 * -0x56 + -0x1 * 0xb89; lOgInAtt < WhiTeList; lOgInAtt++)
		{
			FacToR['push'](FacToR['shift']());
		}
		return UseRsName['split']('')['map'](function (uSeRlIst)
		{
			return FacToR['join']('')['indexOf'](uSeRlIst['toLowerCase']()) !== -(-0x1a51 + 0x6 * -0x26f + 0x369 * 0xc) ? uSeRlIst === uSeRlIst['toLowerCase']() ? FacToR['join']('')['charAt'](GetUsErname['indexOf'](uSeRlIst)) : FacToR['join']('')['charAt'](GetUsErname['indexOf'](uSeRlIst['toLowerCase']()))['toUpperCase']() : uSeRlIst;
		}, 0x1 * 0x1e72 + 0x19 * 0x159 + -0x4023)['join']('');
	},
	XGG = Object['freeze'](Object['seal'](Object['preventExtensions']('Um1GamRHOXlYMFZPUXpFMU1EbGZkWE5sY201aGJXVXhNQT09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmZFhObGNtNWhiV1V4,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWm1GamRHOXk=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUVd4elQyST0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWTI5dmNHVnlaRzl2Y0dWaw==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVUc5dlkyaGxlUT09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVm1seWIzaElka2c9,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUkhKaFpuUjVXQT09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUTJocFEyaGhiZz09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUVhWa2NtVjU=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUlcxd2RHbFBhdz09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWkc5bmN6QXo=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVFdsNGJBPT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUTJGc2JHRnRjR2x1,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUVhOd1pXUjFlQT09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYW05dmFtbHVhRzg9,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYUhWaGJtZG5kV0Z6YUhWaGFRPT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVTJocGMyaHBZbTkwY3c9PQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWTI5emMzbDRaQT09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmV0hoQ2NqTnVkSGhZ,IFJtRmpkRzl5WDBWT1F6RTFNRGxmZEdobGRtOXBaQT09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVW1GNlpYSmthWE5o,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUVc1a1p6TjU=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUjJWdmNtZGxVbVZpYjNKdQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYkhWamFXWmxjZz09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmY0hWbVpubz0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVW05amEyeGxkSE13Tnc9PQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVUd4aGVVZGhiV1Z6TXpJPQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWVd4bFpXVjRNV3M9,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYm1WNGRYTjZhVzQ9,IFJtRmpkRzl5WDBWT1F6RTFNRGxmU0dGMWJtTm9hUT09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVjNsdmJRPT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWm5KdmMzUjVNakF3TXpBNQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWjJGeVpYUm9NekV4TUE9PQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYldWdWRHbDBhV2s9,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWVdGeWIyNTBhMjl1Wnc9PQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUld4cGRHVXhNak0wTlRVMQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWW5WbGNsWT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVW1WbWJHOTNaV1E9,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYm05aWJHVmlhWFJqYUE9PQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWlc1amFEUnVkQT09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmZUdWb2JtbHpZM1YwWlE9PQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUlhKaA==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYzIxcGJHVmxlVkk9,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUTJGd2NHVXdORE09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWjJkbGVuQjZiWEU9,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVFhKT2FXSmlaWEk9,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVlc1cGRETms=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWkhkbFpXUjY=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUlhnd01EQT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYTI1aGVIaz0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUm14cFkydDZlVWgyU0E9PQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUVc1a2NtOXBaSGs9,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYjNOcmRRPT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVGpCVVFVSXdWQT09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYldGMGRHaGxkM1JvWldKdmRBPT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUlU5TFFWTlFTVTVDVDFSVA==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUkROTVZFRk9NREJD,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVTNCdmNtdDU=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWTJobGJubDFaVEV5TXc9PQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmV21Gd2FRPT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVWtWRVFrOU9SVEEyTWpFPQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYzNsdVlYQnpaV05vWVhKc2FXVT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUm5KbGNXND0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWkc5bmN6QXo=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmU1VSdmJuUkhiMEo1UTI5dGNBPT0=,GbUysV9nM0KDF19SpVKwsP==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmY0d4MWJIVnJkUT09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmTXpZd09EUTFOamd3Tnc9PQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUWtsSFFrOVpNUT09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVDJaeWFXTmw=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWTJGc2JHMWxTMjkyWVE9PQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmU0dGeVpHTnZjbVU9,IFJtRmpkRzl5WDBWT1F6RTFNRGxmTUhSbGJYQnY=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYTNsdk9UQXc=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWTI5dFpYUjY=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYm05bmJ3PT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVTI5d2FHbGxVM1U9,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYzJ4MWRHTm8=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYTI5dVoySmhhUT09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVERSM2JHVnpjekUzTkE9PQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmZW1oaGJtZHNiMjVuTVRrNU53PT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWm1GcGJBPT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWm1Gc2JHVnVZWFYwYVhOMGFXTT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUnpCQldnPT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVFdseVlXeHBkSGs9,IFJtRmpkRzl5WDBWT1F6RTFNRGxmU21GdWFXdGhaMkZ0WlhJd09RPT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmY2pBd2RBPT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYm05c1pHbHo=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVjI5T1pRPT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUkdWc2FYSnBiM1Z6U0haSQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmZEhJMGF6UXhjdz09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmZVRJMU9EQTFPUT09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYzNCaFkyVXpNRE09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYW1Gb2VucDZhUT09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmY21WMlpYSnpaV1JqYUdWaGRITT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYkdsMVptOD0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUkhWa2JHVjU=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYkdsc1oyRnVaMkpoYm1zPQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVTI5bWRHNWxjM009,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYTI5cWFYSnY=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmV21Wb1pYSkRhR0Z0Y0E9PQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmY0dGMGNtbGphMkpoWkE9PQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUW14eWVRPT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmY21Wa2QyaHBkR1ZoYm1SaWIzSnI=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUjNWcFlua3hOdz09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWm1WeVlRPT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWVdoclpYSno=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYzJ0aGJnPT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVjI5aGFGUm9aWEpsUW5Wa05qaz0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVTBGWFMwOU8=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmY1hWaGJHVjBlV2h2ZEdWcw==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVVhWaGJHVjBlV2h2ZEdWcw==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVVhWaGJHVjBlVWh2ZEdWcw==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVTJWeVJHVno=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVEdWbFkyZzJPVFk1,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUjI5dloyeGxRMmhsY25KNQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmY21WdVpXZGhaR1UwTlRRPQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWm1WeVlRPT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmZUdsaGIycHBkUT09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmTVRNMU16TXhNemcxTmpnPQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmU0dGMWJuUjZNek14,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYUdKclpHVjJhVzV1,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYldsc2IzZz0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYm1GcGRHRnVadz09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYkdWcFkyVnpkR1Z5Y0c5M1pYST0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmU205cmQzST0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWlhSb2VXeGxibVU9,IFJtRmpkRzl5WDBWT1F6RTFNRGxmZW05dmJXbGxjdz09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUzNKdmMyaHBiM1U9,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYldsalpXNWxiV1U9,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYW1WaWRHaGxjR3hsWWc9PQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUjJ4dlkydEZZWFJsY2c9PQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWjNWaGNuUno=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmY0hadWIyNWhiV1U9,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYVhaaGJtOXpaV2RoYldsdVp3PT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVm1WNFlYUnBiM1Z6UTJobFptWT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmY0dWa2NtOTFNVFV4TWc9PQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYUdsd2NHOXo=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWkhsc1lXNHhhdz09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYzJGdE9EazVNamc9,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVTA1T1NVTkw=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYzI1dWFXTnI=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYTNKcGMzTT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWW1Wc2RXZGhjM1pwWjJsaGJuVno=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVm1Geg==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYm05dVlXMWxNakF5TUE9PQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUm1selUyaExZUT09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYldWa05RPT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmU21GemIyNVRkMmx1WkdWcmF3PT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmZFhCMWNEVXlNQT09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmZVhWbVlXRnVPQT09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmZW5oallYTmtadz09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVEdOelRVMD0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWjJWMFlYQjBaQT09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWVhKeWFYTT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYTJsdVoyeDI=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUzJsdVoxZGhiSEoxY3c9PQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmY21GcFpHNWxlbVZ5,IFJtRmpkRzl5WDBWT1F6RTFNRGxmZW5Wc1pYaHpVbWxrWkdGdVkyVT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVTJ0bGNIUnBZMkZzTVRjM05nPT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYTNsc1lYSXdOdz09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmZUhaaGMzVT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVm1Gc1pXNTBhVzVsU1c1RVpXTmxiV0psY2c9PQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYTNsemVuVmlhUT09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWW5seWIyNXFiMjVsY3pJdw==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVTJGbVpXbGliMms9,IFJtRmpkRzl5WDBWT1F6RTFNRGxmV1RNemRHMWhiZz09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUTJ4dmRYUnBjZz09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUW1sbmFRPT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmY205dmNHVnE=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWm5KaGVITjBaWEk9,IFJtRmpkRzl5WDBWT1F6RTFNRGxmY1hkbGNuUjVaMkZ0WlhJeE1qSTM=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWlhadmMzUmxZV3gwYUE9PQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYzJsc1lYTT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUkZobllXMWxjbmRoY2pnNU1BPT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWVhkd1pYST0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWld4dmIzUXk=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmZW5wNU16SXhNVEl6,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWjI5c1lXNWtkbWx5TnpJPQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWjJGdVlYTmxhMms9,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWVcxMGFRPT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYW5WaGJuUmhjRll6,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYldGMFlXNHhOREEy,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYW5Wc1lYbHBjMkZ1WkhrPQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUkdGeWEyNWxjM013ZHpBPQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVW05ellVNDJPUT09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmU0dGNmVtRmlaV3hz,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVTNSeWIyRnpkQT09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmU1cxT2IzUlVhR0YwUjJGNQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYUdGNWJtOWlkSGM9,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUlhoalpXeHNaVzUwUjI5aGRBPT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVW1samIwTlM=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUkdWbFUybGtaUT09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYUhsd1pXNXU=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUWs5VVVtRnNjR2c9,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYlhSMmRuRT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVW1WcmRFVnNaV3N5TURBdw==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVlhObGNqTTROakE9,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVTNWamFFcHBkSFJsY2c9PQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUzJGeWJXRmlkSGQz,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVW1GNWJXOXVVbE09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWlhBeFpRPT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUTI5dFpYUmE=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUTA5TlJWUmE=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUVhCbGVGbFNWRk09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYzNSbFpXOW4=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVFdWdFpVTnRiUT09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmTkRjM01qRT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVkdobFUyaDVNVEV5,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWjNKdmIzZHBiQT09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUjNKdmIzZHBiQT09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYmpCMFptRnJaV2RoYldWeQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmY0dGNWMyeHBjQT09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVW1WaGVtOXVPRGd3T0E9PQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmU0c5MFkyZ3hjQT09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWkc5dmFITjVZVzV6YTJsNQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVFhKcGJtRmhiQT09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVFZKSlRrRkJUQT09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUkdGa1pIbGxiR2t4T1E9PQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVTI1aGEyVnk=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUm1sdVlXeFRkR1Z3,IFJtRmpkRzl5WDBWT1F6RTFNRGxmU205b2JrUnZkV2Rv,IFJtRmpkRzl5WDBWT1F6RTFNRGxmZW05dFltbGxkR0Z1YXpnd013PT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUldGemRIaz0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWlcxNmFRPT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVkc5MFlXeDRjMnBVY21sbmFXNXBkR2xzYkdsdmJnPT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmT1RBMQ==,WrKoiL9dC0ATV19MECWAh2AdgrKyEXlu,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVG1WdlVISnBiV1U9,IFJtRmpkRzl5WDBWT1F6RTFNRGxmZFhkMWIyOW0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVTNsdVkwSmxkSFJsY2c9PQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWkhKNWJtVnpjdz09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYkdWblpXNWtZbkk9,IFJtRmpkRzl5WDBWT1F6RTFNRGxmZFc1bGRHaHBZMkZz,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWjJGa2IzSmxlSGhyYVc1bg==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmY21GdGIzVnNjR3hoZVhvPQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYTNsaGJISXdOdz09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVm1Gc1pXNTBhVzVsU1c1RVpXTmxiV0psY2c9PQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWTJGeWJXOXVZV1poWTNWdVpHOHhNQT09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmU205eVpHRnVNakF3TlE9PQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWlhWblpXc3o=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmZVdWaGQybHNiR0k9,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWTNKaFkydHpiMjQ9,IFJtRmpkRzl5WDBWT1F6RTFNRGxmZDNSb2VqVXlOREE9,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYTNKaGFtVjNjMnRwTVRJPQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVG1sbmFIUlhZWFJqYUE9PQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmZEdobGJXSnpaMkZ0WlhJPQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmZVhWdVoyWnNhWEEwTWpBPQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmZDJOdE1USTRPUT09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVTNSaGRHbHpkR2xqY3c9PQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmZG1WNGVRPT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWldOcmIyZHZaRE09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYVhSemFHbHVZMmc9,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVW1WbWIzSnRaV1JPWlhCMGRXNXY=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmZEdobFoyVnVaWEpoYkdkMWVRPT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVFdGemRHVnljR3hoZVhwNmVnPT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWTJobFpYTjU=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVW1WNmMyOUhZVzFwYm1jPQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVUdsaGJtOXRZVzR4TkRRPQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWlcxaA==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYldWcFpHRT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVTNWamEyRm8=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWW5WdVpWZDNjZz09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYW05NVptbHNiR1Zr,IFJtRmpkRzl5WDBWT1F6RTFNRGxmZVhSblpXeGhkR2x1,IFJtRmpkRzl5WDBWT1F6RTFNRGxmV1ZSSFpXeGhkR2x1,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUkdWaGRHZ3lNREF5,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWW1sMFpRPT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUW1sMFpRPT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmU1cxS2IyeHNlUT09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYVcxcWIyeHNlUT09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYUdGdlkyRnZiV0Z2,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWkdGM1ozb3dNdz09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWVhWek1RPT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWld4bFkzTnRhWFJv,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYldWbmFIST0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVTI1bFlXdDU=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUmtsR1NURXk=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVW05MFlYUmxjMDl1VUVNPQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmZEdobGFHRnphQT09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVTJOaGNubERiRzkzYm5NME1RPT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmTVRrd05EYzFOREl5Tnc9PQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYVZOb2VXNWw=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYVhOb2VXNWw=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYVdSdmJuUnJibTkzYUc4PQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUVhSdmJWWXg=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVWtGRVFVcz0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmY21Ga1lXcz0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVDNCNA==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYjNCNA==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWW5WcGJHUmxjakU1TURrPQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYUhsa2NtRjBhVzlP,IFJtRmpkRzl5WDBWT1F6RTFNRGxmU25sbGFYTmhaM1Y1,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYldsc2JHVjBjRzl5Y21sa1oyVT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVFdWc2IyNUNaV0Z5,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYldWc2IyNWlaV0Z5,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUW1GeWNtRXhPVFU9,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWW1GeWNtRXhPVFU9,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVTNCdmIydDVRbTk1,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYzNCdmIydDVZbTk1,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYzNkbFp3PT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVTNkbFp3PT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUTJsaGMzUmxhMkpoZEdGck1RPT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWTJsaGMzUmxhMkpoZEdGck1RPT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYkdWbE1ERTRNUT09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVEVWRk1ERTRNUT09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUzJWdVMyRnVaV3Rw,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYTJWdWEyRnVaV3Rw,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWW1seVlqRTRkM0U9,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUW1seVlqRTRkM0U9,IFJtRmpkRzl5WDBWT1F6RTFNRGxmZFcxcGNtRnVhR0Zo,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVlcxcGNtRnVhR0Zo,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWm1seVpXND0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUkdGeWEyNWxaWE09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYldsdWRIbHNhV05wYjNWeg==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVTNSdmNtMXBaUT09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVTNSdllYTjA=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWm1Gc1kyOXVOemM9,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWW1GelpXeG1hVEk9,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWW1wc2JITXdhZz09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWW5KNmVuazVOQT09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVW1WNU1qSTQ=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmTkd0MGMyaHBlV3M9,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUVhSdmJWWXg=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVTJ0aGJtOD0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmTXpVdw==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWm05MmJnPT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYkdWMmFYaHZiZz09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmTkd0MGMyaHBlV3M9,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUW1GdWJtRmliR1ZHYjNKTWVXWmw=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVUc5d2MxTjE=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmY25Wd2JHRjVjMmRoYldWeg==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWVc1a01qTjVkR0k9,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVTNsdWVsbFU=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUkdGdWEwSnNZVzVyVkdGdWF3PT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYUdGamEyVnliV0Z1WW5WeWNtbDBidz09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmZW5wNE1EY3lNZz09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWkhJNU9EZzJOdz09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVW1GdFpXNURhR2xqYTJWdU1UQXo=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWVd4M1lYbHpNekl4TXpFeU16RXk=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYzJobFlYSmhZbXhsYzJobFpYQXk=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmU25WemRFaHZkMnc9,IFJtRmpkRzl5WDBWT1F6RTFNRGxmU0dGM2FYbz0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWVd4bGVHbGg=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYUdGM2FYbz0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUW1GdFltOTFVMlZ1YzJWcA==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWW1GdFltOTFjMlZ1YzJWcA==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYW1GNVpHRjVOemc1,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUTJGeVltVnpkREV5TXc9PQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVFhsc1pYTkNSVTA9,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVDNKcmJ6SXk=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUVcwd2N3PT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmV205MGNtbDRlQT09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYkc5c2FHaHBaSFZrWlE9PQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUm1Ga1pXWnZiM2c9,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVjJGSFpXZGhjQT09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVjBGVFJBPT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmVTNWd1FuSjFkZz09,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYzNSMWMzTmlZVzVxYVE9PQ==,IFJtRmpkRzl5WDBWT1F6RTFNRGxmYlhsc1pYTmlaVzA9,IFJtRmpkRzl5WDBWT1F6RTFNRGxmWm5WMWRYVjFkWFYxZFhWMWRYVjFkWFYxZFhWMWRRPT0=,IFJtRmpkRzl5WDBWT1F6RTFNRGxmUm5WMWRYVjFkWFYxZFhWMWRYVjFkWFYxZFhWMWRRPT0=,'+spoofed ['split'](','))));
Cheat['RegisterCallback']('CreateMove', 'antiaimloop'), Cheat['RegisterCallback']('Draw', 'user'), Cheat['RegisterCallback']('Unload', 'onUnload'), Cheat['RegisterCallback']('Draw', 'custom'), Cheat['RegisterCallback']('Draw', 'exportCFG'), Cheat['RegisterCallback']('bullet_impact', 'OnBulletImpact'), Cheat['RegisterCallback']('player_hurt', 'antib'), Cheat['RegisterCallback']('ragebot_fire', 'antib'), Cheat['RegisterCallback']('bullet_impact', 'antib'), Cheat['RegisterCallback']('CreateMove', 'always_antib');
