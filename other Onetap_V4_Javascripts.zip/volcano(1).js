function clamp(num, min, max) {return num <= min ? min : num >= max ? max : num;}
function draw_bold_text(x,y,centered,text,color,font){
	Render.String(x + 1, y + 1, centered, text, [0, 0, 0, color[3]], font);
	Render.String(x + 1, y, centered, text, [0, 0, 0, color[3]], font);
	Render.String(x, y + 1, centered, text, [0, 0, 0, color[3]], font);
	Render.String(x - 1, y, centered, text, [0, 0, 0, color[3]], font);
	Render.String(x, y - 1, centered, text, [0, 0, 0, color[3]], font);
	Render.String(x - 1, y - 1, centered, text, [0, 0, 0, color[3]], font);
	Render.String(x,y, 1, text, color, font);
}
function calc_angle(a, n, t, c) {
	return 180 * Math.atan((n - c) / (a - t)) / Math.PI
}

function rand(min, max) {
	return min + Math.floor((max - min) * Math.random());
}

function deg2rad(degress) {
	return degress * Math.PI / 180.0;
}

function angle_to_vec(pitch, yaw) {
	var p = deg2rad(pitch);
	var y = deg2rad(yaw);
	var sin_p = Math.sin(p);
	var cos_p = Math.cos(p);
	var sin_y = Math.sin(y);
	var cos_y = Math.cos(y);
	return [cos_p * cos_y, cos_p * sin_y, -sin_p];
}

function trace_line(entity_id, entity_angles) {
	var entity_vec = angle_to_vec(entity_angles[0], entity_angles[1]);
	var entity_pos = Entity.GetRenderOrigin(entity_id);
	entity_pos[2] += 50;
	var stop = [entity_pos[0] + entity_vec[0] * 8192, entity_pos[1] + entity_vec[1] * 8192, (entity_pos[2]) + entity_vec[2] * 8192];
	var traceResult = Trace.Line(entity_id, entity_pos, stop);
	if (traceResult[1] == 1.0) return;
	stop = [entity_pos[0] + entity_vec[0] * traceResult[1] * 8192, entity_pos[1] + entity_vec[1] * traceResult[1] * 8192, entity_pos[2] + entity_vec[2] * traceResult[1] * 8192];
	var distance = Math.sqrt((entity_pos[0] - stop[0]) * (entity_pos[0] - stop[0]) + (entity_pos[1] - stop[1]) * (entity_pos[1] - stop[1]) + (entity_pos[2] - stop[2]) * (entity_pos[2] - stop[2]));
	entity_pos = Render.WorldToScreen(entity_pos);
	stop = Render.WorldToScreen(stop);
	if (stop[2] != 1 || entity_pos[2] != 1) return;
	return distance;
}
UI.AddSubTab(["Rage", "SUBTAB_MGR"], "volcano")
var path = ["Rage", "volcano", "volcano"]
var freestandkey = UI.AddHotkey(["Rage", "General", "General", "Key assignment"], "[volcano] Freestand key", "[volcano] Freestand key")
var opt = UI.AddDropdown(path, "[volcano] tab", ["rage", "anti-aim", "visuals"], 0)
var fckinnn = UI.AddDropdown(path, "[volcano] legit aa", ["none", "safe", "max"], 0);
var nowyoucanpretendyouhaveskeet = UI.AddCheckbox(path, "[volcano] fake indicators")
var dt_enb = UI.AddCheckbox(path, "[volcano] better doubletap")
var dt_opt = UI.AddDropdown(path, "[volcano] doubletap types", ["dynamic"], 0)
var l_break = UI.AddCheckbox(path, "[volcano] leg breaker")
var w_mark = UI.AddCheckbox(path, "[volcano] watermark")
var w_mark_c = UI.AddColorPicker(path, "[volcano] watermark color")
var bodyyawtp = UI.AddDropdown(path, "[volcano] body-yaw type", ["hide", "peek"], 0)
var real_opt = UI.AddDropdown(path, "[volcano] real type", ["default" ,"random"], 0)
var l_opt = UI.AddDropdown(path, "[volcano] delta type", ["low", "normal", "high", "automatic"], 0)
var i_tick = UI.AddCheckbox(path, "[volcano] ideal tick")
var n_hitchance = UI.AddCheckbox(path, "[volcano] noscope hitchance")
var n_hitchance_val = UI.AddSliderInt(path, "[volcano] hitchance", 0, 100)
var a_hitchance = UI.AddCheckbox(path, "[volcano] in air hitchance")
var a_hitchance_val = UI.AddSliderInt(path, "[volcano] air hitchance", 0, 100)
var txt_color = UI.AddColorPicker(path, "[volcano] text color")
var i_acc1 = UI.AddColorPicker(path, "[volcano] accent color")
var i_acc2 = UI.AddColorPicker(path, "[volcano] second accent color")
var a_acc1 = UI.AddColorPicker(path, "[volcano] arrow true color")
var a_acc2 = UI.AddColorPicker(path, "[volcano] arrow false color")
var in_enabled = UI.AddCheckbox(path, "[volcano] inverter arrows")
var hm_enabled = UI.AddCheckbox(path, "[volcano] hitmarker")
var hm_color = UI.AddColorPicker(path, "[volcano] hitmarker color")
var fkn_thirdperson = UI.AddSliderInt(path, "[volcano] thirdperson distance", 50, 300)
var i_hotkey = UI.AddHotkey(["Rage", "General", "General", "Key assignment"], "[volcano] Ideal tick", "[volcano] Ideal tick")
var m_color1 = UI.AddCheckbox(["Rage", "volcano", "volcano"], "[volcano] min damage indicator")
var m_color2 = UI.AddColorPicker(["Rage", "volcano", "volcano"], "[volcano] min damage indicator color")
var inverted = UI.GetValue(["Rage", "Anti Aim", "General", "Key assignment", "AA Direction inverter"])
var flcache1 = UI.GetValue(["Rage", "Fake Lag", "General", "Limit"])
var flcache2 = UI.GetValue(["Rage", "Fake Lag", "General", "Trigger limit"])
var jtcache1 = UI.GetValue(["Rage", "Fake Lag", "General", "Jitter"])
var hdf = UI.AddHotkey(["Rage", "General", "General", "Key assignment"], "[volcano] Damage override", "[volcano] Damage override")
var fakelagmodes = UI.AddDropdown(path,'[volcano] fakelag mode',['default', 'alternative', 'random'],0)
var YT4PvIrt = Cheat.GetUsername()
var lt_class = 0
var target = 0
var a_fl = 0
var font;
var distance_delta;
i = 0

function simpleshitretard() {
	if (UI.GetValue(freestandkey)) {
		UI.SetValue(["Rage", "Anti Aim", "Directions", "Auto direction"], 1);
	}
	else {
		UI.SetValue(["Rage", "Anti Aim", "Directions", "Auto direction"], 0);
	}
}

function menu() {
	UI.SetEnabled(nowyoucanpretendyouhaveskeet, 0)
	UI.SetEnabled(dt_opt, 0)
	UI.SetEnabled(l_break, 0)
	UI.SetEnabled(a_hitchance, 0)
	UI.SetEnabled(a_hitchance_val, 0)
	UI.SetEnabled(l_opt, 0)
	UI.SetEnabled(bodyyawtp, 0)
	UI.SetEnabled(i_tick, 0)
	UI.SetEnabled(real_opt, 0)
	UI.SetEnabled(n_hitchance, 0)
	UI.SetEnabled(n_hitchance_val, 0)
	UI.SetEnabled(i_acc1, 0)
	UI.SetEnabled(i_acc2, 0)
	UI.SetEnabled(a_acc1, 0)
	UI.SetEnabled(a_acc2, 0)
	UI.SetEnabled(txt_color, 0)
	UI.SetEnabled(m_color1, 0)
	UI.SetEnabled(m_color2, 0)
	UI.SetEnabled(w_mark, 0)
	UI.SetEnabled(w_mark_c, 0)
	UI.SetEnabled(dt_enb, 0)
	UI.SetEnabled(hm_enabled, 0)
	UI.SetEnabled(hm_color, 0)
	UI.SetEnabled(fkn_thirdperson, 0)
	UI.SetEnabled(in_enabled, 0)
	UI.SetEnabled(fckinnn, 0)
	UI.SetEnabled(fakelagmodes, 0)
	if (UI.GetValue(["Rage", "volcano", "volcano", "[volcano] tab"]) == 0) {
		UI.SetEnabled(dt_enb, 1)
		UI.SetEnabled(i_tick, 1)
		UI.SetEnabled(n_hitchance, 1)
		UI.SetEnabled(a_hitchance, 1)
		if (UI.GetValue(a_hitchance)) {
			UI.SetEnabled(a_hitchance_val, 1)
		}
		if (UI.GetValue(["Rage", "volcano", "volcano", "[volcano] noscope hitchance"]) == 1) {
			UI.SetEnabled(n_hitchance_val, 1)
		}
		if (UI.GetValue(["Rage", "volcano", "volcano", "[volcano] better doubletap"]) == 1) {
			UI.SetEnabled(dt_opt, 1)
		}
	}
	if (UI.GetValue(["Rage", "volcano", "volcano", "[volcano] tab"]) == 1) {
		UI.SetEnabled(l_opt, 1)
		UI.SetEnabled(bodyyawtp, 1)
		UI.SetEnabled(fakelagmodes, 1)
		UI.SetEnabled(fckinnn, 1)
		UI.SetEnabled(real_opt, 1)
	}
	if (UI.GetValue(["Rage", "volcano", "volcano", "[volcano] tab"]) == 2) {
		if (UI.GetValue(["Rage", "volcano", "volcano", "[volcano] watermark"]) == 1) {
			UI.SetEnabled(w_mark_c, 1)
		}
		UI.SetEnabled(i_acc1, 1)
		UI.SetEnabled(in_enabled, 1)
		UI.SetEnabled(i_acc2, 1)
		UI.SetEnabled(txt_color, 1)
		UI.SetEnabled(m_color1, 1)
		UI.SetEnabled(a_acc1, 1)
		UI.SetEnabled(a_acc2, 1)
		UI.SetEnabled(m_color2, 1)
		UI.SetEnabled(l_break, 1)
		UI.SetEnabled(w_mark, 1)
		UI.SetEnabled(hm_enabled, 1)
		UI.SetEnabled(hm_color, 1)
		UI.SetEnabled(fkn_thirdperson, 1)
		UI.SetEnabled(nowyoucanpretendyouhaveskeet, 1)
	}
}

function NOSCOPE_HITCHANCE_CLASS() {
	if (UI.GetValue(["Rage", "volcano", "volcano", "[volcano] noscope hitchance"]) == 1) {
		var local = Entity.GetLocalPlayer()
		var scoped = Entity.GetProp(local, "CCSPlayer", "m_bIsScoped")
		var hitchance = UI.GetValue(["Rage", "volcano", "volcano", "[volcano] hitchance"])
		var hcforce = parseInt(hitchance)
		target = Ragebot.GetTarget()
		if (scoped == 0) {
			Ragebot.ForceTargetHitchance(target, hcforce)
		}
	}
}

function airhc() {
	target = Ragebot.GetTarget()
	if (UI.GetValue(a_hitchance)) {
		if (Entity.GetProp(Entity.GetLocalPlayer(), "CBasePlayer", "m_hGroundEntity")) {
			Ragebot.ForceTargetHitchance(target, UI.GetValue(a_hitchance_val))
		}
	}
}

function IdealTick_CLASS() {
	if (UI.GetValue(["Rage", "volcano", "volcano", "[volcano] ideal tick"]) == 1) {
		if (UI.GetValue(i_hotkey) == true) {
			if (UI.GetValue(["Rage", "Exploits", "Keys", "Double tap"]) == 1) {
				UI.SetValue(["Rage", "Fake Lag", "General", "Limit"], 0)
				UI.SetValue(["Rage", "Fake Lag", "General", "Trigger limit"], 0)
				UI.SetValue(["Rage", "Fake Lag", "Enabled"], 0);
			}
			else if (UI.GetValue(["Rage", "Exploits", "Keys", "Double tap"]) == 0) {
				UI.SetValue(["Rage", "Fake Lag", "General", "Limit"], flcache1)
				UI.SetValue(["Rage", "Fake Lag", "General", "Trigger limit"], flcache2)
				UI.SetValue(["Rage", "Fake Lag", "Enabled"], 0);
			}
		}
		else {
			UI.SetValue(["Rage", "Fake Lag", "Enabled"], 1);
			UI.SetValue(["Rage", "Fake Lag", "General", "Limit"], flcache1)
			UI.SetValue(["Rage", "Fake Lag", "General", "Trigger limit"], flcache2)
		}
	}
}

function LegBreaker_CLASS() {
	if (UI.GetValue(["Rage", "volcano", "volcano", "[volcano] leg breaker"]) == 1) {
		breaker = 10 * Math.abs(Math.sin(64 * Globals.Realtime()))
		breaker > 5 && UI.SetValue(["Misc.", "Movement", "Leg movement"], 0)
		breaker < 5 && UI.SetValue(["Misc.", "Movement", "Leg movement"], 1)
	}
}

function get_velocity(player) {
    var velocity = Entity.GetProp(player, "CBasePlayer", "m_vecVelocity[0]"); return Math.sqrt(velocity[0] * velocity[0] + velocity[1] * velocity[1]);
}

function on_impact() {
    if (!Entity.IsEnemy(Entity.GetEntityFromUserID(Event.GetInt("userid")))) 
        return;
    bullet_impact_user = Entity.GetEntityFromUserID(Event.GetInt("userid"));
    location = [Event.GetFloat("x"), Event.GetFloat("y"), Event.GetFloat("z")];
}

var bullet_impact_user = -1;
var location = [];
var bullet_start_user = -1;
var startlocation = [];

function randomIntFrom(min,max) {
    return Math.floor(Math.random()*(max-min+1)+min);
}

function anti_aim() {

	var alt = 0;
	isSlowwalk = UI.GetValue(["Rage", "Anti Aim", "General", "Slow walk"]);
	var desyncamt = null;
	var local_player = Entity.GetLocalPlayer();
	if (UI.GetValue(["Rage", "volcano", "volcano", "[volcano] delta type"]) == 0) {
		desyncamt = 25
		alt = 25
	}
	else if (UI.GetValue(l_opt) == 1) {
		desyncamt = 30
		alt = 30
	}
	else if (UI.GetValue(l_opt) == 2) {
		desyncamt = 60
		alt = 60
	}
	else if (UI.GetValue(l_opt) == 3) {
				if (isSlowwalk) {
					desyncamt = 25
				}
				else {
					desyncamt = 60
				}

	}

	if (UI.GetValue(real_opt) == 1) {
		desyncamt = Math.random() * alt;
	}
	
	distance_delta = left_distance = trace_line(local_player, [0, Local.GetViewAngles()[1] - 23]) - (right_distance = trace_line(local_player, [0, Local.GetViewAngles()[1] + 23]));
	if (UI.GetValue(["Rage", "Anti Aim", "General", "Key assignment", "Slow walk"]) == true) {
		if (UI.GetValue(["Rage", "volcano", "volacano", "[volcano] body-yaw type"]) == 0) {
			if (distance_delta > 1) {
				AntiAim.SetOverride(1)
				AntiAim.SetFakeOffset(-5)
				AntiAim.SetRealOffset(-25)
			}
			else {
				AntiAim.SetOverride(1)
				AntiAim.SetFakeOffset(-5)	
				AntiAim.SetRealOffset(25)
			}
		}
		else {
			if (distance_delta > 1) {
				AntiAim.SetOverride(1)
				AntiAim.SetFakeOffset(-5)
				AntiAim.SetRealOffset(25)
			}
			else {
				AntiAim.SetOverride(1)
				AntiAim.SetFakeOffset(-5)
				AntiAim.SetRealOffset(-25)
			}
		}
	}
	else {
		if (UI.GetValue(["Rage", "volcano", "volcano", "[volcano] body-yaw type"]) == 0) {
			if (distance_delta > 1) {
				AntiAim.SetOverride(1)
				AntiAim.SetFakeOffset(0)
				AntiAim.SetRealOffset(-desyncamt)
			}
			else {
				AntiAim.SetOverride(1)
				AntiAim.SetFakeOffset(0)
				AntiAim.SetRealOffset(desyncamt)
			}
		}
		else {
			if (distance_delta > 1) {
				AntiAim.SetOverride(1)
				AntiAim.SetFakeOffset(0)
				AntiAim.SetRealOffset(desyncamt)
			}
			else {
				AntiAim.SetOverride(1)
				AntiAim.SetFakeOffset(0)
				AntiAim.SetRealOffset(-desyncamt)
			}
		}
	}
}

function shotfired() {
	if (Entity.IsEnemy(Entity.GetEntityFromUserID(Event.GetInt("userid")))) {
	   bullet_start_user = Entity.GetEntityFromUserID(Event.GetInt("userid"));
	   startlocation = Entity.GetHitboxPosition(Entity.GetEntityFromUserID(Event.GetInt("userid")), 2);
	}
}

function unload() {
	AntiAim.SetOverride(0)
}

Cheat.RegisterCallback("Unload", "unload")

Cheat.RegisterCallback("weapon_fire", "shotfired")
Cheat.RegisterCallback("bullet_impact", "on_impact");

var cnt = 0
var next_update = 0
var flip = false

function ty4asking() {
	eltick = parseInt(Globals.Curtime() * 1000);
    isInverted = UI.GetValue(["Rage", "Anti Aim", "General", "Key assignment", "AA Direction inverter"]);
    isDt = UI.GetValue(["Rage", "Exploits", "Double tap"]) && UI.GetValue(["Rage", "Exploits", "Keys", "Key assignment", "Double tap"]);
    isHideshots = UI.GetValue(["Rage", "Exploits", "Hide shots"]) && UI.GetValue(["Rage", "Exploits", "Keys", "Key assignment", "Hide shots"]);
    divide = 25;
    var view_angles = Local.GetViewAngles();
    var fake = Local.GetFakeYaw();

	if (UI.GetValue(fckinnn) == 1) {
		if (Input.IsKeyPressed(0x45)) {
			if (isInverted) {
				switch (eltick % divide)  {
					case 0 : UserCMD.Choke(); UserCMD.SetViewAngles([view_angles[0], view_angles[1] - 180, 0], true); break;
					case 1 : UserCMD.Choke(); UserCMD.SetViewAngles([view_angles[0], view_angles[1] + 75, 0], true); break;
					case 2 : UserCMD.Choke(); UserCMD.SetViewAngles([view_angles[0], view_angles[1] + fake, 0], true); break;
					case 3 : UserCMD.SetViewAngles([view_angles[0], view_angles[1] + 10, 0], true); UserCMD.Send(); break;
				}
			}
			else {
				switch (eltick % divide)  {
					case 0 : UserCMD.Choke(); UserCMD.SetViewAngles([view_angles[0], view_angles[1] + 180, 0], true); break;
					case 1 : UserCMD.Choke(); UserCMD.SetViewAngles([view_angles[0], view_angles[1] - 85, 0], true); break;
					case 2 : UserCMD.Choke(); UserCMD.SetViewAngles([view_angles[0], view_angles[1] - fake, 0], true); break;
					case 3 : UserCMD.SetViewAngles([view_angles[0], view_angles[1], 0], true); UserCMD.Send(); break;
				}
			}
		}
	}

	if (UI.GetValue(fckinnn) == 2) {
		if (Input.IsKeyPressed(0x45)) {
			var send_packet = true
		
			send_packet = false
			if (cnt % 2)
				send_packet = true
			cnt++
		
			flip = !flip
			
			var ang = Local.GetViewAngles()
			var lby = false
			var velo = Entity.GetProp(Entity.GetLocalPlayer(), "CCSPlayer", "m_vecVelocity[0]")
			var len = Math.sqrt(velo[0] * velo[0] + velo[1] * velo[1])
			if (UI.GetValue(["Rage", "volcano", "volcano", "[volcano] body-yaw type"]) == 0) {
				if (distance_delta > 1) //LOL
					inverter = false;
				else
					inverter = true;
			}
			else {
				if (distance_delta > 1)
					inverter = true;
				else
					inverter = false;
			}
			var buttons = UserCMD.GetButtons()
			var flservtime = Entity.GetProp(Entity.GetLocalPlayer(), "CCSPlayer", "m_nTickBase") * Globals.TickInterval()
			var canshoot = Entity.GetProp(Entity.GetWeapon(Entity.GetLocalPlayer()), "DT_BaseCombatWeapon", "m_flNextPrimaryAttack") <= flservtime
		
			var forward = 0
			var side = 0
			
			if (next_update <= Globals.Curtime()) {
				if (len < 10) {
					lby = true
				}
				next_update = Globals.Curtime() + 0.22
				if (side == 0) {
					var val = 1.1
					if (buttons & 4)
						val *= 3
					side = flip ? val : -val
				}
			}
			
			if (lby) {
				var fake_yaw = Local.GetFakeYaw()
				var real_yaw = Local.GetRealYaw()
				var diff = fake_yaw - real_yaw
				
				while (diff < -180)
					diff += 360
				
				while (diff > 180)
					diff -= 360
				
				diff = Math.abs(diff)
				
				if (diff > 58)
					ang[1] -= 180
				else
					ang[1] += inverter ? 120 : -120
				
				UserCMD.SetViewAngles(ang, true)
				send_packet = false
			}
			
			else if (!send_packet) {
				ang[1] += inverter ? -120 : 120
				UserCMD.SetViewAngles(ang, true)
			}
			
			send_packet ? UserCMD.Send() : UserCMD.Choke()
		}
	}
}

function adjust_angle(angle) { //still here
    if (angle < 0) {
        angle = (90 + angle * (-1));
    }
    else if (angle > 0) {
        angle = (90 - angle);
    }
    return angle;
}

shadow = [0, 0, 0, 255]

function Indicators_CLASS() {
	//asdf
	isAutodir = UI.GetValue(["Rage", "Anti Aim", "Directions", "Auto direction"]);
	isFakeduck = UI.GetValue(["Rage", "Anti Aim", "General", "Key assignment", "Fake duck"]);
	isResolver = UI.GetValue(["Rage", "General", "Resolver override"]);
	isForcebaim = UI.GetValue(["Rage", "General", "Force body aim"]);
	isSafepoint = UI.GetValue(["Rage", "General", "Force safe point"]);
	isDt = UI.GetValue(["Rage", "Exploits", "Keys", "Key assignment", "Double tap"]);
	isHideshots = UI.GetValue(["Rage", "Exploits", "Keys", "Key assignment", "Hide shots"]);
	isSlowwalk = UI.GetValue(["Rage", "Anti Aim", "General", "Slow walk"]);
	isCharging = Exploit.GetCharge();
	iticklol = UI.GetValue(["Rage", "General", "General", "Key assignment", "[volcano] Ideal tick"])
	//lol
	valuepath = "Rage", "VOLCANO", "VOLCANO"
	keyassignment = "Rage", "Anti Aim", "General", "Key assignment"
	text = UI.GetColor(["Rage", "volcano", "volcano", "[volcano] text color"]);
	accent = UI.GetColor(["Rage", "volcano", "volcano", "[volcano] accent color"]);
	secondary = UI.GetColor(["Rage", "volcano", "volcano", "[volcano] second accent color"]);

	var view_angles = Local.GetViewAngles();

	var real_yaw = Local.GetRealYaw();
	var view_yaw = view_angles[1] - 180;

	var real = adjust_angle(real_yaw - view_yaw);

	var extension = 1;

	var screensize = Render.GetScreenSize();
	var x = screensize[0] / 2;
	var y = screensize[1] / 2;
	var font = Render.GetFont("6pxbus.ttf", 6, true)
	var fontnn = Render.GetFont("6pxbus.ttf", 7, true)
	var main_size = Render.TextSize("VOLCANO", font)
	var free_size = Render.TextSize("FREESTANDING", font)
	var dt_size = Render.TextSize("DT", font)
	var hd_size = Render.TextSize("HS", font)
	var dt_charge = Exploit.GetCharge();
	var double_tap = UI.GetValue(["Rage", "Exploits", "Keys", "Key assignment", "Double tap"]);
	var desync_delta = clamp(Math.abs(Math.round(Local.GetRealYaw() - Local.GetFakeYaw())), 0, 58) / 1.7
	var dt_color = double_tap ? (dt_charge < 1 ? [255 - (dt_charge * 71), 32 + (dt_charge * 146), 28, 255] : [0, 255, 0, 255]) : [255, 0, 0, 255];
	var pulse_alpha = Math.sin(Math.abs(-Math.PI + (Globals.Curtime() * (1 / 0.5)) % (Math.PI * 2))) * 120;

	if (desync_delta > 0) {
		Render.FilledRect(Global.GetScreenSize()[0] / 2, Global.GetScreenSize()[1] / 2 + 30, 1, 2, secondary );
		Render.GradientRect((Global.GetScreenSize()[0] / 2 + -desync_delta * 2) + desync_delta + 1, Global.GetScreenSize()[1] / 2 + 30, desync_delta, 2, 1, [accent[0], accent[1], accent[2], accent[3]], [secondary[0], secondary[1], secondary[2], secondary[3]]);
		//Render.GradientRect((Global.GetScreenSize()[0] / 2 + -desync_delta * 2) + (desync_delta * 2) + 1, Global.GetScreenSize()[1] / 2 + 30, desync_delta, 2, 1, [secondary[0], secondary[1], secondary[2], secondary[3]], [accent[0], accent[1], accent[2], accent[3]]);
	}
	
		if (UI.GetValue(["Rage", "volcano", "volcano", "[volcano] body-yaw type"]) == 0) {
			if (distance_delta > 1) //LOL
				isInverted = false;
			else
				isInverted = true;
		}
		else {
			if (distance_delta > 1)
				isInverted = true;
			else
				isInverted = false;
		}

		Render.String(x + 38, y - 3, 1, ">", isInverted ? UI.GetColor(a_acc1) : UI.GetColor(a_acc2), font);
		Render.String(x - 38, y - 3, 1, "<", !isInverted ? UI.GetColor(a_acc1) : UI.GetColor(a_acc2), font);

	nn = real - (180 * 0.2)

	if (isDt) extension++;
	if (isHideshots) extension++;
	if (isSafepoint) extension++;
	if (isFakeduck) extension++;
	if (isAutodir) extension++;
	if (iticklol) extension++;

	draw_bold_text(x, (Render.GetScreenSize()[1] / 2 + 20), 1, "VOLCANO", [text[0], text[1], text[2], 255], font)

	if (isHideshots) {
		extension--;
		draw_bold_text(x, y + 27 + (extension * 10), 1, "HS", [0, 255, 0, 255], font)
	}
	if (isDt) {
		extension--;
		draw_bold_text(x, y + 27 + (extension * 10), 1, "DT", dt_color, font)
	}
	if (isSafepoint) {
		extension--;
		draw_bold_text(x, y + 27 + (extension * 10), 1, "SP", secondary, font)
	}
	if (isFakeduck) {
		extension--;
		draw_bold_text(x, y + 27 + (extension * 10), 1, "DUCK", [255, 255, 255, pulse_alpha], font)
	}
	if (isAutodir) {
		extension--;
		draw_bold_text(x, y + 27 + (extension * 10), 1, "AUTO", [73, 140, 255, 255], font)
	}
	if (iticklol) {
		extension--;
		draw_bold_text(x, y + 27 + (extension * 10), 1, "IDEALTICK", [255, 193, 122, 255], font)
	}
}
var weaponTabNames = {
	"usp s": "USP"
	, "glock 18": "Glock"
	, "dual berettas": "Dualies"
	, "r8 revolver": "Revolver"
	, "desert eagle": "Deagle"
	, "p250": "P250"
	, "tec 9": "Tec-9"
	, "mp9": "MP9"
	, "mac 10": "Mac10"
	, "pp bizon": "PP-Bizon"
	, "ump 45": "UMP45"
	, "ak 47": "AK47"
	, "sg 553": "SG553"
	, "aug": "AUG"
	, "m4a1 s": "M4A1-S"
	, "m4a4": "M4A4"
	, "ssg 08": "SSG08"
	, "awp": "AWP"
	, "g3sg1": "G3SG1"
	, "scar 20": "SCAR20"
	, "xm1014": "XM1014"
	, "mag 7": "MAG7"
	, "m249": "M249"
	, "negev": "Negev"
	, "p2000": "P2000"
	, "famas": "FAMAS"
	, "five seven": "Five Seven"
	, "mp7": "MP7"
	, "ump XMRoff": "Sawed off"
	, "cz75 auto" : "CZ-75"
	, "nova": "Nova"
};

function updateDamageValues() {
	if (!Entity.IsAlive(Entity.GetLocalPlayer()))
		return;
	var weaponName = Entity.GetName(Entity.GetWeapon(Entity.GetLocalPlayer()))
	if (!weaponTabNames.hasOwnProperty(weaponName)) {
		return;
	}
	var isOverride = UI.GetValue(hdf) ? true : false;

	if (isOverride) {
		var target = Entity.GetEnemies();
		for (var i in target) {
			if (UI.GetValue(["Rage", "Target", weaponTabNames[weaponName], "Damage Override"]) != 0) {
				Ragebot.ForceTargetMinimumDamage(target[i], UI.GetValue(["Rage", "Target", weaponTabNames[weaponName], "Damage Override"]))
			}
			else {
				Ragebot.ForceTargetMinimumDamage(target[i], UI.GetValue(["Rage", "Target", "General", "Damage Override"]))
			}
		}
	}
}

function dmg_indi() {
	if (UI.GetValue(["Rage", "volcano", "volcano", "[volcano] min damage indicator"])) {
		if (!font)
			font = Render.GetFont("Tahomabd.ttf", 6, true)
		if (Entity.IsAlive(Entity.GetLocalPlayer())) {
			var color = UI.GetColor(["Rage", "volcano", "volcano", "[volcano] min damage indicator color"])
			var screenSize = Render.GetScreenSize();
			var weaponName = Entity.GetName(Entity.GetWeapon(Entity.GetLocalPlayer()))
			if (weaponTabNames.hasOwnProperty(weaponName)) {
				var isOverride = UI.GetValue(hdf) ? true : false;
				if (isOverride) {
					if (UI.GetValue(["Rage", "Target", weaponTabNames[weaponName], "Damage Override"]) != 0) {
						Render.String(screenSize[0] / 2 + 46, screenSize[1] / 2 - 37, 0, UI.GetValue(["Rage", "Target", weaponTabNames[weaponName], "Damage Override"])
							.toString(), [0, 0, 0, 255], font);
						Render.String(screenSize[0] / 2 + 45, screenSize[1] / 2 - 38, 0, UI.GetValue(["Rage", "Target", weaponTabNames[weaponName], "Damage Override"])
							.toString(), color, font);
					}
					else {
						Render.String(screenSize[0] / 2 + 46, screenSize[1] / 2 - 37, 0, UI.GetValue(["Rage", "Target", "General", "Damage Override"])
							.toString(), [0, 0, 0, 255], font);
						Render.String(screenSize[0] / 2 + 45, screenSize[1] / 2 - 38, 0, UI.GetValue(["Rage", "Target", "General", "Damage Override"])
							.toString(), color, font);
					}
				}
			}
		}
	}
}


function main() {
	UI.AddSliderInt(["Rage", "Target", "General"], "Damage Override", 0, 130)
	for (var name in weaponTabNames) {
		UI.AddSliderInt(["Rage", "Target", weaponTabNames[name]], "Damage Override", 0, 130)
	}
	Cheat.RegisterCallback("Draw", "dmg_indi")
	Cheat.RegisterCallback("CreateMove", "updateDamageValues")
}
main()

function watermark_class() {
	var font = Render.GetFont("Verdana.ttf", 10, true)
	var color = UI.GetColor(["Rage", "volcano", "volcano", "[volcano] watermark color"])
	var backgroundcolor = [20, 20, 20, 255]
	var t1 = new Date()
	var h1 = t1.getHours()
	var m1 = t1.getMinutes()
	var s1 = t1.getSeconds()
	var h2 = h1 <= 9 ? "0" + h1 : h1
	var m2 = m1 <= 9 ? "0" + m1 : m1
	var text = " " + Cheat.GetUsername() + " | volcano [BETA]" + " | " + World.GetServerString() + " | " + Globals.Tickrate() + " | " + h2 + ":" + m2
	var w = Render.TextSize(""+text,font)[0] + 8
	var x = Global.GetScreenSize()[0]
	var y = Global.GetScreenSize()[1]
	var x = x - w - 10
	if (UI.GetValue(["Rage", "volcano", "volcano", "[volcano] watermark"]) == 1) {
		//Render.FilledRect(x + 1, 8, w, 20, backgroundcolor)
		Render.GradientRect(x + 1, 8, w/2, 20, 1, [20, 20, 20, 0], [0, 0, 0, 240]);
		Render.GradientRect(x + w/2 + 1, 8, w/2, 20, 1, [0, 0, 0, 240], [20, 20, 20, 0]);
		Render.FilledRect(x - 1, 8, 3, 20, color)
		Render.String(x + 5, 10, 0, text, [255, 255, 255, 255], font)
	}
}

function retarded_class_kys() {
	if (UI.GetValue(nowyoucanpretendyouhaveskeet)) {
		var font = Render.GetFont("Verdana.ttf", 10, true)
		var ihaveuselessvarsrunningeverysingleframefornoreason = UI.GetColor(["Rage", "volcano", "volcano", "[volcano] watermark color"]);
		var fake = Local.GetFakeYaw();
		var real = Local.GetRealYaw();
		var delta = Math.min(Math.abs(real - fake) / 2, 60).toFixed(1);
		var x = Global.GetScreenSize()[0]
		var y = Global.GetScreenSize()[1]
		var wtfissafety = (delta - fake)* 100 /250 
	
		if (UI.GetValue(["Rage", "Anti Aim", "General", "Key assignment", "Slow walk"]) == true) {
			isInverted = false;
		}
		else {
			if (UI.GetValue(["Rage", "volcano", "volcano", "[volcano] body-yaw type"]) == 0) {
				if (distance_delta > 1) //LOL
					isInverted = false;
				else
					isInverted = true;
			}
			else {
				if (distance_delta > 1)
					isInverted = true;
				else
					isInverted = false;
			}
		}
	
		if (isInverted) {
			var text = "FAKE (" + String(delta) + " ) | safety: " + Math.abs(wtfissafety.toFixed(0)) + "% | " + "side: >" 
		}
		else {
			var text = "FAKE (" + String(delta) + " ) | safety: " + Math.abs(wtfissafety.toFixed(0)) + "% | " + "side: <" 
		}
	
		var w = Render.TextSize(""+text,font)[0] + 8
	
		Render.GradientRect(x - w/2 - 122, 32, w/2 + 112, 20, 1,  [20, 20, 20, 100], [20, 20, 20, 100]);
		Render.FilledRect(x - w/2 - 122, 32, 3, 20, [255 - delta, 0 + delta * 4, 0, 255])
		Render.String(x - 114 - w/2, 34, 0, text, [255, 255, 255, 255], font)
		if (delta < 10) {
			Render.Circle(x - 161, 38, 1, [255, 255, 255, 255]);
		}
		else {
			Render.Circle(x - 158, 38, 1, [255, 255, 255, 255]);
		}
	}
}

function bullet_impact() {
	var local_player = Entity.GetLocalPlayer();
	user_id = Entity.GetEntityFromUserID(Event.GetInt("userid"));
	if (user_id != local_player) return;
	pos_final = [Event.GetFloat("x"), Event.GetFloat("y"), Event.GetFloat("z")];
	m_pos.push([pos_final, 255]);
}
var m_pos = [];
var tickcount = 0
var flip = false

function on_paint() {
	for (var i = 0; i < m_pos.length; i++) {
		var col = UI.GetColor(["Rage", "volcano", "volcano", "[volcano] hitmarker color"])
		var pos_lol = Render.WorldToScreen(pos_lmao = m_pos[i][0])
		Render.FilledRect(pos_lol[0], pos_lol[1] - 4, 2, 10, [col[0], col[1], col[2], m_pos[i][1]]);
		Render.FilledRect(pos_lol[0] - 4, pos_lol[1], 10, 2, [col[0], col[1], col[2], m_pos[i][1]]);
		m_pos[i][1]--;
		if (m_pos[i][1] <= 0) {
			m_pos.shift(i, m_pos[i][1]); //i had so much issues with this bullshit 
		}
	}
}

function fakelag() {
	var nn = UI.GetValue(["Rage", "volcano", "volcano", "[volcano] fakelag mode"]);

	if (nn == 1) {
        if(tickcount >= 16 && !flip)
        {
            flip = true
            tickcount = 0
        }
        if(tickcount >= 6 && flip)
        {
            flip = false
            tickcount = 0
        }

    	UI.SetValue(["Rage", "Fake Lag", "Limit"], !flip ? 16 : 0)
    	tickcount++
	}

	if (nn == 2) {
		UI.SetValue(["Rage", "Fake Lag", "Limit"], Math.ceil(Math.random() * 16 + 3))
	}
}

function round_start() {
	m_pos = [];
}

function onCreateMove() {
	NOSCOPE_HITCHANCE_CLASS();
	anti_aim();
	LegBreaker_CLASS();
	IdealTick_CLASS();
	ty4asking();
	fakelag();
	simpleshitretard();
	airhc()
}

function onDraw() {
	const local = Entity.GetLocalPlayer();
	if (!Entity.IsValid(local) || !Entity.IsAlive(local))
		return
	watermark_class();
	Indicators_CLASS();
	dmg_indi();
	if (UI.GetValue(["Rage", "volcano", "volcano", "[volcano] hitmarker"]) == true) {
		on_paint();
	}
	UI.SetValue(["Misc.", "View", "General", "Thirdperson Distance"], UI.GetValue(["Rage", "volcano", "volcano", "[volcano] thirdperson distance"]))
	retarded_class_kys();
}

Cheat.RegisterCallback("Draw", "onDraw")
Cheat.RegisterCallback("CreateMove", "onCreateMove")
Cheat.RegisterCallback("bullet_impact", "bullet_impact");
Cheat.RegisterCallback("round_start", "round_start");
Cheat.RegisterCallback("Draw", "menu")