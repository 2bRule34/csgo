var alpha = 0;
var menuPath = [ "Visuals", "Other", "Other"];
var molotov = [];
var screen_size = Render.GetScreenSize();

function menuoptions() 
{
    var activeindicators = (UI.GetValue(["Visuals", "Indicators", "Indicators", "Indicators"]))
                .toString(2)
                .split("")
                .reverse()
                .map(Number);
    UI.SetEnabled(["Rage", "SUBTAB_MGR", "AA", "SHEET_MGR", "AA", "Real amount:"], UI.GetValue(["Rage", "SUBTAB_MGR", "AA", "SHEET_MGR", "AA", "Real type"]) == 2 && 1 || 0)
    UI.SetEnabled(["Rage", "SUBTAB_MGR", "AA", "SHEET_MGR", "AA", "Fake amount:"], UI.GetValue(["Rage", "SUBTAB_MGR", "AA", "SHEET_MGR", "AA", "Desync type"]) == 2 && 1 || 0)
    UI.SetEnabled(["Rage", "Aimbot", "Aimbot", "Visible Hitbox Thresold"], UI.GetValue(["Rage", "Aimbot", "Aimbot", "Legit Autowall"]))
}
function finlandaa() {
    AntiAim.SetFakeOffset(0);
    var fake_yaw = Local.GetFakeYaw();
    var real_yaw = Local.GetRealYaw();
    var local = 0;
    current_inversion = UI.GetValue(["Rage", "Anti Aim", "General", "Key assignment", "AA Direction inverter"]) == 1 ? -1 : 1;
    
    var local_velocity = Entity.GetProp(local, "CBasePlayer", "m_vecVelocity[0]");
    var local_velocity_length = vector_length(local_velocity);
    var local_eye_yaw_netvar = Entity.GetProp(local, "CCSPlayer", "m_angEyeAngles")[1];
    
    var local_eye_yaw_real_delta = angle_diff(local_eye_yaw_netvar, real_yaw);
    var local_eye_yaw_fake_delta = angle_diff(local_eye_yaw_netvar, fake_yaw);
    lbyamount = UI.GetValue(["Rage", "AA", "AA", "Real amount:"])
    lbyamount2 = UI.GetValue(["Rage", "AA", "AA", "Fake amount:"])
    if (UI.GetValue(["Rage", "AA", "AA", "Real type"]) == 0 ) {
        AntiAim.SetOverride(0);
    }
    if (UI.GetValue(["Rage", "AA", "AA", "Real type"]) == 1 ) {
        AntiAim.SetRealOffset(120 * random_float(1, 2));
    }
    if (UI.GetValue(["Rage", "AA", "AA", "Real type"]) == 2 ) {   
        AntiAim.SetOverride(1);
        AntiAim.SetRealOffset((local_velocity_length > 3.3 ? lbyamount : lbyamount) * -current_inversion);
    }
    
    if (UI.GetValue(["Rage", "AA", "AA", "Real type"]) == 3 ) {
        AntiAim.SetOverride(1);
        AntiAim.SetRealOffset(local_eye_yaw_real_delta > 35 ? (15 * -current_inversion) : (60 * random_float(0.6, 2.5) * -current_inversion));
    }
    if (UI.GetValue(["Rage", "AA", "AA", "Real type"]) == 4 ) {
        AntiAim.SetOverride(1);
        AntiAim.SetRealOffset(real * -current_inversion)
    }
    if (UI.GetValue(["Rage", "AA", "AA", "Real type"]) == 5 ) {
        AntiAim.SetOverride(1);
        AntiAim.SetRealOffset((local_velocity_length > 3.3 ? 20 : 20) * -current_inversion);
    }
    if (UI.GetValue(["Rage", "AA", "AA", "Desync type"]) == 0 ) {
        AntiAim.SetOverride(0);
    }
    
    if (UI.GetValue(["Rage", "AA", "AA", "Desync type"]) == 1 )
    
    {
        AntiAim.SetOverride(1);
        lower_body_yaw_offset = 160 * current_inversion + local_eye_yaw_fake_delta < 50 ? ((Globals.Curtime() * 180 / random_float(-5, 5) % 240) * current_inversion) : ((Globals.Curtime() * 360 / random_float(-0.1, 0.3) % 91) * current_inversion);
        
        if (Globals.Tickcount() % 3 == 0) {
            lower_body_yaw_offset *= -1.5;
        }
        AntiAim.SetLBYOffset(lower_body_yaw_offset);
    }
    
    if (UI.GetValue(["Rage", "AA", "AA", "Desync type"]) == 2 ) {
        AntiAim.SetOverride(1);
        lower_body_yaw_offset = lbyamount2 * current_inversion;
        AntiAim.SetLBYOffset(lower_body_yaw_offset);
    }
    if (UI.GetValue(["Rage", "AA", "AA", "Desync type"]) == 3 ) {
        AntiAim.SetOverride(1);
        AntiAim.SetLBYOffset(fake * -current_inversion);
    }
};


//vector
var vector = {
    _class: 'vector'
};

//vector.new
vector.new = function (data) {
    return {
        x: data[0],
        y: data[1],
        z: data[2]
    };
};

//vector.operate
vector.operate = function (vec, vec2, operation) {
    switch (operation) {
    case '+':
        return {
            x: vec.x + vec2.x, y: vec.y + vec2.y, z: vec.z + vec2.z
        };
        
    case '-':
        return {
            x: vec.x - vec2.x, y: vec.y - vec2.y, z: vec.z - vec2.z
        };
        
    case '*':
        return {
            x: vec.x * vec2.x, y: vec.y * vec2.y, z: vec.z * vec2.z
        };
        
    case '/':
        return {
            x: vec.x / vec2.x, y: vec.y / vec2.y, z: vec.z / vec2.z
        };
        
    default:
        throw new Error("[Vector] Invalid operation type.");
    }
};

//vector angeles
vector.angles = function (vec) {
    return {
        x: -Math.atan2(vec.z, this.length2d(vec)) * 180 / Math.PI,
        y: Math.atan2(vec.y, vec.x) * 180 / Math.PI,
        z: 0
    };
};

//vector length2d
vector.length2d = function (vec) {
    return Math.sqrt(vec.x * vec.x + vec.y * vec.y);
};

//vector fov_to
vector.fov_to = function (origin, destination, view) {
    const angles = this.angles(this.operate(destination, origin, '-'));
    
    const delta = this.new(
        [
            Math.abs(view.x - angles.x)
            , Math.abs(view.y % 360 - angles.y % 360) % 360
            , 0
        ]
    );
    
    if (delta.y > 180)
        delta.y = 360 - delta.y;
    
    return this.length2d(delta);
};

//vector to_array
vector.to_array = function (vec) {
    return [
        vec.x
        , vec.y
        , vec.z
    ];
};

//function normalize_yaw
function normalize_yaw(angle) {
    var adjusted_yaw = angle;
    
    if (adjusted_yaw < -180)
        adjusted_yaw += 360;
    
    if (adjusted_yaw > 180)
        adjusted_yaw -= 360;
    
    return adjusted_yaw;
}

//function vector_length
function vector_length(a) {
    return Math.sqrt(a[0] ** 2 + a[1] ** 2 + a[2] ** 2);
}

//function vecNew (data)
function vecNew(data) {
    return {
        x: data[0],
        y: data[1],
        z: data[2]
    };
}

//function`s angle_diff and random_float
function angle_diff(angle1, angle2) {
    var diff = angle1 - angle2;
    diff %= 360;
    if (diff > 180) {
        diff -= 360;
    }
    if (diff < -180) {
        diff += 360;
    }
    return diff;
}

function random_float(min, max) {
    return Math.random() * (max - min) + min;
}

//function get_closest_target
function get_closest_target() {
    const players = Entity.GetEnemies();
    const localEnt = Entity.GetLocalPlayer();
    const data = {
        id: null,
        fov: 180
    };
    
    for (var i = 0; i < players.length; i++) {
        const e = players[i];
        
        const eHead = vecNew(Entity.GetHitboxPosition(e, 0));
        localHead = vecNew(Entity.GetEyePosition(localEnt));
        const vAngle = vecNew(Local.GetViewAngles());
        
        const fov = vector.fov_to(localHead, eHead, vAngle);
        
        if (fov < data.fov) {
            data.id = e;
            data.fov = fov;
        }
    }
    return data.id;
}
//Anti-aims 
function update_anti_aim_state(state) {
    if (UI.GetValue(["Rage", "General", "General", "Enabled"])) {
        if (UI.GetValue(["Rage", "Anti Aim", "General", "Key assignment", "AA Direction inverter"]) !== state)
            UI.ToggleHotkey(["Rage", "Anti Aim", "General", "Key assignment", "AA Direction inverter"]);   
    }
    state = (state + 1) % 2;
    if (UI.GetValue(["Legit", "General", "General", "Key assignment", "AA Direction inverter"]) !== state)
        UI.ToggleHotkey(["Legit", "General", "General", "Key assignment", "AA Direction inverter"]);
}



var plugin = {
    last_hit_lby: [],
    last_target_visibility: false,
    override_flip: false,
    last_override_time: Globals.Curtime()
};

function get_optimal_angle() {
    const _mode = UI.GetValue(["Rage", "AA", "AA","Freestanding mode"]);
    const me = Entity.GetLocalPlayer();
    const origin = vector.new(Entity.GetRenderOrigin(me));
    var yaw = Local.GetViewAngles()[1];
    var data = {
        left: 0,
        right: 0
    };
    
    for (var r = yaw - 90; r <= yaw + 90; r += 30) {
        if (r === yaw)
            continue;
        const rad = r * Math.PI / 180;
        const point = vector.operate(
            origin, vector.new([
                256 * Math.cos(rad)
                , 256 * Math.sin(rad)
                , 0
            ]), "+"
        );
        const line = Trace.Line(me, vector.to_array(origin), vector.to_array(point));
        const side = r < yaw ? "left" : "right";
        data[side] += line[1];
    }
    data.left /= 3;
    data.right /= 3;
    if (data.left > data.right)
        return _mode === 0 ? 0 : 1;

    return _mode === 0 ? 1 : 0;
}




function update_anti_aim() {
    const me = Entity.GetLocalPlayer();
    if (!Entity.IsValid(me) || !Entity.IsAlive(me))
        return;

     {
        const target = get_closest_target();
        if (target == null) {
            update_anti_aim_state(get_optimal_angle());
            return;
        }
        if (plugin.last_hit_lby[target] == null) {
            update_anti_aim_state(get_optimal_angle());
            return;
        }
        if (plugin.last_hit_lby[target] === 0) {
            update_anti_aim_state(1);
            return;
        }
        update_anti_aim_state(0);
        return;
    }
    update_anti_aim_state(get_optimal_angle());
}


function on_tick() {
    if (!(UI.GetValue(["Rage", "AA", "AA", "Freestanding"])))
        return;
    update_anti_aim();
}

function on_player_hurt() {
    const me = Entity.GetLocalPlayer();
    const attacker = Entity.GetEntityFromUserID(Event.GetInt("attacker"));
    const userid = Entity.GetEntityFromUserID(Event.GetInt("userid"));
    
    if (me != attacker && me == userid) {
        
        plugin.last_hit_lby[attacker] = UI.ToggleHotkey(["Rage", "Anti Aim", "General", "Key assignment", "AA Direction inverter"]);
    }
}

Render.GradientSkeet = function (x, y, w, h, dir, col1, col2)
{
	Render.GradientRect(x, y - 4, w / 4, h, dir, col2, col1);
	Render.GradientRect(x + (w / 4), y - 4, w / 4, h, dir, col1, col2);
};


//functions restrictions  (Security)
function Security()

{
    UI.SetValue(["Rage", "Anti Aim", "Directions", "Yaw offset"], 180)
    UI.SetValue(["Rage", "Anti Aim", "Directions", "Jitter offset"], 0)
    UI.SetValue(["Config", "Cheat", "General", "Restrictions"], 0)
    UI.SetValue(["Rage", "Anti Aim", "General", "Pitch mode"], 0)
    
    {
        UI.SetColor(["Visuals", "Indicators", "Indicators", "Indicators color"], [154, 205, 50, 255]);
    }
}

//Subtabs
UI.AddSubTab(["Rage", "SUBTAB_MGR"], "Aimbot")
UI.AddSubTab(["Rage", "SUBTAB_MGR"], "AA")
UI.AddSubTab(["Visuals", "SUBTAB_MGR"], "Indicators")
UI.AddSubTab(["Visuals", "SUBTAB_MGR"], "Helpers")
UI.AddSubTab(["Visuals", "SUBTAB_MGR"], "Other")

//Aimbot Tab
UI.AddSliderInt(["Rage", "Aimbot", "Aimbot"], "Min fov", 0, 180);
UI.AddSliderInt(["Rage", "Aimbot", "Aimbot"], "Max fov", 0, 180);
UI.AddSliderInt(["Rage", "Aimbot", "Aimbot"], "Minimum damage override", 0, 130);
UI.AddHotkey(["Rage", "General", "General", "Key assignment"], "Minimum damage override", "Minimum damage override");
UI.AddCheckbox(["Rage", "Aimbot", "Aimbot"], "Smoke check");
UI.AddCheckbox(["Rage", "Aimbot", "Aimbot"], "Legit Autowall");
UI.AddSliderInt(["Rage", "Aimbot", "Aimbot"], "Visible Hitbox Thresold", 1, 7)
UI.AddHotkey(["Rage", "General", "General", "Key assignment"], "Autowall key", "Autowall");
UI.AddHotkey(["Rage", "General", "General", "Key assignment"], "Fake duck", "Fake duck");


//AA tab
UI.AddDropdown(["Rage", "AA", "AA"], "Desync type", ["Off", "Random", "Custom angle", "Sway"], 0);
UI.AddSliderInt(["Rage", "AA", "AA"], "Fake amount:", 0, 58);
UI.AddDropdown(["Rage", "AA", "AA"], "Real type", ["Off", "Random", "Custom angle", "Eye yaw based", "Sway", "Low delta"], 0);
UI.AddSliderInt(["Rage", "AA", "AA"], "Real amount:", 0, 58);
UI.AddCheckbox(["Rage", "AA", "AA"], "Freestanding");
UI.AddDropdown(["Rage", "AA", "AA"], "Freestanding mode", ["Peek with fake", "Peek with real"], 0);
UI.AddCheckbox(["Rage", "AA", "AA"], "Leg breaker");



//Visuals tab
UI.AddMultiDropdown(["Visuals", "Indicators", "Indicators"], "Indicators", ["DESYNC RANGE", "MINIMUM DAMAGE", "FOV", "AUTOFIRE", "AUTOWALL", "BODY AIM", "FAKE DUCK", "RESOLVER OVERRIDE"], 1);
UI.AddDropdown(["Visuals", "Indicators", "Indicators"], "Indicators size", ["1", "2", "3"], 0);
UI.AddSliderInt(["Visuals", "Indicators", "Indicators"], "Indicators Y offset", 160, screen_size[1]);
UI.AddDropdown(["Visuals", "Indicators", "Indicators"], "Antiaim arrow type", ["off", "1", "2", "3", "4", "5"], 0);
UI.AddSliderInt(["Visuals", "Indicators", "Indicators"], "Arrows X offset", 15, 200);
UI.AddColorPicker(["Visuals", "Indicators", "Indicators"], "Arrows color");
UI.AddMultiDropdown(["Visuals", "Helpers", "Helpers"], "Hit logs", ["Console", "Chat"], 1);
UI.AddMultiDropdown(["Visuals", "Helpers", "Helpers"], "Buy logs", ["Console", "Chat"], 1);
UI.AddCheckbox(["Visuals", "Indicators", "Indicators"], "Autowall indicator under crosshair");
UI.AddCheckbox(["Visuals", "Helpers", "Helpers"], "Killsay");
UI.AddCheckbox(["Visuals", "Helpers", "Helpers"], "Spectators");
UI.AddColorPicker(["Visuals", "Indicators", "Indicators"], "Indicators color");
UI.AddCheckbox(["Visuals", "Indicators", "Indicators"], "Arrows fake color")
UI.AddSliderFloat(["Visuals", "Helpers", "Helpers"], "Aspect Ratio", 0.0, 5.0);
UI.AddDropdown(["Visuals", "Other", "Other"], "Clantag spammer", ["off", "finlandhook"], 0);
UI.SetEnabled(["Config", "Cheat", "General", "RAGE QUIT"], 0)

//Fakeduck mm fix
var crouchHeight;
function FakeDuck() {
    var cmd = UserCMD.GetButtons();
    //If key is held do ducking
    if(UI.GetValue(["Rage", "General", "General", "Key assignment", "Fake duck"])) {
        var entityStuff = Entity.GetProp(Entity.GetLocalPlayer(), "CCSPlayer", "m_flDuckAmount");
        if(UserCMD.Choke(), entityStuff <= 0.21) {
            crouchHeight = !0
        }
        if(entityStuff >= 0.7 && (crouchHeight = !1, UserCMD.Send()), crouchHeight) {
            UserCMD.SetButtons(4 | cmd)
        } else UserCMD.SetButtons(cmd | 1 << 22)
    } else {
        UserCMD.SetButtons(cmd | 1 << 22)
    }
}

// enemy vis check
const scan_array = [0, 3, 5, 11, 12, 13, 14];
function enemy_vis(enemy) {
	if(!enemy) return 0;

	var total_hitbox_vis = 0;

	var lp = Entity.GetLocalPlayer();

	var eye_pos = Entity.GetEyePosition(lp);

	for (i = 0; i < scan_array.length; i++) {
		var trace = Trace.Line(lp, eye_pos, Entity.GetHitboxPosition(enemy, scan_array[i]))

		if (trace[1] >= 0.95) {
			total_hitbox_vis++;
		}
		if (total_hitbox_vis >= UI.GetValue(["Rage", "Aimbot", "Aimbot", "Visible Hitbox Thresold"])){
			return true;
		}
	}

	return total_hitbox_vis >= UI.GetValue(["Rage", "Aimbot", "Aimbot", "Visible Hitbox Thresold"])
}

//Aspect ratio
function aspectratio( ) {
    menu_val = UI.GetValue(["Visuals", "Helpers", "Helpers", "Aspect Ratio"] );
    string_menu_val = menu_val.toString();
    
    Convar.SetString ("r_aspectratio", string_menu_val );
    }
var observators = [];
//Spectator list
function spec1() {
    if (UI.GetValue(["Visuals", "Helpers", "Helpers", "Spectators"]) == false) return;

    var ents = Entity.GetPlayers();
    var local = Entity.GetLocalPlayer();
    var localtarget = Entity.GetProp(local, "CBasePlayer", "m_hObserverTarget");
    if (!local) return;
    observators = [];
    for (i = 0; i < ents.length; i++) {
        if (Entity.IsAlive(local)) {
            if (!ents[i] || Entity.IsAlive(ents[i])) continue;
            var observer = Entity.GetProp(ents[i], "CBasePlayer", "m_hObserverTarget");
            if (!observer || observer == "m_hObserverTarget") continue;
            if (observer == local) observators.push(Entity.GetName(ents[i]));
        } else {
            if (!ents[i] || Entity.IsAlive(ents[i])) continue;
            var observer = Entity.GetProp(ents[i], "CBasePlayer", "m_hObserverTarget");
            if (!observer || observer == "m_hObserverTarget") continue;
            if (observer == localtarget) observators.push(Entity.GetName(ents[i]));
        }
    }
}

function spec2() {
    if (UI.GetValue(["Visuals", "Helpers", "Helpers", "Spectators"]) == false) return;

    var consola_2 = Render.GetFont("consola.ttf", 12,true);

    var screen = screen_size;
    
    for (i = 0; i < observators.length; i++) {
        var name = observators[i];
        var size = Render.TextSize(name, consola_2);
        Render.String(screen[0] - size[0] - 1400, (i * 20) + 20, 0, name, [255, 255, 255, 255], consola_2);
    }

}
function spec3() {
    observators = [];
}
//Killsay
var normal_killsays = ["Visit www.ezfrags.co.uk for the finest public & private CS:GO cheats", "Stop being a noob! Get good with www.ezfrags.co.uk", "I'm not using www.ezfrags.co.uk, you're just bad", "You just got pwned by EZfrags, the #1 CS:GO cheat"
, "If I was cheating, I'd use www.ezfrags.co.uk", "Think you could do better? Not without www.ezfrags.co.uk"
];


function on_player_death() {
    if (UI.GetValue(["Visuals", "Helpers", "Helpers", "Killsay"])) {
        var victim = Entity.GetEntityFromUserID(Event.GetInt("userid"));
        var attacker = Entity.GetEntityFromUserID(Event.GetInt("attacker"));
        var headshot = Event.GetInt("headshot") == 1;
        
        if (Entity.IsLocalPlayer(attacker) && attacker != victim) {
            var normal_say = normal_killsays[Math.floor(Math.random() * normal_killsays.length)];
            Cheat.ExecuteCommand("say " + normal_say);
        }
    }
}
//Function Smokecheck
function isBehindSmoke(entity_index)
{
    eyepos = Entity.GetEyePosition(Entity.GetLocalPlayer());
    if (Entity.IsValid(entity_index) && Entity.IsAlive(entity_index) && !Entity.IsDormant(entity_index)){
        hitbox_pos = Entity.GetHitboxPosition(entity_index, 0);
        result = Trace.Smoke(eyepos, hitbox_pos);
        return result == 1
    }
}

function smokecheck() {
    enemies = Entity.GetEnemies()
    if(!UI.GetValue(["Rage", "Aimbot", "Aimbot", "Smoke check"])) return;
    for (i=0; i < enemies.length; i++)
    {
        if (isBehindSmoke(enemies[i]))
        {
            Ragebot.IgnoreTarget(enemies[i])
        }
    }
}
//function legs
var BreakLeg = true
var Loop = 1;
var Loop2 = 1;

function legs() {
    
    UI.GetValue(["Rage", "AA", "AA", "Leg breaker"]) && (trufalse = 10 * Math.abs(Math.sin(64 * Globals.Realtime())),trufalse > 5 && UI.SetValue(["Misc.", "Movement", "Leg movement"], 0), trufalse < 5 && UI.SetValue(["Misc.", "Movement", "Leg movement"], 1))
    
}
//function Buylogs
function BuyLogs() {
     
        var items = (UI.GetValue(["Visuals", "Helpers", "Helpers", "Buy logs"]))
        .toString(2)
        .split("")
        .reverse()
        .map(Number);

        var ent = Entity.GetEntityFromUserID(Event.GetInt('userid'))
        
        var team = Event.GetInt('team')
        
        if (team != Entity.GetProp(Entity.GetLocalPlayer(), "CBaseEntity", "m_iTeamNum")) {
            
            var item = Event.GetString('weapon')
            
            item = item.replace("weapon_", "")
            
            item = item.replace("item_", "")
            
            item = item.replace("assaultsuit", "kevlar + helmet")
            
            item = item.replace("incgrenade", "molotov")
            
            
            if (items[0]) 
            {
            if (item != "unknown") {
                
                var name = Entity.GetName(ent)
                
                Cheat.PrintColor([89, 119, 239, 255], '[finlandhook] ')
                Cheat.PrintColor([255, 255, 255, 255], + name + ' bought ' + item + ' \n')
                logs.push(+ name + ' bought ' + item + ' ');
                logsct.push(Globals.Curtime());
                logsalpha.push(255);
            }

            if (items[1]) 
            {
            if (item != "unknown") {

                Cheat.PrintChat(" \x0c[\x0cfinlandhook\x0c]\x08 " + name + "\x0c bought \x08" + item + " \n");      

            }
        }  
    }
}
}

    
//Function clantag
var lasttime = 0;

var customtext = 0;

function time_to_ticks(time) {
    
    var timer = time / Globals.TickInterval() + .5;
    
    return timer;
    
}

var old_text_anim = 0;

function anim(texta, indices) {
    
    if (!World.GetServerString()) return;
    
    if (UI.GetValue(["Visuals", "Other", "Other", "Clantag spammer"]))
    
    {
        
        text_anim = "                 " + texta + "                 ";
        
    } 
    else
    {
        text_anim = "  "
    }
    tickinterval = Globals.TickInterval();
    
    tickcount = Globals.Tickcount() + time_to_ticks(Local.Latency());
    
    ddd = tickcount / time_to_ticks(0.3);
    
    ddd = Math.floor(ddd % indices.length);
    
    ddd = indices[ddd + 1] + 1;
    
    text_anim = text_anim.slice(ddd, ddd + 15);
    
    if (text_anim != old_text_anim)
    
    {
        
        Local.SetClanTag(text_anim);
        
    }
    
    old_text_anim = text_anim;
    
}


function clantag() {
    
    var clantag = UI.GetValue(["Visuals", "Other", "Other", "Clantag spammer"]);
    
    if (clantag == 1)
    {
        customtext = "finlandhook";
    }
    anim(customtext, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11 ,12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28])
}
//SkeetGradient
Render.GradientSkeet = function (x, y, w, h, dir, col1, col2)
{
	Render.GradientRect(x, y - 4, w / 4, h, dir, col2, col1);
	Render.GradientRect(x + (w / 4), y - 4, w / 4, h, dir, col1, col2);
};
    
//Sway
var fake = -60;
var down = true

function fakesway() {
    var speed2 = 0.5
    var AngleC = 0
    var AngleD = -65
    AngleD = 0 - AngleD;
    
    if (down) {
        
        if (fake <= AngleC) {
            fake = fake + 1;
        }
        
        if (fake >= AngleC) {
            down = false;
        }
    }
    if (!down) {
        
        if (fake >= -AngleD) {
            fake = fake - 1;
        }
        if (fake <= -AngleD) {
            down = true;
        }
    }
}




var real = -58;
var up = true

function realsway() {
    var AngleA = 65
    var AngleB = 0
    AngleB = 0 - AngleB;
    
    if (up) { 
        if (real <= AngleA) {
            real = real + 1;
        }

        if (real >= AngleA) {
            up = false;
        }
    } else {
        if (real >= -AngleB) {
            real = real - 1;
        }
        
        if (real <= -AngleB) {
            up = true;
        }
    }
}

var wep2tab = {
    "usp s": "USP",
    "glock 18": "Glock",
    "dual berettas": "Dualies",
    "r8 revolver": "Revolver",
    "desert eagle": "Deagle",
    "p250": "P250",
    "tec 9": "Tec-9",
    "mp9": "MP9",
    "mac 10": "Mac10",
    "pp bizon": "PP-Bizon",
    "ump 45": "UMP45",
    "ak 47": "AK47",
    "sg 553": "SG553",
    "aug": "AUG",
    "m4a1 s": "M4A1-S",
    "m4a4": "M4A4",
    "ssg 08": "SSG08",
    "awp": "AWP",
    "g3sg1": "G3SG1",
    "scar 20": "SCAR20",
    "xm1014": "XM1014",
    "mag 7": "MAG7",
    "m249": "M249",
    "negev": "Negev",
    "p2000": "General",
    "famas": "FAMAS",
    "five seven": "Five Seven",
    "mp7": "MP7",
    "ump 45": "UMP45",
    "p90": "P90",
    "cz75 auto": "CZ-75",
    "mp5 sd": "MP5",
    "galil ar": "GALIL",
    "sawed off": "Sawed off"
};

var tab_names = ["General", "USP", "Glock", "Five Seven", "Tec-9", "Deagle", "Revolver", "Dualies", "P250", "CZ-75", "Mac10", "P90", "MP5", "MP7", "MP9", "UMP45", "PP-Bizon", "M4A1-S", "M4A4", "AK47", "AUG", "SG553", "FAMAS", "GALIL", "AWP", "SSG08", "SCAR20", "G3SG1", "M249", "XM1014", "MAG7", "Negev", "Sawed off"];

//Indicators

const modules = [
    
    {
        ref: ["Rage", "Target", "General", "Minimum damage"],
        draw: function (y) {
            var items = (UI.GetValue(["Visuals", "Indicators", "Indicators", "Indicators"]))
                .toString(2)
                .split("")
                .reverse()
                .map(Number);
            const self = modules[2];
            weapon_name = Entity.GetName(Entity.GetWeapon(Entity.GetLocalPlayer()))            
            var tab = wep2tab[Entity.GetName(Entity.GetWeapon(Entity.GetLocalPlayer()))];
            
            if (tab == undefined) {
                tab = "General";
            }
            
            
            const overridingdamage = UI.GetValue(["Rage", "General", "General", "Key assignment", "Minimum damage override"])

            if ((overridingdamage) == 1) {
                var dmg = UI.GetValue(["Rage", "Aimbot", "Aimbot", "Minimum damage override"]);
            } else {
                var dmg = UI.GetValue(["Rage", "Target", tab, "Minimum damage"]);
            }
                            
            if (items[1]) {
                Render.GradientSkeet(9, y + 4, 100, 30, 1, [0, 0, 0, 55], [0, 0, 0, 0]);
                if (!UI.GetValue(["Rage", "General", "General", "Key assignment", "Minimum damage override"]) == 1)
                return;

                if (dmg > 100) {
                    var hp_text = "HP + " + (dmg-100).toString()
                    Render.String(18, y + 2, 0, hp_text, [17, 17, 17, 255], fontindicators);
                    Render.String(18, y, 0, hp_text, [255, 255, 255, 170], fontindicators);
                } else if (dmg == 0) {
                    Render.String(18, y + 2, 0, "DYNAMIC", [17, 17, 17, 255], fontindicators);
                    Render.String(18, y, 0, "DYNAMIC", [255, 255, 255, 170], fontindicators);
                } else {
                    Render.String(18, y + 2, 0, dmg.toString(), [17, 17, 17, 255], fontindicators);
                    Render.String(18, y, 0, dmg.toString(), [255, 255, 255, 170], fontindicators);
                }
                drawn++;
            }
        }
    },

    {
        ref: ["Rage", "Target", "General", "Minimum damage"],
        draw: function (y) {
            var items = (UI.GetValue(["Visuals", "Indicators", "Indicators", "Indicators"]))
                .toString(2)
                .split("")
                .reverse()
                .map(Number);
            
            const real = Local.GetRealYaw(),
                fake = Local.GetFakeYaw();
            const delta = Math.abs(normalize_yaw(real % 360 - fake % 360)) / 2;
            var abs = Math.abs(delta);
            const color = [
                186 + (154 - 186) * delta / 60
                , 0 + (205 - 0) * delta / 60
                , 16 + (50 - 16) * delta / 60
                , 255
            ];
            
            if (items[0]) {
                /*var indicatorssize = UI.GetValue(["Visuals", "Indicators", "Indicators", "Indicators size"])
                indicatorssize = indicatorssize == 0 && 26 || indicatorssize == 1 && 31 || indicatorssize == 2 && 36;
                var fontindicators = Render.AddFont("Calibrib", indicatorssize, 700)*/

                Render.GradientSkeet(9, y + 4, 100, 30, 1, [0, 0, 0, 55], [0, 0, 0, 0]);
                Render.String(18, y + 2, 0, "FAKE", [17, 17, 17, 255], fontindicators);
                Render.String(18, y, 0, "FAKE", color, fontindicators);

                drawn++;
            }
        },
    },

    {
        draw: function (y) {
            const self = modules[0];
            var items = (UI.GetValue(["Visuals", "Indicators", "Indicators", "Indicators"])).toString(2).split("").reverse().map(Number);
            
            weapon_name = Entity.GetName(Entity.GetWeapon(Entity.GetLocalPlayer()))            
            var tab = wep2tab[Entity.GetName(Entity.GetWeapon(Entity.GetLocalPlayer()))];
            
            if (tab == undefined) {
                tab = "General";
            }
            
            var fov = UI.GetValue(["Rage", "Target", tab, "Field of view"]);
             
            /*var indicatorssize = UI.GetValue(["Visuals", "Indicators", "Indicators", "Indicators size"])
            indicatorssize2 = indicatorssize == 0 && 26 || indicatorssize == 1 && 31 || indicatorssize == 2 && 36;
            var fontindicators = Render.AddFont("Calibrib", indicatorssize2, 700)*/
            
            if (items[2]) {
                Render.GradientSkeet(9, y + 4, 100, 30, 1, [0, 0, 0, 55], [0, 0, 0, 0]);
                Render.String(18, y + 2, 0, "FOV: " + fov, [17, 17, 17, 255], fontindicators);
                Render.String(18, y, 0, "FOV: " + fov, [102, 212, 255, 225], fontindicators);
                drawn++;
            }
        }
    },

    {
        ref: ["Rage", "GENERAL", "General", "Enabled"],
        draw: function (y) {
            const self = modules[3];
            const color = UI.GetColor(["Visuals", "Indicators", "Indicators", "Indicators color"])

            if (!UI.GetValue(["Rage", "General", "General", "Key assignment", "Ragebot activation"]))
                return;
            
            var items = (UI.GetValue(["Visuals", "Indicators", "Indicators", "Indicators"])).toString(2).split("").reverse().map(Number);
            
            
            if (items[3]) {
                Render.GradientSkeet(9, y + 4, 100, 30, 1, [0, 0, 0, 55], [0, 0, 0, 0]);
                Render.String(18, y + 2, 0, "TM", [17, 17, 17, 255], fontindicators);
                Render.String(18, y, 0, "TM", [255, 255, 255, 255], fontindicators);
               
                drawn++;
            }
        },
    },
    
    { 
        ref: ["Rage", "GENERAL", "General", "Enabled"],
        draw: function (y) {
            const self = modules[3];
            const color = UI.GetColor(["Visuals", "Indicators", "Indicators", "Indicators color"])
             

            if (!UI.GetValue(["Rage", "General", "General", "Key assignment", "Autowall key"]) == 1)
                return;
            var text_width = Render.TextSize("TM", 4)[0];
            
            var items = (UI.GetValue(["Visuals", "Indicators", "Indicators", "Indicators"])).toString(2).split("").reverse().map(Number);
            
            
            if (items[4]) {
                Render.GradientSkeet(9, y + 4, 100, 30, 1, [0, 0, 0, 55], [0, 0, 0, 0]);
                Render.String(18, y + 2, 0, "AW", [17, 17, 17, 255], fontindicators);
                Render.String(18, y, 0, "AW", color, fontindicators);
                
                drawn++;
            }
        },
        
    },

    {
        ref: ["Rage", "GENERAL", "Force safe point"],
        draw: function (y) {
            const self = modules[3];
            const color = UI.GetColor(["Visuals", "Indicators", "Indicators", "Indicators color"])
            if (!UI.GetValue(["Rage", "General", "General", "Key assignment", "Force body aim"]) == 1)
                return;
            var text_width = Render.TextSize("FAKE", 4)[0];
            
            var items = (UI.GetValue(["Visuals", "Indicators", "Indicators", "Indicators"])).toString(2).split("").reverse().map(Number);

            if (items[5]) {
                Render.GradientSkeet(9, y + 4, 100, 30, 1, [0, 0, 0, 55], [0, 0, 0, 0]);
                Render.String(18, y + 2, 0, "BAIM", [17, 17, 17, 255], fontindicators);
                Render.String(18, y, 0, "BAIM", color, fontindicators);
                
                drawn++;
            }
        },
        
    },

    {
        ref: ["Rage", "GENERAL", "Force safe point"],
        draw: function (y) {
            const self = modules[3];
            const color = UI.GetColor(["Visuals", "Indicators", "Indicators", "Indicators color"])
            if (!UI.GetValue(["Rage", "General", "General", "Key assignment", "Fake duck"]) == 1)
                return;

            var text_width = Render.TextSize("FAKE", 4)[0];
            
            var items = (UI.GetValue(["Visuals", "Indicators", "Indicators", "Indicators"])).toString(2).split("").reverse().map(Number);

            if (items[6]) {
                Render.GradientSkeet(9, y + 4, 100, 30, 1, [0, 0, 0, 55], [0, 0, 0, 0]);
                Render.String(18, y + 2, 0, "DUCK", [17, 17, 17, 255], fontindicators);
                Render.String(18, y, 0, "DUCK", [255, 255, 255, 200], fontindicators);
                drawn++;
            }
        },
        
    },

    {
        ref: ["Rage", "GENERAL", "Force safe point"],
        draw: function (y) {
            const self = modules[3];
            const color = UI.GetColor(["Visuals", "Indicators", "Indicators", "Indicators color"])

            if (!UI.GetValue(["Rage", "General", "General", "Key assignment", "Resolver override"]) == 1)
                return;

            var text_width = Render.TextSize("FAKE", 4)[0];
            
            var items = (UI.GetValue(["Visuals", "Indicators", "Indicators", "Indicators"])).toString(2).split("").reverse().map(Number);
            if (items[7]) {
                Render.GradientSkeet(9, y + 4, 100, 30, 1, [0, 0, 0, 55], [0, 0, 0, 0]);
                Render.String(18, y + 2, 0, "R: ON", [17, 17, 17, 255], fontindicators);
                Render.String(18, y, 0, "R: ON", [154, 205, 50, 255], fontindicators);
                
                drawn++;
            }
            
        },
        
    },

    {
        ref: ["Rage", "GENERAL", "Force safe point"],
        draw: function (y) {
            const self = modules[3];
            const color = UI.GetColor(["Visuals", "Indicators", "Indicators", "Indicators color"])

            if (!UI.GetValue(["Rage", "General", "General", "Key assignment", "Resolver override"]) == 0)
                return;

            var text_width = Render.TextSize("FAKE", 4)[0];
            
            var items = (UI.GetValue(["Visuals", "Indicators", "Indicators", "Indicators"])).toString(2).split("").reverse().map(Number);
            if (items[7]) {
                Render.GradientSkeet(9, y + 4, 100, 30, 1, [0, 0, 0, 55], [0, 0, 0, 0]);
                Render.String(18, y + 2, 0, "R: OFF", [17, 17, 17, 255], fontindicators);
                Render.String(18, y, 0, "R: OFF", [154, 205, 50, 255], fontindicators);
                
                drawn++;
            }
        },  
    },
]

const do_indicators = function () {
    
    localplayer_index = Entity.GetLocalPlayer();
    localplayer_alive = Entity.IsAlive(localplayer_index);
    if (localplayer_alive == true)
        if (UI.GetValue(["Visuals", "Indicators", "Indicators", "Autowall indicator under crosshair"]) == 1)
            if (UI.GetValue(["Rage", "General", "General", "Key assignment", "Autowall key"]) == 1) {
                screen = screen_size;
                x = screen[0] / 2
                y2 = screen[1] / 2
                const Verdanab = Render.GetFont("Verdanab.ttf", 12, true);
                Render.String(x - 35, y2 + 17, 0, "AUTOWALL", [255, 255, 255, 255], Verdanab); 
            }
    if (!Entity.IsAlive(Entity.GetLocalPlayer()))
        return;
    
    const offset = UI.GetValue(["Visuals", "Indicators", "Indicators", "Indicators Y offset"]);
    
    drawn = 0;
    
    var indicatorssize = UI.GetValue(["Visuals", "Indicators", "Indicators", "Indicators size"])
    var indicators = indicatorssize == 0 && 35 || indicatorssize == 1 && 37 || indicatorssize == 2 && 43;

    var indicatorssizee = UI.GetValue(["Visuals", "Indicators", "Indicators", "Indicators size"])
    indicatorssizee = indicatorssizee == 0 && 26 || indicatorssizee == 1 && 31 || indicatorssizee == 2 && 36;
    fontindicators = Render.GetFont("Calibrib.ttf", indicatorssizee, true);
    for (var i = 0; i < modules.length; i++) {
        const mod = modules[i];
        
        mod.draw(screen_size[1] - offset + drawn * indicators);
    }
}

//Autowall
function allauto() {
    var enable = UI.GetValue(["Rage", "General", "General", "Key assignment", "Autowall key"]);
    
    weapon_name = Entity.GetName(Entity.GetWeapon(Entity.GetLocalPlayer()))
    
    var tab = wep2tab[Entity.GetName(Entity.GetWeapon(Entity.GetLocalPlayer()))];
    
    tab = tab || 'General';

    var edge_awall_on = enemy_vis(get_closest_target());

    if(UI.GetValue(["Rage", "Aimbot", "Aimbot", "Legit Autowall"]) && edge_awall_on) {
        enable = true;
    }

    if (enable == 0)
        UI.SetValue(["Rage", "Target", tab, "Disable autowall"], 1);
    else
        UI.SetValue(["Rage", "Target", tab, "Disable autowall"], 0);
}

function betterTargeting() {
    closest = get_closest_target();
    target = Ragebot.GetTarget();
    if (closest == null) return;
    if (target != closest) {
        Ragebot.ForceTarget(closest);
    }
}

//Function hitlogs
var logs = [];
var logsct = [];
var logsalpha = [];
var shots = 0;

//Hitlogs main

hitboxes = ['generic', 'head', 'chest', 'stomach', 'left arm', 'right arm', 'left leg', 'right leg', '?'];

function hurt() {
        var items = (UI.GetValue(["Visuals", "Helpers", "Helpers", "Hit logs"])).toString(2).split("").reverse().map(Number);
        var attacker = Event.GetInt("attacker");
        var player = Entity.GetEntityFromUserID(Event.GetInt("userid"));
        var weapon = Event.GetString("weapon");
        var health = Event.GetInt("dmg_health");
        var hitbox = Event.GetString("hitgroup");
        var hp = Event.GetInt("health");
        var name = Entity.GetName(player);
        var bone = hitboxes[hitbox] || 'body';
    
        if (Entity.IsLocalPlayer(Entity.GetEntityFromUserID(attacker))) {
            if (items[0])  {
            Cheat.PrintColor([89, 119, 239, 255], '[finlandhook] ')
            Cheat.PrintColor([255, 255, 255, 255], 'Hit ' + name + ' in the ' + bone + ' for ' + health + ' damage' + ' (' + hp + ' health remaining)\n')
            logs.push('Hit ' + name + ' in the ' + bone + ' for ' + health + ' damage' + ' (' + hp + ' health remaining)');
            logsct.push(Globals.Curtime());
            logsalpha.push(255);
        }

        if (items[1]) {
            Cheat.PrintChat(" \x0c[\x0cfinlandhook\x0c]\x08 Hit " + name +  " in the " + bone + " for " + health + " damage" + " (" + hp + " health remaining)\n")
        }
    }
}

function removelogs() {
    if (logs.length > 10) {
        logs.shift();
        logsct.shift();
        logsalpha.shift();
    }

    if (logsct[0] + 6.5 < Globals.Curtime()) {
        logsalpha[0] -= Globals.Frametime() * 600;
        if (logsalpha[0] < 0) {
            logs.shift();
            logsct.shift();
            logsalpha.shift();
        }
    }
}

function onDraw() {
    if (!World.GetServerString()) return;
    
    var consola = Render.GetFont("consola.ttf", 12, true);

    for (i = 0; i < logs.length; i++) {
        Render.String(4, 9 + 13 * i, 0, logs[i], [0, 0, 0, logsalpha[i]], consola);
        Render.String(3, 8 + 13 * i, 0, logs[i], [255, 255, 255, logsalpha[i]], consola);
    }
}
//Function Damage override
function pew() {
    if (UI.GetValue(["Rage", "General", "General", "Key assignment", "Minimum damage override"])) {
        var tab = wep2tab[Entity.GetName(Entity.GetWeapon(Entity.GetLocalPlayer()))] || "General";
        var override = UI.GetValue(["Rage", "Aimbot", "Aimbot", "Minimum damage override"]);
        if (override == 0 && tab != "General") {
            override = UI.GetValue(["Rage", "Aimbot", "Aimbot", "Minimum damage override"])
        }
        var en = Entity.GetEnemies();
        for (i = 0; i < en.length; i++) {
            Ragebot.ForceTargetMinimumDamage(en[i], override);
        }
    }
}

function antiaimarrows() {
    var arrowx = UI.GetValue(["Visuals", "Indicators", "Indicators", "Arrows X offset"])
    const real = Local.GetRealYaw(),
    fake = Local.GetFakeYaw();
    const delta = Math.abs(normalize_yaw(real % 360 - fake % 360)) / 2;
    var arial = Render.GetFont("Arial.ttf", 28, true);
    var musesosan = Render.GetFont("MUSEOSANSCYRL_0.OTF", 28, true);
    var acta_symbools = Render.GetFont("Acta_Symbols_W95_Arrows.ttf", 20, true);

    var lp = Entity.GetLocalPlayer();
    var is_alive = Entity.IsAlive(lp);

    if (!lp || !is_alive) return;

    var arrowcolor = [];
    if (UI.GetValue(["Visuals", "Indicators", "Indicators", "Arrows fake color"]))
        arrowcolor = [
            186 + (154 - 186) * delta / 60
            , 0 + (205 - 0) * delta / 60
            , 16 + (50 - 16) * delta / 60
            , 255
        ];
    else
        arrowcolor = UI.GetColor(["Visuals", "Indicators", "Indicators", "Arrows color"]);

    var arrow_type = UI.GetValue(["Visuals", "Indicators", "Indicators", "Antiaim arrow type"])

    var is_inverted = UI.GetValue(["Rage", "Anti Aim", "General", "Key assignment", "AA Direction inverter"])

    if (arrow_type == 1) {
        var Px = is_inverted && [(screen_size[0] / 2) - 25 - arrowx, (screen_size[1] / 2) + 7] || [(screen_size[0] / 2) + 25 + arrowx, (screen_size[1] / 2) + 7];
        var Py = is_inverted && [(screen_size[0] / 2) - 25 - arrowx, (screen_size[1] / 2) - 7] || [(screen_size[0] / 2) + 25 + arrowx, (screen_size[1] / 2) - 7];
        var Pz = is_inverted && [(screen_size[0] / 2) - 37 - arrowx, (screen_size[1] / 2)] || [(screen_size[0] / 2) + 37 + arrowx, (screen_size[1] / 2)];
        if (is_inverted) {
            Render.Polygon([[Px[0] + 1, Px[1] + 1], [Pz[0] + 1, Pz[1] + 1], [Py[0] + 1, Py[1] + 1]], [0, 0, 0, 100]);
            Render.Polygon([Px, Pz, Py], [100, 100, 100, 200]);
            Render.Polygon([Px, Pz, Py], arrowcolor);
        } else {
            Render.Polygon([[Py[0] + 1, Py[1] + 1], [Pz[0] + 1, Pz[1] + 1], [Px[0] + 1, Px[1] + 1]], [0, 0, 0, 100])
            Render.Polygon([Py, Pz, Px], [100, 100, 100, 200])
            Render.Polygon([Py, Pz, Px], arrowcolor)
        }
        
    } else if (arrow_type == 2) {
        Render.String(screen_size[0] / 2 - arrowx + 7 - 1, screen_size[1] / 2 - 19, 1, "-", [17, 17, 17, 255], arial);
        Render.String(screen_size[0] / 2 - arrowx - 1, screen_size[1] / 2 - 19, 1, "-", [17, 17, 17, 255], arial); 
        Render.String(screen_size[0] / 2 - arrowx + 7, screen_size[1] / 2 - 19 + 1, 1, "-", [17, 17, 17, 255], arial);
        Render.String(screen_size[0] / 2 - arrowx, screen_size[1] / 2 - 19 + 1, 1, "-", [17, 17, 17, 255], arial); 
        Render.String(screen_size[0] / 2 - arrowx + 7, screen_size[1] / 2 - 19 - 1, 1, "-", [17, 17, 17, 255], arial);
        Render.String(screen_size[0] / 2 - arrowx, screen_size[1] / 2 - 19 - 1, 1, "-", [17, 17, 17, 255], arial);
        Render.String(screen_size[0] / 2 - arrowx + 14, screen_size[1] / 2 - 19 - 1, 1, "-", [17, 17, 17, 255], arial);
        Render.String(screen_size[0] / 2 - arrowx + 14, screen_size[1] / 2 - 19 + 1, 1, "-", [17, 17, 17, 255], arial);
        Render.String(screen_size[0] / 2 - arrowx + 14 - 1, screen_size[1] / 2 - 19, 1, "-", [17, 17, 17, 255], arial);
        Render.String(screen_size[0] / 2 - arrowx + 14, screen_size[1] / 2 - 19, 1, "-", arrowcolor, arial);
        Render.String(screen_size[0] / 2 - arrowx + 7, screen_size[1] / 2 - 19, 1, "-", arrowcolor, arial);
        Render.String(screen_size[0] / 2 - arrowx, screen_size[1] / 2 - 19, 1, "-", arrowcolor, arial);
    } else if (arrow_type == 3) {
        Render.String(screen_size[0] / 2 - ( is_inverted && arrowx || -arrowx ) - 1, screen_size[1] / 2 - 19, 1, is_inverted && "<" || ">", [17, 17, 17, 255], musesosan);
        Render.String(screen_size[0] / 2 - ( is_inverted && arrowx || -arrowx ) + 1, screen_size[1] / 2 - 19, 1, is_inverted && "<" || ">", [17, 17, 17, 255], musesosan);
        Render.String(screen_size[0] / 2 - ( is_inverted && arrowx || -arrowx ), screen_size[1] / 2 - 19 - 1, 1, is_inverted && "<" || ">", [17, 17, 17, 255], musesosan);
        Render.String(screen_size[0] / 2 - ( is_inverted && arrowx || -arrowx ), screen_size[1] / 2 - 19 + 1, 1, is_inverted && "<" || ">", [17, 17, 17, 255], musesosan);
        Render.String(screen_size[0] / 2 - ( is_inverted && arrowx || -arrowx ), screen_size[1] / 2 - 19, 1, is_inverted && "<" || ">", arrowcolor, musesosan);
    } else if (arrow_type == 4) {
        Render.String(screen_size[0] / 2 - (is_inverted && arrowx || -arrowx), screen_size[1] / 2 - 9, 1, is_inverted && "g" || "h", [255,255,255,50], acta_symbools);
        Render.String(screen_size[0] / 2 - (is_inverted && arrowx || -arrowx), screen_size[1] / 2 - 9, 1, is_inverted && "g" || "h", arrowcolor, acta_symbools);
    } else if (arrow_type == 5) {
        Render.String(screen_size[0] / 2 - (is_inverted && arrowx || -arrowx), screen_size[1] / 2 - 9, 1, is_inverted && "w" || "x", [255,255,255,50], acta_symbools);
        Render.String(screen_size[0] / 2 - (is_inverted && arrowx || -arrowx), screen_size[1] / 2 - 9, 1, is_inverted && "w" || "x", arrowcolor, acta_symbools);
    }
}

function FINLANDFOV() {    
    distance = 0;
    FOV = UI.GetValue(["Rage", "Aimbot", "Aimbot", "Min fov"]);
    enemies = Entity.GetEnemies();
    for (i = 0; i < enemies.length; i++) {
        if (Entity.IsAlive(enemies[i]) && !Entity.IsDormant(enemies[i])) {
            origin = Entity.GetRenderOrigin(enemies[i]);
            myself = Entity.GetRenderOrigin(Entity.GetLocalPlayer());
            distance_to_enemy = Math.sqrt(Math.pow(origin[0] - myself[0], 2) + Math.pow(origin[1] - myself[1], 2) + Math.pow(origin[2] - myself[2], 2));
            if (distance == 0 || distance_to_enemy < distance) {
                distance = distance_to_enemy;
            }
        }
    }
    diff = 1000 - distance;
    if (diff > 0) {
        FOV += (UI.GetValue(["Rage", "Aimbot", "Aimbot", "Max fov"]) - UI.GetValue(["Rage", "Aimbot", "Aimbot", "Min fov"])) * (diff / 1000);
    }
    FOV = Math.ceil(FOV);
    var tab = wep2tab[Entity.GetName(Entity.GetWeapon(Entity.GetLocalPlayer()))];
    if (tab == undefined) {
        tab = "General";
    }
    UI.SetValue(["Rage", "Target", tab, "Field of view"], FOV);
}

function onUnload() {
    Global.SetClanTag(" ");
    AntiAim.SetOverride(0);
}
Cheat.RegisterCallback("CreateMove", "FINLANDFOV");
Cheat.RegisterCallback("CreateMove", "legs");
Cheat.RegisterCallback("CreateMove", "smokecheck");
Global.RegisterCallback("CreateMove", "betterTargeting");;
Global.RegisterCallback("Draw", "do_indicators");
Global.RegisterCallback("CreateMove", "allauto");
Global.RegisterCallback("CreateMove", "pew");
Global.RegisterCallback("CreateMove", "Security");
Global.RegisterCallback("Draw", "menuoptions")
Global.RegisterCallback("CreateMove", "menuoptions")
Cheat.RegisterCallback("Draw", "antiaimarrows");
Cheat.RegisterCallback("Draw", "finlandaa");
Cheat.RegisterCallback("CreateMove", "finlandaa");
Cheat.RegisterCallback("CreateMove", "realsway");
Cheat.RegisterCallback("CreateMove", "fakesway");
Cheat.RegisterCallback("CreateMove", "on_tick");
Cheat.RegisterCallback("player_hurt", "on_player_hurt")
Cheat.RegisterCallback("Unload", "onUnload");
Global.RegisterCallback("Draw","spec1");
Global.RegisterCallback("Draw","spec2");
Global.RegisterCallback("round_start","spec3");
Cheat.RegisterCallback("item_purchase", "BuyLogs");
Cheat.RegisterCallback("player_death", "on_player_death");
Cheat.RegisterCallback("FrameStageNotify", "aspectratio" );
Cheat.RegisterCallback("Draw", "clantag");
Global.RegisterCallback("Draw", "onDraw");
Cheat.RegisterCallback("player_hurt", "hurt");
Global.RegisterCallback("Draw", "removelogs");
Cheat.RegisterCallback("CreateMove", "FakeDuck");

Cheat.PrintColor([0, 111, 255, 1], "-----------------------------\n");
Cheat.PrintColor([0, 111, 255, 1], "Welcome!");
Cheat.PrintColor([0, 111, 255, 1], " Lua date: ");
Cheat.PrintColor([0, 111, 255, 1], "31.01.21\n");
Cheat.PrintColor([0, 111, 255, 1], "Any questions?");
Cheat.PrintColor([0, 111, 255, 1], "halo1337#6867\n");
Cheat.PrintColor([0, 111, 255, 1], "-----------------------------\n"); 
Cheat.PrintChat(" \x0c[\x0cfinlandhook\x0c]\x08 ready to use!");