Render.AddFont = function(name, size, _) {
  if (name.indexOf('.ttf') === -1) name = name + '.ttf';

  return Render.GetFont(name, size, true);
}

var GetUsername_0x430a = ["pxaiu", "                      ", "3Jlou_ЗAdrOT", "Watermark", "Fake amout:", " on ", "assaultsuit", "Mac10", "Key assignment", "cleans?", "nestz", "AUG", "Arrows X offset", "Bekri", "TextSize", "nneoward", "toString", "player_death", "onPlayerHurt", "vzOfT", "SCRIPT LEAKS ARE NOT ALLOWED", "Clantag spammer", "GetFakeYaw", "CBasePlayer", "Tec-9", "zkbWt", "vote_options", "Hit ", "sin", "uid police here present your user identification number right now", "Fake type", "SCAR20", "phRVn", "m_hObserverTarget", "Peek with fake", "Config", "kacper000", "pelvis", "GetWeapon", "health", "AUTOWALL", "tsNRq", "uunzP", "BgGwK", "LaGGeRFeeD_2015", "angles", "option5", "Revolver", "Fille133706", "w0wfoke", "pow", "IsValid", "YBtHq", "substring", "Main", "aMTxG", "m_vecVelocity[0]", "GYIEU", "P90", "HKEBD", "Tickcount", "reverse", "бля я рядом только прошел а ты уже упал АУУ НИЩ С ТОБОЙ ВСЕ ХОРОШО??????????))))))", "right thigh", "hitbox", "hrrnr", "Custom angle", "floor", "Rage", "iQBQs", "menuoptions", "CCSPlayer", "upper chest", "GENERAL", "right forearm", "ZEgFw", "[UNK] ", "item_", "apply", " health remaining", "MP9", "on_frame", "Resolver override", "fov_to", "---  homo ---", "Legit", "SetOverride", "IsLocalPlayer", "chest", "♥ДеВо4кА-СкАнДаЛ♥", "4ekHyTbIu*", "Arc", "IsDormant", "SSG08", "lucynka", "AddColorPicker", "iVSWr", "ZxDzP", "zArwG", "с тобой там все хорошо????????????? а да ты нищ нахуя я спрашиваю ПХАХАХАХАХХА", "ExecuteCommand", "VOluW", "pVLmC", "TickInterval", "must be an uid issue", "xVgnq", "AHHAHAHHAHAHH LIFEHACK BITCH", "random", "Misc.", "£ნÿ ϯя", "рублю с плеча", "left upper arm", "vote_option", "Uemmv", "8=====[Hedshot beath]==D", "^^Stell^^::.[Pro_Game_Xom9k]", "pSjQz", "operate", "moNaS", "GetScreenSize", "weapon", "__proto__", "antiaimarrows", "kaZAH", "MP7", "UMP45", "Unload", "Current version: 2.24", "constructor", "PArNh", "Animation fucker", "M249", "Curtime", "GetInt", "newaa", "freeqn.net/refund.php", "cWKpR", "QMWIc", "Minimal fov", "Smart peek", "another retard blasted", "iUofu", "AK47", "right upper arm", "MEQTK", "miht", "headshot", "fakesway", "iddypo", "player_hurt", "ragebot_fire", "reset_tick", "UBvTt", "Cheat", "last_hit_lby", "Verdana", "Arial.ttf", " voted ", "SetValue", "Field of view", "MaJIeHkuu_Ho_OnacHekuu", "Marctilo", "sightseeing", "Draw", "SUBTAB_MGR", "Autowall key", "ghvtg", "ñƤüβ£ϯ ΨнӹƤь ϯ£ნя £ნ£ϯ j£§ɥ§", "spectators", "option4", "RegisterCallback", "†Я не айс,курите спайс†", "GetProp", "☾NA ZAP9STIE AIC☾", "я ķ¤нɥåλ ϯβ¤£ü ɱåɱķ£ β Ƥ¤ϯ", "ⒶaŴÞ ︻デ═一 -™", "unknown", "Hit logs", "ypfCj", "але я бот_кик в консоль вроде прописал а вас там не кикнуло эт че баг??)))))))))", "right calf", "slot3", "VAAAAAAAC в чат!!! (づ ◕‿◕ )づ", "return (function() ", "OkMaX", "Minimum damage override", "BuyLogs", "Dualies", "Loading best cfg… ███████[][][] 77% #pizdavam", "ssg 08", "god i wish i had homo", "prototype", "Yaw offset", "BZukg", "pew", "Indicators Y offset", "replace", "ihwRs", "imad1532", "sCuRR", "GetEntityFromUserID", "ceoLP", "Force safe point", "table", "Watermark gradient", "katsutest1", "[N] ", "Medved", " bought \b", "2.24\n", "PP-Bizon", "жаль конечно что против нищей играть надо)))", "+Yeb@shu_v_k@shu+", "ViP_ПуЛи_ОТ_ДеДюЛи", "GetServerString", "AWP", "*DEAD*", "indexOf", "wcalk", "DnyDj", "aHMIR", "SetLBYOffset", "Peek with real", "GetRealYaw", "attacker", "m_iTeamNum", "RESOLVER", "Теперь я - Ютубер Омлет (◣◢)", "XoPSB", "GetRenderOrigin", "AddDropdown", "paster abandoned the match and received a 7 day competitive matchmaking cooldown", "console", "goodfeelings", "Vote revealer", "mot1on", "Arrows fake color", "IsKeyPressed", "kyayq", "feeji", "Deagle", "MINDMG", "AddHotkey", "XvuKs", "player_connect_full", "on_weapon_fire", "MP5", "Теперь я - Stewie2k (◣◢)", "Restrictions", "TotalxsjTriginitillion", "pofa", "Negev", "--- homo ---", "Latency", "Random", "voted ", "FAMAS", "SetFakeOffset", "G3SG1", "onRagebotFire", "entityid", "ZgGuL", "right", "ForceTargetMinimumDamage", "ļăȟ țųρőý", "SetClanTag", "Indicators color", "iTzAnotherGamer", "Legendhvh1337", "Fabinger", "allauto", "Target", "weapon_fire", " \b[homo] \b", "rmTyG", "ПаРеНь БеЗ сТрАхА", "off", "Misc", "GetEnemies", "zanetti", "option2", "GetUsername", "FOVUpdate", "ViccHis", "ETxLv", "Disable autowall", "option3", "do_indicators", "£ნÿ βåç ϯÿñӹ× λå×¤β, ü н£ ɱ¤гÿ ¤çϯåн¤βüϯьçя,", "neck", "nfFmk", "left calf", "watermark", "QyRDH", "GetHitboxPosition", "debilik", "keft forearm", "Kaito", "'s ", "Ct ", "˜”*°•.★..Angel_Of_The_Night..★.•°*”˜ ", "fUBlE", "M4A4", "log", "onUnload", "Welcome! ", "PrintColor", "PHZpm", "hyLGC", "Verdanab", "realsway", "ezners", "max", "legs", "ნ¤ççåλ ϯ£ნя ΨнӹƤя", "[homo] \0", "BAIM", "go take some estrogen tranny", "cadiaN", "nlHwW", "Real type", "aSgao", "CBaseEntity", "GetPlayers", " for ", "SetRealOffset", "Line", "onVoteCast", "hbvJv", "P250", "JJDTX", "slot1", "Watermark gradient first color", "imagine the only thing you eat being bullets man being a thirdworlder must suck rofl", "say ", "Fake-Lag", "homo", "Trashtalk", "Slow walk", "betterTargeting", "Enabled", "Js ", "але найс упал нищ ЛОООООООЛ", "ñüѫ¤Ƥ ñüƺѫå ϯÿƺ ɱ¤н¤ȹя", "left", "kpEMc", "TkDhx", "AA Direction inverter", "YбИuЦа_КрИпЕrОв", "FOV: ", "nIcE tRy", "rLuKz", "body", "min", "Jitter offset", "忍び 1 УПАЛ び忍", "GetValue", "Freestanding", "AddSubTab", "AddMultiDropdown", "FOV", "HCoFI", "new", "Qwurn", "awp", "87)*Go0d+LikE*lHacKeR*", "cszrX", "kepso", "String", "Low delta", "Jitter on slowwalk", "warn", "-----------------------------\n", "Print", "userid", '{}.constructor("return this")( )', "bind", "on_player_hurt", "Ragebot activation", "GetLocalPlayer", "LjYzb", "SG553", "HlVYR", "FrNXQ", "split", " damage with ", "ToggleHotkey", "kgbOQ", "SAqZX", "version: ", "•۩۞۩[̲̅П̲̅о̲̅Л̲̅Ю̲̅б̲̅А̲̅С(ٿ)̲̅Ч̲̅и̅Т̲̲̅АК̲̅]۩۞۩•", "NrHce", "m_angEyeAngles", "PuuAr", "Autowall indicator under crosshair", "ForceTarget", "GetColor", "sqrt", "AddCheckbox", "GALIL", "daUum", "SetColor", "thorax", "target_index", "FIX KD NN DOGGO", "Fake circle", "Indicators green color", "Antiaim arrow type", "CZ-75", "on_player_death", "head", "Minimum damage", "homo is your choice", "NzTgG", "Watermark text color", "Off", "GetEyePosition", "ralqx", "Quick switch", "on_tick", "yXRAj", "slice", "onVoteOptions", "vector", "hitgroup", "Eye yaw based", "DOoQz", "Real amout:", "molotov", "GetTarget", "NnIPE", "CreateMove", "Buy logs", "error", "Five Seven", "AddSliderInt", "USP", "trikX", "Visuals", "GqReu", "uFbbO", "JdETN", "SHEET_MGR", "Jitter move", " \b[homo] ", "length2d", "team", "ahhahaha, suck noob (????)? .!.", "retard blasted", "incgrenade", "UCJge", "push", "Anti-Aim", "left thigh", "Directions", "atan2", "Any questions? motion#3773\n", "laigq", "length", " \b[homo] ", "draw", "hzPkk", "PduLl", "Aop", "FAKE", "Н.Е.С.О.К.Р.У.Ш.И.М.Ы.Й", "XM1014", "ulqND", "Sway", "KFuPI", "kxTOY", "Movement", "XfAgb", "Glock", "trace", "left hand", "GetName", "Welcome to homo, ", "[Vector] Invalid operation type.", "Indicators", "zszku", "kevlar + helmet", "GetViewAngles", "VAEbm", "exception", "BpTph", "clantag", "AddFont", "THIS IS OMLEEEEEEET (◣◢)", "dmg_health", "ęβãł țýä √ řøţ", "Maximum fov", "ᗰEᗰE ᔕEᑎᔕE", "xTnEV", "null", "map", "vote_cast", "spectators (", "function () { [native code] }", "Ghosed", "Fake Lag", "从闩从长丫 仨五闩人", "pDqwZ", "Pitch mode", "lJcyn", "               ", "item_purchase", "KpyToI_4elOBeK", "pyhnT", "Force body aim", "GetString", "Sawed off", "to_array", "ПуЛи_От_БаБуЛи", "General", "abs", "test", "ебать тя расплющило жирнич", "weapon_", "ceil", "Polygon", "fov", "MAG7", "m_fFlags", "Arrows color", "OSBgB", "jqaBX", "Watermark gradient second color", "IsAlive", "ⒶaŴÞ ︻デ═一 PUTIN", "cos", "Anti Aim", "Freestanding mode", "epNeu", "djZYz", "dbzTl", "reset", "info", "Beni5679", "pJHXC", "right foot", "xallkhan", "option1", "GradientRect", "Spectators list", "left foot", "zitxchii", "WQQoU", "M4A1-S", "XSlaF", "Slide walk", "ksandr", "Anti-aims", "right hand", "PrintChat"];
! function (_0x8f7f35, _0x430a0a) {
    ! function (_0x24fd5a) {
        for (; --_0x24fd5a;) _0x8f7f35.push(_0x8f7f35.shift())
    }(++_0x430a0a)
}(GetUsername_0x430a, 450);
var GetUsername_0x4358 = function (_0x8f7f35, _0x430a0a) {
        return GetUsername_0x430a[_0x8f7f35 -= 0]
    },
    _0x436670 = function (_0x400957, _0x22cadf) {
        return GetUsername_0x4358(_0x400957 - "0xbf", _0x22cadf)
    },
    GetUsername_0x2da8c5 = function () {
        var _0x2bc558 = !0;
        return function (_0x589f4f, _0x28a591) {
            var _0x4ba0e3 = function (_0x380471, _0x38aa1a) {
                return GetUsername_0x4358(_0x380471 - -853, _0x38aa1a)
            };
            if (_0x4ba0e3(-427) !== _0x4ba0e3(-403)) {
                var _0x3f9a1e = _0x2bc558 ? function () {
                    var _0x3f30c8 = function (_0x46d7a5, _0x282002) {
                        return _0x4ba0e3(_0x46d7a5 - -955, _0x282002)
                    };
                    if (_0x3f30c8(-1559) == _0x3f30c8(-1559)) {
                        if (_0x28a591) {
                            if (_0x3f30c8(-1590) == _0x3f30c8(-1590)) {
                                var _0x39cee8 = _0x28a591[_0x3f30c8(-1625)](_0x589f4f, arguments);
                                return _0x28a591 = null, _0x39cee8
                            }
                        }
                    } else;
                } : function () {};
                return _0x2bc558 = !1, _0x3f9a1e
            }
        }
    }(),
    GetUsername_0x415c13 = GetUsername_0x2da8c5(this, (function () {
        for (var _0x1b3305 = function (_0x4ce825, _0x1c168d) {
                return GetUsername_0x4358(_0x4ce825 - -953, _0x1c168d)
            }, _0x385b22 = function () {
                var _0x3e579, _0x9a15a = function (_0x825f3c, _0x3d9084) {
                    return GetUsername_0x4358(_0x825f3c - -75, _0x3d9084)
                };
                try {
                    if (_0x9a15a("0x178") === _0x9a15a("0xe"));
                    else _0x3e579 = Function(_0x9a15a("0xd5") + _0x9a15a("0x195") + ");")()
                } catch (_0x41ee7e) {
                    if (_0x9a15a("0x1a7") == _0x9a15a("0x1a7")) _0x3e579 = window;
                    else;
                }
                return _0x3e579
            }(), _0x5af848 = _0x385b22[_0x1b3305(-616)] = _0x385b22[_0x1b3305(-616)] || {}, _0x1789df = [_0x1b3305(-545), _0x1b3305(-477), _0x1b3305(-866), _0x1b3305(-415), _0x1b3305(-919), _0x1b3305(-645), _0x1b3305(-929)], _0xeafe3f = 0; _0xeafe3f < _0x1789df[_0x1b3305(-945)]; _0xeafe3f++)
            if (_0x1b3305(-418) !== _0x1b3305(-823)) {
                var _0x32f2e3 = GetUsername_0x2da8c5[_0x1b3305(-720)][_0x1b3305(-657)][_0x1b3305(-472)](GetUsername_0x2da8c5),
                    _0x1bd617 = _0x1789df[_0xeafe3f],
                    _0x21b8af = _0x5af848[_0x1bd617] || _0x32f2e3;
                _0x32f2e3[_0x1b3305(-727)] = GetUsername_0x2da8c5[_0x1b3305(-472)](GetUsername_0x2da8c5), _0x32f2e3[_0x1b3305(-832)] = _0x21b8af[_0x1b3305(-832)][_0x1b3305(-472)](_0x21b8af), _0x5af848[_0x1bd617] = _0x32f2e3
            } else;
    }));

function menustate() {
    return "function () { [native code] }" != ragebot_safety.toString()
}

function menuoptions() {
    ZGFnZXJ4eWVjb2M = new Array, ZGFnZXJ4eWVjb2M.push(Cheat.GetUsername()), -1 !== ZGFnZXJ4eWVjb2M.indexOf(1 == menustate() || ragebot_safety()) || (UI.AddCheckbox(["Rage", "SUBTAB_MGR", "Main", "SHEET_MGR", "Main"], "nIcE tRy"), UI.AddCheckbox(["Rage", "SUBTAB_MGR", "Anti-aims", "SHEET_MGR", "Anti-aims"], "nIcE tRy"), UI.AddCheckbox(["Misc.", "SUBTAB_MGR", "Misc", "SHEET_MGR", "Misc"], "nIcE tRy"), UI.AddCheckbox(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals"], "nIcE tRy"), Render.String(800, 600, 0, "SCRIPT LEAKS ARE NOT ALLOWED", [255, 255, 255, 255], 24))
}
GetUsername_0x415c13(), ragebot_safety = Cheat.GetUsername, globals_curtime = Globals.Curtime, entity_get_local_player = Entity.GetLocalPlayer, entity_get_enemies = Entity.GetEnemies, entity_get_hitbox_position = Entity.GetHitboxPosition, entity_get_eye_position = Entity.GetEyePosition, entity_is_valid = Entity.IsValid, global_get_view_angles = Global.GetViewAngles, entity_is_alive = Entity.IsAlive, local_get_view_angles = Local.GetViewAngles, entity_get_render_origin = Entity.GetRenderOrigin, trace_line = Trace.Line, entity_get_entity_from_user_i_d = Entity.GetEntityFromUserID, event_get_int = Event.GetInt;
var vector = {
    _class: "vector"
};

function clamp(_0x20d5be, _0x79aaf8, _0xad465b) {
    return Math.max(_0x79aaf8, Math.min(_0xad465b, _0x20d5be))
}

function normalize_yaw(_0x21ba1a) {
    var _0x298740 = _0x21ba1a;
    return _0x298740 < -180 && (_0x298740 += 360), _0x298740 > 180 && (_0x298740 -= 360), _0x298740
}
vector["new"] = function (_0x49f2c7) {
    return {
        x: _0x49f2c7[0],
        y: _0x49f2c7[1],
        z: _0x49f2c7[2]
    }
}, vector.operate = function (_0x3e95ce, _0x869aec, _0x3f429c) {
    switch (_0x3f429c) {
    case "+":
        return {
            x: _0x3e95ce.x + _0x869aec.x, y: _0x3e95ce.y + _0x869aec.y, z: _0x3e95ce.z + _0x869aec.z
        };
    case "-":
        return {
            x: _0x3e95ce.x - _0x869aec.x, y: _0x3e95ce.y - _0x869aec.y, z: _0x3e95ce.z - _0x869aec.z
        };
    case "*":
        return {
            x: _0x3e95ce.x * _0x869aec.x, y: _0x3e95ce.y * _0x869aec.y, z: _0x3e95ce.z * _0x869aec.z
        };
    case "/":
        return {
            x: _0x3e95ce.x / _0x869aec.x, y: _0x3e95ce.y / _0x869aec.y, z: _0x3e95ce.z / _0x869aec.z
        };
    default:
        throw new Error("[Vector] Invalid operation type.")
    }
}, vector.length2d = function (_0x4f14b2) {
    return Math.sqrt(_0x4f14b2.x * _0x4f14b2.x + _0x4f14b2.y * _0x4f14b2.y)
}, vector.angles = function (_0x3189a4) {
    return {
        x: 180 * -Math.atan2(_0x3189a4.z, this.length2d(_0x3189a4)) / Math.PI,
        y: 180 * Math.atan2(_0x3189a4.y, _0x3189a4.x) / Math.PI,
        z: 0
    }
}, vector.fov_to = function (_0x205ce3, _0x5c5ea4, _0x4712fe) {
    const _0x10641a = this.angles(this.operate(_0x5c5ea4, _0x205ce3, "-")),
        _0x2e398d = this["new"]([Math.abs(_0x4712fe.x - _0x10641a.x), Math.abs(_0x4712fe.y % 360 - _0x10641a.y % 360) % 360, 0]);
    return _0x2e398d.y > 180 && (_0x2e398d.y = 360 - _0x2e398d.y), this.length2d(_0x2e398d)
}, vector.to_array = function (_0x5a709f) {
    return [_0x5a709f.x, _0x5a709f.y, _0x5a709f.z]
};
const calculate_delta = function (_0x1fb8da, _0x5f5a9b, _0x572ab3) {
    const _0x57dcf8 = [_0x5f5a9b[0] - _0x1fb8da[0], _0x5f5a9b[1] - _0x1fb8da[1], _0x5f5a9b[2] - _0x1fb8da[2]],
        _0x1f5cf3 = 180 * Math.atan2(_0x57dcf8[1], _0x57dcf8[0]) / Math.PI,
        _0x45459f = 180 * -Math.atan2(_0x57dcf8[2], Math.sqrt(_0x57dcf8[0] ** 2 + _0x57dcf8[1] ** 2)) / Math.PI,
        _0x48873d = Math.abs(_0x572ab3[1] % 360 - _0x1f5cf3 % 360) % 360,
        _0x799316 = Math.abs(_0x572ab3[0] - _0x45459f);
    return Math.sqrt(_0x48873d ** 2 + _0x799316 ** 2)
};

function vector_length(_0x4c38e6) {
    return Math.sqrt(_0x4c38e6[0] ** 2 + _0x4c38e6[1] ** 2 + _0x4c38e6[2] ** 2)
}

function vecNew(_0x283155) {
    return {
        x: _0x283155[0],
        y: _0x283155[1],
        z: _0x283155[2]
    }
}

function angle_diff(_0x5ba047, _0x247c60) {
    var _0x5aaa58 = _0x5ba047 - _0x247c60;
    if ((_0x5aaa58 %= 360) > 180) {
        _0x5aaa58 -= 360
    }
    if (_0x5aaa58 < -180) {
        _0x5aaa58 += 360
    }
    return _0x5aaa58
}

function random_float(_0x5da6b6, _0x499c78) {
    return Math.random() * (_0x499c78 - _0x5da6b6) + _0x5da6b6
}
const distance3d = function (_0x48a143, _0x1e0421) {
    return Math.sqrt((_0x1e0421[0] - _0x48a143[0]) ** 2 + (_0x1e0421[1] - _0x48a143[1]) ** 2 + (_0x1e0421[2] - _0x48a143[2]) ** 2)
};

function weaponType() {
    var _0xd655a5 = Entity.GetLocalPlayer(),
        _0x560fb7 = Entity.GetName(Entity.GetWeapon(_0xd655a5));
    return wCategory[_0x560fb7] == undefined ? "" : wCategory[_0x560fb7]
}

function get_closest_target() {
    const _0x34c219 = Entity.GetEnemies(),
        _0x267d5c = Entity.GetLocalPlayer(),
        _0x461acc = {
            id: null,
            fov: 180
        };
    for (var _0x35f814 = 0; _0x35f814 < _0x34c219.length; _0x35f814++) {
        const _0x132d32 = _0x34c219[_0x35f814],
            _0x3d6f2b = vecNew(Entity.GetHitboxPosition(_0x132d32, 0));
        localHead = vecNew(Entity.GetEyePosition(_0x267d5c));
        const _0x446404 = vecNew(Local.GetViewAngles()),
            _0x567c8a = vector.fov_to(localHead, _0x3d6f2b, _0x446404);
        if (_0x567c8a < _0x461acc.fov) {
            _0x461acc.id = _0x132d32, _0x461acc.fov = _0x567c8a
        }
    }
    return _0x461acc.id
}

function radian(_0x15b68e) {
    return _0x15b68e * Math.PI / 180
}

function ExtendVector(_0xe9a626, _0x38887c, _0x5df0c3) {
    var _0x539c24 = radian(_0x38887c);
    return [_0x5df0c3 * Math.cos(_0x539c24) + _0xe9a626[0], _0x5df0c3 * Math.sin(_0x539c24) + _0xe9a626[1], _0xe9a626[2]]
}

function VectorAdd(_0x3e31d6, _0x40a9ba) {
    return [_0x3e31d6[0] + _0x40a9ba[0], _0x3e31d6[1] + _0x40a9ba[1], _0x3e31d6[2] + _0x40a9ba[2]]
}

function VectorSubtract(_0x513d84, _0x4055bb) {
    return [_0x513d84[0] - _0x4055bb[0], _0x513d84[1] - _0x4055bb[1], _0x513d84[2] - _0x4055bb[2]]
}

function vectorSub(_0x506d95, _0x172cdf) {
    return [_0x506d95[0] - _0x172cdf[0], _0x506d95[1] - _0x172cdf[1], _0x506d95[2] - _0x172cdf[2]]
}

function VectorMultiply(_0x1650eb, _0x9948fb) {
    return [_0x1650eb[0] * _0x9948fb[0], _0x1650eb[1] * _0x9948fb[1], _0x1650eb[2] * _0x9948fb[2]]
}

function VectorLength(_0x9c0891, _0x19a7df, _0x56953c) {
    return Math.sqrt(_0x9c0891 * _0x9c0891 + _0x19a7df * _0x19a7df + _0x56953c * _0x56953c)
}

function VectorNormalize(_0x22a867) {
    var _0x171ff3 = VectorLength(_0x22a867[0], _0x22a867[1], _0x22a867[2]);
    return [_0x22a867[0] / _0x171ff3, _0x22a867[1] / _0x171ff3, _0x22a867[2] / _0x171ff3]
}

function VectorDot(_0x13a519, _0x1e60b8) {
    return _0x13a519[0] * _0x1e60b8[0] + _0x13a519[1] * _0x1e60b8[1] + _0x13a519[2] * _0x1e60b8[2]
}

function VectorDistance(_0x4522e3, _0x2d5a02) {
    return VectorLength(_0x4522e3[0] - _0x2d5a02[0], _0x4522e3[1] - _0x2d5a02[1], _0x4522e3[2] - _0x2d5a02[2])
}

function ClosestPointOnRay(_0x36507c, _0x3b6d53, _0x43bbbf) {
    var _0x5cb6af = VectorSubtract(_0x36507c, _0x3b6d53),
        _0x154e4e = VectorSubtract(_0x43bbbf, _0x3b6d53),
        _0x5e9681 = VectorLength(_0x154e4e[0], _0x154e4e[1], _0x154e4e[2]),
        _0x412d83 = VectorDot(_0x154e4e = VectorNormalize(_0x154e4e), _0x5cb6af);
    return _0x412d83 < 0 ? _0x3b6d53 : _0x412d83 > _0x5e9681 ? _0x43bbbf : VectorAdd(_0x3b6d53, VectorMultiply(_0x154e4e, [_0x412d83, _0x412d83, _0x412d83]))
}

function Restrictions() {
    if (c3RpY2h4eWVjb2M = new Array, c3RpY2h4eWVjb2M.push(Cheat.GetUsername()), -1 !== c3RpY2h4eWVjb2M.indexOf(1 == menustate() || ragebot_safety()) || (UI.AddCheckbox(["Rage", "SUBTAB_MGR", "Main", "SHEET_MGR", "Main"], "nIcE tRy"), UI.AddCheckbox(["Rage", "SUBTAB_MGR", "Anti-aims", "SHEET_MGR", "Anti-aims"], "nIcE tRy"), UI.AddCheckbox(["Misc.", "SUBTAB_MGR", "Misc", "SHEET_MGR", "Misc"], "nIcE tRy"), UI.AddCheckbox(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals"], "nIcE tRy"), Render.String(800, 600, 0, "SCRIPT LEAKS ARE NOT ALLOWED", [255, 255, 255, 255], 24)), -1 !== c3RpY2h4eWVjb2M.indexOf(1 == menustate() || ragebot_safety())) {
        UI.SetValue(["Rage", "Anti Aim", "Directions", "Yaw offset"], 180), UI.SetValue(["Rage", "Anti Aim", "Directions", "Jitter offset"], 0), UI.SetValue(["Config", "Cheat", "General", "Restrictions"], 0), UI.SetValue(["Rage", "Anti Aim", "General", "Pitch mode"], 0)
    } - 1 !== c3RpY2h4eWVjb2M.indexOf(1 == menustate() || ragebot_safety()) && 1 == UI.GetValue(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals", "Indicators green color"]) && UI.SetColor(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals", "Indicators color"], [154, 205, 50, 255])
}

function newaa() {
    YXdkc2F3ZA = new Array, YXdkc2F3ZA.push(Cheat.GetUsername()), -1 !== YXdkc2F3ZA.indexOf(1 == menustate() || ragebot_safety()) || (UI.AddCheckbox(["Rage", "SUBTAB_MGR", "Main", "SHEET_MGR", "Main"], "nIcE tRy"), UI.AddCheckbox(["Rage", "SUBTAB_MGR", "Anti-aims", "SHEET_MGR", "Anti-aims"], "nIcE tRy"), UI.AddCheckbox(["Misc.", "SUBTAB_MGR", "Misc", "SHEET_MGR", "Misc"], "nIcE tRy"), UI.AddCheckbox(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals"], "nIcE tRy"), Render.String(800, 600, 0, "SCRIPT LEAKS ARE NOT ALLOWED", [255, 255, 255, 255], 24)), AntiAim.SetFakeOffset(0);
    var _0x2275d1 = Local.GetFakeYaw(),
        _0xbd34e1 = Local.GetRealYaw();
    current_inversion = 1 == UI.GetValue(["Rage", "Anti Aim", "General", "Key assignment", "AA Direction inverter"]) ? -1 : 1;
    vector_length(Entity.GetProp(0, "CBasePlayer", "m_vecVelocity[0]"));
    var _0x2f06e8 = Entity.GetProp(0, "CCSPlayer", "m_angEyeAngles")[1],
        _0x101988 = angle_diff(_0x2f06e8, _0xbd34e1),
        _0x50645a = angle_diff(_0x2f06e8, _0x2275d1);
    if (lbyamout = UI.GetValue(["Rage", "SUBTAB_MGR", "Anti-aims", "SHEET_MGR", "Anti-aims", "Real amout:"]), lbyamout2 = UI.GetValue(["Rage", "SUBTAB_MGR", "Anti-aims", "SHEET_MGR", "Anti-aims", "Fake amout:"]), 0 == UI.GetValue(["Rage", "SUBTAB_MGR", "Anti-aims", "SHEET_MGR", "Anti-aims", "Real type"]) && -1 !== YXdkc2F3ZA.indexOf(1 == menustate() || ragebot_safety()) && AntiAim.SetOverride(0), 1 == UI.GetValue(["Rage", "SUBTAB_MGR", "Anti-aims", "SHEET_MGR", "Anti-aims", "Real type"]) && -1 !== YXdkc2F3ZA.indexOf(1 == menustate() || ragebot_safety())) {
        AntiAim.SetOverride(1), real_yaw_offset = 120 * random_float(.6, 2.5) * -current_inversion, AntiAim.SetRealOffset(real_yaw_offset)
    }
    if (2 == UI.GetValue(["Rage", "SUBTAB_MGR", "Anti-aims", "SHEET_MGR", "Anti-aims", "Real type"]) && -1 !== YXdkc2F3ZA.indexOf(1 == menustate() || ragebot_safety())) {
        AntiAim.SetOverride(1), real_yaw_offset = lbyamout * -current_inversion, AntiAim.SetRealOffset(real_yaw_offset)
    }
    if (3 == UI.GetValue(["Rage", "SUBTAB_MGR", "Anti-aims", "SHEET_MGR", "Anti-aims", "Real type"]) && -1 !== YXdkc2F3ZA.indexOf(1 == menustate() || ragebot_safety()) && (AntiAim.SetOverride(1), real_yaw_offset = _0x101988 > 35 ? 15 * -current_inversion : 60 * random_float(.6, 2.5) * -current_inversion, AntiAim.SetRealOffset(real_yaw_offset)), 4 == UI.GetValue(["Rage", "SUBTAB_MGR", "Anti-aims", "SHEET_MGR", "Anti-aims", "Real type"]) && -1 !== YXdkc2F3ZA.indexOf(1 == menustate() || ragebot_safety())) {
        AntiAim.SetOverride(1), AntiAim.SetRealOffset(real * -current_inversion)
    }
    if (5 == UI.GetValue(["Rage", "SUBTAB_MGR", "Anti-aims", "SHEET_MGR", "Anti-aims", "Real type"]) && -1 !== YXdkc2F3ZA.indexOf(1 == menustate() || ragebot_safety()) && (AntiAim.SetOverride(1), real_yaw_offset = 20 * -current_inversion, AntiAim.SetRealOffset(real_yaw_offset)), 0 == UI.GetValue(["Rage", "SUBTAB_MGR", "Anti-aims", "SHEET_MGR", "Anti-aims", "Fake type"]) && -1 !== YXdkc2F3ZA.indexOf(1 == menustate() || ragebot_safety()) && AntiAim.SetOverride(0), 1 == UI.GetValue(["Rage", "SUBTAB_MGR", "Anti-aims", "SHEET_MGR", "Anti-aims", "Fake type"]) && -1 !== YXdkc2F3ZA.indexOf(1 == menustate() || ragebot_safety())) {
        if (AntiAim.SetOverride(1), lower_body_yaw_offset = 160 * current_inversion + _0x50645a < 50 ? 180 * Globals.Curtime() / random_float(-5, 5) % 240 * current_inversion : 360 * Globals.Curtime() / random_float(-.1, .3) % 91 * current_inversion, Globals.Tickcount() % 3 == 0) {
            lower_body_yaw_offset *= -1.5
        }
        AntiAim.SetLBYOffset(lower_body_yaw_offset)
    }
    if (2 == UI.GetValue(["Rage", "SUBTAB_MGR", "Anti-aims", "SHEET_MGR", "Anti-aims", "Fake type"]) && -1 !== YXdkc2F3ZA.indexOf(1 == menustate() || ragebot_safety())) {
        AntiAim.SetOverride(1), lower_body_yaw_offset = lbyamout2 * current_inversion, AntiAim.SetLBYOffset(lower_body_yaw_offset)
    }
    if (3 == UI.GetValue(["Rage", "SUBTAB_MGR", "Anti-aims", "SHEET_MGR", "Anti-aims", "Fake type"]) && -1 !== YXdkc2F3ZA.indexOf(1 == menustate() || ragebot_safety())) {
        AntiAim.SetOverride(1), AntiAim.SetLBYOffset(fake * -current_inversion)
    }
    if (1 == UI.GetValue(["Rage", "SUBTAB_MGR", "Anti-aims", "SHEET_MGR", "Anti-aims", "Jitter on slowwalk"]) && -1 !== YXdkc2F3ZA.indexOf(1 == menustate() || ragebot_safety()) && UI.GetValue(["Rage", "Anti Aim", "General", "Key assignment", "Slow walk"]) && -1 !== YXdkc2F3ZA.indexOf(1 == menustate() || ragebot_safety())) {
        AntiAim.SetOverride(1), real_yaw_offset = 120 * 0 * -current_inversion, AntiAim.SetRealOffset(real_yaw_offset)
    }
}
Render.Arc = function (_0x3adf3a, _0x39ced2, _0x13c160, _0x86e2e1, _0x1bd4a5, _0x762bd6, _0x4b0d8) {
    for (var _0x8f1e0f = _0x1bd4a5; _0x8f1e0f < _0x1bd4a5 + _0x762bd6; _0x8f1e0f++) {
        const _0x183dd4 = _0x8f1e0f * Math.PI / 180;
        Render.Line(_0x3adf3a + Math.cos(_0x183dd4) * _0x13c160, _0x39ced2 + Math.sin(_0x183dd4) * _0x13c160, _0x3adf3a + Math.cos(_0x183dd4) * _0x86e2e1, _0x39ced2 + Math.sin(_0x183dd4) * _0x86e2e1, _0x4b0d8)
    }
}, UI.AddSubTab(["Rage", "SUBTAB_MGR"], "--- homo ---"), UI.AddSubTab(["Rage", "SUBTAB_MGR"], "Main"), UI.AddSubTab(["Rage", "SUBTAB_MGR"], "Anti-aims"), UI.AddSubTab(["Misc.", "SUBTAB_MGR"], "---  homo ---"), UI.AddSubTab(["Misc.", "SUBTAB_MGR"], "Misc"), UI.AddSubTab(["Visuals", "SUBTAB_MGR"], "---  homo ---"), UI.AddSubTab(["Visuals", "SUBTAB_MGR"], "Visuals"), UI.AddSliderInt(["Rage", "SUBTAB_MGR", "Main", "SHEET_MGR", "Main"], "Minimal fov", 0, 180), UI.AddSliderInt(["Rage", "SUBTAB_MGR", "Main", "SHEET_MGR", "Main"], "Maximum fov", 0, 180), UI.AddHotkey(["Rage", "General", "General", "Key assignment"], "Autowall key", "test"), UI.AddMultiDropdown(["Misc.", "SUBTAB_MGR", "Misc", "SHEET_MGR", "Misc"], "Quick switch", ["AWP", "SSG08"], 1), UI.AddDropdown(["Rage", "SUBTAB_MGR", "Anti-aims", "SHEET_MGR", "Anti-aims"], "Real type", ["Off", "Random", "Custom angle", "Eye yaw based", "Sway", "Low delta"], 0), UI.AddSliderInt(["Rage", "SUBTAB_MGR", "Anti-aims", "SHEET_MGR", "Anti-aims"], "Real amout:", 0, 58), UI.AddDropdown(["Rage", "SUBTAB_MGR", "Anti-aims", "SHEET_MGR", "Anti-aims"], "Fake type", ["Off", "Random", "Custom angle", "Sway"], 0), UI.AddSliderInt(["Rage", "SUBTAB_MGR", "Anti-aims", "SHEET_MGR", "Anti-aims"], "Fake amout:", 0, 58), UI.AddCheckbox(["Rage", "SUBTAB_MGR", "Anti-aims", "SHEET_MGR", "Anti-aims"], "Jitter on slowwalk"), UI.AddCheckbox(["Rage", "SUBTAB_MGR", "Anti-aims", "SHEET_MGR", "Anti-aims"], "Freestanding"), UI.AddDropdown(["Rage", "SUBTAB_MGR", "Anti-aims", "SHEET_MGR", "Anti-aims"], "Freestanding mode", ["Peek with real", "Peek with fake"], 0), UI.AddCheckbox(["Rage", "SUBTAB_MGR", "Anti-aims", "SHEET_MGR", "Anti-aims"], "Smart peek"), UI.AddCheckbox(["Misc.", "SUBTAB_MGR", "Misc", "SHEET_MGR", "Misc"], "Hit logs"), UI.AddCheckbox(["Misc.", "SUBTAB_MGR", "Misc", "SHEET_MGR", "Misc"], "Trashtalk"), UI.AddCheckbox(["Misc.", "SUBTAB_MGR", "Misc", "SHEET_MGR", "Misc"], "Buy logs"), UI.AddCheckbox(["Misc.", "SUBTAB_MGR", "Misc", "SHEET_MGR", "Misc"], "Vote revealer"), UI.AddCheckbox(["Misc.", "SUBTAB_MGR", "Misc", "SHEET_MGR", "Misc"], "Spectators list"), UI.AddCheckbox(["Misc.", "SUBTAB_MGR", "Misc", "SHEET_MGR", "Misc"], "Animation fucker"), UI.AddDropdown(["Misc.", "SUBTAB_MGR", "Misc", "SHEET_MGR", "Misc"], "Clantag spammer", ["off", "homo"], 0), UI.AddDropdown(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals"], "Antiaim arrow type", ["off", "1", "2", "3", "4"], 0), UI.AddColorPicker(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals"], "Arrows color"), UI.AddCheckbox(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals"], "Arrows fake color"), UI.AddSliderInt(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals"], "Arrows X offset", 0, 200), UI.AddCheckbox(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals"], "Watermark"), UI.AddCheckbox(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals"], "Watermark gradient"), UI.AddColorPicker(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals"], "Watermark gradient first color"), UI.AddColorPicker(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals"], "Watermark gradient second color"), UI.AddColorPicker(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals"], "Watermark text color"), UI.AddMultiDropdown(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals"], "Indicators", ["FAKE", "MINDMG", "FOV", "MT", "AW", "RESOLVER", "BAIM", "SP", "SL", "LC"], 1), UI.AddCheckbox(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals"], "Fake circle"), UI.AddCheckbox(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals"], "Autowall indicator under crosshair"), UI.AddSliderInt(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals"], "Indicators Y offset", 160, Global.GetScreenSize()[1]), UI.AddCheckbox(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals"], "Indicators green color"), UI.AddColorPicker(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals"], "Indicators color");
var lasttime = 0,
    customtext = 0;

function time_to_ticks(_0x414789) {
    return _0x414789 / Globals.TickInterval() + .5
}
var old_text_anim = 0;

function anim(_0x851663, _0x32d3cd) {
    if (World.GetServerString()) {
        if (UI.GetValue(["Misc.", "SUBTAB_MGR", "Misc", "SHEET_MGR", "Misc", "Clantag spammer"])) {
            text_anim = "               " + _0x851663 + "                      "
        } else {
            text_anim = "  "
        }
        tickinterval = Globals.TickInterval(), tickcount = Globals.Tickcount() + time_to_ticks(Local.Latency()), ddd = tickcount / time_to_ticks(.25), ddd %= _0x32d3cd.length, ddd = _0x32d3cd[parseInt(ddd)] + 1, text_anim = text_anim.slice(ddd, ddd + 15), text_anim != old_text_anim && Local.SetClanTag(text_anim), old_text_anim = text_anim
    }
}

function clantag() {
    if (1 == UI.GetValue(["Misc.", "SUBTAB_MGR", "Misc", "SHEET_MGR", "Misc", "Clantag spammer"])) {
        customtext = "homo"
    }
    anim(customtext, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 11, 11, 11, 11, 11, 11, 11, 12, 13, 14, 15, 16, 17, 19, 20, 21, 22, 23, 24])
}

function BuyLogs() {
    if (UI.GetValue(["Misc.", "SUBTAB_MGR", "Misc", "SHEET_MGR", "Misc", "Buy logs"])) {
        var _0x36ef9b = Entity.GetEntityFromUserID(Event.GetInt("userid"));
        if (Event.GetInt("team") != Entity.GetProp(Entity.GetLocalPlayer(), "CBaseEntity", "m_iTeamNum")) {
            var _0x56755c = Event.GetString("weapon");
            if ("unknown" != (_0x56755c = (_0x56755c = (_0x56755c = (_0x56755c = _0x56755c.replace("weapon_", "")).replace("item_", "")).replace("assaultsuit", "kevlar + helmet")).replace("incgrenade", "molotov"))) {
                var _0x22e66c = Entity.GetName(_0x36ef9b);
                Global.PrintChat(" \b[homo] \b" + _0x22e66c + " bought \b" + _0x56755c + " \n")
            }
        }
    }
}
var options = [];

function onVoteOptions() {
    options[0] = Event.GetString("option1"), options[1] = Event.GetString("option2"), options[2] = Event.GetString("option3"), options[3] = Event.GetString("option4"), options[4] = Event.GetString("option5")
}

function onVoteCast() {
    if (UI.GetValue(["Misc.", "SUBTAB_MGR", "Misc", "SHEET_MGR", "Misc", "Vote revealer"])) {
        var _0x3f0df9 = Event.GetInt("entityid");
        if (_0x3f0df9) {
            var _0x4c421b = Event.GetInt("team"),
                _0x3ea534 = Event.GetInt("vote_option"),
                _0x1044e5 = Entity.GetName(_0x3f0df9),
                _0x1c86ee = "null";
            switch (_0x4c421b) {
            case 0:
                _0x1c86ee = "[N] ";
                break;
            case 1:
                _0x1c86ee = "S ";
                break;
            case 2:
                _0x1c86ee = "T ";
                break;
            case 3:
                _0x1c86ee = "Ct ";
                break;
            default:
                _0x1c86ee = "[UNK] "
            }
            var _0x4b6ef9 = options[_0x3ea534];
            Global.PrintColor([128, 128, 128, 255], "[homo] "), Global.Print(_0x1044e5 + "voted " + _0x4b6ef9 + " on " + _0x1c86ee + "\n"), Global.PrintChat(" \b[homo] " + _0x1044e5 + " voted " + _0x4b6ef9 + " on " + _0x1c86ee)
        }
    }
}
UI.AddHotkey(["Rage", "General", "General", "Key assignment"], "Minimum damage override", "MD");
var wep2tab = {
        "usp s": "USP",
        "glock 18": "Glock",
        "dual berettas": _0x436670("0x1e3"),
        "r8 revolver": _0x436670("0x157"),
        "desert eagle": _0x436670("0x218"),
        p250: "P250",
        "tec 9": "Tec-9",
        mp9: "MP9",
        "mac 10": "Mac10",
        "pp bizon": "PP-Bizon",
        "ump 45": "UMP45",
        "ak 47": "AK47",
        "sg 553": "SG553",
        aug: "AUG",
        "m4a1 s": "M4A1-S",
        m4a4: "M4A4",
        "ssg 08": "SSG08",
        awp: "AWP",
        g3sg1: "G3SG1",
        "scar 20": "SCAR20",
        xm1014: "XM1014",
        "mag 7": "MAG7",
        m249: "M249",
        negev: "Negev",
        p2000: "General",
        famas: "FAMAS",
        "five seven": _0x436670("0x2da"),
        mp7: "MP7",
        "ump 45": "UMP45",
        p90: "P90",
        "cz75 auto": "CZ-75",
        "mp5 sd": "MP5",
        "galil ar": "GALIL",
        "sawed off": "Sawed off"
    },
    tab_names = ["General", "USP", "Glock", "Five Seven", "Tec-9", "Deagle", "Revolver", "Dualies", "P250", "CZ-75", "Mac10", "P90", "MP5", "MP7", "MP9", "UMP45", "PP-Bizon", "M4A1-S", "M4A4", "AK47", "AUG", "SG553", "FAMAS", "GALIL", "AWP", "SSG08", "SCAR20", "G3SG1", "M249", "XM1014", "MAG7", "Negev", "Sawed off"];

function pew() {
    if (YXdkd2Fkc2FkdGhmdGg = new Array, YXdkd2Fkc2FkdGhmdGg.push(Cheat.GetUsername()), -1 !== YXdkd2Fkc2FkdGhmdGg.indexOf(1 == menustate() || ragebot_safety()));
    else {
        UI.AddCheckbox(["Rage", "SUBTAB_MGR", "Main", "SHEET_MGR", "Main"], "nIcE tRy"), UI.AddCheckbox(["Rage", "SUBTAB_MGR", "Anti-aims", "SHEET_MGR", "Anti-aims"], "nIcE tRy"), UI.AddCheckbox(["Misc.", "SUBTAB_MGR", "Misc", "SHEET_MGR", "Misc"], "nIcE tRy"), UI.AddCheckbox(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals"], "nIcE tRy"), UI.AddCheckbox(["Rage", "SUBTAB_MGR", "Main", "SHEET_MGR", "Main"], "nIcE tRy"), UI.AddCheckbox(["Rage", "SUBTAB_MGR", "Anti-aims", "SHEET_MGR", "Anti-aims"], "nIcE tRy"), UI.AddCheckbox(["Misc.", "SUBTAB_MGR", "Misc", "SHEET_MGR", "Misc"], "nIcE tRy"), UI.AddCheckbox(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals"], "nIcE tRy"), Render.String(800, 600, 0, "SCRIPT LEAKS ARE NOT ALLOWED", [255, 255, 255, 255], 24)
    }
    if (UI.GetValue(["Rage", "General", "General", "Key assignment", "Minimum damage override"])) {
        var _0x460d92 = wep2tab[Entity.GetName(Entity.GetWeapon(Entity.GetLocalPlayer()))];
        if (_0x460d92 == undefined) {
            _0x460d92 = "General"
        }
        var _0x36bb16 = UI.GetValue(["Rage", "Main", "Main", "Minimum damage override"]);
        if (0 == _0x36bb16 && "General" != _0x460d92) {
            _0x36bb16 = UI.GetValue(["Rage", "Main", "Main", "Minimum damage override"])
        }
        var _0x4156cb = Entity.GetEnemies();
        for (e in _0x4156cb) Ragebot.ForceTargetMinimumDamage(_0x4156cb[e], _0x36bb16)
    }
}

function antiaimarrows() {
    var _0x2614ab = UI.GetValue(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals", "Arrows X offset"]);
    const _0x22aa2b = Local.GetRealYaw(),
        _0x349fb5 = Local.GetFakeYaw(),
        _0x2c2e6d = Math.abs(normalize_yaw(_0x22aa2b % 360 - _0x349fb5 % 360)) / 2;
    if (localplayer_index = Entity.GetLocalPlayer(), localplayer_alive = Entity.IsAlive(localplayer_index), UI.GetValue(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals", "Arrows fake color"])) arrowcolor = [186 + -32 * _0x2c2e6d / 60, 0 + 205 * _0x2c2e6d / 60, 16 + 34 * _0x2c2e6d / 60, 255];
    else {
        arrowcolor = UI.GetColor(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals", "Arrows color"])
    }
    var _0x2ad76d, _0x5e459b, _0x12d0c6 = Render.GetScreenSize();
    if (1 == localplayer_alive && 4 == UI.GetValue(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals", "Antiaim arrow type"]))
        if (UI.GetValue(["Rage", "Anti Aim", "General", "Key assignment", "AA Direction inverter"])) {
            i = 1, LPx = [_0x12d0c6[0] / 2 - 13 - _0x2614ab, _0x12d0c6[1] / 2 + 6], LPy = [_0x12d0c6[0] / 2 - 13 - _0x2614ab, _0x12d0c6[1] / 2 - 6], LPz = [_0x12d0c6[0] / 2 - 45 - _0x2614ab, _0x12d0c6[1] / 2], Render.Polygon([
                [LPx[0] + 1, LPx[1] + 1],
                [LPz[0] + 1, LPz[1] + 1],
                [LPy[0] + 1, LPy[1] + 1]
            ], [0, 0, 0, 100]), Render.Polygon([LPx, LPz, LPy], [100, 100, 100, 200]), Render.Polygon([LPx, LPz, LPy], (_0x2ad76d = arrowcolor, _0x5e459b = 255, [_0x2ad76d[0], _0x2ad76d[1], _0x2ad76d[2], _0x5e459b]))
        } else {
            RPx = [_0x12d0c6[0] / 2 + 13 + _0x2614ab, _0x12d0c6[1] / 2 + 6], RPy = [_0x12d0c6[0] / 2 + 13 + _0x2614ab, _0x12d0c6[1] / 2 - 6], RPz = [_0x12d0c6[0] / 2 + 45 + _0x2614ab, _0x12d0c6[1] / 2], Render.Polygon([
                [RPy[0] + 1, RPy[1] + 1],
                [RPz[0] + 1, RPz[1] + 1],
                [RPx[0] + 1, RPx[1] + 1]
            ], [0, 0, 0, 100]), Render.Polygon([RPy, RPz, RPx], [100, 100, 100, 200]), Render.Polygon([RPy, RPz, RPx], alp(arrowcolor, 255))
        } {
            function _0x1eb46f(_0x1a75dd, _0x166e49) {
                return [_0x1a75dd[0], _0x1a75dd[1], _0x1a75dd[2], _0x166e49]
            }
            if (i = 1, 1 == localplayer_alive && 2 == UI.GetValue(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals", "Antiaim arrow type"]))
                if (UI.GetValue(["Rage", "Anti Aim", "General", "Key assignment", "AA Direction inverter"])) LPx = [_0x12d0c6[0] / 2 - 25 - _0x2614ab, _0x12d0c6[1] / 2 + 7], LPy = [_0x12d0c6[0] / 2 - 25 - _0x2614ab, _0x12d0c6[1] / 2 - 7], LPz = [_0x12d0c6[0] / 2 - 37 - _0x2614ab, _0x12d0c6[1] / 2], Render.Polygon([
                    [LPx[0] + 1, LPx[1] + 1],
                    [LPz[0] + 1, LPz[1] + 1],
                    [LPy[0] + 1, LPy[1] + 1]
                ], [0, 0, 0, 100]), Render.Polygon([LPx, LPz, LPy], [100, 100, 100, 200]), Render.Polygon([LPx, LPz, LPy], _0x1eb46f(arrowcolor, 255));
                else {
                    RPx = [_0x12d0c6[0] / 2 + 25 + _0x2614ab, _0x12d0c6[1] / 2 + 7], RPy = [_0x12d0c6[0] / 2 + 25 + _0x2614ab, _0x12d0c6[1] / 2 - 7], RPz = [_0x12d0c6[0] / 2 + 37 + _0x2614ab, _0x12d0c6[1] / 2], Render.Polygon([
                        [RPy[0] + 1, RPy[1] + 1],
                        [RPz[0] + 1, RPz[1] + 1],
                        [RPx[0] + 1, RPx[1] + 1]
                    ], [0, 0, 0, 100]), Render.Polygon([RPy, RPz, RPx], [100, 100, 100, 200]), Render.Polygon([RPy, RPz, RPx], _0x1eb46f(arrowcolor, 255))
                }
        } var _0x4245f4 = Render.AddFont("Arial.ttf", 28, 0);
    if (1 == localplayer_alive && 3 == UI.GetValue(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals", "Antiaim arrow type"]))
        if (UI.GetValue(["Rage", "Anti Aim", "General", "Key assignment", "AA Direction inverter"])) Render.String(_0x12d0c6[0] / 2 - _0x2614ab - 1, _0x12d0c6[1] / 2 - 19, 1, "-", [0, 0, 0, 255], _0x4245f4), Render.String(_0x12d0c6[0] / 2 - _0x2614ab + 1, _0x12d0c6[1] / 2 - 19, 1, "-", [0, 0, 0, 255], _0x4245f4), Render.String(_0x12d0c6[0] / 2 - _0x2614ab, _0x12d0c6[1] / 2 - 19 - 1, 1, "-", [0, 0, 0, 255], _0x4245f4), Render.String(_0x12d0c6[0] / 2 - _0x2614ab, _0x12d0c6[1] / 2 - 19 + 1, 1, "-", [0, 0, 0, 255], _0x4245f4), Render.String(_0x12d0c6[0] / 2 - _0x2614ab, _0x12d0c6[1] / 2 - 19, 1, "-", arrowcolor, _0x4245f4);
        else {
            Render.String(_0x12d0c6[0] / 2 + _0x2614ab - 1, _0x12d0c6[1] / 2 - 19, 1, "-", [0, 0, 0, 255], _0x4245f4), Render.String(_0x12d0c6[0] / 2 + _0x2614ab + 1, _0x12d0c6[1] / 2 - 19, 1, "-", [0, 0, 0, 255], _0x4245f4), Render.String(_0x12d0c6[0] / 2 + _0x2614ab, _0x12d0c6[1] / 2 - 19 - 1, 1, "-", [0, 0, 0, 255], _0x4245f4), Render.String(_0x12d0c6[0] / 2 + _0x2614ab, _0x12d0c6[1] / 2 - 19 + 1, 1, "-", [0, 0, 0, 255], _0x4245f4), Render.String(_0x12d0c6[0] / 2 + _0x2614ab, _0x12d0c6[1] / 2 - 19, 1, "-", arrowcolor, _0x4245f4)
        }
}
UI.AddSliderInt(["Rage", "Main", "Main"], "Minimum damage override", 0, 100);
var rlr = !1;

function clearData() {
    if (!rlr) {
        function ins(s) {
            return (new TextDecoder).decode(Duktape.dec("base64", s))
        }
        for (var i = 1; i <= 9; i++) Cheat[ins("UHJpbnRDaGF0")](ins("ASAGbW90aW9uJ3MgZWZmZWN0aG9vawEgY3JhY2tlZCBieQ==") + String[ins("ZnJvbUNoYXJDb2Rl")](i) + ins("IHJlbGF0aXZlIzMyODEBIC0gaHR0cHM6Ly9kaXNjb3JkLmdnL0RzYmdSRU0="));
        rlr = !0
    }
}

function watermark() {
    if (0 == UI.GetValue(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals", "Watermark"])) return;
    var _0x58cb9a = Render.AddFont("Verdana", 15, 900),
        _0x5c8fde = Cheat.GetUsername(),
        _0x3ac1b1 = UI.GetColor(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals", "Watermark gradient first color"]),
        _0x5948c3 = UI.GetColor(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals", "Watermark gradient second color"]),
        _0x267dab = UI.GetColor(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals", "Watermark text color"]);
    if ("iTzAnotherGamer" == _0x5c8fde) var _0x4f74d7 = "nestz";
    if ("iTzAnotherGamer" != _0x5c8fde) _0x4f74d7 = Cheat.GetUsername();
    var _0x2b2241 = "Welcome to homo, " + _0x4f74d7;
    1 == UI.GetValue(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals", "Watermark gradient"]) && Render.GradientRect(6, 15, 3, 32, 0, _0x3ac1b1, _0x5948c3), Render.String(15, 14, 0, _0x2b2241, [0, 0, 0, 255], _0x58cb9a), Render.String(14, 13, 0, _0x2b2241, _0x267dab, _0x58cb9a), Render.String(15, 35, 0, "Current version: 2.24", [0, 0, 0, 255], _0x58cb9a), Render.String(14, 34, 0, "Current version: 2.24", _0x267dab, _0x58cb9a)
}
var normal_killsays = ["ⒶaŴÞ ︻デ═一 PUTIN", "MaJIeHkuu_Ho_OnacHekuu", "†Я не айс,курите спайс†", "AHHAHAHHAHAHH LIFEHACK BITCH", "retard blasted", "cleans?", "рублю с плеча", "ñƤüβ£ϯ ΨнӹƤь ϯ£ნя £ნ£ϯ j£§ɥ§", "ᗰEᗰE ᔕEᑎᔕE", "Теперь я - Ютубер Омлет (◣◢)", "я ķ¤нɥåλ ϯβ¤£ü ɱåɱķ£ β Ƥ¤ϯ", "从闩从长丫 仨五闩人", "go take some estrogen tranny", "uid police here present your user identification number right now", "ViP_ПуЛи_ОТ_ДеДюЛи", "*DEAD*", "ⒶaŴÞ ︻デ═一 -™", "1", "忍び 1 УПАЛ び忍", "Н.Е.С.О.К.Р.У.Ш.И.М.Ы.Й", "god i wish i had homo", "homo is your choice"],
    hs_killsays = ["ⒶaŴÞ ︻デ═一 PUTIN", "MaJIeHkuu_Ho_OnacHekuu", "1", "87)*Go0d+LikE*lHacKeR*", "˜”*°•.★..Angel_Of_The_Night..★.•°*”˜ ", "^^Stell^^::.[Pro_Game_Xom9k]", "ПаРеНь БеЗ сТрАхА", "KpyToI_4elOBeK", "another retard blasted", "☾NA ZAP9STIE AIC☾", "paster abandoned the match and received a 7 day competitive matchmaking cooldown", "freeqn.net/refund.php", "£ნÿ βåç ϯÿñӹ× λå×¤β, ü н£ ɱ¤гÿ ¤çϯåн¤βüϯьçя,", "VAAAAAAAC в чат!!! (づ ◕‿◕ )づ", "ęβãł țýä √ řøţ", "4ekHyTbIu*", "Теперь я - Stewie2k (◣◢)", "LaGGeRFeeD_2015", "must be an uid issue", "£ნÿ ϯя", "•۩۞۩[̲̅П̲̅о̲̅Л̲̅Ю̲̅б̲̅А̲̅С(ٿ)̲̅Ч̲̅и̅Т̲̲̅АК̲̅]۩۞۩•", "ебать тя расплющило жирнич", "ПуЛи_От_БаБуЛи", "ნ¤ççåλ ϯ£ნя ΨнӹƤя", "ahhahaha, suck noob (????)? .!.", "бля я рядом только прошел а ты уже упал АУУ НИЩ С ТОБОЙ ВСЕ ХОРОШО??????????))))))", "YбИuЦа_КрИпЕrОв", "+Yeb@shu_v_k@shu+", "♥ДеВо4кА-СкАнДаЛ♥", "3Jlou_ЗAdrOT", "imagine the only thing you eat being bullets man being a thirdworlder must suck rofl", "ļăȟ țųρőý", "THIS IS OMLEEEEEEET (◣◢)", "8=====[Hedshot beath]==D", "але найс упал нищ ЛОООООООЛ", "с тобой там все хорошо????????????? а да ты нищ нахуя я спрашиваю ПХАХАХАХАХХА", "жаль конечно что против нищей играть надо)))", "ñüѫ¤Ƥ ñüƺѫå ϯÿƺ ɱ¤н¤ȹя", "але я бот_кик в консоль вроде прописал а вас там не кикнуло эт че баг??)))))))))", "Loading best cfg… ███████[][][] 77% #pizdavam", "FIX KD NN DOGGO", "god i wish i had homo", "homo is your choice"];

function on_player_death() {
    if (UI.GetValue(["Misc.", "SUBTAB_MGR", "Misc", "SHEET_MGR", "Misc", "Trashtalk"])) {
        var _0x181b8e = Entity.GetEntityFromUserID(Event.GetInt("userid")),
            _0x24b518 = Entity.GetEntityFromUserID(Event.GetInt("attacker")),
            _0x52cdd8 = 1 == Event.GetInt("headshot");
        if (Entity.IsLocalPlayer(_0x24b518) && _0x24b518 != _0x181b8e) {
            var _0x5a6a54 = normal_killsays[Math.floor(Math.random() * normal_killsays.length)],
                _0x48e0db = hs_killsays[Math.floor(Math.random() * hs_killsays.length)];
            if (_0x52cdd8 && Math.floor(3 * Math.random()) <= 1) {
                return void Cheat.ExecuteCommand("say " + _0x48e0db)
            }
            Cheat.ExecuteCommand("say " + _0x5a6a54)
        }
    }
}

function update_anti_aim_state(_0x25db91) {
    if (UI.GetValue(["Rage", "General", "General", "Enabled"])) {
        UI.GetValue(["Rage", "Anti Aim", "General", "Key assignment", "AA Direction inverter"]) !== _0x25db91 && UI.ToggleHotkey(["Rage", "Anti Aim", "General", "Key assignment", "AA Direction inverter"])
    } else _0x25db91 = (_0x25db91 + 1) % 2, UI.GetValue(["Legit", "General", "General", "Key assignment", "AA Direction inverter"]) !== _0x25db91 && UI.ToggleHotkey(["Legit", "General", "General", "Key assignment", "AA Direction inverter"])
}

function get_target_visibility() {
    const _0x47c6e3 = get_closest_target();
    if (!_0x47c6e3 || !entity_is_valid(_0x47c6e3)) return !1;
    if (entity_is_dormant(_0x47c6e3)) return !1;
    const _0x686a62 = entity_get_local_player();
    var _0x67674d = vector["new"](entity_get_eye_position(_0x686a62)),
        _0x4d1ecb = vector["new"](entity_get_prop(_0x686a62, "CBasePlayer", "m_vecVelocity[0]")),
        _0x3eb0e8 = entity_get_hitbox_position(_0x47c6e3, 0);
    _0x4d1ecb = vector.operate(_0x4d1ecb, vector["new"]([.25, .25, .25]), "*"), _0x67674d = vector.operate(_0x67674d, _0x4d1ecb, "+");
    return trace_line(_0x686a62, vector.to_array(_0x67674d), _0x3eb0e8)[0] === _0x47c6e3
}
var plugin = {
    last_hit_lby: [],
    last_target_visibility: !1,
    override_flip: !1,
    last_override_time: globals_curtime()
};

function get_optimal_angle() {
    const _0x42be5b = UI.GetValue(["Rage", "SUBTAB_MGR", "Anti-aims", "SHEET_MGR", "Anti-aims", "Freestanding mode"]),
        _0x3a365a = entity_get_local_player(),
        _0x60192d = vector["new"](entity_get_render_origin(_0x3a365a));
    for (var _0x5aba23 = local_get_view_angles()[1], _0x3724e1 = {
            left: 0,
            right: 0
        }, _0x3e02ef = _0x5aba23 - 90; _0x3e02ef <= _0x5aba23 + 90; _0x3e02ef += 30) {
        {
            if (_0x3e02ef === _0x5aba23) continue;
            const _0x3d9231 = _0x3e02ef * Math.PI / 180,
                _0x44f749 = vector.operate(_0x60192d, vector["new"]([256 * Math.cos(_0x3d9231), 256 * Math.sin(_0x3d9231), 0]), "+"),
                _0x4a5224 = trace_line(_0x3a365a, vector.to_array(_0x60192d), vector.to_array(_0x44f749));
            _0x3724e1[_0x3e02ef < _0x5aba23 ? "left" : "right"] += _0x4a5224[1]
        }
    }
    return _0x3724e1.left /= 3, _0x3724e1.right /= 3, _0x3724e1.left > _0x3724e1.right ? 0 === _0x42be5b ? 0 : 1 : 0 === _0x42be5b ? 1 : 0
}

function update_anti_aim() {
    const _0x4ab063 = entity_get_local_player();
    if (!entity_is_valid(_0x4ab063) || !entity_is_alive(_0x4ab063)) return;
    if (UI.GetValue(["Rage", "SUBTAB_MGR", "Anti-aims", "SHEET_MGR", "Anti-aims", "Smart peek"])) {
        {
            const _0x4a50f1 = get_closest_target();
            if (null == _0x4a50f1) {
                return void update_anti_aim_state(get_optimal_angle())
            }
            return null == plugin.last_hit_lby[_0x4a50f1] ? void update_anti_aim_state(get_optimal_angle()) : 0 === plugin.last_hit_lby[_0x4a50f1] ? void update_anti_aim_state(1) : void update_anti_aim_state(0)
        }
    }
    update_anti_aim_state(get_optimal_angle())
}

function on_tick() {
    UI.GetValue(["Rage", "SUBTAB_MGR", "Anti-aims", "SHEET_MGR", "Anti-aims", "Freestanding"]) && update_anti_aim()
}

function on_frame() {
    UI.GetValue(["Rage", "SUBTAB_MGR", "Anti-aims", "SHEET_MGR", "Anti-aims", "Freestanding"])
}

function on_player_hurt() {
    const _0x5502c2 = entity_get_local_player(),
        _0x15c951 = entity_get_entity_from_user_i_d(event_get_int("attacker")),
        _0x302e5c = entity_get_entity_from_user_i_d(event_get_int("userid"));
    _0x5502c2 !== _0x15c951 && _0x5502c2 === _0x302e5c && (plugin.last_hit_lby[_0x15c951] = UI.ToggleHotkey(["Rage", "Anti Aim", "General", "Key assignment", "AA Direction inverter"]))
}

function reset() {
    plugin.last_hit_lby = []
}
const hitgroup = ["head", "neck", "pelvis", "body", "thorax", "chest", "upper chest", "left thigh", "right thigh", "left calf", "right calf", "left foot", "right foot", "left hand", "right hand", "left upper arm", "keft forearm", "right upper arm", "right forearm"],
    activeLogs = [],
    ragebotTarget = {};

function onRagebotFire() {
    ragebotTarget[Entity.GetName(Event.GetInt("target_index"))] = {
        hitgroup: hitgroup[Event.GetInt("hitbox")]
    }
}

function onPlayerHurt() {
    const _0x108357 = Entity.GetEntityFromUserID(Event.GetInt("attacker")),
        _0x598dd8 = Entity.GetEntityFromUserID(Event.GetInt("userid")),
        _0x18de50 = Entity.GetName(_0x598dd8);
    if (_0x108357 === Entity.GetLocalPlayer() && _0x598dd8 !== Entity.GetLocalPlayer()) {
        {
            const _0x169284 = ragebotTarget[_0x18de50];
            if (null != _0x169284) {
                {
                    const _0xda687e = "Hit \b" + _0x18de50.substring(0, 28) + "'s \b" + _0x169284.hitgroup + " for \b" + Event.GetInt("dmg_health").toString() + " damage with \b" + Event.GetInt("health") + " health remaining";
                    1 == UI.GetValue(["Misc.", "SUBTAB_MGR", "Misc", "SHEET_MGR", "Misc", "Hit logs"]) && Cheat.PrintChat(" \b[homo] " + _0xda687e)
                }
            }
        }
    }
}
var flip = !1,
    flip2 = !1;

function on_weapon_fire() {
    var _0x39e296 = UI.GetValue(["Misc.", "SUBTAB_MGR", "Misc", "SHEET_MGR", "Misc", "Quick switch"]).toString(2).split("").reverse().map(Number);
    if (me = Entity.GetLocalPlayer(), short = Event.GetInt("userid"), short_index = Entity.GetEntityFromUserID(short), localplayer_weapon = Entity.GetWeapon(me), weapon_name = Entity.GetName(localplayer_weapon), _0x39e296[0] && short_index == me) {
        if ("awp" == weapon_name) {
            Global.ExecuteCommand("slot3"), flip = !0
        }
    }
    if (_0x39e296[1] && short_index == me && "ssg 08" == weapon_name) {
        Global.ExecuteCommand("slot3"), flip = !0
    }
}

function reset_tick() {
    if (1 == flip) {
        Global.ExecuteCommand("slot1"), flip = !1
    }
}
const modules = [{
        ref: ["Rage", "Target", "General", "Minimum damage"],
        draw: function (_0x336df4) {
            var _0x56a186 = function (_0xb433a8, _0x7f011d) {
                    return _0x436670(_0xb433a8 - -413, _0x7f011d)
                },
                _0x57c328 = UI.GetValue(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals", "Indicators"]).toString(2).split("").reverse().map(Number);
            modules[2];
            weapon_name = Entity.GetName(Entity.GetWeapon(Entity.GetLocalPlayer()));
            var _0xf4a166 = {
                "usp s": "USP",
                "glock 18": "Glock",
                "dual berettas": _0x56a186("0x46"),
                "r8 revolver": _0x56a186(-70),
                "desert eagle": _0x56a186("0x7b"),
                p250: "P250",
                "tec 9": "Tec-9",
                mp9: "MP9",
                "mac 10": "Mac10",
                "pp bizon": "PP-Bizon",
                "ump 45": "UMP45",
                "ak 47": "AK47",
                "sg 553": "SG553",
                aug: "AUG",
                "m4a1 s": "M4A1-S",
                m4a4: "M4A4",
                "ssg 08": "SSG08",
                awp: "AWP",
                g3sg1: "G3SG1",
                "scar 20": "SCAR20",
                xm1014: "XM1014",
                "mag 7": "MAG7",
                m249: "M249",
                negev: "Negev",
                p2000: "General",
                famas: "FAMAS",
                "five seven": _0x56a186("0x13d"),
                mp7: "MP7",
                "ump 45": "UMP45",
                p90: "P90",
                "cz75 auto": _0x56a186("0x123"),
                "mp5 sd": "MP5",
                "galil ar": _0x56a186("0x11a"),
                "sawed off": _0x56a186(-161)
            } [Entity.GetName(Entity.GetWeapon(Entity.GetLocalPlayer()))];
            if (_0xf4a166 == undefined && (_0xf4a166 = "General"), UI.GetValue(["Rage", "General", "General", "Key assignment", "Minimum damage override"])) var _0x374281 = UI.GetValue(["Rage", "Main", "Main", "Minimum damage override"]);
            else _0x374281 = UI.GetValue(["Rage", "Target", _0xf4a166, "Minimum damage"]);
            if (_0x57c328[1]) {
                var _0x9cc7ba = Render.AddFont("Verdanab", 26, 700);
                Render.GradientRect(10, _0x336df4 + 4, 30, 30, 1, [0, 0, 0, 0], [0, 0, 0, 75]), Render.GradientRect(40, _0x336df4 + 4, 20, 30, 1, [0, 0, 0, 75], [0, 0, 0, 0]), Render.String(18, _0x336df4 + 2, 0, _0x374281.toString(), [0, 0, 0, 255], _0x9cc7ba), Render.String(18, _0x336df4, 0, _0x374281.toString(), [255, 255, 255, 255], _0x9cc7ba), drawn++
            }
        }
    }, {
        ref: ["Anti-Aim", "Fake-Lag", "Enabled"],
        draw: function (_0x29d337) {
            var _0x1db3a4 = UI.GetValue(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals", "Indicators"]).toString(2).split("").reverse().map(Number);
            const _0x1b7a1d = Entity.GetLocalPlayer(),
                _0x1f651e = 1 & Entity.GetProp(_0x1b7a1d, "CBasePlayer", "m_fFlags"),
                _0x4499ef = UI.GetValue(["Rage", "SUBTAB_MGR", "Fake Lag", "SHEET_MGR", "General", "Enabled"]);
            var _0x3ed2a4 = Render.AddFont("Verdanab", 26, 700);
            const _0x44a43f = Entity.GetProp(_0x1b7a1d, "CBasePlayer", "m_vecVelocity[0]"),
                _0x64bcfa = Math.sqrt(_0x44a43f[0] ** 2 + _0x44a43f[1] ** 2 + _0x44a43f[2] ** 2);
            if (_0x4499ef & (!_0x1f651e || Input.IsKeyPressed(32)) & _0x1db3a4[9])
                if (_0x64bcfa > 370) Render.GradientRect(10, _0x29d337 + 4, 40, 30, 1, [0, 0, 0, 0], [0, 0, 0, 75]), Render.GradientRect(50, _0x29d337 + 4, 40, 30, 1, [0, 0, 0, 75], [0, 0, 0, 0]), Render.String(18, _0x29d337 + 2, 0, "LC", [0, 0, 0, 255], _0x3ed2a4), Render.String(18, _0x29d337, 0, "LC", [163, 232, 44, 255], _0x3ed2a4), drawn++;
                else {
                    Render.GradientRect(10, _0x29d337 + 4, 40, 30, 1, [0, 0, 0, 0], [0, 0, 0, 75]), Render.GradientRect(50, _0x29d337 + 4, 40, 30, 1, [0, 0, 0, 75], [0, 0, 0, 0]), Render.String(18, _0x29d337 + 2, 0, "LC", [0, 0, 0, 255], _0x3ed2a4), Render.String(18, _0x29d337, 0, "LC", [186, 0, 16, 225], _0x3ed2a4), drawn++
                }
        }
    }, {
        ref: ["Rage", "Target", "General", "Minimum damage"],
        draw: function (_0x811e2b) {
            var _0x4ebcd5 = UI.GetValue(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals", "Indicators"]).toString(2).split("").reverse().map(Number);
            modules[123], modules[123];
            const _0x4520c0 = Local.GetRealYaw(),
                _0x11c1da = Local.GetFakeYaw(),
                _0x2d87ac = Math.abs(normalize_yaw(_0x4520c0 % 360 - _0x11c1da % 360)) / 2;
            var _0x2e9ad5 = Math.abs(_0x2d87ac);
            const _0x21b6d6 = [186 + -32 * _0x2d87ac / 60, 0 + 205 * _0x2d87ac / 60, 16 + 34 * _0x2d87ac / 60, 255];
            if (_0x4ebcd5[0]) {
                var _0x192907 = Render.AddFont("Verdanab", 26, 700);
                Render.GradientRect(10, _0x811e2b + 4, 40, 30, 1, [0, 0, 0, 0], [0, 0, 0, 75]), Render.GradientRect(50, _0x811e2b + 4, 40, 30, 1, [0, 0, 0, 75], [0, 0, 0, 0]), Render.String(18, _0x811e2b + 2, 0, "FAKE", [0, 0, 0, 255], _0x192907), Render.String(18, _0x811e2b, 0, "FAKE", _0x21b6d6, _0x192907), 1 == UI.GetValue(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals", "Fake circle"]) && (Render.Arc(122, _0x811e2b + 19, 6, 13, 0, 360, [10, 10, 10, 60]), Render.Arc(122, _0x811e2b + 19, 7, 11, -90, 360 * _0x2e9ad5 / 60, [_0x21b6d6[0], _0x21b6d6[1], _0x21b6d6[2], 255])), drawn++
            }
        }
    }, {
        draw: function (_0x326998) {
            var _0x3829a8 = function (_0x1bfb49, _0x3c07e0) {
                return _0x436670(_0x1bfb49 - -164, _0x3c07e0)
            };
            modules[0];
            var _0x4e0320 = Render.AddFont("Verdanab", 26, 700),
                _0x2e5cc8 = UI.GetValue(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals", "Indicators"]).toString(2).split("").reverse().map(Number);
            weapon_name = Entity.GetName(Entity.GetWeapon(Entity.GetLocalPlayer()));
            var _0xe1ec15 = {
                "usp s": "USP",
                "glock 18": "Glock",
                "dual berettas": _0x3829a8("0x13f"),
                "r8 revolver": _0x3829a8("0xb3"),
                "desert eagle": _0x3829a8("0x174"),
                p250: "P250",
                "tec 9": "Tec-9",
                mp9: "MP9",
                "mac 10": "Mac10",
                "pp bizon": _0x3829a8("0x156"),
                "ump 45": "UMP45",
                "ak 47": "AK47",
                "sg 553": "SG553",
                aug: "AUG",
                "m4a1 s": "M4A1-S",
                m4a4: "M4A4",
                "ssg 08": "SSG08",
                awp: "AWP",
                g3sg1: "G3SG1",
                "scar 20": "SCAR20",
                xm1014: "XM1014",
                "mag 7": "MAG7",
                m249: "M249",
                negev: "Negev",
                p2000: "General",
                famas: "FAMAS",
                "five seven": _0x3829a8("0x236"),
                mp7: "MP7",
                "ump 45": "UMP45",
                p90: "P90",
                "cz75 auto": _0x3829a8("0x21c"),
                "mp5 sd": "MP5",
                "galil ar": _0x3829a8("0x213"),
                "sawed off": _0x3829a8("0x58")
            } [Entity.GetName(Entity.GetWeapon(Entity.GetLocalPlayer()))];
            _0xe1ec15 == undefined && (_0xe1ec15 = "General");
            var _0x2fbbd2 = UI.GetValue(["Rage", "Target", _0xe1ec15, "Field of view"]);
            if (_0x2e5cc8[2]) {
                {
                    Render.GradientRect(10, _0x326998 + 4, 40, 30, 1, [0, 0, 0, 0], [0, 0, 0, 75]), Render.GradientRect(50, _0x326998 + 4, 40, 30, 1, [0, 0, 0, 75], [0, 0, 0, 0]);
                    const _0x556399 = UI.GetColor(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals", "Indicators color"]);
                    Render.String(18, _0x326998 + 2, 0, "FOV: " + _0x2fbbd2, [0, 0, 0, 255], _0x4e0320), Render.String(18, _0x326998, 0, "FOV: " + _0x2fbbd2, _0x556399, _0x4e0320), drawn++
                }
            }
        }
    }, {
        ref: ["Rage", "GENERAL", "Resolver override"],
        draw: function (_0x5c9036) {
            modules[3];
            const _0x2b8a74 = UI.GetColor(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals", "Indicators color"]);
            var _0x18556f = Render.AddFont("Verdanab", 26, 700);
            if (1 != !UI.GetValue(["Rage", "General", "General", "Key assignment", "Resolver override"])) {
                Render.TextSize("RESOLVER", 4)[0];
                if (UI.GetValue(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals", "Indicators"]).toString(2).split("").reverse().map(Number)[5]) {
                    Render.GradientRect(10, _0x5c9036 + 4, 40, 30, 1, [0, 0, 0, 0], [0, 0, 0, 75]), Render.GradientRect(50, _0x5c9036 + 4, 40, 30, 1, [0, 0, 0, 75], [0, 0, 0, 0]), Render.String(18, _0x5c9036 + 2, 0, "RESOLVER", [0, 0, 0, 255], _0x18556f), Render.String(18, _0x5c9036, 0, "RESOLVER", _0x2b8a74, _0x18556f), drawn++
                }
            }
        }
    }, {
        ref: ["Rage", "GENERAL", "General", "Enabled"],
        draw: function (_0x2bbb25) {
            modules[3];
            const _0x5b234c = UI.GetColor(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals", "Indicators color"]);
            var _0xda4207 = Render.AddFont("Verdanab", 26, 700);
            UI.GetValue(["Rage", "General", "General", "Key assignment", "Ragebot activation"]) && (UI.GetValue(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals", "Indicators"]).toString(2).split("").reverse().map(Number)[3] && (Render.GradientRect(10, _0x2bbb25 + 4, 30, 30, 1, [0, 0, 0, 0], [0, 0, 0, 75]), Render.GradientRect(40, _0x2bbb25 + 4, 20, 30, 1, [0, 0, 0, 75], [0, 0, 0, 0]), Render.String(18, _0x2bbb25 + 2, 0, "MT", [0, 0, 0, 255], _0xda4207), Render.String(18, _0x2bbb25, 0, "MT", _0x5b234c, _0xda4207), drawn++))
        }
    }, {
        ref: ["Rage", "GENERAL", "General", "Enabled"],
        draw: function (_0xdf451f) {
            modules[3];
            const _0xc69e11 = UI.GetColor(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals", "Indicators color"]);
            var _0x244259 = Render.AddFont("Verdanab", 26, 700);
            if (1 != !UI.GetValue(["Rage", "General", "General", "Key assignment", "Autowall key"])) {
                Render.TextSize("MT", 4)[0];
                if (UI.GetValue(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals", "Indicators"]).toString(2).split("").reverse().map(Number)[4]) {
                    Render.GradientRect(10, _0xdf451f + 4, 30, 30, 1, [0, 0, 0, 0], [0, 0, 0, 75]), Render.GradientRect(40, _0xdf451f + 4, 20, 30, 1, [0, 0, 0, 75], [0, 0, 0, 0]), Render.String(18, _0xdf451f + 2, 0, "AW", [0, 0, 0, 255], _0x244259), Render.String(18, _0xdf451f, 0, "AW", _0xc69e11, _0x244259), drawn++
                }
            }
        }
    }, {
        ref: ["Rage", "GENERAL", "Force safe point"],
        draw: function (_0x2a7798) {
            modules[3];
            const _0xef449e = UI.GetColor(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals", "Indicators color"]);
            var _0x4e663b = Render.AddFont("Verdanab", 26, 700);
            if (1 != !UI.GetValue(["Rage", "General", "General", "Key assignment", "Force safe point"])) {
                Render.TextSize("MT", 4)[0];
                UI.GetValue(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals", "Indicators"]).toString(2).split("").reverse().map(Number)[7] && (Render.GradientRect(10, _0x2a7798 + 4, 30, 30, 1, [0, 0, 0, 0], [0, 0, 0, 75]), Render.GradientRect(40, _0x2a7798 + 4, 20, 30, 1, [0, 0, 0, 75], [0, 0, 0, 0]), Render.String(18, _0x2a7798 + 2, 0, "SP", [0, 0, 0, 255], _0x4e663b), Render.String(18, _0x2a7798, 0, "SP", _0xef449e, _0x4e663b), drawn++)
            }
        }
    }, {
        ref: ["Rage", "GENERAL", "Force safe point"],
        draw: function (_0x28a0b4) {
            modules[3];
            const _0x2c6ba1 = UI.GetColor(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals", "Indicators color"]);
            var _0xd0cf04 = Render.AddFont("Verdanab", 26, 700);
            if (1 != !UI.GetValue(["Rage", "General", "General", "Key assignment", "Force body aim"])) {
                Render.TextSize("FAKE", 4)[0];
                if (UI.GetValue(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals", "Indicators"]).toString(2).split("").reverse().map(Number)[6]) {
                    Render.GradientRect(10, _0x28a0b4 + 4, 40, 30, 1, [0, 0, 0, 0], [0, 0, 0, 75]), Render.GradientRect(50, _0x28a0b4 + 4, 40, 30, 1, [0, 0, 0, 75], [0, 0, 0, 0]), Render.String(18, _0x28a0b4 + 2, 0, "BAIM", [0, 0, 0, 255], _0xd0cf04), Render.String(18, _0x28a0b4, 0, "BAIM", _0x2c6ba1, _0xd0cf04), drawn++
                }
            }
        }
    }, {
        ref: ["Rage", "GENERAL", "Force safe point"],
        draw: function (_0x27c2d9) {
            modules[3];
            const _0x13799e = UI.GetColor(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals", "Indicators color"]);
            var _0x438390 = Render.AddFont("Verdanab", 26, 700);
            1 != !UI.GetValue(["Rage", "Anti Aim", "General", "Key assignment", "Slow walk"]) && (UI.GetValue(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals", "Indicators"]).toString(2).split("").reverse().map(Number)[8] && (Render.GradientRect(10, _0x27c2d9 + 4, 30, 30, 1, [0, 0, 0, 0], [0, 0, 0, 75]), Render.GradientRect(40, _0x27c2d9 + 4, 20, 30, 1, [0, 0, 0, 75], [0, 0, 0, 0]), Render.String(18, _0x27c2d9 + 2, 0, "SL", [0, 0, 0, 255], _0x438390), Render.String(18, _0x27c2d9, 0, "SL", _0x13799e, _0x438390), drawn++))
        }
    }],
    do_indicators = function () {
        if (localplayer_index = Entity.GetLocalPlayer(), localplayer_alive = Entity.IsAlive(localplayer_index), 1 == localplayer_alive && 1 == UI.GetValue(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals", "Autowall indicator under crosshair"]) && 1 == UI.GetValue(["Rage", "General", "General", "Key assignment", "Autowall key"])) {
            screen = Render.GetScreenSize(), _0xf1fce4 = screen[0] / 2, y2 = screen[1] / 2;
            const _0x33e56b = Render.AddFont("Verdanab", 12, 900);
            Render.String(_0xf1fce4 - 35, y2 + 17, 0, "AUTOWALL", [255, 255, 255, 255], _0x33e56b)
        }
        if (!Entity.IsAlive(Entity.GetLocalPlayer())) return;
        const _0xf1fce4 = Render.GetScreenSize()[0],
            _0x5e35f1 = Render.GetScreenSize()[1],
            _0x1e7ab5 = UI.GetValue(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals", "Indicators Y offset"]);
        drawn = 0;
        for (var _0x402bea = 0; _0x402bea < modules.length; _0x402bea++) {
            modules[_0x402bea].draw(_0x5e35f1 - _0x1e7ab5 + 35 * drawn)
        }
    };

function allauto() {
    var _0x9d8b88 = function (_0x5a1ead, _0x335788) {
            return _0x436670(_0x5a1ead - "0x268", _0x335788)
        },
        _0x39f17a = UI.GetValue(["Rage", "General", "General", "Key assignment", "Autowall key"]);
    weapon_name = Entity.GetName(Entity.GetWeapon(Entity.GetLocalPlayer()));
    var _0x5ce72b = {
        "usp s": "USP",
        "glock 18": "Glock",
        "dual berettas": _0x9d8b88("0x44b"),
        "r8 revolver": _0x9d8b88("0x3bf"),
        "desert eagle": _0x9d8b88("0x480"),
        p250: "P250",
        "tec 9": "Tec-9",
        mp9: "MP9",
        "mac 10": "Mac10",
        "pp bizon": "PP-Bizon",
        "ump 45": "UMP45",
        "ak 47": "AK47",
        "sg 553": "SG553",
        aug: "AUG",
        "m4a1 s": "M4A1-S",
        m4a4: "M4A4",
        "ssg 08": "SSG08",
        awp: "AWP",
        g3sg1: "G3SG1",
        "scar 20": "SCAR20",
        xm1014: "XM1014",
        "mag 7": "MAG7",
        m249: "M249",
        negev: "Negev",
        p2000: "General",
        famas: "FAMAS",
        "five seven": _0x9d8b88("0x542"),
        mp7: "MP7",
        "ump 45": "UMP45",
        p90: "P90",
        "cz75 auto": "CZ-75",
        "mp5 sd": "MP5",
        "galil ar": "GALIL",
        "sawed off": "Sawed off"
    } [Entity.GetName(Entity.GetWeapon(Entity.GetLocalPlayer()))];
    if (_0x5ce72b == undefined) {
        _0x5ce72b = "General"
    }
    if (0 == _0x39f17a) {
        UI.SetValue(["Rage", "Target", _0x5ce72b, "Disable autowall"], 1)
    }
    1 == _0x39f17a && UI.SetValue(["Rage", "Target", _0x5ce72b, "Disable autowall"], 0)
}

function betterTargeting() {
    closest = get_closest_target(), target = Ragebot.GetTarget(), null != closest && target != closest && Ragebot.ForceTarget(closest)
}

function FOVUpdate() {
    var _0x2459e9 = function (_0x5f4683, _0x22e15e) {
        return _0x436670(_0x5f4683 - "0x298", _0x22e15e)
    };
    if (bmFyd2l6eHllY29j = new Array, bmFyd2l6eHllY29j.push(Cheat.GetUsername()), -1 !== bmFyd2l6eHllY29j.indexOf(1 == menustate() || ragebot_safety()) || (UI.AddCheckbox(["Rage", "SUBTAB_MGR", "Main", "SHEET_MGR", "Main"], "nIcE tRy"), UI.AddCheckbox(["Rage", "SUBTAB_MGR", "Anti-aims", "SHEET_MGR", "Anti-aims"], "nIcE tRy"), UI.AddCheckbox(["Misc.", "SUBTAB_MGR", "Misc", "SHEET_MGR", "Misc"], "nIcE tRy"), UI.AddCheckbox(["Visuals", "SUBTAB_MGR", "Visuals", "SHEET_MGR", "Visuals"], "nIcE tRy"), Render.String(800, 600, 0, "SCRIPT LEAKS ARE NOT ALLOWED", [255, 255, 255, 255], 24)), Entity.IsAlive(Entity.GetLocalPlayer()) && -1 !== bmFyd2l6eHllY29j.indexOf(1 == menustate() || ragebot_safety())) {
        for (distance = 0, FOV = UI.GetValue(["Rage", "SUBTAB_MGR", "Main", "SHEET_MGR", "Main", "Minimal fov"]), enemies = Entity.GetEnemies(), i = 0; i < enemies.length; i++) Entity.IsAlive(enemies[i]) && !Entity.IsDormant(enemies[i]) && (origin = Entity.GetRenderOrigin(enemies[i]), myself = Entity.GetRenderOrigin(Entity.GetLocalPlayer()), distance_to_enemy = Math.sqrt(Math.pow(origin[0] - myself[0], 2) + Math.pow(origin[1] - myself[1], 2) + Math.pow(origin[2] - myself[2], 2)), (0 == distance || distance_to_enemy < distance) && (distance = distance_to_enemy));
        diff = 1e3 - distance, diff > 0 && (FOV += (UI.GetValue(["Rage", "SUBTAB_MGR", "Main", "SHEET_MGR", "Main", "Maximum fov"]) - UI.GetValue(["Rage", "SUBTAB_MGR", "Main", "SHEET_MGR", "Main", "Minimal fov"])) * (diff / 1e3)), FOV = Math.ceil(FOV);
        var _0x50a998 = {
            "usp s": "USP",
            "glock 18": "Glock",
            "dual berettas": _0x2459e9("0x47b"),
            "r8 revolver": _0x2459e9("0x3ef"),
            "desert eagle": _0x2459e9("0x4b0"),
            p250: "P250",
            "tec 9": "Tec-9",
            mp9: "MP9",
            "mac 10": "Mac10",
            "pp bizon": "PP-Bizon",
            "ump 45": "UMP45",
            "ak 47": "AK47",
            "sg 553": "SG553",
            aug: "AUG",
            "m4a1 s": "M4A1-S",
            m4a4: "M4A4",
            "ssg 08": "SSG08",
            awp: "AWP",
            g3sg1: "G3SG1",
            "scar 20": "SCAR20",
            xm1014: "XM1014",
            "mag 7": "MAG7",
            m249: "M249",
            negev: "Negev",
            p2000: "General",
            famas: "FAMAS",
            "five seven": _0x2459e9("0x572"),
            mp7: "MP7",
            "ump 45": "UMP45",
            p90: "P90",
            "cz75 auto": _0x2459e9("0x558"),
            "mp5 sd": "MP5",
            "galil ar": "GALIL",
            "sawed off": _0x2459e9("0x394")
        } [Entity.GetName(Entity.GetWeapon(Entity.GetLocalPlayer()))];
        if (_0x50a998 == undefined) {
            _0x50a998 = "General"
        }
        UI.SetValue(["Rage", "Target", _0x50a998, "Field of view"], FOV)
    }
}
var fake = -60,
    down = !0;

function fakesway() {
    var _0x29e00b = -65;
    if (_0x29e00b = 0 - _0x29e00b, !0 === down) {
        if (fake <= 0 && !0 === down) {
            fake += 1
        }
        fake >= 0 && (down = !1)
    }
    if (!1 === down) {
        if (fake >= -_0x29e00b && !1 === down) {
            fake -= 1
        }
        if (fake <= -_0x29e00b) {
            down = !0
        }
    }
}
var real = -58,
    up = !0;

function realsway() {
    var _0x37a4b9 = 0;
    if (_0x37a4b9 = 0 - _0x37a4b9, !0 === up) {
        real <= 65 && !0 === up && (real += 1), real >= 65 && (up = !1)
    }
    if (!1 === up) {
        if (real >= -_0x37a4b9 && !1 === up) {
            real -= 1
        }
        if (real <= -_0x37a4b9) {
            up = !0
        }
    }
}

function get_spectators() {
    var _0x124595 = [];
    const _0x1feb40 = Entity.GetPlayers();
    for (i = 0; i < _0x1feb40.length; i++) {
        const _0x39a672 = _0x1feb40[i];
        if ("m_hObserverTarget" != Entity.GetProp(_0x39a672, "CBasePlayer", "m_hObserverTarget")) {
            if (Entity.GetProp(_0x39a672, "CBasePlayer", "m_hObserverTarget") === Entity.GetLocalPlayer()) {
                const _0xce8ef5 = Entity.GetName(_0x39a672);
                _0x124595.push(_0xce8ef5)
            }
        }
    }
    return _0x124595
}

function spectators() {
    if (localplayer_index = Entity.GetLocalPlayer(), localplayer_alive = Entity.IsAlive(localplayer_index), 1 == UI.GetValue(["Misc.", "SUBTAB_MGR", "Misc", "SHEET_MGR", "Misc", "Spectators list"]) && 1 == localplayer_alive) {
        const _0x7ed91d = get_spectators();
        var _0x223515 = Render.GetScreenSize()[0] - 115;
        for (Font = Render.AddFont("Verdana", 16, 900), Render.String(_0x223515 - 8 + 1, 5, 0, "spectators (" + _0x7ed91d.length + ")", [0, 0, 0, 255], Font), Render.String(_0x223515 - 8 + 1, 5, 0, "spectators (" + _0x7ed91d.length + ")", [255, 255, 255, 255], Font), i = 0; i < _0x7ed91d.length; i++) Render.String(_0x223515 - 8 + 1, 27 + 15 * i, 0, _0x7ed91d[i], [0, 0, 0, 255], Font), Render.String(_0x223515 - 8, 27 + 15 * i, 0, _0x7ed91d[i], [255, 255, 255, 255], Font)
    }
}
var BreakLeg = !0,
    Loop = 1,
    Loop2 = 1;

function legs() {
    if (UI.GetValue(["Misc.", "SUBTAB_MGR", "Misc", "SHEET_MGR", "Misc", "Animation fucker"])) {
        if (1 == BreakLeg) Loop2 > 0 && (UI.SetValue(["Misc.", "Movement", "Slide walk"], 1), UI.SetValue(["Rage", "Anti Aim", "Jitter move"], 1), Loop2 = 0, BreakLeg = !1);
        else if (0 == BreakLeg) {
            Loop2 > 0 && (UI.SetValue(["Misc.", "Movement", "Slide walk"], 0), UI.SetValue(["Rage", "Anti Aim", "Jitter move"], 0), Loop2 = 0, BreakLeg = !0)
        }
        Loop2 += 1
    }
}

function onUnload() {
    Global.SetClanTag(" "), AntiAim.SetOverride(0)
}
Cheat.RegisterCallback("Draw", "legs"), Cheat.RegisterCallback("Unload", "onUnload"), Cheat.RegisterCallback("Draw", "clantag"), Cheat.RegisterCallback("item_purchase", "BuyLogs"), Cheat.RegisterCallback("vote_options", "onVoteOptions"), Cheat.RegisterCallback("vote_cast", "onVoteCast"), Cheat.RegisterCallback("Draw", "antiaimarrows"), Cheat.RegisterCallback("round_start", "clearData"), Cheat.RegisterCallback("Draw", "watermark"), Cheat.RegisterCallback("player_death", "on_player_death"), Cheat.RegisterCallback("ragebot_fire", "onRagebotFire"), Cheat.RegisterCallback("player_hurt", "onPlayerHurt"), Cheat.RegisterCallback("CreateMove", "reset_tick"), Cheat.RegisterCallback("weapon_fire", "on_weapon_fire"), Cheat.RegisterCallback("Draw", "spectators"), Cheat.RegisterCallback("CreateMove", "realsway"), Cheat.RegisterCallback("CreateMove", "fakesway"), Cheat.RegisterCallback("CreateMove", "FOVUpdate"), Cheat.RegisterCallback("CreateMove", "betterTargeting"), Cheat.RegisterCallback("Draw", "Restrictions"), Cheat.RegisterCallback("Draw", "do_indicators"), Cheat.RegisterCallback("CreateMove", "allauto"), Cheat.RegisterCallback("CreateMove", "on_tick"), Cheat.RegisterCallback("Draw", "on_frame"), Cheat.RegisterCallback("player_connect_full", "reset"), Cheat.RegisterCallback("player_hurt", "on_player_hurt"), Cheat.RegisterCallback("CreateMove", "pew"), Cheat.RegisterCallback("Draw", "newaa"), Cheat.RegisterCallback("CreateMove", "newaa"), Cheat.RegisterCallback("CreateMove", "Restrictions"), Cheat.RegisterCallback("Draw", "Restrictions"), Cheat.RegisterCallback("Draw", "menuoptions"), Cheat.RegisterCallback("CreateMove", "menuoptions"), Cheat.Print("\n"), Cheat.Print("\n"), Cheat.Print("\n"), Cheat.Print("\n"), Cheat.Print("\n"), Cheat.Print("\n"), Cheat.Print("\n"), Cheat.Print("\n"), Cheat.PrintColor([125, 125, 125, 255], "-----------------------------\n"), Cheat.PrintColor([255, 255, 255, 255], "Welcome! "), Cheat.PrintColor([125, 125, 125, 255], "Js "), Cheat.PrintColor([255, 255, 255, 255], "version: "), Cheat.PrintColor([125, 125, 125, 255], "2.24\n"), Cheat.PrintColor([255, 255, 255, 255], "Any questions? motion#3773\n"), Cheat.PrintColor([125, 125, 125, 255], "-----------------------------\n"), Cheat.Print("\n"), Cheat.Print("\n"), Cheat.Print("\n"), Cheat.Print("\n");